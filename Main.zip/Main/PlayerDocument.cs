using System;
using System.Collections.Generic;
using System.Linq;
using global::MongoDB.Bson;
using global::MongoDB.Bson.Serialization;
using global::MongoDB.Bson.Serialization.Serializers;

namespace StandRiseServer.MongoDB.Main
{
    // Custom serializer to handle banCode as both string and int
    public class FlexibleStringSerializer : SerializerBase<string>
    {
        public override string Deserialize(BsonDeserializationContext context, BsonDeserializationArgs args)
        {
            var bsonType = context.Reader.GetCurrentBsonType();
            switch (bsonType)
            {
                case global::MongoDB.Bson.BsonType.String:
                    return context.Reader.ReadString();
                case global::MongoDB.Bson.BsonType.Int32:
                    return context.Reader.ReadInt32().ToString();
                case global::MongoDB.Bson.BsonType.Int64:
                    return context.Reader.ReadInt64().ToString();
                case global::MongoDB.Bson.BsonType.Null:
                    context.Reader.ReadNull();
                    return null;
                default:
                    throw new FormatException($"Cannot deserialize string from BsonType {bsonType}");
            }
        }

        public override void Serialize(BsonSerializationContext context, BsonSerializationArgs args, string value)
        {
            if (value == null)
            {
                context.Writer.WriteNull();
            }
            else
            {
                context.Writer.WriteString(value);
            }
        }
    }

    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class PlayerDocument : DocumentModelBase
    {
        private string _uid;
        private string _name;
        private string _avatarId;
        private int _timeInGame;
        private string _class1;
        private BsonDateTime _updateDate;
        private BsonDateTime _createDate;

        public string uid
        {
            get => _uid;
            set => _uid = value;
        }

        public string name
        {
            get => _name;
            set => _name = value;
        }

        public string avatarId
        {
            get => _avatarId;
            set => _avatarId = value;
        }

        public int timeInGame 
        { 
            get => _timeInGame; 
            set => _timeInGame = value;
        }

        public string _class
        {
            get => _class1;
            set => _class1 = value;
        }
        public bool noDetectRoot { get; set; }
        public bool isBanned { get; set; }

        // Ban-related fields
        [global::MongoDB.Bson.Serialization.Attributes.BsonSerializer(typeof(FlexibleStringSerializer))]
        public string banCode { get; set; }
        public string banReason { get; set; }
        public BsonDateTime banDate { get; set; }
        public BsonDateTime unbanDate { get; set; }
        public string bannedBy { get; set; }
        public BsonDateTime banExpireDate { get; set; }
        public int banDuration { get; set; }
        public string banType { get; set; }
        public BsonArray banHistory { get; set; }
        
        // Anticheat fields
        public int anticheat { get; set; } // 0 = not running, 1 = running
        public bool anticheatFlagged { get; set; }
        public string anticheatViolationType { get; set; }
        public double anticheatViolationValue { get; set; }
        public BsonDateTime anticheatFlagDate { get; set; }

        // Mute-related fields
        public bool isMuted { get; set; }
        [global::MongoDB.Bson.Serialization.Attributes.BsonSerializer(typeof(FlexibleStringSerializer))]
        public string muteCode { get; set; }
        public string muteReason { get; set; }
        public BsonDateTime muteDate { get; set; }
        public string mutedBy { get; set; }
        public BsonDateTime muteExpireDate { get; set; }
        public int muteDuration { get; set; }
        public string muteType { get; set; }
        public BsonArray muteHistory { get; set; }
        
        // Warning-related fields
        public int warningCount { get; set; }
        public string warningReason { get; set; }
        public BsonDateTime warningDate { get; set; }
        public string warnedBy { get; set; }
        public BsonArray warningHistory { get; set; }
        
        // Kick-related fields
        public int kickCount { get; set; }
        public string kickReason { get; set; }
        public BsonDateTime kickDate { get; set; }
        public string kickedBy { get; set; }
        public BsonArray kickHistory { get; set; }
        
        // Tester fields
        public string testerRole { get; set; }
        public bool isTester { get; set; }
        
        // Version bypass field
        public bool bypassVersionCheck { get; set; }
        
        // Moderator/Admin fields
        public bool isModerator { get; set; }
        public bool isAdmin { get; set; }
        public string moderatorRole { get; set; }
        public string adminRole { get; set; }
        public BsonArray permissions { get; set; }
        
        // VIP/Premium fields
        public bool isVip { get; set; }
        public bool isPremium { get; set; }
        public BsonDateTime vipExpireDate { get; set; }
        public BsonDateTime premiumExpireDate { get; set; }
        
        // Other fields
        public BsonDocument attributes { get; set; }
        public BsonDocument playerStatus { get; set; }
        public BsonDocument settings { get; set; }
        public BsonDocument metadata { get; set; }
        public string lastIp { get; set; }
        public BsonDateTime lastLoginDate { get; set; }
        public BsonDateTime lastActivityDate { get; set; }
        public string deviceId { get; set; }
        public string platform { get; set; }
        public string version { get; set; }
        public string locale { get; set; }
        public string country { get; set; }
        public string region { get; set; }
        public int loginCount { get; set; }
        public BsonArray loginHistory { get; set; }
        
        // Request token fields для защиты от дюпов
        public string currentRequestToken { get; set; }
        public BsonDateTime requestTokenExpiry { get; set; }
        public int requestCount { get; set; }
        public BsonDateTime lastRequestTime { get; set; }

        public BsonDateTime updateDate
        {
            get => _updateDate;
            set => _updateDate = value;
        }

        public BsonDateTime createDate
        {
            get => _createDate;
            set => _createDate = value;
        }
    }
}
