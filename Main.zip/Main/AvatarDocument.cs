using global::MongoDB.Bson;
using System;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class AvatarDocument : DocumentModelBase
    {
        public string avatarId { get; set; }
        public BsonArray bytes { get; set; }
    }
}
