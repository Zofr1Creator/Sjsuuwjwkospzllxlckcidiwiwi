using MongoDB.Bson;
using Axlebolt.Bolt.Protobuf;
using System;

namespace StandRiseServer.MongoDB.Main.GameSettings
{
    public static class GameSettingsExtension
    {
        public static GameSetting GetGameSetting(this BsonElement bsonElement)
        {
            SettingType settingType = bsonElement.Value.BsonType.GetSettingType();
            GameSetting gamesetting = new GameSetting { Key = bsonElement.Name, Type = settingType };
            switch (settingType)
            {
                case SettingType.Integer:
                    gamesetting.IntValue = bsonElement.Value.AsInt32;
                    break;
                case SettingType.Bool:
                    gamesetting.BoolValue = bsonElement.Value.AsBoolean;
                    break;
                case SettingType.Float:
                    gamesetting.FloatValue = (float)bsonElement.Value.ToDouble();
                    break;
                case SettingType.String:
                    gamesetting.Value = bsonElement.Value.AsString;
                    break;
            };
            return gamesetting;
        }
        public static SettingType GetSettingType(this BsonType type)
        {
            switch(type)
            {
                case BsonType.Int32:
                    return SettingType.Integer;
                case BsonType.Boolean:
                    return SettingType.Bool;
                case BsonType.Double:
                    return SettingType.Float;
                case BsonType.String:
                    return SettingType.String;
            };
            throw new ArgumentOutOfRangeException();
        }
        public static bool TryGetValue(this BsonDocument gameSetting, string key, out int value, int defaultValue)
        {
            bool result = gameSetting.TryGetValue(key, out BsonValue bsonValue);
            if (result)
                value = bsonValue.AsInt32;
            else
                value = defaultValue;
            return result;
        }
        public static bool TryGetValue(this BsonDocument gameSetting, string key, out bool value, bool defaultValue)
        {
            bool result = gameSetting.TryGetValue(key, out BsonValue bsonValue);
            if (result)
                value = bsonValue.AsBoolean;
            else
                value = defaultValue;
            return result;
        }
        public static bool TryGetValue(this BsonDocument gameSetting, string key, out string value, string defaultValue)
        {
            bool result = gameSetting.TryGetValue(key, out BsonValue bsonValue);
            if (result)
                value = bsonValue.AsString;
            else
                value = defaultValue;
            return result;
        }
        public static bool TryGetValue(this BsonDocument gameSetting, string key, out float value, float defaultValue)
        {
            bool result = gameSetting.TryGetValue(key, out BsonValue bsonValue);
            if (result)
                value = (float)bsonValue.ToDouble();
            else
                value = defaultValue;
            return result;
        }
    }
}
