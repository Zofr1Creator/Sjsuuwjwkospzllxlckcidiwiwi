using System;
using MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public class GameDocument
    {
        private int _id1;
        private string _gameUid;
        private string _code;
        private BsonDocument _androidSettings;
        private BsonDocument _iosSettings;
        private string _minVersion;
        private string _defaultLocale;

        public int _id
        {
            get => _id1;
            set => _id1 = value;
        }

        public string gameUid
        {
            get => _gameUid;
            set => _gameUid = value;
        }

        public string code
        {
            get => _code;
            set => _code = value;
        }

        public BsonDocument androidSettings
        {
            get => _androidSettings;
            set => _androidSettings = value;
        }

        public BsonDocument iosSettings
        {
            get => _iosSettings;
            set => _iosSettings = value;
        }

        public string minVersion
        {
            get => _minVersion;
            set => _minVersion = value;
        }

        public string defaultLocale
        {
            get => _defaultLocale;
            set => _defaultLocale = value;
        }
        
        // Additional game settings
        public BsonDocument settings { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument features { get; set; }
        public BsonDocument limits { get; set; }
        public BsonDocument economy { get; set; }
        public BsonDocument events { get; set; }
        public BsonDocument seasons { get; set; }
        public bool isActive { get; set; }
        public bool isMaintenance { get; set; }
        public string maintenanceMessage { get; set; }
        public BsonDateTime maintenanceStartDate { get; set; }
        public BsonDateTime maintenanceEndDate { get; set; }
        public string currentVersion { get; set; }
        public string requiredVersion { get; set; }
        public BsonArray supportedVersions { get; set; }
        public BsonDocument serverConfig { get; set; }
        public BsonDocument clientConfig { get; set; }

    }
}
