using MongoDB.Bson;
using Axlebolt.Bolt.Protobuf;
using System;

namespace StandRiseServer.MongoDB.Main.PlayerStats
{
    public static class PlayerStatsExtension
    {
        public static PlayerStat GetPlayerStat(this BsonElement bsonElement)
        {
            bool forceInt = ShouldUseIntegralEncoding(bsonElement.Name);
            StatDefType statType = forceInt ? StatDefType.Int : bsonElement.Value.BsonType.GetStatType();
            PlayerStat playerStat = new PlayerStat { Name = bsonElement.Name, Type = statType };
            
            switch (statType)
            {
                case StatDefType.Int:
                    playerStat.IntValue = ToIntValue(bsonElement.Value);
                    playerStat.LongValue = ToLongValue(bsonElement.Value);
                    break;
                case StatDefType.Float:
                    if (bsonElement.Value.IsDouble)
                        playerStat.FloatValue = (float)bsonElement.Value.AsDouble;
                    else if (bsonElement.Value.IsInt32)
                        playerStat.FloatValue = (float)bsonElement.Value.AsInt32;
                    else if (bsonElement.Value.IsInt64)
                        playerStat.FloatValue = (float)bsonElement.Value.AsInt64;
                    break;
            };
            return playerStat;
        }

        private static bool ShouldUseIntegralEncoding(string statName)
        {
            if (string.IsNullOrWhiteSpace(statName))
            {
                return false;
            }

            return statName.EndsWith("_mmr", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_rank", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_matches", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_count", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_xp", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_time", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_id", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_until", StringComparison.OrdinalIgnoreCase);
        }

        private static int ToIntValue(BsonValue value)
        {
            if (value == null || value.IsBsonNull)
            {
                return 0;
            }

            if (value.IsInt32)
            {
                return value.AsInt32;
            }

            if (value.IsInt64)
            {
                long longValue = value.AsInt64;
                if (longValue > int.MaxValue) return int.MaxValue;
                if (longValue < int.MinValue) return int.MinValue;
                return (int)longValue;
            }

            if (value.IsDouble)
            {
                double doubleValue = value.AsDouble;
                if (double.IsNaN(doubleValue) || double.IsInfinity(doubleValue)) return 0;
                if (doubleValue > int.MaxValue) return int.MaxValue;
                if (doubleValue < int.MinValue) return int.MinValue;
                return (int)Math.Round(doubleValue);
            }

            if (value.IsBoolean)
            {
                return value.AsBoolean ? 1 : 0;
            }

            if (value.IsString && int.TryParse(value.AsString, out var parsedInt))
            {
                return parsedInt;
            }

            if (value.IsString && double.TryParse(value.AsString, out var parsedDouble))
            {
                if (parsedDouble > int.MaxValue) return int.MaxValue;
                if (parsedDouble < int.MinValue) return int.MinValue;
                return (int)Math.Round(parsedDouble);
            }

            return 0;
        }

        private static long ToLongValue(BsonValue value)
        {
            if (value == null || value.IsBsonNull)
            {
                return 0L;
            }

            if (value.IsInt64)
            {
                return value.AsInt64;
            }

            if (value.IsInt32)
            {
                return value.AsInt32;
            }

            if (value.IsDouble)
            {
                double doubleValue = value.AsDouble;
                if (double.IsNaN(doubleValue) || double.IsInfinity(doubleValue)) return 0L;
                if (doubleValue > long.MaxValue) return long.MaxValue;
                if (doubleValue < long.MinValue) return long.MinValue;
                return (long)Math.Round(doubleValue);
            }

            if (value.IsBoolean)
            {
                return value.AsBoolean ? 1L : 0L;
            }

            if (value.IsString && long.TryParse(value.AsString, out var parsedLong))
            {
                return parsedLong;
            }

            if (value.IsString && double.TryParse(value.AsString, out var parsedDouble))
            {
                if (parsedDouble > long.MaxValue) return long.MaxValue;
                if (parsedDouble < long.MinValue) return long.MinValue;
                return (long)Math.Round(parsedDouble);
            }

            return 0L;
        }

        public static StatDefType GetStatType(this BsonType type)
        {
            switch (type)
            {
                case BsonType.Int32:
                case BsonType.Int64:
                    return StatDefType.Int;
                case BsonType.Double:
                    return StatDefType.Float;
                default:
                    return StatDefType.Int;
            };
        }
    }
}
