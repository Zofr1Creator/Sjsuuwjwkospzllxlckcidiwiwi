using MongoDB.Bson;
using System;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public class GoogleAccountDocument : AccountDocumentBase
    {
        public string googleId { get; set; }
        public BsonDocument deviceInfo { get; set; }
        public BsonDocument verification { get; set; }
    }
}
