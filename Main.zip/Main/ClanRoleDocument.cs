using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using Google.Protobuf.Collections;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace StandRiseServer.MongoDB.Main
{
    public class ClanRoleDocument
    {
        // Re-defining _id to int because that's what it is in the DB for roles
        [BsonId]
        public int _id { get; set; }

        public string name { get; set; }

        public string description { get; set; }

        public int level { get; set; }

        public BsonArray permissions { get; set; }

        public ClanMemberRole GetRole()
        {
            ClanMemberRole role = new ClanMemberRole
            {
                Name = name,
                Level = level,
                Descripption = description,
                Id = _id
            };
            role.Permissions.AddRange(GetClanMemberRolePermissions());
            return role;
        }

        public List<ClanMemberRolePermission> GetClanMemberRolePermissions()
        {
            List<ClanMemberRolePermission> list = new List<ClanMemberRolePermission>();
            if (permissions != null)
            {
                for (int i = 0; i < permissions.Count; i++)
                {
                    list.Add((ClanMemberRolePermission)permissions[i].AsInt32);
                }
            }
            return list;
        }
    }
}
