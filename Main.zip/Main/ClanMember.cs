using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.RpcServer;

namespace StandRiseServer.MongoDB.Main
{
    public class ClanMember
    {
        public string playerId { get; set; }

        public string role { get; set; }

        public string clanId { get; set; }

        public BsonDateTime joinDate { get; set; }
        
        // Additional member fields
        public BsonDateTime lastActivityDate { get; set; }
        public int contributionPoints { get; set; }
        public BsonDocument stats { get; set; }
        public BsonDocument permissions { get; set; }
        public BsonDocument metadata { get; set; }
        public string invitedBy { get; set; }
        public BsonDateTime inviteDate { get; set; }
        public string rank { get; set; }
        public int level { get; set; }
        public int experience { get; set; }
        public BsonArray achievements { get; set; }
        public BsonArray badges { get; set; }
        public string status { get; set; }
        public string note { get; set; }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument
            {
                { "playerId", playerId },
                { "role", role },
                { "joinDate", joinDate },
                { "clanId", clanId }
            };
        }

        public Axlebolt.Bolt.Protobuf.ClanMember GetClanMember()
        {
            Axlebolt.Bolt.Protobuf.ClanMember member = new Axlebolt.Bolt.Protobuf.ClanMember
            {
                ClanId = clanId,
                CreateDate = Utils.ToUnixTime(joinDate.ToUniversalTime()),
                RoleId = GetRoleDocument().Id
            };
            member.PlayerFriend.Player = FriendHelper.GetPlayer(playerId);
            member.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
            member.PlayerFriend.LastRelationshipUpdate = Utils.ToUnixTime(DateTime.Now);
            return member;
        }

        public ClanMemberRole GetRoleDocument()
        {
            return BoltMainDatabaseProvider.Instance.GetClanMemberRoleByIdString(role);
        }
    }
}
