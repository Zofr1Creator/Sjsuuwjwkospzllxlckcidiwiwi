using System;
using global::MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class HashDocument : DocumentModelBase
    {
        public string version { get; set; }
        public string gameId { get; set; }
        public string hash { get; set; }
        public string signature { get; set; }
        
        // Additional hash fields
        public BsonDateTime createDate { get; set; }
        public BsonDateTime updateDate { get; set; }
        public string algorithm { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }
        public string platform { get; set; }
        public string buildNumber { get; set; }
        public bool isValid { get; set; }
        public BsonDateTime expireDate { get; set; }
    }
}
