using System;
using System.Collections.Generic;
using System.Linq;
using global::MongoDB.Bson;
using StandRiseServer.RpcServer;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class PlayerStatsDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public BsonDocument stats { get; set; }
        
        // Additional stats metadata
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime createDate { get; set; }
        public int version { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument seasonStats { get; set; }
        public BsonDocument achievements { get; set; }
        public BsonDocument challenges { get; set; }
        public BsonDocument rewards { get; set; }
        public BsonDocument progression { get; set; }
        public BsonDocument leaderboards { get; set; }
        public BsonDocument rankings { get; set; }
    }
    public static class PlayerStatsExtension
    {
        private static bool IsCustomWeapon(WeaponId weaponId)
        {
            return weaponId == WeaponId.GrenadeSnowball || weaponId == WeaponId.SnowPistol || weaponId == WeaponId.SnowM40 || weaponId == WeaponId.SantaGrenadeSnowball || weaponId == WeaponId.SM1014Mincer || weaponId == WeaponId.Bat;
        }
        public static WeaponId[] GetBaseWeaponIds()
        {
            IEnumerable<WeaponId> source = Enum.GetValues(typeof(WeaponId)).Cast<WeaponId>();
            return source.Where((WeaponId weaponId) => !IsCustomWeapon(weaponId) && (int)weaponId <= 89).ToArray();
        }
        public static string WrapMode(string apiName, string gameMode)
        {
            return gameMode.ToLower() + "_" + apiName;
        }

        public static string WrapModeGun(string apiName, string gameMode, WeaponId weaponId)
        {
            return "gun_" + gameMode.ToLower() + "_" + weaponId.ToString().ToLower() + "_" + apiName;
        }
        public static List<BsonElement> GetAllNullStats()
        {
            List<string> gameModes = new List<string> 
            {
                "ArmsRace",
                "CaptureTheFlag",
                "DeathMatch",
                "Defuse",
                "RankedDefuse",
                "KingOfTheHill",
                "MadSanta",
                "Rampage",
                "SniperDuel",
                "SnowMadness",
                "Escort",
                "Zombies",
                "Training",
                "Allies",
                "Ranked2v2"
            };
            List<BsonElement> list = new List<BsonElement>();
            WeaponId[] basse = GetBaseWeaponIds();
            foreach (string gameMode in gameModes)
            {
                list.Add(new BsonElement(WrapMode("damage", gameMode), 0.0));
                list.Add(new BsonElement(WrapMode("damage_dealt", gameMode), 0.0));
                list.Add(new BsonElement(WrapMode("damage_taken", gameMode), 0.0));
                list.Add(new BsonElement(WrapMode("assists", gameMode), 0));
                list.Add(new BsonElement(WrapMode("deaths", gameMode), 0));
                list.Add(new BsonElement(WrapMode("games_played", gameMode), 0));
                list.Add(new BsonElement(WrapMode("headshots", gameMode), 0));
                list.Add(new BsonElement(WrapMode("hits", gameMode), 0));
                list.Add(new BsonElement(WrapMode("kills", gameMode), 0));
                list.Add(new BsonElement(WrapMode("shots", gameMode), 0));
                list.Add(new BsonElement(WrapMode("wins", gameMode), 0));
                list.Add(new BsonElement(WrapMode("losses", gameMode), 0));
                
                foreach (WeaponId weaponId in basse)
                {
                    list.Add(new BsonElement(WrapModeGun("shots", gameMode, weaponId), 0));
                    list.Add(new BsonElement(WrapModeGun("kills", gameMode, weaponId), 0));
                    list.Add(new BsonElement(WrapModeGun("hits", gameMode, weaponId), 0));
                    list.Add(new BsonElement(WrapModeGun("headshots", gameMode, weaponId), 0));
                    list.Add(new BsonElement(WrapModeGun("damage", gameMode, weaponId), 0.0));
                }
            }
            
            // Core stats
            list.Add(new BsonElement("kills", 0));
            list.Add(new BsonElement("deaths", 0));
            list.Add(new BsonElement("assists", 0));
            list.Add(new BsonElement("shots", 0));
            list.Add(new BsonElement("hits", 0));
            list.Add(new BsonElement("headshots", 0));
            list.Add(new BsonElement("damage", 0.0));
            list.Add(new BsonElement("damage_dealt", 0.0));
            list.Add(new BsonElement("damage_taken", 0.0));
            list.Add(new BsonElement("games_played", 0));
            list.Add(new BsonElement("wins", 0));
            list.Add(new BsonElement("losses", 0));

            // Ranked/Competitive stats
            list.Add(new BsonElement("ranked_best_rank", -1));
            list.Add(new BsonElement("ranked_rank", 0));
            list.Add(new BsonElement("ranked_current_mmr", 1000));
            list.Add(new BsonElement("ranked_target_mmr", 1000));
            list.Add(new BsonElement("ranked_ban_code", 0));
            list.Add(new BsonElement("ranked_ban_reason", ""));
            list.Add(new BsonElement("ranked_ban_duration", 0));
            list.Add(new BsonElement("ranked_banned_until", 0));
            list.Add(new BsonElement("RANKED_BANNED_UNTIL", 0));
            list.Add(new BsonElement("ranked_calibration_match_count", 0));
            list.Add(new BsonElement("ranked_last_match_status", 0));
            list.Add(new BsonElement("ranked_last_match_start_time", 0L));
            list.Add(new BsonElement("ranked_banned_match_no", 0));
            list.Add(new BsonElement("ranked_best_rank_history1", 0));
            list.Add(new BsonElement("ranked_last_activity_time1", 0));
            list.Add(new BsonElement("ranked_last_activity_time2", 0));
            list.Add(new BsonElement("ranked_won_match_count", 0));
            list.Add(new BsonElement("ranked_played_matches", 0));
            
            // Allies (2v2) stats (Standard naming)
            list.Add(new BsonElement("ranked_2v2_current_mmr", 1000));
            list.Add(new BsonElement("ranked_2v2_rank", 0));
            list.Add(new BsonElement("ranked_2v2_best_rank", -1));
            list.Add(new BsonElement("ranked_2v2_played_matches", 0));
            list.Add(new BsonElement("ranked_2v2_won_match_count", 0));
            list.Add(new BsonElement("ranked_2v2_calibration_match_count", 10)); // Calibration matches remaining
            list.Add(new BsonElement("ranked_2v2_best_rank_history1", 0));

            // Progression
            list.Add(new BsonElement("level_id", 1));
            list.Add(new BsonElement("level_xp", 0));
            list.Add(new BsonElement("time_played", 0));
            list.Add(new BsonElement("total_time", 0));
            list.Add(new BsonElement("accuracy", 0.0));
            list.Add(new BsonElement("headshots_percentage", 0.0));

            // Season and Clan stats (Updated 0.15.0+)
            list.Add(new BsonElement("current_season_id", "SEASON_03"));
            list.Add(new BsonElement("clan_ranked_current_mmr", 1000));
            list.Add(new BsonElement("clan_ranked_rank", 0));
            list.Add(new BsonElement("clan_ranked_best_rank", -1));
            list.Add(new BsonElement("clan_ranked_played_matches", 0));
            list.Add(new BsonElement("clan_ranked_won_match_count", 0));
            list.Add(new BsonElement("clan_ranked_calibration_match_count", 10));
            list.Add(new BsonElement("clan_ranked_xp", 0));
            list.Add(new BsonElement("clan_ranked_best_rank_history1", 0));
            
            list.Add(new BsonElement("clan_member_ranked_xp", 0));
            list.Add(new BsonElement("clan_member_ranked_played_matches", 0));
            list.Add(new BsonElement("clan_member_ranked_won_match_count", 0));
            list.Add(new BsonElement("clan_member_ranked_last_match_status", 0));
            list.Add(new BsonElement("clan_member_ranked_last_match_start_time", 0L));

            
            return list;
        }
    }
}
