using System;
using global::MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class BoltPlayerGameEventDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public int currentLevel { get; set; }
        public int points { get; set; }
        public object missions { get; set; }
        
        // Additional game event fields
        public BsonDateTime createDate { get; set; }
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime expireDate { get; set; }
        public int eventId { get; set; }
        public string eventType { get; set; }
        public BsonDocument progress { get; set; }
        public BsonDocument rewards { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }
        public bool isCompleted { get; set; }
        public bool isActive { get; set; }
        public BsonArray completedMissions { get; set; }
        public BsonArray activeMissions { get; set; }
        public int totalPoints { get; set; }
        public int earnedPoints { get; set; }
    }
}
