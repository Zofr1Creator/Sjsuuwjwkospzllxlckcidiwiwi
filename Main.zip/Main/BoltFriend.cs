using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    public class BoltFriend
    {
        public string Id {get;set;}
        public string Uid {get;set;}
    }
    public static class BoltHelper
    {
        public static BoltFriend GetBoltFriend(this PlayerDocument a)
        {
            return new BoltFriend { Id = a._id.ToString(), Uid = a.uid };
        }
        public static PlayerDocument GetPlayerDocument(this BoltFriend a)
        {
            return BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(a.Id));
        }
    }
}
