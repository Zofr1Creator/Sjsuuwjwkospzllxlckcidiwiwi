using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public class DeviceInfo
    {
        public string DeviceId { get; set; }
        public string DeviceModel { get; set; }
        public BsonDocument GetBsonElements()
        {
            return new BsonDocument(
                new BsonElement[]
                {
                    new BsonElement("DeviceId", DeviceId),
                    new BsonElement("DeviceModel", DeviceModel)
                }
                as IEnumerable<BsonElement>);
        }
    }
}
