using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [BsonIgnoreExtraElements]
    public class FileStoragesDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public BsonDocument files { get; set; } = new BsonDocument();
        
        // Additional file storage fields
        public BsonDateTime createDate { get; set; }
        public BsonDateTime updateDate { get; set; }
        public long totalSize { get; set; }
        public long usedSize { get; set; }
        public long maxSize { get; set; }
        public int fileCount { get; set; }
        public BsonDocument metadata { get; set; } = new BsonDocument();
        public BsonDocument settings { get; set; } = new BsonDocument();
        public BsonArray fileList { get; set; } = new BsonArray();
        public BsonDocument quotas { get; set; } = new BsonDocument();
    }
}
