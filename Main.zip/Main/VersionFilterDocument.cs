using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace StandRiseServer.MongoDB.Main
{
    public class VersionFilterDocument
    {
        [BsonId]
        public string _id { get; set; } // version string, e.g. "0.16.0"

        public List<int> allowedPlatforms { get; set; } = new List<int>(); // 1=Android, 2=iOS

        public bool enabled { get; set; } = true;
    }
}
