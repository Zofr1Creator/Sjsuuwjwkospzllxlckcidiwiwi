using System;
using global::MongoDB.Bson;
using Axlebolt.Bolt.Protobuf;

namespace StandRiseServer.MongoDB.Main
{
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class ClanMatchDocument : DocumentModelBase
    {
        public string ClanId { get; set; }
        
        public BsonDocument MatchData { get; set; }
        
        public BsonDateTime Timestamp { get; set; }
        
        // Additional match fields
        public BsonDateTime createDate { get; set; }
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime startDate { get; set; }
        public BsonDateTime endDate { get; set; }
        public string matchId { get; set; }
        public string matchType { get; set; }
        public int matchStatus { get; set; }
        public string opponentClanId { get; set; }
        public BsonDocument result { get; set; }
        public BsonDocument stats { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }
        public BsonArray participants { get; set; }
        public int score { get; set; }
        public int opponentScore { get; set; }
        public string winner { get; set; }
        public BsonArray rounds { get; set; }
        public string gameMode { get; set; }
        public string mapName { get; set; }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument
            {
                { "clanId", ClanId },
                { "matchData", MatchData },
                { "timestamp", Timestamp }
            };
        }
    }
}
