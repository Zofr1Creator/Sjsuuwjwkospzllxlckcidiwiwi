using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.RpcServer;

using MongoDB.Bson.Serialization.Attributes;

namespace StandRiseServer.MongoDB.Main
{
	[Serializable]
	[BsonIgnoreExtraElements]
	public class ClanDocument : DocumentModelBase
	{
		public class ClanMessage
		{
			public string senderId { get; set; }

			public List<string> playersRead { get; set; }
		}

		[BsonElement("name")]
		public string name { get; set; }

		[BsonElement("description")]
		public string description { get; set; }

		[BsonElement("type")]
		public ClanType type { get; set; }

		[BsonElement("tag")]
		public string tag { get; set; }

		[BsonElement("avatarId")]
		public string avatarId { get; set; }

		[BsonElement("members")]
		public BsonDocument members { get; set; } = new BsonDocument();

		[BsonElement("messages")]
		public BsonDocument messages { get; set; } = new BsonDocument();

		[BsonElement("requests")]
		public BsonDocument requests { get; set; } = new BsonDocument();

		[BsonElement("invites")]
		public BsonDocument invites { get; set; } = new BsonDocument();

		[BsonElement("creationDate")]
		public BsonDateTime creationDate { get; set; }

		[BsonElement("clanLevel")]
		public int clanLevel { get; set; }

		[BsonElement("membersCount")]
		public int membersCount { get; set; }

		[BsonElement("maxMembersCount")]
		public int maxMembersCount { get; set; }
		
		[BsonElement("stats")]
		public BsonDocument stats { get; set; } = new BsonDocument();
		
		// Ban and moderation fields
		public bool isBanned { get; set; }
		public string banCode { get; set; }
		public string banReason { get; set; }
		public BsonDateTime banDate { get; set; }
		public string bannedBy { get; set; }
		public BsonDateTime banExpireDate { get; set; }
		public int banDuration { get; set; }
		public string banType { get; set; }
		public BsonArray banHistory { get; set; }
		
		// Clan settings and metadata
		public BsonDocument settings { get; set; }
		public BsonDocument metadata { get; set; }
		public string ownerId { get; set; }
		public BsonArray roles { get; set; }
		public BsonDocument permissions { get; set; }
		public bool isVerified { get; set; }
		public bool isOfficial { get; set; }
		public BsonDateTime lastActivityDate { get; set; }
		public int activityScore { get; set; }
		public string region { get; set; }
		public string language { get; set; }
		public BsonArray tags { get; set; }
		public int wins { get; set; }
		public int losses { get; set; }
		public int draws { get; set; }
		public int totalMatches { get; set; }
		public double winRate { get; set; }
		public int ranking { get; set; }
		public int mmr { get; set; }
		public int seasonId { get; set; }
		public BsonDocument seasonStats { get; set; }

		public List<Axlebolt.Bolt.Protobuf.ClanMember> GetMembers()
		{
			List<Axlebolt.Bolt.Protobuf.ClanMember> list = new List<Axlebolt.Bolt.Protobuf.ClanMember>();
			
			if (members == null || members.ElementCount == 0)
			{
				Console.WriteLine($"[ClanDocument] GetMembers: No members found for clan {name} ({tag})");
				return list;
			}
			
			BsonElement[] array = members.ToArray();
			Console.WriteLine($"[ClanDocument] GetMembers: Processing {array.Length} members for clan {name} ({tag})");
			
			for (int i = 0; i < array.Length; i++)
			{
				string playerId = array[i].Name;
				string role = "Member";
				DateTime joinDate = DateTime.UtcNow;
				
				try
				{
					BsonElement val = array[i];
					if (val.Value.IsBsonDocument)
					{
						var memberDoc = val.Value.AsBsonDocument;
						if (memberDoc.TryGetValue("playerId", out var playerIdValue) && playerIdValue.IsString)
						{
							playerId = playerIdValue.AsString;
						}
						if (memberDoc.TryGetValue("role", out var roleValue) && roleValue.IsString)
						{
							role = roleValue.AsString;
						}
						if (memberDoc.TryGetValue("joinDate", out var joinDateValue) && joinDateValue.BsonType == BsonType.DateTime)
						{
							joinDate = joinDateValue.ToUniversalTime();
						}
					}
					
					if (string.IsNullOrWhiteSpace(playerId))
					{
						Console.WriteLine($"[ClanDocument] GetMembers: Skipping member {i} due to empty playerId");
						continue;
					}
					
					Console.WriteLine($"[ClanDocument] GetMembers: Processing member {i}: playerId={playerId}, role={role}");
					
					Axlebolt.Bolt.Protobuf.ClanMember member = new Axlebolt.Bolt.Protobuf.ClanMember
					{
						RoleId = BoltMainDatabaseProvider.Instance.GetClanMemberRoleByIdString(role).Id,
						ClanId = _id.ToString(),
						CreateDate = Utils.ToUnixTime(joinDate)
					};
					
					try
					{
						member.PlayerFriend.Player = FriendHelper.GetPlayer(playerId);
					}
					catch (System.Exception ex)
					{
						Console.WriteLine($"[ClanDocument] GetMembers: Failed to load player {playerId}: {ex.Message}");
						member.PlayerFriend.Player = new Player
						{
							Id = playerId,
							Uid = string.Empty,
							Name = playerId,
							AvatarId = string.Empty,
							PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus
							{
								PlayerId = playerId
							}
						};
					}
					
					member.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
					member.PlayerFriend.LastRelationshipUpdate = Utils.ToUnixTime(DateTime.UtcNow);
					list.Add(member);
					
					Console.WriteLine($"[ClanDocument] GetMembers: Added member {member.PlayerFriend.Player.Name} (ID: {playerId})");
				}
				catch (System.Exception ex)
				{
					Console.WriteLine($"[ClanDocument] GetMembers: Error processing member {i} ({playerId}): {ex.Message}");
				}
			}
			
			Console.WriteLine($"[ClanDocument] GetMembers: Returning {list.Count} members");
			return list;
		}

        public List<ClanUserMessage> GetMessages()
        {
            List<ClanUserMessage> list = new List<ClanUserMessage>();
            BsonElement[] array = messages.ToArray();
            for (int i = 0; i < array.Length; i++)
            {
                BsonElement val = array[i];
                list.Add(new ClanUserMessage
                {
                    MessageType = MessageType.ChatMessage,
                    ChatMessage = new ClanChatMessage
                    {
                        SenderId = val.Value.AsBsonDocument.GetValue("senderId").AsString,
                        Message = val.Value.AsBsonDocument.GetValue("message").AsString
                    },
                    Timestamp = Utils.ToUnixTime(val.Value.AsBsonDocument.GetValue("timestamp").ToUniversalTime())
                });
            }
            return list;
        }

        public List<ClanMessage> GetMessages2()
        {
            List<ClanMessage> list = new List<ClanMessage>();
            BsonElement[] array = messages.ToArray();
            for (int i = 0; i < array.Length; i++)
            {
                BsonElement val = array[i];
                list.Add(new ClanMessage
                {
                    senderId = val.Value.AsBsonDocument.GetValue("senderId").AsString,
                    playersRead = (from bs in val.Value.AsBsonDocument.GetValue("playersRead").AsBsonArray.Values.OfType<BsonString>()
                                   select bs.Value).ToList()
                });
            }
            return list;
        }

		public Axlebolt.Bolt.Protobuf.Clan GetClan()
		{
			// Validate and sanitize clan data before creating proto
			string clanName = name;
			string clanTag = tag;
			
			// If name or tag is null/empty, log error and use defaults
			if (string.IsNullOrWhiteSpace(clanName))
			{
				Console.WriteLine($"[ClanDocument] WARNING: Clan {_id} has empty name! Using 'Unknown Clan'");
				clanName = "Unknown Clan";
			}
			
			if (string.IsNullOrWhiteSpace(clanTag))
			{
				Console.WriteLine($"[ClanDocument] WARNING: Clan {_id} has empty tag! Using 'TAG'");
				clanTag = "TAG";
			}
			
			// Ensure all string fields are not null (Protobuf requirement)
			var clan = new Axlebolt.Bolt.Protobuf.Clan
			{
				Id = _id.ToString(),
				Name = clanName,
				Tag = clanTag,
				AvatarId = avatarId ?? string.Empty,
				ClanType = type,
				CreateDate = Utils.ToUnixTime(creationDate.ToUniversalTime()),
				Description = description ?? string.Empty,
				MebersCount = membersCount > 0 ? membersCount : 1,
				MaxMemberCount = maxMembersCount > 0 ? maxMembersCount : 10
			};
			
			Console.WriteLine($"[ClanDocument] GetClan: Id={clan.Id}, Name='{clan.Name}', Tag='{clan.Tag}', Members={clan.MebersCount}/{clan.MaxMemberCount}, Type={clan.ClanType}");
			return clan;
		}
	}
}
