using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [BsonIgnoreExtraElements]
    public class PlayerMatchDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public List<string> participantIds { get; set; }
        public string matchId { get; set; }
        public string roomId { get; set; }
        public string gameMode { get; set; }
        public long finishDate { get; set; }
        public string winner { get; set; }
        public string loser { get; set; }
        public bool canceled { get; set; }
        public string map { get; set; }
        public byte[] payload { get; set; }
        public string payloadJson { get; set; }

        // Additional fields for proper match history display
        public int trScore { get; set; } = 0;          // Team R score (8 rounds won = 8)
        public int ctScore { get; set; } = 0;          // Team CT score (3 rounds won = 3)
        public int roundsPlayed { get; set; } = 0;     // Total rounds played (11 total)

        // Per-player stats stored for individual match statistics lookup
        public Dictionary<string, PlayerMatchStats> playerStats { get; set; } = new Dictionary<string, PlayerMatchStats>();

        [Serializable]
        public class PlayerMatchStats
        {
            public int kills { get; set; } = 0;
            public int deaths { get; set; } = 0;
            public int assists { get; set; } = 0;
            public int score { get; set; } = 0;
            public int team { get; set; } = 0;           // 1 = T, 2 = CT
            public int status { get; set; } = 0;         // 1 = win, 0 = loss
            public int mmr { get; set; } = 250;
            public int rank { get; set; } = 0;
            public int deltaMmr { get; set; } = 0;
            public int mvp { get; set; } = 0;
        }
    }
}