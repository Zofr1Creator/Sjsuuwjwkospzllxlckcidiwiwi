using MongoDB.Bson;
using System;
using System.Collections.Generic;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public class Verification
    {
        public string Signature { get; set; }
        public bool IsRooted { get; set; }
        public string ApkHash { get; set; }
        public BsonDocument GetBsonElements()
        {
            return new BsonDocument(
                new BsonElement[]
                {
                    new BsonElement("Signature", Signature),
                    new BsonElement("IsRooted", IsRooted),
                    new BsonElement("ApkHash", ApkHash)
                }
                as IEnumerable<BsonElement>);
        }
    }
}
