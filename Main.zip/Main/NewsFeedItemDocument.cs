using MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    public class NewsFeedItemDocument
    {
        public ObjectId _id { get; set; }
        public string definitionId { get; set; }
        public string playerId { get; set; }
        public string itemText { get; set; }
        public long timestamp { get; set; }
    }
}
