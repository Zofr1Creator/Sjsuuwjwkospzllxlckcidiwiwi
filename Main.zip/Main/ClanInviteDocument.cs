using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using global::MongoDB.Bson;
using StandRiseServer.RpcServer;

namespace StandRiseServer.MongoDB.Main
{
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class ClanInviteDocument : DocumentModelBase
    {
        public string clanId { get; set; }

        public string senderId { get; set; }

        public string invitedId { get; set; }

        public BsonDateTime createDate { get; set; }

        public int requestType { get; set; }
        
        // Additional invite fields
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime expireDate { get; set; }
        public BsonDateTime acceptDate { get; set; }
        public BsonDateTime rejectDate { get; set; }
        public int status { get; set; }
        public string statusReason { get; set; }
        public string message { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }
        public string processedBy { get; set; }
        public BsonDateTime processedDate { get; set; }
        public BsonArray history { get; set; }

        public ClanInviteRequest GetInviteRequest()
        {
            return new ClanInviteRequest
            {
                Id = _id.ToString(),
                Clan = BoltMainDatabaseProvider.Instance.GetClan(clanId),
                CreateDate = Utils.ToUnixTime(createDate.ToUniversalTime()),
                CloseDate = Utils.ToUnixTime(DateTime.Now),
                RequestSender = FriendHelper.GetPlayer(senderId),
                InvitedPlayer = FriendHelper.GetPlayer(invitedId),
                RequestType = (RequestType)requestType
            };
        }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument
            {
                { "clanId", clanId },
                { "senderId", senderId },
                { "invitedId", invitedId },
                { "createDate", createDate },
                { "requestType", requestType }
            };
        }
    }
}
