using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace StandRiseServer.MongoDB.Main
{
    /// <summary>
    /// Прогресс игрока по батл-пассу ивента. Коллекция: player_battle_pass
    /// </summary>
    [BsonIgnoreExtraElements]
    public class PlayerBattlePassDocument : DocumentModelBase
    {
        public string playerId { get; set; }

        /// <summary>Код ивента, например DRAGON_RISE</summary>
        public string eventCode { get; set; }

        /// <summary>Очки батл-пасса (опыт)</summary>
        public int points { get; set; }

        /// <summary>Текущий уровень free pass по очкам</summary>
        public int freePassLevel { get; set; }

        /// <summary>Текущий уровень gold pass по очкам (0 если нет gold pass)</summary>
        public int goldPassLevel { get; set; }

        /// <summary>До какого уровня free pass уже выданы награды</summary>
        public int freePassClaimedLevel { get; set; }

        /// <summary>До какого уровня gold pass уже выданы награды</summary>
        public int goldPassClaimedLevel { get; set; }

        public bool claimInitialized { get; set; }

        public long updatedAt { get; set; }
    }
}
