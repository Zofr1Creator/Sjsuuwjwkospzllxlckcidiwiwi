using System;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public class TestAccountDocument : AccountDocumentBase
    {
        private string _token;

        public string token
        {
            get => _token;
            set => _token = value;
        }

    }
}
