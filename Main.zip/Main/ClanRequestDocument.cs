using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using global::MongoDB.Bson;
using StandRiseServer.RpcServer;

namespace StandRiseServer.MongoDB.Main
{
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class ClanRequestDocument : DocumentModelBase
    {
        public string clanId { get; set; }

        public string senderId { get; set; }

        public BsonDateTime createDate { get; set; }

        public int requestType { get; set; }
        
        // Additional request fields
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime expireDate { get; set; }
        public BsonDateTime acceptDate { get; set; }
        public BsonDateTime rejectDate { get; set; }
        public int status { get; set; }
        public string statusReason { get; set; }
        public string message { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }
        public string processedBy { get; set; }
        public BsonDateTime processedDate { get; set; }
        public BsonArray history { get; set; }

        public ClanJoinRequest GetInviteRequest()
        {
            return new ClanJoinRequest
            {
                Id = _id.ToString(),
                Clan = BoltMainDatabaseProvider.Instance.GetClan(clanId),
                CreateDate = Utils.ToUnixTime(createDate.ToUniversalTime()),
                RequestSender = FriendHelper.GetPlayer(senderId),
                RequestType = (RequestType)requestType
            };
        }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument
            {
                { "clanId", clanId },
                { "senderId", senderId },
                { "createDate", createDate },
                { "requestType", requestType }
            };
        }
    }
}
