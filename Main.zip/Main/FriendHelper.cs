using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.RpcServer;
using StandRiseServer.RpcServer.Model;
using StandRiseServer.MongoDB.Game;

namespace StandRiseServer.MongoDB.Main
{
    public static class FriendHelper
    {
        public static RelationshipStatus GetRelationshipStatus(this RelationshipStatusCustom ex, bool isInitiator)
        {
            switch (ex)
            {
                case RelationshipStatusCustom.Request:
                    if (isInitiator)
                    {
                        return RelationshipStatus.RequestRecipient;
                    }
                    return RelationshipStatus.RequestInitiator;
                case RelationshipStatusCustom.None:
                    return RelationshipStatus.None;
                case RelationshipStatusCustom.Blocked:
                    if (isInitiator)
                    {
                        return RelationshipStatus.Blocked;
                    }
                    return RelationshipStatus.None;
                case RelationshipStatusCustom.Friend:
                    return RelationshipStatus.Friend;
                case RelationshipStatusCustom.Ignored:
                    if (isInitiator)
                    {
                        return RelationshipStatus.RequestInitiator;
                    }
                    return RelationshipStatus.Ignored;
                default:
                    throw new ArgumentOutOfRangeException("RelationshipStatusCustom");
            }
        }

        public static RelationshipStatusCustom GetRelationshipStatusCustom(this RelationshipStatus ex)
        {
            return ex switch
            {
                RelationshipStatus.RequestInitiator => RelationshipStatusCustom.Request,
                RelationshipStatus.RequestRecipient => RelationshipStatusCustom.Request,
                RelationshipStatus.None => RelationshipStatusCustom.None,
                RelationshipStatus.Blocked => RelationshipStatusCustom.Blocked,
                RelationshipStatus.Friend => RelationshipStatusCustom.Friend,
                RelationshipStatus.Ignored => RelationshipStatusCustom.Ignored,
                _ => throw new ArgumentOutOfRangeException("RelationshipStatusCustom"),
            };
        }

        public static Player GetPlayer(string playerId)
        {
            PlayerDocument playerDocument = Task.Run(() => BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId))).Result;
            return GetPlayer(playerDocument);
        }

        public static Player GetPlayer(this PlayerDocument playerDocument, bool includeClan = true)
        {
            var player = new Player
            {
                Id = playerDocument._id.ToString(),
                Uid = playerDocument.uid,
                Name = playerDocument.name,
                AvatarId = playerDocument.avatarId,
                TimeInGame = playerDocument.timeInGame,
                RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch,
                PlayerStatus = (StaticClasses.PlayersStatus.ContainsKey(playerDocument._id.ToString()) 
                    ? StandRiseServer.RpcServer.PlayerStatus.GetByDocument(StaticClasses.PlayersStatus[playerDocument._id.ToString()]) 
                    : StandRiseServer.RpcServer.PlayerStatus.GetByDocument(new StandRiseServer.RpcServer.PlayerStatus()))
            };

            // Add clan information only if requested (to avoid blocking DB calls)
            if (includeClan)
            {
                try
                {
                    var clan = BoltMainDatabaseProvider.Instance.GetPlayerClan(playerDocument);
                    if (clan != null)
                    {
                        // Set Clan field for new clients
                        player.Clan = new SimpleClan
                        {
                            Id = clan.Id,
                            Name = clan.Name,
                            Tag = clan.Tag,
                            AvatarId = clan.AvatarId ?? ""
                        };

                        // Also add to Attributes for backward compatibility with old clients
                        if (player.Attributes == null)
                        {
                            player.Attributes = new Attributes();
                        }

                        player.Attributes.Map["CLAN_ID"] = new Axlebolt.Bolt.Protobuf.Attribute { Type = PropertyType.String, String = clan.Id };
                        player.Attributes.Map["CLAN_NAME"] = new Axlebolt.Bolt.Protobuf.Attribute { Type = PropertyType.String, String = clan.Name };
                        player.Attributes.Map["CLAN_TAG"] = new Axlebolt.Bolt.Protobuf.Attribute { Type = PropertyType.String, String = clan.Tag };
                        player.Attributes.Map["CLAN_AVATAR_ID"] = new Axlebolt.Bolt.Protobuf.Attribute { Type = PropertyType.String, String = clan.AvatarId ?? "" };
                    }
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine($"[FriendHelper] GetPlayer(doc): Failed to get clan for player {playerDocument._id}: {ex.Message}");
                }
            }

            return player;
        }

        public static PlayerFriend GetPlayerFriend(this FriendDocument a, string playerId)
        {
            return new PlayerFriend
            {
                Player = ((a.playerInitiatorId == playerId) ? GetPlayer(a.playerId) : GetPlayer(a.playerInitiatorId)),
                RelationshipStatus = a.relationshipStatus.GetRelationshipStatus(a.playerInitiatorId == playerId),
                LastRelationshipUpdate = a.lastTimeUpdate.MillisecondsSinceEpoch
            };
        }

        public static PlayerFriend GetPlayerFriend(this BoltFriend a)
        {
            return new PlayerFriend
            {
                Player = GetPlayer(a.GetPlayerDocument()),
                RelationshipStatus = RelationshipStatus.None,
                LastRelationshipUpdate = 0L
            };
        }

        public static PlayerFriend GetPlayerFriend(this PlayerDocument a)
        {
            return new PlayerFriend
            {
                Player = GetPlayer(a),
                RelationshipStatus = RelationshipStatus.None,
                LastRelationshipUpdate = 0L
            };
        }

        // Fast version without clan lookup - for notifications
        public static PlayerFriend GetPlayerFriendFast(this PlayerDocument a)
        {
            var player = new Player
            {
                Id = a._id.ToString(),
                Uid = a.uid,
                Name = a.name,
                AvatarId = a.avatarId,
                TimeInGame = a.timeInGame,
                RegistrationDate = a.createDate.MillisecondsSinceEpoch,
                PlayerStatus = (StaticClasses.PlayersStatus.ContainsKey(a._id.ToString()) 
                    ? StandRiseServer.RpcServer.PlayerStatus.GetByDocument(StaticClasses.PlayersStatus[a._id.ToString()]) 
                    : StandRiseServer.RpcServer.PlayerStatus.GetByDocument(new StandRiseServer.RpcServer.PlayerStatus()))
            };
            
            return new PlayerFriend
            {
                Player = player,
                RelationshipStatus = RelationshipStatus.None,
                LastRelationshipUpdate = 0L
            };
        }

        public static PlayerFriend GetPlayerFriend(this PlayerDocument a, string playerId)
        {
            List<PlayerFriend> playerFriends = GetPlayerFriends(playerId);
            PlayerFriend playerFriend = playerFriends.FirstOrDefault((PlayerFriend e) => e.Player.Id == a._id.ToString());
            return (playerFriend != null) ? playerFriend : a.GetPlayerFriend();
        }

        public static bool IsContainsFriend(this PlayerDocument a, string playerId)
        {
            List<PlayerFriend> playerFriends = GetPlayerFriends(playerId);
            PlayerFriend playerFriend = playerFriends.FirstOrDefault((PlayerFriend e) => e.Player.Id == a._id.ToString());
            return playerFriend != null && playerFriend.RelationshipStatus == RelationshipStatus.Friend;
        }

        public static List<PlayerFriend> GetPlayerFriends(string playerId)
        {
            Task<List<FriendDocument>> playerFriendsTask = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
            List<FriendDocument> playerFriends = playerFriendsTask.GetAwaiter().GetResult();
            return playerFriends.Select((FriendDocument a) => new PlayerFriend
            {
                Player = ((a.playerInitiatorId == playerId) ? GetPlayer(a.playerId) : GetPlayer(a.playerInitiatorId)),
                RelationshipStatus = a.relationshipStatus.GetRelationshipStatus(a.playerInitiatorId == playerId),
                LastRelationshipUpdate = a.lastTimeUpdate.MillisecondsSinceEpoch
            }).ToList();
        }
    }
}
