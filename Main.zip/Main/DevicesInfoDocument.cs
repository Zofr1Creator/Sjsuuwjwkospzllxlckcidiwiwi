using global::MongoDB.Bson;
using System;
using System.Collections.Generic;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class DevicesInfoDocument : DocumentModelBase
    {
        public string DeviceId { get; set; }
        public string DeviceModel { get; set; }
        public bool isBanned { get; set; }
        
        // Ban-related fields for devices
        public string banCode { get; set; }
        public string banReason { get; set; }
        public BsonDateTime banDate { get; set; }
        public string bannedBy { get; set; }
        public BsonDateTime banExpireDate { get; set; }
        public int banDuration { get; set; }
        public string banType { get; set; }
        public BsonArray banHistory { get; set; }
        
        // Device info fields
        public string platform { get; set; }
        public string osVersion { get; set; }
        public string appVersion { get; set; }
        public BsonDateTime lastUsedDate { get; set; }
        public BsonDateTime firstUsedDate { get; set; }
        public string playerId { get; set; }
        public BsonArray playerIds { get; set; }
        public BsonDocument metadata { get; set; }
        
        public BsonDocument GetBsonElements()
        {
            return new BsonDocument(
                new BsonElement[]
                {
                    new BsonElement("DeviceId", DeviceId),
                    new BsonElement("DeviceModel", DeviceModel)
                }
                as IEnumerable<BsonElement>);
        }
    }
}
