using System.Collections.Generic;
using global::MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    [global::MongoDB.Bson.Serialization.Attributes.BsonIgnoreExtraElements]
    public class ClanLogDocument : DocumentModelBase
    {
        public string playerId { get; set; }

        public BsonDateTime timestamp { get; set; }

        public string clanTag { get; set; }

        public int clanLogType { get; set; }

        public int changedClanType { get; set; }

        public string changedClanName { get; set; }

        public string changedClanTag { get; set; }

        public string primaryMember { get; set; }

        public string secondaryMember { get; set; }

        public int changedMaxMemberCount { get; set; }

        public int assignedRole { get; set; }

        public List<string> playersRead { get; set; } = new List<string>();
        
        // Additional log fields
        public BsonDateTime createDate { get; set; }
        public string clanId { get; set; }
        public string clanName { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument details { get; set; }
        public string actionBy { get; set; }
        public string actionType { get; set; }
        public BsonDocument oldValues { get; set; }
        public BsonDocument newValues { get; set; }
        public string description { get; set; }
        public int severity { get; set; }
        public BsonArray tags { get; set; }
        public string category { get; set; }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument
            {
                { "playerId", playerId },
                { "timestamp", timestamp },
                { "clanTag", clanTag },
                { "clanLogType", clanLogType },
                { "changedClanType", changedClanType },
                { "changedClanName", changedClanName },
                { "changedClanTag", changedClanTag },
                { "primaryMember", primaryMember },
                { "secondaryMember", secondaryMember },
                { "changedMaxMemberCount", changedMaxMemberCount },
                { "assignedRole", assignedRole }
            };
        }
    }
}
