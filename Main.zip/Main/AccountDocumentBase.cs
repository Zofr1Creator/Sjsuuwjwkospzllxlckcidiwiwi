using System;
using MongoDB.Bson;

namespace StandRiseServer.MongoDB.Main
{
    [Serializable]
    public abstract class AccountDocumentBase : DocumentModelBase
    {
        private string _playerId;
        private int _gid;

        public string playerId
        {
            get => _playerId;
            set => _playerId = value;
        }

        public int gid
        {
            get => _gid;
            set => _gid = value;
        }
        
        // Ban and moderation fields
        public bool isBanned { get; set; }
        public string banCode { get; set; }
        public string banReason { get; set; }
        public BsonDateTime banDate { get; set; }
        public string bannedBy { get; set; }
        public BsonDateTime banExpireDate { get; set; }
        public int banDuration { get; set; }
        public string banType { get; set; }
        public BsonArray banHistory { get; set; }
        
        // Account metadata
        public BsonDateTime createDate { get; set; }
        public BsonDateTime updateDate { get; set; }
        public BsonDateTime lastLoginDate { get; set; }
        public string lastIp { get; set; }
        public BsonDocument metadata { get; set; }
        public BsonDocument settings { get; set; }

    }
}
