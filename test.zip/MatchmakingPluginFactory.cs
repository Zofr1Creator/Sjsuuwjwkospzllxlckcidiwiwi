using System;
using System.Collections.Generic;
using Photon.Hive.Plugin;

namespace Axlebolt.Standoff.PhotonPlugin
{
    public class MatchmakingPluginFactory : IPluginFactory
    {
        public IGamePlugin Create(IPluginHost gameHost, string pluginName, Dictionary<string, string> config, out string errorMsg)
        {
            errorMsg = "";
            try
            {
                gameHost.LogInfo($"MatchmakingPluginFactory: Creating plugin '{pluginName}'");
                var plugin = new MatchmakingPlugin();
                // Отдаём клиенту то имя плагина, которое он сам запросил (например
                // "UnevenTeamsGamePlugin"), чтобы Photon не считал это "plugin mismatch"
                // и пускал клиентов независимо от того, как называется плагин у них в настройках.
                plugin.SetRequestedName(pluginName);

                if (plugin.SetupInstance(gameHost, config, out errorMsg))
                {
                    gameHost.LogInfo("MatchmakingPluginFactory: Plugin created and initialized successfully.");
                    return plugin;
                }
                else
                {
                    gameHost.LogError($"MatchmakingPluginFactory: SetupInstance failed: {errorMsg}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                errorMsg = ex.ToString();
                gameHost.LogError($"MatchmakingPluginFactory: Failed to create plugin: {errorMsg}");
                return null;
            }
        }
    }
}
