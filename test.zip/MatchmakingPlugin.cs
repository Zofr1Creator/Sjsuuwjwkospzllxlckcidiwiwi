using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using Photon.Hive.Plugin;

namespace Axlebolt.Standoff.PhotonPlugin
{
    public class MatchmakingPlugin : PluginBase
    {
        // Раньше тут была фиксированная строка "MatchmakingPlugin". Клиент игры при
        // создании комнаты запрашивает плагин по имени (например "UnevenTeamsGamePlugin"),
        // и Photon сверяет запрошенное имя с тем, что вернёт Name — если не совпадает,
        // клиент получает ошибку "plugin mismatch". Наш плагин физически один и тот же
        // для любого имени, поэтому просто отражаем то имя, которое реально запросил клиент
        // (см. MatchmakingPluginFactory.Create) — так подключаются клиенты с любым названием плагина.
        private string _requestedName = "MatchmakingPlugin";
        public override string Name => _requestedName;
        // Имя плагина, которое реально запросил клиент при создании/входе в комнату
        // (см. MatchmakingPluginFactory.Create). По нему же определяем режим SoulHunt —
        // это то, что реально прислал клиент, а не догадка по имени комнаты.
        public string RequestedPluginName => _requestedName;

        internal void SetRequestedName(string requestedName)
        {
            if (!string.IsNullOrWhiteSpace(requestedName))
            {
                _requestedName = requestedName;
            }
        }

        private const byte EVT_CHANGE_TEAM_REQUEST = 21;
        private const byte EVT_CHANGE_TEAM_RESPONSE = 20;
        private const byte EVT_REBALANCE = 22;

        private const byte TEAM_TERRORISTS = 1;
        private const byte TEAM_CT = 2;
        private const byte TEAM_SPECTATOR = 3;
        private const byte TEAM_NONE = 0;

        private const int ERROR_NONE = 0;
        private const int ERROR_TEAM_FULL = 1;
        private const int ERROR_ALREADY_IN_TEAM = 2;

        private const byte EVT_GAME_EVENT = 128; 
        private const string PROP_CHALLENGES = "challenges"; 

        private const byte DATA_KEY = 245;

        // Точечная диагностика неизвестных Photon-эвентов (см. ниже в OnRaiseEvent). Логируем
        // КОД ВПЕРВЫЕ увиденного события не чаще раза в секунду на код — в отличие от прошлой
        // попытки логировать вообще всё (уронило сервер из-за EvCode=201, синхронизации позиций
        // по несколько раз в секунду на актёра). 201, 51, 21, 128 — уже известные коды, их не трогаем.
        private static readonly HashSet<byte> _knownEvCodes = new HashSet<byte> { 201, 51, EVT_CHANGE_TEAM_REQUEST, EVT_CHANGE_TEAM_RESPONSE, EVT_REBALANCE, EVT_GAME_EVENT };
        private static readonly Dictionary<byte, DateTime> _lastUnknownEvLogTime = new Dictionary<byte, DateTime>();
        private static readonly object _unknownEvLogLock = new object();

        public override bool SetupInstance(IPluginHost host, Dictionary<string, string> config, out string errorMsg)
        {
            host.LogInfo("MatchmakingPlugin: SetupInstance called. Initializing team selection plugin.");
            return base.SetupInstance(host, config, out errorMsg);
        }

        public override void OnCreateGame(ICreateGameCallInfo info)
        {
            this.PluginHost.LogInfo($"MatchmakingPlugin: OnCreateGame - Room: {this.PluginHost.GameId}");

            bool isSoulHuntGame = IsSoulHunt();
            bool isSantaClausGame = IsSantaClaus();

            if (isSoulHuntGame || isSantaClausGame)
            {
                // Пробуем поставить команду прямо в реквесте ДО Continue() (в теории должно
                // уйти атомарно вместе с созданием комнаты) — но это не проверено вживую и,
                // судя по всему, само по себе не сработало. Оставляю как попытку "на всякий",
                // ошибку глушим, ниже всё равно есть рабочий путь через GameActors.
                try
                {
                    if (info.Request.ActorProperties == null)
                    {
                        info.Request.ActorProperties = new Hashtable();
                    }
                    info.Request.ActorProperties["team"] = TEAM_CT;
                }
                catch (Exception ex)
                {
                    this.PluginHost.LogError($"MatchmakingPlugin: Error pre-setting SoulHunt creator team via ActorProperties: {ex}");
                }
            }

            info.Continue();

            if (isSoulHuntGame)
            {
                // Создатель комнаты — это ПЕРВЫЙ актёр, и Photon НЕ вызывает для него
                // BeforeJoin/OnJoin (эти хуки только для тех, кто заходит в УЖЕ существующую
                // комнату). Это рабочий путь, который реально спавнил хоста: сразу пробуем
                // найти актёра в GameActors, а если его там ещё нет (гонка) — повторяем
                // коротким таймером.
                var creator = this.PluginHost.GameActors.FirstOrDefault();
                if (creator != null)
                {
                    AssignSoulHuntTeam(creator.ActorNr);
                    StartSoulHuntMatchIfReady();
                }
                else
                {
                    this.PluginHost.CreateOneTimeTimer(() => {
                        try
                        {
                            var retryCreator = this.PluginHost.GameActors.FirstOrDefault();
                            if (retryCreator != null)
                            {
                                AssignSoulHuntTeam(retryCreator.ActorNr);
                            }
                            else
                            {
                                this.PluginHost.LogError("MatchmakingPlugin: SoulHunt - creator actor still not found after retry delay");
                            }
                            StartSoulHuntMatchIfReady();
                        }
                        catch (Exception ex)
                        {
                            this.PluginHost.LogError($"MatchmakingPlugin: Error assigning SoulHunt creator team (retry): {ex}");
                        }
                    }, 200);
                }
            }
            if (isSantaClausGame)
            {
                var creator = this.PluginHost.GameActors.FirstOrDefault();
                if (creator != null)
                {
                    AssignSantaClausTeam(creator.ActorNr);
                    StartSantaClausMatchIfReady();
                }
                else
                {
                    this.PluginHost.CreateOneTimeTimer(() => {
                        try
                        {
                            var retryCreator = this.PluginHost.GameActors.FirstOrDefault();
                            if (retryCreator != null)
                            {
                                AssignSantaClausTeam(retryCreator.ActorNr);
                            }
                            else
                            {
                                this.PluginHost.LogError("MatchmakingPlugin: SantaClaus - creator actor still not found after retry delay");
                            }
                            StartSantaClausMatchIfReady();
                        }
                        catch (Exception ex)
                        {
                            this.PluginHost.LogError($"MatchmakingPlugin: Error assigning SantaClaus creator team (retry): {ex}");
                        }
                    }, 200);
                }
            }

            // Removed 30s timer that blasted the HTTP API for every actor, causing lag and timeout issues.
        }

        public override void BeforeJoin(IBeforeJoinGameCallInfo info)
        {
            this.PluginHost.LogInfo($"MatchmakingPlugin: BeforeJoin - PlayerId: {info.UserId}");
            info.Continue();
        }

        private void FetchChallengesAndSetProperties(string playerId, int actorNr = 0)
        {
            try
            {
                // Было жёстко зашито на чей-то старый чужой IP (31.76.29.22) — HTTP API там не
                // отвечал, запрос тихо фейлился, "challenges" никогда не попадал в свойства
                // актёра, и задания в катке не показывались вообще. Реальный IP HTTP API сервера:
                // 157.228.136.148. ВАЖНО: Photon и HTTP API — на РАЗНЫХ машинах, поэтому 157.228.136.148
                // тут в принципе не мог работать (это был мой косяк, я решил что это hairpin NAT
                // на одной машине). ~21-секундный таймаут коннекта на 157.228.136.148:2224 — это
                // типичный тайминг Windows TCP при заблокированном/зафильтрованном порте (SYN
                // просто дропается файрволом, и коннект висит ~21с прежде чем зафейлиться).
                // Нужно открыть порт 2224 на сервере 157.228.136.148 для входящих с IP Photon-сервера,
                // иначе эта задержка вернётся даже с правильным IP.
                string url = $"http://157.228.136.148:2224/api/gameevent/challenges?PlayerId={playerId}";
                
                var request = new HttpRequest
                {
                    Url = url,
                    Method = "GET",
                    Accept = "application/json",
                    Callback = (response, userState) => {
                        if (response.Status == HttpRequestQueueResult.Success && response.HttpCode == 200)
                        {
                            Hashtable props = new Hashtable();
                            props[PROP_CHALLENGES] = response.ResponseText;
                            
                            int targetActor = actorNr;
                            if (targetActor == 0)
                            {
                                var actor = this.PluginHost.GameActors.FirstOrDefault(a => a.UserId == playerId);
                                if (actor != null) targetActor = actor.ActorNr;
                            }

                            // Актёр мог успеть выйти из комнаты, пока летел HTTP-запрос (OnLeave раньше
                            // callback'а) — раньше это валило SetProperties с "Actor with number N not
                            // found" и спамило лог ошибками. Проверяем, что актёр всё ещё в комнате.
                            if (targetActor != 0 && this.PluginHost.GameActors.Any(a => a.ActorNr == targetActor))
                            {
                                this.PluginHost.SetProperties(targetActor, props, null, true);
                                this.PluginHost.LogInfo($"MatchmakingPlugin: Synced challenges for Actor {targetActor}");
                            }
                        }
                    }
                };
                this.PluginHost.HttpRequest(request);
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in FetchChallengesAndSetProperties: {ex.Message}");
            }
        }

        public override void OnJoin(IJoinGameCallInfo info)
        {
            this.PluginHost.LogInfo($"MatchmakingPlugin: OnJoin - Actor: {info.ActorNr} PlayerId: {info.UserId}");
            FetchChallengesAndSetProperties(info.UserId, info.ActorNr);

            if (IsSoulHunt())
            {
                // Важно: ставим team ДО info.Continue(). Continue() — это то, что реально
                // отправляет клиенту ответ на JoinGame. Если выставлять team ПОСЛЕ Continue()
                // (как было раньше), клиент получает актёра ещё без свойства "team" и пытается
                // заспавниться "в никуда" -> зависает на "Ожидание игроков"/SERVER ERROR.
                // Выставляя team до Continue(), свойство уходит сразу в самом ответе на джойн.
                AssignSoulHuntTeam(info.ActorNr);
                info.Continue();
                StartSoulHuntMatchIfReady();
                return;
            }

            if (IsSantaClaus())
            {
                AssignSantaClausTeam(info.ActorNr);
                info.Continue();
                StartSantaClausMatchIfReady();
                return;
            }

            info.Continue();

            if (this.PluginHost.GameActors.Count == 1)
            {
                this.PluginHost.LogInfo("MatchmakingPlugin: First player joined. Starting 10s auto-start timer.");
                this.PluginHost.CreateOneTimeTimer(() => {
                    try {
                        if (this.PluginHost.GameActors.Count > 0)
                        {
                            this.PluginHost.LogInfo("MatchmakingPlugin: 10s timeout reached. Force starting match.");
                            Hashtable props = new Hashtable();
                            props["MatchStarted"] = true;
                            props["S1"] = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                            this.PluginHost.SetProperties(0, props, null, true);
                        }
                    } catch (Exception ex) {
                        this.PluginHost.LogError("MatchmakingPlugin: Error in auto-start timer: " + ex.Message);
                    }
                }, 10000);
            }

            try
            {
                var actor = this.PluginHost.GameActors.FirstOrDefault(a => a.ActorNr == info.ActorNr);
                if (actor != null)
                {
                    object existingTeam;
                    if (!actor.Properties.TryGetValue("team", out existingTeam) || existingTeam == null)
                    {
                        Hashtable props = new Hashtable();
                        props["team"] = TEAM_NONE;
                        
                        // We must send properties update so client knows they have TEAM_NONE
                        this.PluginHost.SetProperties(info.ActorNr, props, null, true);
                    }
                }
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error setting default team: {ex}");
            }
        }

        // Определяем SoulHunt по имени плагина, которое реально запросил клиент
        // (UnevenTeamsGamePlugin) — это то, что клиент реально прислал, а не догадка
        // по GameProperties["C0"] (не сработало). GameId-префикс — доп. подстраховка.
        // Определяем текущий режим по префиксу имени комнаты (см. MatchmakingManager.CreateMatch:
        // roomId = $"{photonMode}_{matchId}", photonMode один из DeathMatch/Defuse/ArmsRace/
        // Escalation/RankedDefuse/Ranked2v2/Training/SniperDuel/Arcade). Нужно для квестов,
        // завязанных на конкретный режим (например "25 килов в Гонке вооружений").
        private string GetCurrentModeName()
        {
            if (IsSoulHunt()) return "SoulHunt";
            if (IsSantaClaus()) return "SantaClaus";

            string gameId = this.PluginHost.GameId ?? string.Empty;
            string[] knownModes = { "DeathMatch", "RankedDefuse", "Defuse", "ArmsRace", "Escalation", "Ranked2v2", "Training", "SniperDuel", "Arcade" };
            foreach (var mode in knownModes)
            {
                if (gameId.StartsWith(mode, StringComparison.OrdinalIgnoreCase))
                    return mode;
            }
            return "Unknown";
        }

        private bool IsSoulHunt()
        {
            return string.Equals(RequestedPluginName, "UnevenTeamsGamePlugin", StringComparison.OrdinalIgnoreCase)
                || (!string.IsNullOrEmpty(this.PluginHost.GameId)
                    && this.PluginHost.GameId.StartsWith("SoulHunt", StringComparison.OrdinalIgnoreCase));
        }

        private bool IsSantaClaus()
        {
            return string.Equals(RequestedPluginName, "SantaClausGamePlugin", StringComparison.OrdinalIgnoreCase)
                || (!string.IsNullOrEmpty(this.PluginHost.GameId)
                    && this.PluginHost.GameId.StartsWith("SantaClaus", StringComparison.OrdinalIgnoreCase));
        }

        // Режим SoulHunt (1v1): каждый заходящий сразу спавнится за спецназ (CT).
        // Как только заходит второй игрок — один из двоих случайно назначается террористом,
        // и матч стартует сразу, без обычного 10-секундного таймера ожидания.
        private void AssignSoulHuntTeam(int actorNr)
        {
            try
            {
                var actor = this.PluginHost.GameActors.FirstOrDefault(a => a.ActorNr == actorNr);
                if (actor != null)
                {
                    Hashtable props = new Hashtable();
                    props["team"] = TEAM_CT;
                    this.PluginHost.SetProperties(actorNr, props, null, true);
                    this.PluginHost.LogInfo($"MatchmakingPlugin: SoulHunt - Actor {actorNr} auto-assigned to CT (spawn)");
                }
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in AssignSoulHuntTeam: {ex}");
            }
        }

        private void StartSoulHuntMatchIfReady()
        {
            try
            {
                if (this.PluginHost.GameActors.Count == 2)
                {
                    // Хост (создатель комнаты) всегда должен оставаться за КТ — раньше рандом
                    // мог выбрать в террористы именно его, и, судя по всему, именно в этом
                    // случае что-то ломалось у хоста. Поэтому больше не рандомим между обоими:
                    // террористом всегда становится именно ВТОРОЙ зашедший (не хост), у него
                    // самый большой ActorNr, так как он присоединился позже создателя комнаты.
                    var actors = this.PluginHost.GameActors.ToList();
                    var terrorist = actors.OrderByDescending(a => a.ActorNr).First();

                    Hashtable terroristProps = new Hashtable();
                    terroristProps["team"] = TEAM_TERRORISTS;
                    this.PluginHost.SetProperties(terrorist.ActorNr, terroristProps, null, true);
                    this.PluginHost.LogInfo($"MatchmakingPlugin: SoulHunt - Actor {terrorist.ActorNr} (non-host) assigned to Terrorists");

                    Hashtable matchProps = new Hashtable();
                    matchProps["MatchStarted"] = true;
                    matchProps["S1"] = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                    this.PluginHost.SetProperties(0, matchProps, null, true);
                    this.PluginHost.LogInfo("MatchmakingPlugin: SoulHunt - 2 players joined, match started.");
                }
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in StartSoulHuntMatchIfReady: {ex}");
            }
        }

        private void AssignSantaClausTeam(int actorNr)
        {
            try
            {
                var actor = this.PluginHost.GameActors.FirstOrDefault(a => a.ActorNr == actorNr);
                if (actor != null)
                {
                    Hashtable props = new Hashtable();
                    props["team"] = TEAM_CT;
                    this.PluginHost.SetProperties(actorNr, props, null, true);
                    this.PluginHost.LogInfo($"MatchmakingPlugin: SantaClaus - Actor {actorNr} auto-assigned to CT (spawn)");
                }
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in AssignSantaClausTeam: {ex}");
            }
        }

        private void StartSantaClausMatchIfReady()
        {
            try
            {
                if (this.PluginHost.GameActors.Count == 2)
                {
                    var actors = this.PluginHost.GameActors.ToList();
                    
                    // Для Санты делаем настоящий рандом
                    var random = new Random();
                    var terrorist = actors[random.Next(actors.Count)];
                    var ct = actors.First(a => a.ActorNr != terrorist.ActorNr);

                    Hashtable terroristProps = new Hashtable();
                    terroristProps["team"] = TEAM_TERRORISTS;
                    this.PluginHost.SetProperties(terrorist.ActorNr, terroristProps, null, true);
                    
                    Hashtable ctProps = new Hashtable();
                    ctProps["team"] = TEAM_CT;
                    this.PluginHost.SetProperties(ct.ActorNr, ctProps, null, true);
                    
                    this.PluginHost.LogInfo($"MatchmakingPlugin: SantaClaus - Actor {terrorist.ActorNr} assigned to T, Actor {ct.ActorNr} assigned to CT");

                    Hashtable matchProps = new Hashtable();
                    matchProps["MatchStarted"] = true;
                    matchProps["S1"] = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
                    this.PluginHost.SetProperties(0, matchProps, null, true);
                    this.PluginHost.LogInfo("MatchmakingPlugin: SantaClaus - 2 players joined, match started.");
                }
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in StartSantaClausMatchIfReady: {ex}");
            }
        }

        public override void OnLeave(ILeaveGameCallInfo info)
        {
            this.PluginHost.LogInfo($"MatchmakingPlugin: OnLeave - Actor: {info.ActorNr} PlayerId: {info.UserId}");
            info.Continue();
        }

        public override void OnRaiseEvent(IRaiseEventCallInfo info)
        {
            // Безопасная версия прошлой диагностики: логируем только НЕизвестные коды событий,
            // не чаще раза в секунду на конкретный код — чтобы не повторить инцидент с EvCode=201.
            byte evCode = info.Request.EvCode;
            if (!_knownEvCodes.Contains(evCode))
            {
                bool shouldLog = false;
                lock (_unknownEvLogLock)
                {
                    if (!_lastUnknownEvLogTime.TryGetValue(evCode, out var lastTime) || (DateTime.UtcNow - lastTime).TotalSeconds >= 1)
                    {
                        _lastUnknownEvLogTime[evCode] = DateTime.UtcNow;
                        shouldLog = true;
                    }
                }

                if (shouldLog)
                {
                    try
                    {
                        var evData = info.Request.Data as IDictionary;
                        string evDump = evData != null
                            ? string.Join(", ", evData.Keys.Cast<object>().Select(k => $"{k}={evData[k]}"))
                            : "(no data / not IDictionary)";
                        this.PluginHost.LogInfo($"MatchmakingPlugin: Unknown OnRaiseEvent EvCode={evCode} Actor={info.ActorNr} Data=[{evDump}]");
                    }
                    catch (Exception ex)
                    {
                        this.PluginHost.LogWarning($"MatchmakingPlugin: Unknown-event diagnostic dump failed: {ex.Message}");
                    }
                }
            }

            if (info.Request.EvCode == EVT_CHANGE_TEAM_REQUEST)
            {
                HandleChangeTeamRequest(info);
                return;
            }
            else if (info.Request.EvCode == EVT_GAME_EVENT)
            {
                HandleMissionEvent(info);
            }

            info.Continue();
        }

        private void HandleMissionEvent(IRaiseEventCallInfo info)
        {
            try
            {
                var data = info.Request.Data as IDictionary;
                if (data == null) return;

                // Диагностика: пока не знаем код для "поставить бомбу" и не знаем, шлёт ли клиент
                // айди/имя оружия в этом же событии — логируем ВСЕ ключи, чтобы поймать их на
                // следующем тесте (killfeed / плант бомбы), не гадая вслепую.
                var keysDump = string.Join(", ", data.Keys.Cast<object>().Select(k => $"{k}={data[k]}"));
                this.PluginHost.LogInfo($"MatchmakingPlugin: HandleMissionEvent raw data: [{keysDump}]");

                // ОТКЛЮЧЕНО: код 1 в этом кастомном Photon-эвенте, судя по всему, шлётся на КАЖДЫЙ
                // хит, а не только на добивающий (killing blow) — отсюда баг "4 попадания = 4 килла
                // в квестах". Плюс выяснилось (когда weapon-specific квесты заработали сами, без
                // единой правки тут), что реальный подсчёт прогресса миссий идёт КЛИЕНТСКИ
                // (Axlebolt.Standoff.Missions.HitMissionTrigger / GameMission.CurrentPoints), а не
                // через этот Photon-эвент. Наш SendChallengeProgress тут был лишним и вредным
                // дублирующим путём на основе неверной догадки о смысле actionCode. Оставляю только
                // диагностический дамп (сверху) на случай, если понадобится для чего-то другого
                // (например для плант-бомбы/win-match, где клиентского трекинга может не быть).
                /*
                if (data.Contains((byte)0))
                {
                    int actionCode = Convert.ToInt32(data[(byte)0]);
                    string actionStr = actionCode == 1 ? "get_kills" : (actionCode == 2 ? "get_headshots" : "action_" + actionCode);
                    string mode = GetCurrentModeName();

                    var attacker = this.PluginHost.GameActors.FirstOrDefault(a => a.ActorNr == info.ActorNr);
                    if (attacker != null && !string.IsNullOrEmpty(attacker.UserId))
                    {
                        this.PluginHost.LogInfo($"MatchmakingPlugin: Player {attacker.UserId} did action {actionCode} ({actionStr}) in mode {mode}! Updating challenge progress.");
                        if (mode != "Unknown")
                        {
                            SendChallengeProgress(attacker.UserId, $"{actionStr}_{mode}", 1);
                        }
                        else
                        {
                            SendChallengeProgress(attacker.UserId, actionStr, 1);
                        }
                    }
                }
                */
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in HandleMissionEvent: {ex.Message}");
            }
        }

        private void SendChallengeProgress(string playerId, string challengeId, int points)
        {
            try
            {
                string url = "http://157.228.136.148:2224/api/gameevent/progress";
                
                string json = "{\"PlayerId\":\"" + playerId + "\", \"ChallengeId\":\"" + challengeId + "\", \"Points\":" + points + "}";
                
                var request = new HttpRequest
                {
                    Url = url,
                    Method = "POST",
                    Accept = "application/json",
                    ContentType = "application/json",
                    DataStream = new MemoryStream(Encoding.UTF8.GetBytes(json)),
                    Callback = (response, userState) => {
                        if (response.Status != HttpRequestQueueResult.Success || response.HttpCode != 200)
                        {
                            this.PluginHost.LogWarning($"MatchmakingPlugin: Failed to sync challenge progress for {playerId}. Status: {response.Status}, HttpCode: {response.HttpCode}");
                        }
                    }
                };

                this.PluginHost.HttpRequest(request);
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in SendChallengeProgress: {ex.Message}");
            }
        }

        private void HandleChangeTeamRequest(IRaiseEventCallInfo info)
        {
            try
            {
                this.PluginHost.LogDebug($"MatchmakingPlugin: Team change request from Actor {info.ActorNr}");

                var eventData = info.Request.Data as IDictionary;
                if (eventData == null || !eventData.Contains((byte)0))
                {
                    this.PluginHost.LogError("MatchmakingPlugin: Invalid team change request - no data or missing key 0");
                    info.Cancel();
                    return;
                }

                byte requestedTeam = Convert.ToByte(eventData[(byte)0]);
                this.PluginHost.LogInfo($"MatchmakingPlugin: Actor {info.ActorNr} requests team {requestedTeam}");

                if (requestedTeam != TEAM_TERRORISTS && requestedTeam != TEAM_CT && requestedTeam != TEAM_SPECTATOR)
                {
                    this.PluginHost.LogError($"MatchmakingPlugin: Invalid team value: {requestedTeam}");
                    info.Cancel();
                    return;
                }

                var actor = this.PluginHost.GameActors.FirstOrDefault(a => a.ActorNr == info.ActorNr);
                if (actor == null)
                {
                    this.PluginHost.LogError($"MatchmakingPlugin: Actor {info.ActorNr} not found");
                    info.Cancel();
                    return;
                }

                byte currentTeam = TEAM_NONE;
                object currentTeamObj;
                if (actor.Properties.TryGetValue("team", out currentTeamObj) && currentTeamObj != null)
                {
                    currentTeam = Convert.ToByte(currentTeamObj);
                }

                if (currentTeam == requestedTeam)
                {
                    this.PluginHost.LogInfo($"MatchmakingPlugin: Actor {info.ActorNr} already in team {requestedTeam}");
                    SendChangeTeamResponse(info.ActorNr, false, currentTeam, requestedTeam, ERROR_ALREADY_IN_TEAM);
                    info.Cancel();
                    return;
                }

                if (requestedTeam != TEAM_SPECTATOR)
                {
                    int maxTeamSize = GetMaxTeamSize();
                    int requestedTeamCount = CountPlayersInTeam(requestedTeam);

                    if (requestedTeamCount >= maxTeamSize)
                    {
                        this.PluginHost.LogInfo($"MatchmakingPlugin: Team {requestedTeam} is full ({requestedTeamCount}/{maxTeamSize})");
                        SendChangeTeamResponse(info.ActorNr, false, currentTeam, requestedTeam, ERROR_TEAM_FULL);
                        info.Cancel();
                        return;
                    }

                    string mode = this.PluginHost.GameProperties != null && this.PluginHost.GameProperties.ContainsKey("C0") ? this.PluginHost.GameProperties["C0"] as string : "";

                    // Проверка баланса: не дает зайти в команду, если там уже БОЛЬШЕ игроков, чем в противоположной
                    if (mode != "Yokai" && (requestedTeam == TEAM_TERRORISTS || requestedTeam == TEAM_CT))
                    {
                        byte otherTeam = (requestedTeam == TEAM_TERRORISTS) ? TEAM_CT : TEAM_TERRORISTS;
                        int otherTeamCount = CountPlayersInTeam(otherTeam);

                        // Если в желаемой команде уже БОЛЬШЕ человек, чем в противоположной — не пускаем
                        if (requestedTeamCount > otherTeamCount)
                        {
                            this.PluginHost.LogInfo($"MatchmakingPlugin: Balance blocked join for Actor {info.ActorNr} to Team {requestedTeam}. T:{CountPlayersInTeam(TEAM_TERRORISTS)} CT:{CountPlayersInTeam(TEAM_CT)}");
                            SendChangeTeamResponse(info.ActorNr, false, currentTeam, requestedTeam, ERROR_TEAM_FULL);
                            info.Cancel();
                            return;
                        }
                    }
                }

                Hashtable properties = new Hashtable();
                properties["team"] = requestedTeam;
                this.PluginHost.SetProperties(info.ActorNr, properties, null, true);

                this.PluginHost.LogInfo($"MatchmakingPlugin: Actor {info.ActorNr} changed team from {currentTeam} to {requestedTeam}");

                SendChangeTeamResponse(info.ActorNr, true, currentTeam, requestedTeam, ERROR_NONE);

                info.Continue();
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error handling team change: {ex}");
                info.Cancel();
            }
        }

        private void SendChangeTeamResponse(int actorNr, bool approved, byte oldTeam, byte newTeam, int errorCode)
        {
            object[] responseData = new object[] { approved, oldTeam, newTeam, errorCode };
            var data = new Dictionary<byte, object> { { DATA_KEY, responseData } };

            this.PluginHost.BroadcastEvent(
                recieverActors: new List<int> { actorNr },
                senderActor: 0,
                evCode: EVT_CHANGE_TEAM_RESPONSE,
                data: data,
                cacheOp: 0,
                sendParameters: default(SendParameters)
            );
        }

        private int GetMaxTeamSize()
        {
            if (this.PluginHost.GameProperties != null && this.PluginHost.GameProperties.ContainsKey("C0"))
            {
                string gameMode = this.PluginHost.GameProperties["C0"] as string;
                if (gameMode == "Ranked2v2")
                {
                    return 2;
                }
                if (gameMode == "Yokai")
                {
                    return this.PluginHost.GameActors.Count > 10 ? this.PluginHost.GameActors.Count : 10;
                }
            }

            if (this.PluginHost.GameProperties != null && this.PluginHost.GameProperties.ContainsKey("max_team_size"))
            {
                try
                {
                    return Convert.ToInt32(this.PluginHost.GameProperties["max_team_size"]);
                }
                catch { }
            }
            return 5; 
        }

        private int CountPlayersInTeam(byte team)
        {
            int count = 0;
            foreach (var actor in this.PluginHost.GameActors)
            {
                object teamObj;
                if (actor.Properties.TryGetValue("team", out teamObj) && teamObj != null)
                {
                    try
                    {
                        if (Convert.ToByte(teamObj) == team)
                            count++;
                    }
                    catch { }
                }
            }
            return count;
        }

        public override void OnSetProperties(ISetPropertiesCallInfo info)
        {
            info.Continue();
        }

        public override void OnCloseGame(ICloseGameCallInfo info)
        {
            this.PluginHost.LogInfo($"MatchmakingPlugin: OnCloseGame - Room: {this.PluginHost.GameId}");

            // Раньше post-match дроп (RECIPE_DROP_IN_GAME / RECIPE_GOOD_GAME_* и т.д.) выдавался
            // сервером просто по кулдауну на клиентский вызов exchangeInventoryItems - клиент мог
            // сам спамить этот RPC сколько угодно (дюп). Теперь при РЕАЛЬНОМ закрытии матча (это
            // серверное, не подделываемое клиентом Photon-событие) сообщаем основному серверу,
            // кто реально доиграл матч - и только это даёт "кредит" на пост-матч дроп.
            SendMatchFinished();

            info.Continue();
        }

        private void SendMatchFinished()
        {
            try
            {
                var playerIds = this.PluginHost.GameActors
                    .Where(a => !string.IsNullOrEmpty(a.UserId))
                    .Select(a => a.UserId)
                    .Distinct()
                    .ToList();

                if (playerIds.Count == 0)
                {
                    return;
                }

                string url = "http://157.228.136.148:2224/api/match/finished";
                string matchId = this.PluginHost.GameId + "_" + DateTime.UtcNow.Ticks;
                string playerIdsJson = string.Join(",", playerIds.Select(id => "\"" + id + "\""));
                string json = "{\"MatchId\":\"" + matchId + "\", \"PlayerIds\":[" + playerIdsJson + "]}";

                var request = new HttpRequest
                {
                    Url = url,
                    Method = "POST",
                    Accept = "application/json",
                    ContentType = "application/json",
                    DataStream = new MemoryStream(Encoding.UTF8.GetBytes(json)),
                    Callback = (response, userState) => {
                        if (response.Status != HttpRequestQueueResult.Success || response.HttpCode != 200)
                        {
                            this.PluginHost.LogWarning($"MatchmakingPlugin: Failed to report match finished. Status: {response.Status}, HttpCode: {response.HttpCode}");
                        }
                    }
                };

                this.PluginHost.HttpRequest(request);
            }
            catch (Exception ex)
            {
                this.PluginHost.LogError($"MatchmakingPlugin: Error in SendMatchFinished: {ex.Message}");
            }
        }
    }
}