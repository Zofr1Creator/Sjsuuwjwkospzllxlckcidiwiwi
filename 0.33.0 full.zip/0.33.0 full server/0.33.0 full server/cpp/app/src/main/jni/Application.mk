APP_ABI := arm64-v8a
APP_PLATFORM := android-24
APP_STL := none
APP_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti
APP_OPTIM := release
