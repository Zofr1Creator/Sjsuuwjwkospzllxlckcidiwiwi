#pragma once
#include <cstdint>

namespace so2::rva033
{
    // il2cpp
    inline constexpr uintptr_t metadata_init = 0x32818FC;
    inline constexpr uintptr_t object_new    = 0x3281B8C;
    inline constexpr uintptr_t str_alloc     = 0x4CC593C;
    inline constexpr uintptr_t google_cred_class = 0x69208E0; // ptr/data
    // creds
    inline constexpr uintptr_t cred_signin_base = 0x3C4EC4C;
    inline constexpr uintptr_t cred_callback    = 0x3C4ECAC;
    inline constexpr uintptr_t cred_success     = 0x4402CC0;
    inline constexpr uintptr_t cred_error       = 0x4402D6C;
    inline constexpr uintptr_t google_cred_ctor = 0x475DBE0;
    // account
    inline constexpr uintptr_t account_signin          = 0x4FF97F0;
    inline constexpr uintptr_t account_signin_with     = 0x4FF98AC;
    inline constexpr uintptr_t account_signin_new      = 0x4FF9EC8;
    inline constexpr uintptr_t account_last_signin     = 0x4FF9658;
    inline constexpr uintptr_t account_cred_selected   = 0x4FFA13C;
    inline constexpr uintptr_t account_callback        = 0x4FFA1B0;


    // bolt init
    inline constexpr uintptr_t bolt_init_step      = 0x3E9A2DC;
    inline constexpr uintptr_t bolt_init           = 0x5798BAC;
    inline constexpr uintptr_t bolt_init_env       = 0x5798DE8;
    inline constexpr uintptr_t bolt_set_ip         = 0x5798F78;
    inline constexpr uintptr_t bolt_endpoint_pair  = 0x3C49568;
    inline constexpr uintptr_t bolt_set_endpoint1  = 0x3B827C8;
    inline constexpr uintptr_t bolt_set_endpoint2  = 0x3B82888;
    inline constexpr uintptr_t bolt_conn_fail_info = 0x5798960;
    // tls
    inline constexpr uintptr_t tls_validate   = 0x588501C;
    inline constexpr uintptr_t x509_raw_data  = 0x4B3FDAC;

    // protobuf
    inline constexpr uintptr_t msg_to_bytes       = 0x463D9A0;
    inline constexpr uintptr_t msg_to_bytestring  = 0x4635510;
    inline constexpr uintptr_t msg_merge_bytes    = 0x463DB48;
    inline constexpr uintptr_t msg_merge_bs       = 0x463D83C;
    inline constexpr uintptr_t bs_to_bytes        = 0x462E0A8;


    // bolt transport
    inline constexpr uintptr_t bolt_deserialize = 0x3B44854;
    inline constexpr uintptr_t bolt_write       = 0x3B48D88;

    // login, auth
    inline constexpr uintptr_t bolt_cred_handoff = 0x4FE9080;
    inline constexpr uintptr_t bolt_login_move   = 0x4FE9FE4;
    inline constexpr uintptr_t key_exchange      = 0x3B54410;
    inline constexpr uintptr_t rpc_builder       = 0x3B43CD0;
    inline constexpr uintptr_t handshake_rpc     = 0x619C2EC;
    inline constexpr uintptr_t auth_connect      = 0x3CE2ED0;
    inline constexpr uintptr_t bolt_lifecycle    = 0x3B82298;
    inline constexpr uintptr_t auth_phase        = 0x3CE3604;
    inline constexpr uintptr_t handshake_phase   = 0x3CE37A4;

    // google
    inline constexpr uintptr_t google_signin     = 0x50AF008;
    inline constexpr uintptr_t google_signin_main= 0x50AF1E0;
    inline constexpr uintptr_t google_callback   = 0x50AF2CC;

    // photon
    inline constexpr uintptr_t photon_connect_master = 0x3DC817C;
    inline constexpr uintptr_t peer_connect          = 0x48B4E2C;
    // play controller
    inline constexpr uintptr_t play_options        = 0x3E5329C;
    inline constexpr uintptr_t play_resolve        = 0x3E534F8;
    inline constexpr uintptr_t play_no_args        = 0x3E5388C;
    inline constexpr uintptr_t play_exception      = 0x3E5398C;
    inline constexpr uintptr_t play_set_busy       = 0x3E53B08;
    inline constexpr uintptr_t play_cancel         = 0x3E53B14;
    inline constexpr uintptr_t play_conn_failed    = 0x3E54094;
    inline constexpr uintptr_t play_photon_error   = 0x3E54BB8;
    inline constexpr uintptr_t play_bolt_error     = 0x3E54F18;
}