LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := dobby
LOCAL_SRC_FILES := libraries/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libba
LOCAL_SRC_FILES := main.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/include
LOCAL_CPPFLAGS := -std=c++17 -O2 -fvisibility=hidden -fno-exceptions -fno-rtti \
                  -ffunction-sections -fdata-sections -Wall -Wextra \
                  -Wno-unused-parameter -Wno-missing-field-initializers
LOCAL_LDFLAGS := -Wl,--gc-sections -Wl,--exclude-libs,ALL \
                 -Wl,-z,relro -Wl,-z,now \
                 -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
LOCAL_LDLIBS := -ldl
LOCAL_STATIC_LIBRARIES := dobby
include $(BUILD_SHARED_LIBRARY)
