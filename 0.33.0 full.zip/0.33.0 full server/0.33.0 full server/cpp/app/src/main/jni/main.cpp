#include "bolt033_certpin.hpp"

using u8 = unsigned char;
using u16 = unsigned short;
using u32 = unsigned int;
using u64 = unsigned long;
using i32 = signed int;
using i64 = signed long;
using usize = unsigned long;
using isize = signed long;
using uptr = unsigned long;

using va_list = __builtin_va_list;

extern "C" {
void* malloc(usize);
void free(void*);
void* memcpy(void*, const void*, usize);
void* memset(void*, int, usize);
int memcmp(const void*, const void*, usize);
usize strlen(const char*);
int strcmp(const char*, const char*);
int strncmp(const char*, const char*, usize);
char* strstr(const char*, const char*);
int atoi(const char*);
int snprintf(char*, usize, const char*, ...);
__attribute__((noreturn)) void abort(void);

int open(const char*, int, ...);
isize read(int, void*, usize);
isize write(int, const void*, usize);
int close(int);
__attribute__((noreturn)) void _exit(int);
unsigned int usleep(unsigned int);
unsigned long getauxval(unsigned long);

struct FsFile;
FsFile* fopen(const char*, const char*);
char* fgets(char*, int, FsFile*);
int fclose(FsFile*);
int sscanf(const char*, const char*, ...);

struct timespec {
    i64 tv_sec;
    i64 tv_nsec;
};
int clock_gettime(int, timespec*);

using pthread_t = u64;
int pthread_create(pthread_t*, const void*, void* (*)(void*), void*);
int pthread_detach(pthread_t);

int DobbyHook(void*, void*, void**);

int CodePatch(void*, u8*, u32);
void* dlsym(void*, const char*);
int* __errno(void);
int getpid(void);
int mprotect(void*, usize, int);

struct dl_phdr_info {
    uptr dlpi_addr;
    const char* dlpi_name;
    const void* dlpi_phdr;
    u16 dlpi_phnum;
};
int dl_iterate_phdr(int (*callback)(dl_phdr_info*, usize, void*), void* data);

struct sockaddr {
    u16 sa_family;
    char sa_data[14];
};
using socklen_t = u32;
int socket(int, int, int);
int connect(int, const sockaddr*, socklen_t);
int fcntl(int, int, ...);
struct pollfd {
    int fd;
    short events;
    short revents;
};
int poll(pollfd*, unsigned long, int);
int getsockopt(int, int, int, void*, socklen_t*);
isize send(int, const void*, usize, int);
isize recv(int, void*, usize, int);
}

void* operator new(usize n) {
    void* p = malloc(n ? n : 1);
    if (!p)
        abort();
    return p;
}

void* operator new[](usize n) {
    return ::operator new(n);
}

void operator delete(void* p) noexcept {
    free(p);
}

void operator delete[](void* p) noexcept {
    free(p);
}

void operator delete(void* p, usize) noexcept {
    free(p);
}

void operator delete[](void* p, usize) noexcept {
    free(p);
}

namespace std {
[[noreturn]] void terminate() {
    abort();
}
} // namespace std

extern "C" void* __cxa_begin_catch(void* p) {
    return p;
}

extern "C" int __gxx_personality_v0(...) {
    return 0;
}

extern "C" void _Unwind_Resume(void*) {
    abort();
}

extern "C" int __android_log_vprint(int, const char*, const char*, va_list) {
    return 0;
}

extern "C" void* abi_cti_vtable[4] __asm__("_ZTVN10__cxxabiv117__class_type_infoE");
extern "C" void* abi_si_vtable[4] __asm__("_ZTVN10__cxxabiv120__si_class_type_infoE");
extern "C" void* abi_vmi_vtable[4] __asm__("_ZTVN10__cxxabiv121__vmi_class_type_infoE");
void* abi_cti_vtable[4] = {};
void* abi_si_vtable[4] = {};
void* abi_vmi_vtable[4] = {};

namespace client033 {

// 0.33 android, arm64 only
static_assert(sizeof(void*) == 8 && sizeof(usize) == 8, "64-bit ABI required");
static_assert(sizeof(u32) == 4 && sizeof(u64) == 8, "Unexpected integer widths");

static constexpr uptr kRtldDefault = 0;
static constexpr uptr kInitBoltExecuteStepRva = 0x3E9A2DC;
static constexpr uptr kMatchmakingConnectRva = 0x3B5B584;

static constexpr int kFcntlGetFlags = 3;
static constexpr int kFcntlSetFlags = 4;
static constexpr int kOpenNonBlock = 04000;
static constexpr short kPollIn = 0x0001;
static constexpr short kPollOut = 0x0004;
static constexpr short kPollError = 0x0008;
static constexpr short kPollHangup = 0x0010;
static constexpr int kSocketLevel = 1;
static constexpr int kSocketError = 4;

static constexpr int kOpenReadOnly = 0;
static constexpr int kOpenCloseOnExec = 02000000;
static constexpr int kClockRealtime = 0;
static constexpr i32 kJniVersion16 = 0x00010006;

struct Il2CppObject {
    void* klass;
    void* monitor;
};
struct Il2CppString {
    Il2CppObject obj;
    i32 length;
    u16 chars[1];
};
struct Il2CppByteArray {
    Il2CppObject obj;
    void* bounds;
    uptr maxLength;
    u8 vector[1];
};

struct ClientConfig {
    char boltPrimary[128];
    char boltSecondary[128];
    char photonHost[128];
    i32 photonPort;
    bool redirectBolt;
    bool redirectPhoton;
    bool trustBoltCertificate;

    bool integrityEnabled;
    bool integrityEnforce;
    i32 integrityIntervalSec;
};

static ClientConfig g_config{};

static uptr g_unity_base = 0;

static volatile int g_started = 0;

static volatile int g_bolt_core_ready = 0;
static volatile int g_sensitive_bootstrap_blocked = 0;
static volatile int g_init_step_gate_armed = 0;
static volatile int g_translated_runtime = -1;
static volatile u16 g_manifest_bolt_port = 2222;
static volatile u16 g_manifest_photon_port = 5055;

// manifest slots, poryadok ne trogat
enum class TargetSlot : u16 {
    ManagedStringCreate = 1,
    InitBoltExecuteStep,
    InitBolt,
    InitBoltEnvironment,
    SetBoltAddress,
    BoltEndpointProvider,
    BoltPrimarySetter,
    BoltSecondarySetter,
    CredentialHandoff,
    TlsValidator,
    CertificateRawData,
    PhotonMasterConnect,
    PhotonPeerConnect,
    MatchmakingTransportConnect,
    Reserved15,
    Reserved16
};

static constexpr u16 kTargetCount = 16;
static uptr g_targets[kTargetCount + 1]{};

static uptr target_rva(TargetSlot slot) {
    const u16 index = static_cast<u16>(slot);
    return index > 0 && index <= kTargetCount ? g_targets[index] : 0;
}

// helpers, chtobi vnizu ne bila pomoyka
static void copy_string(char* out, usize capacity, const char* text) {
    if (!out || capacity == 0)
        return;
    usize i = 0;
    if (text)
        for (; i + 1 < capacity && text[i]; ++i)
            out[i] = text[i];
    out[i] = 0;
}

static bool string_equals(const char* a, const char* b) {
    return a && b && strcmp(a, b) == 0;
}

static void android_breathe(unsigned int usec) {
    // emulator can tupit here
    usleep(usec);
}

static bool read_small_file(const char* path, char* out, usize capacity, usize* bytesRead = nullptr) {
    if (!path || !out || capacity < 2)
        return false;
    int fd = open(path, kOpenReadOnly | kOpenCloseOnExec);
    if (fd < 0)
        return false;
    isize count = read(fd, out, capacity - 1);
    close(fd);
    if (count < 0)
        return false;
    out[count] = 0;
    if (bytesRead)
        *bytesRead = (usize)count;
    return true;
}

static void wipe_memory(void* memory, usize size) {
    volatile u8* bytes = (volatile u8*)memory;
    while (size--)
        *bytes++ = 0;
}

__attribute__((noinline)) static u32 token_step(u32 s) {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
}
__attribute__((noinline)) static bool decode_token(char* out, usize capacity, const volatile u8* encoded, usize length,
                                                   volatile u32 seed) {
    if (!out || !encoded || capacity <= length)
        return false;
    u32 state = (u32)seed;
#if defined(__clang__) || defined(__GNUC__)
    __asm__ __volatile__("" : "+r"(state) : : "memory");
#endif
    for (usize i = 0; i < length; ++i) {
        state = token_step(state);
        u8 byte = encoded[i];
        out[i] = (char)(byte ^ (u8)(state >> 24));
    }
    out[length] = 0;
    return true;
}

__attribute__((noinline)) static void default_backend_host(char out[128]) {
    // ip server, pomenyat pered build
    copy_string(out, 128, "31.76.30.206");
}

static void runtime_proc_maps(char out[24]) {
    static volatile const u8 e[15] = {0x58, 0x4F, 0xBB, 0x90, 0xAF, 0xC8, 0xFF, 0xF1,
                                      0x2E, 0x32, 0x37, 0x66, 0xA9, 0xD8, 0x81};
    if (!decode_token(out, 24, e, sizeof(e), 0xA73D24E1U))
        out[0] = 0;
}

static void runtime_wbarrier_name(char out[40]) {
    static volatile const u8 e[28] = {0x48, 0x24, 0x28, 0x62, 0x0C, 0x2B, 0xE9, 0x54, 0x6D, 0x6D,
                                      0xF7, 0x24, 0xA6, 0xA8, 0xD4, 0xF8, 0x90, 0x9A, 0x0C, 0x62,
                                      0xBB, 0x49, 0xAA, 0x8B, 0xCF, 0x7B, 0x43, 0xAB};
    if (!decode_token(out, 40, e, sizeof(e), 0x94D049BBU))
        out[0] = 0;
}

static void runtime_stock_bolt_host(char out[32]) {
    static volatile const u8 e[20] = {0x9C, 0x75, 0x3A, 0x03, 0x34, 0xB0, 0x63, 0x35, 0x1D, 0xDD,
                                      0x0C, 0xAF, 0xEA, 0xD1, 0xBD, 0x1E, 0x0C, 0x7E, 0x12, 0xFE};
    if (!decode_token(out, 32, e, sizeof(e), 0x5A17C3E1U))
        out[0] = 0;
}

static void runtime_payload_marker(char out[16]) {
    static volatile const u8 e[9] = {0x18, 0xDD, 0xFA, 0x55, 0xA6, 0x37, 0xCE, 0x2E, 0x22};
    if (!decode_token(out, 16, e, sizeof(e), 0xA10F44D3U))
        out[0] = 0;
}

static void runtime_reconnect_marker(char out[32]) {
    static volatile const u8 e[20] = {0xC9, 0x60, 0x7E, 0x20, 0x36, 0xC7, 0xAB, 0x88, 0x74, 0xF3,
                                      0xD1, 0x5A, 0xB7, 0xC6, 0x8B, 0xE4, 0x9B, 0x08, 0x88, 0xD5};
    if (!decode_token(out, 32, e, sizeof(e), 0xC39B127DU))
        out[0] = 0;
}

static void reset_config() {
    memset(&g_config, 0, sizeof(g_config));
    default_backend_host(g_config.boltPrimary);
    default_backend_host(g_config.boltSecondary);
    default_backend_host(g_config.photonHost);
    g_config.photonPort = 5055;
    g_config.redirectBolt = true;
    g_config.redirectPhoton = true;
    g_config.trustBoltCertificate = true;
    g_config.integrityEnabled = true;
    g_config.integrityEnforce = false;
    g_config.integrityIntervalSec = 15;
}

static bool memory_accessible(uptr address, usize size, bool writable, bool executable) {
    char mapsPath[24]{};
    runtime_proc_maps(mapsPath);
    FsFile* file = fopen(mapsPath, "r");
    wipe_memory(mapsPath, sizeof(mapsPath));
    if (!file)
        return false;
    char line[1024];
    bool ok = false;
    while (fgets(line, sizeof(line), file)) {
        unsigned long long begin = 0, end = 0, offset = 0;
        char permissions[5]{};
        char path[600]{};
        int fields = sscanf(line, "%llx-%llx %4s %llx %*s %*s %599[^\n]", &begin, &end, permissions, &offset, path);
        if (fields >= 4 && address >= (uptr)begin && address + size <= (uptr)end &&
            permissions[0] == 'r' && (!writable || permissions[1] == 'w') &&
            (!executable || permissions[2] == 'x')) {
            ok = true;
            break;
        }
    }
    fclose(file);
    return ok;
}

struct LibraryBaseQuery {
    const char* lib;
    uptr base;
};

static int find_library_base_callback(dl_phdr_info* info, usize, void* opaque) {
    if (!info || !opaque)
        return 0;
    LibraryBaseQuery* query = (LibraryBaseQuery*)opaque;
    if (!query->lib || !info->dlpi_name || !*info->dlpi_name)
        return 0;

    const char* hit = strstr(info->dlpi_name, query->lib);
    if (!hit || strcmp(hit, query->lib) != 0)
        return 0;

    if (info->dlpi_addr) {
        query->base = (uptr)info->dlpi_addr;
        return 1;
    }
    return 0;
}

static uptr find_library_base(const char* libraryName) {
    //  /proc/maps
    LibraryBaseQuery query{libraryName, 0};
    dl_iterate_phdr(find_library_base_callback, &query);
    if (query.base) {
        return query.base;
    }

    char mapsPath[24]{};
    runtime_proc_maps(mapsPath);
    FsFile* file = fopen(mapsPath, "r");
    wipe_memory(mapsPath, sizeof(mapsPath));
    if (!file)
        return 0;

    struct Mapping {
        uptr begin, end, offset;
        char permissions[5];
    };
    Mapping maps[64]{};
    int count = 0;
    char line[1024];

    while (fgets(line, sizeof(line), file) && count < 64) {
        if (!strstr(line, libraryName))
            continue;

        unsigned long long begin = 0, end = 0, offset = 0;
        char permissions[5]{};
        if (sscanf(line, "%llx-%llx %4s %llx", &begin, &end, permissions, &offset) < 4)
            continue;

        maps[count].begin = (uptr)begin;
        maps[count].end = (uptr)end;
        maps[count].offset = (uptr)offset;
        memcpy(maps[count].permissions, permissions, 5);
        ++count;
    }
    fclose(file);

    uptr bestBase = 0;
    uptr bestGap = (uptr)-1;

    for (int executableIndex = 0; executableIndex < count; ++executableIndex) {
        if (maps[executableIndex].permissions[2] != 'x')
            continue;

        for (int headerIndex = 0; headerIndex < count; ++headerIndex) {
            if (maps[headerIndex].offset != 0)
                continue;
            if (maps[headerIndex].begin > maps[executableIndex].begin)
                continue;

            uptr gap = maps[executableIndex].begin - maps[headerIndex].begin;
            if (gap < bestGap) {
                bestGap = gap;
                bestBase = maps[headerIndex].begin;
            }
        }
    }

    if (bestBase) {
        return bestBase;
    }

    for (int i = count - 1; i >= 0; --i) {
        if (maps[i].offset == 0) {
            return maps[i].begin;
        }
    }

    return 0;
}

static bool map_executable(uptr address, usize size) {
    char mapsPath[24]{};
    runtime_proc_maps(mapsPath);
    FsFile* file = fopen(mapsPath, "r");
    wipe_memory(mapsPath, sizeof(mapsPath));
    if (!file)
        return false;
    char line[1024];
    bool ok = false;
    while (fgets(line, sizeof(line), file)) {
        unsigned long long begin = 0, end = 0, offset = 0;
        char permissions[5]{};
        if (sscanf(line, "%llx-%llx %4s %llx", &begin, &end, permissions, &offset) >= 4) {
            if (address >= (uptr)begin && address + size <= (uptr)end && permissions[2] == 'x') {
                ok = true;
                break;
            }
        }
    }
    fclose(file);
    return ok;
}

static bool is_executable_rva(uptr rva) {
    return g_unity_base && map_executable(g_unity_base + rva, 4);
}

static void str_to_ascii(Il2CppString* value, char* out, usize capacity) {
    if (!out || capacity == 0) return;

    out[0] = 0;
    if (!value || !memory_accessible((uptr)value, 20, false, false))


        return;

    const i32 length = value->length;
    if (length < 0 || length > 4096)
        return;

    usize count = (usize)length;
    if (count + 1 > capacity)
        count = capacity - 1;

    if (count && !memory_accessible((uptr)value->chars, count * 2, false, false))
        return;

    for (usize i = 0; i < count; ++i) {
        const u16 ch = value->chars[i];
        out[i] = (ch >= 32 && ch < 127) ? (char)ch : '?';
    }
    out[count] = 0;
}

static bool replace_string(Il2CppString* value, const char* replacement) {
    if (!value || !replacement || !memory_accessible((uptr)value, 20, true, false))
        return false;

    const i32 oldLength = value->length;
    const usize newLength = strlen(replacement);
    if (oldLength < 0 || oldLength > 4096 || newLength > (usize)oldLength)
        return false;
    if (oldLength && !memory_accessible((uptr)value->chars, (usize)oldLength * 2, true, false))
        return false;

    for (usize i = 0; i < newLength; ++i)
        value->chars[i] = (u8)replacement[i];
    for (usize i = newLength; i < (usize)oldLength; ++i)
        value->chars[i] = 0;

    value->length = (i32)newLength;
    return true;
}

static void managed_ref_store(void* owner, uptr fieldOffset, void* value) {
    if (!owner || !memory_accessible((uptr)owner + fieldOffset, sizeof(void*), true, false))
        return;
    using WriteBarrierFn = void (*)(void*, void**, void*);
    static WriteBarrierFn writeBarrier = nullptr;
    static bool resolved = false;
    if (!resolved) {
        resolved = true;
        char symbol[40]{};
        runtime_wbarrier_name(symbol);
        writeBarrier = (WriteBarrierFn)dlsym((void*)kRtldDefault, symbol);
        wipe_memory(symbol, sizeof(symbol));
    }
    void** field = (void**)((uptr)owner + fieldOffset);
    if (writeBarrier)
        writeBarrier(owner, field, value);
    else
        *field = value;
}

static Il2CppString* string_field(void* owner, uptr offset) {
    if (!owner || !memory_accessible((uptr)owner, offset + 8, false, false))
        return nullptr;
    return *(Il2CppString**)((uptr)owner + offset);
}

static Il2CppString* make_managed_string(const char* text) {
    using StringCreateFn = Il2CppString* (*)(i32, const void*);
    StringCreateFn createString = (StringCreateFn)(g_unity_base + target_rva(TargetSlot::ManagedStringCreate));
    usize length = strlen(text);
    if (!is_executable_rva(target_rva(TargetSlot::ManagedStringCreate)) || length > 4096)
        return nullptr;
    Il2CppString* value = createString((i32)length, nullptr);
    if (!value || !memory_accessible((uptr)value, 20 + length * 2, true, false))
        return nullptr;
    value->length = (i32)length;
    for (usize i = 0; i < length; ++i)
        value->chars[i] = (u8)text[i];
    return value;
}

static usize runtime_page_size() {
    static volatile usize cached = 0;
    usize pageSize = __atomic_load_n(&cached, __ATOMIC_ACQUIRE);
    if (pageSize)
        return pageSize;
    const unsigned long kAuxPageSize = 6UL;
    usize detectedSize = (usize)getauxval(kAuxPageSize);
    if (detectedSize < 4096 || detectedSize > 65536 || (detectedSize & (detectedSize - 1)) != 0)
        detectedSize = 4096;
    __atomic_store_n(&cached, detectedSize, __ATOMIC_RELEASE);
    return detectedSize;
}

// native bridge sometimes tupit on start

static bool is_translated_runtime() {
    int cached = __atomic_load_n(&g_translated_runtime, __ATOMIC_ACQUIRE);
    if (cached >= 0)
        return cached != 0;

    char mapsPath[24]{};
    runtime_proc_maps(mapsPath);
    FsFile* file = fopen(mapsPath, "r");

    wipe_memory(mapsPath, sizeof(mapsPath));
    if (!file) {

        __atomic_store_n(&g_translated_runtime, 0, __ATOMIC_RELEASE);
        return false;
    }
    char line[1024];
    bool translated = false;
    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, "houdini") || strstr(line, "Houdini") || strstr(line, "ndk_translation") ||
            strstr(line, "nativebridge") || strstr(line, "native_bridge") || strstr(line, "libnb.so") ||
            strstr(line, "intel_bridge") || strstr(line, "IntelBridge")) {
            translated = true;
            break;
        }
    }
    fclose(file);
    __atomic_store_n(&g_translated_runtime, translated ? 1 : 0, __ATOMIC_RELEASE);
    return translated;
}

static bool are_target_bytes_stable(uptr address) {
    if (!memory_accessible(address, 16, false, true))
        return false;
    u8 before[16]{}, after[16]{};
    memcpy(before, (const void*)address, sizeof(before));
    android_breathe(120000);
    if (!memory_accessible(address, 16, false, true))
        return false;
    memcpy(after, (const void*)address, sizeof(after));
    return memcmp(before, after, sizeof(before)) == 0;
}

static bool prepare_hook_page(void* target, uptr* pageOut, usize* spanOut, int* changedOut) {
    if (pageOut)
        *pageOut = 0;
    if (spanOut)
        *spanOut = 0;
    if (changedOut)
        *changedOut = 0;
    uptr address = (uptr)target;
    usize pageSize = runtime_page_size();
    uptr page = address & ~((uptr)pageSize - 1);
    usize span = pageSize;

    if ((address - page) + 32 > pageSize)
        span = pageSize * 2;
    if (pageOut)
        *pageOut = page;
    if (spanOut)
        *spanOut = span;

    bool readable = memory_accessible(address, 16, false, true);
    if (readable)
        return true;

    if (mprotect((void*)page, span, 1 | 4) != 0)
        return false;
    if (changedOut)
        *changedOut = 1;
    return memory_accessible(address, 16, false, true);
}

template <class OriginalFn, class ReplacementFn>
static bool install_hook(uptr rva, ReplacementFn replacement, OriginalFn* original) {
    // dobby ok
    if (!is_executable_rva(rva)) {
        return false;
    }

    void* target = (void*)(g_unity_base + rva);

    uptr page = 0;
    usize span = 0;
    int promoted = 0;
    if (!prepare_hook_page(target, &page, &span, &promoted)) {
        return false;
    }
    if (!are_target_bytes_stable((uptr)target)) {
        return false;
    }

    const bool translated = is_translated_runtime();
    if (translated) {
        android_breathe(50000);
    }

    *original = nullptr;
    int status = DobbyHook(target, (void*)replacement, (void**)original);
    __builtin___clear_cache((char*)page, (char*)(page + span));

    if (promoted)
        mprotect((void*)page, span, 1 | 4);

    if (status != 0 || !*original) {
        return false;
    }

    if (translated)
        android_breathe(250000);
    return true;
}

template <class OriginalFn, class ReplacementFn>
static bool install_bootstrap_hook(uptr rva, ReplacementFn replacement, OriginalFn* original) {
    if (!is_executable_rva(rva)) {
        return false;
    }
    void* target = (void*)(g_unity_base + rva);
    uptr page = 0;
    usize span = 0;
    int promoted = 0;
    if (!prepare_hook_page(target, &page, &span, &promoted)) {
        return false;
    }
    *original = nullptr;
    int status = DobbyHook(target, (void*)replacement, (void**)original);
    __builtin___clear_cache((char*)page, (char*)(page + span));
    if (promoted)
        mprotect((void*)page, span, 1 | 4);
    if (status != 0 || !*original) {
        return false;
    }
    return true;
}

static i64 now_ms() {
    timespec ts{};
    clock_gettime(kClockRealtime, &ts);
    return ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

using InitStepFn = void* (*)(void*, uptr, const void*);
static InitStepFn g_original_init_step;

static void* hook_init_step(void* self, uptr cancellationToken, const void* method) {
    if (__atomic_load_n(&g_sensitive_bootstrap_blocked, __ATOMIC_ACQUIRE))
        return g_original_init_step ? g_original_init_step(self, cancellationToken, method) : nullptr;

       // timeout
    if (!__atomic_load_n(&g_bolt_core_ready, __ATOMIC_ACQUIRE)) {
        for (int i = 0; i < 6000 && !__atomic_load_n(&g_bolt_core_ready, __ATOMIC_ACQUIRE); ++i)
            android_breathe(10000);
    }
    return g_original_init_step ? g_original_init_step(self, cancellationToken, method) : nullptr;
}

using EndpointPairFn = void* (*)(void*, const void*);
static EndpointPairFn g_original_endpoint_pair;

static void* hook_endpoint_pair(void* self, const void* method) {
    void* pair = g_original_endpoint_pair(self, method);
    if (g_config.redirectBolt && pair) {
        Il2CppString* primary = string_field(pair, 0x10);
        Il2CppString* secondary = string_field(pair, 0x18);
        if (!replace_string(primary, g_config.boltPrimary)) {
            Il2CppString* replacement = make_managed_string(g_config.boltPrimary);
            if (replacement)
                managed_ref_store(pair, 0x10, replacement);
        }
        if (!replace_string(secondary, g_config.boltSecondary)) {
            Il2CppString* replacement = make_managed_string(g_config.boltSecondary);
            if (replacement)
                managed_ref_store(pair, 0x18, replacement);
        }
    }
    return pair;
}

using EndpointSetterFn = void (*)(void*, Il2CppString*, const void*);
static EndpointSetterFn g_original_primary_setter;
static EndpointSetterFn g_original_secondary_setter;

static void hook_primary_setter(void* self, Il2CppString* value, const void* method) {
    if (g_config.redirectBolt) {
        if (!replace_string(value, g_config.boltPrimary)) {
            Il2CppString* replacement = make_managed_string(g_config.boltPrimary);
            if (replacement)
                value = replacement;
        }
    }
    g_original_primary_setter(self, value, method);
}

static void hook_secondary_setter(void* self, Il2CppString* value, const void* method) {
    if (g_config.redirectBolt) {
        if (!replace_string(value, g_config.boltSecondary)) {
            Il2CppString* replacement = make_managed_string(g_config.boltSecondary);
            if (replacement)
                value = replacement;
        }
    }
    g_original_secondary_setter(self, value, method);
}

using TlsValidateFn = void* (*)(void*, Il2CppString*, bool, void*, void*, const void*);
static TlsValidateFn g_original_tls_validate;

static bool bolt_tls_host(const char* host) {
    if (!host)
        return false;
    char stockHost[32]{};
    runtime_stock_bolt_host(stockHost);
    const bool ok = string_equals(host, stockHost) || string_equals(host, g_config.boltPrimary) ||
                    string_equals(host, g_config.boltSecondary);
    wipe_memory(stockHost, sizeof(stockHost));
    return ok;
}

static bool bolt_tls_cert(void* leaf) {
    if (!leaf || !is_executable_rva(target_rva(TargetSlot::CertificateRawData)))
        return false;
    using CertificateDataFn = Il2CppByteArray* (*)(void*, const void*);
    CertificateDataFn readCertificateData = (CertificateDataFn)(g_unity_base + target_rva(TargetSlot::CertificateRawData));
    Il2CppByteArray* raw = readCertificateData(leaf, nullptr);
    if (!raw || !memory_accessible((uptr)raw, 0x20, false, false))
        return false;
    usize size = (usize)raw->maxLength;
    if (size != (usize)bolt033_pin::kCertificateDerSize)
        return false;
    if (!memory_accessible((uptr)raw->vector, size, false, false))
        return false;
    return memcmp(raw->vector, bolt033_pin::kCertificateDer, size) == 0;
}

static bool accept_tls_result(void* result, void* self) {
    if (!result || !memory_accessible((uptr)result, 0x20, true, false))
        return false;
    u8* bytes = (u8*) result;
    bytes[0x10] = 1;
    bytes[0x11] = 0;
    *(i32*)(bytes + 0x14) = 0;
    memset(bytes + 0x18, 0, 8);
    if (self && memory_accessible((uptr)self, 0x40, false, false)) {
        void* stream = *(void**)((uptr)self + 0x38);
        if (stream && memory_accessible((uptr)stream + 0x44, 1, true, false))
            *((u8*)((uptr)stream + 0x44)) = 0;
    }

    return true;
}

static void* hook_tls_validate(void* self, Il2CppString* host, bool serverMode, void* leaf, void* chain,
                               const void* method) {
    char hostname[256]{};
    str_to_ascii(host, hostname, sizeof(hostname));

    void* result = g_original_tls_validate(self, host, serverMode, leaf, chain, method);
    const bool localHost =
        g_config.redirectBolt && g_config.trustBoltCertificate && !serverMode && bolt_tls_host(hostname);
    if (localHost && bolt_tls_cert(leaf))
        accept_tls_result(result, self);
    return result;
}

using PhotonMasterFn = bool (*)(Il2CppString*, i32, Il2CppString*, Il2CppString*, const void*);
static PhotonMasterFn g_original_photon_master;
static bool hook_photon_master(Il2CppString* address, i32 port, Il2CppString* app, Il2CppString* version,
                               const void* method) {
    Il2CppString* endpoint = address;
    i32 endpointPort = port;
    if (g_config.redirectPhoton) {
        if (Il2CppString* replacement = make_managed_string(g_config.photonHost)) {
            endpoint = replacement;
            endpointPort = g_config.photonPort;
        }
    }
    return g_original_photon_master(endpoint, endpointPort, app, version, method);
}

static bool is_bolt_candidate_port(u16 port) {
     return port ==  2222 || port == 2223 || port == 2224;
}

using TransportConnectFn = void* (*)(void*, void*, const void*);
static TransportConnectFn g_original_matchmaking_connect = nullptr;

static Il2CppString* dedicated_matchmaking_endpoint() {
    return make_managed_string(g_config.boltPrimary);
}

static bool read_int32_field(void* base, uptr offset, i32* out) {
    if (out)
        *out = 0x7fffffff;
    if (!base || !memory_accessible((uptr)base + offset, sizeof(i32), false, false))
        return false;
    if (out)
        *out = *(i32*)((uptr)base + offset);
    return true;
}

static void* hook_matchmaking_connect(void* self, void* config, const void* method) {
    i32 port = 0;
    if (config)
        read_int32_field(config, 0x24, &port);

    const bool ready = __atomic_load_n(&g_bolt_core_ready, __ATOMIC_ACQUIRE) != 0;
    if (config && ready && is_bolt_candidate_port((u16)(port & 0xFFFF)) &&
        memory_accessible((uptr)config + 0x30, sizeof(i32), true, false)) {
        if (Il2CppString* endpoint = dedicated_matchmaking_endpoint()) {
            managed_ref_store(config, 0x10, endpoint);
            managed_ref_store(config, 0x18, endpoint);
        }

        u16 targetPort = __atomic_load_n(&g_manifest_bolt_port, __ATOMIC_ACQUIRE);
        if (!targetPort)
            targetPort = 2222;
        *(volatile i32*)((uptr)config + 0x24) = (i32)targetPort;
        __sync_synchronize();
    }

    return g_original_matchmaking_connect ? g_original_matchmaking_connect(self, config, method) : nullptr;
}

static bool patch_arm64_word(uptr rva, u32 expected, u32 replacement) {
    uptr address = g_unity_base + rva;
    u32 current = 0;
    if (!memory_accessible(address, sizeof(current), false, true)) {
        return false;
    }
    memcpy(&current, (const void*)address, sizeof(current));
    if (current == replacement) {
        return true;
    }
    if (current != expected) {
        return false;
    }
    u32 patchedWord = replacement;
    int status = CodePatch((void*)address, (u8*)&patchedWord, (u32)sizeof(patchedWord));
    if (status != 0) {
        return false;
    }
    __builtin___clear_cache((char*)address, (char*)(address + sizeof(patchedWord)));
    u32 readBack = 0;
    memcpy(&readBack, (const void*)address, sizeof(readBack));
    if (readBack != replacement) {
        return false;
    }
    return true;
}

// room fix
static bool install_public_room_patch() {
    const bool waitPatch = patch_arm64_word(0x428DC30, 0x540000EC, 0x14000007);
    const bool resultPatch = patch_arm64_word(0x428DC94, 0x1A9FD7E1, 0x52800021);
    return waitPatch && resultPatch;
}

static bool bolt_targets_ready() {
    static constexpr TargetSlot required[] = {TargetSlot::InitBoltExecuteStep, TargetSlot::BoltEndpointProvider,
                                              TargetSlot::BoltPrimarySetter, TargetSlot::BoltSecondarySetter,
                                              TargetSlot::TlsValidator};

    for (TargetSlot slot : required) {
        if (!is_executable_rva(target_rva(slot)))
            return false;
    }
    return true;
}

static const u8 kManifestSeedA[32] = {0x6B, 0x3E, 0xD6, 0xDE, 0xAA, 0x70, 0x12, 0xF9, 0xE0, 0x09, 0x6D,
                                      0x85, 0xF0, 0xCC, 0x5B, 0x97, 0xEA, 0xF9, 0x87, 0x21, 0xE9, 0x15,
                                      0x87, 0x83, 0x28, 0x37, 0x9F, 0x05, 0x0D, 0xD7, 0x54, 0x6E};

static const u8 kManifestSeedB[32] = {0x6B, 0x65, 0xF9, 0x0A, 0xA6, 0x24, 0x8D, 0x75, 0xF1, 0xF0, 0x69,
                                      0xE7, 0x60, 0x50, 0xC4, 0x07, 0x99, 0xA7, 0x3B, 0x15, 0x13, 0x47,
                                      0xA4, 0xDE, 0xC3, 0xE2, 0x64, 0xEB, 0x8E, 0x3B, 0xA4, 0x66};

static const u32 kManifestMagic = 0x334D5652U;
static const u16 kManifestVersion = 3;
static const u16 kManifestPort = 2221;
static const u64 kManifestBuild = 0x03300003ULL;
static const usize kManifestResponseSize = 192;
static const usize kManifestAuthenticatedBytes = 160;
static const u64 kCapabilityBolt = 1ULL << 0;
static const u64 kCapabilityPhoton = 1ULL << 1;
static u64 g_manifest_capabilities = 0;
static u32 rotr32(u32 x, u32 n) {
    return (x >> n) | (x << (32 - n));
}

struct Sha256Context {
    u32 state[8];
    u64 bitCount;
    u8 buffer[64];
    u32 buffered;
};

static const u32 kSha256RoundConstants[64] = {
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U, 0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U, 0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU, 0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U, 0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U, 0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U, 0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U, 0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U, 0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U};

static void sha256_transform(Sha256Context& ctx, const u8* block) {
    u32 schedule[64];
    for (int i = 0; i < 16; ++i) {
        schedule[i] = ((u32)block[i * 4] << 24) | ((u32)block[i * 4 + 1] << 16) |
                      ((u32)block[i * 4 + 2] << 8) | block[i * 4 + 3];
    }
    for (int i = 16; i < 64; ++i) {
        const u32 sigma0 = rotr32(schedule[i - 15], 7) ^ rotr32(schedule[i - 15], 18) ^
                           (schedule[i - 15] >> 3);
        const u32 sigma1 = rotr32(schedule[i - 2], 17) ^ rotr32(schedule[i - 2], 19) ^
                           (schedule[i - 2] >> 10);
        schedule[i] = schedule[i - 16] + sigma0 + schedule[i - 7] + sigma1;
    }

    u32 a = ctx.state[0], b = ctx.state[1], c = ctx.state[2], d = ctx.state[3];
    u32 e = ctx.state[4], f = ctx.state[5], g = ctx.state[6], h = ctx.state[7];
    for (int i = 0; i < 64; ++i) {
        const u32 sigma1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25);
        const u32 choose = (e & f) ^ ((~e) & g);
        const u32 temp1 = h + sigma1 + choose + kSha256RoundConstants[i] + schedule[i];
        const u32 sigma0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22);
        const u32 majority = (a & b) ^ (a & c) ^ (b & c);
        const u32 temp2 = sigma0 + majority;
        h = g;
        g = f;
        f = e;
        e = d + temp1;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2;
    }
    ctx.state[0] += a;
    ctx.state[1] += b;
    ctx.state[2] += c;
    ctx.state[3] += d;
    ctx.state[4] += e;
    ctx.state[5] += f;
    ctx.state[6] += g;
    ctx.state[7] += h;
}

static void sha256_init(Sha256Context& ctx) {
    u32 initialState[8] = {0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
                           0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
    memcpy(ctx.state, initialState, sizeof(initialState));
    ctx.bitCount = 0;
    ctx.buffered = 0;
}

static void sha256_update(Sha256Context& ctx, const u8* data, usize size) {
    ctx.bitCount += (u64)size * 8;
    while (size) {
        usize chunkSize = 64 - ctx.buffered;
        if (chunkSize > size)
            chunkSize = size;
        memcpy(ctx.buffer + ctx.buffered, data, chunkSize);
        ctx.buffered += (u32)chunkSize;
        data += chunkSize;
        size -= chunkSize;
        if (ctx.buffered == 64) {
            sha256_transform(ctx, ctx.buffer);
            ctx.buffered = 0;
        }
    }
}

static void sha256_final(Sha256Context& ctx, u8 out[32]) {
    ctx.buffer[ctx.buffered++] = 0x80;
    if (ctx.buffered > 56) {
        while (ctx.buffered < 64)
            ctx.buffer[ctx.buffered++] = 0;
        sha256_transform(ctx, ctx.buffer);
        ctx.buffered = 0;
    }
    while (ctx.buffered < 56)
        ctx.buffer[ctx.buffered++] = 0;
    for (int i = 7; i >= 0; i--)
        ctx.buffer[ctx.buffered++] = (u8)(ctx.bitCount >> (i * 8));
    sha256_transform(ctx, ctx.buffer);
    for (int i = 0; i < 8; i++) {
        out[i * 4] = (u8)(ctx.state[i] >> 24);
        out[i * 4 + 1] = (u8)(ctx.state[i] >> 16);
        out[i * 4 + 2] = (u8)(ctx.state[i] >> 8);
        out[i * 4 + 3] = (u8)ctx.state[i];
    }
}

static void sha256_digest(const u8* data, usize size, u8 out[32]) {
    Sha256Context ctx;
    sha256_init(ctx);
    sha256_update(ctx, data, size);
    sha256_final(ctx, out);
    wipe_memory(&ctx, sizeof(ctx));
}

static void derive_manifest_key(u8 out[32]) {
    u8 material[72]{};
    memcpy(material, kManifestSeedA, 32);
    memcpy(material + 32, kManifestSeedB, 32);
    for (int i = 0; i < 8; i++)
        material[64 + i] = (u8)(kManifestBuild >> (i * 8));
    sha256_digest(material, sizeof(material), out);
    wipe_memory(material, sizeof(material));
}

static void hmac_sha256(const u8* key, usize keySize, const u8* message, usize messageSize, u8 out[32]) {
    u8 keyBlock[64]{}, innerHash[32], outerPad[64], innerPad[64];
    if (keySize > 64) {
        Sha256Context keyHash;
        sha256_init(keyHash);
        sha256_update(keyHash, key, keySize);
        sha256_final(keyHash, keyBlock);
    } else
        memcpy(keyBlock, key, keySize);
    for (int i = 0; i < 64; i++) {
        innerPad[i] = keyBlock[i] ^ 0x36;
        outerPad[i] = keyBlock[i] ^ 0x5c;
    }
    Sha256Context inner;

    sha256_init(inner);
    sha256_update(inner, innerPad, 64);
    sha256_update(inner, message, messageSize);
    sha256_final(inner, innerHash);

    Sha256Context outer;

    sha256_init(outer);
    sha256_update(outer, outerPad, 64);
    sha256_update(outer, innerHash, 32);
    sha256_final(outer, out);

    wipe_memory(keyBlock, sizeof(keyBlock));
    wipe_memory(innerHash, sizeof(innerHash));
    wipe_memory(outerPad, sizeof(outerPad));
    wipe_memory(innerPad, sizeof(innerPad));
}

static bool constant_time_equal32(const u8* a, const u8* b) {
    u8 difference = 0;
    for (int i = 0; i < 32; i++)
        difference |= a[i] ^ b[i];
    return difference == 0;
}

static void write_u16_le(u8* p, u16 v) {
    p[0] = (u8)v;
    p[1] = (u8)(v >> 8);
}

static void write_u32_le(u8* p, u32 v) {
    for (int i = 0; i < 4; i++)
        p[i] = (u8)(v >> (i * 8));
}

static void write_u64_le(u8* p, u64 v) {
    for (int i = 0; i < 8; i++)
        p[i] = (u8)(v >> (i * 8));
}

static u16 read_u16_le(const u8* p) {
    return (u16)((u16)p[0] | ((u16)p[1] << 8));
}

static u32 read_u32_le(const u8* p) {
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

static u64 read_u64_le(const u8* p) {
    u64 v = 0;
    for (int i = 7; i >= 0; i--)
        v = (v << 8) | p[i];
    return v;
}

static bool parse_ipv4(const char* text, u32& out) {
    u32 octets[4]{};
    if (!text)
        return false;
    for (int index = 0; index < 4; index++) {
        u32 value = 0;
        int digits = 0;
        while (*text >= '0' && *text <= '9') {
            value = value * 10 + (u32)(*text - '0');
            if (value > 255)
                return false;
            text++;
            digits++;
        }
        if (!digits)
            return false;
        octets[index] = value;
        if (index < 3) {
            if (*text != '.')
                return false;
            text++;
        }
    }
    if (*text)
        return false;
    out = octets[0] | (octets[1] << 8) | (octets[2] << 16) | (octets[3] << 24);
    return true;
}

struct sockaddr_in4 {
    u16 family;
    u16 port;
    u32 addr;
    u8 zero[8];
};

static u16 net16(u16 x) {
    return (u16)((x << 8) | (x >> 8));
}

static u64 boot_nonce() {
    u64 nonce = 0;
    int randomFd = open("/dev/urandom", kOpenReadOnly | kOpenCloseOnExec);
    if (randomFd >= 0) {
        isize count = read(randomFd, &nonce, sizeof(nonce));
        close(randomFd);
        if (count == (isize)sizeof(nonce) && nonce)
            return nonce;
    }
    timespec time{};
    clock_gettime(kClockRealtime, &time);
    nonce = ((u64)time.tv_sec << 32) ^ (u64)time.tv_nsec ^ (u64)getpid() ^ (u64)(uptr)&time;
    return nonce ? nonce : 0x9e3779b97f4a7c15ULL;
}

static u32 target_mask(const u8 key[32], u64 clientNonce, u64 serverNonce, u64 generation, u16 slot) {
    u8 message[32]{}, mac[32];
    write_u64_le(message, clientNonce);
    write_u64_le(message + 8, serverNonce);
    write_u64_le(message + 16, generation);
    write_u16_le(message + 24, slot);
    write_u16_le(message + 26, kManifestVersion);
    write_u32_le(message + 28, (u32)kManifestBuild);
    hmac_sha256(key, 32, message, sizeof(message), mac);
    u32 mask = read_u32_le(mac);
    wipe_memory(mac, sizeof(mac));
    wipe_memory(message, sizeof(message));
    return mask;
}

static int net_errno() {
    int* error = __errno();
    return error ? *error : 0;
}

static bool wait_fd(int fd, short events, int timeoutMs, short* outRevents) {
    pollfd descriptor{};
    descriptor.fd = fd;
    descriptor.events = events;
    int status = poll(&descriptor, 1UL, timeoutMs);
    if (outRevents)
        *outRevents = descriptor.revents;

    if (status <= 0) {
        return false;
    }
    if (descriptor.revents & (kPollError | kPollHangup)) {
        return false;
    }
    return (descriptor.revents & events) != 0;
}

static bool is_pending_socket_error(int error) {
    constexpr int kTryAgain = 11;
    constexpr int kAlreadyInProgress = 114;
    constexpr int kInProgress = 115;
    return error == kTryAgain || error == kAlreadyInProgress || error == kInProgress;
}

static bool connect_nonblocking(int fd, const sockaddr* address, socklen_t addressSize, int timeoutMs) {
    int oldFlags = fcntl(fd, kFcntlGetFlags, 0);
    if (oldFlags < 0) {
        return false;
    }
    if (fcntl(fd, kFcntlSetFlags, oldFlags | kOpenNonBlock) != 0) {
        return false;
    }

    int status = connect(fd, address, addressSize);
    if (status == 0) {
        return true;
    }

    int error = net_errno();

    if (!is_pending_socket_error(error)) {
        return false;
    }

    short revents = 0;
    if (!wait_fd(fd, kPollOut, timeoutMs, &revents)) {
        return false;
    }

    int socketError = -1;
    socklen_t optionSize = (socklen_t)sizeof(socketError);
    if (getsockopt(fd, kSocketLevel, kSocketError, &socketError, &optionSize) != 0) {
        return false;
    }
    if (socketError != 0) {
        return false;
    }

    return true;
}

static bool send_bounded(int fd, const u8* data, usize size, int timeoutMs) {
    usize sent = 0;
    while (sent < size) {
        isize count = send(fd, data + sent, size - sent, 0);
        if (count > 0) {
            sent += (usize)count;
            continue;
        }

        int error = net_errno();
        if (count < 0 && is_pending_socket_error(error)) {
            short revents = 0;
            if (!wait_fd(fd, kPollOut, timeoutMs, &revents))
                return false;
            continue;
        }

        return false;
    }
    return true;
}

static bool recv_bounded(int fd, u8* data, usize size, int timeoutMs) {
    usize received = 0;
    while (received < size) {
        isize count = recv(fd, data + received, size - received, 0);
        if (count > 0) {
            received += (usize)count;
            continue;
        }
        if (count == 0) {
            return false;
        }

        int error = net_errno();
        if (is_pending_socket_error(error)) {
            short revents = 0;
            if (!wait_fd(fd, kPollIn, timeoutMs, &revents))
                return false;
            continue;
        }

        return false;
    }
    return true;
}

static bool fetch_manifest() {
    // bez prikolov
    char host[128]{};
    default_backend_host(host);
    u32 ip = 0;
    if (!parse_ipv4(host, ip)) {
        return false;
    }
    int fd = socket(2, 1, 0);
    if (fd < 0) {
        return false;
    }
    sockaddr_in4 address{};
    address.family = 2;
    address.port = net16(kManifestPort);
    address.addr = ip;
    if (!connect_nonblocking(fd, (const sockaddr*)&address, (socklen_t)sizeof(address), 900)) {
        close(fd);
        return false;
    }

    u8 key[32];
    derive_manifest_key(key);
    u8 request[64]{};
    const u64 clientNonce = boot_nonce();
    timespec ts{};
    clock_gettime(kClockRealtime, &ts);
    write_u32_le(request, kManifestMagic);
    write_u16_le(request + 4, kManifestVersion);
    write_u16_le(request + 6, 0xB314U);
    write_u64_le(request + 8, kManifestBuild);
    write_u64_le(request + 16, clientNonce);
    write_u64_le(request + 24, (u64)ts.tv_sec);
    hmac_sha256(key, 32, request, 32, request + 32);
    if (!send_bounded(fd, request, sizeof(request), 900)) {
        wipe_memory(key, sizeof(key));
        close(fd);
        return false;
    }

    u8 response[kManifestResponseSize]{};
    bool ok = recv_bounded(fd, response, sizeof(response), 1500);
    close(fd);
    if (!ok) {
        wipe_memory(key, sizeof(key));
        return false;
    }
    if (read_u32_le(response) != kManifestMagic || read_u16_le(response + 4) != kManifestVersion ||
        read_u16_le(response + 6) != 0 || read_u64_le(response + 8) != clientNonce) {
        wipe_memory(key, sizeof(key));
        return false;
    }

    u8 responseMac[32]{};
    hmac_sha256(key, 32, response, kManifestAuthenticatedBytes, responseMac);
    if (!constant_time_equal32(responseMac, response + kManifestAuthenticatedBytes)) {
        wipe_memory(key, sizeof(key));
        wipe_memory(responseMac, sizeof(responseMac));
        return false;
    }
    wipe_memory(responseMac, sizeof(responseMac));

    const u64 serverNonce = read_u64_le(response + 16);
    const u64 generation = read_u64_le(response + 24);
    const u64 expiresAt = read_u64_le(response + 32);
    const u64 capabilities = read_u64_le(response + 40);
    const u16 boltPort = read_u16_le(response + 48);
    const u16 photonPort = read_u16_le(response + 50);
    const u16 count = read_u16_le(response + 52);
    const u16 flags = read_u16_le(response + 54);
    const u64 build = read_u64_le(response + 56);
    if (serverNonce == 0 || generation == 0 || expiresAt == 0 || count != (u16)kTargetCount || (flags & 0x0001U) == 0 ||
        build != kManifestBuild || boltPort == 0 || photonPort == 0 || (capabilities & kCapabilityBolt) == 0) {
        wipe_memory(key, sizeof(key));
        return false;
    }

    uptr candidate[(int)kTargetCount + 1]{};
    for (u16 slot = 1; slot <= (u16)kTargetCount; ++slot) {
        const u32 masked = read_u32_le(response + 64 + (usize)(slot - 1) * 4);
        const u32 rva = masked ^ target_mask(key, clientNonce, serverNonce, generation, slot);
        if (rva < 0x1000U || rva > 0x0FFFFFFFU) {
            wipe_memory(key, sizeof(key));
            wipe_memory(candidate, sizeof(candidate));
            return false;
        }
        candidate[slot] = (uptr)rva;
    }
    for (u16 slot = 1; slot <= (u16)kTargetCount; ++slot)
        for (u16 otherSlot = (u16)(slot + 1); otherSlot <= (u16)kTargetCount; ++otherSlot)
            if (candidate[slot] == candidate[otherSlot]) {
                wipe_memory(key, sizeof(key));
                wipe_memory(candidate, sizeof(candidate));
                return false;
            }

    u16 badSlot = 0;
    for (u16 slot = 1; slot <= (u16)kTargetCount; ++slot) {
        if (!is_executable_rva(candidate[slot])) {
            badSlot = slot;
            break;
        }
    }
    if (badSlot) {

       const uptr oldBase = g_unity_base;
       const uptr refreshed = find_library_base("libunity.so");
        if (refreshed && refreshed != oldBase) {

            g_unity_base = refreshed;
              badSlot = 0;
            for (u16 slot = 1; slot <= (u16)kTargetCount; ++slot) {
                
                if (!is_executable_rva(candidate[slot])) {
                    badSlot = slot;
                    break;
                }
            }
        }
    }
    if (badSlot) {
        wipe_memory(key, sizeof(key));
        wipe_memory(candidate, sizeof(candidate));
        return false;
    }

    memcpy(g_targets, candidate, sizeof(g_targets));
    g_manifest_capabilities = capabilities;
    __atomic_store_n(&g_manifest_bolt_port, boltPort, __ATOMIC_RELEASE);
    __atomic_store_n(&g_manifest_photon_port, photonPort, __ATOMIC_RELEASE);
    wipe_memory(candidate, sizeof(candidate));
    wipe_memory(key, sizeof(key));
    return true;
}

static bool has_capability(u64 value) {
    return (g_manifest_capabilities & value) != 0;
}

static unsigned int boot_hook_gap() {
    return is_translated_runtime() ? 250000U : 50000U;
}

template <class OriginalFn, class ReplacementFn>
static bool install_target_hook(TargetSlot slot, ReplacementFn replacement, OriginalFn* original) {
    const bool ok = is_executable_rva(target_rva(slot)) && install_hook(target_rva(slot), replacement, original);
    android_breathe(boot_hook_gap());
    return ok;
}

template <class OriginalFn, class ReplacementFn>
static bool install_direct_hook(uptr rva, ReplacementFn replacement, OriginalFn* original) {
    const bool ok = is_executable_rva(rva) && install_hook(rva, replacement, original);
    android_breathe(boot_hook_gap());
    return ok;
}

static bool install_bolt_hooks() {
    bool ok = true;

    if (__atomic_load_n(&g_init_step_gate_armed, __ATOMIC_ACQUIRE)) {
        if (target_rva(TargetSlot::InitBoltExecuteStep) != kInitBoltExecuteStepRva || !g_original_init_step) {
            return false;
        }
    } else {
        ok &= install_target_hook(TargetSlot::InitBoltExecuteStep, hook_init_step, &g_original_init_step);
    }

    // try oll hooks
    ok &= install_target_hook(TargetSlot::BoltEndpointProvider, hook_endpoint_pair, &g_original_endpoint_pair);
    ok &= install_target_hook(TargetSlot::BoltPrimarySetter, hook_primary_setter, &g_original_primary_setter);
    ok &= install_target_hook(TargetSlot::BoltSecondarySetter, hook_secondary_setter, &g_original_secondary_setter);
    if (!ok)
        return false;

    if (g_config.trustBoltCertificate) {
        if (!install_target_hook(TargetSlot::TlsValidator, hook_tls_validate, &g_original_tls_validate))
            return false;
    }
    return true;
}

static bool install_photon_hooks() {
    if (!g_config.redirectPhoton || !has_capability(kCapabilityPhoton)) {
        return false;
    }
    if (!install_target_hook(TargetSlot::PhotonMasterConnect, hook_photon_master, &g_original_photon_master))
        return false;
    return true;
}

static void install_matchmaking_hooks() {
    install_public_room_patch();
    android_breathe(boot_hook_gap());

    install_direct_hook(kMatchmakingConnectRva, hook_matchmaking_connect, &g_original_matchmaking_connect);
}

struct IntegrityVerdict {
    int rootSignals;
    int tracerPid;
    int emulatorSignals;
    int frameworkSignals;
    int injectorSignals;
    int rwxMappings;
    int selinuxPermissive;
    int libunityHashMismatch;
    int score;
};

static void digest_to_hex(const u8 digest[32], char out[65]) {

    static const char* digits = "0123456789abcdef";

    for (int i = 0; i < 32; ++i) {
        out[i * 2] = digits[digest[i] >> 4];
        out[i * 2 + 1] = digits[digest[i] & 15];
    }
    out[64] = 0;
}

static bool hash_file_sha256(const char* path, char out[65]) {
    int fd = open(path, kOpenReadOnly | kOpenCloseOnExec);
    if (fd < 0)
        return false;
    Sha256Context ctx{};
    sha256_init(ctx);
    u8 buffer[32768];
    for (;;) {
        isize count = read(fd, buffer, sizeof(buffer));
        if (count < 0) {
            close(fd);
            return false;
        }
        if (!count)
            break;
        sha256_update(ctx, buffer, (usize)count);
    }
    close(fd);
    u8 digest[32];
    sha256_final(ctx, digest);
    digest_to_hex(digest, out);
    return true;
}

static bool find_libunity_path(char* out, usize capacity) {
    if (!out || capacity < 2)
        return false;
    out[0] = 0;
    FsFile* file = fopen("/proc/self/maps", "r");
    if (!file)
        return false;
    char line[1400];
    bool ok = false;
    while (fgets(line, sizeof(line), file)) {
        if (!strstr(line, "libunity.so"))
            continue;
        char* slash = line;
        while (*slash && *slash != '/')
            ++slash;
        if (!*slash)
            continue;
        char* end = slash + strlen(slash);
        while (end > slash && (end[-1] == '\n' || end[-1] == '\r' || end[-1] == ' ' || end[-1] == '\t'))
            --end;
        *end = 0;
        copy_string(out, capacity, slash);
        ok = true;
        break;
    }
    fclose(file);
    return ok;
}

static volatile int g_libunity_integrity_state = 0;
static void verify_libunity_once() {
    if (__atomic_load_n(&g_libunity_integrity_state, __ATOMIC_ACQUIRE) != 0 || !g_unity_base)
        return;
    char path[768]{}, actual[65]{};
    static const char expected[] = "750a14ace8a6506fa291c1715407f9052901392d7f34443c36ab9bd14f984862";
    int state = 3;
    if (find_libunity_path(path, sizeof(path)) && hash_file_sha256(path, actual))
        state = (strcmp(actual, expected) == 0) ? 1 : 2;
    __atomic_store_n(&g_libunity_integrity_state, state, __ATOMIC_RELEASE);
}

static bool file_exists(const char* path) {
    int fd = open(path, kOpenReadOnly | kOpenCloseOnExec);
    if (fd < 0)
        return false;
    close(fd);
    return true;
}

static int read_tracer_pid() {
    FsFile* file = fopen("/proc/self/status", "r");
    if (!file)
        return 0;
    char line[256];
    int pid = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "TracerPid:", 10) == 0) {
            pid = atoi(line + 10);
            break;
        }
    }
    fclose(file);
    return pid;
}

static int is_selinux_permissive() {
    char buffer[16]{};
    usize count = 0;
    if (!read_small_file("/sys/fs/selinux/enforce", buffer, sizeof(buffer), &count) || !count)
        return 0;
    return buffer[0] == '0' ? 1 : 0;
}
// skip module nahuy
static void scan_integrity_mappings(IntegrityVerdict* verdict) {
    if (!verdict)
        return;
    FsFile* file = fopen("/proc/self/maps", "r");
    if (!file)
        return;
    char payloadMarker[16]{}, reconnectMarker[32]{};
    runtime_payload_marker(payloadMarker);
    runtime_reconnect_marker(reconnectMarker);
    char line[1400];
    while (fgets(line, sizeof(line), file)) {
        const bool own = strstr(line, "libpayload.so") || strstr(line, payloadMarker) || strstr(line, reconnectMarker) ||
                         strstr(line, "dobby") || strstr(line, "Dobby");
        if (own)
            continue;

        const bool framework = strstr(line, "frida") || strstr(line, "gum-js-loop") || strstr(line, "xposed") ||
                               strstr(line, "lsposed") || strstr(line, "zygisk") || strstr(line, "riru") ||
                               strstr(line, "substrate");
        const bool injector = strstr(line, "frida-gadget") || strstr(line, "frida-agent") ||
                              strstr(line, "memfd:frida") || strstr(line, "linjector") || strstr(line, "libinject") ||
                              strstr(line, "injector.so");

        if (framework)
            ++verdict->frameworkSignals;
        if (injector)
            ++verdict->injectorSignals;

        if (strstr(line, "rwxp"))
            ++verdict->rwxMappings;
    }
    fclose(file);
    wipe_memory(payloadMarker, sizeof(payloadMarker));
    wipe_memory(reconnectMarker, sizeof(reconnectMarker));
}

static IntegrityVerdict scan_integrity() {
    IntegrityVerdict verdict{};
    const char* rootPaths[] = {"/system/bin/su",         "/system/xbin/su", "/sbin/su",     "/su/bin/su",
                               "/data/adb/magisk",       "/data/adb/ksu",   "/data/adb/ap", "/data/adb/modules",
                               "/debug_ramdisk/.magisk", "/sbin/.magisk",   "/metadata/adb"};
    for (usize i = 0; i < sizeof(rootPaths) / sizeof(rootPaths[0]); ++i)
        if (file_exists(rootPaths[i]))
            ++verdict.rootSignals;
    verdict.tracerPid = read_tracer_pid();
    const char* emuPaths[] = {"/dev/qemu_pipe", "/dev/socket/qemud", "/system/lib64/libhoudini.so"};
    for (usize i = 0; i < sizeof(emuPaths) / sizeof(emuPaths[0]); ++i)
        if (file_exists(emuPaths[i]))
            ++verdict.emulatorSignals;
    verdict.selinuxPermissive = is_selinux_permissive();
    scan_integrity_mappings(&verdict);
    verify_libunity_once();
    verdict.libunityHashMismatch = __atomic_load_n(&g_libunity_integrity_state, __ATOMIC_ACQUIRE) == 2 ? 1 : 0;

    const int rwxTelemetry = verdict.rwxMappings > 3 ? 2 : (verdict.rwxMappings > 0 ? 1 : 0);
    verdict.score = (verdict.rootSignals ? 2 : 0) + (verdict.tracerPid ? 4 : 0) + (verdict.emulatorSignals ? 1 : 0) +
              (verdict.frameworkSignals ? 4 : 0) + (verdict.injectorSignals ? 4 : 0) + rwxTelemetry +
              (verdict.selinuxPermissive ? 1 : 0) + (verdict.libunityHashMismatch ? 2 : 0);
    return verdict;
}

static volatile int g_ac_strong_streak = 0;

static bool has_tunnel_route() {
    static volatile const u8 ep[15] = {0xFE, 0x04, 0x54, 0x4E, 0x07, 0x17, 0x34, 0xF4,
                                       0x5C, 0xB5, 0x28, 0x7B, 0xA5, 0x7B, 0xA2};
    static volatile const u8 e0[3] = {0xCC, 0xB9, 0x32};
    static volatile const u8 e1[3] = {0xAF, 0xC9, 0xF9};
    static volatile const u8 e2[3] = {0x08, 0xA1, 0xB2};
    static volatile const u8 e3[2] = {0xA4, 0x05};
    static volatile const u8 e4[5] = {0xC3, 0x7F, 0x12, 0x46, 0x58};
    static volatile const u8 e5[3] = {0x64, 0x0A, 0xA1};
    char path[24]{}, p0[8]{}, p1[8]{}, p2[8]{}, p3[8]{}, p4[8]{}, p5[8]{};
    if (!decode_token(path, sizeof(path), ep, sizeof(ep), 0x51A7D391U))
        return false;
    decode_token(p0, sizeof(p0), e0, sizeof(e0), 0x1F234AB1U);
    decode_token(p1, sizeof(p1), e1, sizeof(e1), 0xE1039A77U);
    decode_token(p2, sizeof(p2), e2, sizeof(e2), 0x9A2F117CU);
    decode_token(p3, sizeof(p3), e3, sizeof(e3), 0x4317C2A9U);
    decode_token(p4, sizeof(p4), e4, sizeof(e4), 0xB9D04832U);
    decode_token(p5, sizeof(p5), e5, sizeof(e5), 0x0C2AF157U);
    FsFile* f = fopen(path, "r");
    wipe_memory(path, sizeof(path));
    if (!f) {
        wipe_memory(p0, sizeof(p0));
        wipe_memory(p1, sizeof(p1));
        wipe_memory(p2, sizeof(p2));
        wipe_memory(p3, sizeof(p3));
        wipe_memory(p4, sizeof(p4));
        wipe_memory(p5, sizeof(p5));
        return false;
    }
    bool hit = false;
    char line[512]{}, iface[64]{};
    while (fgets(line, sizeof(line), f)) {
        iface[0] = 0;
        if (sscanf(line, "%63s", iface) != 1)
            continue;
        if (strncmp(iface, p0, strlen(p0)) == 0 || strncmp(iface, p1, strlen(p1)) == 0 ||
            strncmp(iface, p2, strlen(p2)) == 0 || strncmp(iface, p3, strlen(p3)) == 0 ||
            strncmp(iface, p4, strlen(p4)) == 0 || strncmp(iface, p5, strlen(p5)) == 0) {
            hit = true;
            break;
        }
    }
    fclose(f);
    wipe_memory(iface, sizeof(iface));
    wipe_memory(line, sizeof(line));
    wipe_memory(p0, sizeof(p0));
    wipe_memory(p1, sizeof(p1));
    wipe_memory(p2, sizeof(p2));
    wipe_memory(p3, sizeof(p3));
    wipe_memory(p4, sizeof(p4));
    wipe_memory(p5, sizeof(p5));
    return hit;
}

static bool bootstrap_policy_allows() {
    if (!has_tunnel_route())
        return true;
    const IntegrityVerdict verdict = scan_integrity();
    const bool independentAnalysis = (verdict.tracerPid > 0) || (verdict.frameworkSignals > 0) ||
                                     (verdict.injectorSignals > 0);
    if (!independentAnalysis)
        return true;
    __atomic_store_n(&g_sensitive_bootstrap_blocked, 1, __ATOMIC_RELEASE);
    return false;
}

static bool is_strong_integrity_signal(const IntegrityVerdict& verdict) {
    if (verdict.injectorSignals > 0)
        return true;
    if (verdict.frameworkSignals > 0)
        return true;
    if (verdict.tracerPid > 0)
        return true;
    if (verdict.rootSignals >= 2 && verdict.selinuxPermissive > 0)
        return true;
    return false;
}

static bool run_integrity_check(bool startup) {
    if (!g_config.integrityEnabled)
        return true;
    IntegrityVerdict verdict = scan_integrity();
    const bool strong = is_strong_integrity_signal(verdict);

    if (!g_config.integrityEnforce || !strong) {
        __atomic_store_n(&g_ac_strong_streak, 0, __ATOMIC_RELEASE);
        return true;
    }

    if (startup) {
        __atomic_store_n(&g_ac_strong_streak, 0, __ATOMIC_RELEASE);
        return true;
    }

    const int streak = __atomic_add_fetch(&g_ac_strong_streak, 1, __ATOMIC_ACQ_REL);
    return streak < 2;
}

static void* integrity_monitor_thread(void*) {
    for (;;) {
        unsigned intervalSeconds = (unsigned)(g_config.integrityIntervalSec < 5 ? 15 : g_config.integrityIntervalSec);
        android_breathe(intervalSeconds * 1000000U);
        if (!run_integrity_check(false)) {
            _exit(173);
        }
    }
    return nullptr;
}

static void start_integrity_monitor() {
    if (!g_config.integrityEnabled)
        return;
    pthread_t thread = 0;
    if (pthread_create(&thread, nullptr, integrity_monitor_thread, nullptr) == 0)
        pthread_detach(thread);
}

static bool wait_for_unity() {
    uptr lastBase = 0;
    int stableSamples = 0;
    for (int i = 0; i < 6000; i++) {

        uptr base = find_library_base("libunity.so");
        if (base) {
            if (base == lastBase)
                ++stableSamples;
            else {
                lastBase = base;
                stableSamples = 1;
            }
            if (stableSamples >= 6) {
                g_unity_base = base;
                break;
            }
        }
        android_breathe(5000);
    }
    if (!g_unity_base) {
        return false;
    }
    return true;
}

static bool install_init_step_bootstrap_gate() {
    if (__atomic_load_n(&g_init_step_gate_armed, __ATOMIC_ACQUIRE))
        return g_original_init_step != nullptr;
    if (!is_executable_rva(kInitBoltExecuteStepRva)) {
        return false;
    }
    if (!install_bootstrap_hook(kInitBoltExecuteStepRva, hook_init_step, &g_original_init_step))
        return false;
    __atomic_store_n(&g_init_step_gate_armed, 1, __ATOMIC_RELEASE);
    return true;
}

static bool fetch_manifest_with_retry() {
    const i64 deadline = now_ms() + 60000LL;
    int localAttempt = 0;
    while (now_ms() < deadline) {
        ++localAttempt;
        if (fetch_manifest()) {
            return true;
        }
        unsigned int delayUs = localAttempt <= 5 ? 120000U : (localAttempt <= 15 ? 350000U : 800000U);
        android_breathe(delayUs);
    }
    return false;
}

static void* boot_worker(void*) {
    // startup main ne trogaem
    reset_config();
    run_integrity_check(true);

    if (!wait_for_unity()) {
        return nullptr;
    }

    if (!install_init_step_bootstrap_gate()) {
        return nullptr;
    }

    if (!bootstrap_policy_allows()) {

        return nullptr;

    }

    if (!fetch_manifest_with_retry()) {
        return nullptr;
    }
    if (!bolt_targets_ready()) {
        return nullptr;
    }
    if (!install_bolt_hooks()) {
        return nullptr;
    }

    start_integrity_monitor();
    __atomic_store_n(&g_bolt_core_ready, 1, __ATOMIC_RELEASE);

    g_config.photonPort = (i32)__atomic_load_n(&g_manifest_photon_port, __ATOMIC_ACQUIRE);
    if (g_config.photonPort <= 0)
        g_config.photonPort = 5055;

    install_photon_hooks();
    install_matchmaking_hooks();

    return nullptr;
}

static void start() {
    if (__atomic_exchange_n(&g_started, 1, __ATOMIC_ACQ_REL)) return;

    reset_config();

    pthread_t thread = 0;
    if (pthread_create(&thread, nullptr, boot_worker, nullptr) == 0) {
        pthread_detach(thread);
        return;
    }

    __atomic_store_n(&g_started, 0, __ATOMIC_RELEASE);
}

} //  033

extern "C" __attribute__((visibility("default"))) i32 JNI_OnLoad(void*, void*) {
    using namespace client033;
    start();
    return kJniVersion16;
}

