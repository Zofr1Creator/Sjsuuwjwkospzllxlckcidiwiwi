package androidx.appcompat.app;

import android.animation.*;
import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.*;
import android.view.View.*;
import android.content.res.AssetManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.StringBuilder;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.os.Build;
import android.text.Html;
import android.view.Window;
import android.widget.Toast;
import android.os.Process;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.app.Activity;
import java.util.Arrays;
import android.util.Log;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Process;
import android.text.Html;
import android.widget.Toast;
import java.io.File;
import java.util.List;
import java.net.NetworkInterface;
import java.nio.channels.NetworkChannel;
import android.net.NetworkInfo;
import android.animation.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.util.*;
import android.os.*;
import android.view.*;
import android.text.*;
import android.widget.*;
import android.app.AlertDialog;
import android.R;
import android.net.Uri;
import javax.security.auth.Destroyable;
import java.util.regex.MatchResult;
import android.transition.AutoTransition;
import java.io.UnsupportedEncodingException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.io.BufferedReader;
import android.content.Intent;

public class WrapperActivity extends Activity {
    protected static native void getContext(Context var0);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.loadLibrary("StandRise");
        
        
    }
    public static void openURL(Context cx, String url)
    {
        Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        cx.startActivity(browser);
    }
}
