@echo off
setlocal
cd /d "%~dp0"

echo Cleaning...
if exist bin rmdir /s /q bin
if exist obj rmdir /s /q obj

where dotnet >nul 2>&1
if errorlevel 1 (
    echo .NET 8 SDK not found.
    pause
    exit /b 1
)

echo Restoring packages...
dotnet restore TspServer.csproj --nologo
if errorlevel 1 goto build_failed

echo Building Release...
dotnet build TspServer.csproj -c Release --no-restore --nologo
if errorlevel 1 goto build_failed

if not exist "certs\server.pfx" (
    echo Creating local certificate...
    powershell -NoProfile -ExecutionPolicy Bypass ^
        -File "scripts\create-certificate.ps1" ^
        -OutputPath "%CD%\certs\server.pfx" ^
        -Password "local-dev"

    if errorlevel 1 goto build_failed
)

echo.
echo Build OK.
pause
exit /b 0

:build_failed
echo.
echo Build failed.
pause
exit /b 1