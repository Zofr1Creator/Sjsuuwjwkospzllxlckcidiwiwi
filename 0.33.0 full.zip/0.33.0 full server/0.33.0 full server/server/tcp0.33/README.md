Короче это фулл серверная часть StandLine 0.33.0

В архиве лежит все основное что нужно для запуска: сервер, cpp часть и база, большая часть настроек вынесена в serverconfig.json, так что ебаться с переменными среды для обычного запуска не надо

перед первым запуском просто открой serverconfig.json и проверь несколько вещей:

по дефолту стоит mongodb://127.0.0.1:2077
tls.certificate путь до PFX
tls.password пароль от PFX
manifestPort, boltPort, photonPort порты

В архиве уже лежит сертификат
certs/server.pfx

Пароль:

server033

SHA1:

3433A3DDCCF5268E6D2CA7BED71B5AF1624D3010

Google тоже настраивается через serverconfig.json, блок google.

Там:

webClientId — OAuth Web Client ID

webClientSecret — OAuth Web Client Secret

tokenEndpoint — не трогать

Запуск простой:

поднимаешь бд с папки на 2077
проверяешь serverconfig.json
запускаешь startserver.bat

сливаю как есть дальше уже разбирайтесь сами, фиксите, форкайте, делайте свои проекты мне похуй ахахха

Автор: секрет

Telegram: t.me/Standlinee