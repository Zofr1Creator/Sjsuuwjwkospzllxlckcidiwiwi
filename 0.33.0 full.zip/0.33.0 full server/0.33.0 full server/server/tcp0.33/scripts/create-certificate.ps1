param(
    [string]$DnsName = 'server.boltgaming.io',
    [string]$OutputPath = "$PSScriptRoot\..\certs\server.pfx",
    [string]$Password = 'local-dev'
)

$ErrorActionPreference = 'Stop'

$directory = Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Force -Path $directory | Out-Null

$certificate = New-SelfSignedCertificate `
    -DnsName $DnsName `
    -CertStoreLocation 'cert:\CurrentUser\My' `
    -KeyAlgorithm RSA `
    -KeyLength 2048 `
    -HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
    -NotAfter (Get-Date).AddYears(5)

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
Export-PfxCertificate `
    -Cert $certificate `
    -FilePath $OutputPath `
    -Password $securePassword | Out-Null

