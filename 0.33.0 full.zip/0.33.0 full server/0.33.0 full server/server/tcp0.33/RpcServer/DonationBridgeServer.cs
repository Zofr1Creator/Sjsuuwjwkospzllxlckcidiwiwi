using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.RpcServer.Api;

namespace TspServer.RpcServer
{

    internal static class DonationBridgeServer
    {
        private const string GrantCollection = "donation_grants";
        private static readonly ConcurrentDictionary<string, object> OrderLocks = new(StringComparer.Ordinal);
        private static TcpListener _listener;
        private static int _started;
         private static string _secret = string.Empty;
       private static bool _allowRemote;

        public static void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0) return;
           if (!ReadBool("BOLT_DONATION_BRIDGE_ENABLED", false))
           {
                return;
            }

            _secret = (Environment.GetEnvironmentVariable("BOLT_DONATION_BRIDGE_SECRET") ?? string.Empty).Trim();
            if (_secret.Length < 24)
            {
                return;
            }

            _allowRemote = ReadBool("BOLT_DONATION_BRIDGE_ALLOW_REMOTE", false);
            string host = (Environment.GetEnvironmentVariable("BOLT_DONATION_BRIDGE_HOST") ?? "127.0.0.1").Trim();
            int port = ReadInt("BOLT_DONATION_BRIDGE_PORT", 2245);
            IPAddress address = host == "0.0.0.0" ? IPAddress.Any : IPAddress.Parse(host);
           _listener = new TcpListener(address, port);
            _listener.Start(64);
            _ = Task.Run(AcceptLoopAsync);
        }

        private static IMongoCollection<BsonDocument> Collection =>
            BoltGameDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>(GrantCollection);

        private static async Task AcceptLoopAsync()
        {
            while (_listener != null)
            {
                TcpClient client = null;
                try
                {
                    client = await _listener.AcceptTcpClientAsync().ConfigureAwait(false);
                    _ = Task.Run(() => Handle(client));
               }
                catch (ObjectDisposedException) { return; }
                catch (System.Exception)
                {
                    client?.Dispose();
                    await Task.Delay(100).ConfigureAwait(false);
                }
            }
        }

        private static void Handle(TcpClient client)
        {
            using (client)
            using (NetworkStream stream = client.GetStream())
            {
                stream.ReadTimeout = 5000; stream.WriteTimeout = 5000;
                IPEndPoint remote = client.Client.RemoteEndPoint as IPEndPoint;
                if (!_allowRemote && remote != null && !IPAddress.IsLoopback(remote.Address))
                {
                    WriteJson(stream, 403, new { ok = false, error = "loopback only" }); return;
                }

                string requestLine = ReadLine(stream, 4096);
                if (string.IsNullOrWhiteSpace(requestLine)) return;
                string[] first = requestLine.Split(' ');
                if (first.Length < 2) { WriteJson(stream, 400, new { ok = false, error = "bad request" }); return; }
                 string method = first[0].ToUpperInvariant();
                string path = first[1].Split('?')[0];

                int contentLength = 0; string authorization = string.Empty;
               for (int i = 0; i < 64; i++)
                 {
                     string line = ReadLine(stream, 8192);
                    if (line == null || line.Length == 0) break;
                    int colon = line.IndexOf(':'); if (colon <= 0) continue;
                    string name = line.Substring(0, colon).Trim(); string value = line.Substring(colon + 1).Trim();
                    if (name.Equals("Content-Length", StringComparison.OrdinalIgnoreCase)) int.TryParse(value, out contentLength);
                    else if (name.Equals("Authorization", StringComparison.OrdinalIgnoreCase)) authorization = value;
                }

                if (method == "GET" && path == "/donation/health")
                {
                    WriteJson(stream, 200, new { ok = true, service = "donation-bridge", utc = DateTime.UtcNow }); return;
                }
                if (method == "GET" && path == "/donation/admin/stats")
                {
                    if (!AuthOk(authorization)) { WriteJson(stream, 401, new { ok = false, error = "unauthorized" }); return; }
                    WriteJson(stream, 200, BuildAdminStats()); return;
                }
                if (method != "POST" || path != "/donation/grant")
                {
                    WriteJson(stream, 404, new { ok = false, error = "not found" }); return;
                 }
                if (!AuthOk(authorization)) { WriteJson(stream, 401, new { ok = false, error = "unauthorized" }); return; }
                if (contentLength <= 0 || contentLength > 65536) { WriteJson(stream, 413, new { ok = false, error = "invalid body size" }); return; }

                byte[] body = ReadExact(stream, contentLength);
                try
                {
                    DonationRequest request = JsonSerializer.Deserialize<DonationRequest>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    DonationResult result = Process(request);
                    WriteJson(stream, result.Ok ? 200 : 400, result);
                }
                catch (System.Exception ex)
                 {
                    WriteJson(stream, 500, new { ok = false, error = ex.Message });
                }
            }
        }

        private static object BuildAdminStats()
        {
            string[] boltOnlinePlayers;
            int boltConnections;
            lock (ServerState.UsersLock)
            {
                boltConnections = ServerState.Users.Count;
                boltOnlinePlayers = ServerState.Users.Values
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();
             }

           Dictionary<string, PlayerStatus> statusSnapshot = ServerState.GetPlayerStatusSnapshots();
            string[] presenceOnlinePlayers = statusSnapshot
                .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) && pair.Value != null)
               .Where(pair =>
                {
                    PlayerStatus status = pair.Value;
                    bool hasGamePresence = status.playInGame != null &&
                        (!string.IsNullOrWhiteSpace(status.playInGame.lobbyId) || status.playInGame.photonGame != null);
                    return status.onlineStatus != PlayerStatus.OnlineStatus.StateOffline || hasGamePresence;
                })
                .Select(pair => pair.Key)
                .Distinct(StringComparer.Ordinal)
                .ToArray();

            string[] onlinePlayers = boltOnlinePlayers
                .Concat(presenceOnlinePlayers)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.Ordinal)
                .ToArray();
            int lobbyCount;
            int lobbyMembers;
            int lobbySpectators;
            object[] lobbyDetails;
             lock (ServerState.Lobbies)
            {
                var snapshot = ServerState.Lobbies.Values.Where(x => x != null).ToArray();
                lobbyCount = snapshot.Length;
                lobbyMembers = snapshot.Sum(x => x.LobbyMembers?.Length ?? 0);
                lobbySpectators = snapshot.Sum(x => x.LobbySpectators?.Length ?? 0);
                lobbyDetails = snapshot
                    .OrderByDescending(x => (x.LobbyMembers?.Length ?? 0) + (x.LobbySpectators?.Length ?? 0))
                    .Take(100)
                    .Select(x =>
                    {
                         string mode = string.Empty;
                        string map = string.Empty;
                        try
                        {
                            if (x.Data != null)
                            {
                                if (!x.Data.TryGetValue("mode", out mode))
                                   x.Data.TryGetValue("gameMode", out mode);
                                x.Data.TryGetValue("map", out map);
                            }
                        }
                        catch { }
                        return (object)new
                        {
                            lobbyId = x.Id ?? string.Empty,
                           name = x.Name ?? string.Empty,
                            type = x.Type.ToString(),
                           members = x.LobbyMembers?.Length ?? 0,
                            spectators = x.LobbySpectators?.Length ?? 0,
                            maxMembers = x.MaxMembers,
                            maxSpectators = x.MaxSpectators,
                             joinable = x.Joinable,
                             mode = mode ?? string.Empty,
                            map = map ?? string.Empty,
                            hasGameServer = x.GameServer != null
                        };
                    })
                   .ToArray();
            }

            var presence = onlinePlayers.Select(playerId =>
            {
                PlayerStatus status = ServerState.GetPlayerStatusSnapshot(playerId);
                string lobbyId = status?.playInGame?.lobbyId ?? string.Empty;
                PhotonGame game = status?.playInGame?.photonGame;
                string roomId = game?.roomId ?? string.Empty;
                 string mode = string.Empty;
                if (game?.customProperties != null)
                {
                    if (!game.customProperties.TryGetValue("mode", out mode))
                        game.customProperties.TryGetValue("gameMode", out mode);
                }
                mode = (mode ?? string.Empty).Trim();
                 if (mode.Length == 0 && roomId.StartsWith("Ranked2v2", StringComparison.OrdinalIgnoreCase))
                    mode = "Ranked2v2";
                if (mode.Length == 0 && roomId.StartsWith("RankedDuel", StringComparison.OrdinalIgnoreCase))
                    mode = "RankedDuel";
                if (mode.Length == 0 && (roomId.StartsWith("RankedDefuse", StringComparison.OrdinalIgnoreCase) ||
                                         roomId.StartsWith("Ranked5v5", StringComparison.OrdinalIgnoreCase)))
                    mode = "RankedDefuse";
                if (mode.Length == 0 && roomId.StartsWith("Ranked", StringComparison.OrdinalIgnoreCase))
                    mode = "Ranked";
                if (mode.Length == 0 && roomId.StartsWith("Duel", StringComparison.OrdinalIgnoreCase))
                    mode = "Duel";
                 if (mode.Length == 0 && !string.IsNullOrWhiteSpace(roomId))
                    mode = "Unknown";
                return new
                {
                   playerId,
                    lobbyId,
                    roomId,
                    mode,
                    region = game?.region ?? string.Empty,
                    appVersion = game?.appVersion ?? string.Empty
                };
            }).ToArray();

            int inGame = presence.Count(x => !string.IsNullOrWhiteSpace(x.roomId));
            int inLobby = presence.Count(x => !string.IsNullOrWhiteSpace(x.lobbyId));
            int lobbyOnly = presence.Count(x => !string.IsNullOrWhiteSpace(x.lobbyId) && string.IsNullOrWhiteSpace(x.roomId));
            int inMenu = Math.Max(0, onlinePlayers.Length - inGame - lobbyOnly);
            int rankedInGame = presence.Count(x =>
                !string.IsNullOrWhiteSpace(x.roomId) &&
                (x.mode.StartsWith("Ranked", StringComparison.OrdinalIgnoreCase) ||
                 x.roomId.StartsWith("Ranked", StringComparison.OrdinalIgnoreCase)));

            int CapacityForMode(string mode)
            {
                string value = (mode ?? string.Empty).Replace("_", string.Empty).Replace("-", string.Empty).Replace(" ", string.Empty).ToLowerInvariant();
                if (value.Contains("5v5") || value.Contains("rankeddefuse")) return 10;
                if (value.Contains("2v2")) return 4;
                if (value.Contains("duel") || value == "1v1") return 2;
               return 0;
            }

            var rooms = presence
                .Where(x => !string.IsNullOrWhiteSpace(x.roomId))
                .GroupBy(x => x.roomId, StringComparer.Ordinal)
                .Select(g =>
                {
                    string mode = g.Select(x => x.mode).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x) && x != "Unknown")
                        ?? g.First().mode ?? "Unknown";
                    string region = g.Select(x => x.region).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? string.Empty;
                     string appVersion = g.Select(x => x.appVersion).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? string.Empty;
                    return new
                    {
                        roomId = g.Key,
                        mode,
                        players = g.Count(),
                        maxPlayers = CapacityForMode(mode),
                        region,
                        appVersion
                    };
                })
               .OrderByDescending(x => x.players)
                .ThenBy(x => x.mode, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.roomId, StringComparer.Ordinal)
                .Take(250)
               .ToArray();

            var modes = presence
                .Where(x => !string.IsNullOrWhiteSpace(x.roomId))
                .GroupBy(x => string.IsNullOrWhiteSpace(x.mode) ? "Unknown" : x.mode, StringComparer.OrdinalIgnoreCase)
                .Select(g => new
                 {
                    mode = g.Key,
                    players = g.Count(),
                   rooms = g.Select(x => x.roomId).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).Count()
                })
                .OrderByDescending(x => x.players)
                .ThenBy(x => x.mode, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            int gameServerConnections;
            lock (ServerState.GameServerUsers) gameServerConnections = ServerState.GameServerUsers.Count;

            return new
            {
                 ok = true,
                utc = DateTime.UtcNow,
                playersOnline = onlinePlayers.Length,
                boltPlayersOnline = boltOnlinePlayers.Length,
               presencePlayersOnline = presenceOnlinePlayers.Length,
                boltConnections,
                playersInMenu = inMenu,
                playersInLobby = inLobby,
                playersLobbyOnly = lobbyOnly,
                playersInGame = inGame,
                rankedPlayersInGame = rankedInGame,
                activeRooms = rooms.Length,
                rooms,
               modes,
                lobbies = lobbyCount,
                lobbyMembers,
                lobbySpectators,
                lobbyDetails,
                gameServerConnections
            };
        }

        private static DonationResult Process(DonationRequest r)
        {
            if (r == null || string.IsNullOrWhiteSpace(r.OrderId) || r.OrderId.Length > 80)
                return DonationResult.Fail("bad orderId");
            if (!ObjectId.TryParse(r.PlayerId, out ObjectId playerObjectId))
                return DonationResult.Fail("bad playerId");
            if (r.Reward == null || string.IsNullOrWhiteSpace(r.Reward.Type))
                return DonationResult.Fail("missing reward");

            object gate = OrderLocks.GetOrAdd(r.OrderId, _ => new());
            lock (gate)
            {
                try
               {
                    BsonDocument existing = Collection.Find(Builders<BsonDocument>.Filter.Eq("_id", r.OrderId)).FirstOrDefault();
                    if (existing != null)
                   {
                        string status = existing.GetValue("status", "").AsString;
                        if (status == "completed")
                        {
                            return DonationResult.SuccessVerified(
                                r.OrderId,
                                true,
                                "already completed",
                                existing.GetValue("amount", 0).ToInt32(),
                                existing.GetValue("balanceBefore", 0).ToDouble(),
                                existing.GetValue("balanceAfter", 0).ToDouble(),
                                existing.GetValue("verified", false).ToBoolean());
                        }
                        return DonationResult.Fail("order is already reserved with status=" + status);
                   }

                    try
                    {
                        Collection.InsertOne(new BsonDocument {
                            { "_id", r.OrderId }, { "playerId", r.PlayerId }, { "rewardType", r.Reward.Type },
                            { "status", "granting" }, { "createdAt", DateTime.UtcNow }
                        });
                    }
                    catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
                    {
                        return DonationResult.Success(r.OrderId, true, "duplicate order");
                    }

                    DonationResult result = ExecuteGrant(r, playerObjectId);
                    if (result.Ok)
                    {
                        var completedUpdate = Builders<BsonDocument>.Update
                            .Set("status", "completed")
                            .Set("completedAt", DateTime.UtcNow)
                            .Set("result", result.Message ?? "ok")
                            .Set("verified", result.Verified)
                            .Set("amount", result.Amount)
                            .Set("balanceBefore", result.BalanceBefore)
                            .Set("balanceAfter", result.BalanceAfter);
                        Collection.UpdateOne(
                            Builders<BsonDocument>.Filter.Eq("_id", r.OrderId),
                            completedUpdate);
                    }
                    else
                    {
                         Collection.UpdateOne(Builders<BsonDocument>.Filter.Eq("_id", r.OrderId),
                            Builders<BsonDocument>.Update.Set("status", "failed-review").Set("error", result.Error ?? "unknown").Set("failedAt", DateTime.UtcNow));
                    }
                    return result;
                }
                finally { OrderLocks.TryRemove(r.OrderId, out _); }
             }
        }

        private static DonationResult ExecuteGrant(DonationRequest r, ObjectId playerObjectId)
        {
            string type = r.Reward.Type.Trim().ToLowerInvariant();
            switch (type)
            {
                case "gold":
                    {
                        int amount = Math.Clamp(r.Reward.Amount, 1, 1_000_000);
                        var inventoryCol = BoltGameDatabaseProvider.Instance.GetDatabase()
                            .GetCollection<BsonDocument>(InventoryCatalog.PlayerInventoryCollection);
                        var filter = Builders<BsonDocument>.Filter.Eq("playerId", r.PlayerId);
                        string currencyPath = "Currencies.102";

                       BsonDocument beforeDoc = inventoryCol.FindOneAndUpdate(
                             filter,
                            Builders<BsonDocument>.Update.Inc(currencyPath, (double)amount),
                            new FindOneAndUpdateOptions<BsonDocument>
                            {
                                ReturnDocument = ReturnDocument.Before
                            });

                        if (beforeDoc == null)
                            return DonationResult.Fail("player inventory not found");

                        double before = ReadCurrencyV2(beforeDoc, 102);
                        BsonDocument afterDoc = inventoryCol.Find(filter).FirstOrDefault();
                        if (afterDoc == null)
                            return DonationResult.Fail("player inventory disappeared after grant");

                        double after = ReadCurrencyV2(afterDoc, 102);
                        double expected = before + amount;

                        if (after + 0.0001 < expected)
                        {
                            return DonationResult.Fail(
                                $"gold write verification failed before={before} after={after} expected={expected}");
                        }

                        var rewardEvent = new Reward();
                        rewardEvent.Currencies.Add(new CurrencyAmount
                       {
                            CurrencyId = 102,
                            OldValue = (int)Math.Clamp(before, int.MinValue, int.MaxValue),
                            Value = amount
                        });
                         InventoryEventBus.InventoryChanged(
                            r.PlayerId,
                            currencies: rewardEvent.Currencies,
                             source: "donation-gold-verified");


                        return DonationResult.SuccessVerified(
                            r.OrderId, false, $"gold={amount}", amount, before, after);
                    }
                case "item":
                    {
                        int definitionId = r.Reward.DefinitionId; int quantity = Math.Clamp(r.Reward.Quantity <= 0 ? 1 : r.Reward.Quantity, 1, 100);
                        BsonDocument def = BoltGameDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("inventory_items")
                            .Find(Builders<BsonDocument>.Filter.Eq("key", definitionId) & Builders<BsonDocument>.Filter.Eq("enabled", true)).FirstOrDefault();
                        if (def == null) return DonationResult.Fail("item definition not found/enabled");
                        var info = new RewardInfo(); info.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = definitionId, Value = quantity });
                        Reward granted = BattlePassRuntime.GrantRewardInfo(r.PlayerId, info);
                        InventoryEventBus.InventoryChanged(r.PlayerId, added: granted.Items, source: "donation-item");
                        return DonationResult.Success(r.OrderId, false, $"item={definitionId}x{quantity}");
                    }
                case "gold_pass":
                    {
                        BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                       int passId = definition.GoldPassItemDefinitionId > 0 ? definition.GoldPassItemDefinitionId : BattlePassRuntime.FallbackGoldPassItemDefinitionId;
                        if (BattlePassRuntime.OwnsInventoryDefinition(r.PlayerId, passId))
                            return DonationResult.Success(r.OrderId, false, "gold pass already owned");
                        var info = new RewardInfo(); info.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = passId, Value = 1 });
                       Reward pass = BattlePassRuntime.GrantRewardInfo(r.PlayerId, info);
                        Reward pending;
                        lock (BattlePassRuntime.LockForPlayer(r.PlayerId))
                       {
                            BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(r.PlayerId, definition);
                            pending = BattlePassRuntime.ApplyPendingPassRewards(r.PlayerId, definition, state);
                            BattlePassRuntime.SaveState(state);
                        }
                        InventoryEventBus.InventoryChanged(r.PlayerId, added: pass.Items.Concat(pending.Items), currencies: pending.Currencies, source: "donation-gold-pass");
                        GameEventRemoteService.SendPassChanged(r.PlayerId, pending);
                        return DonationResult.Success(r.OrderId, false, $"goldPass={passId}");
                    }
                case "bp_levels":
                    {
                        int levels = Math.Clamp(r.Reward.Levels, 1, 100);
                        BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                        Reward pending; int total;
                        lock (BattlePassRuntime.LockForPlayer(r.PlayerId))
                        {
                            BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(r.PlayerId, definition);
                            total = BattlePassRuntime.AddEventPoints(state, checked(levels * BattlePassRuntime.PreyPointsPerLevel));
                            pending = BattlePassRuntime.ApplyPendingPassRewards(r.PlayerId, definition, state);
                            BattlePassRuntime.SaveState(state);
                         }
                        InventoryEventBus.InventoryChanged(r.PlayerId, added: pending.Items, currencies: pending.Currencies, source: "donation-bp-levels");
                        GameEventRemoteService.SendPassChanged(r.PlayerId, pending);
                        return DonationResult.Success(r.OrderId, false, $"bpLevels={levels};points={total}");
                   }
                default: return DonationResult.Fail("unsupported reward type");
            }
        }

        private static double ReadCurrencyV2(BsonDocument inventory, int currencyId)
        {
            if (inventory == null) return 0d;
            if (!inventory.TryGetValue("Currencies", out BsonValue currenciesRaw) ||
                !currenciesRaw.IsBsonDocument)
                return 0d;

            BsonDocument currencies = currenciesRaw.AsBsonDocument;
            if (!currencies.TryGetValue(currencyId.ToString(), out BsonValue value) ||
                value == null || value.IsBsonNull)
                return 0d;

            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsDouble) return value.AsDouble;
            if (value.IsDecimal128) return (double)value.AsDecimal128;
            if (value.IsString &&
                double.TryParse(
                    value.AsString,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out double parsed))
                return parsed;
            return 0d;
        }

        private static bool AuthOk(string header)
        {
             const string bearerPrefix = "Bearer ";
             if (string.IsNullOrWhiteSpace(header) ||
                !header.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase))
             {
                return false;
            }

            string token = header[bearerPrefix.Length..].Trim();
            byte[] suppliedHash = SHA256.HashData(Encoding.UTF8.GetBytes(token));
            byte[] expectedHash = SHA256.HashData(Encoding.UTF8.GetBytes(_secret));
            return CryptographicOperations.FixedTimeEquals(suppliedHash, expectedHash);
        }

       private static string ReadLine(NetworkStream stream, int maxLength)
        {
            using var buffer = new MemoryStream();
            int previous = -1;

            for (int i = 0; i < maxLength; i++)
            {
                int current = stream.ReadByte();
                if (current < 0)
                   break;

                if (previous == '\r' && current == '\n')
                   break;

                if (previous >= 0)
                    buffer.WriteByte((byte)previous);

                previous = current;
           }

            return Encoding.ASCII.GetString(buffer.ToArray()).TrimEnd('\r');
        }

        private static byte[] ReadExact(NetworkStream stream, int count)
        {
            var buffer = new byte[count];
            int offset = 0;

            while (offset < count)
            {
                int read = stream.Read(buffer, offset, count - offset);
                if (read <= 0)
                    throw new EndOfStreamException();

                offset += read;
             }

            return buffer;
        }

        private static void WriteJson(NetworkStream stream, int statusCode, object value)
        {
            byte[] body = JsonSerializer.SerializeToUtf8Bytes(
                value,
                new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

             string reason = statusCode == 200 ? "OK" : "Error";
            string header =
                $"HTTP/1.1 {statusCode} {reason}\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                $"Content-Length: {body.Length}\r\n" +
                "Connection: close\r\n" +
                "Cache-Control: no-store\r\n\r\n";

            byte[] headerBytes = Encoding.ASCII.GetBytes(header);
            stream.Write(headerBytes);
            stream.Write(body);
        }

        private static bool ReadBool(string key, bool fallback)
        {
            string? raw = Environment.GetEnvironmentVariable(key);
            if (string.IsNullOrWhiteSpace(raw))
                return fallback;

            return raw.Equals("1", StringComparison.OrdinalIgnoreCase) ||
                    raw.Equals("true", StringComparison.OrdinalIgnoreCase) ||
                   raw.Equals("yes", StringComparison.OrdinalIgnoreCase) ||
                   raw.Equals("on", StringComparison.OrdinalIgnoreCase);
        }

        private static int ReadInt(string key, int fallback)
        {
            return int.TryParse(Environment.GetEnvironmentVariable(key), out int value)
                ? value
                : fallback;
        }

       private sealed class DonationRequest
        {
            public string OrderId { get; set; } = string.Empty;
            public string PlayerId { get; set; } = string.Empty;
           public DonationReward Reward { get; set; } = new();
        }

        private sealed class DonationReward
        {
            public string Type { get; set; } = string.Empty;
            public int Amount { get; set; }
            public int DefinitionId { get; set; }
            public int Quantity { get; set; }
            public int Levels { get; set; }
        }

        private sealed class DonationResult
        {
            public bool Ok { get; set; }
            public bool Duplicate { get; set; }
            public string OrderId { get; set; }
            public string Message { get; set; }
            public string Error { get; set; }
            public bool Verified { get; set; }
            public int Amount { get; set; }
            public double BalanceBefore { get; set; }
            public double BalanceAfter { get; set; }

            public static DonationResult Success(string id, bool duplicate, string message) =>
                new() { Ok = true, Duplicate = duplicate, OrderId = id, Message = message };

            public static DonationResult SuccessVerified(
               string id,
                bool duplicate,
                string message,
                int amount,
                double before,
                double after,
                bool verified = true) =>
                new()
                {
                    Ok = true,
                    Duplicate = duplicate,
                    OrderId = id,
                    Message = message,
                    Verified = verified,
                    Amount = amount,
                    BalanceBefore = before,
                    BalanceAfter = after
                 };

            public static DonationResult Fail(string error) =>
                new() { Ok = false, Error = error };
        }
   }
}
