using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace TspServer.RpcServer
{
    public enum WireEncoding
    {
        Plain = 0,
        BootstrapAes = 1,
        SessionAes = 2
    }

     public static class Protocol
    {
        public static readonly byte[] BootstrapKey = Encoding.ASCII.GetBytes("key_abcdefghijkl");
        public static readonly byte[] BootstrapIv = Encoding.ASCII.GetBytes("iv_abcdefghijklm");
         public static readonly byte[] StandardRsaPublicExponent = new byte[] { 0x01, 0x00, 0x01 };

        public static byte[] GetBinaryValueBytes(BinaryValue value)
       {
            if (value == null)
                return Array.Empty<byte>();

            if (value.One != null && value.One.Length > 0)
                return value.One.ToByteArray();

            if (value.Array != null && value.Array.Count > 0 && value.Array[0] != null)
                return value.Array[0].ToByteArray();

            return Array.Empty<byte>();
        }

        public static byte[] EncryptAesCbc(byte[] plain, byte[] key, byte[] iv)
        {
            if (plain == null) throw new ArgumentNullException(nameof(plain));
            ValidateAes(key, iv);

            using Aes aes = Aes.Create();
            aes.KeySize = 128;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = key;
             aes.IV = iv;

            using ICryptoTransform encryptor = aes.CreateEncryptor();
            return encryptor.TransformFinalBlock(plain, 0, plain.Length);
        }

        public static byte[] DecryptAesCbc(byte[] cipher, byte[] key, byte[] iv)
        {
            if (cipher == null) throw new ArgumentNullException(nameof(cipher));
            ValidateAes(key, iv);
            if (cipher.Length == 0 || cipher.Length % 16 != 0)
                throw new CryptographicException($"AES-CBC payload length is invalid: {cipher.Length}");

            using Aes aes = Aes.Create();
           aes.KeySize = 128;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = key;
            aes.IV = iv;

            using ICryptoTransform decryptor = aes.CreateDecryptor();
            return decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
        }

        public static bool TryDecryptAesCbc(byte[] cipher, byte[] key, byte[] iv, out byte[] plain)
        {
            try
            {
                plain = DecryptAesCbc(cipher, key, iv);
                return true;
            }
            catch
            {
                plain = Array.Empty<byte>();
               return false;
            }
        }

        public static bool TryReadLengthDelimitedFields(
            byte[] payload,
            out Dictionary<int, byte[]> fields,
             out string error)
        {
            fields = new Dictionary<int, byte[]>();
           error = null;

            try
            {
                CodedInputStream input = new CodedInputStream(payload ?? Array.Empty<byte>());
                uint tag;
                while ((tag = input.ReadTag()) != 0)
                {
                    int field = WireFormat.GetTagFieldNumber(tag);
                   WireFormat.WireType wire = WireFormat.GetTagWireType(tag);
                    if (wire == WireFormat.WireType.LengthDelimited)
                    {
                        fields[field] = input.ReadBytes().ToByteArray();
                    }
                    else
                    {
                        input.SkipLastField();
                    }
                }

                return true;
            }
            catch (System.Exception ex)
            {
                error = $"{ex.GetType().Name}: {ex.Message}";
                return false;
            }
        }

        public static byte[] BuildHelloResponse(byte[] encryptedSessionKey, string sessionId)
        {
            using MemoryStream ms = new MemoryStream();
            CodedOutputStream output = new CodedOutputStream(ms);

            output.WriteRawTag(0x0A);
            output.WriteBytes(ByteString.CopyFrom(encryptedSessionKey ?? Array.Empty<byte>()));
            output.WriteRawTag(0x12);
            output.WriteString(sessionId ?? string.Empty);
            output.Flush();
            return ms.ToArray();
        }

        public static bool TryEncryptRsaPkcs1(
            byte[] modulus,
            byte[] exponent,
            byte[] plain,
            out byte[] encrypted,
            out string error)
         {
            encrypted = Array.Empty<byte>();
            error = null;

            try
            {
                byte[] normalizedModulus = TrimUnsignedPrefix(modulus);
                byte[] normalizedExponent = TrimUnsignedPrefix(exponent);
                if (normalizedExponent.Length == 0)
                    normalizedExponent = StandardRsaPublicExponent;

                if (normalizedModulus.Length < 64)
                    throw new CryptographicException($"RSA modulus is too short: {normalizedModulus.Length}");
               if (normalizedExponent.Length == 0 || normalizedExponent.Length > 8)
                    throw new CryptographicException($"RSA exponent length is invalid: {normalizedExponent.Length}");

                using RSA rsa = RSA.Create();
                rsa.ImportParameters(new RSAParameters
                {
                    Modulus = normalizedModulus,
                    Exponent = normalizedExponent
                });

                encrypted = rsa.Encrypt(plain ?? Array.Empty<byte>(), RSAEncryptionPadding.Pkcs1);
               return true;
            }
            catch (System.Exception ex)
            {
                error = $"{ex.GetType().Name}: {ex.Message}";
                return false;
            }
        }

        public static string Fingerprint(byte[] data)
        {
            using SHA256 sha = SHA256.Create();
            byte[] hash = sha.ComputeHash(data ?? Array.Empty<byte>());
            return Convert.ToHexString(hash, 0, 6);
        }

        public static string Mask(string value)
         {
            if (string.IsNullOrEmpty(value)) return "<empty>";
            if (value.Length <= 10) return $"len={value.Length}";
            return $"{value.Substring(0, 5)}…{value.Substring(value.Length - 4)} len={value.Length}";
        }

        private static void ValidateAes(byte[] key, byte[] iv)
        {
            if (key == null || key.Length != 16)
                throw new CryptographicException("AES key must be exactly 16 bytes");
            if (iv == null || iv.Length != 16)
               throw new CryptographicException("AES IV must be exactly 16 bytes");
        }

        private static byte[] TrimUnsignedPrefix(byte[] value)
        {
            if (value == null || value.Length == 0)
                return Array.Empty<byte>();

           int start = 0;
            while (start < value.Length - 1 && value[start] == 0)
                start++;

           if (start == 0) return value;
            byte[] result = new byte[value.Length - start];
             Buffer.BlockCopy(value, start, result, 0, result.Length);
            return result;
        }
    }
}
