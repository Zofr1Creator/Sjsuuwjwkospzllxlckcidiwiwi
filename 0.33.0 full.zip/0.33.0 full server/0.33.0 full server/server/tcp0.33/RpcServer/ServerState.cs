using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer
{
    public class EnumMapper<TProto, TModel>
       where TProto : notnull
        where TModel : notnull
    {
        private static readonly Dictionary<TProto, TModel> ProtoToModel;
        private static readonly Dictionary<TModel, TProto> ModelToProto;

       static EnumMapper()
        {
            Type protoType = typeof(TProto);
            Type modelType = typeof(TModel);

            ModelToProto = Enum.GetValues(modelType)
                .Cast<TModel>()
                .ToDictionary(value =>
                    value,
                     value => (TProto)Enum.Parse(protoType, value!.ToString()!));

            ProtoToModel = Enum.GetValues(protoType)
                .Cast<TProto>()
                .ToDictionary(value =>
                    value,
                    value => (TModel)Enum.Parse(modelType, value!.ToString()!));
        }

        public static TModel ToOriginal(TProto proto)
        {
            return ProtoToModel[proto];
        }

        public static TProto ToProto(TModel original)
         {
            return ModelToProto[original];
        }

        public static TModel[] ToOriginal(TProto[] values)
        {
            return values.Select(ToOriginal).ToArray();
        }

        public static TProto[] ToProto(TModel[] values)
        {
            return values.Select(ToProto).ToArray();
        }
    }

    public class Token
    {
        public ObjectId playerId;
       public string gameCode;
        public string gameVersion;
    }

    [Serializable]
    public class PlayerStatus
    {
        public PlayInGame playInGame { get; set; } = null;
        public string gpid { get; set; } = string.Empty;
        public OnlineStatus onlineStatus { get; set; } = OnlineStatus.StateOffline;
        public static Axlebolt.Bolt.Protobuf2.PlayerStatus GetByDocument(PlayerStatus document)
        {
            bool hasGame = document.playInGame != null &&
                           (!string.IsNullOrWhiteSpace(document.playInGame.lobbyId) ||
                            document.playInGame.photonGame != null);

            return new Axlebolt.Bolt.Protobuf2.PlayerStatus
            {
                PlayerId = document.gpid ?? string.Empty,
                 OnlineStatus = (Axlebolt.Bolt.Protobuf2.OnlineStatus)document.onlineStatus,
                PlayInGame = hasGame ? PlayInGame.GetByDocument(document.playInGame) : null
            };
        }

        public enum OnlineStatus
        {
            StateOffline,
            StateOnline,
             StateBusy,
            StateAway,
            StateSnooze,
            StateLookingToTrade,
            StateLookingToPlay
        }
    }

    [Serializable]
    public class PlayInGame
    {
        public string gameCode { get; set; }
        public string gameVersion { get; set; }
        public string lobbyId { get; set; }
        public PhotonGame photonGame { get; set; }
        public string lobbyName { get; set; } = string.Empty;

        public static Axlebolt.Bolt.Protobuf2.PlayInGame GetByDocument(PlayInGame document)
        {
             return new Axlebolt.Bolt.Protobuf2.PlayInGame
            {
                GameCode = document.gameCode ?? string.Empty,
                GameVersion = document.gameVersion ?? string.Empty,
                LobbyId = document.lobbyId ?? string.Empty,
                PhotonGame = document.photonGame != null
                    ? PhotonGame.GetByDocument(document.photonGame)
                    : null,
                LobbyName = document.lobbyName ?? string.Empty
            };
        }
    }

    [Serializable]
    public class PhotonGame
    {
        public string region { get; set; }
        public string roomId { get; set; }
        public string appVersion { get; set; }
        public Dictionary<string, string> customProperties { get; set; }

        public static Axlebolt.Bolt.Protobuf2.PhotonGame GetByDocument(PhotonGame document)
        {
            var result = new Axlebolt.Bolt.Protobuf2.PhotonGame
            {
                Region = document.region ?? string.Empty,
                RoomId = document.roomId ?? string.Empty,
                 AppVersion = document.appVersion ?? string.Empty
            };
            if (document.customProperties == null)
                return result;

            foreach (KeyValuePair<string, string> property in document.customProperties)
                result.CustomProperties[property.Key] = property.Value ?? string.Empty;

            return result;
        }
     }

     public static class ServerState
    {
        public static readonly object EventSendersLock = new();
        public static readonly object UsersLock = new();

        public static Dictionary<string, BoltLobby> Lobbies = new Dictionary<string, BoltLobby>();
         public static Dictionary<string, List<IEventSender>> EventSenders = new Dictionary<string, List<IEventSender>>();

        public static Dictionary<TcpClient, List<IEventSender>> EventSendersByConnection =
            new Dictionary<TcpClient, List<IEventSender>>();
        public static Dictionary<string, Token> Tokens = new Dictionary<string, Token>();
        public static Dictionary<string, PlayerStatus> PlayersStatus = new Dictionary<string, PlayerStatus>();
        private static readonly object PlayersStatusLock = new();
        public static void SetConnectionEventSenders(
            string playerId,
            TcpClient client,
            List<IEventSender> senders)
        {
            if (string.IsNullOrWhiteSpace(playerId) || client == null || senders == null)
                return;

            lock (EventSendersLock)
            {
                 if (EventSendersByConnection.TryGetValue(client, out List<IEventSender> oldList) && oldList != null &&
                    EventSenders.TryGetValue(playerId, out List<IEventSender> oldAggregate) && oldAggregate != null)
               {
                    foreach (IEventSender oldSender in oldList) oldAggregate.Remove(oldSender);
                }

                EventSendersByConnection[client] = senders;
                if (!EventSenders.TryGetValue(playerId, out List<IEventSender> aggregate) || aggregate == null)
                {
                    aggregate = new List<IEventSender>();
                    EventSenders[playerId] = aggregate;
                }
                foreach (IEventSender sender in senders)
                    if (sender != null && !aggregate.Contains(sender)) aggregate.Add(sender);
            }
        }

        public static void EnsureConnectionEventSender<TSender>(
            string playerId,
            TcpClient client,
            Func<TSender> factory)
            where TSender : class, IEventSender
        {
            if (string.IsNullOrWhiteSpace(playerId) || client == null || factory == null)
                return;

            lock (EventSendersLock)
            {
                if (!EventSendersByConnection.TryGetValue(client, out List<IEventSender> list) || list == null)
                {
                    list = new List<IEventSender>();
                    EventSendersByConnection[client] = list;
                }
                if (!list.OfType<TSender>().Any())
                    list.Add(factory());
                if (!EventSenders.TryGetValue(playerId, out List<IEventSender> aggregate) || aggregate == null)
                {
                     aggregate = new List<IEventSender>();
                    EventSenders[playerId] = aggregate;
                }
                foreach (IEventSender sender in list)
                    if (sender != null && !aggregate.Contains(sender)) aggregate.Add(sender);
            }
        }

        public static List<TSender> GetLiveEventSenders<TSender>(string playerId)
            where TSender : class, IEventSender
        {
            var result = new List<TSender>();
            if (string.IsNullOrWhiteSpace(playerId))
                return result;

            List<TcpClient> clients;
            lock (UsersLock)
           {
                clients = Users
                    .Where(pair => string.Equals(pair.Value, playerId, StringComparison.Ordinal))
                    .Select(pair => pair.Key)
                    .Where(client => client != null)
                   .ToList();
            }

            lock (EventSendersLock)
            {
                foreach (TcpClient client in clients)
                {
                    if (!EventSendersByConnection.TryGetValue(client, out List<IEventSender> list) || list == null)
                       continue;
                    result.AddRange(list.OfType<TSender>());
                }

                if (result.Count == 0 &&
                    EventSenders.TryGetValue(playerId, out List<IEventSender> fallback) &&
                    fallback != null)
                {
                    result.AddRange(fallback.OfType<TSender>());
                }
            }
            return result.Distinct().ToList();
        }

        public static void RemoveConnectionEventSenders(TcpClient client, string playerId)
        {
            if (client == null) return;

            List<TcpClient> otherClients = new List<TcpClient>();
            if (!string.IsNullOrWhiteSpace(playerId))
            {
                lock (UsersLock)
                {
                    otherClients = Users
                       .Where(pair => pair.Key != client &&
                             string.Equals(pair.Value, playerId, StringComparison.Ordinal))
                        .Select(pair => pair.Key)
                        .Where(value => value != null)
                        .ToList();
                }
            }

            lock (EventSendersLock)
            {
                EventSendersByConnection.TryGetValue(client, out List<IEventSender> removed);
                EventSendersByConnection.Remove(client);
                if (string.IsNullOrWhiteSpace(playerId)) return;

                if (EventSenders.TryGetValue(playerId, out List<IEventSender> aggregate) && aggregate != null && removed != null)
                {
                    foreach (IEventSender sender in removed) aggregate.Remove(sender);
                    if (aggregate.Count == 0) EventSenders.Remove(playerId);
                }
            }
        }

        private static string NormalizeProductGameVersion(string gameVersion, string photonAppVersion)
        {
            string raw = !string.IsNullOrWhiteSpace(gameVersion) ? gameVersion : (photonAppVersion ?? string.Empty);
            raw = raw.Trim();
            if (raw.Length == 0) return "0.33.0";

            int underscore = raw.IndexOf('_');

            if (underscore > 0) raw = raw.Substring(0, underscore);
            int f = raw.IndexOf('F');
            if (f <= 0) f = raw.IndexOf('f');
            if (f > 0) raw = raw.Substring(0, f);
            return string.IsNullOrWhiteSpace(raw) ? "0.33.0" : raw;
        }

        public static void SetPlayerPhotonPresence(string playerId, string roomId, string region, string appVersion, IDictionary<string, string> customProperties = null, string gameVersion = null)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return;

            PlayerStatus status = GetOrCreatePlayerStatus(playerId);
           status.gpid = playerId;
            string beforeFingerprint = PresenceFingerprint(status);
            status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
            if (status.playInGame == null)
                status.playInGame = new PlayInGame();

            status.playInGame.gameCode = string.IsNullOrWhiteSpace(status.playInGame.gameCode) ? "standoff2" : status.playInGame.gameCode;

            status.playInGame.gameVersion = NormalizeProductGameVersion(gameVersion, appVersion);
            status.playInGame.photonGame = string.IsNullOrWhiteSpace(roomId)
                ? null
                : new PhotonGame
                {
                    roomId = roomId,
                    region = string.IsNullOrWhiteSpace(region) ? "eur" : region,
                    appVersion = string.IsNullOrWhiteSpace(appVersion) ? "0.33.0_1.96" : appVersion,
                    customProperties = customProperties == null
                        ? new Dictionary<string, string>()
                        : new Dictionary<string, string>(customProperties, StringComparer.Ordinal)
                };

           string afterFingerprint = PresenceFingerprint(status);
            bool changed = !string.Equals(beforeFingerprint, afterFingerprint, StringComparison.Ordinal);
            SetPlayerStatusSnapshot(playerId, status);
            if (!changed)
           {
                return;
            }

            try
            {
                if (ObjectId.TryParse(playerId, out ObjectId objectId))
                     BoltMainDatabaseProvider.Instance.SetPlayerStatus(objectId, status);
            }
             catch (System.Exception)
            {
            }

            TspServer.RpcServer.Api.SocialProfileEventBridge.BroadcastStatus(playerId, status);
         }

        public static void SetPlayerStatusSnapshot(string playerId, PlayerStatus status)
        {
            if (string.IsNullOrWhiteSpace(playerId) || status == null) return;
            lock (PlayersStatusLock)
                PlayersStatus[playerId] = status;
         }

        public static PlayerStatus GetOrCreatePlayerStatus(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                throw new ArgumentException("playerId is empty", nameof(playerId));

            lock (PlayersStatusLock)
            {
                if (!PlayersStatus.TryGetValue(playerId, out var status) || status == null)
                {
                    status = new PlayerStatus
                    {
                        gpid = playerId,
                        onlineStatus = PlayerStatus.OnlineStatus.StateOnline,
                        playInGame = new PlayInGame
                        {
                            gameCode = string.Empty,
                            gameVersion = string.Empty,
                            lobbyId = string.Empty,
                             photonGame = null
                        }
                    };
                    PlayersStatus[playerId] = status;
                }
                 else
                {
                    status.gpid = playerId;
                }
                if (status.playInGame == null)
                {
                    status.playInGame = new PlayInGame
                    {
                        gameCode = string.Empty,
                        gameVersion = string.Empty,
                        lobbyId = string.Empty,
                        photonGame = null
                    };
                }

                return status;
            }
        }
        public static bool HasOtherLiveConnection(string playerId, TcpClient except)
        {
            lock (UsersLock)
            {
                return Users.Any(pair => pair.Key != except && pair.Value == playerId && pair.Key?.Connected == true);
            }
        }

        public static bool HasAnyConnection(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return false;
            lock (UsersLock)
            {
                return Users.Any(pair => string.Equals(pair.Value, playerId, StringComparison.Ordinal) && pair.Key != null);
            }
        }

        public static PlayerStatus GetPlayerStatusSnapshot(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return null;
           lock (PlayersStatusLock)
            {
                PlayersStatus.TryGetValue(playerId, out PlayerStatus status);
                return status;
            }
        }

        public static Dictionary<string, PlayerStatus> GetPlayerStatusSnapshots()
        {
            lock (PlayersStatusLock)
            {
                return PlayersStatus.ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.Ordinal);
            }
        }

        private static string PresenceFingerprint(PlayerStatus status)
        {
            if (status == null) return "<null>";
            PlayInGame p = status.playInGame;
            PhotonGame g = p?.photonGame;
            string custom = g?.customProperties == null
                ? string.Empty
                : string.Join(";", g.customProperties.OrderBy(x => x.Key).Select(x => x.Key + "=" + x.Value));
            return ((int)status.onlineStatus) + "|" + (p?.gameCode ?? "") + "|" +
                (p?.gameVersion ?? "") + "|" + (p?.lobbyId ?? "") + "|" + (p?.lobbyName ?? "") + "|" +
                (g?.roomId ?? "") + "|" + (g?.region ?? "") + "|" +
                (g?.appVersion ?? "") + "|" + custom;
        }

        public static Dictionary<TcpClient, string> Users = new Dictionary<TcpClient, string>();

        public static List<TcpClient> GameServerUsers = new List<TcpClient>();
   }

}
