using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using Google.Protobuf.Reflection;
namespace TspServer.RpcServer
{
    public class RpcValueReader
    {
        private readonly MessageParser _parser;
         private readonly Type _parameterType;

        public RpcValueReader(Type parameterType)
        {
            ArgumentNullException.ThrowIfNull(parameterType);

            _parameterType = RpcTypeCodec.ToProtoType(parameterType);
            Type parserType = _parameterType.IsArray
                ? _parameterType.GetElementType()!
                : _parameterType;

            PropertyInfo parserProp = parserType.GetProperty("Parser")
                ?? throw new ArgumentException($"protobuf parser missing for {parserType.Name}", nameof(parameterType));

            _parser = (MessageParser?)parserProp.GetValue(null)
                ?? throw new ArgumentException($"protobuf parser unavailable for {parserType.Name}", nameof(parameterType));
        }

        public object FromBytes(BinaryValue value)
        {
            ArgumentNullException.ThrowIfNull(value);

            if (value.IsNull)
                return null!;

            if (_parameterType.IsArray)
                return FromBytesArray(_parameterType.GetElementType()!, value);

            return FromBytesOne(value.One, _parameterType);
        }

        protected virtual object FromBytesArray(Type elementType, BinaryValue value)
        {
            Array items = Array.CreateInstance(elementType, value.Array.Count);
            for (int i = 0; i < items.Length; i++)
                items.SetValue(FromBytesOne(value.Array[i], elementType), i);

            return items;
         }

        protected virtual object FromBytesOne(ByteString bytes, Type elementType)
        {
            return RpcTypeCodec.ToOrigValue(_parser.ParseFrom(bytes), elementType);
        }
    }

    public static class RpcTypeCodec
    {
        public static RpcValueWriter[] GetParamToBytesMethods(MethodInfo method)
         {
            ArgumentNullException.ThrowIfNull(method);
            return method.GetParameters()
                .Select(parameter => CreateToByteMethod(parameter.ParameterType))
                .ToArray();
        }

        public static RpcValueWriter GetReturnToBytesMethod(MethodInfo method)
       {
            ArgumentNullException.ThrowIfNull(method);
            return method.ReturnType == typeof(void)
                ? null!
                : CreateToByteMethod(method.ReturnType);
        }

        public static RpcValueWriter CreateToByteMethod(Type type)
        {
            return IsEnumType(type)
                ? new EnumValueWriter(type)
                : new RpcValueWriter(type);
        }

        public static RpcValueReader[] GetParamFromBytesMethods(MethodInfo method)
        {
            ArgumentNullException.ThrowIfNull(method);
            return method.GetParameters()
                .Select(parameter => CreateFromByteMethod(parameter.ParameterType))
               .ToArray();
        }

        public static RpcValueReader GetReturnFromBytesMethod(MethodInfo method)
        {
            ArgumentNullException.ThrowIfNull(method);
            return method.ReturnType == typeof(void)
                ? null!
                : CreateFromByteMethod(method.ReturnType);
        }

        public static bool IsEnumType(Type type)
        {
            ArgumentNullException.ThrowIfNull(type);
            Type actual = type.IsArray ? type.GetElementType()! : type;
            return actual.IsEnum;
        }

        public static bool IsSupportedType(Type type)
        {
             ArgumentNullException.ThrowIfNull(type);
            Type actual = type.IsArray ? type.GetElementType()! : type;

            if (actual == typeof(void))
                return true;

             if (actual.IsEnum)
             {
                return actual
                    .GetFields()
                    .Where(field => field.Name != "value__")
                    .All(field => Attribute.IsDefined(field, typeof(OriginalNameAttribute)));
            }

            return actual == typeof(int) ||
                   actual == typeof(float) ||
                   actual == typeof(long) ||
                   actual == typeof(string) ||
                   actual == typeof(double) ||
                   actual == typeof(bool) ||
                   actual == typeof(byte) ||
                   actual == typeof(int?) ||
                   actual == typeof(float?) ||
                   actual == typeof(long?) ||
                   actual == typeof(double?) ||
                   actual == typeof(bool?) ||
                  actual == typeof(byte?) ||
                   typeof(IMessage).IsAssignableFrom(actual);
        }

        public static object ToProtoValue(object value)
        {
            ArgumentNullException.ThrowIfNull(value);

            if (value.GetType().IsArray && value.GetType().GetElementType()?.IsEnum == true)
                return value;

            return value switch
             {
                int number => new Integer { Value = number },
                int[] numbers => WrapInts(numbers),
                float number => new Float { Value = number },
                float[] numbers => WrapFloats(numbers),
                long number => new Long { Value = number },
                long[] numbers => WrapLongs(numbers),
                string text => new Axlebolt.RpcSupport.Protobuf.String { Value = text },
                string[] strings => WrapStrings(strings),
                double number => new Axlebolt.RpcSupport.Protobuf.Double { Value = number },
                double[] numbers => WrapDoubles(numbers),
                bool flag => new Axlebolt.RpcSupport.Protobuf.Boolean { Value = flag },
                bool[] flags => WrapBools(flags),
                byte number => new Axlebolt.RpcSupport.Protobuf.Byte
                {
                    Value = ByteString.CopyFrom(new[] { number })
                },
                byte[] bytes => new Axlebolt.RpcSupport.Protobuf.Byte
                {
                    Value = ByteString.CopyFrom(bytes)
                },
                _ => value
            };
        }

        public static object ToOrigValue(object protoValue, Type originalType)
        {
            ArgumentNullException.ThrowIfNull(protoValue);
            ArgumentNullException.ThrowIfNull(originalType);

            return protoValue switch
            {
               Integer value => value.Value,
                IntegerArray value => value.Value.ToArray(),
                Float value => value.Value,
                FloatArray value => value.Value.ToArray(),
                Long value => value.Value,
                LongArray value => value.Value.ToArray(),
                Axlebolt.RpcSupport.Protobuf.String value => value.Value,
                StringArray value => value.Value.ToArray(),
                Axlebolt.RpcSupport.Protobuf.Double value => value.Value,
                DoubleArray value => value.Value.ToArray(),
                Axlebolt.RpcSupport.Protobuf.Boolean value => value.Value,
                BooleanArray value => value.Value.ToArray(),
                Axlebolt.RpcSupport.Protobuf.Byte value => value.Value.ToByteArray()[0],
                ByteArray value => value.Value.ToByteArray(),
                _ => protoValue
            };
        }

        public static Type ToProtoType(Type originalType)
        {
            ArgumentNullException.ThrowIfNull(originalType);

            if (originalType == typeof(int) || originalType == typeof(int?))
                return typeof(Integer);
            if (originalType == typeof(int[]))
                return typeof(IntegerArray);
            if (originalType == typeof(float) || originalType == typeof(float?))
               return typeof(Float);
             if (originalType == typeof(float[]))
                return typeof(FloatArray);

            if (originalType == typeof(long) || originalType == typeof(long?))
                return typeof(Long);
            if (originalType == typeof(long[]))
                return typeof(LongArray);

            if (originalType == typeof(string))
                return typeof(Axlebolt.RpcSupport.Protobuf.String);
            if (originalType == typeof(string[]))
                return typeof(StringArray);

            if (originalType == typeof(double) || originalType == typeof(double?))
                return typeof(Axlebolt.RpcSupport.Protobuf.Double);
            if (originalType == typeof(double[]))
                 return typeof(DoubleArray);

            if (originalType == typeof(bool) || originalType == typeof(bool?))
                return typeof(Axlebolt.RpcSupport.Protobuf.Boolean);
            if (originalType == typeof(bool[]))
                return typeof(BooleanArray);

            if (originalType == typeof(byte) || originalType == typeof(byte?))
                return typeof(Axlebolt.RpcSupport.Protobuf.Byte);
           if (originalType == typeof(byte[]))
                 return typeof(ByteArray);

            return originalType;
        }

        private static RpcValueReader CreateFromByteMethod(Type type)
        {
            return IsEnumType(type)
                ? new EnumValueReader(type)
                : new RpcValueReader(type);
        }

        private static IntegerArray WrapInts(int[] values)
        {
            var result = new IntegerArray();
            result.Value.AddRange(values);
             return result;
        }

        private static FloatArray WrapFloats(float[] values)
        {
            var result = new FloatArray();
            result.Value.AddRange(values);
            return result;
        }

        private static LongArray WrapLongs(long[] values)
        {
            var result = new LongArray();
            result.Value.AddRange(values);
            return result;
        }

        private static StringArray WrapStrings(string[] values)
        {
            var result = new StringArray();
            result.Value.AddRange(values);
            return result;
        }

        private static DoubleArray WrapDoubles(double[] values)
        {
            var result = new DoubleArray();
            result.Value.AddRange(values);
            return result;
        }

        private static BooleanArray WrapBools(bool[] values)
        {
            var result = new BooleanArray();
            result.Value.AddRange(values);
            return result;
        }
    }

    public sealed class EnumValueReader : RpcValueReader
    {
        private readonly Type _enumType;

         public EnumValueReader(Type parameterType)
            : base(parameterType.IsArray
                ? typeof(Axlebolt.RpcSupport.Protobuf.Enum[])
                : typeof(Axlebolt.RpcSupport.Protobuf.Enum))
        {
            ArgumentNullException.ThrowIfNull(parameterType);
            _enumType = parameterType.IsArray
                ? parameterType.GetElementType()!
                : parameterType;
        }

        protected override object FromBytesArray(Type type, BinaryValue binaryValue)
        {
            return base.FromBytesArray(_enumType, binaryValue);
        }

        protected override object FromBytesOne(ByteString bytes, Type elementType)
        {
            var value = (Axlebolt.RpcSupport.Protobuf.Enum)base.FromBytesOne(bytes, elementType);
            return System.Enum.ToObject(_enumType, value.Value);
        }
    }

    public class RpcValueWriter
    {
        private readonly Type _parameterType;

        public RpcValueWriter(Type parameterType)
        {
            ArgumentNullException.ThrowIfNull(parameterType);
            _parameterType = RpcTypeCodec.ToProtoType(parameterType);
        }

        public virtual BinaryValue ToBytes(object? value)
        {
            if (value == null)
                return new BinaryValue { IsNull = true };

            if (_parameterType.IsArray)
                return ToBytesArray(value);

            return new BinaryValue
             {
                IsNull = false,
                One = ToBytesOne(value)
            };
        }

        protected virtual ByteString ToBytesOne(object value)
        {
            return ((IMessage)RpcTypeCodec.ToProtoValue(value)).ToByteString();
        }

        private BinaryValue ToBytesArray(object value)
        {
           var binary = new BinaryValue { IsNull = false };

            if (value is not IEnumerable enumerable)
                return binary;

            foreach (object? item in enumerable)
            {
                if (item != null)
                    binary.Array.Add(ToBytesOne(item));
            }

            return binary;
        }
     }

    public sealed class EnumValueWriter : RpcValueWriter
    {
        public EnumValueWriter(Type parameterType)
            : base(parameterType.IsArray
                ? typeof(Axlebolt.RpcSupport.Protobuf.Enum[])
                : typeof(Axlebolt.RpcSupport.Protobuf.Enum))
        {
        }

        protected override ByteString ToBytesOne(object value)
        {
             ArgumentNullException.ThrowIfNull(value);
           var proto = new Axlebolt.RpcSupport.Protobuf.Enum
            {
                Value = (int)value
            };

            return base.ToBytesOne(proto);
        }
    }

    public enum InventoryId
    {
        None = 0
    }
}
