using System;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

public static class BinaryValueExt
{
    public static byte[] GetBytesSafe(this BinaryValue bv)
    {
        if (bv == null)
       return Array.Empty<byte>();

        var type = bv.GetType();

        string[] names =
       {
       "One",
        "Bytes",
        "Value",
        "Data"
    };

        foreach (string name in names)
        {
            var property = type.GetProperty(name);
           if (property != null)
            {
                object obj = property.GetValue(bv);

                if (obj is byte[] bytes)
                    return bytes;

                if (obj is ByteString byteString)
                    return byteString.ToByteArray();
            }

            var field = type.GetField(name);
            if (field != null)
            {
               object obj = field.GetValue(bv);

                if (obj is byte[] bytes)
                    return bytes;

                if (obj is ByteString byteString)
                    return byteString.ToByteArray();
            }
        }

        return Array.Empty<byte>();
    }

    public static int ByteLength(this BinaryValue bv) => bv.GetBytesSafe().Length;
}
