using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{

    public class PlayerRemoteService : RpcHandler
   {

        public PlayerRemoteService(ClientSession user) : base(user)
        { 
        }
        protected void SetPlayerAvatar(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                RpcValueReader from = new RpcValueReader(typeof(byte[]));
                byte[] Avatarforset = (byte[])from.FromBytes(values[0]);
                int[] rt = new int[Avatarforset.Length];
                rt = Avatarforset.Select(i => (int)i).ToArray();
                string avatarId = boltGame.FindOrCreateAvatar(rt);
                
                boltMain.SetPlayerAvatar(ObjectId.Parse(Id), avatarId);
              
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse{ Id = guid, Return = new RpcValueWriter(typeof(string)).ToBytes(avatarId) } });
                return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                     }
                }
            });
        }
        protected void GetCurrentPlayer(BinaryValue[] values, string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string idStr) || string.IsNullOrEmpty(idStr))
            {
                Send401(guid);
                return;
            }

           if (!ObjectId.TryParse(idStr, out var oid))
            {
                SendException(guid, 500);
                return;
            }

            var boltMain = BoltMainDatabaseProvider.Instance;
            var playerDocument = boltMain.GetPlayerDocument(oid);

             if (playerDocument == null)
            {
                SendException(guid, 404);
                return;
            }

            ServerState.GetOrCreatePlayerStatus(idStr);
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new RpcValueWriter(typeof(Axlebolt.Bolt.Protobuf2.Player)).ToBytes(
                         FriendHelper.GetPlayer(playerDocument))
               }
           });
        }

        protected void GetPlayer2(BinaryValue[] values, string guid)
        {
           if (!ServerState.Users.TryGetValue(_session.TcpClient, out string idStr) ||
                string.IsNullOrWhiteSpace(idStr))
            {
                Send401(guid);
                return;
             }

            if (!ObjectId.TryParse(idStr, out ObjectId oid))
            {
                SendException(guid, 500);
                return;
            }

            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(oid);
            if (playerDocument == null)
            {
                SendException(guid, 404);
                return;
            }

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(idStr);
           var player = new Axlebolt.Bolt.Protobuf2.Player
            {
                Id = playerDocument._id.ToString(),
                 Uid = playerDocument.uid ?? string.Empty,
                Name = playerDocument.name ?? string.Empty,
                AvatarId = playerDocument.avatarId ?? string.Empty,
                TimeInGame = playerDocument.timeInGame,
                RegistrationDate = playerDocument.createDate == null
                    ? 0
                    : playerDocument.createDate.MillisecondsSinceEpoch,
                PlayerStatus = status.GetPlayerStatusProto()
           };
             PlayerProfileContract.Apply(player, playerDocument);

            byte[] playerBytes;

            IMongoCollection<BsonDocument> profileFlagsCollection = BoltMainDatabaseProvider.Instance.GetDatabase()
                .GetCollection<BsonDocument>("player_profile_flags");
            FilterDefinition<BsonDocument> profileFlagsFilter = Builders<BsonDocument>.Filter.Eq("playerId", idStr);
            profileFlagsCollection.UpdateOne(
                profileFlagsFilter,
                Builders<BsonDocument>.Update
                    .SetOnInsert("playerId", idStr)
                    .SetOnInsert("verified", false)
                    .SetOnInsert("testerRole", string.Empty)
                     .SetOnInsert("tags", new BsonArray())
                    .SetOnInsert("createDate", DateTime.UtcNow)
                    .Set("updateDate", DateTime.UtcNow),
                new UpdateOptions { IsUpsert = true });
            BsonDocument profileFlags = profileFlagsCollection.Find(profileFlagsFilter).FirstOrDefault();
            bool verified = PlayerProfileContract.IsVerified(playerDocument);
            string testerRole = profileFlags != null && profileFlags.TryGetValue("testerRole", out BsonValue roleValue) && !roleValue.IsBsonNull
                ? roleValue.ToString()
                : (Environment.GetEnvironmentVariable("BOLT_DEFAULT_TESTER_ROLE") ?? string.Empty);
            List<int> tags = new List<int>();
            if (profileFlags != null && profileFlags.TryGetValue("tags", out BsonValue tagsValue) && tagsValue.IsBsonArray)
                tags.AddRange(tagsValue.AsBsonArray.Where(x => x.IsInt32 || x.IsInt64).Select(x => x.ToInt32()));

            foreach (int tag in tags)
                if (!player.Tags.Contains(tag)) player.Tags.Add(tag);
            if (verified && !player.Tags.Contains(PlayerProfileContract.VerifiedPlayerTag))
                player.Tags.Add(PlayerProfileContract.VerifiedPlayerTag);

            playerBytes = player.ToByteArray();

            using (var playerStream = new MemoryStream())
            {
                playerStream.Write(playerBytes, 0, playerBytes.Length);
                 using (var playerOut = new CodedOutputStream(playerStream, true))
                 {
                    if (!string.IsNullOrWhiteSpace(testerRole))
                    {
                        playerOut.WriteTag(10, WireFormat.WireType.LengthDelimited);
                        playerOut.WriteString(testerRole);
                    }
                    if (playerDocument.isBanned)
                    {
                        byte[] banBytes = ContractWire.Build(ban =>
                        {
                            ban.Int32(1, playerDocument.banCode);
                            ban.String(2, playerDocument.banReason ?? string.Empty);
                           ban.Varint(3, playerDocument.bannedUntil, emitDefault: true);
                        });
                        playerOut.WriteTag(11, WireFormat.WireType.LengthDelimited);
                        playerOut.WriteBytes(ByteString.CopyFrom(banBytes));
                    }
                    playerOut.WriteTag(14, WireFormat.WireType.Varint);
                    playerOut.WriteBool(true);
                    playerOut.Flush();
                }
                playerBytes = playerStream.ToArray();
            }

             byte[] responsePayload;
           using (var responseStream = new MemoryStream())
            {
                using (var output = new CodedOutputStream(responseStream, true))
                {
                    output.WriteTag(1, WireFormat.WireType.LengthDelimited);
                    output.WriteBytes(ByteString.CopyFrom(playerBytes));
                    output.WriteTag(3, WireFormat.WireType.LengthDelimited);
                    output.WriteString(playerDocument.uid ?? playerDocument._id.ToString());
                    output.Flush();
                }
                responsePayload = responseStream.ToArray();
            }


            _session.SendResponse(new ResponseMessage
             {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.CopyFrom(responsePayload)
                    }
                }
            });
        }

        private void Send401(string guid) => SendException(guid, 401);

       private void SendException(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        protected void SetPlayerName(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
           {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
               RpcValueReader fromByte = new RpcValueReader(typeof(string));
                string name = (string)fromByte.FromBytes(values[0]);
                boltMain.SetPlayerName(ObjectId.Parse(Id), name);

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
                });
                return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
               {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
             });
        }
        protected void SetAwayStatus(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus status = ServerState.GetOrCreatePlayerStatus(Id);
               status.onlineStatus = PlayerStatus.OnlineStatus.StateAway;
                boltMain.SetPlayerStatus(ObjectId.Parse(Id), status);
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                       {
                            IsNull = true
                        }
                    }
                });
                return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                         Code = 401
                    }
                }
            });
        }
        protected void SetOnlineStatus(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus status = ServerState.GetOrCreatePlayerStatus(Id);
                status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
               boltMain.SetPlayerStatus(ObjectId.Parse(Id), status);
                _session.SendResponse(new ResponseMessage
                {
                   RpcResponse = new RpcResponse
                     {
                        Id = guid,
                        Return = new BinaryValue
                         {
                            IsNull = true
                       }
                    }
                });
                return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                   Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
           });
         }
       protected void BanMe(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                RpcValueReader fromByte1 = new RpcValueReader(typeof(string));
                RpcValueReader fromByte2 = new RpcValueReader(typeof(int));
                 string banReason = (string)fromByte1.FromBytes(values[0]);
                int banCode = (int)fromByte2.FromBytes(values[1]);
                long until = ServerOptions.Current.AntiCheatBanSeconds > 0
                    ? DateTimeOffset.UtcNow.ToUnixTimeSeconds() + ServerOptions.Current.AntiCheatBanSeconds
                    : 0;
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
               });
                return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                     Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                     }
                }
            });
        }

        private void BanMeV2(RpcRequest request)
         {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
           int banCode = ContractWire.ReadIntField(raw, 1, 0);
            string reason = ContractWire.ReadStringField(raw, 2, string.Empty).Trim();

           if (banCode <= 0 || banCode > 1_000_000)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            int reportCode = banCode;
            bool stockDetector = reportCode >= 2101 && reportCode <= 2114;
            if (string.IsNullOrWhiteSpace(reason))
                reason = stockDetector ? $"Client anti-cheat detector {reportCode}" : $"Client security report {reportCode}";
             else if (stockDetector && !reason.StartsWith("[detector ", StringComparison.OrdinalIgnoreCase))
                reason = $"[detector {reportCode}] {reason}";
           long until = ServerOptions.Current.AntiCheatBanSeconds > 0
                ? DateTimeOffset.UtcNow.ToUnixTimeSeconds() + ServerOptions.Current.AntiCheatBanSeconds
                : 0;

           ContractWire.SendEmpty(_session, request.Id);
        }

       private void BroadcastToFriends(string playerId, string eventName, params object[] payload)
        {
            string[] friendIds = BoltGameDatabaseProvider.Instance
                .GetPlayerFriends(playerId)
                 .Where(x => x != null && x.relationshipStatus == RelationshipStatusCustom.Friend)
                .Select(x => string.Equals(x.playerInitiatorId, playerId, StringComparison.Ordinal)
                    ? x.playerId
                    : x.playerInitiatorId)
               .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.Ordinal)
                .ToArray();

            foreach (string friendId in friendIds)
             {
                SocialEventDelivery.Send<FriendsRemoteEventSender>(
                     friendId,
                    "friends",
                     eventName,
                    payload ?? Array.Empty<object>());
            }
       }

        private void SetOnlineStatusV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId objectId))
            {
               ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
            BoltMainDatabaseProvider.Instance.SetPlayerStatus(objectId, status);
            SocialProfileEventBridge.BroadcastStatus(playerId, status);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void SetPlayerAvatarV2(RpcRequest request)
         {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }

            byte[] avatar = ContractWire.ReadBytesField(
                ContractWire.Param(request), 1);
            if (avatar == null || avatar.Length == 0 || avatar.Length > 4 * 1024 * 1024)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            string avatarId = BoltGameDatabaseProvider.Instance.FindOrCreateAvatar(
                avatar.Select(value => (int)value).ToArray());
            BoltMainDatabaseProvider.Instance.SetPlayerAvatar(objectId, avatarId);
            SocialProfileEventBridge.BroadcastAvatar(playerId, avatarId);

             byte[] response = ContractWire.Build(w => w.String(1, avatarId));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void SetPlayerNameV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            string name = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (name.Length < 1 || name.Length > 32)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            BoltMainDatabaseProvider.Instance.SetPlayerName(objectId, name);
            SocialProfileEventBridge.BroadcastName(playerId, name);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void SetDefaultAvatar(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }

            string avatarId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            BoltMainDatabaseProvider.Instance.SetPlayerAvatar(objectId, avatarId);
            SocialProfileEventBridge.BroadcastAvatar(playerId, avatarId);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void SetAwayStatusV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.onlineStatus = PlayerStatus.OnlineStatus.StateAway;
            BoltMainDatabaseProvider.Instance.SetPlayerStatus(objectId, status);
            SocialProfileEventBridge.BroadcastStatus(playerId, status);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void SetPlayerSettings(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

           try
            {
                if (!BootstrapContracts.SavePlayerSettings(_session, request, out int keyCount, out string language))
               {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                 }

                ContractWire.SendEmpty(_session, request.Id);
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "setPlayerSettings2") SetPlayerSettings(request);
             
            else if (request.MethodName == "setPlayerName2") SetPlayerNameV2(request);
            else if (request.MethodName == "setDefaultAvatar") SetDefaultAvatar(request);
            else if (request.MethodName == "setAwayStatus2") SetAwayStatusV2(request);
            else if (request.MethodName == "setOnlineStatus2") SetOnlineStatusV2(request);
            else if (request.MethodName == "setPlayerAvatar2") SetPlayerAvatarV2(request);
            else if (request.MethodName == "setPlayerAvatar") SetPlayerAvatar(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayer") GetCurrentPlayer(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayer2") GetPlayer2(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "setPlayerName") SetPlayerName(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "setAwayStatus") SetAwayStatus(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "setOnlineStatus") SetOnlineStatus(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "banMe") BanMeV2(request);
            else
             {

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                         Id = request.Id,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 404
                        }
                    }
                });
            }

        }
    }
    public static class PlayerServiceHelper
    {

        public static Axlebolt.Bolt.Protobuf2.PlayerStatus GetPlayerStatusProto(this PlayerStatus bsonElements)
        {
            return PlayerStatus.GetByDocument(bsonElements);
        }
    }
}
