using System;
using Axlebolt.RpcSupport.Protobuf;
namespace TspServer.RpcServer.Api
{

    public sealed class ClanStatsRemoteEventSender : IEventSender
    {
        private readonly ClientSession _session;
        public string eventListenerName { get; set; } = "ClanStatsRemoteEventListener";

        public ClanStatsRemoteEventSender(ClientSession user) { _session = user; }

        public void SendEvent(string eventName, object[] parameters)
        {
            if (parameters != null && parameters.Length == 1 && parameters[0] is byte[] raw)
            {
                SendRawEvent(eventName, raw);
                return;
            }
            throw new InvalidOperationException("dl5005");
        }

        public void SendRawEvent(string eventName, byte[] payload)
        {
            EventResponse envelope = BoltEventContract.CreateRaw(
                eventListenerName,
               eventName,
                payload ?? Array.Empty<byte>());
            _session.SendResponse(new ResponseMessage { EventResponse = envelope });
        }
    }
}
