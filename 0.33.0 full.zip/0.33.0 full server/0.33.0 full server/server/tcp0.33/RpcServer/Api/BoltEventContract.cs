using System;
using System.Collections.Generic;
using System.Threading;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{

   internal static class BoltEventContract
    {
        internal sealed class Spec
       {
            public string Listener { get; }
            public string EventName { get; }
            public uint Route { get; }

            public Spec(string listener, string eventName, uint route)
            {
                Listener = listener;
                EventName = eventName;
                 Route = route;
             }
        }

        private static readonly Dictionary<string, Spec> Specs = BuildMap();
       private static int _testState;

        private static Dictionary<string, Spec> BuildMap()
        {
            var result = new Dictionary<string, Spec>(StringComparer.OrdinalIgnoreCase);

            void Add(string listener, string eventName, uint route, params string[] aliases)
            {
                var spec = new Spec(listener, eventName, route);
                result[EventKey(listener, eventName)] = spec;
                foreach (string alias in aliases ?? Array.Empty<string>())
                    result[EventKey(listener, alias)] = spec;
            }
            const string playerInternal = "PlayerInternalRemoteEventListener";

           Add(playerInternal, "onPlayerBanned", 1);

            const string globalChat = "GlobalChatRemoteEventListener";
            Add(globalChat, "onIncomingGlobalChatMessageEvent", 0, "onIncomingGlobalChatMessage");

             const string market = "MarketplaceRemoteEventListener";
            Add(market, "onTradeUpdatedEvent", 1, "onTradeUpdated");
            Add(market, "onTradeRequestClosedEvent", 2, "onTradeRequestClosed");
             Add(market, "onTradeRequestOpenedEvent", 3, "onTradeRequestOpened");
            Add(market, "onPlayerRequestClosedEvent", 4, "onPlayerRequestClosed");
            Add(market, "onPlayerRequestOpenedEvent", 5, "onPlayerRequestOpened");

            const string friends = "FriendsRemoteEventListener";
            Add(friends, "onPlayerStatusChangedEvent", 11, "onPlayerStatusChanged");
            Add(friends, "onFriendAvatarChangedEvent", 12, "onFriendAvatarChanged");
            Add(friends, "onNewFriendshipRequestEvent", 13, "onNewFriendshipRequest");
            Add(friends, "onFriendNameChangedEvent", 14, "onFriendNameChanged");
            Add(friends, "onFriendAddedEvent", 15, "onFriendAdded");
            Add(friends, "onPlayerAttributesChanged", 16, "onPlayerAttributesChangedEvent");
            Add(friends, "onFriendRemovedEvent", 17, "onFriendRemoved");
            Add(friends, "onRevokeFriendshipRequestEvent", 18, "onRevokeFriendshipRequest");

            const string clans = "ClansRemoteEventListener";
            Add(clans, "onOnlineStatusChangedEvent", 31, "onOnlineStatusChanged");
            Add(clans, "onPlayerAvatarChangedEvent", 32, "onPlayerAvatarChanged");
            Add(clans, "OnJoinRequestTaken", 33, "onJoinRequestTaken", "OnJoinRequestTakenEvent");
            Add(clans, "onPlayerNameChangedEvent", 34, "onPlayerNameChanged");
            Add(clans, "OnMemberJoinedToClan", 35, "onMemberJoinedToClan", "OnMemberJoinedToClanEvent");
            Add(clans, "onPlayerAttributesChanged", 36, "onPlayerAttributesChangedEvent");
            Add(clans, "OnJoinRequestCancelledEvent", 37, "onJoinRequestCancelled");
            Add(clans, "onReadClosedInviteRequestEvent", 38, "onReadClosedInviteRequest");
            Add(clans, "OnJoinedToClan", 39, "onJoinedToClan", "OnJoinedToClanEvent");
            Add(clans, "onInviteRequestDeclinedEvent", 40, "onInviteRequestDeclined");
            Add(clans, "onClanMemberDeclinedRequestEvent", 41, "onClanMemberDeclinedRequest");
            Add(clans, "OnKickedMember", 42, "onKickedMember", "OnKickedMemberEvent");
            Add(clans, "OnAssignedRoleEvent", 43, "onAssignedRoleEvent", "onAssignedRole");
            Add(clans, "OnInvitedToClanEvent", 44, "onInvitedToClanEvent", "onInvitedToClan");
            Add(clans, "onJoinRequestDeclinedEvent", 45, "onJoinRequestDeclined");
            Add(clans, "onLeftFromClan", 46, "onLeftFromClanEvent");
            Add(clans, "onAssignedLeaderRoleEvent", 47, "onAssignedLeaderRole");
            Add(clans, "onClanTypeChanged", 48, "onClanTypeChangedEvent");
           Add(clans, "onClanAvatarChangedEvent", 49, "onClanAvatarChanged");
            Add(clans, "onKickedEvent", 50, "onKicked");
            Add(clans, "OnInviteRequestCancelledEvent", 51, "onInviteRequestCancelled");
            Add(clans, "onClanTagAndNameChanged", 52, "onClanTagAndNameChangedEvent");
            Add(clans, "onClanMembersCountIncreased", 53, "onClanMaxMembersCountIncreased", "onClanMembersCountIncreasedEvent");
            Add(clans, "onClanDescriptionChangedEvent", 54, "onClanDescriptionChanged");

            const string clanMessages = "ClanMessagesRemoteEventListener";
            Add(clanMessages, "onIncomingClanChatMessageEvent", 58, "onIncomingClanChatMessage");

            const string clanStats = "ClanStatsRemoteEventListener";
            Add(clanStats, "onClanStatsUpdated", 59, "onClanStatsUpdatedEvent");

            const string lobby = "MatchmakingRemoteEventListener";

            Add(lobby, "onLobbyDataChangedEvent", 61, "onLobbyDataChanged");
             Add(lobby, "onLobbyJoinableChangedEvent", 62, "onLobbyJoinableChanged");
            Add(lobby, "onNewPlayerInvitedToLobbyEvent", 63, "onNewPlayerInvitedToLobby");
            Add(lobby, "onLobbyChatMessageEvent", 64, "onLobbyChatMessage");
            Add(lobby, "onReceivedInviteToLobbyEvent", 65, "onReceivedInviteToLobby");
            Add(lobby, "onNewPlayerJoinedLobbyEvent", 66, "onNewPlayerJoinedLobby");
            Add(lobby, "onLobbyMaxMembersChangedEvent", 67, "onLobbyMaxMembersChanged");
            Add(lobby, "onLobbyPhotonGameChangedEvent", 68, "onLobbyPhotonGameChanged");
            Add(lobby, "onPlayerLeftLobbyEvent", 69, "onPlayerLeftLobby");
            Add(lobby, "onLobbyTypeChangedEvent", 70, "onLobbyTypeChanged");
            Add(lobby, "onLobbyMaxSpectatorsChangedEvent", 71, "onLobbyMaxSpectatorsChanged");
            Add(lobby, "onRevokeInviteToLobbyEvent", 72, "onRevokeInviteToLobby");
            Add(lobby, "onLobbyOwnerChangedEvent", 73, "onLobbyOwnerChanged");
            Add(lobby, "onPlayerKickedFromLobbyEvent", 74, "onPlayerKickedFromLobby");
            Add(lobby, "onRefuseInviteToLobbyEvent", 75, "onRefuseInviteToLobby");
            Add(lobby, "onNewSpectatorJoinedLobbyEvent", 76, "onNewSpectatorJoinedLobby");
            Add(lobby, "onNewSpectatorInvitedToLobbyEvent", 77, "onNewSpectatorInvitedToLobby");
            Add(lobby, "onLobbyPlayerTypeChangedEvent", 78, "onLobbyPlayerTypeChanged");
            Add(lobby, "onReceivedSpectatorInviteToLobbyEvent", 79, "onReceivedSpectatorInviteToLobby");
             Add(lobby, "onLobbyGameServerChangedEvent", 80, "onLobbyGameServerChanged");
            Add(lobby, "onLobbyNameChangedEvent", 81, "onLobbyNameChanged");

            const string gameEvent = "GameEventRemoteEventListener";
             Add(gameEvent, "onProgressSharedGameEvent", 0);
            Add(gameEvent, "onGamePassChanged", 1, "onGamePassChangedEvent");
             Add(gameEvent, "onProgressGameEvent", 2);
            Add(gameEvent, "onProgressChallengeEvent", 3);
            Add(gameEvent, "onSharedGameEventLevelAchieved", 4);

            const string inventory = "InventoryRemoteEventListener";
            Add(inventory, "onInventoryChangedEvent", 111, "onInventoryChanged");
            Add(inventory, "onCouponActivatedEvent", 112, "onCouponActivated");

            const string messages = "MessagesRemoteEventListener";
            Add(messages, "onMsgFromFriendEvent", 121, "onMsgFromFriend");

            const string ranked = "MatchmakingRemoteListener";
            Add(ranked, "onMatchmakingDone", 1, "onMatchmakingDoneEvent");
            Add(ranked, "onMatchmakingProgress", 2, "onMatchmakingProgressEvent");
            Add(ranked, "onPlayersConfirmed", 3, "onPlayersConfirmedEvent");
            Add(ranked, "onMatchmakingFail", 4, "onMatchmakingFailEvent");

            return result;
        }

        private static string EventKey(string listener, string eventName) =>
            (listener ?? string.Empty) + "\n" + (eventName ?? string.Empty);

        public static bool TryResolve(string listener, string eventName, out Spec spec) =>
            Specs.TryGetValue(EventKey(listener, eventName), out spec);

        public static void SelfTestOnce()
        {
            if (Interlocked.CompareExchange(ref _testState, 1, 0) != 0)
                 return;
            try
            {
                SelfTest();
            }
            catch
            {
                Volatile.Write(ref _testState, 0);
               throw;
            }
        }

       public static void SelfTest()
        {
            EventResponse source = Create(
                "MatchmakingRemoteEventListener",
                "onLobbyJoinableChanged",
                new object[] { true });
            if (source.Route != 62 || source.Params.Count != 1 || source.Params[0].IsNull || source.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 event envelope failed");

            byte[] frameBytes = new ResponseMessage { EventResponse = source }.ToByteArray();
            ResponseMessage parsed = ResponseMessage.Parser.ParseFrom(frameBytes);
            EventResponse roundTrip = parsed.EventResponse;
            if (roundTrip == null || roundTrip.Route != 62 ||
                roundTrip.ListenerName != "MatchmakingRemoteEventListener" ||
                roundTrip.EventName != "onLobbyJoinableChangedEvent" ||
                roundTrip.Params.Count != 1 || roundTrip.Params[0].One.Length == 0)
               throw new InvalidOperationException("0.33 event envelope protobuf round-trip failed");

            EventResponse progress = CreateRaw(
               "MatchmakingRemoteListener",
                "onMatchmakingProgress",
               new byte[] { 0x08, 0x14 });
            if (progress.Route != 2 || progress.ListenerName != "MatchmakingRemoteListener" ||
                progress.Params.Count != 1 || progress.Params[0].One.Length != 2)
                 throw new InvalidOperationException("0.33 ranked event route failed");

            EventResponse done = CreateRaw(
                "MatchmakingRemoteListener",
                "onMatchmakingDone",
                new byte[] { 0x0A, 0x00 });
            if (done.Route != 1)
                throw new InvalidOperationException("0.33 ranked done route failed");

           EventResponse lobbyType = Create(
                "MatchmakingRemoteEventListener",
                "onLobbyTypeChanged",
                new object[] { 2 });
             if (lobbyType.Route != 70 || lobbyType.Params.Count != 1 ||
                lobbyType.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 lobby event route failed");

             EventResponse chat = Create(
                "MatchmakingRemoteEventListener",
                "onLobbyChatMessage",
                 new object[] { "selftest", "hello" });
            if (chat.Route != 64 || chat.Params.Count != 1 ||
                chat.Params[0].One.Length == 0)
               throw new InvalidOperationException("0.33 lobby chat event route failed");

            EventResponse market = Create(
                "MarketplaceRemoteEventListener",
                "onTradeUpdated",
               new object[] { Array.Empty<byte>() });
             if (market.Route != 1 || market.Params.Count != 1)
                throw new InvalidOperationException("0.33 marketplace event route failed");
            EventResponse inventory = CreateRaw(
                "InventoryRemoteEventListener",
                "onInventoryChanged",
                Array.Empty<byte>());
           if (inventory.Route != 111 || inventory.Params.Count != 1)
                throw new InvalidOperationException("0.33 inventory event route failed");

            EventResponse gamePass = CreateRaw(
                "GameEventRemoteEventListener",
                "onGamePassChanged",
                Array.Empty<byte>());
            if (gamePass.Route != 1 || gamePass.Params.Count != 1)
                throw new InvalidOperationException("0.33 game-pass event route failed");

            EventResponse friend = Create(
                "FriendsRemoteEventListener",
                "onNewFriendshipRequestEvent",
                new object[] { new PlayerFriend(), "selftest" });
            if (friend.Route != 13 || friend.Params.Count != 1 ||
                friend.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 friendship request event route failed");

            EventResponse message = Create(
                "MessagesRemoteEventListener",
                 "onMsgFromFriendEvent",
                 new object[] { new UserMessage { SenderId = "selftest", Message = "hello", Timestamp = 1 } });
            if (message.Route != 121 || message.Params.Count != 1 ||
                message.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 direct-message event route failed");

            EventResponse clanInvite = Create(
                "ClansRemoteEventListener",
               "onInvitedToClanEvent",
                new object[] { new OnInvitedToClanEvent { RequestId = "selftest" } });
            if (clanInvite.Route != 44 || clanInvite.Params.Count != 1 ||
                clanInvite.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 clan invite event route failed");

            EventResponse clanProfile = CreateRaw(
                "ClansRemoteEventListener",
                "onPlayerAvatarChangedEvent",
                ContractWire.Build(w => { w.String(1, "selftest"); w.String(2, "avatar"); }));
            if (clanProfile.Route != 32 || clanProfile.Params.Count != 1 ||
                clanProfile.Params[0].One.Length == 0)
                 throw new InvalidOperationException("0.33 clan profile event route failed");

            EventResponse clanChat = Create(
                "ClanMessagesRemoteEventListener",
                "onIncomingClanChatMessage",
                new object[] { new ClanUserMessage() });
            if (clanChat.Route != 58 || clanChat.Params.Count != 1 ||
                clanChat.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 clan-chat event route failed");

            EventResponse globalChat = CreateRaw(
                "GlobalChatRemoteEventListener",
                 "onIncomingGlobalChatMessageEvent",
                ContractWire.Build(w => w.Message(1, ContractWire.Build(m =>
                {
                    m.String(1, "selftest");
                    m.String(2, "sender");
                    m.Varint(3, 1);
                }))));
            if (globalChat.Route != 0 || globalChat.Params.Count != 1 ||
                globalChat.Params[0].One.Length == 0)
                throw new InvalidOperationException("0.33 global-chat event route failed");

        }

        public static EventResponse CreateRaw(string listener, string eventName, byte[] payload)
        {
            if (!TryResolve(listener, eventName, out Spec spec))
                throw new InvalidOperationException($"Unknown 0.33 event contract {listener}.{eventName}");

            var response = new EventResponse
            {
                ListenerName = spec.Listener,
                EventName = spec.EventName,
                Route = spec.Route
            };
            response.Params.Add(new BinaryValue
            {
                IsNull = false,
                 One = ByteString.CopyFrom(payload ?? Array.Empty<byte>())
             });
            return response;
        }

        public static EventResponse CreateRawWithRoute(string listener, string eventName, uint route, byte[] payload)
        {
            if (!TryResolve(listener, eventName, out Spec spec))
                throw new InvalidOperationException($"Unknown 0.33 event contract {listener}.{eventName}");

            var response = new EventResponse
            {
                ListenerName = spec.Listener,
                EventName = spec.EventName,
                Route = route
            };
            response.Params.Add(new BinaryValue
            {
                IsNull = false,
                One = ByteString.CopyFrom(payload ?? Array.Empty<byte>())
            });
            return response;
        }

        public static EventResponse Create(string listener, string eventName, object[] parameters)
        {
            if (!TryResolve(listener, eventName, out Spec spec))
                throw new InvalidOperationException($"Unknown 0.33 event contract {listener}.{eventName}");

            byte[] payload = WritePayload(spec, parameters ?? Array.Empty<object>());
            var response = new EventResponse
           {
                ListenerName = spec.Listener,
                EventName = spec.EventName,
               Route = spec.Route
            };
            response.Params.Add(new BinaryValue
            {
                IsNull = false,
                One = ByteString.CopyFrom(payload)
           });
           return response;
        }

        private static byte[] WritePayload(Spec spec, object[] args)
        {
            if (args.Length == 1 && args[0] is IMessage exact &&
                string.Equals(exact.GetType().Name, MessageTypeName(spec.EventName), StringComparison.Ordinal))
                return exact.ToByteArray();

            if (string.Equals(spec.Listener, "ClansRemoteEventListener", StringComparison.Ordinal) &&
                args.Length == 1 && args[0] is IMessage exactClan)
                return exactClan.ToByteArray();

            string e = BaseEventName(spec.EventName);

            byte[] lobbyPayload = BuildLobbyPayload(e, args);
            if (lobbyPayload != null)
                return lobbyPayload;
             return ContractWire.Build(w =>
            {
                switch (e)
                {
                    case "onTradeUpdated":
                    case "onTradeRequestClosed":
                    case "onTradeRequestOpened":
                    case "onPlayerRequestOpened":
                        w.Message(1, MessageArg(args, 0));
                        break;
                    case "onPlayerRequestClosed":
                        w.Message(1, MessageArg(args, 0));
                        w.Message(2, MessageArg(args, 1));
                        break;

                    case "onPlayerStatusChanged":
                        w.String(1, StringValue(args, 0));
                        w.Message(2, MessageArg(args, 1));
                        break;
                    case "onFriendAvatarChanged":
                    case "onFriendNameChanged":
                        w.String(1, StringValue(args, 0));
                        w.String(2, StringValue(args, 1));
                       break;
                   case "onNewFriendshipRequest":
                    {
                        string requestMsg = StringValue(args, 1);
                        if (args.Length > 0 && args[0] is PlayerFriend requestFriend)
                            w.Message(1, SocialContract.SerializePlayerFriend(requestFriend, requestMsg));
                        else
                            w.Message(1, MessageArg(args, 0));
                        w.String(2, requestMsg);
                        break;
                    }
                    case "onFriendAdded":
                        w.Message(1, MessageArg(args, 0));
                        break;
                    case "onPlayerAttributesChanged":
                        w.String(1, StringValue(args, 0));
                        w.Message(2, MessageArg(args, 1));
                        break;
                    case "onFriendRemoved":
                    case "onRevokeFriendshipRequest":
                       w.String(1, StringValue(args, 0));
                        break;

                    case "OnJoinRequestCancelled":
                    case "onReadClosedInviteRequest":
                    case "onInviteRequestDeclined":
                    case "onClanMemberDeclinedRequest":
                    case "onJoinRequestDeclined":
                    case "OnInviteRequestCancelled":
                        break;
                    case "onClanDescriptionChanged":
                        w.String(1, StringValue(args, 0));
                        break;
                    case "onClanAvatarChanged":
                        w.String(1, StringValue(args, 0));
                        if (args.Length > 1)
                            w.Bytes(2, ByteValue(args, 1));
                        break;

                    case "onIncomingClanChatMessage":
                        w.Message(1, MessageArg(args, 0));
                        break;

                    case "onMsgFromFriend":
                        w.Message(1, MessageArg(args, 0));
                       break;

                    case "onLobbyDataChanged":
                   case "onLobbyPhotonGameChanged":
                    case "onLobbyGameServerChanged":
                    case "onNewPlayerJoinedLobby":
                    case "onNewSpectatorJoinedLobby":
                        w.Message(1, MessageArg(args, 0));
                        break;
                    case "onLobbyJoinableChanged":
                        w.Bool(1, BoolValue(args, 0), true);
                        break;
                    case "onLobbyMaxMembersChanged":
                    case "onLobbyMaxSpectatorsChanged":
                    case "onLobbyTypeChanged":
                        w.Int32(1, IntValue(args, 0), true);
                        break;
                    case "onLobbyChatMessage":
                    case "onLobbyPlayerTypeChanged":
                        w.String(1, StringValue(args, 0));
                        if (e == "onLobbyChatMessage") w.String(2, StringValue(args, 1));
                        else w.Int32(2, IntValue(args, 1), true);
                         break;
                    case "onNewPlayerInvitedToLobby":
                    case "onNewSpectatorInvitedToLobby":
                        w.String(1, StringValue(args, 0));
                        w.Message(2, MessageArg(args, 1));
                        break;
                    case "onReceivedInviteToLobby":
                    case "onReceivedSpectatorInviteToLobby":
                        w.Message(1, InviteValue(args));
                        break;
                   case "onPlayerLeftLobby":
                    case "onLobbyOwnerChanged":
                    case "onLobbyNameChanged":
                       w.String(1, StringValue(args, 0));
                        break;
                    case "onRevokeInviteToLobby":
                    case "onPlayerKickedFromLobby":
                    case "onRefuseInviteToLobby":
                        w.String(1, StringValue(args, 0));
                        w.String(2, StringValue(args, 1));
                        break;
                    default:
                        throw new InvalidOperationException("No exact payload writer for " + e);
                 }
            });
        }

        private static byte[] BuildLobbyPayload(string e, object[] args)
        {
            switch (e)
            {
                case "onLobbyJoinableChanged":
                    return new OnLobbyJoinableChangedEvent { Joinable = BoolValue(args, 0) }.ToByteArray();
                case "onLobbyMaxMembersChanged":
                    return new OnLobbyMaxMembersChangedEvent { MaxMembers = IntValue(args, 0) }.ToByteArray();
                case "onLobbyMaxSpectatorsChanged":
                     return new OnLobbyMaxSpectatorsChangedEvent { MaxSpectators = IntValue(args, 0) }.ToByteArray();
                case "onLobbyTypeChanged":
                    return new OnLobbyTypeChangedEvent { LobbyType = (LobbyType)IntValue(args, 0) }.ToByteArray();
                case "onLobbyDataChanged":
                    return new OnLobbyDataChangedEvent { Data = ReadMessage(Axlebolt.Bolt.Protobuf2.Dictionary.Parser, args, 0) }.ToByteArray();
                case "onLobbyPhotonGameChanged":
                    return new OnLobbyPhotonGameChangedEvent { PhotonGame = ReadMessage(Axlebolt.Bolt.Protobuf2.PhotonGame.Parser, args, 0) }.ToByteArray();
                case "onLobbyGameServerChanged":
                    return new OnLobbyGameServerChangedEvent { GameServer = ReadMessage(GameServer.Parser, args, 0) }.ToByteArray();
                case "onNewPlayerJoinedLobby":
                    return new OnNewPlayerJoinedLobbyEvent { NewPlayer = ReadMessage(PlayerFriend.Parser, args, 0) }.ToByteArray();
                case "onNewSpectatorJoinedLobby":
                    return new OnNewSpectatorJoinedLobbyEvent { NewSpectator = ReadMessage(PlayerFriend.Parser, args, 0) }.ToByteArray();
                case "onLobbyChatMessage":
                    return new OnLobbyChatMessageEvent { Gpid = StringValue(args, 0), Message = StringValue(args, 1) }.ToByteArray();
                case "onLobbyPlayerTypeChanged":
                    return new OnLobbyPlayerTypeChangedEvent { Gpid = StringValue(args, 0), PlayerType = (LobbyPlayerType)IntValue(args, 1) }.ToByteArray();
                case "onNewPlayerInvitedToLobby":
                    return new OnNewPlayerInvitedToLobbyEvent { InviteSenderGpid = StringValue(args, 0), NewPlayer = ReadMessage(PlayerFriend.Parser, args, 1) }.ToByteArray();
                case "onNewSpectatorInvitedToLobby":
                   return new OnNewSpectatorInvitedToLobbyEvent { InviteSenderGpid = StringValue(args, 0), NewSpectator = ReadMessage(PlayerFriend.Parser, args, 1) }.ToByteArray();
                case "onReceivedInviteToLobby":
                    return new OnReceivedInviteToLobbyEvent { Invite = ReadMessage(LobbyInvite.Parser, args, 0) }.ToByteArray();
                case "onReceivedSpectatorInviteToLobby":
                    return new OnReceivedSpectatorInviteToLobbyEvent { Invite = ReadMessage(LobbyInvite.Parser, args, 0) }.ToByteArray();
                case "onPlayerLeftLobby":
                    return new OnPlayerLeftLobbyEvent { LeftGpid = StringValue(args, 0) }.ToByteArray();
                case "onLobbyOwnerChanged":
                    return new OnLobbyOwnerChangedEvent { LobbyOwnerGpid = StringValue(args, 0) }.ToByteArray();
                case "onLobbyNameChanged":
                    return new OnLobbyNameChangedEvent { Name = StringValue(args, 0) }.ToByteArray();
                case "onRevokeInviteToLobby":
                    return new OnRevokeInviteToLobbyEvent { InviteSenderGpid = StringValue(args, 0), InvitedGpid = StringValue(args, 1) }.ToByteArray();
                case "onPlayerKickedFromLobby":
                    return new OnPlayerKickedFromLobbyEvent { KickInitiatorGpid = StringValue(args, 0), KickedGpid = StringValue(args, 1) }.ToByteArray();
                case "onRefuseInviteToLobby":
                   return new OnRefuseInviteToLobbyEvent { InviteSenderGpid = StringValue(args, 0), InvitedGpid = StringValue(args, 1) }.ToByteArray();
                default:
                    return null;
            }
        }

         private static T ReadMessage<T>(MessageParser<T> parser, object[] args, int index) where T : IMessage<T>
       {
            if (index < 0 || index >= args.Length || args[index] == null) return default(T);
            if (args[index] is T typed) return typed;
            if (args[index] is byte[] raw) return parser.ParseFrom(raw);
            if (args[index] is ByteString bytes) return parser.ParseFrom(bytes);
            if (args[index] is IMessage message) return parser.ParseFrom(message.ToByteArray());
            throw new InvalidOperationException($"Cannot convert lobby event argument {index} ({args[index].GetType().FullName}) to {typeof(T).FullName}");
         }

        private static string BaseEventName(string eventName)
        {
            if (string.IsNullOrEmpty(eventName)) return string.Empty;
            return eventName.EndsWith("Event", StringComparison.Ordinal)
                ? eventName.Substring(0, eventName.Length - "Event".Length)
                : eventName;
        }

        private static string MessageTypeName(string eventName)
        {
           if (string.IsNullOrEmpty(eventName)) return string.Empty;
           string name = char.ToUpperInvariant(eventName[0]) + eventName.Substring(1);
            if (name.EndsWith("Event", StringComparison.Ordinal)) return name;
            return string.Equals(name, "OnPlayerAttributesChanged", StringComparison.Ordinal)
               ? name
                : name + "Event";
        }

        private static byte[] MessageArg(object[] args, int index)
        {
            if (index < 0 || index >= args.Length || args[index] == null) return Array.Empty<byte>();
            if (args[index] is byte[] raw) return raw;
            if (args[index] is IMessage message) return SocialContract.SerializeMessage(message);
            throw new InvalidOperationException($"Expected IMessage/byte[] event argument {index}, got {args[index].GetType().FullName}");
        }

        private static string StringValue(object[] args, int index)
        {
            if (index < 0 || index >= args.Length || args[index] == null) return string.Empty;
            return args[index] as string ?? Convert.ToString(args[index]) ?? string.Empty;
        }

        private static int IntValue(object[] args, int index)
        {
            if (index < 0 || index >= args.Length || args[index] == null) return 0;
            return Convert.ToInt32(args[index]);
        }

        private static bool BoolValue(object[] args, int index)
        {
            if (index < 0 || index >= args.Length || args[index] == null) return false;
            return Convert.ToBoolean(args[index]);
        }

        private static byte[] ByteValue(object[] args, int index)
        {
            if (index < 0 || index >= args.Length || args[index] == null) return Array.Empty<byte>();
            if (args[index] is byte[] raw) return raw;
           if (args[index] is ByteString bytes) return bytes.ToByteArray();
            throw new InvalidOperationException($"Expected byte[]/ByteString event argument {index}, got {args[index].GetType().FullName}");
        }

        private static byte[] InviteValue(object[] args)
        {
            if (args.Length > 0 && args[0] is LobbyInvite invite)
            {
                string lobbyName = string.Empty;
                if (!string.IsNullOrWhiteSpace(invite.LobbyId) &&
                    ServerState.Lobbies.TryGetValue(invite.LobbyId, out BoltLobby lobby) &&
                    lobby != null)
                {
                    lobbyName = lobby.Name ?? string.Empty;
                }
                return SocialContract.SerializeLobbyInvite(invite, lobbyName);
             }
            if (args.Length > 0 && args[0] is IMessage exactInvite)
                return SocialContract.SerializeMessage(exactInvite);
            IMessage sender = args.Length > 0 ? args[0] as IMessage : null;
            string lobbyId = StringValue(args, 1);
            return ContractWire.Build(w =>
            {
                w.String(1, lobbyId);
                w.Message(2, sender == null ? null : SocialContract.SerializeMessage(sender));
                w.Int32(4, 0, true);
            });
        }
    }
}
