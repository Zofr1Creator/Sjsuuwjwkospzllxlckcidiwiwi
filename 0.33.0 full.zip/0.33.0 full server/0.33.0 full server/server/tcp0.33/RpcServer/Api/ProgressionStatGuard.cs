using System;
using System.Collections.Generic;

namespace TspServer.RpcServer.Api
{

    internal static class ProgressionStatGuard
    {
        private static readonly HashSet<string> KnownNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "xp_reworked", "level", "level_id", "player_level", "account_xp",

              "ranked_ban_reason",  "ranked_banned_until", "ranked_ban_code", "ranked_ban_duration", "ranked_banned_match_no"
         };

        public static bool IsServerOwned(string name)
        {
             if (string.IsNullOrWhiteSpace(name)) return false;
            if (KnownNames.Contains(name)) return true;
            return name.StartsWith("ranked_", StringComparison.OrdinalIgnoreCase) ||
                   name.StartsWith("ranked2v2_", StringComparison.OrdinalIgnoreCase) ||
                   name.StartsWith("ranked_2v2_", StringComparison.OrdinalIgnoreCase) ||
                   name.StartsWith("ranked_duel_", StringComparison.OrdinalIgnoreCase);
        }
    }
}
