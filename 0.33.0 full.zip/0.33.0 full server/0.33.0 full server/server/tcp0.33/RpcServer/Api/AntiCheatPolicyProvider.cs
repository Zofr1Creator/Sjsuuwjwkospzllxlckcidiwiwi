using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{
    internal sealed class AntiCheatPolicy
    {
        public bool Enabled { get; init; } = true;

        public bool RequireVerification { get; init; } = true;
        
        public bool RequireHashes { get; init; } = true;
        
        public bool RequireKnownHashes { get; init; }
        
        public IReadOnlyList<string> AllowedApkHashes { get; init; } = Array.Empty<string>();
        
        public IReadOnlyList<string> AllowedContentHashes { get; init; } = Array.Empty<string>();
        
        public bool RejectRooted { get; init; } = true;
        
        public bool RejectForbiddenApps { get; init; } = true;
        
        public bool BanOnAuthViolation { get; init; } = true;

        public bool NativeBanUi { get; init; } = true;
        
        public int BanCode { get; init; } = 1;
        
        public long BanSeconds { get; init; }

        public int CacheSeconds { get; init; } = 15;

        public bool MatchEnabled { get; init; } = true;
        
        public int SecurityScoreThreshold { get; init; } = 35;
        
        public int SecurityReviewThreshold { get; init; } = 10;
        
        public int SecurityBanThreshold { get; init; } = 35;
        
        public int ScoreWindowSeconds { get; init; } = 60;
        
        public double ScoreDecayPerSecond { get; init; } = 0.35;
        
        public int StrongEvidenceHitsToBan { get; init; } = 2;
        
        public int LiveBanKickDelayMs { get; init; } = 900;

        public int MaxCachedEventsPerActor { get; init; } = 256;
        
        public int MaxCachedEventsPerRoom { get; init; } = 1024;
        
        public int MaxEventsPerSecond { get; init; } = 180;
        
        public int MaxPropertyWritesPerSecond { get; init; } = 30;
        
        public int MaxWireDepth { get; init; } = 8;
        public int MaxArrayItems { get; init; } = 512;
        public int MaxMapEntries { get; init; } = 256;
        public int MaxStringLength { get; init; } = 2048;
        public int MaxBinaryBytes { get; init; } = 65536;
    }

    internal static class AntiCheatPolicyProvider
    {
        private const string ConfigCollection = "server_config";
        private const string ConfigId = "anti_cheat";

        private static readonly object _sync = new();
        
        private static AntiCheatPolicy _cached = Defaults();
        
        private static DateTime _expiresUtc = DateTime.MinValue;

        public static AntiCheatPolicy Current
        {
            get
            {
                lock (_sync)
                {
                    if (DateTime.UtcNow < _expiresUtc)
                        return _cached;

                    _cached = Load();
                    _expiresUtc = DateTime.UtcNow.AddSeconds(
                        Math.Clamp(_cached.CacheSeconds, 2, 300));

                    return _cached;
                }
            }
        }

        public static AntiCheatPolicy Refresh()
        {
            lock (_sync)
            {
                _expiresUtc = DateTime.MinValue;
                return Current;
            }
        }

        private static AntiCheatPolicy Load()
        {
            AntiCheatPolicy fallback = Defaults();

            try
            {
                BoltMainDatabaseProvider provider = BoltMainDatabaseProvider.Instance;
                if (provider == null)
                    return fallback;

                IMongoCollection<BsonDocument> collection = provider.GetDatabase()
                    .GetCollection<BsonDocument>(ConfigCollection);

                BsonDocument document = collection
                    .Find(Builders<BsonDocument>.Filter.Eq("_id", ConfigId))
                    .FirstOrDefault();

                if (document == null)
                    return fallback;

                return Parse(document, fallback);
            }
            catch
            {
                return fallback;
            }
        }

        private static AntiCheatPolicy Defaults()
        {
            return new AntiCheatPolicy
            {
                BanCode = ServerOptions.Current.AntiCheatBanCode,
                BanSeconds = ServerOptions.Current.AntiCheatBanSeconds
            };
        }

        private static AntiCheatPolicy Parse(BsonDocument document, AntiCheatPolicy fallback)
        {
            BsonDocument auth = Section(document, "auth");
            BsonDocument sanctions = Section(document, "sanctions");
            BsonDocument match = Section(document, "match");

            return new AntiCheatPolicy
            {
                Enabled = ReadBool(document, "enabled", fallback.Enabled),
                CacheSeconds = ReadInt(document, "cacheSeconds", fallback.CacheSeconds, 2, 300),

                RequireVerification = ReadBool(auth, "requireVerification", fallback.RequireVerification),
                RequireHashes = ReadBool(auth, "requireHashes", fallback.RequireHashes),
                RequireKnownHashes = ReadBool(auth, "requireKnownHashes", fallback.RequireKnownHashes),
                AllowedApkHashes = ReadStrings(auth, "allowedApkHashes"),
                AllowedContentHashes = ReadStrings(auth, "allowedContentHashes"),
                RejectRooted = ReadBool(auth, "rejectRooted", fallback.RejectRooted),
                RejectForbiddenApps = ReadBool(auth, "rejectForbiddenApps", fallback.RejectForbiddenApps),
                BanOnAuthViolation = ReadBool(auth, "banOnViolation", fallback.BanOnAuthViolation),

                NativeBanUi = ReadBool(sanctions, "nativeBanUi", fallback.NativeBanUi),
                BanCode = ReadInt(sanctions, "banCode", fallback.BanCode, 1, 1_000_000),
                BanSeconds = ReadLong(
                    sanctions,
                    "banSeconds",
                    fallback.BanSeconds,
                    0,
                    3650L * 24 * 60 * 60),

                MatchEnabled = ReadBool(match, "enabled", fallback.MatchEnabled),
                SecurityScoreThreshold = ReadInt(
                    match, "securityScoreThreshold", fallback.SecurityScoreThreshold, 10, 100),
                SecurityReviewThreshold = ReadInt(
                    match, "securityReviewThreshold", fallback.SecurityReviewThreshold, 1, 100),
                SecurityBanThreshold = ReadInt(
                    match, "securityBanThreshold", fallback.SecurityBanThreshold, 10, 200),
                ScoreWindowSeconds = ReadInt(
                    match, "scoreWindowSeconds", fallback.ScoreWindowSeconds, 10, 600),
                ScoreDecayPerSecond = ReadDouble(
                    match, "scoreDecayPerSecond", fallback.ScoreDecayPerSecond, 0.0, 10.0),
                StrongEvidenceHitsToBan = ReadInt(
                    match, "strongEvidenceHitsToBan", fallback.StrongEvidenceHitsToBan, 2, 10),
                LiveBanKickDelayMs = ReadInt(
                    match, "liveBanKickDelayMs", fallback.LiveBanKickDelayMs, 250, 5000),

                MaxCachedEventsPerActor = ReadInt(
                    match, "maxCachedEventsPerActor", fallback.MaxCachedEventsPerActor, 16, 4096),
                MaxCachedEventsPerRoom = ReadInt(
                    match, "maxCachedEventsPerRoom", fallback.MaxCachedEventsPerRoom, 64, 16384),
                MaxEventsPerSecond = ReadInt(
                    match, "maxEventsPerSecond", fallback.MaxEventsPerSecond, 10, 5000),
                MaxPropertyWritesPerSecond = ReadInt(
                    match, "maxPropertyWritesPerSecond", fallback.MaxPropertyWritesPerSecond, 5, 1000),
                MaxWireDepth = ReadInt(
                    match, "maxWireDepth", fallback.MaxWireDepth, 2, 32),
                MaxArrayItems = ReadInt(
                    match, "maxArrayItems", fallback.MaxArrayItems, 16, 8192),
                MaxMapEntries = ReadInt(
                    match, "maxMapEntries", fallback.MaxMapEntries, 16, 4096),
                MaxStringLength = ReadInt(
                    match, "maxStringLength", fallback.MaxStringLength, 128, 65536),
                MaxBinaryBytes = ReadInt(
                    match, "maxBinaryBytes", fallback.MaxBinaryBytes, 1024, 1048576)
            };
        }

        private static BsonDocument Section(BsonDocument document, string key)
        {
            if (document.TryGetValue(key, out BsonValue value) && value.IsBsonDocument)
                return value.AsBsonDocument;

            return new BsonDocument();
        }

        private static IReadOnlyList<string> ReadStrings(BsonDocument document, string key)
        {
            if (!document.TryGetValue(key, out BsonValue value) || !value.IsBsonArray)
                return Array.Empty<string>();

            var result = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (BsonValue item in value.AsBsonArray)
            {
                if (!item.IsString)
                    continue;

                string text = item.AsString.Trim();
                if (text.Length == 0 || !seen.Add(text))
                    continue;

                result.Add(text);
            }

            return result.ToArray();
        }

        private static bool ReadBool(BsonDocument document, string key, bool fallback)
        {
            if (!document.TryGetValue(key, out BsonValue value) || !value.IsBoolean)
                return fallback;

            return value.AsBoolean;
        }

        private static int ReadInt(
            BsonDocument document,
            string key,
            int fallback,
            int min,
            int max)
        {
            if (!document.TryGetValue(key, out BsonValue value) || !value.IsNumeric)
                return fallback;

            try
            {
                return Math.Clamp(value.ToInt32(), min, max);
            }
            catch
            {
                return fallback;
            }
        }

        private static long ReadLong(
            BsonDocument document,
            string key,
            long fallback,
            long min,
            long max)
        {
            if (!document.TryGetValue(key, out BsonValue value) || !value.IsNumeric)
                return fallback;

            try
            {
                return Math.Clamp(value.ToInt64(), min, max);
            }
            catch
            {
                return fallback;
            }
        }

        private static double ReadDouble(
            BsonDocument document,
            string key,
            double fallback,
            double min,
            double max)
        {
            if (!document.TryGetValue(key, out BsonValue value) || !value.IsNumeric)
                return fallback;

            try
            {
                return Math.Clamp(value.ToDouble(), min, max);
            }
            catch
            {
                return fallback;
            }
        }
    }
}
