using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{
    [BsonIgnoreExtraElements]
    public sealed class BattlePassPlayerStateDocument
    {
        [BsonId] public ObjectId Id { get; set; }
        
        public string PlayerId { get; set; }
        
        public string EventId { get; set; }
        
        public int Points { get; set; }
        
        public Dictionary<string, int> Levels { get; set; } = new();
        
        public List<string> ClaimedRewards { get; set; } = new();
        
        public Dictionary<string, int> ChallengePoints { get; set; } = new();
        
        public List<string> CompletedChallenges { get; set; } = new();
        
        public DateTime UpdatedAtUtc { get; set; }
    }
    [BsonIgnoreExtraElements]
    public sealed class BattlePassMatchSnapshotDocument
    {
        [BsonId] public ObjectId Id { get; set; }
        public string PlayerId { get; set; }
        public string EventId { get; set; }
        public string MatchId { get; set; }
        public int Kills { get; set; }
        public int Headshots { get; set; }
        public bool MatchCredited { get; set; }
        public bool WinCredited { get; set; }
        public Dictionary<string, int> BaselineChallengePoints { get; set; } = new();
        public DateTime UpdatedAtUtc { get; set; }
    }
    internal sealed class BattlePassMissionSettlementResult
    {
        public int KillDelta { get; set; }
        public int HeadshotDelta { get; set; }
        public int MatchDelta { get; set; }
        public int WinDelta { get; set; }
        public int EventPointsAwarded { get; set; }
        public int EventPointsTotal { get; set; }
        public Reward Reward { get; set; } = new();
       public List<string> ChangedChallenges { get; set; } = new();
        public List<string> CompletedChallenges { get; set; } = new();
   }

    [BsonIgnoreExtraElements]
    public sealed class BattlePassChallengeDocument
    {
        [BsonId] public string Id { get; set; }
        public string EventId { get; set; }
        public string Code { get; set; }
        public string Action { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public int FromDay { get; set; }
        public int ToDay { get; set; }
        public int TargetPoints { get; set; }
        public int EventPoints { get; set; }
        public int KeyItemDefinitionId { get; set; }
       public Dictionary<string, int> RewardCurrencies { get; set; } = new(StringComparer.Ordinal);
       public Dictionary<string, int> RewardItems { get; set; } = new(StringComparer.Ordinal);
    }

    internal sealed class BattlePassDefinition
    {
        public string Id { get; set; }
        public string Code { get; set; }
        public long DateSince { get; set; }
        public long DateUntil { get; set; }
        public int DurationDays { get; set; }
        public int CurrentDay { get; set; }
        public int GoldPassItemDefinitionId { get; set; }
        public Dictionary<string, List<GamePassLevel>> Passes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
     }

    internal static class BattlePassRuntime
     {
       private static readonly ConcurrentDictionary<string, string> _activeMatches = new(StringComparer.Ordinal);
        private const string StateCollection = "battle_pass_player_states";

       private const string ChallengeCollection = "battle_pass_challenges";

        private const string SnapshotCollection = "battle_pass_match_snapshots";

        public const string CanonicalPreyEventId = "prey";

        public const string CanonicalPreyCode = "PREY";

        public const int PreyCollectionId = 56;

        public const int FallbackGoldPassItemDefinitionId = 625;

        public const int PreyBoxItemDefinitionId = 350;

        public const int PreyCaseItemDefinitionId = 351;

        public const int PreyArcaneCaseItemDefinitionId = 358;

        public const int PreyStickerPackItemDefinitionId = 724;

        public const int PreyGraffitiPackItemDefinitionId = 725;

        public const int PreyCharmPackItemDefinitionId = 726;

        private static readonly string[] _preyAliases = { "prey" };

        private static readonly string[] _eventLookupCodes = { "PREY", "Prey", "prey" };

        private const int MaxProgressPerCall = 100000;

       public const int FallbackPreyLevelCount = 450;

       public const int PreyPointsPerLevel = 1000;

        private static readonly ConcurrentDictionary<string, object> _playerLocks = new();

        private static readonly object _definitionLock = new();

        private static BattlePassDefinition _cachedDefinition;

         private static DateTime _definitionCacheUntilUtc;

        private static IMongoDatabase Db
        {
            get
            {
                 BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                if (provider == null)
                    throw new InvalidOperationException("game database unavailable");

                return provider.GetDatabase();
             }
        }

        private static IMongoCollection<BattlePassPlayerStateDocument> States => Db.GetCollection<BattlePassPlayerStateDocument>(StateCollection);
        private static IMongoCollection<BattlePassChallengeDocument> Challenges => Db.GetCollection<BattlePassChallengeDocument>(ChallengeCollection);
        private static IMongoCollection<BattlePassMatchSnapshotDocument> MatchSnapshots => Db.GetCollection<BattlePassMatchSnapshotDocument>(SnapshotCollection);

        public static object LockForPlayer(string playerId)
         {
            return _playerLocks.GetOrAdd(playerId ?? string.Empty, _ => new());
        }

        private static long UnixSeconds(long value)
        {
            if (value <= 0) return value;
            return value >= 100000000000L ? value / 1000L : value;
        }

        public static BattlePassDefinition GetDefinition()
        {
             lock (_definitionLock)
            {
                if (_cachedDefinition != null && DateTime.UtcNow < _definitionCacheUntilUtc)
                    return _cachedDefinition;
            }
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            try
            {
                BoltGameEventDocument source = null;
                foreach (string candidate in _eventLookupCodes)
                {
                    try
                    {
                        source = BoltGameDatabaseProvider.Instance.GetGameEvent(candidate);
                       if (source != null) break;
                    }
                    catch { }
                }
               if (source != null && source.enabled && source.levels != null && source.levels.Count > 0)
                {
                    var parsed = BoltGameEventDocument.GetByDocument(source.levels);
                    int durationDays = source.durationDays > 0 ? source.durationDays : 56;
                    long sourceSince = UnixSeconds(source.dateSince);
                    long sourceUntil = UnixSeconds(source.dateUntil);
                    bool sourceActive = sourceSince > 0 && sourceSince <= now && sourceUntil > now;
                    long activeSince = sourceActive ? sourceSince : now - 86400L;
                    long activeUntil = sourceActive ? sourceUntil : activeSince + (long)durationDays * 86400L;
                    var definition = new BattlePassDefinition
                    {
                        Id = CanonicalPreyEventId,
                        Code = CanonicalPreyCode,
                        DateSince = activeSince,
                        DateUntil = activeUntil,
                        DurationDays = durationDays,
                        GoldPassItemDefinitionId = source.goldPassItem > 0 ? source.goldPassItem : FallbackGoldPassItemDefinitionId
                    };
                    definition.CurrentDay = GetCurrentDay(definition, now);
                    foreach (var pair in parsed)
                     {
                        definition.Passes[NormalizePassCode(pair.Key)] = pair.Value.GetGamePassLevelsProto()
                             .OrderBy(x => x.Level)
                            .ToList();
                    }
                    EnsureTracks(definition);
                   return Cache(definition);
                }
            }
            catch
            {
           }

            var fallback = BuildFallbackDefinition(now);
            return Cache(fallback);
        }

        private static BattlePassDefinition Cache(BattlePassDefinition definition)
        {
            lock (_definitionLock)
            {
                _cachedDefinition = definition;
                _definitionCacheUntilUtc = DateTime.UtcNow.AddSeconds(60);
                return _cachedDefinition;
            }
        }

        private static bool HasReward(GamePassLevel level)
        {
            if (level?.Reward == null) return false;
            return (level.Reward.Items != null && level.Reward.Items.Count > 0) ||
            (level.Reward.Currencies != null && level.Reward.Currencies.Count > 0);
        }

        private static bool HasFullTrack(List<GamePassLevel> track)
        {
            if (track == null || track.Count < FallbackPreyLevelCount) return false;
            return track.Take(FallbackPreyLevelCount).All(HasReward);
        }

        private static void EnsureTracks(BattlePassDefinition definition)
         {
            definition.Passes["FreePass"] = BuildPreyLevels(false);

            if (!definition.Passes.TryGetValue("GoldPass", out List<GamePassLevel> gold) ||
                !HasFullTrack(gold))
                definition.Passes["GoldPass"] = BuildPreyLevels(true);
        }

        private static string NormalizePassCode(string code)
        {
            if (string.Equals(code, "freePass", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(code, "free", StringComparison.OrdinalIgnoreCase))
                return "FreePass";
            if (string.Equals(code, "goldPass", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(code, "gold", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(code, "premium", StringComparison.OrdinalIgnoreCase))
                return "GoldPass";
            return string.IsNullOrWhiteSpace(code) ? "FreePass" : code;
        }

       private static BattlePassDefinition BuildFallbackDefinition(long now)
        {
            var result = new BattlePassDefinition
            {
                Id = CanonicalPreyEventId,
                Code = CanonicalPreyCode,
                DateSince = now - 86400L,
                DateUntil = now + 56L * 86400L,
                DurationDays = 57,
               CurrentDay = 1,
                 GoldPassItemDefinitionId = FallbackGoldPassItemDefinitionId
            };
            result.Passes["FreePass"] = BuildPreyLevels(false);
            result.Passes["GoldPass"] = BuildPreyLevels(true);
            return result;
         }

        internal static List<GamePassLevel> BuildPreyLevels(bool premium)
        {
            var levels = new List<GamePassLevel>(FallbackPreyLevelCount);

            int[] packs = { PreyStickerPackItemDefinitionId, PreyGraffitiPackItemDefinitionId, PreyCharmPackItemDefinitionId };
           int[] skins = { 240166,240167,240168,240169,240170,240171,240172,240173,240174,240175,240176,240177 };
            int[] statTrackSkins = { 1240166,1240167,1240168,1240169,1240170,1240171,1240172,1240173,1240174,1240175,1240176,1240177 };
            int[] stickers = { 1575,1576,1577,1578,1579,1580,1581,1582,1583,1584,1585,1586 };
            int[] charms = { 5308,5309,5310,5311,5312,5313,5314,5315,5316,5317,5318,5319 };
            int[] gloves = { 3041,3042,3043,3044,3045,3046 };

            var goldMedals = new Dictionary<int, int>
            {
                [75] = 352,
                [150] = 353,
                [225] = 354,
                [300] = 355,
                [375] = 356,
                [450] = 357
            };

            for (int level = 1; level <= FallbackPreyLevelCount; level++)
            {
                var reward = new RewardInfo();
               int minPoints = (level - 1) * PreyPointsPerLevel;

                if (!premium)
                {
                    if (level % 30 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyCaseItemDefinitionId, Value = 1 });
                    }
                    else if (level % 20 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = skins[(level / 20 - 1) % skins.Length], Value = 1 });
                    }
                    else if (level % 15 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyBoxItemDefinitionId, Value = 1 });
                    }
                    else if (level % 10 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = packs[(level / 10 - 1) % packs.Length], Value = 1 });
                    }
                    else if (level % 8 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = charms[(level / 8 - 1) % charms.Length], Value = 1 });
                    }
                    else if (level % 6 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyCharmPackItemDefinitionId, Value = 1 });
                    }
                    else if (level % 4 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = stickers[(level / 4 - 1) % stickers.Length], Value = 1 });
                   }
                    else if (level % 2 == 0)
                    {

                        int selector = (level / 2) % 3;
                        if (selector == 0)
                            reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyStickerPackItemDefinitionId, Value = 1 });
                       else if (selector == 1)
                            reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyGraffitiPackItemDefinitionId, Value = 1 });
                        else
                            reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = stickers[(level / 2 - 1) % stickers.Length], Value = 1 });
                    }
                    else
                    {

                       int silver = 50 + ((level / 25) % 4) * 25;
                        reward.Currencies.Add(new CurrencyAmount { CurrencyId = 101, Value = silver });
                    }

                    if (level % 75 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyCaseItemDefinitionId, Value = 1 });
                        reward.Currencies.Add(new CurrencyAmount { CurrencyId = 102, Value = 5 });
                    }
                }
                else
                {

                    if (goldMedals.TryGetValue(level, out int medalId))
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = medalId, Value = 1 });
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyArcaneCaseItemDefinitionId, Value = 1 });
                    }
                    else if (level % 60 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = gloves[(level / 60 - 1) % gloves.Length], Value = 1 });
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyArcaneCaseItemDefinitionId, Value = 1 });
                    }
                    else if (level % 40 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyArcaneCaseItemDefinitionId, Value = 1 });
                    }
                    else if (level % 25 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = statTrackSkins[(level / 25 - 1) % statTrackSkins.Length], Value = 1 });
                    }
                    else if (level % 10 == 0)
                    {
                         reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = skins[(level / 10 - 1) % skins.Length], Value = 1 });
                    }
                    else if (level % 5 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyCaseItemDefinitionId, Value = 1 });
                    }
                    else if (level % 3 == 0)
                    {
                       reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyBoxItemDefinitionId, Value = 1 });
                    }
                    else if (level % 2 == 0)
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyCharmPackItemDefinitionId, Value = 1 });
                    }
                    else
                    {
                        reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = PreyStickerPackItemDefinitionId, Value = 1 });
                    }

                    if (level % 20 == 0)
                        reward.Currencies.Add(new CurrencyAmount { CurrencyId = 101, Value = 150 });
                    if (level % 50 == 0)
                       reward.Currencies.Add(new CurrencyAmount { CurrencyId = 102, Value = 10 });
                }

                if (!HasReward(new GamePassLevel { Reward = reward }))
                    reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = premium ? PreyStickerPackItemDefinitionId : stickers[(level - 1) % stickers.Length], Value = 1 });

                levels.Add(new GamePassLevel
                {
                    Level = level,
                    MinPoints = minPoints,
                    Reward = reward
                });
            }
            return levels;
        }

        public static IReadOnlyList<string> GetPreyWireAliases() => _preyAliases;

        public static bool MatchesEventIdOrCode(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return true;
            if (string.Equals(value, CanonicalPreyEventId, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(value, CanonicalPreyCode, StringComparison.OrdinalIgnoreCase)) return true;
            return _preyAliases.Any(x => string.Equals(x, value, StringComparison.OrdinalIgnoreCase));
        }

        public static BattlePassDefinition BuildWireDefinition(BattlePassDefinition source, string wireCode)
       {
            string id = string.IsNullOrWhiteSpace(wireCode) ? CanonicalPreyEventId : wireCode;
            return new BattlePassDefinition
            {
                Id = id,
                Code = CanonicalPreyCode,
                 DateSince = source.DateSince,
                DateUntil = source.DateUntil,
               DurationDays = source.DurationDays,
                CurrentDay = source.CurrentDay,
                GoldPassItemDefinitionId = source.GoldPassItemDefinitionId,
                Passes = source.Passes
            };
        }

        public static string NormalizeBattlePassCode(BattlePassDefinition definition, string passIdOrCode)
        {
            if (string.IsNullOrWhiteSpace(passIdOrCode)) return "FreePass";
            string value = passIdOrCode.Trim();
            int colon = value.LastIndexOf(':');
            if (colon >= 0 && colon + 1 < value.Length) value = value.Substring(colon + 1);
            return NormalizePassCode(value);
        }

        private static int GetCurrentDay(BattlePassDefinition definition, long nowSeconds)
        {
            if (definition.DateSince <= 0) return 1;
            long elapsed = Math.Max(0, nowSeconds - definition.DateSince);
            int day = (int)(elapsed / 86400L) + 1;
            int max = Math.Max(1, definition.DurationDays);
            return Math.Max(1, Math.Min(day, max));
        }

        public static BattlePassPlayerStateDocument GetState(string playerId, BattlePassDefinition definition)
        {
            var filter = Builders<BattlePassPlayerStateDocument>.Filter.Where(x => x.PlayerId == playerId && x.EventId == definition.Id);
            var state = States.Find(filter).FirstOrDefault();
            if (state != null)
           {
                FixState(state);
                MigrateChallengeIds(state, definition);
                return state;
            }

            state = new BattlePassPlayerStateDocument
            {
                Id = ObjectId.GenerateNewId(),
                PlayerId = playerId,
                EventId = definition.Id,
                Points = 0,
                Levels = new Dictionary<string, int> { ["FreePass"] = 1, ["GoldPass"] = 1 },
                ClaimedRewards = new(),
                ChallengePoints = new(),
                CompletedChallenges = new(),
                UpdatedAtUtc = DateTime.UtcNow
            };
            try
            {
                States.InsertOne(state);
            }
            catch (MongoWriteException)
            {
               state = States.Find(filter).First();
                FixState(state);
                MigrateChallengeIds(state, definition);
            }
            return state;
        }

        private static void FixState(BattlePassPlayerStateDocument state)
        {
            state.Levels = state.Levels ?? new();
            state.ClaimedRewards = state.ClaimedRewards ?? new();
            state.ChallengePoints = state.ChallengePoints ?? new();
            state.CompletedChallenges = state.CompletedChallenges ?? new();
            if (!state.Levels.ContainsKey("FreePass") || state.Levels["FreePass"] < 1) state.Levels["FreePass"] = 1;
            if (!state.Levels.ContainsKey("GoldPass") || state.Levels["GoldPass"] < 1) state.Levels["GoldPass"] = 1;
        }

        public static void SaveState(BattlePassPlayerStateDocument state)
        {
            state.UpdatedAtUtc = DateTime.UtcNow;
            States.ReplaceOne(x => x.Id == state.Id, state, new ReplaceOptions { IsUpsert = true });
        }

        public static CurrentGameEvent BuildCurrentGameEvent(string playerId, BattlePassDefinition definition, BattlePassPlayerStateDocument state)
        {
            UpdateLevelsOnly(state, definition);
             var current = new CurrentGameEvent
            {
                Id = definition.Id,
                Code = definition.Code,
                DateSince = definition.DateSince,
                DateUntil = definition.DateUntil,
                 DurationDays = definition.DurationDays,
                CurrentDay = definition.CurrentDay,
                Points = state.Points
            };

            foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
           {
                int currentLevel = state.Levels.TryGetValue(pass.Key, out int value) ? value : 0;
                var protoPass = new GamePass
                {
                    Id = definition.Id + ":" + pass.Key,
                    Code = pass.Key,
                    KeyItemDefinitionId = pass.Key == "GoldPass" ? definition.GoldPassItemDefinitionId : 0,
                    CurrentLevel = currentLevel
                };
                protoPass.Levels.Add(pass.Value.Select(x => x.Clone()));
                current.GamePasses.Add(protoPass);
            }
            return current;
        }

        public static int GetCurrentPassLevel(BattlePassPlayerStateDocument state, BattlePassDefinition definition, string passCode)
        {
            if (state == null || definition == null || !definition.Passes.TryGetValue(passCode, out List<GamePassLevel> levels) || levels == null || levels.Count == 0)
                return 1;
            int maxLevel = Math.Max(1, levels.Max(x => x.Level));

            int calculated = checked((int)Math.Min(maxLevel, Math.Max(1L, ((long)Math.Max(0, state.Points) / PreyPointsPerLevel) + 1L)));
            return calculated;
        }
        public static int GetVisibleLevelPoints(BattlePassPlayerStateDocument state)
        {
           if (state == null) return 0;
            int total = Math.Max(0, state.Points);
            return total % PreyPointsPerLevel;
        }

        public static int GetPointsToNextLevel(BattlePassPlayerStateDocument state, BattlePassDefinition definition, string passCode)
       {
            int current = GetCurrentPassLevel(state, definition, passCode);
           if (definition != null && definition.Passes.TryGetValue(passCode, out List<GamePassLevel> levels) && levels != null && levels.Count > 0 && current >= levels.Max(x => x.Level))
                return 0;
            return PreyPointsPerLevel;
         }

        public static Dictionary<string, int> UpdateLevelsOnly(BattlePassPlayerStateDocument state, BattlePassDefinition definition)
        {
            foreach (var pass in definition.Passes)
                state.Levels[pass.Key] = GetCurrentPassLevel(state, definition, pass.Key);
            return new Dictionary<string, int>(state.Levels);
        }

        public static Reward ApplyPendingPassRewards(string playerId, BattlePassDefinition definition, BattlePassPlayerStateDocument state)
        {
            UpdateLevelsOnly(state, definition);
            bool ownsGoldPass = OwnsInventoryDefinition(playerId, definition.GoldPassItemDefinitionId);
            Reward aggregate = new();

            foreach (var pass in definition.Passes)
            {
                if (pass.Key == "GoldPass" && !ownsGoldPass)
                    continue;
               int currentLevel = state.Levels.TryGetValue(pass.Key, out int value) ? value : 0;
                foreach (var level in pass.Value.Where(x => x.Level > 0 && x.Level <= currentLevel).OrderBy(x => x.Level))
                {
                    string claimKey = pass.Key + ":" + level.Level;
                    if (state.ClaimedRewards.Contains(claimKey))
                        continue;

                    Reward granted = GrantRewardInfo(playerId, level.Reward ?? new RewardInfo());
                    MergeReward(aggregate, granted);
                    state.ClaimedRewards.Add(claimKey);
                }
            }
            return aggregate;
        }

        public static int AddEventPoints(BattlePassPlayerStateDocument state, int points)
        {
            int safe = Math.Max(0, Math.Min(points, MaxProgressPerCall));
            long total = (long)state.Points + safe;
             state.Points = total > int.MaxValue ? int.MaxValue : (int)total;
            return state.Points;
        }

        public static bool OwnsInventoryDefinition(string playerId, int itemDefinitionId)
        {
            if (itemDefinitionId <= 0) return false;
            try
            {
                PlayerInventoryDocument inventory = BoltGameDatabaseProvider.Instance.GetPlayerInventoryDocument(ObjectId.Parse(playerId));
               return inventory.InventoryItems.Elements.Any(x =>
                {
                    BsonDocument doc = x.Value.AsBsonDocument;
                    if (!doc.TryGetValue("itemDefinitionId", out BsonValue value)) return false;
                    int definitionId = value.IsInt32 ? value.AsInt32 : Convert.ToInt32(value.ToString());
                    return definitionId == itemDefinitionId;
                });
            }
            catch
            {
                return false;
             }
        }

        private const string KillMissionJson = "{\"Action\":{\"Trigger\":{\"Type\":0,\"Hit\":{\"IsKilled\":{\"Enabled\":true,\"Value\":true}}},\"Player\":{}},\"MissionTime\":0,\"GiveTriggerPoints\":false}";

        private const string HeadshotMissionJson = "{\"Action\":{\"Trigger\":{\"Type\":0,\"Hit\":{\"IsKilled\":{\"Enabled\":true,\"Value\":true},\"IsHeadShot\":{\"Enabled\":true,\"Value\":true}}},\"Player\":{}},\"MissionTime\":0,\"GiveTriggerPoints\":false}";

        private const string MatchFinishedMissionJson = "{\"Action\":{\"Trigger\":{\"Type\":5,\"GameFinished\":{}},\"Player\":{}},\"MissionTime\":0,\"GiveTriggerPoints\":false}";

        private const string WinMissionJson = "{\"Action\":{\"Trigger\":{\"Type\":5,\"GameFinished\":{\"Win\":{\"Enabled\":true,\"Value\":true}}},\"Player\":{}},\"MissionTime\":0,\"GiveTriggerPoints\":false}";

        public static string GetCanonicalMissionJson(string code, string action)
        {
            string c = (code ?? string.Empty).Trim().ToLowerInvariant();
            string a = (action ?? string.Empty).Trim();
            string legacy = a.ToLowerInvariant();
            if (c.Contains("headshot") || legacy == "headshots" || legacy == "headshot") return HeadshotMissionJson;
            if (c.Contains("win") || legacy == "wins" || legacy == "win") return WinMissionJson;
            if (c.Contains("match") || legacy == "matches" || legacy == "match" || legacy == "game_finished") return MatchFinishedMissionJson;
            if (c.Contains("kill") || legacy == "kills" || legacy == "kill") return KillMissionJson;
            if (LooksLikeMissionJson(a)) return a;
            return null;
        }

        public static bool LooksLikeMissionJson(string action)
        {
            if (string.IsNullOrWhiteSpace(action)) return false;
            string a = action.Trim();
            return a.Length >= 2 && a[0] == '{' && a[a.Length - 1] == '}' &&
                   a.IndexOf("\"Action\"", StringComparison.Ordinal) >= 0 &&
                   a.IndexOf("\"Trigger\"", StringComparison.Ordinal) >= 0;
        }

        private static string ChallengeId(string code, int fromDay)
         {
            string source = string.IsNullOrWhiteSpace(code) ? "mission" : code.Trim().ToLowerInvariant();
            var chars = source.Select(ch =>
                (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_' || ch == '-'
                    ? ch
                   : '_').ToArray();
            string safe = new string(chars).Trim('_');
            if (string.IsNullOrWhiteSpace(safe)) safe = "mission";

            return CanonicalPreyEventId + ":" + safe + ":" + Math.Max(1, fromDay)
                .ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        private static string LegacyChallengeId(string code, int fromDay)
        {
            string source = string.IsNullOrWhiteSpace(code) ? "mission" : code.Trim().ToLowerInvariant();
            var chars = source.Select(ch =>
                (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_' || ch == '-'
                    ? ch
                    : '_').ToArray();
            string safe = new string(chars).Trim('_');
            if (string.IsNullOrWhiteSpace(safe)) safe = "mission";
            return safe + "_" + Math.Max(1, fromDay)
                .ToString(System.Globalization.CultureInfo.InvariantCulture);
       }

        private static string MissionType(string type, string code)
        {
            string value = (type ?? string.Empty).Trim();
            if (value == "D" || value == "W")
                return value;

            string lower = value.ToLowerInvariant();
            string missionCode = (code ?? string.Empty).ToLowerInvariant();

            if (lower == "daily" || missionCode.Contains("_daily_"))
                return "D";
            if (lower == "weekly" || missionCode.Contains("_weekly_"))
                return "W";

            return value;
        }

        private static string LegacyChallengeIdWithEvent(BattlePassDefinition definition, string code, int fromDay)
        {
            return definition.Id + ":" + code + ":" + Math.Max(1, fromDay).ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

       public static IReadOnlyList<string> GetChallengeProgressWireIds(BattlePassDefinition definition, BattlePassChallengeDocument challenge)
        {
            if (challenge == null || string.IsNullOrWhiteSpace(challenge.Id)) return Array.Empty<string>();
            return new[] { challenge.Id };
        }

        private static void MigrateChallengeIds(BattlePassPlayerStateDocument state, BattlePassDefinition definition)
        {
            if (state == null || definition == null) return;
            bool changed = false;
             foreach (BattlePassChallengeDocument challenge in BuildChallenges(definition))
            {
                string canonical = challenge.Id;
                string[] oldIds =
                {
                    LegacyChallengeId(challenge.Code, challenge.FromDay),
                    LegacyChallengeIdWithEvent(definition, challenge.Code, challenge.FromDay)
                };
               foreach (string oldId in oldIds.Distinct(StringComparer.Ordinal))
                {
                    if (string.Equals(canonical, oldId, StringComparison.Ordinal)) continue;
                    if (state.ChallengePoints.TryGetValue(oldId, out int legacyPoints))
                    {
                        if (!state.ChallengePoints.TryGetValue(canonical, out int current) || legacyPoints > current)
                            state.ChallengePoints[canonical] = legacyPoints;
                        state.ChallengePoints.Remove(oldId);
                        changed = true;
                    }
                    if (state.CompletedChallenges.Remove(oldId))
                    {
                        if (!state.CompletedChallenges.Contains(canonical)) state.CompletedChallenges.Add(canonical);
                        changed = true;
                    }
                }
            }
            if (changed)
            {
                state.UpdatedAtUtc = DateTime.UtcNow;
                States.ReplaceOne(x => x.Id == state.Id, state, new ReplaceOptions { IsUpsert = true });
            }
        }

        private static bool IsChallengeActive(BattlePassDefinition definition, BattlePassChallengeDocument item)
        {
            if (definition == null || item == null) return false;
            if (!string.Equals(item.Type, "D", StringComparison.Ordinal) && !string.Equals(item.Type, "W", StringComparison.Ordinal))
                return true;
            int day = Math.Max(1, definition.CurrentDay);
            return day >= Math.Max(1, item.FromDay) && day <= Math.Max(item.FromDay, item.ToDay);
        }

        private static bool PrepareChallenge(BattlePassDefinition definition, BattlePassChallengeDocument item)
        {
            if (item == null || string.IsNullOrWhiteSpace(item.Id)) return false;
            if (string.IsNullOrWhiteSpace(item.EventId)) item.EventId = definition.Id;
            if (item.FromDay <= 0)
            {
                item.FromDay = 1;
                item.ToDay = Math.Max(1, item.ToDay + 1);
            }
            item.ToDay = Math.Max(item.FromDay, item.ToDay);
            if (!string.IsNullOrWhiteSpace(item.Code))
                item.Id = ChallengeId(item.Code, item.FromDay);
            item.Type = MissionType(item.Type, item.Code);
            item.TargetPoints = Math.Max(1, item.TargetPoints);
            item.EventPoints = Math.Max(0, item.EventPoints);
            string canonical = GetCanonicalMissionJson(item.Code, item.Action);
            if (canonical == null)
                return false;

            item.Action = canonical;
           if (string.IsNullOrWhiteSpace(item.DisplayName)) item.DisplayName = MissionDisplayName(item.Code);
            if (string.IsNullOrWhiteSpace(item.Description)) item.Description = MissionDescription(item.Code, item.TargetPoints);
            return true;
        }

        public static string MissionDisplayName(string code)
        {
            string c = (code ?? string.Empty).ToLowerInvariant();
            if (c.Contains("headshot")) return "Headshots";
            if (c.Contains("win")) return "Wins";
            if (c.Contains("match")) return "Matches";
            if (c.Contains("kill")) return "Kills";
            return string.IsNullOrWhiteSpace(code) ? "Mission" : code;
        }

        public static string MissionDescription(string code, int target)
        {
            string c = (code ?? string.Empty).ToLowerInvariant();
            if (c.Contains("headshot")) return $"Get {Math.Max(1, target)} headshots";
             if (c.Contains("win")) return $"Win {Math.Max(1, target)} matches";
            if (c.Contains("match")) return $"Play {Math.Max(1, target)} matches";
            if (c.Contains("kill")) return $"Get {Math.Max(1, target)} kills";
            return "Complete the mission";
       }

        public static List<BattlePassChallengeDocument> GetChallengeDefinitions(BattlePassDefinition definition)
        {
            var result = BuildChallenges(definition);
        try
            {
                var custom = Challenges.Find(x => x.EventId == definition.Id).ToList();
                foreach (var item in custom)
                {
                    if (item == null) continue;
                    if (!PrepareChallenge(definition, item)) continue;
                   int index = result.FindIndex(x => x.Id == item.Id);
                    if (index >= 0) result[index] = item;
                    else result.Add(item);
                }
            }
            catch
            {

            }
            return result
                .Where(x => PrepareChallenge(definition, x))
                .Where(x => IsChallengeActive(definition, x))
                 .GroupBy(x => x.Id, StringComparer.Ordinal)
                .Select(g => g.Last())
                .ToList();
        }

        private static List<BattlePassChallengeDocument> BuildChallenges(BattlePassDefinition definition)
        {
            int day = Math.Max(1, definition.CurrentDay);
            int week = Math.Max(1, (day + 6) / 7);
            int weekFrom = (week - 1) * 7 + 1;
            int weekTo = Math.Min(Math.Max(1, definition.DurationDays), week * 7);

            (string code, string action, int target, int points)[] dailyPool =
            {
                 ("prey_daily_kills_10", "kills", 10, 300),
                ("prey_daily_headshots_5", "headshots", 5, 300),
                ("prey_daily_matches_3", "matches", 3, 300),
                 ("prey_daily_wins_2", "wins", 2, 350),
                ("prey_daily_kills_18", "kills", 18, 350),
                ("prey_daily_headshots_8", "headshots", 8, 350),
                 ("prey_daily_matches_5", "matches", 5, 350),
                ("prey_daily_wins_3", "wins", 3, 400)
            };
            (string code, string action, int target, int points)[] weeklyPool =
            {
                ("prey_weekly_kills_35", "kills", 35, 900),
                ("prey_weekly_headshots_18", "headshots", 18, 900),
                ("prey_weekly_matches_10", "matches", 10, 900),
                ("prey_weekly_wins_5", "wins", 5, 1000),
                ("prey_weekly_kills_70", "kills", 70, 1100),
                ("prey_weekly_headshots_35", "headshots", 35, 1100),
                ("prey_weekly_matches_18", "matches", 18, 1100),
                 ("prey_weekly_wins_9", "wins", 9, 1200),
                ("prey_weekly_kills_100", "kills", 100, 1300),
                ("prey_weekly_headshots_50", "headshots", 50, 1300),
                ("prey_weekly_matches_25", "matches", 25, 1400),
                ("prey_weekly_wins_12", "wins", 12, 1500)
            };

            var result = new List<BattlePassChallengeDocument>(10);
            int dailyStart = (day * 3) % dailyPool.Length;
            for (int i = 0; i < 3; i++)
            {
                var m = dailyPool[(dailyStart + i) % dailyPool.Length];
                result.Add(CreateChallenge(definition, m.code, m.action, "D", day, day, m.target, m.points));
            }

            int weeklyStart = (week * 5) % weeklyPool.Length;
            for (int i = 0; i < 6; i++)
            {
                var m = weeklyPool[(weeklyStart + i) % weeklyPool.Length];
                result.Add(CreateChallenge(definition, m.code, m.action, "W", weekFrom, weekTo, m.target, m.points));
            }

            string goldAction = week % 2 == 0 ? "kills" : "wins";
            int goldTarget = week % 2 == 0 ? 120 : 12;
            result.Add(CreateChallenge(definition, $"prey_weekly_gold_{goldAction}", goldAction, "W",
                weekFrom, weekTo, goldTarget, 1600, definition.GoldPassItemDefinitionId));
            return result;
        }

        private static BattlePassChallengeDocument CreateChallenge(BattlePassDefinition definition, string code, string action, string type,
            int fromDay, int toDay, int targetPoints, int eventPoints, int keyItemDefinitionId = 0)
       {
            return new BattlePassChallengeDocument
            {
                Id = ChallengeId(code, fromDay),
                EventId = definition.Id,
                Code = code,
                Action = GetCanonicalMissionJson(code, action) ?? action,
                DisplayName = MissionDisplayName(code),
                Description = MissionDescription(code, targetPoints),
                Type = type,
                FromDay = fromDay,
                ToDay = toDay,
                TargetPoints = targetPoints,
                EventPoints = eventPoints,
                KeyItemDefinitionId = keyItemDefinitionId,
                RewardCurrencies = new(StringComparer.Ordinal),
                RewardItems = new(StringComparer.Ordinal)
            };
        }

        public static void ValidateStaticContract(BattlePassDefinition definition, IReadOnlyList<BattlePassChallengeDocument> challenges)
        {
            if (definition == null) throw new InvalidOperationException("battle pass definition missing");
            if (!string.Equals(definition.Code, CanonicalPreyCode, StringComparison.Ordinal))
                throw new InvalidOperationException("bad prey code");
            foreach (BattlePassChallengeDocument c in challenges ?? Array.Empty<BattlePassChallengeDocument>())
            {
                if (c == null) throw new InvalidOperationException("null challenge");
                if (!string.Equals(c.EventId, definition.Id, StringComparison.Ordinal))
                    throw new InvalidOperationException("bad challenge event");
                if (c.Type != "D" && c.Type != "W" && !c.Code.StartsWith("custom", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("bad challenge type");
               if ((c.Type == "D" || c.Type == "W") && (string.IsNullOrEmpty(c.Id) || c.Id.IndexOf(':') < 0))
                    throw new InvalidOperationException("bad challenge id");
                if (c.Type == "D" && c.FromDay != c.ToDay)
                    throw new InvalidOperationException("bad daily range");
                if (c.Type == "W")
                {
                    int expectedFrom = ((Math.Max(1, definition.CurrentDay) - 1) / 7) * 7 + 1;
                    if (c.FromDay != expectedFrom)
                        throw new InvalidOperationException("bad weekly range");
                }
                if (!LooksLikeMissionJson(c.Action))
                    throw new InvalidOperationException("bad mission action");
            }
        }

        public static CurrentChallenge ToProto(BattlePassChallengeDocument definition, BattlePassPlayerStateDocument state)
        {
            int current = state.ChallengePoints.TryGetValue(definition.Id, out int value) ? value : 0;
            return new CurrentChallenge
            {
                GameEventChallengeId = definition.Id,
                Code = definition.Code ?? string.Empty,
                KeyItemDefinitionId = definition.KeyItemDefinitionId,
                LocalizedTitle = new LocalizedTitle
                {
                    Name = string.IsNullOrWhiteSpace(definition.DisplayName) ? (definition.Code ?? string.Empty) : definition.DisplayName,
                    Description = string.IsNullOrWhiteSpace(definition.Description) ? MissionDescription(definition.Code, definition.TargetPoints) : definition.Description
                },
                Action = definition.Action ?? string.Empty,
                DayRange = new DayRange { From = definition.FromDay, To = definition.ToDay },
                 Type = definition.Type ?? string.Empty,
                EventPoints = definition.EventPoints,
                TargetPoints = definition.TargetPoints,
                CurrentPoints = current,
                Reward = ToRewardInfo(definition)
            };
        }

        public static RewardInfo ToRewardInfo(BattlePassChallengeDocument definition)
        {
            var reward = new RewardInfo();
            if (definition.RewardCurrencies != null)
            {
                foreach (var pair in definition.RewardCurrencies)
                {
                    if (!int.TryParse(pair.Key, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out int currencyId))
                    {
                        continue;
                    }
                    reward.Currencies.Add(new CurrencyAmount { CurrencyId = currencyId, Value = pair.Value });
                }
            }
            if (definition.RewardItems != null)
            {
                foreach (var pair in definition.RewardItems)
                {
                    if (!int.TryParse(pair.Key, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out int itemDefinitionId))
                    {
                        continue;
                    }
                    reward.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = itemDefinitionId, Value = pair.Value });
                }
           }
            return reward;
        }

        public static BattlePassChallengeDocument FindChallenge(BattlePassDefinition definition, string challengeId)
        {
            return GetChallengeDefinitions(definition).FirstOrDefault(x =>
                x.Id == challengeId || x.Code == challengeId ||
                LegacyChallengeId(x.Code, x.FromDay) == challengeId ||
                LegacyChallengeIdWithEvent(definition, x.Code, x.FromDay) == challengeId);
        }

        public static void SaveCustomChallenge(BattlePassDefinition definition, string code, string action, int targetPoints)
        {
            string safeCode = string.IsNullOrWhiteSpace(code) ? "custom" : code.Trim();
            var doc = new BattlePassChallengeDocument
            {
                Id = ChallengeId("custom_" + safeCode, 1),
                EventId = definition.Id,
                Code = safeCode,
                Action = GetCanonicalMissionJson(safeCode, action) ?? MatchFinishedMissionJson,
                DisplayName = MissionDisplayName(safeCode),
                Description = MissionDescription(safeCode, Math.Max(1, targetPoints)),
                Type = "Custom",
                FromDay = 1,
                ToDay = Math.Max(1, definition.DurationDays),
                TargetPoints = Math.Max(1, targetPoints),
                EventPoints = Math.Max(1, targetPoints),
                RewardCurrencies = new(StringComparer.Ordinal) { ["101"] = Math.Max(1, targetPoints) },
                RewardItems = new(StringComparer.Ordinal)
            };
            Challenges.ReplaceOne(x => x.Id == doc.Id, doc, new ReplaceOptions { IsUpsert = true });
        }

        private static bool IsChallengeActiveToday(BattlePassChallengeDocument challenge, BattlePassDefinition definition)
        {
            int day = Math.Max(1, definition.CurrentDay);
            return challenge != null && day >= Math.Max(1, challenge.FromDay) && day <= Math.Max(challenge.FromDay, challenge.ToDay);
        }

        private static string GetMissionKind(BattlePassChallengeDocument challenge)
        {
            string code = (challenge?.Code ?? string.Empty).ToLowerInvariant();
            if (code.Contains("headshot")) return "headshots";
            if (code.Contains("win")) return "wins";
            if (code.Contains("match")) return "matches";
            if (code.Contains("kill")) return "kills";
            return string.Empty;
        }

        private static void UpdateChallenge(string playerId, BattlePassDefinition definition,
            BattlePassPlayerStateDocument state, BattlePassChallengeDocument challenge, int desiredPoints,
            BattlePassMissionSettlementResult result)
        {
             if (challenge == null || !IsChallengeActiveToday(challenge, definition)) return;
            int target = Math.Max(1, challenge.TargetPoints);
            int old = state.ChallengePoints.TryGetValue(challenge.Id, out int value) ? Math.Max(0, value) : 0;
           int current = Math.Max(0, Math.Min(target, desiredPoints));
            bool wasCompleted = state.CompletedChallenges.Contains(challenge.Id);
            state.ChallengePoints[challenge.Id] = current;
            if (current != old) result.ChangedChallenges.Add(challenge.Id);

            bool completed = current >= target;
            int awardedEventPoints = 0;
             if (completed && !wasCompleted)
            {
                state.CompletedChallenges.Add(challenge.Id);
                Reward granted = GrantRewardInfo(playerId, ToRewardInfo(challenge));
                MergeReward(result.Reward, granted);
                awardedEventPoints = Math.Max(0, challenge.EventPoints);
                AddEventPoints(state, awardedEventPoints);
                result.EventPointsAwarded += awardedEventPoints;
                result.CompletedChallenges.Add(challenge.Id);
            }
            else if (!completed && wasCompleted)
            {
                current = target;
                state.ChallengePoints[challenge.Id] = target;
                completed = true;
            }

        }

        public static BattlePassMissionSettlementResult ApplyMatchSnapshot(string playerId, string matchId,
            int kills, int headshots, bool matchCompleted, bool won)
         {
            if (string.IsNullOrWhiteSpace(playerId)) throw new ArgumentException("player id required");
            if (string.IsNullOrWhiteSpace(matchId)) throw new ArgumentException("match id required");
            BattlePassDefinition definition = GetDefinition();
            lock (LockForPlayer(playerId))
            {
                BattlePassPlayerStateDocument state = GetState(playerId, definition);
                IReadOnlyList<BattlePassChallengeDocument> challenges = GetChallengeDefinitions(definition);
                var filter = Builders<BattlePassMatchSnapshotDocument>.Filter.Where(x =>
                    x.PlayerId == playerId && x.EventId == definition.Id && x.MatchId == matchId);
                BattlePassMatchSnapshotDocument snapshot = MatchSnapshots.Find(filter).FirstOrDefault();
                if (snapshot == null)
               {
                    snapshot = new BattlePassMatchSnapshotDocument
                    {
                        Id = ObjectId.GenerateNewId(), PlayerId = playerId, EventId = definition.Id, MatchId = matchId,
                        Kills = 0, Headshots = 0, MatchCredited = false, WinCredited = false,
                        BaselineChallengePoints = challenges.ToDictionary(
                            c => c.Id,
                            c => state.ChallengePoints.TryGetValue(c.Id, out int v) ? Math.Max(0, v) : 0,
                            StringComparer.Ordinal),
                       UpdatedAtUtc = DateTime.UtcNow
                    };
                }
                snapshot.BaselineChallengePoints = snapshot.BaselineChallengePoints ?? new();
                foreach (BattlePassChallengeDocument c in challenges)
                    if (!snapshot.BaselineChallengePoints.ContainsKey(c.Id))
                        snapshot.BaselineChallengePoints[c.Id] = state.ChallengePoints.TryGetValue(c.Id, out int v) ? Math.Max(0, v) : 0;

                kills = Math.Max(0, kills);
                headshots = Math.Max(0, Math.Min(headshots, kills));
                var result = new BattlePassMissionSettlementResult
                {
                    KillDelta = Math.Max(0, kills - Math.Max(0, snapshot.Kills)),
                    HeadshotDelta = Math.Max(0, headshots - Math.Max(0, snapshot.Headshots)),
                    MatchDelta = matchCompleted && !snapshot.MatchCredited ? 1 : 0,
                    WinDelta = matchCompleted && won && !snapshot.WinCredited ? 1 : 0
                };

                snapshot.Kills = Math.Max(snapshot.Kills, kills);
                snapshot.Headshots = Math.Max(snapshot.Headshots, headshots);
               if (matchCompleted) snapshot.MatchCredited = true;
                if (matchCompleted && won) snapshot.WinCredited = true;
                snapshot.UpdatedAtUtc = DateTime.UtcNow;

                foreach (BattlePassChallengeDocument challenge in challenges)
                {
                    int baseline = snapshot.BaselineChallengePoints.TryGetValue(challenge.Id, out int b) ? Math.Max(0, b) : 0;
                    int metric = GetMissionKind(challenge) switch
                    {
                        "kills" => snapshot.Kills,
                        "headshots" => snapshot.Headshots,
                        "matches" => snapshot.MatchCredited ? 1 : 0,
                        "wins" => snapshot.WinCredited ? 1 : 0,
                        _ => 0
                    };
                    if (metric > 0 || GetMissionKind(challenge) is "kills" or "headshots" or "matches" or "wins")
                        UpdateChallenge(playerId, definition, state, challenge, baseline + metric, result);
                }

                UpdateLevelsOnly(state, definition);

                if (result.EventPointsAwarded > 0)
                {
                    Reward unlocked = ApplyPendingPassRewards(playerId, definition, state);
                     MergeReward(result.Reward, unlocked);
                }

                SaveState(state);
                MatchSnapshots.ReplaceOne(filter, snapshot, new ReplaceOptions { IsUpsert = true });
                result.EventPointsTotal = state.Points;
                return result;
            }
        }

        public static BattlePassMissionSettlementResult BindActiveMatch(string playerId, string matchId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(matchId))
                return new BattlePassMissionSettlementResult();
            _activeMatches[playerId] = matchId;
           BattlePassMissionSettlementResult result = ApplyMatchSnapshot(playerId, matchId, 0, 0, false, false);
            return result;
        }

        public static void ClearActiveMatch(string playerId, string matchId = null)
        {
           if (string.IsNullOrWhiteSpace(playerId)) return;
            if (string.IsNullOrWhiteSpace(matchId))
            {
                _activeMatches.TryRemove(playerId, out _);
                return;
             }
            if (_activeMatches.TryGetValue(playerId, out string current) &&
                string.Equals(current, matchId, StringComparison.Ordinal))
                _activeMatches.TryRemove(playerId, out _);
        }

       public static BattlePassMissionSettlementResult ApplyCommittedCombatStats(string playerId, int killDelta, int headshotDelta)
        {
            if (string.IsNullOrWhiteSpace(playerId) || (killDelta <= 0 && headshotDelta <= 0))
                return new BattlePassMissionSettlementResult();

            BattlePassDefinition definition = GetDefinition();
            string matchId = null;
            _activeMatches.TryGetValue(playerId, out matchId);

            BattlePassMatchSnapshotDocument snapshot = null;
            if (!string.IsNullOrWhiteSpace(matchId))
            {
                snapshot = MatchSnapshots.Find(x => x.PlayerId == playerId && x.EventId == definition.Id && x.MatchId == matchId).FirstOrDefault();
                if (snapshot == null)
                {
                    BindActiveMatch(playerId, matchId);
                    snapshot = MatchSnapshots.Find(x => x.PlayerId == playerId && x.EventId == definition.Id && x.MatchId == matchId).FirstOrDefault();
                }
            }

           if (snapshot == null)
            {
                snapshot = MatchSnapshots.Find(x => x.PlayerId == playerId && x.EventId == definition.Id)
                    .SortByDescending(x => x.UpdatedAtUtc).FirstOrDefault();
                if (snapshot == null || (DateTime.UtcNow - snapshot.UpdatedAtUtc) > TimeSpan.FromMinutes(10))
                {

                    matchId = "stats-" + Guid.NewGuid().ToString("N");
                    BindActiveMatch(playerId, matchId);
                    snapshot = MatchSnapshots.Find(x => x.PlayerId == playerId && x.EventId == definition.Id && x.MatchId == matchId).FirstOrDefault();
                    if (snapshot == null)
                    {
                        return new BattlePassMissionSettlementResult();
                   }
                }
                matchId = snapshot.MatchId;
            }

            int nextHeadshots = checked(Math.Min(int.MaxValue, Math.Max(0, snapshot.Headshots) + Math.Max(0, headshotDelta)));
            int nextKills = checked(Math.Min(int.MaxValue, Math.Max(0, snapshot.Kills) + Math.Max(0, killDelta)));
            nextKills = Math.Max(nextKills, nextHeadshots);
            BattlePassMissionSettlementResult result = ApplyMatchSnapshot(
                playerId, matchId, nextKills, nextHeadshots, snapshot.MatchCredited, snapshot.WinCredited);
            return result;
        }

        public static BattlePassMissionSettlementResult ApplyClientChallengeAbsolute(string playerId, string challengeId, int reportedPoints)
        {
            var result = new BattlePassMissionSettlementResult();
             if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(challengeId)) return result;
            BattlePassDefinition definition = GetDefinition();
            lock (LockForPlayer(playerId))
            {
                BattlePassPlayerStateDocument state = GetState(playerId, definition);
                BattlePassChallengeDocument challenge = FindChallenge(definition, challengeId);
                if (challenge == null) throw new ArgumentException("unknown challenge " + challengeId);
                 int desired = Math.Max(0, Math.Min(Math.Max(1, challenge.TargetPoints), reportedPoints));
                UpdateChallenge(playerId, definition, state, challenge, desired, result);
                UpdateLevelsOnly(state, definition);
                 if (result.EventPointsAwarded > 0)
                {
                    Reward unlocked = ApplyPendingPassRewards(playerId, definition, state);
                    MergeReward(result.Reward, unlocked);
                }
                SaveState(state);
                result.EventPointsTotal = state.Points;
                return result;
            }
        }

        public static Reward GrantRewardInfo(string playerId, RewardInfo rewardInfo)
       {
            Reward result = new();
            var game = BoltGameDatabaseProvider.Instance;
            ObjectId playerObjectId = ObjectId.Parse(playerId);
            PlayerInventoryDocument inventory;
            try
            {
                inventory = game.GetPlayerInventoryDocument(playerObjectId);
            }
            catch
            {
                game.CreatePlayerInventory(playerObjectId);
                inventory = game.GetPlayerInventoryDocument(playerObjectId);
            }

           inventory.Currencies = inventory.Currencies ?? new BsonDocument();
            inventory.InventoryItems = inventory.InventoryItems ?? new BsonDocument();

            if (rewardInfo != null)
            {
               foreach (CurrencyAmount currency in rewardInfo.Currencies)
                {
                    double oldValue = ReadCurrency(inventory, currency.CurrencyId);
                    double amount = Math.Max(0, currency.Value);
                    if (amount <= 0) continue;
                    game.CurrencyPlusValue(playerObjectId, currency.CurrencyId, amount);
                    result.Currencies.Add(new CurrencyAmount
                    {
                         CurrencyId = currency.CurrencyId,
                        OldValue = (int)oldValue,
                        Value = (float)amount
                    });
                    inventory.Currencies[currency.CurrencyId.ToString()] = BsonValue.Create(oldValue + amount);
                }

                 foreach (InventoryItemAmount item in rewardInfo.Items)
               {
                    if (item.InventoryItemDefinitionId <= 0 || item.Value <= 0) continue;

                    if (ProfileFrameRuntime.IsProfileFrameDefinition(item.InventoryItemDefinitionId))
                    {

                        inventory = ProfileFrameRuntime.RepairEarnedLevelFrames(playerId) ?? inventory;
                        if (ProfileFrameRuntime.TryGetOwnedFrame(
                                inventory, item.InventoryItemDefinitionId, out int existingFrameId, out InventoryItem existingFrame))
                        {
                             result.Items.Add(existingFrame);
                            continue;
                        }
                    }

                     int nextId = NextItemId(inventory);
                    var stored = new BoltInventoryItem
                    {
                        id = nextId,
                        itemDefinitionId = item.InventoryItemDefinitionId,
                        quantity = item.Value,
                        flags = 0,
                        date = new BsonDateTime(DateTime.UtcNow),
                        Properties = new List<BoltInventoryItemProperty>()
                    };
                    ProfileFrameRuntime.DecorateGrantedItem(playerId, stored);
                    game.AddItemToPlayerInventoryDocument(playerObjectId, stored, nextId);
                    result.Items.Add(stored.ToInventory(nextId));
                    inventory.InventoryItems[nextId.ToString()] = stored.GetBsonElements();
                }
            }
            return result;
        }

        private static int NextItemId(PlayerInventoryDocument inventory)
       {
            int max = 0;
            foreach (BsonElement element in inventory.InventoryItems.Elements)
            {
                if (int.TryParse(element.Name, out int id) && id > max)
                   max = id;
            }
           return max + 1;
        }

        private static double ReadCurrency(PlayerInventoryDocument inventory, int currencyId)
        {
            if (inventory?.Currencies == null || !inventory.Currencies.TryGetValue(currencyId.ToString(), out BsonValue value))
                return 0;
            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsDouble) return value.AsDouble;
           if (value.IsDecimal128) return (double)value.AsDecimal128;
            return 0;
        }

        public static void MergeReward(Reward destination, Reward source)
         {
            if (destination == null || source == null) return;
            destination.Items.Add(source.Items);
             foreach (CurrencyAmount incoming in source.Currencies)
             {
                CurrencyAmount existing = destination.Currencies.FirstOrDefault(x => x.CurrencyId == incoming.CurrencyId);
                if (existing == null)
                {
                    destination.Currencies.Add(incoming.Clone());
               }
                else
                {
                     existing.Value = incoming.Value;
                    if (existing.OldValue == 0) existing.OldValue = incoming.OldValue;
                }
            }
       }
    }
}
