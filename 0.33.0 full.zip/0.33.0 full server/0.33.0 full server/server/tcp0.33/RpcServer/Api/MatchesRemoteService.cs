using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class MatchesRemoteService : RpcHandler
    {
        public MatchesRemoteService(ClientSession user) : base(user) { }

        private static byte[] BuildProto(Action<CodedOutputStream> writer)
        {
            using (var stream = new MemoryStream())
            using (var output = new CodedOutputStream(stream, true))
            {
                writer(output);
                output.Flush();
                return stream.ToArray();
            }
        }

        private static void WriteString(CodedOutputStream o, int field, string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            o.WriteTag(field, WireFormat.WireType.LengthDelimited);
            o.WriteString(value);
        }

        private static void WriteInt(CodedOutputStream o, int field, int value)
        {
             if (value == 0) return;
           o.WriteTag(field, WireFormat.WireType.Varint);
            o.WriteInt32(value);
        }

        private static void WriteLong(CodedOutputStream o, int field, long value)
        {
             if (value == 0L) return;
            o.WriteTag(field, WireFormat.WireType.Varint);
            o.WriteInt64(value);
        }

        private static void WriteBool(CodedOutputStream o, int field, bool value)
        {
            if (!value) return;
            o.WriteTag(field, WireFormat.WireType.Varint);
            o.WriteBool(value);
       }
private static void WriteMessage(CodedOutputStream o, int field, byte[] value)
        {
            if (value == null) return;
            o.WriteTag(field, WireFormat.WireType.LengthDelimited);
            o.WriteBytes(ByteString.CopyFrom(value));
        }

        private static byte[] PropInt(string name, int value) => BuildProto(o =>
        {
            WriteString(o, 1, name);
            WriteInt(o, 3, value);
        });
private static byte[] PropString(string name, string value) => BuildProto(o =>
       {
            WriteString(o, 1, name);
            WriteInt(o, 2, 2);
            WriteString(o, 6, value ?? string.Empty);
        });

         private static byte[] PropBool(string name, bool value) => BuildProto(o =>
        {
           WriteString(o, 1, name);
            WriteInt(o, 2, 3);
            WriteBool(o, 7, value);
        });

        private static int GetInt(BsonDocument d, string key, int fallback = 0)
         {
            try { return d != null && d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToInt32() : fallback; }
            catch { return fallback; }
        }

        private static bool GetBool(BsonDocument d, string key, bool fallback = false)
        {
            try { return d != null && d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToBoolean() : fallback; }
            catch { return fallback; }
        }

        private static string GetString(BsonDocument d, string key, string fallback = "")
        {
            try { return d != null && d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToString() : fallback; }
            catch { return fallback; }
        }

        private static DateTime GetDate(BsonDocument d, string key)
        {
            try { return d != null && d.TryGetValue(key, out BsonValue v) && v.IsBsonDateTime ? v.AsBsonDateTime.ToUniversalTime() : DateTime.MinValue; }
            catch { return DateTime.MinValue; }
        }

        private static int FindInt(BsonDocument d, int fallback, params string[] keys)
        {
            foreach (string key in keys)
            {
                int value = GetInt(d, key, int.MinValue);
                if (value != int.MinValue) return value;
            }
            return fallback;
        }

        private static string FindString(BsonDocument d, string fallback, params string[] keys)
        {
            foreach (string key in keys)
            {
                string value = GetString(d, key, null);
                if (!string.IsNullOrWhiteSpace(value)) return value;
            }
            return fallback ?? string.Empty;
        }

        private static bool FindFlag(BsonDocument d, params string[] keys)
        {
            foreach (string key in keys)
           {
                if (d != null && d.TryGetValue(key, out BsonValue value) && !value.IsBsonNull)
                {
                    try
                    {
                        if (value.IsBoolean) return value.AsBoolean;
                         if (value.IsInt32) return value.AsInt32 != 0;
                        if (value.IsInt64) return value.AsInt64 != 0;
                        string text = value.ToString();
                        if (bool.TryParse(text, out bool parsed)) return parsed;
                         if (int.TryParse(text, out int number)) return number != 0;
                    }
                     catch { }
                }
           }
            return false;
        }

        private sealed class MatchPlayerInfo
        {
            public string Id = string.Empty;
            public string Uid = string.Empty;
            public string Name = string.Empty;
            public string AvatarId = string.Empty;
        }

        private static MatchPlayerInfo GetPlayerInfo(BsonDocument player, BsonDocument result)
        {
            string playerId = FindString(player, string.Empty, "playerId", "id", "profileId", "accountId");
            if (string.IsNullOrWhiteSpace(playerId))
                playerId = FindString(result, string.Empty, "playerId", "id", "profileId", "accountId");

            var profile = new MatchPlayerInfo
            {
                Id = playerId,
                Uid = FindString(player, string.Empty, "playerUid", "uid"),
                Name = FindString(player, string.Empty, "playerName", "name", "nickname"),
                AvatarId = FindString(player, string.Empty, "avatarId", "avatar")
            };

            if (string.IsNullOrWhiteSpace(profile.Uid))
                profile.Uid = FindString(result, string.Empty, "playerUid", "uid");
            if (string.IsNullOrWhiteSpace(profile.Name))
                profile.Name = FindString(result, string.Empty, "playerName", "name", "nickname");
            if (string.IsNullOrWhiteSpace(profile.AvatarId))
                profile.AvatarId = FindString(result, string.Empty, "avatarId", "avatar");

            if (!string.IsNullOrWhiteSpace(playerId) && ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                try
                {
                    PlayerDocument stored = BoltMainDatabaseProvider.Instance?.GetPlayerDocument(objectId);
                    if (stored != null)
                    {
                        if (string.IsNullOrWhiteSpace(profile.Uid)) profile.Uid = stored.uid ?? string.Empty;
                        if (string.IsNullOrWhiteSpace(profile.Name)) profile.Name = stored.name ?? string.Empty;
                        if (string.IsNullOrWhiteSpace(profile.AvatarId)) profile.AvatarId = stored.avatarId ?? string.Empty;
                    }
               }
                catch { }
             }

            if (string.IsNullOrWhiteSpace(profile.Uid)) profile.Uid = playerId;
            if (string.IsNullOrWhiteSpace(profile.Name)) profile.Name = "Player";
            return profile;
        }

        private static int GetPlayerStatus(BsonDocument player, BsonDocument result)
        {
            if (FindFlag(result, "isKicked", "kicked", "wasKicked") ||
                FindFlag(player, "isKicked", "kicked", "wasKicked"))
                return 1;

            if (FindFlag(result, "isAbandon", "abandoned", "rankedAbandon", "didLeave", "isLeft", "left") ||
                FindFlag(player, "isAbandon", "abandoned", "rankedAbandon", "didLeave", "isLeft", "left"))
                return 2;

            string reason = (FindString(result, string.Empty, "status", "finishReason", "leaveReason", "disconnectReason") + " " +
                             FindString(player, string.Empty, "status", "finishReason", "leaveReason", "disconnectReason"))
                .Trim().ToLowerInvariant();

            if (reason.Contains("kick")) return 1;
            if (reason.Contains("leave") || reason.Contains("left") || reason.Contains("abandon")) return 2;

            int status = FindInt(result, int.MinValue, "historyStatus", "matchPlayerStatus");
            if (status != int.MinValue) return status;
             return 0;
       }

        private static BsonDocument GetDocument(BsonDocument d, string key)
        {
            try
            {
                return d != null && d.TryGetValue(key, out BsonValue value) && value.IsBsonDocument
                    ? value.AsBsonDocument
                    : null;
            }
            catch { return null; }
        }
        private static int GetTeamScore(BsonDocument document, bool tr)
        {
            string[] direct = tr
                ? new[] { "trScore", "scoreTr", "scoreTR", "team1Score", "score1", "tr_score" }
                : new[] { "ctScore", "scoreCt", "scoreCT", "team2Score", "score2", "ct_score" };
            int value = FindInt(document, int.MinValue, direct);
            if (value != int.MinValue) return value;

            foreach (string containerName in new[] { "score", "scores", "teamScores", "finalScore", "result" })
            {
                BsonDocument nested = GetDocument(document, containerName);
                if (nested == null) continue;
                value = FindInt(nested, int.MinValue, direct);
                if (value != int.MinValue) return value;
                value = FindInt(nested, int.MinValue, tr ? new[] { "1", "tr", "Tr" } : new[] { "2", "ct", "Ct" });
                if (value != int.MinValue) return value;
            }
            return 0;
        }

        private static string ReadMatchId(RpcRequest request)
         {
            try
            {
                if (request.Params == null || request.Params.Count == 0) return string.Empty;
                byte[] raw = request.Params[0].GetBytesSafe();
               if (raw == null || raw.Length == 0) return string.Empty;

                int index = 0;
                while (index < raw.Length)
                {
                    uint tag = ReadVarint(raw, ref index);
                   if (tag == 0) break;
                    int field = (int)(tag >> 3);
                    int wire = (int)(tag & 7);
                    if (field == 1 && wire == 2)
                    {
                         int length = checked((int)ReadVarint(raw, ref index));
                        if (length < 0 || index + length > raw.Length)
                            throw new InvalidOperationException("Invalid GetMatchRequest MatchId length.");
                         return System.Text.Encoding.UTF8.GetString(raw, index, length);
                    }
                    SkipField(raw, ref index, wire);
                }
            }
             catch { }
            return string.Empty;
        }

        private static uint ReadVarint(byte[] data, ref int index)
        {
            uint value = 0;
            int shift = 0;
            while (index < data.Length && shift < 35)
            {
                byte b = data[index++];
                value |= (uint)(b & 0x7F) << shift;
                if ((b & 0x80) == 0) return value;
                shift += 7;
            }
            throw new InvalidOperationException("Malformed protobuf varint.");
        }

        private static void SkipField(byte[] data, ref int index, int wire)
        {
            switch (wire)
            {
                case 0: ReadVarint(data, ref index); return;
                case 1: index += 8; break;
                case 2:
                    int len = checked((int)ReadVarint(data, ref index));
                    index += len;
                    break;
                case 5: index += 4; break;
                default: throw new InvalidOperationException("Unsupported protobuf wire type: " + wire);
           }
            if (index < 0 || index > data.Length)
                 throw new InvalidOperationException("Protobuf field exceeds request length.");
        }

        private static byte[] StatInt(string name, int value) => BuildProto(o =>
        {
            WriteString(o, 1, name);
            WriteInt(o, 2, value);
        });
private static byte[] BuildReward(BsonDocument player, BsonDocument result)
       {
            int kills = FindInt(result, FindInt(player, 0, "kills", "killCount"), "kills", "killCount");
            int deaths = FindInt(result, FindInt(player, 0, "deaths", "deathCount"), "deaths", "deathCount");
            int assists = FindInt(result, FindInt(player, 0, "assists", "assistCount"), "assists", "assistCount");
            int score = FindInt(result, FindInt(player, 0, "score", "points"), "score", "points");
            int headshots = FindInt(result, FindInt(player, 0, "headshots", "headshotCount"), "headshots", "headshotCount");
            int mmrDelta = FindInt(result, 0, "mmrDelta", "deltaMmr", "ratingDelta");
            int won = FindFlag(result, "won", "isWinner", "winner") ? 1 : 0;
           int xp = FindInt(result, int.MinValue, "xp", "xpReward", "rewardXp", "earnedXp");
            if (xp == int.MinValue)
                xp = MatchProgressionRuntime.ComputeSmartMatchXp(kills, deaths, assists, headshots, score, won != 0);

            var stats = new List<byte[]>
            {
                StatInt("xp_reworked", xp),
                StatInt("kills", kills),
                StatInt("deaths", deaths),
                StatInt("assists", assists),
                StatInt("score", score),
                StatInt("mmr_delta", mmrDelta),
                StatInt("won", won)
            };

            return BuildProto(o =>
            {
                foreach (byte[] stat in stats)
                    WriteMessage(o, 1, stat);
            });
        }

        private static byte[] BuildPlayer(BsonDocument player, BsonDocument result)
        {
            MatchPlayerInfo profile = GetPlayerInfo(player, result);

            return BuildProto(o =>
            {
                WriteString(o, 1, profile.Id);
                WriteString(o, 2, profile.Uid);
                WriteString(o, 3, profile.Name);
                WriteString(o, 4, profile.AvatarId);

                int team = FindInt(player, FindInt(result, 0, "team"), "team", "currentTeam");
                if (team is not 1 and not 2)
                {
                    int matchTeam = FindInt(player, FindInt(result, -1, "matchTeam"), "matchTeam");
                    team = matchTeam is 0 or 1 ? matchTeam + 1 : 0;
                }
                int rank = GetInt(result, "newRank", GetInt(result, "oldRank"));
                int status = GetPlayerStatus(player, result);

                byte[][] properties =
                {
                    PropInt("Team", team),
                    PropInt("Kills", FindInt(player, GetInt(result, "kills"), "kills", "killCount")),
                   PropInt("Death", FindInt(player, FindInt(result, 0, "deaths", "deathCount"), "deaths", "deathCount")),
                    PropInt("Assists", FindInt(player, GetInt(result, "assists"), "assists", "assistCount")),
                    PropInt("Score", FindInt(player, GetInt(result, "score"), "score", "points")),
                    PropInt("Mvp", FindInt(player, FindInt(result, 0, "mvp", "mvpCount"), "mvp", "mvpCount")),
                    PropInt("DeltaMmr", GetInt(result, "mmrDelta")),
                    PropInt("Mmr", GetInt(result, "newMmr", GetInt(result, "oldMmr"))),
                   PropInt("Rank", rank),
                    PropInt("Status", status),
                    PropInt("Ping", FindInt(player, GetInt(result, "ping"), "ping")),
                    PropString("LobbyId", FindString(player, GetString(result, "lobbyId"), "lobbyId"))
                };

                foreach (byte[] property in properties)
                    WriteMessage(o, 5, property);

                WriteMessage(o, 6, BuildReward(player, result));
           });
        }

       private static string GetCreatorId(BsonDocument document)
        {
            string creator = FindString(document, string.Empty, "creatorId", "creatorGpid", "masterPlayerId", "ownerId");
            if (!string.IsNullOrWhiteSpace(creator)) return creator;

            if (document != null && document.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray)
            {
                foreach (BsonValue item in playersValue.AsBsonArray.Where(x => x.IsBsonDocument))
                {
                    string id = FindString(item.AsBsonDocument, string.Empty, "playerId", "id", "profileId", "accountId");
                    if (!string.IsNullOrWhiteSpace(id)) return id;
                }
            }
            return string.Empty;
        }

        private static byte[] BuildMatch(BsonDocument document)
        {
            if (document == null) return Array.Empty<byte>();
            try { MatchProgressionRuntime.Apply(document); }
            catch { }

            var results = new Dictionary<string, BsonDocument>(StringComparer.Ordinal);
            if (document.TryGetValue("playerResults", out BsonValue resultsValue) && resultsValue.IsBsonArray)
           {
                foreach (BsonValue item in resultsValue.AsBsonArray.Where(x => x.IsBsonDocument))
                {
                    BsonDocument entry = item.AsBsonDocument;
                    string id = FindString(entry, string.Empty, "playerId", "id", "profileId", "accountId");
                    if (string.IsNullOrEmpty(id)) continue;
                    results[id] = entry.TryGetValue("result", out BsonValue nested) && nested.IsBsonDocument
                        ? nested.AsBsonDocument
                        : entry;
                }
            }

             DateTime started = GetDate(document, "startedAt");
            DateTime finished = GetDate(document, "finishedAt");

            return BuildProto(o =>
            {
                WriteString(o, 1, GetString(document, "matchId", GetString(document, "_id")));

                WriteString(o, 3, GetCreatorId(document));

                WriteString(o, 4, GetString(document, "region", "eur"));

                WriteString(o, 5, GetString(document, "version", "0.33.0"));
                 if (started != DateTime.MinValue)
                    WriteLong(o, 6, new DateTimeOffset(started).ToUnixTimeMilliseconds());

                if (finished != DateTime.MinValue)
                    WriteLong(o, 7, new DateTimeOffset(finished).ToUnixTimeMilliseconds());
                WriteString(o, 8, GetString(document, "seasonId", "season-1"));

                byte[][] properties =
                {
                    PropString("LevelName", GetString(document, "map")),
                    PropString("GameMode", GetString(document, "mode")),
                    PropInt("Score1", GetTeamScore(document, true)),
                    PropInt("Score2", GetTeamScore(document, false)),
                    PropInt("TrScore", GetTeamScore(document, true)),
                    PropInt("CtScore", GetTeamScore(document, false)),
                    PropInt("ScoreTr", GetTeamScore(document, true)),
                    PropInt("ScoreCt", GetTeamScore(document, false)),
                    PropInt("Team1Score", GetTeamScore(document, true)),
                    PropInt("Team2Score", GetTeamScore(document, false)),
                    PropInt("StableTeam0Score", FindInt(document, GetTeamScore(document, true), "matchTeam0Score", "team0Score")),
                    PropInt("StableTeam1Score", FindInt(document, GetTeamScore(document, false), "matchTeam1Score", "team1Score")),
                    PropInt("WinTeam", FindInt(document, 0, "winningTeam", "winTeam", "winnerTeam")),
                    PropBool("IsGiveUp", GetBool(document, "isGiveUp"))
                };

                foreach (byte[] property in properties)
                    WriteMessage(o, 10, property);

                 if (document.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray)
                {
                   foreach (BsonValue item in playersValue.AsBsonArray.Where(x => x.IsBsonDocument))
                    {
                        BsonDocument player = item.AsBsonDocument;
                        string playerId = FindString(player, string.Empty, "playerId", "id", "profileId", "accountId");
                        results.TryGetValue(playerId, out BsonDocument result);
                       BsonDocument resultDoc = result ?? new BsonDocument();

                        WriteMessage(o, 11, BuildPlayer(player, resultDoc));
                    }
                }
             });
        }

        private static (string playerId, int offset, int length) ReadListRequest(RpcRequest request, string fallback)
        {
            string playerId = fallback;
            int offset = 0;
           int length = 20;

             try
           {
                if (request.Params == null || request.Params.Count == 0)
                     return (playerId, offset, length);

                byte[] raw = request.Params[0].GetBytesSafe();
                var input = new CodedInputStream(raw);
                uint tag;
                while ((tag = input.ReadTag()) != 0)
                {
                    int field = WireFormat.GetTagFieldNumber(tag);
                    if (field == 1)
                    {
                        playerId = input.ReadString();
                    }
                    else if (field == 2)
                   {
                        var nested = new CodedInputStream(input.ReadBytes().ToByteArray());
                        uint nestedTag;
                        while ((nestedTag = nested.ReadTag()) != 0)
                        {
                            int nestedField = WireFormat.GetTagFieldNumber(nestedTag);
                            if (nestedField == 1) offset = nested.ReadInt32();
                            else if (nestedField == 2) length = nested.ReadInt32();
                            else nested.SkipLastField();
                        }
                    }
                    else
                    {
                        input.SkipLastField();
                    }
                }
           }
            catch { }

            if (string.IsNullOrWhiteSpace(playerId)) playerId = fallback;
            return (playerId, Math.Max(0, offset), Math.Max(1, Math.Min(length <= 0 ? 20 : length, 50)));
       }

        private string GetPlayerId() =>
            ServerState.Users.TryGetValue(_session.TcpClient, out string id) ? id : string.Empty;
       public override void Invoke(RpcRequest request)
        {
            try
            {
                if (request.MethodName == "getCurrentPlayerLastMatch" || request.MethodName == "getPlayerLastMatch")
                {
                    BsonDocument match = RankedAuthorityRepository.Instance.GetLastPlayerMatch(GetPlayerId());

                     byte[] response = BuildProto(o =>
                    {
                        if (match != null)
                            WriteMessage(o, 1, BuildMatch(match));
                    });

                   RpcResponseWriter.SendPayload(_session, request.Id, response);
                    return;
                }
                if (request.MethodName == "getPlayerMatches")
                {
                    var query = ReadListRequest(request, GetPlayerId());
                    List<BsonDocument> matches = RankedAuthorityRepository.Instance
                        .GetPlayerMatches(query.playerId, query.offset, query.length);

                     byte[] response = BuildProto(o =>
                    {
                        foreach (BsonDocument match in matches)
                            WriteMessage(o, 1, BuildMatch(match));
                    });
                    RpcResponseWriter.SendPayload(_session, request.Id, response);
                    return;
                }

                if (request.MethodName == "getMatch")
                {
                    string matchId = ReadMatchId(request);
                    BsonDocument match = RankedAuthorityRepository.Instance.GetMatch(matchId);

                    byte[] response = BuildProto(o =>
                    {
                        if (match != null)
                            WriteMessage(o, 1, BuildMatch(match));
                   });
                    if (match != null)
RpcResponseWriter.SendPayload(_session, request.Id, response);

                    return;
                }

                if (request.MethodName == "getClanMatches" ||
                    request.MethodName == "getClanLastMatch")
               {
                     RpcResponseWriter.SendPayload(_session, request.Id, Array.Empty<byte>());
                    return;
                }

                RpcResponseWriter.SendNotFound(_session, request.Id);

            }
            catch (System.Exception)
            {
                RpcResponseWriter.SendPayload(_session, request.Id, Array.Empty<byte>());
            }
        }
   }
}
