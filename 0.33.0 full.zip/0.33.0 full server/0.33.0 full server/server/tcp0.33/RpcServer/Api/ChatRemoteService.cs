using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using RpcException = Axlebolt.RpcSupport.Protobuf.Exception;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;
using TspServer.RpcServer;

namespace TspServer.RpcServer.Api
{

    public class ChatRemoteService : RpcHandler
    {
        public ChatRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request)
        {
            try
            {
                EnsureMessageEvents();


                switch (request.MethodName)
                {
                     case "getChatUsersLite": Rpc_GetChatUsersLite(request.Id); return;
                    case "getChatUsers2": Rpc_GetChatUsersV2(request, 0, 0, false); return;
                    case "getChatUsersByPage2": Rpc_GetChatUsersByPage(request); return;
                    case "getChatUsersByOffset2": Rpc_GetChatUsersByOffset(request); return;
                    case "getUnreadChatUsersCount2": Rpc_GetUnreadChatUsersCountV2(request); return;
                    case "getFriendMsgsByOffset2": Rpc_GetFriendMsgsByOffset(request); return;
                    case "getFriendMsgsByPage2": Rpc_GetFriendMsgsByPage(request); return;
                    case "getChatUser": Rpc_GetChatUser(request); return;
                    case "sendFriendMsg2": Rpc_SendFriendMsgV2(request); return;
                    case "readFriendMsgs2": Rpc_ReadFriendMsgsV2(request); return;
                   case "deleteFriendMsgs2": Rpc_DeleteFriendMsgsV2(request); return;
                    case "sendGroupMsg2": Rpc_SendGroupMsg(request); return;
                    case "getGroupMsgs2": Rpc_GetGroupMsgs(request); return;
                    case "readGroupMsgs2": Rpc_ReadGroupMsgs(request); return;
                    case "deleteGroupMsgs2": Rpc_DeleteGroupMsgs(request); return;
                    case "sendGlobalChatMessage2":
                    case "sendGlobalChatMessage": Rpc_SendGlobalChatMessage(request); return;
                    case "getChatUsers": Rpc_GetChatUsers(request.Id); return;
                    case "getUnreadChatUsersCount": Rpc_GetUnreadChatUsersCount(request.Id); return;
                     case "sendFriendMsg": Rpc_SendFriendMsg(request.Params.ToArray(), request.Id); return;

                    case "getFriendMsgsByOffset": Rpc_GetFriendMsgs_ByOffset(request.Params.ToArray(), request.Id); return;
                    case "getFriendMsgs": Rpc_GetFriendMsgs_PageSize(request.Params.ToArray(), request.Id); return;
                    case "getFriendMsgsByPage": Rpc_GetFriendMsgs_ByPage(request.Params.ToArray(), request.Id); return;

                    case "readFriendMsgs": Rpc_ReadFriendMsgs(request.Params.ToArray(), request.Id); return;
                    case "deleteFriendMsgs": Rpc_DeleteFriendMsgs(request.Params.ToArray(), request.Id); return;

                    case "sendGroupMsg": Rpc_SendGroupMsgLegacy(request.Params?.ToArray(), request.Id); return;
                    case "getGroupMsgs": Rpc_GetGroupMsgsLegacy(request.Params?.ToArray(), request.Id); return;
                    case "readGroupMsgs": Rpc_ReadGroupMsgsLegacy(request.Params?.ToArray(), request.Id); return;
                    case "deleteGroupMsgs": Rpc_DeleteGroupMsgsLegacy(request.Params?.ToArray(), request.Id); return;

                     default:
                        Send404(request.Id); return;
               }
            }
            catch
            {
               Send500(request.Id);
            }
        }
        private void EnsureMessageEvents()
        {
            if (!TryGetMyId(out string myId))
               return;
            ServerState.EnsureConnectionEventSender(
               myId,
                _session.TcpClient,
                () => new MessagesRemoteEventSender(_session));
        }

        private void Rpc_GetFriendMsgs_ByOffset(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId)) { Send401(guid); return; }
             if (values == null || values.Length < 2) { SendRpcResult(guid, Array.Empty<UserMessage>()); return; }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
            var (page, size) = ProtoOffsetParser.ParseOffset(values[1]);

            SendMsgs(myId, friendId, page, size, guid);
        }

        private void Rpc_GetFriendMsgs_PageSize(BinaryValue[] values, string guid)
       {
            if (!TryGetMyId(out var myId)) { Send401(guid); return; }
            if (values == null || values.Length < 3) { SendRpcResult(guid, Array.Empty<UserMessage>()); return; }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
            int page = (int)new RpcValueReader(typeof(int)).FromBytes(values[1]);
            int size = (int)new RpcValueReader(typeof(int)).FromBytes(values[2]);

            SendMsgs(myId, friendId, page, size, guid);
        }

        private void Rpc_GetFriendMsgs_ByPage(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId)) { Send401(guid); return; }
            if (values == null || values.Length < 2) { SendRpcResult(guid, Array.Empty<UserMessage>()); return; }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);

            var (page, size) = ProtoPageParser.ParsePage(values[1]);

            SendMsgs(myId, friendId, page, size, guid);
        }
        internal static class ProtoPageParser
        {
            public static (int page, int size) ParsePage(BinaryValue pageBinaryValue)
            {
                try
                {
                    byte[] data = GetBytes(pageBinaryValue);
                    if (data == null || data.Length == 0)
                        return (0, 20);

                    int idx = 0;
                    int page = 0;
                     int size = 20;

                    while (idx < data.Length)
                    {
                        uint tag = ReadVarint(data, ref idx);
                       int field = (int)(tag >> 3);
                        int wire = (int)(tag & 0x7);

                        if (wire == 0)
                        {
                            ulong v = ReadVarint64(data, ref idx);
                            if (field == 1) page = (int)v;
                            else if (field == 2) size = (int)v;

                        }
                        else if (wire == 2)
                         {
                             int len = (int)ReadVarint64(data, ref idx);
                            idx += len;
                        }
                        else
                        {
                            break;
                        }
                    }
                     return (page, size);
                }
               catch
                {
                    return (0, 20);
               }
           }

            private static byte[] GetBytes(BinaryValue bv)
            {
                if (bv == null) return Array.Empty<byte>();

                Type type = bv.GetType();
                PropertyInfo property = type.GetProperty("Bytes") ?? type.GetProperty("Value") ?? type.GetProperty("Data");
                if (property != null)
                {
                    object obj = property.GetValue(bv);
                    if (obj is byte[] b) return b;
                    if (obj is Google.Protobuf.ByteString bs) return bs.ToByteArray();
                }

                FieldInfo field = type.GetField("Bytes") ?? type.GetField("Value") ?? type.GetField("Data");
                if (field != null)
                {
                    object obj = field.GetValue(bv);
                    if (obj is byte[] b) return b;
                    if (obj is Google.Protobuf.ByteString bs) return bs.ToByteArray();
                }

                return Array.Empty<byte>();
            }

            private static uint ReadVarint(byte[] data, ref int idx) => (uint)ReadVarint64(data, ref idx);

            private static ulong ReadVarint64(byte[] data, ref int idx)
            {
                ulong result = 0;
                 int shift = 0;
                while (idx < data.Length)
                {
                    byte b = data[idx++];
                    result |= ((ulong)(b & 0x7F) << shift);
                    if ((b & 0x80) == 0) return result;

                    shift += 7;
                    if (shift > 63) throw new InvalidDataException("Varint is too long.");
                }

                throw new EndOfStreamException("Unexpected end of stream while reading varint.");
            }
        }

        private void SendMsgs(string myId, string friendId, int page, int size, string guid)
        {
            if (page < 0) page = 0;
            if (size <= 0) size = 20;
            if (size > 100) size = 100;

            var docs = ChatMongoRepo.GetFriendMessages(myId, friendId, page, size);

            var arr = docs
                .OrderByDescending(x => x.Timestamp)
                .Select(d => new UserMessage
                {
                    SenderId = d.SenderId,
                    Message = d.Message ?? string.Empty,
                    Timestamp = d.Timestamp,
                   IsRead = d.IsRead
                })
                .ToArray();

            SendRpcResult(guid, arr);
        }

        private static byte[] SerializeUserMessages(IEnumerable<UserMessage> messages)
        {
            return ContractWire.Build(w =>
             {
                foreach (UserMessage message in messages ?? Array.Empty<UserMessage>())
                    w.Message(1, SocialContract.SerializeUserMessage(message));
            });
         }

        private sealed class ChatCard
        {
            public ServerChatDialogStateDoc FriendDialog;
            public ServerGroupChatStateDoc GroupDialog;
            public long Timestamp => FriendDialog?.LastTimestamp ?? GroupDialog?.LastTimestamp ?? 0L;
        }

        private byte[] SerializeChatUser(string myId, ServerChatDialogStateDoc dialog)
        {
            if (dialog == null) return Array.Empty<byte>();
            PlayerFriend friend = MakeFallbackFriend(dialog.FriendId);
            try
            {
                if (ObjectId.TryParse(dialog.FriendId, out ObjectId friendObjectId))
                {
                    PlayerDocument document = BoltMainDatabaseProvider.Instance.GetPlayerDocument(friendObjectId);
                    if (document != null) friend = document.GetPlayerFriend(myId);
                }
            }
            catch
             {
            }

            return ContractWire.Build(w =>
            {
                w.Message(1, SocialContract.SerializePlayerFriend(friend));
                w.String(3, dialog.LastMessage ?? string.Empty);
               w.Varint(4, dialog.LastTimestamp);
                w.Int32(5, Math.Max(0, dialog.UnreadCount));
            });
        }

        private static byte[] SerializeGroup(ServerGroupChatStateDoc dialog)
        {
            if (dialog == null) return Array.Empty<byte>();
             return ContractWire.Build(w =>
            {
                w.String(1, dialog.GroupId ?? string.Empty);
                w.String(2, string.IsNullOrWhiteSpace(dialog.Name) ? dialog.GroupId : dialog.Name);
                w.String(3, dialog.AvatarId ?? string.Empty);
            });
        }

        private static byte[] SerializeChatUser(ServerGroupChatStateDoc dialog)
        {
            if (dialog == null) return Array.Empty<byte>();
            return ContractWire.Build(w =>
            {
               w.Message(2, SerializeGroup(dialog));
                w.String(3, dialog.LastMessage ?? string.Empty);
                w.Varint(4, dialog.LastTimestamp);
                 w.Int32(5, Math.Max(0, dialog.UnreadCount));
            });
         }

        private List<ChatCard> GetChatCards(string myId)
        {
            var result = new List<ChatCard>();
           result.AddRange(ChatMongoRepo.GetDialogs(myId).Select(x => new ChatCard { FriendDialog = x }));
            result.AddRange(ChatMongoRepo.GetGroupDialogs(myId).Select(x => new ChatCard { GroupDialog = x }));
           return result.OrderByDescending(x => x.Timestamp).ToList();
        }

        private void Rpc_GetChatUsersV2(RpcRequest request, int offset, int length, bool bounded)
         {
           if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            List<ChatCard> cards = GetChatCards(myId);
            IEnumerable<ChatCard> selected = cards;
            if (bounded)
                selected = selected.Skip(Math.Max(0, offset)).Take(Math.Max(1, Math.Min(length, 100)));
            ChatCard[] materialized = selected.ToArray();

            byte[] response = ContractWire.Build(wrapper =>
            {
                foreach (ChatCard card in materialized)
                {
                    byte[] payload = card.FriendDialog != null
                        ? SerializeChatUser(myId, card.FriendDialog)
                        : SerializeChatUser(card.GroupDialog);
                    wrapper.Message(1, payload);
               }
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void Rpc_GetChatUsersByPage(RpcRequest request)
       {
            byte[] raw = ContractWire.Param(request);
            byte[] pageRaw = ContractWire.ReadBytesField(raw, 1);
            int page = Math.Max(0, ContractWire.ReadIntField(pageRaw, 1, 0));
            int size = Math.Max(1, Math.Min(ContractWire.ReadIntField(pageRaw, 2, 20), 100));
            int offset = page > int.MaxValue / size ? int.MaxValue : page * size;
           Rpc_GetChatUsersV2(request, offset, size, true);
        }

        private void Rpc_GetChatUsersByOffset(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            byte[] offsetRaw = ContractWire.ReadBytesField(raw, 1);
            int offset = Math.Max(0, ContractWire.ReadIntField(offsetRaw, 1, 0));
           int length = Math.Max(1, Math.Min(ContractWire.ReadIntField(offsetRaw, 2, 20), 100));
            Rpc_GetChatUsersV2(request, offset, length, true);
         }

        private void Rpc_GetUnreadChatUsersCountV2(RpcRequest request)
       {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            int count = ChatMongoRepo.GetUnreadDialogsCount(myId) + ChatMongoRepo.GetUnreadGroupDialogsCount(myId);
            byte[] response = ContractWire.Build(w => w.Int32(1, count, true));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void Rpc_SendGlobalChatMessage(RpcRequest request)
        {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
            string topic = ContractWire.ReadStringField(raw, 1, string.Empty).Trim();
            string message = ContractWire.ReadStringField(raw, 2, string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(topic) || string.IsNullOrWhiteSpace(message))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            if (message.Length > 512)
            {
                ContractWire.SendException(_session, request.Id, 400);
               return;
            }

            long timestamp = NowMs();
            byte[] userMessage = ContractWire.Build(w =>
            {
                w.String(1, message);
                 w.String(2, myId);
                 w.Varint(3, timestamp);
            });
            byte[] eventPayload = ContractWire.Build(w => w.Message(1, userMessage));

            foreach (ClientSession subscriber in BoltEvents.Subscribers(topic).Distinct())
            {
                try
                {
                    var envelope = BoltEventContract.CreateRaw(
                       "GlobalChatRemoteEventListener",
                        "onIncomingGlobalChatMessageEvent",
                        eventPayload);
                    subscriber.SendResponse(new ResponseMessage { EventResponse = envelope });
                }
                catch
                {
                   BoltEvents.RemoveUser(subscriber);
                }
            }

            ContractWire.SendEmpty(_session, request.Id);
        }

        private void Rpc_SendGroupMsg(RpcRequest request)
         {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            byte[] raw = ContractWire.Param(request);
            string groupId = ContractWire.ReadStringField(raw, 1, string.Empty).Trim();
            string message = ContractWire.ReadStringField(raw, 2, string.Empty);
            if (string.IsNullOrWhiteSpace(groupId) || string.IsNullOrWhiteSpace(message))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
           long timestamp = NowMs();
             ChatMongoRepo.AddGroupMessage(myId, groupId, message, timestamp);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private static byte[] SerializeGroupMessages(string ownerId, IEnumerable<ServerGroupChatMessageDoc> docs)
        {
            return ContractWire.Build(wrapper =>
            {
                foreach (ServerGroupChatMessageDoc doc in docs ?? Array.Empty<ServerGroupChatMessageDoc>())
                {
                    bool isRead = string.Equals(doc.SenderId, ownerId, StringComparison.Ordinal) ||
                                  (doc.ReadBy?.Contains(ownerId) ?? false);
                    byte[] message = ContractWire.Build(item =>
                    {
                        item.String(1, doc.SenderId ?? string.Empty);
                        item.String(2, doc.Message ?? string.Empty);
                        item.Varint(3, doc.Timestamp);
                        item.Bool(4, isRead);
                    });
                    wrapper.Message(1, message);
                }
             });
        }

        private void Rpc_GetGroupMsgs(RpcRequest request)
        {
            if (!TryGetMyId(out string myId))
           {
                ContractWire.SendException(_session, request.Id, 401);
                return;
             }
            byte[] raw = ContractWire.Param(request);
            string groupId = ContractWire.ReadStringField(raw, 1, string.Empty).Trim();
            int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int pageSize = Math.Max(1, Math.Min(ContractWire.ReadIntField(raw, 3, 20), 100));
            if (string.IsNullOrWhiteSpace(groupId))
             {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            ChatMongoRepo.EnsureGroupParticipant(myId, groupId);
           ServerGroupChatMessageDoc[] docs = ChatMongoRepo.GetGroupMessages(myId, groupId, page, pageSize);
            byte[] response = SerializeGroupMessages(myId, docs);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void Rpc_ReadGroupMsgs(RpcRequest request)
       {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }
            string groupId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (!string.IsNullOrWhiteSpace(groupId)) ChatMongoRepo.ReadGroupMessages(myId, groupId);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void Rpc_DeleteGroupMsgs(RpcRequest request)
        {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string groupId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (!string.IsNullOrWhiteSpace(groupId)) ChatMongoRepo.DeleteGroupMessages(myId, groupId);
            ContractWire.SendEmpty(_session, request.Id);
        }

         private void Rpc_SendGroupMsgLegacy(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out string myId)) { Send401(guid); return; }
            if (values == null || values.Length < 2) { SendOk(guid); return; }
            string groupId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
           string message = (string)new RpcValueReader(typeof(string)).FromBytes(values[1]);
            if (!string.IsNullOrWhiteSpace(groupId) && !string.IsNullOrWhiteSpace(message))
               ChatMongoRepo.AddGroupMessage(myId, groupId, message, NowMs());
            SendOk(guid);
        }

        private void Rpc_GetGroupMsgsLegacy(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out string myId)) { Send401(guid); return; }
            if (values == null || values.Length < 1) { SendRpcResult(guid, Array.Empty<UserMessage>()); return; }
            string groupId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
            int page = values.Length > 1 ? (int)new RpcValueReader(typeof(int)).FromBytes(values[1]) : 0;
            int size = values.Length > 2 ? (int)new RpcValueReader(typeof(int)).FromBytes(values[2]) : 20;
            ChatMongoRepo.EnsureGroupParticipant(myId, groupId);
            UserMessage[] result = ChatMongoRepo.GetGroupMessages(myId, groupId, Math.Max(0, page), Math.Max(1, Math.Min(size, 100)))
                 .Select(x => new UserMessage { SenderId = x.SenderId, Message = x.Message ?? string.Empty, Timestamp = x.Timestamp, IsRead = x.SenderId == myId || (x.ReadBy?.Contains(myId) ?? false) })
                .ToArray();
            SendRpcResult(guid, result);
        }

        private void Rpc_ReadGroupMsgsLegacy(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out string myId)) { Send401(guid); return; }
            if (values != null && values.Length > 0)
                ChatMongoRepo.ReadGroupMessages(myId, (string)new RpcValueReader(typeof(string)).FromBytes(values[0]));
            SendOk(guid);
        }

        private void Rpc_DeleteGroupMsgsLegacy(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out string myId)) { Send401(guid); return; }
             if (values != null && values.Length > 0)
                 ChatMongoRepo.DeleteGroupMessages(myId, (string)new RpcValueReader(typeof(string)).FromBytes(values[0]));
            SendOk(guid);
        }

        private void Rpc_GetFriendMsgsByOffset(RpcRequest request)
         {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }
            byte[] raw = ContractWire.Param(request);
            string friendId = ContractWire.ReadStringField(raw, 1, string.Empty);
            byte[] offsetRaw = ContractWire.ReadBytesField(raw, 2);
            int offset = Math.Max(0, ContractWire.ReadIntField(offsetRaw, 1, 0));
            int length = Math.Max(1, Math.Min(ContractWire.ReadIntField(offsetRaw, 2, 20), 100));
            if (string.IsNullOrWhiteSpace(friendId))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            UserMessage[] messages = ChatMongoRepo.GetFriendMessagesByOffset(myId, friendId, offset, length)
                .OrderByDescending(x => x.Timestamp)
                .Select(d => new UserMessage
                {
                    SenderId = d.SenderId,
                    Message = d.Message ?? string.Empty,
                    Timestamp = d.Timestamp,
                    IsRead = d.IsRead
                })
                .ToArray();
            byte[] response = SerializeUserMessages(messages);
            ContractWire.SendRaw(_session, request.Id, response);
       }

        private void Rpc_GetChatUser(RpcRequest request)
        {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string friendId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(friendId))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
           ServerChatDialogStateDoc dialog = ChatMongoRepo.GetDialogs(myId)
                .FirstOrDefault(x => string.Equals(x.FriendId, friendId, StringComparison.Ordinal));
            PlayerFriend friend = MakeFallbackFriend(friendId);
            try
            {
                if (ObjectId.TryParse(friendId, out ObjectId friendObjectId))
                {
                    PlayerDocument document = BoltMainDatabaseProvider.Instance.GetPlayerDocument(friendObjectId);
                    if (document != null) friend = document.GetPlayerFriend(myId);
                }
            }
            catch { }

            byte[] chatUser = ContractWire.Build(w =>
            {
                w.Message(1, SocialContract.SerializePlayerFriend(friend));
                w.String(3, dialog?.LastMessage ?? string.Empty);
                w.Varint(4, dialog?.LastTimestamp ?? 0L);
                w.Int32(5, Math.Max(0, dialog?.UnreadCount ?? 0));
            });
            byte[] response = ContractWire.Build(w => w.Message(1, chatUser));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void Rpc_GetFriendMsgsByPage(RpcRequest request)
       {
           if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
            string friendId = ContractWire.ReadStringField(raw, 1, string.Empty);
            byte[] pageRaw = ContractWire.ReadBytesField(raw, 2);
            int page = Math.Max(0, ContractWire.ReadIntField(pageRaw, 1, 0));
            int size = Math.Max(1, Math.Min(ContractWire.ReadIntField(pageRaw, 2, 20), 100));

            if (string.IsNullOrWhiteSpace(friendId))
            {
                 ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            UserMessage[] messages = ChatMongoRepo.GetFriendMessages(myId, friendId, page, size)
                .OrderByDescending(x => x.Timestamp)
                .Select(d => new UserMessage
                {
                    SenderId = d.SenderId,
                   Message = d.Message ?? string.Empty,
                    Timestamp = d.Timestamp,
                    IsRead = d.IsRead
                })
                 .ToArray();

            byte[] response = SerializeUserMessages(messages);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void Rpc_SendFriendMsgV2(RpcRequest request)
       {
            if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
            string friendId = ContractWire.ReadStringField(raw, 1, string.Empty);
            string message = ContractWire.ReadStringField(raw, 2, string.Empty);
            if (string.IsNullOrWhiteSpace(friendId) || string.IsNullOrWhiteSpace(message))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            if (!PlayerExists(friendId))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            if (IsBlockedByFriend(myId, friendId))
            {
                ContractWire.SendException(_session, request.Id, 3102);
                return;
            }

            long timestamp = NowMs();
            ChatMongoRepo.AddFriendMessage(myId, friendId, message, timestamp);
            ContractWire.SendEmpty(_session, request.Id);
             PushMsgToOnlineFriend(friendId, myId, message, timestamp);
        }

        private void Rpc_ReadFriendMsgsV2(RpcRequest request)
        {
           if (!TryGetMyId(out string myId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string friendId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (!string.IsNullOrWhiteSpace(friendId))
               ChatMongoRepo.ReadFriendMessages(myId, friendId);
            ContractWire.SendEmpty(_session, request.Id);
        }

       private void Rpc_DeleteFriendMsgsV2(RpcRequest request)
        {
            if (!TryGetMyId(out string myId))
           {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string friendId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
           if (!string.IsNullOrWhiteSpace(friendId))
                ChatMongoRepo.DeleteFriendMessages(myId, friendId);
            ContractWire.SendEmpty(_session, request.Id);
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }
        private void Rpc_GetChatUsersLite(string guid)
       {
            if (!TryGetMyId(out var myId))
            {
                 ContractWire.SendException(_session, guid, 401);
                return;
            }

            List<ChatCard> cards = GetChatCards(myId);
           byte[] response = ContractWire.Build(wrapper =>
            {
                foreach (ChatCard card in cards)
                 {
                   byte[] chatUser = ContractWire.Build(item =>
                    {
                        if (card.FriendDialog != null)
                        {
                            item.String(1, card.FriendDialog.FriendId ?? string.Empty);
                            item.String(3, card.FriendDialog.LastMessage ?? string.Empty);
                            item.Varint(4, card.FriendDialog.LastTimestamp);
                            item.Int32(5, Math.Max(0, card.FriendDialog.UnreadCount));
                         }
                        else if (card.GroupDialog != null)
                        {
                            item.String(2, card.GroupDialog.GroupId ?? string.Empty);
                             item.String(3, card.GroupDialog.LastMessage ?? string.Empty);
                            item.Varint(4, card.GroupDialog.LastTimestamp);
                            item.Int32(5, Math.Max(0, card.GroupDialog.UnreadCount));
                       }
                   });
                    wrapper.Message(1, chatUser);
                }
            });

            ContractWire.SendRaw(_session, guid, response);
        }

        private void Rpc_GetChatUsers(string guid)
         {
            if (!TryGetMyId(out var myId))
            {
                Send401(guid);
                return;
            }

            var dialogs = ChatMongoRepo.GetDialogs(myId);

            var boltMain = BoltMainDatabaseProvider.Instance;

            var result = dialogs
                .OrderByDescending(d => d.LastTimestamp)
                .Select(d =>
                {
                    PlayerFriend pf = null;

                   if (ObjectId.TryParse(d.FriendId, out var friendOid))
                    {
                        try
                         {
                             var friendDoc = boltMain.GetPlayerDocument(friendOid);
                            if (friendDoc != null)
                            {
                                pf = friendDoc.GetPlayerFriend(myId);
                            }
                        }
                        catch
                        {
                        }
                    }

                    if (pf == null)
                    {
                        pf = MakeFallbackFriend(d.FriendId);
                     }

                    var cu = new ChatUser
                    {
                        Player = pf,
                        Group = null,
                        Message = d.LastMessage ?? "",
                        Timestamp = d.LastTimestamp
                    };

                    TrySetUnreadCount(cu, d.UnreadCount);
                    return cu;
                 })
                .ToArray();

            SendRpcResult(guid, result);
        }

        private static PlayerFriend MakeFallbackFriend(string friendId)
        {
            return new PlayerFriend
            {
                Player = new Player
                 {
                    Id = friendId,
                    Name = "Unknown"
                },
                RelationshipStatus = RelationshipStatus.None,
                LastRelationshipUpdate = 0
            };
        }

        private void Rpc_GetUnreadChatUsersCount(string guid)
        {
            if (!TryGetMyId(out var myId))
            {
                Send401(guid);
                return;
            }

           int count = ChatMongoRepo.GetUnreadDialogsCount(myId) + ChatMongoRepo.GetUnreadGroupDialogsCount(myId);
            SendRpcResult(guid, count);
        }

        private void Rpc_SendFriendMsg(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId)) { Send401(guid); return; }
            if (values == null || values.Length < 2) { SendOk(guid); return; }

            string peerId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
            string msg = (string)new RpcValueReader(typeof(string)).FromBytes(values[1]);

            if (string.IsNullOrWhiteSpace(peerId) || string.IsNullOrWhiteSpace(msg))
            {
                SendOk(guid);
                return;
            }

            if (IsBlockedByFriend(myId, peerId))
            {
                SendException(guid, 3102);
                return;
            }

            long ts = NowMs();

            ChatMongoRepo.AddFriendMessage(myId, peerId, msg, ts);
            PushMsgToOnlineFriend(receiverId: peerId, senderId: myId, message: msg, timestamp: ts);

            SendOk(guid);
        }

        private bool PlayerExists(string playerId)
       {
            try
            {
                if (!ObjectId.TryParse(playerId, out var oid))
                   return true;

                var boltMain = BoltMainDatabaseProvider.Instance;
               var doc = boltMain.GetPlayerDocument(oid);
                return doc != null;
            }
            catch
            {
                return true;
            }
       }

        private void Rpc_GetFriendMsgs(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId))
            {
                Send401(guid);
                return;
           }

            if (values == null || values.Length < 2)
            {
                SendRpcResult(guid, Array.Empty<UserMessage>());
                return;
            }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);

            var (page, size) = ProtoOffsetParser.ParseOffset(values[1]);

            if (page < 0) page = 0;
            if (size <= 0) size = 20;
            if (size > 100) size = 100;

            var docs = ChatMongoRepo.GetFriendMessages(myId, friendId, page, size);

            var arr = docs
                .OrderByDescending(x => x.Timestamp)
                .Select(d => new UserMessage
                {
                    SenderId = d.SenderId,
                    Message = d.Message ?? string.Empty,
                    Timestamp = d.Timestamp,
                    IsRead = d.IsRead
                })
                .ToArray();

            SendRpcResult(guid, arr);
        }

        private void Rpc_ReadFriendMsgs(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId))
             {
                Send401(guid);
                return;
            }

            if (values == null || values.Length < 1)
            {
                SendOk(guid);
                return;
           }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);

            ChatMongoRepo.ReadFriendMessages(myId, friendId);

            SendOk(guid);
        }

        private void Rpc_DeleteFriendMsgs(BinaryValue[] values, string guid)
        {
            if (!TryGetMyId(out var myId))
            {
                Send401(guid);
               return;
           }

            if (values == null || values.Length < 1)
            {
                SendOk(guid);
                return;
            }

            string friendId = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);

            ChatMongoRepo.DeleteFriendMessages(myId, friendId);

            SendOk(guid);
        }

        private bool TryGetMyId(out string myId)
        {
            myId = string.Empty;
            return SessionIdentity.TryGetPlayerId(_session, out myId);
        }

        private static long NowMs()
        {
            return (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds;
        }

        private void PushMsgToOnlineFriend(string receiverId, string senderId, string message, long timestamp)
        {
            var payload = new UserMessage
            {
                SenderId = senderId,
                Message = message,
                Timestamp = timestamp,
                IsRead = false
            };
            SocialEventDelivery.Send<MessagesRemoteEventSender>(
                receiverId,
               "dm",
                "onMsgFromFriend",
                new object[] { payload });
         }

        private bool IsBlockedByFriend(string myId, string friendId)
        {
             var boltGame = BoltGameDatabaseProvider.Instance;
            var friends = boltGame.GetPlayerFriends(myId);
            var doc = friends.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);

            if (doc == null)
                return false;

            if (doc.relationshipStatus == RelationshipStatusCustom.Blocked && doc.playerInitiatorId != myId)
                return true;

            return false;
        }

         private void SendRpcResult<T>(string guid, T obj)
       {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new RpcValueWriter(typeof(T)).ToBytes(obj)
                }
            });
        }

       private void SendOk(string guid)
       {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }

         private void Send401(string guid) => SendException(guid, 401);
        private void Send404(string guid) => SendException(guid, 404);
        private void Send500(string guid) => SendException(guid, 500);

        private void SendException(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new RpcException
                    {
                       Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
             });
         }

        private static void TrySetUnreadCount(ChatUser chatUser, int unread)
        {
            try
            {
                 var t = chatUser.GetType();
                var prop = t.GetProperty("UnreadMsgsCount") ?? t.GetProperty("UnreadMsgsCount_");
                if (prop != null && prop.CanWrite)
               {
                    prop.SetValue(chatUser, unread);
                     return;
                }

                var field = t.GetField("unreadMsgsCount_", BindingFlags.Instance | BindingFlags.NonPublic);
                if (field != null)
                 {
                    field.SetValue(chatUser, unread);
                }
            }
            catch { }
        }
    }

    public class MessagesRemoteEventSender : IEventSender
    {
        private readonly ClientSession User;
        public string eventListenerName { get; set; } = "MessagesRemoteEventListener";

        public MessagesRemoteEventSender(ClientSession user) { User = user; }

        public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse envelope = BoltEventContract.Create(
                eventListenerName, eventName, parameters ?? Array.Empty<object>());
            User.SendResponse(new ResponseMessage { EventResponse = envelope });
        }
    }
}

namespace TspServer.MongoDB.Game
{

    public class ServerChatMessageDoc
    {
        [BsonId]
        public ObjectId Id { get; set; }

         public string DialogId { get; set; }

        public string SenderId { get; set; }
        public string ReceiverId { get; set; }

        public string Message { get; set; }
        public long Timestamp { get; set; }

       public bool IsRead { get; set; }

        public List<string> DeletedBy { get; set; } = new List<string>();
    }

    public class ServerChatDialogStateDoc
     {
        [BsonId]
        public ObjectId Id { get; set; }

        public string OwnerId { get; set; }
        public string FriendId { get; set; }

        public string LastMessage { get; set; }
        public long LastTimestamp { get; set; }

        public int UnreadCount { get; set; }
    }

    public class ServerGroupChatMessageDoc
    {
        [BsonId]
       public ObjectId Id { get; set; }
        public string GroupId { get; set; }
        public string SenderId { get; set; }
        public string Message { get; set; }
        public long Timestamp { get; set; }
        public List<string> ReadBy { get; set; } = new List<string>();
        public List<string> DeletedBy { get; set; } = new List<string>();
    }

    public class ServerGroupChatStateDoc
    {
        [BsonId]
         public ObjectId Id { get; set; }
        public string OwnerId { get; set; }
        public string GroupId { get; set; }
        public string Name { get; set; }
        public string AvatarId { get; set; }
        public string LastMessage { get; set; }
        public long LastTimestamp { get; set; }
        public int UnreadCount { get; set; }
    }

    public static class ChatMongoRepo
    {
       private const string DbName = "Main";
        private const string MessagesCollection = "chat_messages";
        private const string DialogsCollection = "chat_dialog_states";
        private const string GroupMessagesCollection = "chat_group_messages";
        private const string GroupDialogsCollection = "chat_group_states";

        private static IMongoDatabase GetDb()
        {
            object provider = BoltMainDatabaseProvider.Instance;

            if (provider == null)
                throw new InvalidOperationException("Game database provider is not initialized.");

           var type = provider.GetType();
            MongoClient client = null;

            for (Type cur = type; cur != null; cur = cur.BaseType)
            {
                var f = cur.GetField("_client", BindingFlags.Instance | BindingFlags.NonPublic);
                if (f != null)
                {
                    client = f.GetValue(provider) as MongoClient;
                    if (client != null) break;
                }
            }

            if (client == null)
               throw new InvalidOperationException("Mongo client field was not found on the database provider.");

             return client.GetDatabase(DbName);
        }

        private static IMongoCollection<ServerChatMessageDoc> Messages()
        {
            return GetDb().GetCollection<ServerChatMessageDoc>(MessagesCollection);
        }

        private static IMongoCollection<ServerChatDialogStateDoc> Dialogs()
        {
            return GetDb().GetCollection<ServerChatDialogStateDoc>(DialogsCollection);
        }

        private static IMongoCollection<ServerGroupChatMessageDoc> GroupMessages()
        {
            return GetDb().GetCollection<ServerGroupChatMessageDoc>(GroupMessagesCollection);
        }

        private static IMongoCollection<ServerGroupChatStateDoc> GroupDialogs()
        {
           return GetDb().GetCollection<ServerGroupChatStateDoc>(GroupDialogsCollection);
        }

        public static string MakeDialogId(string a, string b)
        {
            return string.CompareOrdinal(a, b) < 0 ? $"{a}_{b}" : $"{b}_{a}";
        }
       public static void AddFriendMessage(string senderId, string receiverId, string msg, long ts)
       {
            var dialogId = MakeDialogId(senderId, receiverId);

            Messages().InsertOne(new ServerChatMessageDoc
            {
                DialogId = dialogId,
                SenderId = senderId,
                ReceiverId = receiverId,
               Message = msg,
                Timestamp = ts,
                IsRead = false
            });

            UpsertDialog(ownerId: senderId, friendId: receiverId, lastMsg: msg, ts: ts, unreadInc: 0);

            UpsertDialog(ownerId: receiverId, friendId: senderId, lastMsg: msg, ts: ts, unreadInc: 1);
        }

        private static void UpsertDialog(string ownerId, string friendId, string lastMsg, long ts, int unreadInc)
        {
             var filter = Builders<ServerChatDialogStateDoc>.Filter.Where(x => x.OwnerId == ownerId && x.FriendId == friendId);

            var update = Builders<ServerChatDialogStateDoc>.Update
                .Set(x => x.LastMessage, lastMsg)
                .Set(x => x.LastTimestamp, ts)
                .Inc(x => x.UnreadCount, unreadInc);

            Dialogs().UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
        }

        private static readonly object RepairLock = new();
        private static bool _indexesReady;

        private static void EnsureIndexes()
        {
            if (_indexesReady) return;
            lock (RepairLock)
            {
                if (_indexesReady) return;
                try
                 {
                    var allDialogs = Dialogs().Find(Builders<ServerChatDialogStateDoc>.Filter.Empty).ToList();
                    foreach (var duplicateGroup in allDialogs.GroupBy(x => (x.OwnerId ?? string.Empty) + "\n" + (x.FriendId ?? string.Empty)).Where(x => x.Count() > 1))
                    {
                        var keep = duplicateGroup.OrderByDescending(x => x.LastTimestamp).First();
                        var removeIds = duplicateGroup.Where(x => x.Id != keep.Id).Select(x => x.Id).ToList();
                        if (removeIds.Count > 0)
                             Dialogs().DeleteMany(Builders<ServerChatDialogStateDoc>.Filter.In(x => x.Id, removeIds));
                    }

                    Messages().Indexes.CreateOne(new CreateIndexModel<ServerChatMessageDoc>(
                        Builders<ServerChatMessageDoc>.IndexKeys
                            .Ascending(x => x.DialogId)
                            .Descending(x => x.Timestamp),
                        new CreateIndexOptions { Name = "idx_dm_dialog_time" }));
                   Dialogs().Indexes.CreateOne(new CreateIndexModel<ServerChatDialogStateDoc>(
                        Builders<ServerChatDialogStateDoc>.IndexKeys
                            .Ascending(x => x.OwnerId)
                            .Ascending(x => x.FriendId),
                        new CreateIndexOptions { Name = "uniq_dm_owner_friend", Unique = true }));
                    GroupMessages().Indexes.CreateOne(new CreateIndexModel<ServerGroupChatMessageDoc>(
                        Builders<ServerGroupChatMessageDoc>.IndexKeys
                           .Ascending(x => x.GroupId)
                            .Descending(x => x.Timestamp),
                       new CreateIndexOptions { Name = "idx_group_dialog_time" }));
                    GroupDialogs().Indexes.CreateOne(new CreateIndexModel<ServerGroupChatStateDoc>(
                        Builders<ServerGroupChatStateDoc>.IndexKeys
                           .Ascending(x => x.OwnerId)
                            .Ascending(x => x.GroupId),
                        new CreateIndexOptions { Name = "uniq_group_owner_group", Unique = true }));
                }
                catch
                {
                }
                _indexesReady = true;
            }
         }

        public static void RepairDialogsFor(string ownerId)
        {
            if (string.IsNullOrWhiteSpace(ownerId)) return;
            EnsureIndexes();
            try
            {
                var ownerFilter = Builders<ServerChatMessageDoc>.Filter.Or(
                    Builders<ServerChatMessageDoc>.Filter.Eq(x => x.SenderId, ownerId),
                    Builders<ServerChatMessageDoc>.Filter.Eq(x => x.ReceiverId, ownerId));
                var notDeletedFilter = Builders<ServerChatMessageDoc>.Filter.Not(
                    Builders<ServerChatMessageDoc>.Filter.AnyEq(x => x.DeletedBy, ownerId));
                var messages = Messages().Find(ownerFilter & notDeletedFilter)
                    .SortByDescending(x => x.Timestamp)
                    .ToList();

                var activeFriendIds = messages
                   .Select(x => x.SenderId == ownerId ? x.ReceiverId : x.SenderId)
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct()
                    .ToList();
               var staleDialogFilter = Builders<ServerChatDialogStateDoc>.Filter.Eq(x => x.OwnerId, ownerId);
                if (activeFriendIds.Count > 0)
                    staleDialogFilter &= Builders<ServerChatDialogStateDoc>.Filter.Nin(x => x.FriendId, activeFriendIds);
                Dialogs().DeleteMany(staleDialogFilter);

                foreach (var group in messages.GroupBy(x => x.SenderId == ownerId ? x.ReceiverId : x.SenderId))
                {
                    string friendId = group.Key;
                    if (string.IsNullOrWhiteSpace(friendId)) continue;
                    var last = group.OrderByDescending(x => x.Timestamp).First();
                    int unread = group.Count(x => x.ReceiverId == ownerId && !x.IsRead);
                     var filter = Builders<ServerChatDialogStateDoc>.Filter.Where(x => x.OwnerId == ownerId && x.FriendId == friendId);
                    var update = Builders<ServerChatDialogStateDoc>.Update
                        .Set(x => x.LastMessage, last.Message ?? string.Empty)
                        .Set(x => x.LastTimestamp, last.Timestamp)
                         .Set(x => x.UnreadCount, unread);
                    Dialogs().UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
                }

            }
            catch
            {
            }
        }

        public static List<ServerChatDialogStateDoc> GetDialogs(string ownerId)
        {
            RepairDialogsFor(ownerId);
            return Dialogs().Find(x => x.OwnerId == ownerId).SortByDescending(x => x.LastTimestamp).ToList();
        }

        public static int GetUnreadDialogsCount(string ownerId)
        {
           RepairDialogsFor(ownerId);
            return (int)Dialogs().CountDocuments(x => x.OwnerId == ownerId && x.UnreadCount > 0);
        }

        public static void EnsureGroupParticipant(string ownerId, string groupId, string name = null, string avatarId = null)
        {
            if (string.IsNullOrWhiteSpace(ownerId) || string.IsNullOrWhiteSpace(groupId)) return;
             EnsureIndexes();
            var filter = Builders<ServerGroupChatStateDoc>.Filter.Where(x => x.OwnerId == ownerId && x.GroupId == groupId);
            var update = Builders<ServerGroupChatStateDoc>.Update
                .SetOnInsert(x => x.OwnerId, ownerId)
                .SetOnInsert(x => x.GroupId, groupId)
               .SetOnInsert(x => x.Name, string.IsNullOrWhiteSpace(name) ? groupId : name)
                .SetOnInsert(x => x.AvatarId, avatarId ?? string.Empty)
                .SetOnInsert(x => x.LastMessage, string.Empty)
                .SetOnInsert(x => x.LastTimestamp, 0L)
                .SetOnInsert(x => x.UnreadCount, 0);
            GroupDialogs().UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
        }

        public static void AddGroupMessage(string senderId, string groupId, string message, long timestamp)
        {
            if (string.IsNullOrWhiteSpace(senderId) || string.IsNullOrWhiteSpace(groupId)) return;
            EnsureGroupParticipant(senderId, groupId);
             GroupMessages().InsertOne(new ServerGroupChatMessageDoc
             {
                GroupId = groupId,
                SenderId = senderId,
                Message = message ?? string.Empty,
                Timestamp = timestamp,
                ReadBy = new List<string> { senderId },
                DeletedBy = new List<string>()
            });

            List<string> participants = GroupDialogs().Find(x => x.GroupId == groupId)
                .Project(x => x.OwnerId).ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList();
             if (!participants.Contains(senderId)) participants.Add(senderId);
            foreach (string ownerId in participants)
            {
                var filter = Builders<ServerGroupChatStateDoc>.Filter.Where(x => x.OwnerId == ownerId && x.GroupId == groupId);
                var update = Builders<ServerGroupChatStateDoc>.Update
                    .SetOnInsert(x => x.OwnerId, ownerId)
                    .SetOnInsert(x => x.GroupId, groupId)
                    .SetOnInsert(x => x.Name, groupId)
                    .SetOnInsert(x => x.AvatarId, string.Empty)
                    .Set(x => x.LastMessage, message ?? string.Empty)
                    .Set(x => x.LastTimestamp, timestamp);
                if (!string.Equals(ownerId, senderId, StringComparison.Ordinal))
                    update = update.Inc(x => x.UnreadCount, 1);
                GroupDialogs().UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
             }
        }

        public static List<ServerGroupChatStateDoc> GetGroupDialogs(string ownerId)
        {
            EnsureIndexes();
            return GroupDialogs().Find(x => x.OwnerId == ownerId).SortByDescending(x => x.LastTimestamp).ToList();
        }

        public static int GetUnreadGroupDialogsCount(string ownerId)
        {
            EnsureIndexes();
            return (int)GroupDialogs().CountDocuments(x => x.OwnerId == ownerId && x.UnreadCount > 0);
        }

        public static ServerGroupChatMessageDoc[] GetGroupMessages(string ownerId, string groupId, int page, int pageSize)
        {
            EnsureGroupParticipant(ownerId, groupId);
            int safePage = Math.Max(0, page);
            int safeSize = Math.Max(1, Math.Min(pageSize, 100));
            var filter = Builders<ServerGroupChatMessageDoc>.Filter.Eq(x => x.GroupId, groupId) &
                         Builders<ServerGroupChatMessageDoc>.Filter.Not(
                             Builders<ServerGroupChatMessageDoc>.Filter.AnyEq(x => x.DeletedBy, ownerId));
            return GroupMessages().Find(filter)
                .SortByDescending(x => x.Timestamp)
                .Skip(safePage * safeSize)
                .Limit(safeSize)
                 .ToList().ToArray();
        }

        public static void ReadGroupMessages(string ownerId, string groupId)
        {
            if (string.IsNullOrWhiteSpace(ownerId) || string.IsNullOrWhiteSpace(groupId)) return;
            EnsureGroupParticipant(ownerId, groupId);
           GroupMessages().UpdateMany(
                Builders<ServerGroupChatMessageDoc>.Filter.Eq(x => x.GroupId, groupId),
                Builders<ServerGroupChatMessageDoc>.Update.AddToSet(x => x.ReadBy, ownerId));
            GroupDialogs().UpdateOne(
                x => x.OwnerId == ownerId && x.GroupId == groupId,
                Builders<ServerGroupChatStateDoc>.Update.Set(x => x.UnreadCount, 0));
       }

        public static void DeleteGroupMessages(string ownerId, string groupId)
        {
            if (string.IsNullOrWhiteSpace(ownerId) || string.IsNullOrWhiteSpace(groupId)) return;
            GroupMessages().UpdateMany(
                Builders<ServerGroupChatMessageDoc>.Filter.Eq(x => x.GroupId, groupId),
                Builders<ServerGroupChatMessageDoc>.Update.AddToSet(x => x.DeletedBy, ownerId));
            GroupDialogs().DeleteOne(x => x.OwnerId == ownerId && x.GroupId == groupId);
        }

        public static ServerChatMessageDoc[] GetFriendMessagesByOffset(string userId, string friendId, int offset, int length)
        {
            var dialogId = MakeDialogId(userId, friendId);
            var filter = Builders<ServerChatMessageDoc>.Filter.Eq(x => x.DialogId, dialogId) &
                         Builders<ServerChatMessageDoc>.Filter.Not(
                             Builders<ServerChatMessageDoc>.Filter.AnyEq(x => x.DeletedBy, userId));
            return Messages()
                .Find(filter)
                .SortByDescending(x => x.Timestamp)
               .Skip(Math.Max(0, offset))
               .Limit(Math.Max(1, Math.Min(length, 100)))
                .ToList()
                .ToArray();
       }

        public static ServerChatMessageDoc[] GetFriendMessages(string userId, string friendId, int page, int pageSize)
        {
             var dialogId = MakeDialogId(userId, friendId);
            int skip = page * pageSize;

            var filter = Builders<ServerChatMessageDoc>.Filter.Eq(x => x.DialogId, dialogId) &
                          Builders<ServerChatMessageDoc>.Filter.Not(
                             Builders<ServerChatMessageDoc>.Filter.AnyEq(x => x.DeletedBy, userId));
            return Messages()
                .Find(filter)
                .SortByDescending(x => x.Timestamp)
                .Skip(skip)
               .Limit(pageSize)
                .ToList()
                 .ToArray();
        }

        public static void ReadFriendMessages(string userId, string friendId)
        {
            var dialogId = MakeDialogId(userId, friendId);

            Messages().UpdateMany(
                x => x.DialogId == dialogId && x.SenderId == friendId && x.ReceiverId == userId && x.IsRead == false,
                Builders<ServerChatMessageDoc>.Update.Set(x => x.IsRead, true)
            );

            Dialogs().UpdateOne(
                x => x.OwnerId == userId && x.FriendId == friendId,
                Builders<ServerChatDialogStateDoc>.Update.Set(x => x.UnreadCount, 0)
            );
        }

        public static void DeleteFriendMessages(string userId, string friendId)
        {
            var dialogId = MakeDialogId(userId, friendId);

            Messages().UpdateMany(
                x => x.DialogId == dialogId,
                Builders<ServerChatMessageDoc>.Update.AddToSet(x => x.DeletedBy, userId));

            Dialogs().DeleteOne(x => x.OwnerId == userId && x.FriendId == friendId);
        }

    }
}

namespace TspServer.RpcServer.Api
{
   internal static class ProtoOffsetParser
    {
        public static (int page, int size) ParseOffset(BinaryValue offsetBinaryValue)
        {
            try
            {
                byte[] data = GetBytes(offsetBinaryValue);
                if (data == null || data.Length == 0)
                    return (0, 20);

                int idx = 0;
                int offset = 0;
                int length = 20;

                while (idx < data.Length)
                {
                   uint tag = ReadVarint(data, ref idx);
                    int field = (int)(tag >> 3);
                    int wire = (int)(tag & 0x7);

                    if (wire == 0)
                    {
                        ulong v = ReadVarint64(data, ref idx);
                        if (field == 1) offset = (int)v;
                        else if (field == 2) length = (int)v;
                    }
                    else if (wire == 2)
                    {
                        int len = (int)ReadVarint64(data, ref idx);
                        idx += len;
                    }
                    else
                    {
                        break;
                    }
                }

                return (offset, length);
            }
            catch
            {
                return (0, 20);
            }
        }

         private static byte[] GetBytes(BinaryValue bv)
        {
            if (bv == null) return Array.Empty<byte>();

            Type type = bv.GetType();
            PropertyInfo property = type.GetProperty("Bytes") ?? type.GetProperty("Value") ?? type.GetProperty("Data");
           if (property != null)
            {
                object obj = property.GetValue(bv);
                if (obj is byte[] b) return b;
                if (obj is Google.Protobuf.ByteString bs) return bs.ToByteArray();
            }

            FieldInfo field = type.GetField("Bytes") ?? type.GetField("Value") ?? type.GetField("Data");
            if (field != null)
            {
                object obj = field.GetValue(bv);
                if (obj is byte[] b) return b;
                 if (obj is Google.Protobuf.ByteString bs) return bs.ToByteArray();
            }

            return Array.Empty<byte>();
        }

        private static uint ReadVarint(byte[] data, ref int idx)
        {
            return (uint)ReadVarint64(data, ref idx);
        }

        private static ulong ReadVarint64(byte[] data, ref int idx)
        {
            ulong result = 0;
            int shift = 0;
             while (idx < data.Length)
            {
                byte b = data[idx++];
                result |= ((ulong)(b & 0x7F) << shift);
                if ((b & 0x80) == 0)
                    return result;

                shift += 7;
                if (shift > 63)
                    throw new InvalidDataException("Varint is too long.");
            }

            throw new EndOfStreamException("");
        }
   }
}
