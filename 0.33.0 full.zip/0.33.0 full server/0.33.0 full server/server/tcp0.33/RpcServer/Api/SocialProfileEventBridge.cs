using System;
using System.Collections.Generic;
using System.Linq;
using Google.Protobuf;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{

   internal static class SocialProfileEventBridge
    {
        private static readonly object StatusBroadcastLock = new();
        private static readonly Dictionary<string, string> LastStatusFingerprint =
            new Dictionary<string, string>(StringComparer.Ordinal);

        public static void BroadcastStatus(string playerId, TspServer.RpcServer.PlayerStatus status)
        {
            if (string.IsNullOrWhiteSpace(playerId) || status == null)
                return;

            status.gpid = playerId;
           Axlebolt.Bolt.Protobuf2.PlayerStatus proto = status.GetPlayerStatusProto();
            proto.PlayerId = playerId;

            string fingerprint = StatusKey(proto);
            lock (StatusBroadcastLock)
             {
                if (LastStatusFingerprint.TryGetValue(playerId, out string previous) &&
                    string.Equals(previous, fingerprint, StringComparison.Ordinal))
                {
                    return;
               }
                LastStatusFingerprint[playerId] = fingerprint;
             }


            SendFriends(playerId, "onPlayerStatusChangedEvent", playerId, proto);

            byte[] clanPayload = ContractWire.Build(w =>
                w.Message(1, proto.ToByteArray()));
            ClanRemoteService.BroadcastPlayerProfileEvent(
                 playerId,
                "onOnlineStatusChangedEvent",
                clanPayload);
       }

       private static string StatusKey(Axlebolt.Bolt.Protobuf2.PlayerStatus proto)
        {
             byte[] bytes = proto?.ToByteArray() ?? Array.Empty<byte>();
            unchecked
             {
                ulong hash = 1469598103934665603UL;
                foreach (byte value in bytes)
                {
                    hash ^= value;
                    hash *= 1099511628211UL;
                }
                return hash.ToString("X16");
            }
        }

        public static void BroadcastAvatar(string playerId, string avatarId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return;

            avatarId = avatarId ?? string.Empty;
            SendFriends(playerId, "onFriendAvatarChangedEvent", playerId, avatarId);

            byte[] clanPayload = ContractWire.Build(w =>
            {
                w.String(1, playerId);
                w.String(2, avatarId);
            });
            ClanRemoteService.BroadcastPlayerProfileEvent(
                playerId,
                "onPlayerAvatarChangedEvent",
                clanPayload);
        }

        public static void BroadcastName(string playerId, string name)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return;

             name = name ?? string.Empty;
            SendFriends(playerId, "onFriendNameChangedEvent", playerId, name);

            byte[] clanPayload = ContractWire.Build(w =>
            {
                w.String(1, playerId);
                w.String(2, name);
            });
            ClanRemoteService.BroadcastPlayerProfileEvent(
                playerId,
               "onPlayerNameChangedEvent",
                clanPayload);
         }

        public static int ResyncFriendStatusesTo(string viewerId)
        {
            if (string.IsNullOrWhiteSpace(viewerId)) return 0;
            int sent = 0;
            try
            {
                string[] friendIds = BoltGameDatabaseProvider.Instance
                    .GetPlayerFriends(viewerId)
                    .Where(value => value != null && value.relationshipStatus == RelationshipStatusCustom.Friend)
                    .Select(value => string.Equals(value.playerInitiatorId, viewerId, StringComparison.Ordinal)
                        ? value.playerId
                        : value.playerInitiatorId)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                   .Distinct(StringComparer.Ordinal)
                    .ToArray();

                foreach (string friendId in friendIds)
                {
                    TspServer.RpcServer.PlayerStatus status =
                        TspServer.RpcServer.ServerState.GetPlayerStatusSnapshot(friendId) ??
                        new TspServer.RpcServer.PlayerStatus
                        {
                            onlineStatus = TspServer.RpcServer.PlayerStatus.OnlineStatus.StateOffline,
                            playInGame = null
                        };
                    Axlebolt.Bolt.Protobuf2.PlayerStatus proto = status.GetPlayerStatusProto();
                    proto.PlayerId = friendId;
                    sent += SocialEventDelivery.Send<FriendsRemoteEventSender>(
                        viewerId, "friends-resync", "onPlayerStatusChangedEvent", new object[] { friendId, proto });
                }
            }
            catch (System.Exception)
            {
            }
             return sent;
        }
        private static void SendFriends(string playerId, string eventName, params object[] payload)
        {
            try
            {
                string[] friendIds = BoltGameDatabaseProvider.Instance
                    .GetPlayerFriends(playerId)
                    .Where(value => value != null && value.relationshipStatus == RelationshipStatusCustom.Friend)
                    .Select(value => string.Equals(value.playerInitiatorId, playerId, StringComparison.Ordinal)
                        ? value.playerId
                        : value.playerInitiatorId)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();

                foreach (string friendId in friendIds)
                {
                    SocialEventDelivery.Send<FriendsRemoteEventSender>(
                        friendId,
                        "friends",
                        eventName,
                        payload ?? Array.Empty<object>());
                }
            }
            catch (System.Exception)
            {
            }
         }
    }
}
