using System;
using Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer.Api
{
    public sealed class BoltRemoteService : RpcHandler
    {
        public BoltRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request)
        {
            if (request == null) return;

            string method = (request.MethodName ?? "").Trim();
            string m = method.ToLowerInvariant();


             try
            {
                switch (m)
                {
                    case "subscribe2":
                        SubscribeV2(request);
                        return;
                    case "unsubscribe2":
                        UnsubscribeV2(request);
                       return;
                    case "subscribe":
                        Subscribe(request.Params?.ToArray(), request.Id);
                        return;
                    case "unsubscribe":
                        Unsubscribe(request.Params?.ToArray(), request.Id);
                        return;
                    case "systemtime":
                        SystemTime(request.Id);
                        return;
                     default:
                        SendException(request.Id, 404);
                        return;
               }
            }
            catch (System.Exception)
            {
                SendException(request.Id, 500);
            }
        }

        private void SubscribeV2(RpcRequest request)
        {
            string topic = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            BoltEvents.Subscribe(topic, _session);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void UnsubscribeV2(RpcRequest request)
        {
            string topic = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            BoltEvents.Unsubscribe(topic, _session);
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void Subscribe(BinaryValue[] args, string guid)
        {
            string topic = ReadString(args, 0) ?? "";
            BoltEvents.Subscribe(topic, _session);
            SendVoid(guid);
         }

       private void Unsubscribe(BinaryValue[] args, string guid)
       {
            string topic = ReadString(args, 0) ?? "";
            BoltEvents.Unsubscribe(topic, _session);
            SendVoid(guid);
        }

        private void SystemTime(string guid)
        {
            long unixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            SendReturn(guid, unixMs, typeof(long));
        }
        private static string ReadString(BinaryValue[] args, int index)
         {
            if (args == null || index < 0 || index >= args.Length) return null;
            if (args[index] == null || args[index].IsNull) return null;
            try { return (string)new RpcValueReader(typeof(string)).FromBytes(args[index]); }
            catch { return null; }
        }

        private void SendVoid(string guid)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendReturn(string guid, object obj, System.Type type)
        {
           _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                   Return = new RpcValueWriter(type).ToBytes(obj)
                }
            });
        }
        private void SendException(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
               {
                    Id = guid,
                   Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
