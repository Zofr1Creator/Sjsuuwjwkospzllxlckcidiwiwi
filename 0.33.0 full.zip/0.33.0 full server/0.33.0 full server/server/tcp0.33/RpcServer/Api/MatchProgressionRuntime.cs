using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{
    internal static class MatchProgressionRuntime
    {
        private const string MarkerCollection = "match_progression";

        internal static int ComputeSmartMatchXp(
            int kills,
            int deaths,
            int assists,
            int headshots,
            int score,
            bool won)
        {
            kills = Math.Clamp(kills, 0, 500);
            deaths = Math.Clamp(deaths, 0, 500);
            assists = Math.Clamp(assists, 0, 500);
            headshots = Math.Clamp(headshots, 0, kills);
            score = Math.Clamp(score, 0, 100000);

            int xp = 120;
            xp += kills * 14;
            xp += assists * 8;
            xp += headshots * 4;
            xp += Math.Min(300, score / 10);
            xp += Math.Min(120, Math.Max(0, kills - deaths) * 3);

            if (won)
                xp += 180;

            return Math.Clamp(xp, 0, 2500);
        }

        public static void Apply(BsonDocument match)
        {
            if (match == null || !ReadBool(match, "finalized"))
                return;

            string status = ReadString(match, "status");
            if (!string.Equals(status, "Finished", StringComparison.OrdinalIgnoreCase))
                return;

            string matchId = FindString(match, "matchId", "_id");
            if (string.IsNullOrWhiteSpace(matchId))
                return;

            if (!match.TryGetValue("players", out BsonValue players) || !players.IsBsonArray)
                return;

            Dictionary<string, BsonDocument> results = ReadResults(match);

            foreach (BsonValue value in players.AsBsonArray)
            {
                if (!value.IsBsonDocument)
                    continue;

                BsonDocument player = value.AsBsonDocument;
                string playerId = FindString(player, "playerId", "id", "profileId", "accountId");
                if (string.IsNullOrWhiteSpace(playerId))
                    continue;

                results.TryGetValue(playerId, out BsonDocument result);
                ApplyResult(matchId, playerId, player, result);
            }
        }

        private static void ApplyResult(
            string matchId,
            string playerId,
            BsonDocument player,
            BsonDocument result)
        {
            IMongoDatabase db = BoltGameDatabaseProvider.Instance.GetDatabase();
            IMongoCollection<BsonDocument> markers =
                db.GetCollection<BsonDocument>(MarkerCollection);

            string markerId = matchId + ":" + playerId;

            try
            {
                markers.InsertOne(new BsonDocument
                {
                    ["_id"] = markerId,
                    ["matchId"] = matchId,
                    ["playerId"] = playerId,
                    ["appliedAt"] = DateTime.UtcNow
                });
            }
            catch (MongoWriteException ex) when (
                ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
                return;
            }

            try
            {
                BsonDocument data = result ?? new BsonDocument();

                int kills = FindInt(
                    data,
                    FindInt(player, 0, "kills", "killCount"),
                    "kills",
                    "killCount");

                int deaths = FindInt(
                    data,
                    FindInt(player, 0, "deaths", "deathCount"),
                    "deaths",
                    "deathCount");

                int assists = FindInt(
                    data,
                    FindInt(player, 0, "assists", "assistCount"),
                    "assists",
                    "assistCount");

                int score = FindInt(
                    data,
                    FindInt(player, 0, "score", "points"),
                    "score",
                    "points");

                int headshots = FindInt(
                    data,
                    FindInt(player, 0, "headshots", "headshotCount"),
                    "headshots",
                    "headshotCount");

                bool won = FindFlag(data, "won", "isWinner", "winner");

                int xp = FindInt(
                    data,
                    int.MinValue,
                    "xp",
                    "xpReward",
                    "rewardXp",
                    "earnedXp");

                if (xp == int.MinValue)
                    xp = ComputeSmartMatchXp(kills, deaths, assists, headshots, score, won);

                IMongoCollection<BsonDocument> stats =
                    db.GetCollection<BsonDocument>("stats");

                FilterDefinition<BsonDocument> filter =
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId);

                UpdateDefinition<BsonDocument> update = Builders<BsonDocument>.Update
                    .SetOnInsert("playerId", playerId)
                    .Inc("stats.games_played", 1)
                    .Inc("stats.kills", kills)
                    .Inc("stats.deaths", deaths)
                    .Inc("stats.assists", assists)
                    .Inc("stats.score", score)
                    .Inc("stats.xp_reworked", xp)
                    .Inc(won ? "stats.wins" : "stats.losses", 1);

                stats.UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });

                PlayerLevelRuntime.NormalizePersistedStats(playerId);

                markers.UpdateOne(
                    Builders<BsonDocument>.Filter.Eq("_id", markerId),
                    Builders<BsonDocument>.Update
                        .Set("xp", xp)
                        .Set("kills", kills)
                        .Set("deaths", deaths)
                        .Set("assists", assists)
                        .Set("score", score)
                        .Set("won", won));
            }
            catch
            {
                markers.DeleteOne(
                    Builders<BsonDocument>.Filter.Eq("_id", markerId));
                throw;
            }
        }

        private static Dictionary<string, BsonDocument> ReadResults(BsonDocument match)
        {
            var result = new Dictionary<string, BsonDocument>(StringComparer.Ordinal);

            if (!match.TryGetValue("playerResults", out BsonValue value) || !value.IsBsonArray)
                return result;

            foreach (BsonValue item in value.AsBsonArray)
            {
                if (!item.IsBsonDocument)
                    continue;

                BsonDocument entry = item.AsBsonDocument;
                string playerId = FindString(entry, "playerId", "id", "profileId", "accountId");
                if (string.IsNullOrWhiteSpace(playerId))
                    continue;

                if (entry.TryGetValue("result", out BsonValue nested) && nested.IsBsonDocument)
                    result[playerId] = nested.AsBsonDocument;
                else
                    result[playerId] = entry;
            }

            return result;
        }

        private static string ReadString(
            BsonDocument document,
            string key,
            string fallback = "")
        {
            if (document == null ||
                !document.TryGetValue(key, out BsonValue value) ||
                value.IsBsonNull)
            {
                return fallback;
            }

            try
            {
                return value.ToString();
            }
            catch
            {
                return fallback;
            }
        }

        private static string FindString(BsonDocument document, params string[] keys)
        {
            foreach (string key in keys)
            {
                string value = ReadString(document, key);
                if (!string.IsNullOrWhiteSpace(value))
                    return value;
            }

            return string.Empty;
        }

        private static int ReadInt(
            BsonDocument document,
            string key,
            int fallback = 0)
        {
            if (document == null ||
                !document.TryGetValue(key, out BsonValue value) ||
                value.IsBsonNull)
            {
                return fallback;
            }

            try
            {
                return value.ToInt32();
            }
            catch
            {
                return fallback;
            }
        }

        private static int FindInt(
            BsonDocument document,
            int fallback,
            params string[] keys)
        {
            foreach (string key in keys)
            {
                int value = ReadInt(document, key, int.MinValue);
                if (value != int.MinValue)
                    return value;
            }

            return fallback;
        }

        private static bool ReadBool(BsonDocument document, string key)
        {
            if (document == null ||
                !document.TryGetValue(key, out BsonValue value) ||
                value.IsBsonNull)
            {
                return false;
            }

            try
            {
                return value.ToBoolean();
            }
            catch
            {
                return false;
            }
        }

        private static bool FindFlag(BsonDocument document, params string[] keys)
        {
            foreach (string key in keys)
            {
                if (ReadBool(document, key))
                    return true;
            }

            return false;
        }
    }
}
