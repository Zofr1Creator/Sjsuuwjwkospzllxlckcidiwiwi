using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{
    public sealed class GameEventRemoteService : RpcHandler
    {
        public GameEventRemoteService(ClientSession user) : base(user)
        {
        }

        public override void Invoke(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                SendError(request.Id, 401, "player authenticated?");

                return;
            }

            try
            {
                switch (request.MethodName)
                {
                    case "getCurrentGameEvents":
                     case "getPlayerCurrentGameEvents":
                        GetCurrentGameEvents(playerId, request.Id);
                        return;
                    case "getCurrentGameEventsByServer":
                       GetCurrentGameEventsByServer(playerId, request, request.Id);
                        return;
                    case "getPlayerGameEventsProgresses":
                        GetPlayerGameEventsProgresses(playerId, request.Id);
                        return;
                    case "getCachedPlayerGameEvents":
                        GetCachedPlayerGameEvents(playerId, request.Id);
                        return;
                    case "getPlayerGameEventProgress":
                         GetPlayerGameEventProgress(playerId, request, request.Id);
                        return;
                    case "claimAllRewardsOfSpecificPasses":
                     case "claimAllRewards":
                        ClaimAllRewards(playerId, request, request.Id);
                        return;
                    case "claimSpecificLevelReward":
                    case "claimLevelReward":
                        ClaimSpecificLevelReward(playerId, request, request.Id);
                        return;
                    case "getCurrentChallenges":
                        GetCurrentChallenges(playerId, Parse<GetCurrentChallengesRequest>(request, 0), request.Id);
                        return;
                    case "getAllChallenges":
                        GetAllChallenges(playerId, ReadString(request, 0), request.Id);
                        return;
                    case "progressChallenge":
                    case "setChallengeProgress":
                        ProgressChallenge(playerId, request, request.Id);
                        return;
                    case "progressGameEvent":
                        ProgressGameEvent(playerId, Parse<ProgressGameEventRequest>(request, 0), request.Id);
                        return;
                    case "saveChallenge2":
                        SaveChallenge2(playerId, request, request.Id);
                        return;
                    default:
                         SendError(request.Id, 404, "Unknown game-event RPC: " + request.MethodName);
                        return;
                }
            }
            catch (ArgumentException ex)
            {
                SendError(request.Id, 400, ex.Message);
            }
            catch (System.Exception ex)
            {
                SendError(request.Id, 500, ex.Message);
            }
        }

        private void GetCurrentGameEvents(string playerId, string guid)
        {
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
               BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                BattlePassRuntime.SaveState(state);
                BattlePassDefinition levelDefinition = PlayerLevelRuntime.GetDefinition();
                BattlePassPlayerStateDocument levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);
                PlayerLevelRuntime.SettleUnlockedRewardsForGameEventPath(playerId, "getCurrentGameEvents");
                levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);

                byte[] levelEvent = BuildPlayerLevelEvent(levelDefinition, levelState);
                byte[] response = ContractWire.Build(w =>
                {
                    foreach (string alias in BattlePassRuntime.GetPreyWireAliases())
                    {
                        BattlePassDefinition wire = BattlePassRuntime.BuildWireDefinition(definition, alias);
                        w.Message(1, BuildBattlePassEvent(playerId, wire, definition, state));
                    }
                    w.Message(1, levelEvent);
                 });
                SendOkRaw(guid, response);

             }
        }

        private void GetCurrentGameEventsByServer(string playerId, RpcRequest request, string guid)
       {

           lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                BattlePassRuntime.SaveState(state);
                BattlePassDefinition wire = BattlePassRuntime.BuildWireDefinition(definition, BattlePassRuntime.CanonicalPreyEventId);
                BattlePassDefinition levelDefinition = PlayerLevelRuntime.GetDefinition();
                 BattlePassPlayerStateDocument levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);
                byte[] response = ContractWire.Build(w =>
                {
                    w.Message(1, BuildBattlePassEvent(playerId, wire, definition, state));

                     w.Message(1, BuildPlayerLevelEvent(levelDefinition, levelState));
                });
                SendOkRaw(guid, response);

            }
        }

        private void GetPlayerGameEventsProgresses(string playerId, string guid)
        {
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                BattlePassRuntime.SaveState(state);
                BattlePassDefinition levelDefinition = PlayerLevelRuntime.GetDefinition();
                BattlePassPlayerStateDocument levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);
                PlayerLevelRuntime.SettleUnlockedRewardsForGameEventPath(playerId, "getPlayerGameEventsProgresses");
                levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);
                byte[] levelProgress = BuildEventProgress(levelDefinition, levelState);

                byte[] response = ContractWire.Build(w =>
                {
                    foreach (string alias in BattlePassRuntime.GetPreyWireAliases())
                    {
                       BattlePassDefinition wire = BattlePassRuntime.BuildWireDefinition(definition, alias);
                        w.Message(1, BuildPassProgress(wire, definition, state, playerId));
                    }
                    w.Message(1, levelProgress);
                });
                RpcResponseWriter.SendPayload(_session, guid, response);
}
        }

        private void GetCachedPlayerGameEvents(string playerId, string guid)
        {
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                long nowSeconds = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                long untilRefreshMs = Math.Max(60000L, Math.Min(3600000L, Math.Max(0L, definition.DateUntil - nowSeconds) * 1000L));
                byte[] playerLevelDefinition = BuildPlayerLevelDefinition(PlayerLevelRuntime.GetDefinition());
                byte[] response = ContractWire.Build(w =>
                 {
                    foreach (string alias in BattlePassRuntime.GetPreyWireAliases())
                    {
                       BattlePassDefinition wire = BattlePassRuntime.BuildWireDefinition(definition, alias);
                        w.Message(1, BuildPassDefinition(wire, definition));
                    }
                    w.Message(1, playerLevelDefinition);
                    w.String(2, "prey:" + definition.CurrentDay + ":pass19-level-primary-rewards-v6");
                    w.Varint(3, untilRefreshMs);
                });
                RpcResponseWriter.SendPayload(_session, guid, response);
}
        }

        private static long ToClientTime(long unixValue)
        {
            if (unixValue <= 0) return unixValue;
            if (unixValue >= 100000000000L) return unixValue;
            checked { return unixValue * 1000L; }
        }

        private static long ToUnixSeconds(long unixValue)
        {
            if (unixValue <= 0) return unixValue;
            return unixValue >= 100000000000L ? unixValue / 1000L : unixValue;
        }

        private static byte[] BuildBattlePassEvent(string playerId, BattlePassDefinition wire, BattlePassDefinition canonical, BattlePassPlayerStateDocument state)
        {
            BattlePassRuntime.UpdateLevelsOnly(state, canonical);
            return ContractWire.Build(w =>
            {
                w.String(1, wire.Id);
                w.String(2, wire.Code);
                w.Varint(3, ToClientTime(canonical.DateSince));
                w.Varint(4, ToClientTime(canonical.DateUntil));
                w.Int32(5, canonical.DurationDays);
                foreach (var pass in canonical.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                {
                   int currentLevel = BattlePassRuntime.GetCurrentPassLevel(state, canonical, pass.Key);
                    byte[] passWire = ContractWire.Build(p =>
                    {
                        p.String(1, wire.Id + ":" + pass.Key);
                        p.String(2, pass.Key);
                        p.Int32(3, pass.Key == "GoldPass" ? canonical.GoldPassItemDefinitionId : 0);
                       foreach (GamePassLevel level in pass.Value)
                            p.Message(4, BuildPassLevel(level, true));
                        p.Int32(5, currentLevel);
                         foreach (int claimable in Claimable(canonical, state, pass.Key))
                            p.Int32(6, claimable);
                    });
                    w.Message(6, passWire);
                }
                w.Int32(7, Math.Max(0, state.Points));
                w.Int32(8, canonical.CurrentDay);
                w.Message(10, ContractWire.Build(title => { title.String(1, "Prey"); title.String(2, "Season 9: Prey"); }));
                w.String(11, "battle_pass");
                w.Bool(12, false);
            });
        }

        private static byte[] BuildPassProgress(BattlePassDefinition wire, BattlePassDefinition canonical, BattlePassPlayerStateDocument state, string playerId)
        {
            return ContractWire.Build(w =>
            {
                w.String(1, wire.Id);
                w.Int32(2, Math.Max(0, state.Points));
                foreach (var pass in canonical.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                 {
                    int currentLevel = BattlePassRuntime.GetCurrentPassLevel(state, canonical, pass.Key);
                    byte[] passProgress = ContractWire.Build(p =>
                     {
                       p.String(1, wire.Id + ":" + pass.Key);
                        p.Int32(2, Math.Max(1, currentLevel));
                        foreach (GamePassLevel level in pass.Value)
                        {
                            string claimKey = pass.Key + ":" + level.Level;
                            if (level.Level > 0 && level.Level <= currentLevel && !state.ClaimedRewards.Contains(claimKey))
                                 p.Int32(3, level.Level);
                        }
                     });
                    w.Message(3, passProgress);
                }
                foreach (BattlePassChallengeDocument challenge in BattlePassRuntime.GetChallengeDefinitions(canonical))
                {
                    int points = state.ChallengePoints.TryGetValue(challenge.Id, out int value) ? value : 0;
                    bool completed = state.CompletedChallenges.Contains(challenge.Id);
                    foreach (string progressWireId in BattlePassRuntime.GetChallengeProgressWireIds(canonical, challenge))
                    {
                        byte[] challengeProgress = ContractWire.Build(c =>
                        {
                             c.String(1, progressWireId);
                            c.Int32(2, points);
                            c.Bool(3, completed);
                            c.Bool(4, completed);
                            c.String(5, playerId + ":" + challenge.Id);
                        });
                        w.Message(4, challengeProgress);
                     }
               }
                w.Int32(5, canonical.CurrentDay);
            });
        }

        private static byte[] BuildPassDefinition(BattlePassDefinition wire, BattlePassDefinition canonical)
        {
            return ContractWire.Build(w =>
             {
                w.String(1, wire.Id);
                w.String(2, wire.Code);
                w.Varint(3, ToClientTime(canonical.DateSince));
                w.Varint(4, ToClientTime(canonical.DateUntil));
                w.Int32(5, canonical.DurationDays);
                foreach (var pass in canonical.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                {
                    byte[] passDefinition = ContractWire.Build(p =>
                    {
                        p.String(1, wire.Id + ":" + pass.Key);
                        p.String(2, pass.Key);
                        p.Int32(3, pass.Key == "GoldPass" ? canonical.GoldPassItemDefinitionId : 0);
                        foreach (GamePassLevel level in pass.Value) p.Message(4, BuildPassLevel(level, true));
                    });
                    w.Message(6, passDefinition);
                }
                foreach (BattlePassChallengeDocument challenge in BattlePassRuntime.GetChallengeDefinitions(canonical))
                {
                    byte[] challengeDefinition = ContractWire.Build(c =>
                    {
                        c.String(1, challenge.Id);
                        c.String(2, wire.Id);
                        c.String(3, challenge.Code);
                        c.Int32(4, challenge.KeyItemDefinitionId);
                        c.Message(5, ContractWire.Build(title => {
                            title.String(1, string.IsNullOrWhiteSpace(challenge.DisplayName) ? challenge.Code : challenge.DisplayName);
                           title.String(2, string.IsNullOrWhiteSpace(challenge.Description) ? BattlePassRuntime.MissionDescription(challenge.Code, challenge.TargetPoints) : challenge.Description);
                        }));
                        c.String(6, challenge.Action);
                        c.Message(7, ContractWire.Build(range => { range.Int32(1, challenge.FromDay); range.Int32(2, challenge.ToDay); }));
                        c.String(8, challenge.Type);
                        c.Int32(9, challenge.EventPoints);
                        c.Int32(10, challenge.TargetPoints);
                        c.Message(11, BattlePassRuntime.ToRewardInfo(challenge).ToByteArray());
                    });
                    w.Message(7, challengeDefinition);
                }
                w.Message(9, ContractWire.Build(title => { title.String(1, "Prey"); title.String(2, "Season 9: Prey"); }));
               w.String(10, "battle_pass");
                w.Bool(11, false);
           });
        }

        private static byte[] BuildEventProgress(BattlePassDefinition definition, BattlePassPlayerStateDocument state)
         {
            return ContractWire.Build(w =>
            {
                w.String(1, definition.Id);
               bool prey = BattlePassRuntime.MatchesEventIdOrCode(definition.Id) && definition.Id != PlayerLevelRuntime.EventId;
                w.Int32(2, Math.Max(0, state.Points));
                foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                {
                    int currentLevel = prey ? BattlePassRuntime.GetCurrentPassLevel(state, definition, pass.Key) : (state.Levels.TryGetValue(pass.Key, out int value) ? value : 1);
                    byte[] passProgress = ContractWire.Build(p =>
                    {
                       p.String(1, definition.Id + ":" + pass.Key);
                        p.Int32(2, Math.Max(1, currentLevel));
                        foreach (int claimable in Claimable(definition, state, pass.Key))
                            p.Int32(3, claimable);
                    });
                    w.Message(3, passProgress);
                }
                if (BattlePassRuntime.MatchesEventIdOrCode(definition.Id))
                {
                     foreach (BattlePassChallengeDocument challenge in BattlePassRuntime.GetChallengeDefinitions(definition))
                    {
                        int challengePoints = state.ChallengePoints.TryGetValue(challenge.Id, out int storedPoints)
                            ? Math.Max(0, storedPoints)
                            : 0;
                        bool completed = state.CompletedChallenges != null && state.CompletedChallenges.Contains(challenge.Id);
                        foreach (string progressWireId in BattlePassRuntime.GetChallengeProgressWireIds(definition, challenge))
                        {
                            byte[] challengeProgress = ContractWire.Build(c =>
                           {
                                 c.String(1, progressWireId);
                                c.Int32(2, challengePoints);
                               c.Bool(3, completed);
                                c.Bool(4, completed);
                                c.String(5, state.PlayerId + ":" + challenge.Id);
                            });
                            w.Message(4, challengeProgress);
                        }
                    }
                }
                w.Int32(5, definition.CurrentDay);
            });
        }

         private void GetPlayerGameEventProgress(string playerId, RpcRequest request, string guid)
        {
            string requestedId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                if (string.Equals(requestedId, PlayerLevelRuntime.EventId, StringComparison.OrdinalIgnoreCase))
                {
                    BattlePassDefinition levelDefinition = PlayerLevelRuntime.GetDefinition();
                    BattlePassPlayerStateDocument levelState = PlayerLevelRuntime.GetState(playerId, levelDefinition);
                    SendOkRaw(guid, ContractWire.Build(w => w.Message(1, BuildEventProgress(levelDefinition, levelState))));
                    return;
                }
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                if (!BattlePassRuntime.MatchesEventIdOrCode(requestedId))
                {
                    SendOkRaw(guid, Array.Empty<byte>());
                    return;
               }
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                BattlePassRuntime.SaveState(state);
                BattlePassDefinition wire = BattlePassRuntime.BuildWireDefinition(definition,
                    string.IsNullOrWhiteSpace(requestedId) ? BattlePassRuntime.CanonicalPreyCode : requestedId);
               SendOkRaw(guid, ContractWire.Build(w => w.Message(1, BuildEventProgress(wire, state))));
            }
        }

        private void ClaimAllRewards(string playerId, RpcRequest request, string guid)
        {
            string requestedEventId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                bool xpLevel = string.Equals(requestedEventId, PlayerLevelRuntime.EventId, StringComparison.OrdinalIgnoreCase);
                BattlePassDefinition definition = xpLevel ? PlayerLevelRuntime.GetDefinition() : BattlePassRuntime.GetDefinition();
                if (!xpLevel && !BattlePassRuntime.MatchesEventIdOrCode(requestedEventId))
                    throw new ArgumentException("Unknown gameEventId " + requestedEventId);
                if (xpLevel && !string.IsNullOrWhiteSpace(requestedEventId) && !string.Equals(requestedEventId, definition.Id, StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Unknown gameEventId " + requestedEventId);
                BattlePassPlayerStateDocument state = xpLevel ? PlayerLevelRuntime.GetState(playerId, definition) : BattlePassRuntime.GetState(playerId, definition);
                HashSet<string> requestedPasses = ReadStrings(ContractWire.Param(request), 2);
                if (requestedPasses.Count > 0)
                {
                    var normalized = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach(string pass in requestedPasses) normalized.Add(xpLevel ? PlayerLevelRuntime.NormalizePassCode(definition, pass) : BattlePassRuntime.NormalizeBattlePassCode(definition, pass));
                    requestedPasses = normalized;
                 }
                Reward reward = ClaimPassRewards(playerId, definition, state, requestedPasses, xpLevel);
               if (xpLevel) PlayerLevelRuntime.SaveState(state); else BattlePassRuntime.SaveState(state);
                SendOkRaw(guid, ContractWire.Build(w => w.Message(1, reward.ToByteArray())));
                if (reward.Items.Count > 0 || reward.Currencies.Count > 0)
                    InventoryEventBus.InventoryChanged(playerId, added: reward.Items, currencies: reward.Currencies,
                        source: xpLevel ? "xp-level-claim-all" : "prey-bp-claim-all");
                if (xpLevel) SendPlayerLevelChanged(playerId); else SendPassState(playerId, definition, state, new Reward());
            }
        }

        private void ClaimSpecificLevelReward(string playerId, RpcRequest request, string guid)
        {
            byte[] raw = ContractWire.Param(request);
            string eventId = ContractWire.ReadStringField(raw, 1, string.Empty);
            string passId = ContractWire.ReadStringField(raw, 2, string.Empty);
            int requestedLevel = ContractWire.ReadIntField(raw, 3, 0);
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                bool xpLevel = string.Equals(eventId, PlayerLevelRuntime.EventId, StringComparison.OrdinalIgnoreCase);
                BattlePassDefinition definition = xpLevel ? PlayerLevelRuntime.GetDefinition() : BattlePassRuntime.GetDefinition();
                if (!xpLevel && !BattlePassRuntime.MatchesEventIdOrCode(eventId))
                    throw new ArgumentException("Unknown gameEventId " + eventId);
                if (xpLevel && !string.IsNullOrWhiteSpace(eventId) && !string.Equals(eventId, definition.Id, StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Unknown gameEventId " + eventId);
               string passCode = xpLevel ? PlayerLevelRuntime.NormalizePassCode(definition, passId) : BattlePassRuntime.NormalizeBattlePassCode(definition, passId);
                if (!definition.Passes.TryGetValue(passCode, out List<GamePassLevel> levels))
                    throw new ArgumentException("Unknown passId " + passId);
                if (!xpLevel && passCode.Equals("GoldPass", StringComparison.OrdinalIgnoreCase) &&
                    !BattlePassRuntime.OwnsInventoryDefinition(playerId, definition.GoldPassItemDefinitionId))
                    throw new ArgumentException("GoldPass is not owned");
                BattlePassPlayerStateDocument state = xpLevel ? PlayerLevelRuntime.GetState(playerId, definition) : BattlePassRuntime.GetState(playerId, definition);
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                int currentLevel = state.Levels.TryGetValue(passCode, out int value) ? value : 1;
                int minimumClaimLevel = xpLevel ? 2 : 1;
                if (requestedLevel < minimumClaimLevel || requestedLevel > currentLevel)
                    throw new ArgumentException("Level is not unlocked");
                GamePassLevel level = levels.FirstOrDefault(x => x.Level == requestedLevel);
                if (level == null) throw new ArgumentException("Unknown level " + requestedLevel);
                string claimKey = passCode + ":" + requestedLevel;
                Reward reward = new Reward();
                if (!state.ClaimedRewards.Contains(claimKey))
                {
                    reward = BattlePassRuntime.GrantRewardInfo(playerId, level.Reward ?? new RewardInfo());
                    state.ClaimedRewards.Add(claimKey);
                }
                if (xpLevel) PlayerLevelRuntime.SaveState(state); else BattlePassRuntime.SaveState(state);
                SendOkRaw(guid, ContractWire.Build(w => w.Message(1, reward.ToByteArray())));
                if (reward.Items.Count > 0 || reward.Currencies.Count > 0)
                    InventoryEventBus.InventoryChanged(playerId, added: reward.Items, currencies: reward.Currencies,
                        source: xpLevel ? "xp-level-claim-one" : "prey-bp-claim-one");
                 if (xpLevel) SendPlayerLevelChanged(playerId); else SendPassState(playerId, definition, state, new Reward());
            }
         }

        private static string ChallengeProgressId(BattlePassPlayerStateDocument state, BattlePassChallengeDocument challenge)
        {
            return (state?.PlayerId ?? string.Empty) + ":" + (challenge?.Id ?? string.Empty);
        }
       private static byte[] BuildChallenge(BattlePassChallengeDocument challenge, BattlePassPlayerStateDocument state)
        {
            int current = state.ChallengePoints.TryGetValue(challenge.Id, out int value) ? value : 0;
            bool completed = state.CompletedChallenges.Contains(challenge.Id);
            return ContractWire.Build(c =>
            {
               c.String(1, challenge.Id);
                c.String(2, challenge.Code ?? string.Empty);
                c.Int32(3, challenge.KeyItemDefinitionId);
                c.Message(4, ContractWire.Build(title =>
                {
                    title.String(1, string.IsNullOrWhiteSpace(challenge.DisplayName) ? (challenge.Code ?? string.Empty) : challenge.DisplayName);
                    title.String(2, string.IsNullOrWhiteSpace(challenge.Description) ? BattlePassRuntime.MissionDescription(challenge.Code, challenge.TargetPoints) : challenge.Description);
                }));
                c.String(5, challenge.Action ?? string.Empty);
                c.Message(6, ContractWire.Build(range => { range.Int32(1, challenge.FromDay); range.Int32(2, challenge.ToDay); }));
                c.String(7, challenge.Type ?? string.Empty);
                c.Int32(8, challenge.EventPoints);
                c.Int32(9, challenge.TargetPoints);
                c.Int32(10, current);
                c.Message(11, BattlePassRuntime.ToRewardInfo(challenge).ToByteArray());
                c.Bool(12, completed);
                c.String(13, challenge.EventId ?? string.Empty);
                c.Bool(14, completed);
                c.String(15, ChallengeProgressId(state, challenge));
            });
        }

        private void GetCurrentChallenges(string playerId, GetCurrentChallengesRequest request, string guid)
        {
            if (request == null) throw new ArgumentException("GetCurrentChallengesRequest is required");
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                 string eventId = string.IsNullOrWhiteSpace(request.GameEventId) ? definition.Id : request.GameEventId;
                var selected = new List<BattlePassChallengeDocument>();
                if (BattlePassRuntime.MatchesEventIdOrCode(eventId))
                {
                    foreach (BattlePassChallengeDocument challenge in BattlePassRuntime.GetChallengeDefinitions(definition))
                    {
                       bool completed = state.CompletedChallenges.Contains(challenge.Id);
                        bool active = challenge.FromDay <= definition.CurrentDay && challenge.ToDay >= definition.CurrentDay;
                        if (active && completed == request.Completed) selected.Add(challenge);
                    }
                }
                byte[] response = ContractWire.Build(w =>
                {
                    foreach (BattlePassChallengeDocument challenge in selected)
                        w.Message(1, BuildChallenge(challenge, state));
                });
                SendOkRaw(guid, response);
            }
        }

        private void GetAllChallenges(string playerId, string requestedEventId, string guid)
        {
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                string eventId = string.IsNullOrWhiteSpace(requestedEventId) ? definition.Id : requestedEventId;
                IReadOnlyList<BattlePassChallengeDocument> selected = BattlePassRuntime.MatchesEventIdOrCode(eventId)
                    ? BattlePassRuntime.GetChallengeDefinitions(definition)
                    : Array.Empty<BattlePassChallengeDocument>();
                byte[] response = ContractWire.Build(w =>
                {
                    foreach (BattlePassChallengeDocument challenge in selected)
                         w.Message(1, BuildChallenge(challenge, state));
                });
                SendOkRaw(guid, response);
             }
        }

        private void ProgressGameEvent(string playerId, ProgressGameEventRequest request, string guid)
        {
            if (request == null) throw new ArgumentException("ProgressGameEventRequest is required");
            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                if (!BattlePassRuntime.MatchesEventIdOrCode(request.GameEventId))
                    throw new ArgumentException("Unknown gameEventId " + request.GameEventId);

                int requested = request.Points;
                if (requested <= 0 || requested > 20000 || requested % 1000 != 0)
                 {
                    ContractWire.SendException(_session, guid, 403);
                    return;
                }
                int levels = requested / 1000;
                int goldPerLevel = 80;
                string goldSetting = Environment.GetEnvironmentVariable("bp_gold_per_level");
                if (string.IsNullOrWhiteSpace(goldSetting))
                    goldSetting = Environment.GetEnvironmentVariable("BOLT_BP_GOLD_PER_LEVEL");
                if (int.TryParse(goldSetting, out int configured))
                    goldPerLevel = Math.Clamp(configured, 1, 100000);
                double cost = checked(levels * goldPerLevel);
                ObjectId oid = ObjectId.Parse(playerId);
                 if (!BoltGameDatabaseProvider.Instance.TrySpendCurrencyAtomic(oid, 102, cost, out double beforeGold, out double afterGold))
                {
                    ContractWire.SendException(_session, guid, 402);
                    return;
               }

                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);

                try
                {
                   BattlePassRuntime.AddEventPoints(state, requested);
                    BattlePassRuntime.UpdateLevelsOnly(state, definition);
                    BattlePassRuntime.SaveState(state);
                }
                catch
                {
                    BoltGameDatabaseProvider.Instance.RefundCurrencyAtomic(oid, 102, cost);
                    throw;
                 }

                var response = new ProgressGameEventResponse { Points = state.Points, Reward = new Reward() };
                foreach (var level in state.Levels) response.Levels[level.Key] = level.Value;
                SendOk(guid, response);
               InventoryEventBus.InventoryChanged(playerId, currencies: new[]{new CurrencyAmount{CurrencyId=102,OldValue=(int)Math.Round(beforeGold),Value=(float)(-cost)}}, source:"bp-level-purchase");
                SendPassState(playerId, definition, state, new Reward());
            }
        }

         private void ProgressChallenge(string playerId, RpcRequest rpc, string guid)
        {

            byte[] raw = ContractWire.Param(rpc);
            string challengeId = ContractWire.ReadStringField(raw, 1, string.Empty);
            int reportedPoints = ContractWire.ReadIntField(raw, 2, 0);

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassChallengeDocument challenge = BattlePassRuntime.FindChallenge(definition, challengeId);
               if (challenge == null)
                {
                    ContractWire.SendException(_session, guid, 404);
                    return;
                }

                BattlePassPlayerStateDocument before = BattlePassRuntime.GetState(playerId, definition);
                int oldPoints = before.ChallengePoints.TryGetValue(challenge.Id, out int oldValue) ? Math.Max(0, oldValue) : 0;

                int target = Math.Max(1, challenge.TargetPoints);
               int desired = Math.Clamp(Math.Max(oldPoints, reportedPoints), 0, target);
                BattlePassMissionSettlementResult settled = BattlePassRuntime.ApplyClientChallengeAbsolute(
                    playerId, challenge.Id, desired);
               BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                int current = state.ChallengePoints.TryGetValue(challenge.Id, out int currentValue) ? Math.Max(0, currentValue) : 0;
                bool completed = state.CompletedChallenges.Contains(challenge.Id) || current >= target;

                byte[] givenReward = BuildReward(settled.Reward);
                byte[] response = ContractWire.Build(w =>
                {
                    w.Bool(1, completed);
                    w.Int32(2, current);
                     w.Message(3, givenReward);
                    w.Int32(4, Math.Max(0, state.Points));
                     foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                    {
                        string passId = definition.Id + ":" + pass.Key;
                         int level = BattlePassRuntime.GetCurrentPassLevel(state, definition, pass.Key);
                        w.Message(5, ContractWire.Build(e => { e.String(1, passId); e.Int32(2, level); }));
                    }
                    w.Message(6, givenReward);
                   w.Bool(7, completed);
                });
                SendOkRaw(guid, response);

                if (settled.Reward != null && (settled.Reward.Items.Count > 0 || settled.Reward.Currencies.Count > 0))
                    InventoryEventBus.InventoryChanged(playerId, added: settled.Reward.Items, currencies: settled.Reward.Currencies, source: "prey-bp-progressV2");
                SendChallengeChanged(playerId, new[] { challenge.Id }, settled.Reward);
               if (settled.EventPointsAwarded > 0 || settled.CompletedChallenges.Count > 0)
                     SendPassChanged(playerId, settled.Reward);

           }
        }

        private static byte[] BuildReward(Reward reward)
        {

            return ContractWire.Build(w =>
            {
                if (reward == null) return;
                foreach (InventoryItem item in reward.Items)
                {

                    w.Message(1, ContractWire.Build(i =>
                    {
                        i.Int32(1, item.Id);
                        i.Int32(2, item.ItemDefinitionId);
                        i.Int32(3, item.Quantity);
                        i.Int32(4, item.Flags);
                         i.Varint(5, item.Date);
                    }));
                }
                foreach (CurrencyAmount currency in reward.Currencies) w.Message(2, currency.ToByteArray());
            });
        }

        private void SaveChallenge2(string playerId, RpcRequest request, string guid)
       {
            string editSetting = Environment.GetEnvironmentVariable("bp_allow_challenge_edit");
            if (string.IsNullOrWhiteSpace(editSetting))
                editSetting = Environment.GetEnvironmentVariable("BOLT_BP_ALLOW_CLIENT_ADMIN_MUTATIONS");
            bool allow = string.Equals(editSetting, "true", StringComparison.OrdinalIgnoreCase);
            if (!allow)
            {
                ContractWire.SendException(_session, guid, 403);
                return;
            }
            byte[] raw = ContractWire.Param(request);
            string code = ContractWire.ReadStringField(raw, 1, string.Empty);
            string action = ContractWire.ReadStringField(raw, 2, string.Empty);
            int targetPoints = ContractWire.ReadIntField(raw, 3, 1);
           if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("challenge code is required");
            BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
             BattlePassRuntime.SaveCustomChallenge(definition, code, action, targetPoints);
           ContractWire.SendEmpty(_session, guid);
       }

        public static void BroadcastStateChanged(string playerId, Reward reward)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;
            lock (BattlePassRuntime.LockForPlayer(playerId))
           {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
                SendPassState(playerId, definition, state, reward ?? new Reward());
            }
        }
        private static int CountClaimable(BattlePassDefinition definition, BattlePassPlayerStateDocument state)
       {
            int count = 0;
             foreach (var pass in definition.Passes)
            {
                int currentLevel = state.Levels.TryGetValue(pass.Key, out int value) ? value : 0;
                count += pass.Value.Count(level => level.Level > 0 && level.Level <= currentLevel &&
                     !state.ClaimedRewards.Contains(pass.Key + ":" + level.Level));
            }
            return count;
        }

       private static HashSet<string> ReadStrings(byte[] raw, int fieldNumber)
        {
            var values = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (raw == null || raw.Length == 0) return values;
            var input = new CodedInputStream(raw);
             uint tag;
            while ((tag = input.ReadTag()) != 0)
             {
                if (WireFormat.GetTagFieldNumber(tag) == fieldNumber &&
                    WireFormat.GetTagWireType(tag) == WireFormat.WireType.LengthDelimited)
                    values.Add(input.ReadString());
                else
                     input.SkipLastField();
            }
            return values;
        }

         private static Reward ClaimPassRewards(
            string playerId,
             BattlePassDefinition definition,
            BattlePassPlayerStateDocument state,
            HashSet<string> requestedPasses,
           bool xpLevel = false)
        {
            BattlePassRuntime.UpdateLevelsOnly(state, definition);
            bool ownsGoldPass = BattlePassRuntime.OwnsInventoryDefinition(playerId, definition.GoldPassItemDefinitionId);
             var aggregate = new Reward();
            foreach (var pass in definition.Passes)
            {
                if (requestedPasses != null && requestedPasses.Count > 0 && !requestedPasses.Contains(pass.Key)) continue;
               if (!xpLevel && pass.Key.Equals("GoldPass", StringComparison.OrdinalIgnoreCase) && !ownsGoldPass) continue;
                int currentLevel = state.Levels.TryGetValue(pass.Key, out int value) ? value : 1;
                foreach (GamePassLevel level in pass.Value.Where(x => x.Level > (xpLevel ? 1 : 0) && x.Level <= currentLevel).OrderBy(x => x.Level))
                {
                    string claimKey = pass.Key + ":" + level.Level;
                    if (state.ClaimedRewards.Contains(claimKey)) continue;
                   Reward granted = BattlePassRuntime.GrantRewardInfo(playerId, level.Reward ?? new RewardInfo());
                    BattlePassRuntime.MergeReward(aggregate, granted);
                    state.ClaimedRewards.Add(claimKey);
                }
            }
            return aggregate;
        }

        private static byte[] BuildPassLevel(GamePassLevel level, bool preyProgress = false)
        {
            return ContractWire.Build(w =>
            {
                w.Int32(1, level.Level);
                w.Int32(2, Math.Max(0, level.MinPoints));
                if (level.Reward != null) w.Message(3, level.Reward.ToByteArray());
                w.Int32(4, !preyProgress && level.Level == PlayerLevelRuntime.RecurringCarrierLevel ? PlayerLevelRuntime.RecurringXpStep : 0);
            });
        }

        private static IReadOnlyList<int> Claimable(BattlePassDefinition definition, BattlePassPlayerStateDocument state, string passCode)
        {
           if (definition.Id == PlayerLevelRuntime.EventId)
                return PlayerLevelRuntime.GetClaimableLevels(definition, state, passCode);
            if (!definition.Passes.TryGetValue(passCode, out List<GamePassLevel> levels)) return Array.Empty<int>();
            int current = state.Levels.TryGetValue(passCode, out int c) ? c : 1;
            return levels.Where(x => x.Level > 0 && x.Level <= current && !state.ClaimedRewards.Contains(passCode + ":" + x.Level))
                .Select(x => x.Level).OrderBy(x => x).ToArray();
        }

        private static byte[] BuildPlayerLevelEvent(BattlePassDefinition definition, BattlePassPlayerStateDocument state)
        {
            return ContractWire.Build(w =>
           {
                w.String(1, definition.Id); w.String(2, definition.Code);
                w.Varint(3, ToClientTime(definition.DateSince)); w.Varint(4, ToClientTime(definition.DateUntil)); w.Int32(5, definition.DurationDays);
                foreach (var pass in definition.Passes)
               {
                    string passId = definition.Id + ":" + pass.Key;
                    IReadOnlyList<int> claimable = Claimable(definition, state, pass.Key);
                    byte[] gamePass = ContractWire.Build(p =>
                    {
                        p.String(1, passId); p.String(2, pass.Key); p.Int32(3, 0);
                         foreach (GamePassLevel level in pass.Value) p.Message(4, BuildPassLevel(level));
                        int current = state.Levels.TryGetValue(pass.Key, out int c) ? c : 1;
                        p.Int32(5, Math.Max(1, current));
                        foreach (int level in claimable) p.Int32(6, level);
                     });
                    w.Message(6, gamePass);
                 }

                w.Int32(7, state.Points); w.Int32(8, definition.CurrentDay);
            });
       }

        private static byte[] BuildPlayerLevelDefinition(BattlePassDefinition definition)
        {
            return ContractWire.Build(w =>
             {
               w.String(1, definition.Id); w.String(2, definition.Code);
                w.Varint(3, ToClientTime(definition.DateSince)); w.Varint(4, ToClientTime(definition.DateUntil)); w.Int32(5, definition.DurationDays);
                foreach (var pass in definition.Passes)
                 {
                    byte[] passDefinition = ContractWire.Build(p =>
                     {
                        p.String(1, definition.Id + ":" + pass.Key); p.String(2, pass.Key); p.Int32(3, 0);
                        foreach (GamePassLevel level in pass.Value) p.Message(4, BuildPassLevel(level));
                    });
                    w.Message(6, passDefinition);
                }
                w.Message(9, ContractWire.Build(title => { title.String(1, PlayerLevelRuntime.EventId); title.String(2, "Player level"); }));
                w.String(10, "account_level"); w.Bool(11, false);
             });
        }

        internal static int SendPlayerLevelChanged(string playerId)
       {
            if (string.IsNullOrWhiteSpace(playerId)) return 0;
            PlayerLevelRuntime.NormalizePersistedStats(playerId);
            BattlePassDefinition definition = PlayerLevelRuntime.GetDefinition();
            BattlePassPlayerStateDocument state = PlayerLevelRuntime.GetState(playerId, definition);
             string passCode = definition.Passes.Keys.First();
            IReadOnlyList<int> claimable = Claimable(definition, state, passCode);
            byte[] payload = ContractWire.Build(w =>
            {
                w.String(1, definition.Id);
                w.Int32(2, state.Points);
                foreach (var level in state.Levels)
                     w.Message(3, ContractWire.Build(e => { e.String(1, definition.Id + ":" + level.Key); e.Int32(2, Math.Max(1, level.Value)); }));
                w.Message(4, Array.Empty<byte>());
                foreach (var level in state.Levels)
                {
                    IReadOnlyList<int> levelsToClaim = Claimable(definition, state, level.Key);
                    byte[] list = ContractWire.Build(l => { foreach (int x in levelsToClaim) l.Int32(1, x); });
                    w.Message(5, ContractWire.Build(e => { e.String(1, definition.Id + ":" + level.Key); e.Message(2, list); }));
                }
           });
            int delivered = GameEventRemoteEventSender.SendRawToPlayer(playerId, "onGamePassChanged", payload,
                $"player-level-sync;points={state.Points};current={state.Levels[passCode]};claimable={claimable.Count}");
            return delivered;
        }

        internal static int SendChallengeChanged(string playerId, IEnumerable<string> challengeIds, Reward reward = null)
        {
            if (string.IsNullOrWhiteSpace(playerId) || challengeIds == null) return 0;
            BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
            BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
            var wanted = new HashSet<string>(challengeIds.Where(x => !string.IsNullOrWhiteSpace(x)), StringComparer.Ordinal);
            if (wanted.Count == 0) return 0;

            int delivered = 0;
            foreach (BattlePassChallengeDocument challenge in BattlePassRuntime.GetChallengeDefinitions(definition))
            {
                 if (!wanted.Contains(challenge.Id)) continue;
                int current = state.ChallengePoints.TryGetValue(challenge.Id, out int value) ? Math.Max(0, value) : 0;
                bool completed = state.CompletedChallenges != null && state.CompletedChallenges.Contains(challenge.Id);
                 byte[] payload = ContractWire.Build(w =>
                {
                    w.String(1, challenge.Id);
                    w.Bool(2, completed);
                    w.Int32(3, current);
                    w.Message(4, BuildReward(reward));
                   w.String(5, definition.Id);
                    w.Int32(6, Math.Max(0, state.Points));
                    foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                    {
                        int level = BattlePassRuntime.GetCurrentPassLevel(state, definition, pass.Key);
                        w.Message(7, ContractWire.Build(e => { e.String(1, definition.Id + ":" + pass.Key); e.Int32(2, level); }));
                    }
                    w.Message(8, BuildReward(reward));
                    foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                    {
                        string passId = definition.Id + ":" + pass.Key;
                        IReadOnlyList<int> levels = Claimable(definition, state, pass.Key);
                         byte[] list = ContractWire.Build(l => { foreach (int level in levels) l.Int32(1, level); });
                        w.Message(9, ContractWire.Build(e => { e.String(1, passId); e.Message(2, list); }));
                    }
                     w.Bool(10, completed);
                    w.String(11, ChallengeProgressId(state, challenge));
                });
                int one = GameEventRemoteEventSender.SendRawToPlayer(playerId, "onProgressChallengeEvent", payload,
                    $"prey-challenge-sync;id={challenge.Id};points={current};completed={completed}");
               delivered += one;
            }
           return delivered;
        }

       internal static void SendPassChanged(string playerId, Reward reward = null)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;
            BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
            BattlePassPlayerStateDocument state = BattlePassRuntime.GetState(playerId, definition);
            SendPassState(playerId, definition, state, reward ?? new Reward());
        }

        private static void SendPassState(string playerId, BattlePassDefinition definition, BattlePassPlayerStateDocument state, Reward reward)
        {
            int delivered = 0;
            foreach (string alias in BattlePassRuntime.GetPreyWireAliases())
            {
                byte[] payload = ContractWire.Build(w =>
                {
                    w.String(1, alias);
                    w.Int32(2, Math.Max(0, state.Points));
                    foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                    {
                         int current = BattlePassRuntime.GetCurrentPassLevel(state, definition, pass.Key);
                        string passId = alias + ":" + pass.Key;
                         w.Message(3, ContractWire.Build(e => { e.String(1, passId); e.Int32(2, Math.Max(1, current)); }));
                    }
                   w.Message(4, BuildReward(reward));
                     foreach (var pass in definition.Passes.OrderBy(x => x.Key == "FreePass" ? 0 : 1))
                    {
                        string passId = alias + ":" + pass.Key;
                        IReadOnlyList<int> levels = Claimable(definition, state, pass.Key);
                        byte[] list = ContractWire.Build(l => { foreach (int level in levels) l.Int32(1, level); });
                        w.Message(5, ContractWire.Build(e => { e.String(1, passId); e.Message(2, list); }));
                    }
                });
               delivered += GameEventRemoteEventSender.SendRawToPlayer(playerId, "onGamePassChanged", payload,
                    $"prey-bp-sync;alias={alias};points={state.Points};model=absolute-cumulative");
            }
        }

        private static T Parse<T>(RpcRequest request, int index) where T : class
        {
            if (request.Params == null || request.Params.Count <= index)
                 throw new ArgumentException($"Missing parameter {index}");
            return (T)new RpcValueReader(typeof(T)).FromBytes(request.Params[index]);
        }

        private static T ParsePrimitive<T>(RpcRequest request, int index)
        {
            if (request.Params == null || request.Params.Count <= index)
                throw new ArgumentException($"Missing parameter {index}");
            return (T)new RpcValueReader(typeof(T)).FromBytes(request.Params[index]);
        }

        private static string ReadString(RpcRequest request, int index)
        {
            if (request.Params == null || request.Params.Count <= index || request.Params[index].IsNull)
                return string.Empty;
            var input = new CodedInputStream(request.Params[index].One.ToByteArray());
            string result = string.Empty;
            uint tag;
            while ((tag = input.ReadTag()) != 0)
            {
                if (tag == 10) result = input.ReadString();
                else input.SkipLastField();
            }
            return result;
        }

        private void SendOkRaw(string guid, byte[] payload)
        {
            ContractWire.SendRaw(_session, guid, payload ?? Array.Empty<byte>());
       }

        private void SendOk<T>(string guid, T message)
        {
             _session.SendResponse(new ResponseMessage
           {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new RpcValueWriter(typeof(T)).ToBytes(message)
                }
            });
        }

        private void SendVoid(string guid)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string guid, int code, string message)
         {
            _session.SendResponse(new ResponseMessage
            {
                 RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }

    public sealed class GameEventRemoteEventSender : IEventSender
     {
        private readonly ClientSession _session;
        public ClientSession User => _session;
        public string eventListenerName { get; set; } = "GameEventRemoteEventListener";

        public GameEventRemoteEventSender(ClientSession user) => _session = user;

        public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse response = BoltEventContract.Create(eventListenerName, eventName, parameters ?? Array.Empty<object>());
            _session.SendResponse(new ResponseMessage { EventResponse = response });
        }

       public void SendRawEvent(string eventName, byte[] payload, string source)
        {
            EventResponse response = BoltEventContract.CreateRaw(eventListenerName, eventName, payload ?? Array.Empty<byte>());
            _session.SendResponse(new ResponseMessage { EventResponse = response });
        }

        internal static int SendRawToPlayer(string playerId, string eventName, byte[] payload, string source)
        {
            List<GameEventRemoteEventSender> senders = ServerState.GetLiveEventSenders<GameEventRemoteEventSender>(playerId);
            int delivered = 0;
            foreach (GameEventRemoteEventSender sender in senders)
            {
                try { sender.SendRawEvent(eventName, payload, source); delivered++; }
                catch { }
            }
            return delivered;
         }
    }

}
