using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public class StorageRemoteService : RpcHandler
    {
        private const string rejoinopton = "rejoin_options";

        private const string LastMatchstatFile = "last_match_status";

        public StorageRemoteService(ClientSession user) : base(user)
        {


        }

        public void WriteFile(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                RpcValueReader from = new RpcValueReader(typeof(string));
                RpcValueReader from2 = new RpcValueReader(typeof(byte[]));
                string FileName = (string)from.FromBytes(values[0]);
                byte[] File = (byte[])from2.FromBytes(values[1]);

                if (string.Equals(FileName, rejoinopton, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(FileName, LastMatchstatFile, StringComparison.OrdinalIgnoreCase))
                {
                    BsonDocument match = RejoinMatch(Id);
                    if (match != null)
                    {
                        if (string.Equals(FileName, rejoinopton, StringComparison.OrdinalIgnoreCase))
                       {

                             File = RejoinOptions(match);
                        }

                         if (string.Equals(FileName, LastMatchstatFile, StringComparison.OrdinalIgnoreCase))
                        {
                            File = Encoding.UTF8.GetBytes("0");
                        }
                    }
                    else if (string.Equals(FileName, rejoinopton, StringComparison.OrdinalIgnoreCase))
                    {
                        if (!IsEmpty(File) && IsRecentRejoin(File, 240) && IsRankedRejoin(File))
                        {
                            boltMain.WriteOrCreateFile(ObjectId.Parse(Id), LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                        }
                        else if (IsEmpty(File))
                        {

                            FileStoragesDocument stored = boltMain.GetFiles(ObjectId.Parse(Id));
                            if (stored?.files != null && stored.files.TryGetValue(rejoinopton, out BsonValue rv) && rv.IsBsonArray)
                            {
                                byte[] previous = rv.AsBsonArray.Select(v => (byte)v.AsInt32).ToArray();
                                if (IsRecentRejoin(previous, 240) && IsRankedRejoin(previous))
                                 {
                                    File = previous;
                                    boltMain.WriteOrCreateFile(ObjectId.Parse(Id), LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                                }
                            }
                        }
                    }

                    if (string.Equals(FileName, rejoinopton, StringComparison.OrdinalIgnoreCase) && !IsEmpty(File))
                    {
                        boltMain.WriteOrCreateFile(ObjectId.Parse(Id), LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                    }
                }

                boltMain.WriteOrCreateFile(ObjectId.Parse(Id), FileName, File);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                return;
            }

            Unauthorized(guid);
        }

        public void ReadFiles(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {

                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                BsonDocument match = RejoinMatch(Id);
                FileStoragesDocument fileStorage = boltMain.GetFiles(ObjectId.Parse(Id));
                var projected = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
                foreach (BsonElement stored in fileStorage.files)
                {

                    projected[stored.Name] = stored.Value.AsBsonArray
                        .Select(v => (byte)v.AsInt32).ToArray();
                }

                byte[] authoritativeRejoin = BuildActiveRejoinOptions(Id);
                if (authoritativeRejoin.Length > 0)
                {
                    projected[rejoinopton] = authoritativeRejoin;
                   projected[LastMatchstatFile] = Encoding.UTF8.GetBytes("0");
                }
Storage[] storages = projected.Select(a => new Storage
                {
                    Filename = a.Key,
                    File = ByteString.CopyFrom(a.Value)
                }).ToArray();

                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(Storage[])).ToBytes(storages) } });
                return;
            }

            Unauthorized(guid);
        }
        public static bool ArmRankedRejoin(string playerId, string source)
         {
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out ObjectId objectId))
                return false;
           try
            {
                BsonDocument match = RejoinMatch(playerId);
                if (match == null)
                {
                     return false;
                }
                byte[] rejoin = RejoinOptions(match);
               BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                boltMain.WriteOrCreateFile(objectId, rejoinopton, rejoin);
                boltMain.WriteOrCreateFile(objectId, LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                return true;
           }
            catch (System.Exception)
            {
                return false;
            }
        }
        private static BsonDocument RejoinMatch(string playerId)
        {
            try
            {
                return RankedAuthorityRepository.Instance.GetActiveRejoinDescriptor(playerId);
           }
            catch (System.Exception)
            {
                return null;
            }
        }

        private static bool IsEmpty(byte[] file)
        {
            if (file == null || file.Length == 0)
            {
                return true;
            }

            string text = Encoding.UTF8.GetString(file).Trim();

            return text.Length == 0 || text == "null" || text == "\"\"";
        }

        internal static byte[] BuildActiveRejoinOptions(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out ObjectId objectId))
                return Array.Empty<byte>();
           try
            {
                BsonDocument match = RankedAuthorityRepository.Instance.GetActiveRejoinDescriptor(playerId);
               if (match != null)
                {
                    byte[] rejoin = RejoinOptions(match);
                    BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                   boltMain.WriteOrCreateFile(objectId, rejoinopton, rejoin);
                    boltMain.WriteOrCreateFile(objectId, LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                    return rejoin;
                }

                FileStoragesDocument stored = BoltGameDatabaseProvider.Instance.GetFiles(objectId);
                if (stored?.files != null &&
                    stored.files.TryGetValue(rejoinopton, out BsonValue rv) && rv.IsBsonArray)
                {
                    byte[] raw = rv.AsBsonArray.Select(v => (byte)v.AsInt32).ToArray();
                    if (IsRecentRejoin(raw, 240))
                    {
                        BoltGameDatabaseProvider.Instance.WriteOrCreateFile(objectId, LastMatchstatFile, Encoding.UTF8.GetBytes("0"));
                        return raw;
                    }
                }
                return Array.Empty<byte>();
            }
            catch (System.Exception)
            {
                return Array.Empty<byte>();
            }
        }

        private static bool IsRankedRejoin(byte[] file)
        {
            if (file == null || file.Length == 0) return false;
            try
            {
               string json = Encoding.UTF8.GetString(file);
                   return json.IndexOf("\"IsRankedMatchmaking\":true", StringComparison.OrdinalIgnoreCase) >= 0 &&
                  
                    json.IndexOf("\"RoomName\":\"Ranked", StringComparison.OrdinalIgnoreCase) >= 0 &&
                  
                    json.IndexOf("\"GameVersion\":", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            catch { return false; }
        }

        private static bool IsRecentRejoin(byte[] file, int maxAgeSeconds)
        {
             if (file == null || file.Length == 0) return false;
            try
            {
               string json = Encoding.UTF8.GetString(file);
                const string marker = "\"JoinTimeInSeconds\":";
                int start = json.IndexOf(marker, StringComparison.Ordinal);
                if (start < 0) return false;
                 start += marker.Length;
                int end = start;
                while (end < json.Length && char.IsDigit(json[end])) end++;
                if (end <= start || !long.TryParse(json.Substring(start, end - start), out long joined)) return false;
                long age = DateTimeOffset.UtcNow.ToUnixTimeSeconds() - joined;
                return age >= -5 && age <= Math.Max(1, maxAgeSeconds);
            }
            catch { return false; }
        }

        private static byte[] RejoinOptions(BsonDocument match)
        {
            string room = Escape(match.GetValue("roomName", string.Empty).ToString());
            string region = Escape(match.GetValue("region", string.Empty).ToString());
            string gameMode = Escape(match.GetValue("gameModeId", string.Empty).ToString());
            string gameVersion = Escape(RejoinVersion(
                    match.GetValue("gameVersion", "0.33.0F1").ToString()));
            int gameType = match.GetValue("gameType", 0).ToInt32();
            long joinTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            string json = "{" +
                "\"RoomName\":\"" + room + "\"," +
                "\"Region\":\"" + region + "\"," +
                "\"GameModeId\":\"" + gameMode + "\"," +
                "\"IsRankedMatchmaking\":true," +
                "\"GameType\":" + gameType + "," +
                "\"JoinTimeInSeconds\":" + joinTime + "," +
                "\"GameVersion\":\"" + gameVersion + "\"}";

            return Encoding.UTF8.GetBytes(json);
        }

        private static string RejoinVersion(string value)
        {
            string raw = (value ?? string.Empty).Trim();
            if (raw.Length == 0 || raw.StartsWith("0.33.0", StringComparison.OrdinalIgnoreCase)) return "0.33.0F1";
            return raw;
         }

        private static string Escape(string value)
        {
            return (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private void Unauthorized(string guid)
        {
            _session.SendResponse(new ResponseMessage
            {
               RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                       Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                 }
             });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "writeFile") WriteFile(request.Params.ToArray(), request.Id);
                                                                                                else if (request.MethodName == "readAllFiles") ReadFiles(request.Params.ToArray(), request.Id);
                                                                                                   else _session.SendResponse(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
      
        }
    }
}
