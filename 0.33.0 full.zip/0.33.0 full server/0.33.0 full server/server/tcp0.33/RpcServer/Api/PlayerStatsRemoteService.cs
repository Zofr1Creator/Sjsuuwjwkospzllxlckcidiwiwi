using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;
using TspServer.MongoDB.Main.PlayerStats;

namespace TspServer.RpcServer.Api
{

    public class PlayerStatsRemoteService : RpcHandler
    {
        public PlayerStatsRemoteService(ClientSession user) : base(user) { }

        internal static string SeasonId => "season-9";

        internal static string SeasonName => "Season 9";

        internal static string SeasonTitle(string seasonId)
        {
            string value = (seasonId ?? string.Empty).Trim();
            if (value.Length == 0) return "Season";
            const string prefix = "season-";
           if (value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && value.Length > prefix.Length)
                return "Season " + value.Substring(prefix.Length);
            return value.Replace('_', ' ');
        }

        internal static List<BsonElement> LoadStats(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out _))
                return new List<BsonElement>();

            try { PlayerLevelRuntime.NormalizePersistedStats(playerId); } catch { }

            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            PlayerStatsDocument document;
             try
            {
                document = database.GetPlayerStatsDocument(playerId);
            }
            catch
            {
                database.CreatePlayerStats(playerId);
                document = database.GetPlayerStatsDocument(playerId);
            }

            List<BsonElement> stats = FillMissingStats(database, playerId, document);
            stats = FillCoreStats(database, playerId, stats);
            return MergeRankedStats(playerId, stats);
        }

        internal static void SaveSeasonStats(string playerId, IEnumerable<BsonElement> stats = null)
        {
            try
            {
                List<BsonElement> snapshot = stats?.ToList() ?? LoadStats(playerId);
                BoltGameDatabaseProvider.Instance.StoreSeasonStatsSnapshot(playerId, SeasonId, snapshot);
            }
            catch { }
        }

        private static List<BsonElement> MissingStats(List<BsonElement> expected, List<BsonElement> current)
        {
            var names = new HashSet<string>(
                (current ?? new List<BsonElement>()).Select(x => x.Name),
                StringComparer.Ordinal);

                 return (expected ?? new List<BsonElement>())
                .Where(x => !names.Contains(x.Name))
                .ToList();
        }
        private static List<BsonElement> MergeRankedStats(string playerId, IEnumerable<BsonElement> inventoryStats)
        {
            var merged = new List<BsonElement>();
            foreach (BsonElement element in inventoryStats ?? Enumerable.Empty<BsonElement>())
            {
                if (!RankedStatGuard.IsServerOwned(element.Name))
                     merged.Add(element);
            }

            try
            {
                BsonDocument ranked = RankedAuthorityRepository.Instance.GetLegacyStats(playerId);
                 foreach (BsonElement element in ranked.Elements)
                {
                    if (RankedStatGuard.IsServerOwned(element.Name))
                        merged.Add(element);
                }
            }
            catch { }
            return merged;
        }

        private static readonly IReadOnlyDictionary<string, int> RequiredStats =
            new Dictionary<string, int>(StringComparer.Ordinal)
            {
                ["level"] = 1,
                ["level_id"] = 1,
                ["xp_reworked"] = 0,
                ["daily_won_matches_last_reset_time"] = 0,

                ["kills"] = 0,
                 ["deaths"] = 0,
                 ["assists"] = 0,
                ["shots"] = 0,
                ["hits"] = 0,
                ["headshots"] = 0,
               ["damage"] = 0,
                ["games_played"] = 0,
                ["resultround"] = 0,
                ["max_killstreak"] = 0,
                ["killtype"] = 0,
                ["hegrenade"] = 0,
                ["firegrenade"] = 0,

                ["ranked_ban_reason"] = 0,
                ["ranked_banned_until"] = 0,
                ["ranked_current_mmr"] = 500,
                ["ranked_rank"] = 0,
                ["ranked_calibration_status"] = 0,
                ["ranked_ban_code"] = -1,
               ["ranked_ban_duration"] = 0,
                ["ranked_banned_match_no"] = 0,
                ["ranked_calibration_match_count"] = 0,
                ["ranked_played_matches"] = 0,
                ["ranked_won_match_count"] = 0,
                ["ranked_best_rank"] = 0,
                ["ranked_best_rank_history1"] = 0,
                ["ranked_2v2_current_mmr"] = 500,
                ["ranked_2v2_rank"] = 0,
                ["ranked_2v2_calibration_status"] = 0,
                ["ranked_2v2_ban_code"] = -1,
                ["ranked_2v2_ban_duration"] = 0,
                ["ranked_2v2_banned_match_no"] = 0,
               ["ranked_2v2_ban_reason"] = 0,
                ["ranked_2v2_banned_until"] = 0,
                ["ranked_2v2_calibration_match_count"] = 0,
                ["ranked_2v2_played_matches"] = 0,
                ["ranked_2v2_won_match_count"] = 0,
                ["ranked_2v2_best_rank"] = 0,
                ["ranked_2v2_best_rank_history1"] = 0,
                ["ranked_duel_current_mmr"] = 500,
                ["ranked_duel_rank"] = 0,
               ["ranked_duel_calibration_status"] = 0,
                ["ranked_duel_ban_code"] = -1,
                ["ranked_duel_ban_duration"] = 0,
                ["ranked_duel_banned_match_no"] = 0,
                ["ranked_duel_ban_reason"] = 0,
                ["ranked_duel_banned_until"] = 0,
                ["ranked_duel_calibration_match_count"] = 0,
                ["ranked_duel_played_matches"] = 0,
                ["ranked_duel_won_match_count"] = 0,
                ["ranked_duel_best_rank"] = 0,
                ["ranked_duel_best_rank_history1"] = 0
            };

         private static List<BsonElement> FillCoreStats(
            BoltGameDatabaseProvider boltMain,
            string playerId,
            IEnumerable<BsonElement> source)
       {
            var current = (source ?? Enumerable.Empty<BsonElement>()).ToList();
            var names = new HashSet<string>(current.Select(x => x.Name), StringComparer.Ordinal);

            ObjectId objectId = ObjectId.Parse(playerId);

            foreach (KeyValuePair<string, int> required in RequiredStats)
            {
                if (names.Contains(required.Key))
                    continue;

                var element = new BsonElement(required.Key, required.Value);
                current.Add(element);
                names.Add(required.Key);
                boltMain.StoreStat(objectId, required.Key, required.Value);

            }

            string[] rankedMmrKeys =
             {
                "ranked_current_mmr",
                "ranked_2v2_current_mmr",
                "ranked_duel_current_mmr"
            };
            foreach (string mmrKey in rankedMmrKeys)
             {
                int index = current.FindIndex(x => string.Equals(x.Name, mmrKey, StringComparison.Ordinal));
               if (index < 0)
                    continue;

                int mmr = 0;
                try { mmr = current[index].Value.ToInt32(); } catch { mmr = 0; }
                if (mmr > 0)
                    continue;

                current[index] = new BsonElement(mmrKey, 500);
                boltMain.StoreStat(objectId, mmrKey, 500);

            }

            FixProgression(boltMain, objectId, playerId, current);
            return current;
        }

        private static void FixProgression(
            BoltGameDatabaseProvider provider,
            ObjectId objectId,
            string playerId,
            List<BsonElement> stats)
        {
            int ReadValue(string key, int fallback)
            {
                BsonElement found = stats.FirstOrDefault(x => string.Equals(x.Name, key, StringComparison.Ordinal));
               if (string.IsNullOrEmpty(found.Name)) return fallback;
                try { return found.Value.ToInt32(); } catch { return fallback; }
            }

            void SetValue(string key, int value)
            {
                int index = stats.FindIndex(x => string.Equals(x.Name, key, StringComparison.Ordinal));
                if (index >= 0) stats[index] = new BsonElement(key, value);
                else stats.Add(new BsonElement(key, value));
                provider.StoreStat(objectId, key, value);
             }

            int xp = Math.Max(0, ReadValue("xp_reworked", 0));
            PlayerLevelRuntime.Snapshot levelState = PlayerLevelRuntime.GetSnapshot(playerId);
            int calculatedLevel = levelState.Level;
            if (ReadValue("level", 1) != calculatedLevel) SetValue("level", calculatedLevel);
            if (ReadValue("level_id", 1) != calculatedLevel) SetValue("level_id", calculatedLevel);
            if (ReadValue("level_xp", -1) != levelState.LevelXp) SetValue("level_xp", levelState.LevelXp);
            if (ReadValue("next_level_xp", -1) != levelState.NextLevelXp) SetValue("next_level_xp", levelState.NextLevelXp);
            if (ReadValue("total_xp_earned", -1) != xp) SetValue("total_xp_earned", xp);
        }

        private static List<BsonElement> FillMissingStats(
            BoltGameDatabaseProvider boltMain,
            string playerId,
            PlayerStatsDocument document)
        {
            List<BsonElement> expectedSchema = MongoDB.Main.PlayerStatsExtension.GetAllNullStats();
            List<BsonElement> current = document?.stats?.ToList() ?? new List<BsonElement>();
            List<BsonElement> missing = MissingStats(expectedSchema, current);
            foreach (BsonElement element in missing)
            {
                current.Add(element);
                boltMain.StoreStat(ObjectId.Parse(playerId), element.Name, element.Value.AsInt32);
            }
            return current;
        }

         protected void GetPlayerStats(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                 RpcValueReader from = new RpcValueReader(typeof(string));
                string playerId = (string)from.FromBytes(values[0]);
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                PlayerStatsDocument playerStatsDocument = boltMain.GetPlayerStatsDocument(playerId);
                List<BsonElement> complete = FillMissingStats(boltMain, playerId, playerStatsDocument);
                Stats stats = new Stats();
                PlayerStat[] playerStats = MergeRankedStats(playerId, complete).Select((a) => a.GetPlayerStat()).ToArray();
                stats.Stat.AddRange(playerStats);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(Stats)).ToBytes(stats) } });
                 return;
            }
           _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        protected void GetStats(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
               PlayerStatsDocument playerStatsDocument = null;
                try
                {
                    playerStatsDocument = boltMain.GetPlayerStatsDocument(Id);
                 } catch (System.Exception)
               {
                    boltMain.CreatePlayerStats(Id);
                     playerStatsDocument = boltMain.GetPlayerStatsDocument(Id);
                }
                List<BsonElement> playerStatsOrig = FillMissingStats(boltMain, Id, playerStatsDocument);
                playerStatsOrig = MergeRankedStats(Id, playerStatsOrig);
                Stats stats = new Stats();
               stats.Stat.AddRange(playerStatsOrig.Select((a) => a.GetPlayerStat()).ToArray());
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(Stats)).ToBytes(stats) } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

       private void GetPlayerStatsV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string viewerId) ||
                string.IsNullOrWhiteSpace(viewerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
            string playerId = ContractWire.ReadStringField(raw, 1, string.Empty);
            List<string> requestedApiNames =
                ContractWire.ReadRepeatedStringField(raw, 2);

            if (string.IsNullOrWhiteSpace(playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }

            try
            {
                PlayerDocument player =
                    BoltMainDatabaseProvider.Instance.GetPlayerDocument(playerObjectId);
               if (player == null)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
             }

            try
            {
                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
                PlayerStatsDocument document;
                 try
                {
                    document = database.GetPlayerStatsDocument(playerId);
                }
                catch
                {
                    database.CreatePlayerStats(playerId);
                    document = database.GetPlayerStatsDocument(playerId);
                }

                List<BsonElement> complete =
                    FillMissingStats(database, playerId, document);
                complete = FillCoreStats(database, playerId, complete);
                 List<BsonElement> merged =
                    MergeRankedStats(playerId, complete);
                SaveSeasonStats(playerId, merged);

                if (requestedApiNames.Count > 0)
                {
                    var requested = new HashSet<string>(
                        requestedApiNames,
                       StringComparer.Ordinal);
                    foreach (string core in RequiredStats.Keys)
                        requested.Add(core);
                    merged = merged.Where(x => requested.Contains(x.Name)).ToList();
                }

                long updatedDate = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                string seasonId = SeasonId;
                byte[] payload = BuildPlayerStatsResponse(
                    playerId,
                    merged,
                    seasonId,
                    updatedDate);

                ContractWire.SendRaw(_session, request.Id, payload);
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        protected void GetCurrentStats(BinaryValue[] values, string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId))
            {
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                       {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 401
                        }
                    }
                });
                return;
            }

            try
             {
                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
                 PlayerStatsDocument document;
                try
                 {
                    document = database.GetPlayerStatsDocument(playerId);
                }
                catch
                {
                    database.CreatePlayerStats(playerId);
                    document = database.GetPlayerStatsDocument(playerId);
                }

                 List<BsonElement> complete = FillMissingStats(database, playerId, document);
                complete = FillCoreStats(database, playerId, complete);
                List<BsonElement> merged = MergeRankedStats(playerId, complete);
                SaveSeasonStats(playerId, merged);
               long updatedDate = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                string seasonId = SeasonId;

                byte[] payload = BuildCurrentStatsResponse(merged, seasonId, updatedDate);

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(payload)
                        }
                    }
                });
            }
            catch (System.Exception)
            {
                byte[] fallback = new byte[] { 0x0A, 0x00 };
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(fallback)
                        }
                    }
                });
            }
        }

        private static byte[] BuildPlayerStatsResponse(
            string playerId,
            IEnumerable<BsonElement> source,
            string seasonId,
           long updatedDate)
        {
            byte[] statsBytes = BuildStatsMessage(source, seasonId, updatedDate);
            byte[] playerStatsBytes = ContractWire.Build(w =>
            {
                w.String(1, playerId);
                w.Message(2, statsBytes);
           });
            return ContractWire.Build(w =>
                w.Message(1, playerStatsBytes));
        }

        private static byte[] BuildCurrentStatsResponse(
            IEnumerable<BsonElement> source,
             string seasonId,
            long updatedDate)
        {
            byte[] statsBytes = BuildStatsMessage(source, seasonId, updatedDate);
            using MemoryStream stream = new MemoryStream();
            using (CodedOutputStream output = new CodedOutputStream(stream))
            {
                output.WriteRawTag(0x0A);
                output.WriteBytes(ByteString.CopyFrom(statsBytes));
                output.Flush();
            }
            return stream.ToArray();
        }

         private static byte[] BuildStatsMessage(
           IEnumerable<BsonElement> source,
            string seasonId,
             long updatedDate)
       {
            using MemoryStream stream = new MemoryStream();
            using (CodedOutputStream output = new CodedOutputStream(stream))
            {
                foreach (BsonElement element in source ?? Enumerable.Empty<BsonElement>())
                {
                    if (string.IsNullOrWhiteSpace(element.Name) ||
                        element.Value == null ||
                        element.Value.IsBsonNull)
                         continue;

                    byte[] playerStat = BuildPlayerStat(element);
                    output.WriteRawTag(0x0A);
                    output.WriteBytes(ByteString.CopyFrom(playerStat));
                }

                if (!string.IsNullOrWhiteSpace(seasonId))
                {
                    output.WriteRawTag(0x1A);
                    output.WriteString(seasonId);
                }

                if (updatedDate != 0)
                {
                    output.WriteRawTag(0x20);
                    output.WriteInt64(updatedDate);
                }
                output.Flush();
            }
           return stream.ToArray();
        }

        internal static byte[] BuildPlayerStat(BsonElement element)
        {
             using MemoryStream stream = new MemoryStream();
            using (CodedOutputStream output = new CodedOutputStream(stream))
            {
                output.WriteRawTag(0x0A);
                output.WriteString(element.Name);

                BsonValue value = element.Value;
                switch (value.BsonType)
                {
                    case BsonType.Int32:
                        WriteIntStat(output, value.AsInt32);
                        break;

                    case BsonType.Int64:

                         long longValue = value.AsInt64;
                        if (RankedStatGuard.IsServerOwned(element.Name) &&
                            longValue >= int.MinValue && longValue <= int.MaxValue)
                        {
                            WriteIntStat(output, (int)longValue);
                       }
                        else
                        {
                            output.WriteRawTag(0x28);
                            output.WriteInt32(3);
                            output.WriteRawTag(0x30);
                            output.WriteInt64(longValue);
                        }
                       break;

                    case BsonType.Boolean:
                        WriteIntStat(output, value.AsBoolean ? 1 : 0);
                        break;

                    case BsonType.Double:
                        WriteFloatStat(output, (float)value.AsDouble);
                        break;

                   case BsonType.Decimal128:
                        WriteFloatStat(
                            output,
                            (float)Decimal128.ToDecimal(value.AsDecimal128)
                        );
                       break;

                    default:
                        WriteIntStat(output, 0);
                        break;
                }
                output.Flush();
           }
            return stream.ToArray();
        }

         private static void WriteIntStat(CodedOutputStream output, int value)
        {
            if (value != 0)
            {
               output.WriteRawTag(0x10);
                output.WriteInt32(value);
             }
        }

        private static void WriteFloatStat(CodedOutputStream output, float value)
        {
            output.WriteRawTag(0x28);
            output.WriteInt32(1);
            if (value != 0f)
            {
                output.WriteRawTag(0x1D);
                output.WriteFloat(value);
            }
        }

        private sealed class StoreStatsPlayer
        {
            public string Gpid = string.Empty;
            public string SeasonId = string.Empty;
            public readonly List<StoreStatsValue> Stats = new List<StoreStatsValue>();
       }

       private sealed class StoreStatsValue
        {
            public string Name = string.Empty;
            public BsonValue Value = 0;
        }

        private static List<StoreStatsPlayer> ParseStoreRequest(byte[] raw)
        {
             var result = new List<StoreStatsPlayer>();
            var input = new CodedInputStream(raw ?? Array.Empty<byte>());
            uint tag;
            while ((tag = input.ReadTag()) != 0)
            {
                 int field = WireFormat.GetTagFieldNumber(tag);
                if (field != 1 || WireFormat.GetTagWireType(tag) != WireFormat.WireType.LengthDelimited)
                {
                     input.SkipLastField();
                    continue;
                }

                byte[] playerBytes = input.ReadBytes().ToByteArray();
                var player = new StoreStatsPlayer();
                var pi = new CodedInputStream(playerBytes);
                uint pt;
                while ((pt = pi.ReadTag()) != 0)
                {
                   int pf = WireFormat.GetTagFieldNumber(pt);
                    switch (pf)
                    {
                        case 1 when WireFormat.GetTagWireType(pt) == WireFormat.WireType.LengthDelimited:
                            player.Gpid = pi.ReadString();
                            break;
                        case 2 when WireFormat.GetTagWireType(pt) == WireFormat.WireType.LengthDelimited:
                            player.Stats.Add(ParseStatValue(pi.ReadBytes().ToByteArray()));
                            break;
                        case 4 when WireFormat.GetTagWireType(pt) == WireFormat.WireType.LengthDelimited:
                            player.SeasonId = pi.ReadString();
                             break;
                        default:
                            pi.SkipLastField();
                            break;
                   }
                }
                result.Add(player);
            }
            return result;
       }

        private static StoreStatsValue ParseStatValue(byte[] raw)
        {
            var result = new StoreStatsValue();
            bool valueSeen = false;
            var input = new CodedInputStream(raw ?? Array.Empty<byte>());
            uint tag;
           while ((tag = input.ReadTag()) != 0)
            {
                int field = WireFormat.GetTagFieldNumber(tag);
                switch (field)
                {
                    case 1 when WireFormat.GetTagWireType(tag) == WireFormat.WireType.LengthDelimited:
                         result.Name = input.ReadString();
                        break;
                    case 2 when WireFormat.GetTagWireType(tag) == WireFormat.WireType.Varint:
                        result.Value = input.ReadInt32();
                        valueSeen = true;
                        break;
                    case 3 when WireFormat.GetTagWireType(tag) == WireFormat.WireType.Fixed32:
                         result.Value = input.ReadFloat();
                        valueSeen = true;
                        break;
                    case 4 when WireFormat.GetTagWireType(tag) == WireFormat.WireType.Varint:
                        result.Value = input.ReadInt64();
                        valueSeen = true;
                        break;
                    default:
                        input.SkipLastField();
                        break;
                }
            }
            if (!valueSeen) result.Value = 0;
           return result;
        }

        private void StoreStatsV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string currentPlayerId))
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401
                    }
                }});
                return;
            }

            try
            {
                byte[] raw = request.Params.Count > 0 && request.Params[0].One != null
                   ? request.Params[0].One.ToByteArray()
                    : Array.Empty<byte>();
                List<StoreStatsPlayer> players = ParseStoreRequest(raw);
                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;

                foreach (StoreStatsPlayer player in players)
                {
                   string target = string.IsNullOrWhiteSpace(player.Gpid) ? currentPlayerId : player.Gpid;
                    string seasonId = string.IsNullOrWhiteSpace(player.SeasonId) ? SeasonId : player.SeasonId.Trim();

                    if (!string.Equals(target, currentPlayerId, StringComparison.Ordinal))
                    {
                        continue;
                    }

                     foreach (StoreStatsValue stat in player.Stats)
                    {
                         if (string.IsNullOrWhiteSpace(stat.Name)) {  continue; }
                        if (RankedStatGuard.IsServerOwned(stat.Name) || ProgressionStatGuard.IsServerOwned(stat.Name))
                        {
                            continue;
                        }
                        database.StoreStatValue(target, stat.Name, stat.Value);
                        database.StoreSeasonStatValue(target, seasonId, stat.Name, stat.Value);

                    }

                    try
                    {
                        PlayerStatsDocument doc = database.GetPlayerStatsDocument(target);
                        List<BsonElement> complete = FillMissingStats(database, target, doc);
                        complete = FillCoreStats(database, target, complete);
                        List<BsonElement> authoritative = MergeRankedStats(target, complete);
                        database.StoreSeasonStatsSnapshot(target, seasonId, authoritative);
                    }
                    catch
                    {
                        try { database.CreatePlayerStats(target); } catch { }
                    }
}


                _session.SendResponse(new ResponseMessage
                {
                   RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Return = new BinaryValue { IsNull = false, One = ByteString.Empty }
                    }
                });
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500
                    }
               }});
            }
        }

        protected void StoreStats(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                RpcValueReader from = new RpcValueReader(typeof(StorePlayerStat[]));
                StorePlayerStat[] storePlayerStats = (StorePlayerStat[])from.FromBytes(values[0]);
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;

                if (storePlayerStats.Length > 0)
                {
                    foreach (StorePlayerStat storePlayerStat in storePlayerStats)
                    {
                        if (RankedStatGuard.IsServerOwned(storePlayerStat.Name) || ProgressionStatGuard.IsServerOwned(storePlayerStat.Name))
                        {
                            continue;
                        }
                        boltMain.StoreStat(ObjectId.Parse(Id), storePlayerStat);

                    }
                }
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                return;
            }
             _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getCurrentStats") GetCurrentStats(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayerStats2") GetPlayerStatsV2(request);
           else if (request.MethodName == "getPlayerStats") GetPlayerStats(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getStats") GetStats(request.Params.ToArray(), request.Id);
           else if (request.MethodName == "storeStats") StoreStats(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "storeStats2") StoreStatsV2(request);
            else _session.SendResponse(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }
    }
}
