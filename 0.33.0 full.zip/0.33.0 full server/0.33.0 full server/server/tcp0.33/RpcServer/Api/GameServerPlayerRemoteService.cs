using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public class GameServerPlayerRemoteService : RpcHandler
    {
        public GameServerPlayerRemoteService(ClientSession user) : base(user)
        {
        }

        protected void SetPhotonGame(BinaryValue[] values, string guid)
       {
            if (ServerState.GameServerUsers.Contains(_session.TcpClient))
            {
                string Id = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
                Axlebolt.Bolt.Protobuf2.PhotonGame photonGame = (Axlebolt.Bolt.Protobuf2.PhotonGame)new RpcValueReader(typeof(Axlebolt.Bolt.Protobuf2.PhotonGame)).FromBytes(values[1]);
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                RpcServer.PlayerStatus playerStatus = ServerState.GetOrCreatePlayerStatus(Id);
                if (photonGame == null)
                {
                    ServerState.SetPlayerPhotonPresence(Id, null, null, null);
                }
                else
                 {
                    var properties = photonGame.CustomProperties.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
                    ServerState.SetPlayerPhotonPresence(Id, photonGame.RoomId, photonGame.Region, photonGame.AppVersion, properties);
                }
                playerStatus = ServerState.GetOrCreatePlayerStatus(Id);
               boltMain.SetPlayerStatus(ObjectId.Parse(Id), playerStatus);
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                       Return = new BinaryValue
                        {
                            IsNull = true
                         }
                    }
                });
                return;
             }
            _session.SendResponse(new ResponseMessage
           {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                       Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                 }
            });
        }
        private static string ResolveMode(string roomId, IDictionary<string, string> properties)
        {
            string value;
            foreach (string key in new[] { "game_mode", "mode", "GameMode", "C0" })
            {
                if (properties != null && properties.TryGetValue(key, out value) && !string.IsNullOrWhiteSpace(value))
                     return NormalizeMode(value);
            }

            return NormalizeMode(roomId);
        }

        private static string NormalizeMode(string value)
        {
            value = value ?? string.Empty;
            if (value.IndexOf("ranked2v2", StringComparison.OrdinalIgnoreCase) >= 0) return "Ranked 2v2";
            if (value.IndexOf("ranked", StringComparison.OrdinalIgnoreCase) >= 0) return "Ranked Defuse";
            if (value.IndexOf("defuse", StringComparison.OrdinalIgnoreCase) >= 0) return "Defuse";
            if (value.IndexOf("assault", StringComparison.OrdinalIgnoreCase) >= 0) return "Assault";
            if (value.IndexOf("teamdeathmatch", StringComparison.OrdinalIgnoreCase) >= 0 ||
                value.IndexOf("tdm", StringComparison.OrdinalIgnoreCase) >= 0) return "Team Deathmatch";
            if (value.IndexOf("deathmatch", StringComparison.OrdinalIgnoreCase) >= 0) return "Deathmatch";
            if (value.IndexOf("duel", StringComparison.OrdinalIgnoreCase) >= 0) return "Duel";
            return "Game";
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "setPhotonGame") SetPhotonGame(request.Params.ToArray(), request.Id);
            else _session.SendResponse(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }
    }
}
