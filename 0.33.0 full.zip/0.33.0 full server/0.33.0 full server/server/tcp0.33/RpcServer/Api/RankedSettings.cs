using System;
using System.Linq;
using System.Text.Json;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    internal sealed class RankedMatchmakingSettings
    {
        public int[] SearchRange = { 0, 20, 40, 60, 100, 150, 200, 300, 500, 1000, 100000 };
         public int SearchStepDelayMs = 1000;
        public int ConfirmationSeconds = 20;
        public int PlayerTtlMs = 240000;
        public int[] BanDurations = { 900, 3600, 43200, 86400 };
        public int RequiredLevel = 0;
        public int CalibrationMatchesCount = 10;
        public int[] RankDistribution =
        {
            250, 300, 400, 500, 600, 700, 800, 900, 1000,
            1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900
        };
        public double LobbyMaxMmrDifference = 100000.0;
        public int MmrLowerThreshold = 250;
    }

    internal static class RankedSettings
    {
        private static readonly object Sync = new();
        private static DateTime _expiresUtc = DateTime.MinValue;
        private static RankedMatchmakingSettings _ranked5v5;
        private static RankedMatchmakingSettings _ranked2v2;
       private static RankedMatchmakingSettings _rankedDuel;
        public static RankedMatchmakingSettings For(RankedModeContract mode)
        {
            lock (Sync)
            {
                if (_ranked5v5 == null || _ranked2v2 == null || _rankedDuel == null || DateTime.UtcNow >= _expiresUtc)
                    Reload();
                if (mode != null && mode.Id == RankedModeId.Ranked2v2) return _ranked2v2;
                 if (mode != null && mode.Id == RankedModeId.RankedDuel) return _rankedDuel;
                return _ranked5v5;
            }
        }

        private static void Reload()
        {
            _ranked5v5 = Defaults();
            _ranked2v2 = Defaults();
            _rankedDuel = Defaults();
             try
            {
                GameDocument game = BoltMainDatabaseProvider.Instance?.GetGameInfo("0.33.0");
                BsonDocument android = game?.androidSettings;
                if (android != null)
                {
                    ApplyClient(android, _ranked5v5);
                    ApplyClient(android, _ranked2v2);
                    ApplyClient(android, _rankedDuel);
                    ApplyProfile(android, "ranked_profile_settings_season-1", _ranked5v5);
                    ApplyProfile(android, "ranked_2v2_profile_settings_season-1", _ranked2v2);
                    ApplyProfile(android, "ranked_duel_profile_settings_season-1", _rankedDuel);
                }
            }
            catch (System.Exception)
            {
           }

            ExpandRange(_ranked5v5);
           ExpandRange(_ranked2v2);
            ExpandRange(_rankedDuel);

            int confirmation;
            string env = Environment.GetEnvironmentVariable("RANKED_CONFIRMATION_SECONDS");
            if (int.TryParse(env, out confirmation) && confirmation >= 5 && confirmation <= 120)
            {
                _ranked5v5.ConfirmationSeconds = confirmation;
                _ranked2v2.ConfirmationSeconds = confirmation;
                _rankedDuel.ConfirmationSeconds = confirmation;
            }

            _expiresUtc = DateTime.UtcNow.AddSeconds(5);
        }

        private static RankedMatchmakingSettings Defaults() => new RankedMatchmakingSettings();

        private static void ExpandRange(RankedMatchmakingSettings target)
        {
            int[] current = target?.SearchRange ?? Array.Empty<int>();
            int[] tail = { 300, 500, 1000, 100000 };
            target.SearchRange = current.Concat(tail)
                .Select(x => Math.Max(0, x))
                .Distinct()
                .OrderBy(x => x)
                .ToArray();
        }

         private static void ApplyClient(BsonDocument settings, RankedMatchmakingSettings target)
        {
            if (!FindJson(settings, "ranked_client_matchmaking_config", out JsonDocument json))
                return;
            using (json)
            {
                JsonElement root = json.RootElement;
                if (root.TryGetProperty("SearchRange", out JsonElement range) && range.ValueKind == JsonValueKind.Array)
               {
                    int[] parsed = range.EnumerateArray().Where(x => x.TryGetInt32(out _))
                        .Select(x => Math.Max(0, x.GetInt32())).ToArray();
                    if (parsed.Length > 0) target.SearchRange = parsed;
                }
                target.SearchStepDelayMs = ReadInt(root, "SearchStepDelay", target.SearchStepDelayMs, 100, 30000);
                target.PlayerTtlMs = ReadInt(root, "PlayerTTL", target.PlayerTtlMs, 15000, 900000);
                if (root.TryGetProperty("BanDurations", out JsonElement bans) && bans.ValueKind == JsonValueKind.Array)
                {
                    int[] parsed = bans.EnumerateArray().Where(x => x.TryGetInt32(out _))
                        .Select(x => x.GetInt32()).Where(x => x > 0).ToArray();
                    if (parsed.Length > 0) target.BanDurations = parsed;
                }
             }
        }

        private static void ApplyProfile(BsonDocument settings, string key, RankedMatchmakingSettings target)
        {
             if (!FindJson(settings, key, out JsonDocument json))
                return;
            using (json)
           {
                JsonElement root = json.RootElement;
                target.RequiredLevel = ReadInt(root, "RequiredLevel", target.RequiredLevel, 0, 1000);
                target.CalibrationMatchesCount = ReadInt(root, "CalibrationMatchesCount", target.CalibrationMatchesCount, 1, 1000);
                target.MmrLowerThreshold = ReadInt(root, "MmrLowerThreshold", target.MmrLowerThreshold, 0, 100000);
                target.LobbyMaxMmrDifference = ReadDouble(root, "LobbyMaxMmrDifference", target.LobbyMaxMmrDifference, 0, 100000);
                if (root.TryGetProperty("RankDistribution", out JsonElement ranks) && ranks.ValueKind == JsonValueKind.Array)
                {
                    int[] parsed = ranks.EnumerateArray().Where(x => x.TryGetInt32(out _))
                        .Select(x => x.GetInt32()).Where(x => x >= 0).ToArray();
                    if (parsed.Length > 0) target.RankDistribution = parsed;
                }
            }
        }

        private static bool FindJson(BsonDocument settings, string key, out JsonDocument document)
        {
            document = null;
            if (!settings.TryGetValue(key, out BsonValue value) || !value.IsString || string.IsNullOrWhiteSpace(value.AsString))
                return false;
            try
             {
                 document = JsonDocument.Parse(value.AsString);
               return true;
           }
            catch
            {
                return false;
            }
        }

        private static int ReadInt(JsonElement root, string name, int fallback, int min, int max)
         {
            if (!root.TryGetProperty(name, out JsonElement value) || !value.TryGetInt32(out int parsed))
               return fallback;
            return Math.Max(min, Math.Min(max, parsed));
         }

        private static double ReadDouble(JsonElement root, string name, double fallback, double min, double max)
        {
            if (!root.TryGetProperty(name, out JsonElement value) || !value.TryGetDouble(out double parsed))
               return fallback;
            return Math.Max(min, Math.Min(max, parsed));
        }
    }
}
