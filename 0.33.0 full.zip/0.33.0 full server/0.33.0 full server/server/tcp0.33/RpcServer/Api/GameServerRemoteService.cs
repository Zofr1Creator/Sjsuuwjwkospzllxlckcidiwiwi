using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public class GameServerRemoteService : RpcHandler
    {
        public GameServerRemoteService(ClientSession user) : base(user)
        {
        }

        protected void ServerHandshake(BinaryValue[] values, string guid)
        {
           RpcValueReader from = new RpcValueReader(typeof(ServerHandshake));
            ServerHandshake serverHandshake = (ServerHandshake)from.FromBytes(values[0]);
            BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
            GameDocument game = boltMain.GetGameInfo();
            if (game.code.Contains(serverHandshake.ApiKey))
            {
                if (ServerState.GameServerUsers.Contains(_session.TcpClient))
               {
                    _session.SendResponse(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 1332
                            }
                        }
                    });
                    return;
                }
                ServerState.GameServerUsers.Add(_session.TcpClient);
               _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                       }
                    }
                });
            }

        }
         protected void Logout(BinaryValue[] values, string guid)
        {
            if (ServerState.GameServerUsers.Contains(_session.TcpClient))
            {
                ServerState.GameServerUsers.Remove(_session.TcpClient);
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
       public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "serverHandshake") ServerHandshake(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "logout") Logout(request.Params.ToArray(), request.Id);
            else _session.SendResponse(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }
    }
}
