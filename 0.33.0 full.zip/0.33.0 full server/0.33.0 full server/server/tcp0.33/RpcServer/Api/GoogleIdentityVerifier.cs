using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth;

namespace TspServer.RpcServer.Api
{
    internal sealed class GoogleIdentity
    {
        public string Subject { get; init; } = string.Empty;
        public string Email { get; init; } = string.Empty;
        public string Name { get; init; } = string.Empty;
        public string Picture { get; init; } = string.Empty;
        public bool EmailVerified { get; init; }
        public string CredentialKind { get; init; } = string.Empty;
    }

    internal sealed class GoogleIdentityException : Exception
    {
        public GoogleIdentityException(string message) : base(message) { }

        public GoogleIdentityException(string message, Exception inner)
            : base(message, inner) { }
    }

    internal static class GoogleIdentityVerifier
    {
        private static readonly HttpClient Http = new();

        public static async Task<GoogleIdentity> VerifyAsync(
            string credential,
            CancellationToken cancellationToken = default)
        {
            ServerOptions options = ServerOptions.Current;

            if (!options.GoogleAuthEnabled)
                throw new GoogleIdentityException("google auth is disabled");

            if (string.IsNullOrWhiteSpace(options.GoogleWebClientId))
                throw new GoogleIdentityException("google client id is not configured");

            if (string.IsNullOrWhiteSpace(credential))
                throw new GoogleIdentityException("google credential is empty");

            credential = credential.Trim();

            if (IsJwt(credential))
            {
                if (!options.GoogleAllowIdToken)
                    throw new GoogleIdentityException("google id token auth is disabled");

                return await ValidateIdToken(credential, "id_token").ConfigureAwait(false);
            }

            if (!options.GoogleAllowServerAuthCode)
                throw new GoogleIdentityException("google auth code login is disabled");

            if (!options.GoogleWebClientSecretLooksConfigured)
                throw new GoogleIdentityException("google client secret is not configured");

            string idToken = await ExchangeAuthCode(credential, cancellationToken).ConfigureAwait(false);
            return await ValidateIdToken(idToken, "server_auth_code").ConfigureAwait(false);
        }

        private static bool IsJwt(string value)
        {
            int firstDot = value.IndexOf('.');
            if (firstDot <= 0)
                return false;

            int secondDot = value.IndexOf('.', firstDot + 1);
            if (secondDot <= firstDot + 1)
                return false;

            return value.IndexOf('.', secondDot + 1) < 0;
        }

        private static async Task<GoogleIdentity> ValidateIdToken(string idToken, string kind)
        {
            try
            {
                ServerOptions options = ServerOptions.Current;
                var settings = new GoogleJsonWebSignature.ValidationSettings
                {
                    Audience = new[] { options.GoogleWebClientId }
                };

                GoogleJsonWebSignature.Payload payload =
                    await GoogleJsonWebSignature.ValidateAsync(idToken, settings).ConfigureAwait(false);

                if (payload == null || string.IsNullOrWhiteSpace(payload.Subject))
                    throw new GoogleIdentityException("google token has no subject");

                if (options.GoogleRequireVerifiedEmail && payload.EmailVerified != true)
                    throw new GoogleIdentityException("google email is not verified");

                return new GoogleIdentity
                {
                    Subject = payload.Subject,
                    Email = payload.Email ?? string.Empty,
                    Name = payload.Name ?? string.Empty,
                    Picture = payload.Picture ?? string.Empty,
                    EmailVerified = payload.EmailVerified == true,
                    CredentialKind = kind
                };
            }
            catch (GoogleIdentityException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new GoogleIdentityException("google token validation failed", ex);
            }
        }

        private static async Task<string> ExchangeAuthCode(
            string authCode,
            CancellationToken cancellationToken)
        {
            ServerOptions options = ServerOptions.Current;

            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(Math.Clamp(options.GoogleAuthTimeoutMs, 2_000, 30_000));

            var form = new List<KeyValuePair<string, string>>
            {
                new("client_id", options.GoogleWebClientId),
                new("client_secret", options.GoogleWebClientSecret),
                new("code", authCode),
                new("grant_type", "authorization_code")
            };

            if (!string.IsNullOrWhiteSpace(options.GoogleOAuthRedirectUri))
                form.Add(new("redirect_uri", options.GoogleOAuthRedirectUri));

            try
            {
                using var request = new HttpRequestMessage(HttpMethod.Post, options.GoogleTokenEndpoint)
                {
                    Content = new FormUrlEncodedContent(form)
                };
                request.Headers.Accept.ParseAdd("application/json");

                using HttpResponseMessage response =
                    await Http.SendAsync(request, timeout.Token).ConfigureAwait(false);

                string body =
                    await response.Content.ReadAsStringAsync(timeout.Token).ConfigureAwait(false);

                using JsonDocument json =
                    JsonDocument.Parse(string.IsNullOrWhiteSpace(body) ? "{}" : body);

                JsonElement root = json.RootElement;

                if (!response.IsSuccessStatusCode)
                {
                    string error = ReadString(root, "error");
                    string description = ReadString(root, "error_description");

                    if (string.Equals(error, "invalid_client", StringComparison.OrdinalIgnoreCase))
                        throw new GoogleIdentityException("google oauth client is invalid");

                    string details = string.Join(" ", new[] { error, description }).Trim();
                    string message = $"google auth code exchange failed ({(int)response.StatusCode})";

                    if (!string.IsNullOrWhiteSpace(details))
                        message += ": " + details;

                    throw new GoogleIdentityException(message);
                }

                string idToken = ReadString(root, "id_token");
                if (string.IsNullOrWhiteSpace(idToken))
                    throw new GoogleIdentityException("google auth response has no id token");

                return idToken;
            }
            catch (GoogleIdentityException)
            {
                throw;
            }
            catch (OperationCanceledException ex)
            {
                throw new GoogleIdentityException("google auth request timed out", ex);
            }
            catch (Exception ex)
            {
                throw new GoogleIdentityException("google auth code exchange failed", ex);
            }
        }

        private static string ReadString(JsonElement root, string property)
        {
            if (root.ValueKind != JsonValueKind.Object)
                return string.Empty;

            if (!root.TryGetProperty(property, out JsonElement value))
                return string.Empty;

            return value.ValueKind == JsonValueKind.String
                ? value.GetString() ?? string.Empty
                : string.Empty;
        }
    }
}
