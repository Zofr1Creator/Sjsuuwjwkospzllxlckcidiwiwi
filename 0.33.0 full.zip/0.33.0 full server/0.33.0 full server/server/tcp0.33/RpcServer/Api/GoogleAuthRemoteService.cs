using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class GoogleAuthRemoteService : RpcHandler
    {
        private static readonly object GoogleAccountLock = new();

        public GoogleAuthRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request) => InvokeAsync(request).GetAwaiter().GetResult();

        public override async Task InvokeAsync(RpcRequest request)
        {
            if (request == null || request.Params == null || request.Params.Count == 0)
            {
                SendError(request?.Id, 400, "auth payload missing");
                return;
            }

            byte[] raw = Protocol.GetBinaryValueBytes(request.Params[0]);

            if (!ReadAuthRequest(raw, out GoogleAuthRequest authRequest, out string decodeMode, out string parseError))
            {
                SendError(request.Id, 400, "invalid auth protobuf");
                return;
            }

            AuthGoogle auth = authRequest.AuthGoogle;
            string authCode = auth?.AuthCode?.Trim() ?? string.Empty;
            string gameId = string.IsNullOrWhiteSpace(auth?.GameId) ? "1" : auth.GameId;
            string gameVersion = string.IsNullOrWhiteSpace(auth?.GameVersion) ? "0.33.0" : auth.GameVersion;
            bool localGuest = authCode.StartsWith("guest:v1:", StringComparison.Ordinal);
            string credentialKind = localGuest ? "guest" : CountChar(authCode, '.') == 2 ? "jwt-like" : "opaque-code";


            try
            {
                if (localGuest)
                {
                    if (!ServerOptions.Current.AllowLocalGuest)
                    {
                        SendAuthError(request.Id, "Guest authentication is disabled.");
                        return;
                    }

                    GuestLogin(request.Id, authRequest, gameId, gameVersion, authCode, decodeMode);
                    return;
                }

                GoogleIdentity identity = await GoogleIdentityVerifier.VerifyAsync(authCode).ConfigureAwait(false);

                GoogleLogin(request.Id, authRequest, gameId, gameVersion, identity, decodeMode);
            }
            catch (GoogleIdentityException)
            {
                SendAuthError(request.Id, "Google authentication failed.");
            }
            catch (System.Exception)
            {
                SendError(request.Id, 5555, "auth internal error");
            }
        }

        private void GoogleLogin(
            string requestId,
            GoogleAuthRequest authRequest,
            string gameId,
            string gameVersion,
            GoogleIdentity identity,
            string decodeMode)
        {
            BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;
            GoogleAccountDocument account;
            bool created = false;

            lock (GoogleAccountLock)
            {
                try
                {
                    account = database.GetGoogleAccount(identity.Subject);
                }
                catch (AccountNotFoundException)
                {
                    int numericGameId = int.TryParse(gameId, out int parsedGameId) ? parsedGameId : 1;
                    string suffix = Protocol.Fingerprint(Encoding.UTF8.GetBytes(identity.Subject));
                    string playerName = GoogleName(identity, suffix);
                    string playerUid = database.GetNextUid100k().ToString();

                    var verification = new TspServer.MongoDB.Main.Verification
                    {
                        Signature = string.Empty,
                        IsRooted = authRequest.AppVerification?.IsRooted == true,
                        ApkHash = authRequest.AppVerification?.ApkHash ?? string.Empty
                    };
                    var device = new TspServer.MongoDB.Main.DeviceInfo
                    {
                        DeviceId = authRequest.DeviceInfo?.DeviceId ?? string.Empty,
                        DeviceModel = authRequest.DeviceInfo?.DeviceModel ?? string.Empty
                    };

                    try
                    {
                        database.CreateGoogleAccountWithPlayer(
                            playerName,
                            playerUid,
                            identity.Subject,
                            numericGameId,
                            verification,
                            device);
                        created = true;
                    }
                    catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
                    {

                    }

                    account = database.GetGoogleAccount(identity.Subject);
                }
            }

            if (account == null || string.IsNullOrWhiteSpace(account.playerId) ||
                !ObjectId.TryParse(account.playerId, out ObjectId playerId))
                throw new InvalidOperationException("Google account has no valid playerId");

            FinishLogin(requestId, authRequest, gameId, gameVersion, playerId, decodeMode, "google", created);
        }

        private void GuestLogin(
            string requestId,
            GoogleAuthRequest authRequest,
            string gameId,
            string gameVersion,
            string guestToken,
            string decodeMode)
        {
            BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;
            LocalAccountDocument account;
            bool created = false;

            try
            {
                account = database.GetLocalAccount(guestToken);
            }
            catch (AccountNotFoundException)
            {
                int numericGameId = int.TryParse(gameId, out int parsedGameId) ? parsedGameId : 1;
                string suffix = Protocol.Fingerprint(Encoding.UTF8.GetBytes(guestToken));
                string playerName = "Guest_" + suffix;
                string playerUid = database.GetNextUid100k().ToString();

                var device = new TspServer.MongoDB.Main.DeviceInfo
                {
                    DeviceId = authRequest.DeviceInfo?.DeviceId ?? string.Empty,
                    DeviceModel = authRequest.DeviceInfo?.DeviceModel ?? string.Empty
                };
                database.CreateLocalAccountWithPlayer(playerName, playerUid, guestToken, numericGameId, device, "guest");
                account = database.GetLocalAccount(guestToken);
                created = true;
            }

            if (account == null || string.IsNullOrWhiteSpace(account.playerId) ||
                !ObjectId.TryParse(account.playerId, out ObjectId playerId))
                throw new InvalidOperationException("Guest account has no valid playerId");

            FinishLogin(requestId, authRequest, gameId, gameVersion, playerId, decodeMode, "guest", created);
        }

        private void FinishLogin(
            string requestId,
            GoogleAuthRequest authRequest,
            string gameId,
            string gameVersion,
            ObjectId playerId,
            string decodeMode,
            string provider,
            bool created)
        {
            BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;
            PlayerDocument? currentPlayer = null;
            try { currentPlayer = database.GetPlayerDocument(playerId); } catch { }
            if (currentPlayer?.isBanned == true)
            {
                long nowSeconds = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                if (currentPlayer.bannedUntil <= 0 || currentPlayer.bannedUntil > nowSeconds)
                {
                    string activeReason = string.IsNullOrWhiteSpace(currentPlayer.banReason) ? "Account banned" : currentPlayer.banReason;
                    SendBanError(
                        requestId,
                        currentPlayer.banCode <= 0 ? 1 : currentPlayer.banCode,
                        activeReason,
                        currentPlayer.bannedUntil,
                        string.IsNullOrWhiteSpace(currentPlayer.uid) ? playerId.ToString() : currentPlayer.uid);
                    return;
                }
                database.ClearExpiredPlayerBan(playerId);
                currentPlayer.isBanned = false;
                currentPlayer.banCode = 0;
                currentPlayer.banReason = string.Empty;
                currentPlayer.bannedUntil = 0;
            }

            AntiCheatPolicy ac = AntiCheatPolicyProvider.Current;
            if (ac.Enabled)
            {
                bool hasVerification = authRequest.AppVerification != null;
                bool rooted = authRequest.AppVerification?.IsRooted == true;
                int forbiddenApps = authRequest.AppVerification?.JsonForbiddenApps?.Count ?? 0;
                bool hasIntegrityHash = !string.IsNullOrWhiteSpace(authRequest.AppVerification?.ApkHash) ||
                    !string.IsNullOrWhiteSpace(authRequest.AppVerification?.ContentHash);
                bool exempt = currentPlayer?.noDetectRoot == true;
                bool apkAllowlistConfigured = ac.AllowedApkHashes != null && ac.AllowedApkHashes.Count > 0;
                bool contentAllowlistConfigured = ac.AllowedContentHashes != null && ac.AllowedContentHashes.Count > 0;
                bool knownHash = !ac.RequireKnownHashes ||
                    ((apkAllowlistConfigured || contentAllowlistConfigured) &&
                     (!apkAllowlistConfigured || IsHashAllowed(authRequest.AppVerification?.ApkHash, ac.AllowedApkHashes)) &&
                     (!contentAllowlistConfigured || IsHashAllowed(authRequest.AppVerification?.ContentHash, ac.AllowedContentHashes)));
                string violation = !exempt && ac.RequireVerification && !hasVerification
                    ? "verification is missing"
                    : !exempt && ac.RequireHashes && !hasIntegrityHash
                        ? "hash missing"
                        : !exempt && ac.RequireKnownHashes && !knownHash
                            ? "hashe "
                        : !exempt && ac.RejectRooted && rooted
                            ? "root access detected"
                            : !exempt && ac.RejectForbiddenApps && forbiddenApps > 0
                                ? "root environment detected"
                                : string.Empty;
                if (!string.IsNullOrEmpty(violation))
                {
                    long until = ac.BanSeconds > 0
                        ? DateTimeOffset.UtcNow.ToUnixTimeSeconds() + ac.BanSeconds
                        : 0;
                    if (ac.BanOnAuthViolation)
                    {
                        PlayerSanctionService.Ban(playerId.ToString(), ac.BanCode, violation, until, "auth-attestation");
                        SendBanError(
                            requestId,
                            ac.BanCode,
                            violation,
                            until,
                            string.IsNullOrWhiteSpace(currentPlayer?.uid) ? playerId.ToString() : currentPlayer.uid);
                    }
                    else
                    {
                        SendAuthError(requestId, violation);
                    }
                    return;
                }
            }

            DeviceEconomyGuard.ObserveSuccessfulLogin(
                playerId,
                new TspServer.MongoDB.Main.DeviceInfo
                {
                    DeviceId = authRequest.DeviceInfo?.DeviceId ?? string.Empty,
                    DeviceModel = authRequest.DeviceInfo?.DeviceModel ?? string.Empty
                },
                provider,
                created);

            string ticket = SessionTicket.Issue(playerId);
            lock (ServerState.Tokens)
            {
                ServerState.Tokens[ticket] = new Token
                {
                    playerId = playerId,
                    gameCode = gameId,
                    gameVersion = gameVersion
                };
            }

            _session.LastAuthToken = ticket;
            _session.LastGameId = gameId;
            _session.LastGameVersion = gameVersion;

            GoogleAuthResponse response = new GoogleAuthResponse
            {
                PlayerTicket = playerId.ToString()
            };

            byte[] ticketBytes = Encoding.UTF8.GetBytes(ticket);
            byte[] modulus = authRequest.AppVerification?.N?.ToByteArray() ?? Array.Empty<byte>();
            byte[] exponent = authRequest.AppVerification?.E?.ToByteArray() ?? Array.Empty<byte>();
if (Protocol.TryEncryptRsaPkcs1(
                    modulus,
                    exponent,
                    ticketBytes,
                    out byte[] encryptedTicket,
                    out string rsaError))
            {
                response.TicketBinary = ByteString.CopyFrom(encryptedTicket);
            }
            else
            {
                throw new CryptographicException($"0.33 encryption failed: {rsaError}");
            }

            SendProto(requestId, response.ToByteArray(), decodeMode);
        }

        private static int CountChar(string value, char needle)
        {
            int count = 0;
            foreach (char c in value ?? string.Empty) if (c == needle) count++;
            return count;
        }

        private static string GoogleName(GoogleIdentity identity, string fallbackSuffix)
        {
            string source = !string.IsNullOrWhiteSpace(identity.Name)
                ? identity.Name
                : !string.IsNullOrWhiteSpace(identity.Email)
                    ? identity.Email.Split('@')[0]
                    : "Google_" + fallbackSuffix;

            source = Regex.Replace(source, @"[^\p{L}\p{N}_\- ]", string.Empty).Trim();
            if (source.Length == 0) source = "Google_" + fallbackSuffix;
            if (source.Length > 20) source = source.Substring(0, 20);
            return source;
        }

        private bool ReadAuthRequest(
            byte[] raw,
            out GoogleAuthRequest request,
            out string mode,
            out string error)
        {
            request = null;
            mode = "none";
            error = null;

            if (TryParse(raw, out request))
            {
                mode = "direct";
                return true;
            }

            byte[] sessionKey = _session.GetSessionKey();
            byte[] sessionIv = _session.GetSessionIv();
            if (sessionKey?.Length == 16 && sessionIv?.Length == 16 &&
                Protocol.TryDecryptAesCbc(raw, sessionKey, sessionIv, out byte[] sessionPlain) &&
                TryParse(sessionPlain, out request))
            {
                mode = "inner-session-aes";
                return true;
            }

            if (Protocol.TryDecryptAesCbc(raw, Protocol.BootstrapKey, Protocol.BootstrapIv, out byte[] bootstrapPlain) &&
                TryParse(bootstrapPlain, out request))
            {
                mode = "inner-bootstrap-aes";
                return true;
            }

            error = $"payloadBytes={raw?.Length ?? 0}; no direct/session/bootstrap AES variant parsed";
            return false;
        }

        private static bool TryParse(byte[] data, out GoogleAuthRequest request)
        {
            request = null;
            try
            {
                GoogleAuthRequest parsed = GoogleAuthRequest.Parser.ParseFrom(data ?? Array.Empty<byte>());
                if (parsed?.AuthGoogle == null ||
                    string.IsNullOrWhiteSpace(parsed.AuthGoogle.AuthCode))
                    return false;
                request = parsed;
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void SendProto(string requestId, byte[] payload, string decodeMode)
        {
            byte[] responsePayload = EncodeResponse(payload, decodeMode);
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.CopyFrom(responsePayload)
                    }
                }
            });
        }

        private byte[] EncodeResponse(byte[] payload, string decodeMode)
        {
            payload ??= Array.Empty<byte>();

            if (decodeMode == "inner-session-aes")
            {
                byte[] key = _session.GetSessionKey();
                byte[] iv = _session.GetSessionIv();
                return Protocol.EncryptAesCbc(payload, key, iv);
            }

            if (decodeMode == "inner-bootstrap-aes")
                return Protocol.EncryptAesCbc(payload, Protocol.BootstrapKey, Protocol.BootstrapIv);

            return payload;
        }

        private static bool IsHashAllowed(string value, IReadOnlyList<string> allowed)
        {
            if (string.IsNullOrWhiteSpace(value) || allowed == null || allowed.Count == 0) return false;
            string normalized = value.Trim();
            return allowed.Any(x => string.Equals((x ?? string.Empty).Trim(), normalized, StringComparison.OrdinalIgnoreCase));
        }

        private void SendBanError(
            string requestId,
            int banCode,
            string reason,
            long until,
            string uid)
        {
            int safeBanCode = Math.Clamp(banCode, 1, 1_000_000);
            long safeUntil = Math.Max(0, until);
            string safeReason = string.IsNullOrWhiteSpace(reason) ? "Account banned" : reason;
            string safeUid = string.IsNullOrWhiteSpace(uid) ? string.Empty : uid;


            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 9999,
                        Property =
                        {
                            ["banScope"] = "0",
                            ["banCode"] = safeBanCode.ToString(System.Globalization.CultureInfo.InvariantCulture),
                            ["reason"] = safeReason,
                            ["until"] = safeUntil.ToString(System.Globalization.CultureInfo.InvariantCulture),
                            ["uid"] = safeUid
                        }
                    }
                }
            });
        }

        private void SendAuthError(string requestId, string reason)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 2104,
                        Property = { ["reason"] = reason ?? "Authentication failed" }
                    }
                }
            });
        }

        private void SendError(string requestId, int code, string reason)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code,
                        Property = { ["reason"] = reason }
                    }
                }
            });
        }
    }
}
