using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    public sealed class ClanMemberStatsRemoteService : RpcHandler
    {
        private const int MaxStatsPerPlayer = 256;
        private const int MaxStatIdLength = 128;
        private static readonly object IndexLock = new();
        private static bool _indexesReady;

        private IMongoDatabase Db => BoltGameDatabaseProvider.Instance.GetDatabase();
         private IMongoCollection<ClanMemberStatsDoc> Stats =>
            Db.GetCollection<ClanMemberStatsDoc>("clan_member_stats");
        private IMongoCollection<ClanRemoteService.ClanMemberDoc> Members =>
            Db.GetCollection<ClanRemoteService.ClanMemberDoc>("clan_members");

        public ClanMemberStatsRemoteService(ClientSession user) : base(user) { }

        public override Task InvokeAsync(RpcRequest request)
       {
            Invoke(request);
            return Task.CompletedTask;
        }

        public override void Invoke(RpcRequest request)
        {
            try
             {
                 InitIndexes();
                switch (request.MethodName)
               {
                    case "getCurrentClanMemberStats":
                        GetCurrentStats(request);
                        return;
                    case "getClanMembersStats":
                    case "getClanMembersStats2":
                        GetMembersStats(request);
                        return;
                    case "saveCurrentClanMemberStats":
                        SaveCurrentStats(request);
                        return;
                     default:
                        SendException(request.Id, 404);
                        return;
                 }
            }
            catch (ClanMemberStatsException ex)
            {
                SendException(request.Id, ex.Code);
            }
            catch (System.Exception)
           {
                SendException(request.Id, 500);
            }
        }

        private void InitIndexes()
        {
            if (_indexesReady) return;
            lock (IndexLock)
            {
                if (_indexesReady) return;
                try
                {
                    Stats.Indexes.CreateOne(new CreateIndexModel<ClanMemberStatsDoc>(
                       Builders<ClanMemberStatsDoc>.IndexKeys.Ascending(x => x.PlayerId),
                        new CreateIndexOptions { Unique = true, Name = "uniq_clan_member_stats_player" }));
                    Stats.Indexes.CreateOne(new CreateIndexModel<ClanMemberStatsDoc>(
                        Builders<ClanMemberStatsDoc>.IndexKeys.Ascending(x => x.ClanId),
                        new CreateIndexOptions { Name = "idx_clan_member_stats_clan" }));
                }
                catch (System.Exception)
                {
                }
                _indexesReady = true;
            }
        }

        private void GetCurrentStats(RpcRequest request)
        {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            CurrentClanMemberStats current = ReadStats(playerId, membership.ClanId);
            Send(request.Id, new GetCurrentClanMemberStatsResponse
            {
                ClanId = membership.ClanId ?? string.Empty,
                ClanMemberStats = current
            });
        }

        private void GetMembersStats(RpcRequest request)
        {
            GetClanMembersStatsRequest args = Read<GetClanMembersStatsRequest>(request, 0)
                                                ?? new GetClanMembersStatsRequest();
            string clanId = (args.ClanId ?? string.Empty).Trim();
            if (clanId.Length == 0)
            {
               string playerId = GetPlayerId();
                clanId = Membership(playerId).ClanId;
            }

            List<string> memberIds = Members.Find(x => x.ClanId == clanId)
                .Project(x => x.PlayerId)
                .ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .ToList();

            var response = new GetClanMembersStatsResponse { ClanId = clanId };
             foreach (string memberId in memberIds)
            {
                CurrentClanMemberStats stored = ReadStats(memberId, clanId);
                var item = new ClanMemberStats { PlayerId = memberId };
                item.Stats.Add(stored.Stats);
                response.ClanMembersStats.Add(item);
            }
            Send(request.Id, response);
        }

        private void SaveCurrentStats(RpcRequest request)
         {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            SaveCurrentClanMemberStatsRequest args = Read<SaveCurrentClanMemberStatsRequest>(request, 0)
                                                     ?? new SaveCurrentClanMemberStatsRequest();
            CurrentClanMemberStats sanitized = Sanitize(args.ClanMemberStats ?? new CurrentClanMemberStats());
            byte[] payload = sanitized.ToByteArray();

            UpdateDefinition<ClanMemberStatsDoc> update = Builders<ClanMemberStatsDoc>.Update
                .SetOnInsert(x => x._id, ObjectId.GenerateNewId())
                .Set(x => x.PlayerId, playerId)
                .Set(x => x.ClanId, membership.ClanId)
                .Set(x => x.Payload, payload)
                .Set(x => x.UpdatedAt, DateTime.UtcNow);
            Stats.UpdateOne(x => x.PlayerId == playerId, update, new UpdateOptions { IsUpsert = true });

            new ClanStatsRemoteService(_session).BroadcastClanStatsUpdated(membership.ClanId);
            Send(request.Id, new SaveCurrentClanMemberStatsResponse());
        }

        private CurrentClanMemberStats ReadStats(string playerId, string clanId)
        {
            ClanMemberStatsDoc doc = Stats.Find(x => x.PlayerId == playerId && x.ClanId == clanId).FirstOrDefault();
            if (doc?.Payload == null || doc.Payload.Length == 0)
                return new CurrentClanMemberStats();
            try
            {
                return CurrentClanMemberStats.Parser.ParseFrom(doc.Payload);
            }
            catch (System.Exception)
             {
                return new CurrentClanMemberStats();
            }
        }
        private static CurrentClanMemberStats Sanitize(CurrentClanMemberStats source)
       {
            var result = new CurrentClanMemberStats();
            if (source == null) return result;

            var byId = new Dictionary<string, ClanMemberStat>(StringComparer.Ordinal);
           foreach (ClanMemberStat stat in source.Stats.Take(MaxStatsPerPlayer))
            {
                if (stat == null) continue;
                 string id = (stat.StatId ?? string.Empty).Trim();
                if (id.Length == 0 || id.Length > MaxStatIdLength) continue;
                ClanMemberStat clone = stat.Clone();
                clone.StatId = id;
                byId[id] = clone;
            }
            result.Stats.Add(byId.Values);
            return result;
        }

        private ClanRemoteService.ClanMemberDoc Membership(string playerId)
       {
            ClanRemoteService.ClanMemberDoc member = Members.Find(x => x.PlayerId == playerId).FirstOrDefault();
            if (member == null)
               throw new ClanMemberStatsException(ClanRemoteService.ErrorCodes.NotClanMember, "NOT_CLAN_MEMBER");
            return member;
        }

        private string GetPlayerId()
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string id)) return id;
            throw new ClanMemberStatsException(401, "NOT_AUTHENTICATED");
        }

        private static T Read<T>(RpcRequest request, int index) where T : class
        {
            if (request.Params == null || index < 0 || index >= request.Params.Count || request.Params[index].IsNull)
                return null;
            return (T)new RpcValueReader(typeof(T)).FromBytes(request.Params[index]);
        }

        private void Send<T>(string id, T value)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = RpcTypeCodec.CreateToByteMethod(typeof(T)).ToBytes(value)
                }
            });
        }

        private void SendException(string id, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

       public sealed class ClanMemberStatsDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("playerId")] public string PlayerId { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("payload")] public byte[] Payload { get; set; }
            [BsonElement("updatedAt")] public DateTime UpdatedAt { get; set; }
        }

        private sealed class ClanMemberStatsException : System.Exception
        {
            public int Code { get; }
            public ClanMemberStatsException(int code, string message) : base(message) { Code = code; }
        }
    }
}
