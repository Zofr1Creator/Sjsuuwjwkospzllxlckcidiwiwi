using System;
using System.Collections.Generic;
using System.Linq;
using TspServer.RpcServer;

namespace TspServer.RpcServer.Api
{

    internal static class SocialEventDelivery
    {
       private sealed class PendingDelivery
        {
            public DateTime CreatedUtc;
           public string Domain;
            public string EventName;
            public Action Replay;
       }

        private static readonly object PendingLock = new();
       private static readonly Dictionary<string, List<PendingDelivery>> Pending =
            new Dictionary<string, List<PendingDelivery>>(StringComparer.Ordinal);
        private static readonly TimeSpan PendingTtl = TimeSpan.FromMinutes(5);
        private const int MaxPendingPerPlayer = 128;

       public static int Send<TSender>(
            string playerId,
            string domain,
            string eventName,
            object[] parameters)
            where TSender : class, IEventSender
        {
            object[] stableParameters = parameters ?? Array.Empty<object>();
            return SendInternal<TSender>(playerId, domain, eventName, stableParameters, true);
        }

        private static int SendInternal<TSender>(
            string playerId,
            string domain,
            string eventName,
           object[] parameters,
            bool queueIfMissing)
            where TSender : class, IEventSender
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return 0;

            var senders = ServerState.GetLiveEventSenders<TSender>(playerId);
           int delivered = 0;
            foreach (TSender sender in senders)
            {
                try
                {
                    sender.SendEvent(eventName, parameters ?? Array.Empty<object>());
                    delivered++;
                }
                catch (System.Exception)
                {
                }
            }

            if (delivered == 0 && queueIfMissing && ServerState.HasAnyConnection(playerId))
           {
               object[] captured = parameters ?? Array.Empty<object>();
                Enqueue(playerId, domain, eventName,
                    () => SendInternal<TSender>(playerId, domain, eventName, captured, false));
            }

            return delivered;
        }

        public static int SendRaw<TSender>(
            string playerId,
            string domain,
            string eventName,
            byte[] payload,
            Action<TSender, string, byte[]> sendRaw)
            where TSender : class, IEventSender
        {
            if (string.IsNullOrWhiteSpace(playerId) || sendRaw == null)
                return 0;

            byte[] stablePayload = payload ?? Array.Empty<byte>();
            var senders = ServerState.GetLiveEventSenders<TSender>(playerId);
            int delivered = 0;
            foreach (TSender sender in senders)
            {
                try
                {
                    sendRaw(sender, eventName, stablePayload);
                    delivered++;
                }
                catch (System.Exception)
                {
                }
             }

            if (delivered == 0 && ServerState.HasAnyConnection(playerId))
            {
               Enqueue(playerId, domain, eventName, () =>
                {
                    var replaySenders = ServerState.GetLiveEventSenders<TSender>(playerId);
                    foreach (TSender sender in replaySenders)
                    {
                        try { sendRaw(sender, eventName, stablePayload); }
                       catch { }
                    }
               });
             }

            return delivered;
       }

        private static void Enqueue(string playerId, string domain, string eventName, Action replay)
         {
            if (replay == null) return;
            lock (PendingLock)
            {
                DateTime cutoff = DateTime.UtcNow - PendingTtl;
               if (!Pending.TryGetValue(playerId, out List<PendingDelivery> list) || list == null)
                 {
                    list = new List<PendingDelivery>();
                    Pending[playerId] = list;
                }
                list.RemoveAll(x => x == null || x.CreatedUtc < cutoff);
                list.Add(new PendingDelivery
                {
                    CreatedUtc = DateTime.UtcNow,
                    Domain = domain ?? string.Empty,
                    EventName = eventName ?? string.Empty,
                    Replay = replay
                 });
                if (list.Count > MaxPendingPerPlayer)
                    list.RemoveRange(0, list.Count - MaxPendingPerPlayer);
            }
        }

        public static int ReplayPending(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return 0;
            List<PendingDelivery> replay;
            lock (PendingLock)
            {
                if (!Pending.TryGetValue(playerId, out List<PendingDelivery> list) || list == null || list.Count == 0)
                    return 0;
                 DateTime cutoff = DateTime.UtcNow - PendingTtl;
                replay = list.Where(x => x != null && x.CreatedUtc >= cutoff).ToList();
                Pending.Remove(playerId);
            }

            int count = 0;
            foreach (PendingDelivery item in replay)
            {
                try { item.Replay?.Invoke(); count++; }
                catch (System.Exception)
                {
                }
            }
             return count;
        }
     }
}
