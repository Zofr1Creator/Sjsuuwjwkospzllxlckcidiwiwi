using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class LobbyInviteRuntimeDocument
    {
        [BsonId] 
        public ObjectId Id { get; set; }

        public string PlayerId { get; set; }

        public string LobbyId { get; set; }

        public string InviteSenderId { get; set; }

        public int PlayerType { get; set; }

        public long Date { get; set; }
    }

    public static class LobbyInviteRuntimeStore
    {
        private const string DbName = "Main";

        private const string CollectionName = "lobby_invites";

        private static readonly object Sync = new();

        private static bool _indexReady;

        private static IMongoDatabase Db()
        {
            object provider = BoltMainDatabaseProvider.Instance;
            for (Type type = provider?.GetType(); type != null; type = type.BaseType)
            {
                FieldInfo field = type.GetField("_client", BindingFlags.Instance | BindingFlags.NonPublic);
                if (field?.GetValue(provider) is MongoClient client)
                    return client.GetDatabase(DbName);
            }
            throw new InvalidOperationException("Mongo client not found for lobby invite store");
        }

        private static IMongoCollection<LobbyInviteRuntimeDocument> Collection()
        {
            var collection = Db().GetCollection<LobbyInviteRuntimeDocument>(CollectionName);
            if (!_indexReady)
            {
               lock (Sync)
                {
                    if (!_indexReady)
                    {
                        try
                        {
                            collection.Indexes.CreateOne(new CreateIndexModel<LobbyInviteRuntimeDocument>(
                                Builders<LobbyInviteRuntimeDocument>.IndexKeys
                                    .Ascending(x => x.PlayerId)
                                    .Ascending(x => x.LobbyId),
                                new CreateIndexOptions { Name = "uniq_lobby_invite_player_lobby", Unique = true }));
                         }
                        catch (System.Exception)
                         {
                        }
                        _indexReady = true;
                    }
                }
            }
            return collection;
        }

        public static LobbyInvite Save(string playerId, string lobbyId, string creatorId, LobbyPlayerType playerType)
        {
            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var filter = Builders<LobbyInviteRuntimeDocument>.Filter.Where(x => x.PlayerId == playerId && x.LobbyId == lobbyId);
            var update = Builders<LobbyInviteRuntimeDocument>.Update
                .Set(x => x.InviteSenderId, creatorId)
                .Set(x => x.PlayerType, (int)playerType)
                .Set(x => x.Date, now);
            Collection().UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
            return Build(lobbyId, creatorId, playerType, now, playerId);
        }

        public static LobbyInvite[] GetForPlayer(string playerId)
         {
             var docs = Collection().Find(x => x.PlayerId == playerId).SortByDescending(x => x.Date).ToList();
            var result = new List<LobbyInvite>();
            foreach (var doc in docs)
            {
                if (!ServerState.Lobbies.ContainsKey(doc.LobbyId))
                 {
                    Collection().DeleteOne(x => x.Id == doc.Id);
                    continue;
                }
                result.Add(Build(doc.LobbyId, doc.InviteSenderId, (LobbyPlayerType)doc.PlayerType, doc.Date, playerId));
            }
            return result.ToArray();
        }

        public static void Remove(string playerId, string lobbyId)
        {
            Collection().DeleteMany(x => x.PlayerId == playerId && x.LobbyId == lobbyId);
        }

        public static void RemoveAllForLobby(string lobbyId)
       {
            Collection().DeleteMany(x => x.LobbyId == lobbyId);
        }

        private static LobbyInvite Build(string lobbyId, string creatorId, LobbyPlayerType playerType, long date, string viewerId)
        {
            PlayerFriend creator;
            try
            {
               ObjectId oid;
                var document = ObjectId.TryParse(creatorId, out oid)
                    ? BoltMainDatabaseProvider.Instance.GetPlayerDocument(oid)
                    : null;
                creator = document?.GetPlayerFriend(viewerId) ?? new PlayerFriend
                {
                    Player = new Player { Id = creatorId ?? string.Empty, Name = "Player" },
                     RelationshipStatus = RelationshipStatus.None
                };
            }
            catch
            {
                creator = new PlayerFriend
                {
                    Player = new Player { Id = creatorId ?? string.Empty, Name = "Player" },
                    RelationshipStatus = RelationshipStatus.None
                };
            }

            return new LobbyInvite
            {
                LobbyId = lobbyId ?? string.Empty,
                InviteSender = creator,
                Date = date,
                PlayerType = playerType
            };
        }
    }
}
