using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer.Api
{

    public static class BoltEvents
    {
        private static readonly ConcurrentDictionary<string, ConcurrentDictionary<ClientSession, byte>> Subs
            = new ConcurrentDictionary<string, ConcurrentDictionary<ClientSession, byte>>(StringComparer.Ordinal);

        public static void Subscribe(string topic, ClientSession user)
        {
            if (string.IsNullOrWhiteSpace(topic) || user == null) 
                return;
            Subs.GetOrAdd(topic, _ => new ConcurrentDictionary<ClientSession, byte>())[user] = 1;
       }

       public static void Unsubscribe(string topic, ClientSession user)
        {
            if (string.IsNullOrWhiteSpace(topic) || user == null) return;

            if (Subs.TryGetValue(topic, out ConcurrentDictionary<ClientSession, byte> set))
            {
                set.TryRemove(user, out _);
                if (set.IsEmpty) Subs.TryRemove(topic, out _);
            }
        }

        public static void RemoveUser(ClientSession user)
        {
            if (user == null) return;
            foreach (KeyValuePair<string, ConcurrentDictionary<ClientSession, byte>> pair in Subs.ToArray())
            {
                pair.Value.TryRemove(user, out _);

                if (pair.Value.IsEmpty) Subs.TryRemove(pair.Key, out _);
            }
        }

        public static ClientSession[] Subscribers(string topic)
        {
            if (string.IsNullOrWhiteSpace(topic)) return Array.Empty<ClientSession>();
            return Subs.TryGetValue(topic, out ConcurrentDictionary<ClientSession, byte> set)
             ? set.Keys.ToArray()
                : Array.Empty<ClientSession>();
       }

        public static int Publish(string topic, string listenerName, string eventName, params object[] parameters)
        {
            return PublishMany(new[] { topic }, listenerName, eventName, parameters);
        }

        public static int PublishMany(IEnumerable<string> topics, string listenerName, string eventName, params object[] parameters)
        {
           if (topics == null) return 0;
            var recipients = new HashSet<ClientSession>();
           foreach (string topic in topics.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal))
            {
                foreach (ClientSession user in Subscribers(topic))
                     recipients.Add(user);
            }

            int delivered = 0;
            foreach (ClientSession user in recipients)
            {
               if (SendDirect(user, listenerName, eventName, parameters)) delivered++;
            }

            return delivered;
        }

        public static bool SendDirect(ClientSession user, string listenerName, string eventName, params object[] parameters)
        {
            if (user == null || string.IsNullOrWhiteSpace(listenerName) || string.IsNullOrWhiteSpace(eventName)) return false;

            try
           {
                EventResponse eventResponse;
                if (BoltEventContract.TryResolve(listenerName, eventName, out _))
                {
                     eventResponse = BoltEventContract.Create(
                        listenerName,
                        eventName,
                         parameters ?? Array.Empty<object>());
                }
                else
                {
                    eventResponse = new EventResponse
                    {
                        ListenerName = listenerName,
                        EventName = eventName
                    };
                    if (parameters != null)
                    {
                        foreach (object value in parameters)
                        {
                            eventResponse.Params.Add(value == null
                                ? new BinaryValue { IsNull = true }
                                : RpcTypeCodec.CreateToByteMethod(value.GetType()).ToBytes(value));
                        }
                    }
               }

               user.SendResponse(new ResponseMessage { EventResponse = eventResponse });
               return true;
            }
            catch (System.Exception)
           {
                RemoveUser(user);
                return false;
            }
        }

        public static void Publish(string topic, string eventName)
        {
            Publish(topic, topic, eventName, Array.Empty<object>());
        }
    }
}
