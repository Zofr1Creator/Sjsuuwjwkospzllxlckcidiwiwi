using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{
    public class InventoryRemoteService : RpcHandler
    {
        private static readonly object InventoryPurchaseSync = new();
        public InventoryRemoteService(ClientSession user) : base(user) { }

        protected void GetInventoryItemDefinitions(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                List<BoltInventoryItemDefinitionDocument> definitions = boltGame.GetAllItemDefinitionsByType(0);
                InventoryItemDefinition[] inventoryItemPropertyDefinitions = NormalizeShopPrices(definitions.Select(a => a.ToInventoryItemDefinition()));
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(InventoryItemDefinition[])).ToBytes(inventoryItemPropertyDefinitions) } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        protected void GetInventoryItemPropertyDefinitions(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                List<BoltInventoryItemPropertyDefinitionsDocument> definitions = boltGame.GetAllItemPropertyDefinitions();
                InventoryItemPropertyDefinitions[] inventoryItemPropertyDefinitions = definitions.Select(a => a.GetInventoryItemPropertyDefinitions()).ToArray();
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(InventoryItemPropertyDefinitions[])).ToBytes(inventoryItemPropertyDefinitions) } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        protected void GetPlayerInventoryV2(string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 401
                        }
                    }
                });
                return;
            }

            try
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                ObjectId playerObjectId = ObjectId.Parse(Id);
                PlayerInventoryDocument playerInventoryDocument;

                try
                {
                    playerInventoryDocument = boltGame.GetPlayerInventoryDocument(playerObjectId);
                }
                catch (System.Exception)
                {
                    boltGame.CreatePlayerInventory(playerObjectId);
                    playerInventoryDocument = boltGame.GetPlayerInventoryDocument(playerObjectId);
                }
                playerInventoryDocument = ProfileFrameRuntime.RepairEarnedLevelFrames(Id) ?? playerInventoryDocument;

                int statTrackRecovered = StatTrackBridge.RepairOwnedInventoryForPlayer(Id);
                if (statTrackRecovered > 0)
                {
                    playerInventoryDocument = boltGame.GetPlayerInventoryDocument(playerObjectId);
                }

                PlayerInventory playerInventory =
                     playerInventoryDocument?.GetPlayerInventoryProto() ?? new PlayerInventory();
                byte[] playerInventoryBytes = playerInventory.ToByteArray();
                byte[] responseBytes;
                using (MemoryStream stream = new MemoryStream())
                {
                    CodedOutputStream output = new CodedOutputStream(stream);
                    output.WriteTag(1, WireFormat.WireType.LengthDelimited);
                    output.WriteBytes(ByteString.CopyFrom(playerInventoryBytes));
                    output.Flush();
                    responseBytes = stream.ToArray();
                }
                byte[] sessionKey = _session.GetSessionKey();
                byte[] sessionIv = _session.GetSessionIv();
                if (sessionKey == null || sessionKey.Length != 16 ||
                    sessionIv == null || sessionIv.Length != 16)
                {
                    throw new InvalidOperationException(
                         "inventory aes not ready");
                }

                byte[] encryptedResponseBytes = Protocol.EncryptAesCbc(
                    responseBytes, sessionKey, sessionIv);

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(encryptedResponseBytes)
                        }
                    }
                });
            }
            catch (System.Exception)
            {
                byte[] fallbackPlain = new byte[] { 0x0A, 0x00 };
                byte[] fallbackCipher;
                try
                {
                    fallbackCipher = Protocol.EncryptAesCbc(
                        fallbackPlain, _session.GetSessionKey(), _session.GetSessionIv());
                }
                catch (System.Exception)
                {

                    _session.SendResponse(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 500,
                                Property = { ["reason"] = "INVENTORY_ENCRYPTION_NOT_READY" }
                            }
                        }
                    });
                    return;
                }

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(fallbackCipher)
                        }
                    }
                });
            }
        }

        protected void GetPlayerInventory(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                PlayerInventoryDocument playerInventoryDocument = null;
                try
                {
                    playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(Id));
                }
                catch (System.Exception)
                {
                    boltGame.CreatePlayerInventory(ObjectId.Parse(Id));
                    playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(Id));
                }
                playerInventoryDocument = ProfileFrameRuntime.RepairEarnedLevelFrames(Id) ?? playerInventoryDocument;
                PlayerInventory playerInventory = playerInventoryDocument.GetPlayerInventoryProto();
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(PlayerInventory)).ToBytes(playerInventory) } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        protected void GetPlayerInventory(string playerId, int[] itemDefinitionIds, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                PlayerInventoryDocument playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(playerId));
                InventoryItem[] items = playerInventoryDocument.GetInventoryItemsProto(itemDefinitionIds);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(InventoryItem[])).ToBytes(items) } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        protected void ExchangeInventoryItems(RpcRequest request, bool wrapExecuteResponse = false)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            if (request.Params == null || request.Params.Count < 3)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            try
            {
                string recipeCode = (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]);
                int[] inventoryIds = (int[])new RpcValueReader(typeof(int[])).FromBytes(request.Params[2]);

                int recipeId = RecipeId(recipeCode);
                if (recipeId <= 0 || inventoryIds == null || inventoryIds.Length == 0)
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
                BoltInventoryItemDefinitionDocument recipe =
                    database.GetInventoryItemDefinition(recipeId, 1);

                if (recipe?.properties == null || !recipe.enabled)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                List<int> candidates = DefinitionIds(recipe.properties, "containsIds", "contains");
                if (candidates.Count == 0)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                var enabled = new List<int>();
                foreach (int definitionId in candidates)
                {
                    BoltInventoryItemDefinitionDocument definition =
                        database.GetInventoryItemDefinition(definitionId, 1);

                    if (definition != null && definition.enabled)
                        enabled.Add(definitionId);
                }

                int rewardDefinitionId = PickReward(recipe, enabled);
                if (rewardDefinitionId <= 0)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                PlayerInventoryDocument inventory =
                    database.GetPlayerInventoryDocument(playerObjectId);

                int consumedInventoryId = inventoryIds[0];
                string consumedKey = consumedInventoryId.ToString();

                if (inventory?.InventoryItems == null ||
                    !inventory.InventoryItems.TryGetValue(consumedKey, out BsonValue rawItem) ||
                    !rawItem.IsBsonDocument)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                BsonDocument consumedDocument = rawItem.AsBsonDocument;
                int quantity = Math.Max(1, consumedDocument.GetValue("quantity", 1).ToInt32());
                BoltInventoryItem consumed = new BsonElement(consumedKey, consumedDocument).ToBoltInventory();

                int rewardInventoryId = NextItemId(inventory.InventoryItems);
                var reward = new BoltInventoryItem
                {
                    itemDefinitionId = rewardDefinitionId,
                    quantity = 1,
                    flags = 0,
                    date = (BsonDateTime)DateTime.UtcNow
                };

                if (!database.TryBeginInventoryMutation(
                        playerId, "exchangeInventoryItems", request.Id, out string mutationKey))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                bool removed = quantity <= 1;
                try
                {
                    if (removed)
                        database.RemoveItemToPlayerInventoryDocument(playerObjectId, consumedInventoryId);
                    else
                        database.SetPlayerInventoryItemQuantity(
                            playerObjectId, consumedInventoryId, quantity - 1);

                    database.AddItemToPlayerInventoryDocument(
                        playerObjectId, reward, rewardInventoryId);
                }
                catch
                {
                    try
                    {
                        if (removed)
                            database.AddItemToPlayerInventoryDocument(
                                playerObjectId, consumed, consumedInventoryId);
                        else
                            database.SetPlayerInventoryItemQuantity(
                                playerObjectId, consumedInventoryId, quantity);

                        database.RemoveItemToPlayerInventoryDocument(
                            playerObjectId, rewardInventoryId);
                    }
                    catch
                    {
                    }

                    database.AbortInventoryMutation(mutationKey);
                    throw;
                }

                database.CompleteInventoryMutation(mutationKey);

                var result = new ExchangeResult();
                result.InventoryItems.Add(reward.ToInventory(rewardInventoryId));

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Return = SerializeRecipeResult(result, wrapExecuteResponse)
                    }
                });

                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: result.InventoryItems,
                    source: "exchange-item",
                    preferredUser: _session);
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private static int RecipeId(string recipeCode)
        {
            if (string.IsNullOrWhiteSpace(recipeCode))
                return 0;

            const string prefix = "RECIPE_";
            const string v2Prefix = "RECIPE_V2_";

            string code = recipeCode.Trim();
            if (code.StartsWith(v2Prefix, StringComparison.OrdinalIgnoreCase))
                code = prefix + code.Substring(v2Prefix.Length);

            if (!code.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                return 0;

            return int.TryParse(
                code.Substring(prefix.Length),
                System.Globalization.NumberStyles.None,
                System.Globalization.CultureInfo.InvariantCulture,
                out int recipeId)
                ? recipeId
                : 0;
        }

        private static BinaryValue SerializeRecipeResult(ExchangeResult exchangeResult, bool wrapExecuteResponse)
        {
            BinaryValue raw = new RpcValueWriter(typeof(ExchangeResult)).ToBytes(exchangeResult);
            if (!wrapExecuteResponse)
                return raw;

            byte[] payload = raw.One?.ToByteArray() ?? Array.Empty<byte>();
            using (var ms = new System.IO.MemoryStream())
            {
                ms.WriteByte(0x0A);
                WriteVarUInt32(ms, (uint)payload.Length);
                ms.Write(payload, 0, payload.Length);
                return new BinaryValue
                {
                    IsNull = false,
                    One = Google.Protobuf.ByteString.CopyFrom(ms.ToArray())
                };
            }
        }

        private static void WriteVarUInt32(System.IO.Stream stream, uint value)
        {
            while (value >= 0x80)
            {
                stream.WriteByte((byte)(value | 0x80));
                value >>= 7;
            }
            stream.WriteByte((byte)value);
        }

        private void GetRecipeStatus(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out _))
                return;

            byte[] responseBytes = { 0x08, 0x01, 0x10, 0x01 };
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.CopyFrom(responseBytes)
                    }
                }
            });
        }

        private void ExecuteRecipe(RpcRequest request)
        {
            ExchangeInventoryItems(request, false);
        }

        protected void BuyInventoryItem(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            double spent = 0d;
            int spentCurrencyId = 0;
            var createdIds = new List<int>();
            try
            {
                int itemDefinitionId = (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[0]);
                int quantity = (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[1]);
                int requestedCurrencyId = (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[2]);
                bool toManyItems = (bool)new RpcValueReader(typeof(bool)).FromBytes(request.Params[3]);
                if (itemDefinitionId <= 0 || quantity <= 0 || quantity > 100)
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                BoltInventoryItemDefinitionDocument definition = database.GetInventoryItemDefinition(itemDefinitionId, 1);
                if (definition == null || !definition.enabled ||
                    !TryGetBuyPrice(definition, requestedCurrencyId, out int currencyId, out double unitPrice) ||
                    unitPrice < 0 || double.IsNaN(unitPrice) || double.IsInfinity(unitPrice))
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                double totalPrice = checked(unitPrice * quantity);
                if (totalPrice > 0 && !database.TryDebitCurrencyAtomic(playerObjectId, currencyId, totalPrice))
                {
                    ContractWire.SendException(_session, request.Id, 402);
                    return;
                }
                spent = totalPrice;
                spentCurrencyId = currencyId;

                var inventoryItems = new List<InventoryItem>();
                int records = toManyItems ? quantity : 1;
                int quantityPerRecord = toManyItems ? 1 : quantity;
                for (int index = 0; index < records; index++)
                {
                    var stored = new BoltInventoryItem
                    {
                        itemDefinitionId = itemDefinitionId,
                        date = (BsonDateTime)DateTime.UtcNow,
                        flags = 0,
                        quantity = quantityPerRecord
                    };
                    int inventoryId = database.AddItemToPlayerInventoryDocumentAtomic(playerObjectId, stored);
                    createdIds.Add(inventoryId);
                    inventoryItems.Add(stored.ToInventory(inventoryId));
                }

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Return = new RpcValueWriter(typeof(InventoryItem[])).ToBytes(inventoryItems.ToArray())
                    }
                });
            }
            catch (OverflowException)
            {
                foreach (int id in createdIds) { try { database.RemoveItemToPlayerInventoryDocument(playerObjectId, id); } catch { } }
                if (spent > 0) { try { database.RefundCurrencyAtomic(playerObjectId, spentCurrencyId, spent); } catch { } }
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch (System.Exception)
            {
                foreach (int id in createdIds) { try { database.RemoveItemToPlayerInventoryDocument(playerObjectId, id); } catch { } }
                if (spent > 0) { try { database.RefundCurrencyAtomic(playerObjectId, spentCurrencyId, spent); } catch { } }
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        protected void SetInventoryItemFlags(RpcRequest request)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
                ItemFlags itemFlags = (ItemFlags)new RpcValueReader(typeof(ItemFlags)).FromBytes(request.Params[0]);
                foreach (KeyValuePair<int, int> keyValuePair in itemFlags.Flags) boltGameDatabaseProvider.SetItemFlag(ObjectId.Parse(Id), keyValuePair.Key, keyValuePair.Value);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                return;
            }
            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        private List<InventoryItem> ApplyProperties(
             string playerId,
             IEnumerable<InventoryItemProperties> updates)
        {
            var changedIds = new HashSet<int>();
            var provider = BoltGameDatabaseProvider.Instance;
            ObjectId playerObjectId = ObjectId.Parse(playerId);
            PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);

            foreach (InventoryItemProperties update in updates ?? Array.Empty<InventoryItemProperties>())
            {
                string itemKey = update?.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) ?? string.Empty;
                if (update == null || inventory?.InventoryItems == null ||
                    !inventory.InventoryItems.TryGetValue(itemKey, out BsonValue ownedRaw) || !ownedRaw.IsBsonDocument)
                {
                    continue;
                }

                foreach (KeyValuePair<string, InventoryItemProperty> pair in update.Properties)
                {
                    if (pair.Value == null || string.IsNullOrWhiteSpace(pair.Key)) continue;
                    BoltInventoryItemProperty.PropertyType type = (BoltInventoryItemProperty.PropertyType)pair.Value.Type;
                    string value;
                    switch (pair.Value.Type)
                    {
                        case PropertyType.Int: value = pair.Value.IntValue.ToString(System.Globalization.CultureInfo.InvariantCulture); break;
                        case PropertyType.Float: value = pair.Value.FloatValue.ToString(System.Globalization.CultureInfo.InvariantCulture); break;
                        case PropertyType.String: value = pair.Value.StringValue ?? string.Empty; break;
                        case PropertyType.Boolean: value = pair.Value.BooleanValue.ToString(); break;
                        default: value = pair.Value.IntValue.ToString(System.Globalization.CultureInfo.InvariantCulture); type = BoltInventoryItemProperty.PropertyType.Int; break;
                    }

                    if (string.Equals(pair.Key, "stattrack_value", StringComparison.Ordinal))
                    {
                        int requested = Math.Max(0, pair.Value.IntValue);
                        int current = 0;
                        try
                        {
                            BsonDocument itemDoc = ownedRaw.AsBsonDocument;
                            if (itemDoc.TryGetValue("properties", out BsonValue propsValue) && propsValue.IsBsonDocument)
                            {
                                BsonDocument props = propsValue.AsBsonDocument;
                                if (props.TryGetValue("stattrack_value", out BsonValue oldValue))
                                    current = oldValue.IsInt32 ? Math.Max(0, oldValue.AsInt32) : Math.Max(0, Convert.ToInt32(oldValue.ToString()));
                                else if (props.TryGetValue("stattrack_property", out BsonValue legacyValue))
                                    current = legacyValue.IsInt32 ? Math.Max(0, legacyValue.AsInt32) : Math.Max(0, Convert.ToInt32(legacyValue.ToString()));
                            }
                        }
                        catch { }

                        int next = Math.Max(current, requested);
                        value = next.ToString(System.Globalization.CultureInfo.InvariantCulture);
                        type = BoltInventoryItemProperty.PropertyType.Int;
                        try { provider.RemoveItemProperty(playerObjectId, update.Id, "stattrack_property"); } catch { }
                    }

                    provider.SetItemProperty(playerObjectId, update.Id, new BoltInventoryItemProperty
                    {
                        Name = pair.Key,
                        Type = type,
                        Value = value
                    });
                    changedIds.Add(update.Id);
                }
            }

            var changed = new List<InventoryItem>();
            PlayerInventoryDocument refreshed = provider.GetPlayerInventoryDocument(playerObjectId);
            foreach (int inventoryId in changedIds)
            {
                string key = inventoryId.ToString(System.Globalization.CultureInfo.InvariantCulture);
                if (refreshed?.InventoryItems != null &&
                    refreshed.InventoryItems.TryGetValue(key, out BsonValue raw) && raw.IsBsonDocument)
                    changed.Add(new BsonElement(key, raw.AsBsonDocument).ToInventory());
            }
            return changed;
        }

        protected void SetInventoryItemsProperties(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
                return;
            }

            try
            {
                InventoryItemProperties[] updates = request.Params.Count > 0
                    ? (InventoryItemProperties[])new RpcValueReader(typeof(InventoryItemProperties[])).FromBytes(request.Params[0])
                    : Array.Empty<InventoryItemProperties>();
                List<InventoryItem> changed = ApplyProperties(playerId, updates);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                if (changed.Count > 0)
                    InventoryEventBus.InventoryChanged(playerId, changed: changed, source: "set-properties");
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
            }
        }

        private void SetModificationsEncrypted(RpcRequest request)
        {
            SetModifications(request, "setItemsModificationsEncrypted");
        }

        private void SetPropertiesEncrypted(RpcRequest request)
        {
            SetModifications(request, "setInventoryItemsPropertiesEncrypted");
        }

        private void SetModifications(RpcRequest request, string methodName)
        {
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
                {
                    ContractWire.SendException(_session, request.Id, 401);
                    return;
                }

                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, methodName);
                var updates = new List<InventoryItemProperties>();
                var reader = new ContractWire.Reader(plainRequest);
                while (reader.TryReadField(out int field, out int wire))
                {
                    if (field == 1 && wire == 2)
                    {
                        byte[] itemBytes = reader.ReadBytes();
                        if (itemBytes.Length > 0)
                            updates.Add(InventoryItemProperties.Parser.ParseFrom(itemBytes));
                    }
                    else
                    {
                        reader.Skip(wire);
                    }
                }

                List<InventoryItem> changed = ApplyProperties(playerId, updates);

                ContractWire.SendEncrypted(_session, request.Id, Array.Empty<byte>(), methodName);
                if (changed.Count > 0)
                    InventoryEventBus.InventoryChanged(
                        playerId, changed: changed, source: "set-modifications", preferredUser: _session);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private static bool TryGetOwnedItem(
            PlayerInventoryDocument inventory,
            int inventoryId,
            out BoltInventoryItem item)
        {
            item = null;
            if (inventoryId <= 0 || inventory?.InventoryItems == null)
                return false;

            string key = inventoryId.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (!inventory.InventoryItems.TryGetValue(key, out BsonValue raw) || !raw.IsBsonDocument)
                return false;

            item = new BsonElement(key, raw.AsBsonDocument).ToBoltInventory();
            return item != null;
        }

        private static InventoryItem ReadOwnedItem(
            BoltGameDatabaseProvider provider,
            ObjectId playerObjectId,
            int inventoryId)
        {
            PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
            string key = inventoryId.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (inventory?.InventoryItems == null ||
                !inventory.InventoryItems.TryGetValue(key, out BsonValue raw) ||
                 !raw.IsBsonDocument)
                return null;
            return new BsonElement(key, raw.AsBsonDocument).ToInventory();
        }
        private static BoltInventoryItemProperty GetModification(BoltInventoryItem item, string modificationName)
        {
            if (item?.Properties == null || string.IsNullOrWhiteSpace(modificationName))
                return null;
            return item.Properties.FirstOrDefault(x =>
               x != null && string.Equals(x.Name, modificationName, StringComparison.Ordinal));
        }

        private static int GetMountedId(BoltInventoryItemProperty property)
        {
            if (property == null || string.IsNullOrWhiteSpace(property.Value))
                return 0;
            return int.TryParse(
                property.Value,
                System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture,
                out int definitionId)
                ? Math.Max(0, definitionId)
                : 0;
        }

        private static InventoryItem CreateUnmountedItem(
            BoltGameDatabaseProvider provider,
            ObjectId playerObjectId,
            PlayerInventoryDocument inventory,
            int itemDefinitionId)
        {
            if (itemDefinitionId <= 0)
                return null;

            inventory.InventoryItems ??= new BsonDocument();
            int inventoryId = NextItemId(inventory.InventoryItems);
            var restored = new BoltInventoryItem
            {
                id = inventoryId,
                itemDefinitionId = itemDefinitionId,
                quantity = 1,
                flags = 0,
                date = new BsonDateTime(DateTime.UtcNow),
                Properties = new List<BoltInventoryItemProperty>()
            };
            provider.AddItemToPlayerInventoryDocument(playerObjectId, restored, inventoryId);

            inventory.InventoryItems[inventoryId.ToString(System.Globalization.CultureInfo.InvariantCulture)] =
                restored.GetBsonElements();
            return restored.ToInventory(inventoryId);
        }

        private void MountEncrypted(RpcRequest request)
        {
            const string methodName = "mountInventoryItemEncrypted";
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId) ||
                    !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                {
                    ContractWire.SendException(_session, request.Id, 401);
                    return;
                }

                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, methodName);
                int consumedItemId = ContractWire.ReadIntField(plainRequest, 1, 0);
                int modifiedItemId = ContractWire.ReadIntField(plainRequest, 2, 0);
                string modificationName = ContractWire.ReadStringField(plainRequest, 3, string.Empty).Trim();
                if (consumedItemId <= 0 || modifiedItemId <= 0 ||
                      consumedItemId == modifiedItemId || string.IsNullOrWhiteSpace(modificationName))
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem modifiedItem;
                InventoryItem unmountedItem = null;
                InventoryItem consumedDelta;
                int mountedDefinitionId;
                int previousDefinitionId;

                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    if (!TryGetOwnedItem(inventory, consumedItemId, out BoltInventoryItem consumed) ||
                        !TryGetOwnedItem(inventory, modifiedItemId, out BoltInventoryItem modified))
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    mountedDefinitionId = consumed.itemDefinitionId;
                    if (mountedDefinitionId <= 0 || consumed.quantity <= 0)
                    {
                        ContractWire.SendException(_session, request.Id, 409);
                        return;
                    }

                    BoltInventoryItemProperty existing = GetModification(modified, modificationName);
                    previousDefinitionId = GetMountedId(existing);

                    if (previousDefinitionId > 0 && previousDefinitionId != mountedDefinitionId)
                    {
                        unmountedItem = CreateUnmountedItem(
                            provider, playerObjectId, inventory, previousDefinitionId);
                    }

                    bool alreadyMounted = previousDefinitionId == mountedDefinitionId && previousDefinitionId > 0;
                    if (!alreadyMounted)
                    {
                        provider.SetItemProperty(playerObjectId, modifiedItemId, new BoltInventoryItemProperty
                        {
                            Name = modificationName,
                            Type = BoltInventoryItemProperty.PropertyType.Int,
                            Value = mountedDefinitionId.ToString(System.Globalization.CultureInfo.InvariantCulture)
                        });

                        int quantityBefore = Math.Max(1, consumed.quantity);
                        consumedDelta = consumed.ToInventory(consumedItemId);
                        if (quantityBefore <= 1)
                        {
                            provider.RemoveItemToPlayerInventoryDocument(playerObjectId, consumedItemId);
                            consumedDelta.Quantity = 0;
                        }
                        else
                        {
                            provider.SetPlayerInventoryItemQuantity(
                                 playerObjectId, consumedItemId, quantityBefore - 1);
                            consumedDelta.Quantity = quantityBefore - 1;
                        }
                    }
                    else
                    {
                        consumedDelta = null;
                    }

                    modifiedItem = ReadOwnedItem(provider, playerObjectId, modifiedItemId);
                    if (modifiedItem == null)
                        throw new InvalidOperationException("item missing after mount");
                }

                byte[] plainResponse = ContractWire.Build(w =>
                {
                    w.Message(1, modifiedItem);
                    if (unmountedItem != null) w.Message(2, unmountedItem);
                });
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, methodName);

                var changed = new List<InventoryItem> { modifiedItem };
                if (consumedDelta != null) changed.Add(consumedDelta);
                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: unmountedItem == null ? null : new[] { unmountedItem },
                    changed: changed,
                    source: "mount-modification",
                   preferredUser: _session);
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }
        private void UnmountEncrypted(RpcRequest request)
        {
            const string methodName = "unmountInventoryItemEncrypted";
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId) ||
                     !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                {
                    ContractWire.SendException(_session, request.Id, 401);
                    return;
                }

                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, methodName);
                int modifiedItemId = ContractWire.ReadIntField(plainRequest, 1, 0);
                string modificationName = ContractWire.ReadStringField(plainRequest, 2, string.Empty).Trim();
                if (modifiedItemId <= 0 || string.IsNullOrWhiteSpace(modificationName))
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem unmountedItem;
                InventoryItem modifiedItem;
                int previousDefinitionId;
                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    if (!TryGetOwnedItem(inventory, modifiedItemId, out BoltInventoryItem modified))
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    BoltInventoryItemProperty existing = GetModification(modified, modificationName);
                    previousDefinitionId = GetMountedId(existing);
                    if (previousDefinitionId <= 0)
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    provider.RemoveItemProperty(playerObjectId, modifiedItemId, modificationName);
                    try
                    {
                        unmountedItem = CreateUnmountedItem(
                            provider, playerObjectId, inventory, previousDefinitionId);
                    }
                    catch
                    {
                        provider.SetItemProperty(playerObjectId, modifiedItemId, new BoltInventoryItemProperty
                        {
                            Name = modificationName,
                            Type = BoltInventoryItemProperty.PropertyType.Int,
                            Value = previousDefinitionId.ToString(System.Globalization.CultureInfo.InvariantCulture)
                        });
                        throw;
                    }

                    modifiedItem = ReadOwnedItem(provider, playerObjectId, modifiedItemId);
                    if (modifiedItem == null)
                        throw new InvalidOperationException("item missing after unmount");
                }

                byte[] plainResponse = ContractWire.Build(w => w.Message(1, unmountedItem));
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, methodName);
                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: new[] { unmountedItem },
                    changed: new[] { modifiedItem },
                    source: "unmount-modification",
                    preferredUser: _session);
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void RemoveModificationEncrypted(RpcRequest request)
        {
            const string methodName = "removeItemModificationEncrypted";
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId) ||
                    !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                {
                    ContractWire.SendException(_session, request.Id, 401);
                    return;
                }

                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, methodName);
                byte[] requestBody = plainRequest;

                int modifiedItemId = ContractWire.ReadIntField(requestBody, 1, 0);
                string modificationName =
                    ContractWire.ReadStringField(requestBody, 2, string.Empty).Trim();

                if (modifiedItemId <= 0 || string.IsNullOrWhiteSpace(modificationName))
                {
                    try
                    {
                        var outer = new ContractWire.Reader(plainRequest);
                        while (outer.TryReadField(out int outerField, out int outerWire))
                        {
                            if (outerWire == 2)
                            {
                                byte[] nested = outer.ReadBytes();
                                if (nested.Length == 0)
                                    continue;

                                int nestedId = ContractWire.ReadIntField(nested, 1, 0);
                                string nestedName =
                                    ContractWire.ReadStringField(nested, 2, string.Empty).Trim();

                                if (nestedId > 0)
                                {
                                    requestBody = nested;
                                    modifiedItemId = nestedId;
                                    modificationName = nestedName;
                                    break;
                                }
                            }
                            else
                            {
                                outer.Skip(outerWire);
                            }
                        }
                    }
                    catch
                    {

                    }
                }

                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem unmountedItem;
                InventoryItem modifiedItem;
                int previousDefinitionId;

                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory =
                        provider.GetPlayerInventoryDocument(playerObjectId);

                    if (modifiedItemId <= 0 ||
                        !TryGetOwnedItem(
                            inventory, modifiedItemId, out BoltInventoryItem modified))
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(modificationName) &&
                        modified.Properties != null)
                    {
                        BoltInventoryItemProperty recovered = null;
                        foreach (BoltInventoryItemProperty property in modified.Properties)
                        {
                            if (property == null || string.IsNullOrWhiteSpace(property.Name))
                                continue;

                            int definitionId = GetMountedId(property);
                            if (definitionId <= 0)
                                continue;

                            BoltInventoryItemDefinitionDocument definition =
                               provider.GetInventoryItemDefinition(definitionId, 1);
                            if (definition == null)
                                continue;

                            string recoveredRuntimeClass =
                                 definition.properties?.GetValue(
                                    "runtimeClass", "").ToString() ?? string.Empty;
                            string recoveredClientRuntimeClass =
                                definition.properties?.GetValue(
                                    "clientRuntimeClass", "").ToString() ?? string.Empty;
                            string recoveredClientKind =
                                definition.properties?.GetValue(
                                    "clientKind", "").ToString() ?? string.Empty;

                            bool recoveredIsCharm =
                                recoveredRuntimeClass.IndexOf(
                                    "Charm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                recoveredClientRuntimeClass.IndexOf(
                                    "Charm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                recoveredClientKind.Equals(
                                     "charm", StringComparison.OrdinalIgnoreCase);

                            if (!recoveredIsCharm)
                                continue;
                            if (recovered != null)
                            {

                                recovered = null;
                                break;
                            }

                            recovered = property;
                        }

                        if (recovered != null)
                        {
                            modificationName = recovered.Name;
                        }
                    }

                    if (string.IsNullOrWhiteSpace(modificationName))
                    {
                        ContractWire.SendException(_session, request.Id, 400);
                        return;
                    }

                    BoltInventoryItemProperty existing =
                        GetModification(modified, modificationName);
                    previousDefinitionId = GetMountedId(existing);

                    if (previousDefinitionId <= 0)
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    BoltInventoryItemDefinitionDocument previousDefinition =
                         provider.GetInventoryItemDefinition(previousDefinitionId, 1);
                    string runtimeClass =
                         previousDefinition?.properties?.GetValue(
                             "runtimeClass", "").ToString() ?? string.Empty;
                    string clientRuntimeClass =
                        previousDefinition?.properties?.GetValue(
                             "clientRuntimeClass", "").ToString() ?? string.Empty;
                    string clientKind =
                        previousDefinition?.properties?.GetValue(
                            "clientKind", "").ToString() ?? string.Empty;

                    bool isCharm =
                        runtimeClass.IndexOf(
                            "Charm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        clientRuntimeClass.IndexOf(
                            "Charm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        clientKind.Equals(
                            "charm", StringComparison.OrdinalIgnoreCase);

                    if (!isCharm)
                    {
                        ContractWire.SendException(_session, request.Id, 409);
                        return;
                    }

                    provider.RemoveItemProperty(
                       playerObjectId, modifiedItemId, modificationName);

                    try
                    {
                        unmountedItem = CreateUnmountedItem(
                            provider,
                            playerObjectId,
                            inventory,
                            previousDefinitionId);
                    }
                    catch
                    {
                        provider.SetItemProperty(
                           playerObjectId,
                           modifiedItemId,
                           new BoltInventoryItemProperty
                           {
                               Name = modificationName,
                               Type = BoltInventoryItemProperty.PropertyType.Int,
                               Value = previousDefinitionId.ToString(
                                   System.Globalization.CultureInfo.InvariantCulture)
                           });
                        throw;
                    }

                    modifiedItem =
                        ReadOwnedItem(
                            provider, playerObjectId, modifiedItemId);
                    if (modifiedItem == null || unmountedItem == null)
                        throw new InvalidOperationException(
                            "bad unmount state");
                }

                byte[] plainResponse =
                    ContractWire.Build(w => w.Message(1, unmountedItem));
                ContractWire.SendEncrypted(
                    _session, request.Id, plainResponse, methodName);

                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: new[] { unmountedItem },
                    changed: new[] { modifiedItem },
                    source: "unmount-route58",
                    preferredUser: _session);
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void HandleModification(RpcRequest request)
        {
            const string wireMethod = "inventoryModificationCompatEncrypted033";
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId) ||
                    !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                {
                    ContractWire.SendException(_session, request.Id, 401);
                    return;
                }

                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, wireMethod);
                int field1 = 0;
                int field2Int = 0;
                string field2String = string.Empty;
                string field3String = string.Empty;
                var shape = new ContractWire.Reader(plainRequest);
                while (shape.TryReadField(out int field, out int wire))
                {
                    if (field == 1 && wire == 0) field1 = shape.ReadInt32();
                    else if (field == 2 && wire == 0) field2Int = shape.ReadInt32();
                    else if (field == 2 && wire == 2) field2String = shape.ReadString().Trim();
                    else if (field == 3 && wire == 2) field3String = shape.ReadString().Trim();
                    else shape.Skip(wire);
                }

                if (field1 > 0 && field2Int > 0 && !string.IsNullOrWhiteSpace(field3String))
                {
                    MountPlain(request, playerId, playerObjectId,
                        field1, field2Int, field3String, wireMethod);
                    return;
                }

                if (field1 <= 0 || string.IsNullOrWhiteSpace(field2String))
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem changed = null;
                InventoryItem detached = null;
                bool removed = false;
                bool isCharm = false;

                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    if (!TryGetOwnedItem(inventory, field1, out BoltInventoryItem modified))
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    BoltInventoryItemProperty existing = GetModification(modified, field2String);
                    int mountedDefinitionId = GetMountedId(existing);
                    if (mountedDefinitionId > 0)
                    {
                        BoltInventoryItemDefinitionDocument mountedDefinition =
                            provider.GetInventoryItemDefinition(mountedDefinitionId, 1);
                        string runtimeClass = mountedDefinition?.properties?.GetValue("runtimeClass", "").ToString() ?? string.Empty;
                        string clientRuntimeClass = mountedDefinition?.properties?.GetValue("clientRuntimeClass", "").ToString() ?? string.Empty;
                        isCharm = runtimeClass.IndexOf("Charm", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                 clientRuntimeClass.IndexOf("Charm", StringComparison.OrdinalIgnoreCase) >= 0;
                    }

                    if (existing != null)
                    {
                        provider.RemoveItemProperty(playerObjectId, field1, field2String);
                        removed = true;

                        if (isCharm && mountedDefinitionId > 0)
                            detached = CreateUnmountedItem(provider, playerObjectId, inventory, mountedDefinitionId);
                    }

                    changed = ReadOwnedItem(provider, playerObjectId, field1);
                    if (changed == null)
                        throw new InvalidOperationException("item missing after modification");
                }

                if (isCharm && detached != null)
                {

                    byte[] response = ContractWire.Build(w => w.Message(1, detached));
                    ContractWire.SendEncrypted(_session, request.Id, response, wireMethod);
                    InventoryEventBus.InventoryChanged(playerId,
                        added: new[] { detached }, changed: new[] { changed },
                        source: "unmount-charm", preferredUser: _session);
                }
                else
                {

                    byte[] response = ContractWire.Build(w => w.Message(1, changed));
                    ContractWire.SendEncrypted(_session, request.Id, response, wireMethod);
                    if (removed)
                        InventoryEventBus.InventoryChanged(playerId,
                            changed: new[] { changed }, source: "remove-modification", preferredUser: _session);
                }

            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void MountPlain(
            RpcRequest request, string playerId, ObjectId playerObjectId,
             int consumedItemId, int modifiedItemId, string modificationName, string responseMethod)
        {
            if (consumedItemId <= 0 || modifiedItemId <= 0 || consumedItemId == modifiedItemId ||
                string.IsNullOrWhiteSpace(modificationName))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
            InventoryItem modifiedItem;
            InventoryItem unmountedItem = null;
            InventoryItem consumedDelta;
            int mountedDefinitionId;
            int previousDefinitionId;

            lock (InventoryPurchaseSync)
            {
                PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                if (!TryGetOwnedItem(inventory, consumedItemId, out BoltInventoryItem consumed) ||
                    !TryGetOwnedItem(inventory, modifiedItemId, out BoltInventoryItem modified))
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                mountedDefinitionId = consumed.itemDefinitionId;
                if (mountedDefinitionId <= 0 || consumed.quantity <= 0)
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                BoltInventoryItemProperty existing = GetModification(modified, modificationName);
                previousDefinitionId = GetMountedId(existing);
                if (previousDefinitionId > 0 && previousDefinitionId != mountedDefinitionId)
                    unmountedItem = CreateUnmountedItem(provider, playerObjectId, inventory, previousDefinitionId);

                bool alreadyMounted = previousDefinitionId == mountedDefinitionId && previousDefinitionId > 0;
                consumedDelta = consumed.ToInventory(consumedItemId);
                if (!alreadyMounted)
                {
                    provider.SetItemProperty(playerObjectId, modifiedItemId, new BoltInventoryItemProperty
                    {
                        Name = modificationName,
                        Type = BoltInventoryItemProperty.PropertyType.Int,
                        Value = mountedDefinitionId.ToString(System.Globalization.CultureInfo.InvariantCulture)
                    });

                    int remain = Math.Max(0, consumed.quantity - 1);
                    consumedDelta.Quantity = remain;
                    if (remain == 0) provider.RemoveItemToPlayerInventoryDocument(playerObjectId, consumedItemId);
                    else provider.SetPlayerInventoryItemQuantity(playerObjectId, consumedItemId, remain);
                }

                modifiedItem = ReadOwnedItem(provider, playerObjectId, modifiedItemId);
                if (modifiedItem == null)
                    throw new InvalidOperationException("item missing after mount");
            }

            byte[] response = ContractWire.Build(w =>
            {
                w.Message(1, modifiedItem);
                if (unmountedItem != null) w.Message(2, unmountedItem);
            });
            ContractWire.SendEncrypted(_session, request.Id, response, responseMethod);

            var added = unmountedItem == null ? null : new[] { unmountedItem };
            var changed = new List<InventoryItem> { modifiedItem };
            if (consumedDelta != null) changed.Add(consumedDelta);
            InventoryEventBus.InventoryChanged(playerId, added: added, changed: changed,
                source: "mount-modification", preferredUser: _session);

        }

        protected void ApplyInventoryItem(int? consumedItemId, int? appliedItemId, string appliedPropertyName, bool IsRemovable, string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId) ||
                !consumedItemId.HasValue || !appliedItemId.HasValue || string.IsNullOrWhiteSpace(appliedPropertyName))
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
                return;
            }

            try
            {
                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem changedApplied;
                InventoryItem consumedDelta = null;
                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    string consumedKey = consumedItemId.Value.ToString();
                    string appliedKey = appliedItemId.Value.ToString();
                    if (inventory?.InventoryItems == null ||
                        !inventory.InventoryItems.TryGetValue(consumedKey, out BsonValue consumedValue) || !consumedValue.IsBsonDocument ||
                        !inventory.InventoryItems.TryGetValue(appliedKey, out BsonValue appliedValue) || !appliedValue.IsBsonDocument)
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
                        return;
                    }

                    BoltInventoryItem consumed = new BsonElement(consumedKey, consumedValue.AsBsonDocument).ToBoltInventory();
                    BoltInventoryItem applied = new BsonElement(appliedKey, appliedValue.AsBsonDocument).ToBoltInventory();
                    provider.SetItemProperty(playerObjectId, appliedItemId.Value, new BoltInventoryItemProperty
                    {
                        Name = appliedPropertyName,
                        Type = BoltInventoryItemProperty.PropertyType.Int,
                        Value = consumed.itemDefinitionId.ToString()
                    });
                    applied.Properties.RemoveAll(x => x.Name == appliedPropertyName);
                    applied.Properties.Add(new BoltInventoryItemProperty { Name = appliedPropertyName, Type = BoltInventoryItemProperty.PropertyType.Int, Value = consumed.itemDefinitionId.ToString() });
                    changedApplied = applied.ToInventory(appliedItemId.Value);

                    if (IsRemovable)
                    {
                        int quantity = Math.Max(1, consumed.quantity);
                        consumedDelta = consumed.ToInventory(consumedItemId.Value);
                        if (quantity <= 1)
                        {
                            provider.RemoveItemToPlayerInventoryDocument(playerObjectId, consumedItemId.Value);
                            consumedDelta.Quantity = 0;
                        }
                        else
                        {
                            provider.SetPlayerInventoryItemQuantity(playerObjectId, consumedItemId.Value, quantity - 1);
                            consumedDelta.Quantity = quantity - 1;
                        }
                    }
                }

                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(InventoryItem)).ToBytes(changedApplied) } });
                InventoryEventBus.InventoryChanged(playerId,
                   changed: consumedDelta == null ? new[] { changedApplied } : new[] { changedApplied, consumedDelta },
                    source: "apply-item-property");
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
            }
        }

        protected void RemoveInventoryItemProperty(int? itemId, string propertyName, string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId) || !itemId.HasValue || string.IsNullOrWhiteSpace(propertyName))
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
                return;
            }

            try
            {
                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                InventoryItem changed;
                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    string key = itemId.Value.ToString();
                    if (inventory?.InventoryItems == null || !inventory.InventoryItems.TryGetValue(key, out BsonValue value) || !value.IsBsonDocument)
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
                        return;
                    }
                    BoltInventoryItem applied = new BsonElement(key, value.AsBsonDocument).ToBoltInventory();
                    applied.Properties.RemoveAll(x => x.Name == propertyName);
                    provider.RemoveItemProperty(playerObjectId, itemId.Value, propertyName);
                    changed = applied.ToInventory(itemId.Value);
                }

                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(InventoryItem)).ToBytes(changed) } });
                InventoryEventBus.InventoryChanged(playerId, changed: new[] { changed }, source: "remove-item-property");
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
            }
        }

        private void SetFlagsEncrypted(RpcRequest request)
        {
            try
            {
                if (!SessionIdentity.TryGetPlayerId(_session, out string playerId)) return;
                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, "setInventoryItemFlagsEncrypted");
                byte[] itemFlagsBytes = ContractWire.ReadBytesField(plainRequest, 1);
                ItemFlags parsedFlags = itemFlagsBytes != null && itemFlagsBytes.Length > 0
                    ? ItemFlags.Parser.ParseFrom(itemFlagsBytes)
                    : ItemFlags.Parser.ParseFrom(plainRequest);
                var changedItems = new List<InventoryItem>();
                ObjectId playerObjectId = ObjectId.Parse(playerId);
                if (parsedFlags != null)
                {
                    foreach (KeyValuePair<int, int> pair in parsedFlags.Flags)
                    {
                        BoltGameDatabaseProvider.Instance.SetItemFlag(playerObjectId, pair.Key, pair.Value);
                    }
                }
                try
                {
                    PlayerInventoryDocument refreshed = BoltGameDatabaseProvider.Instance.GetPlayerInventoryDocument(playerObjectId);
                    if (parsedFlags != null)
                        foreach (int inventoryId in parsedFlags.Flags.Keys)
                        {
                            string key = inventoryId.ToString();
                            if (refreshed?.InventoryItems != null &&
                                refreshed.InventoryItems.TryGetValue(key, out BsonValue rawItem) &&
                                rawItem.IsBsonDocument)
                            {
                                changedItems.Add(new BsonElement(key, rawItem.AsBsonDocument).ToInventory());
                            }
                        }
                }
                catch (System.Exception)
                {
                }
                ContractWire.SendEncrypted(_session, request.Id, Array.Empty<byte>(), "setInventoryItemFlagsEncrypted");
                if (changedItems.Count > 0)
                    InventoryEventBus.InventoryChanged(playerId, changed: changedItems, source: "set-flags");
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private static InventoryItemDefinition[] AddContainerData(InventoryItemDefinition[] definitions)
        {
            if (definitions == null || definitions.Length == 0) return definitions ?? Array.Empty<InventoryItemDefinition>();
            var containers = new HashSet<int> { 301, 302, 303, 304, 401, 402, 403, 404, 501, 701 };
            foreach (InventoryItemDefinition container in definitions.Where(x => x != null && containers.Contains(x.Id)))
            {
                if (!container.Properties.TryGetValue("collection", out string collection) || string.IsNullOrWhiteSpace(collection)) continue;
                int minRarity = container.Id >= 301 && container.Id <= 304 ? 3 : 1;
                var rewards = definitions
                    .Where(x => x != null && !containers.Contains(x.Id))
                    .Where(x => x.Properties.TryGetValue("collection", out string c) && string.Equals(c, collection, StringComparison.OrdinalIgnoreCase))
                    .Select(x => new { Definition = x, Rarity = x.Properties.TryGetValue("value", out string raw) && int.TryParse(raw, out int rarity) ? rarity : 0 })
                    .Where(x => x.Rarity >= minRarity && x.Rarity <= 6)
                    .OrderBy(x => x.Rarity).ThenBy(x => x.Definition.Id).ToArray();
                if (rewards.Length == 0) continue;
                container.Properties["contains"] = string.Join(", ", rewards.Select(x => x.Definition.Id));
                container.Properties["values"] = string.Join(", ", rewards.Select(x => x.Rarity));
                container.Properties["content_count"] = rewards.Length.ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
            return definitions;
        }

        private static void NormalizeShopPrice(InventoryItemDefinition definition)
        {
            if (definition == null) return;
            if (!TryGetGoldCase(definition.Id, out int currencyId, out double unitPrice)) return;
            definition.BuyPrice.Clear();
            definition.BuyPrice.Add(new CurrencyAmount
            {
                CurrencyId = currencyId,
                OldValue = 0,
                Value = (float)unitPrice
            });
        }

        private static InventoryItemDefinition[] NormalizeShopPrices(IEnumerable<InventoryItemDefinition> definitions)
        {
            InventoryItemDefinition[] result = (definitions ?? Enumerable.Empty<InventoryItemDefinition>())
                .Where(x => x != null).ToArray();
            foreach (InventoryItemDefinition definition in result)
                NormalizeShopPrice(definition);
            return result;
        }

        private void SendInventory(string guid, string methodName)
        {
            try
            {
                if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
                {
                    ContractWire.SendException(_session, guid, 401);
                    return;
                }

                byte[] plainResponse;
                int count;
                if (methodName == "getInventoryItemDefinitionsEncrypted")
                {
                    InventoryItemDefinition[] definitions = NormalizeShopPrices(AddContainerData(BoltGameDatabaseProvider.Instance
                        .GetAllItemDefinitionsByType(0)
                        .Select(x => x.ToInventoryItemDefinition())
                        .Where(x => x != null)
                        .ToArray()));
                    count = definitions.Length;
                    plainResponse = ContractWire.Build(w =>
                    {
                        foreach (InventoryItemDefinition definition in definitions) w.Message(1, definition);
                        w.String(2, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString());
                    });
                }
                else
                {
                    InventoryItemPropertyDefinitions[] definitions = BoltGameDatabaseProvider.Instance
                        .GetAllItemPropertyDefinitions()
                        .Select(x => x.GetInventoryItemPropertyDefinitions())
                        .Where(x => x != null)
                        .ToArray();
                    count = definitions.Length;
                    plainResponse = ContractWire.Build(w =>
                    {
                        foreach (InventoryItemPropertyDefinitions definition in definitions) w.Message(1, definition);
                        w.String(2, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString());
                    });
                }

                ContractWire.SendEncrypted(_session, guid, plainResponse, methodName);
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, guid, 500);
            }
        }

        private static double NumericDouble(BsonValue value)
        {
            if (value == null || value.IsBsonNull) return 0;
            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsDouble) return value.AsDouble;
            if (value.IsDecimal128) return (double)Decimal128.ToDecimal(value.AsDecimal128);
            if (value.IsString && double.TryParse(value.AsString, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out double parsed)) return parsed;
            return 0;
        }

        private static int NextItemId(BsonDocument inventoryItems)
        {
            int max = 0;
            if (inventoryItems != null)
            {
                foreach (BsonElement element in inventoryItems.Elements)
                    if (int.TryParse(element.Name, out int id) && id > max) max = id;
            }
            return max + 1;
        }

        private static bool TryGetGoldCase(int itemDefinitionId, out int currencyId, out double unitPrice)
        {

            currencyId = 102;
            switch (itemDefinitionId)
            {
                case 301:
                case 302:
                case 303:
                case 304:
                case 305:
                case 307:
                case 308:
                case 309:
                case 311:
                case 319:
                case 329:
                case 347:
                case 351:
                case 359:
                    unitPrice = 100d;
                    return true;
                default:
                    unitPrice = 0d;
                    currencyId = 0;
                    return false;
            }
        }

        private static bool TryGetBuyPrice(BoltInventoryItemDefinitionDocument definition,
            int requestedCurrencyId, out int currencyId, out double unitPrice)
        {
            currencyId = requestedCurrencyId;
            unitPrice = 0;
            if (definition != null && TryGetGoldCase(definition.key, out currencyId, out unitPrice))
            {
                return true;
            }
            if (definition?.buyPrice == null || definition.buyPrice.Count == 0)
                return true;

            BsonDocument selected = null;
            foreach (BsonValue value in definition.buyPrice)
            {
                if (!value.IsBsonDocument) continue;
                BsonDocument price = value.AsBsonDocument;
                int candidateCurrency = price.GetValue("currencyId", 0).ToInt32();
                if (requestedCurrencyId > 0 && candidateCurrency == requestedCurrencyId)
                {
                    selected = price;
                    break;
                }
                if (selected == null) selected = price;
            }

            if (selected == null) return false;
            currencyId = selected.GetValue("currencyId", requestedCurrencyId).ToInt32();
            unitPrice = NumericDouble(selected.GetValue("value", 0));
            return currencyId > 0 || unitPrice <= 0;
        }

        private void BuyEncrypted(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            string mutationKey = null;
            bool mutationCommitted = false;
            double spent = 0;
            int spentCurrencyId = 0;

            try
            {
                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, "buyInventoryItemEncrypted");
                int itemDefinitionId = ContractWire.ReadIntField(plainRequest, 1, 0);
                int requestedQuantity = ContractWire.ReadIntField(plainRequest, 2, 1);
                int quantity = Math.Max(1, Math.Min(requestedQuantity, 100));
                int requestedCurrencyId = ContractWire.ReadIntField(plainRequest, 3, 0);
                bool toManyItems = ContractWire.ReadBoolField(plainRequest, 4, false);
                if (itemDefinitionId <= 0 || requestedQuantity <= 0 || requestedQuantity > 100)
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }
                BoltInventoryItemDefinitionDocument definition = database.GetInventoryItemDefinition(itemDefinitionId, 1);
                if (definition == null || !definition.enabled)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }
                if (itemDefinitionId == BattlePassRuntime.FallbackGoldPassItemDefinitionId)
                {
                    if (quantity != 1 || toManyItems)
                    {
                        ContractWire.SendException(_session, request.Id, 400);
                        return;
                    }
                    if (BattlePassRuntime.OwnsInventoryDefinition(playerId, BattlePassRuntime.FallbackGoldPassItemDefinitionId))
                    {
                        ContractWire.SendException(_session, request.Id, 409);
                        return;
                    }
                }
                if (!TryGetBuyPrice(definition, requestedCurrencyId, out int currencyId, out double unitPrice) ||
                    unitPrice < 0 || double.IsNaN(unitPrice) || double.IsInfinity(unitPrice))
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }

                double totalPrice = checked(unitPrice * quantity);
                if (totalPrice < 0 || totalPrice > 1_000_000_000d)
                {
                    ContractWire.SendException(_session, request.Id, 400);
                    return;
                }
                if (!database.TryBeginInventoryMutation(playerId, "buyInventoryItemEncrypted", request.Id, out mutationKey))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                var createdItems = new List<InventoryItem>();
                var createdIds = new List<int>();
                CurrencyAmount currencyDelta = null;

                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory;
                    try { inventory = database.GetPlayerInventoryDocument(playerObjectId); }
                    catch
                    {
                        database.CreatePlayerInventory(playerObjectId);
                        inventory = database.GetPlayerInventoryDocument(playerObjectId);
                    }
                    double balanceBefore = 0, balanceAfter = 0;
                    if (totalPrice > 0)
                    {
                        if (!database.TrySpendCurrencyAtomic(
                                playerObjectId, currencyId, totalPrice,
                                out balanceBefore, out balanceAfter))
                        {
                            database.AbortInventoryMutation(mutationKey);
                            mutationKey = null;
                            ContractWire.SendException(_session, request.Id, 402);
                            return;
                        }
                        spent = totalPrice;
                        spentCurrencyId = currencyId;
                        currencyDelta = new CurrencyAmount
                        {
                            CurrencyId = currencyId,
                            OldValue = (int)Math.Round(balanceBefore),
                            Value = (float)(-totalPrice)
                        };
                    }

                    int records = toManyItems ? quantity : 1;
                    int quantityPerRecord = toManyItems ? 1 : quantity;
                    try
                    {
                        for (int index = 0; index < records; index++)
                        {
                            var stored = new BoltInventoryItem
                            {
                                itemDefinitionId = itemDefinitionId,
                                quantity = quantityPerRecord,
                                flags = 0,
                                date = (BsonDateTime)DateTime.UtcNow
                            };
                            int inventoryId = database.AddItemToPlayerInventoryDocumentAtomic(playerObjectId, stored);
                            createdIds.Add(inventoryId);
                            createdItems.Add(stored.ToInventory(inventoryId));
                        }
                    }
                    catch
                    {
                        foreach (int inventoryId in createdIds)
                        {
                            try { database.RemoveItemToPlayerInventoryDocument(playerObjectId, inventoryId); }
                            catch { }
                        }
                        if (spent > 0)
                        {
                            try { database.RefundCurrencyAtomic(playerObjectId, spentCurrencyId, spent); }
                            catch { }
                            spent = 0;
                        }
                        throw;
                    }
                }

                database.CompleteInventoryMutation(mutationKey);
                mutationCommitted = true;

                byte[] plainResponse = ContractWire.WrapRepeated(1, createdItems);
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, "buyInventoryItemEncrypted");
                InventoryEventBus.InventoryChanged(
                   playerId,
                    added: createdItems,
                    currencies: null,
                    source: itemDefinitionId == BattlePassRuntime.FallbackGoldPassItemDefinitionId ? "buy-goldpass-no-duplicate-currency" : "buy-item-no-duplicate-currency",
                    preferredUser: _session);
                if (itemDefinitionId == BattlePassRuntime.FallbackGoldPassItemDefinitionId)
                    GameEventRemoteService.BroadcastStateChanged(playerId, new Reward());
            }
            catch (OverflowException)
            {
                if (!mutationCommitted && mutationKey != null) database.AbortInventoryMutation(mutationKey);
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch (InvalidDataException)
            {
                if (!mutationCommitted && mutationKey != null) database.AbortInventoryMutation(mutationKey);
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch (System.Exception)
            {
                if (!mutationCommitted && mutationKey != null) database.AbortInventoryMutation(mutationKey);
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private static List<int> DefinitionIds(BsonDocument properties, string arrayField, string csvField)
        {
            var result = new List<int>();
            if (properties == null) return result;

            if (properties.TryGetValue(arrayField, out BsonValue arrayValue) && arrayValue.IsBsonArray)
            {
                foreach (BsonValue value in arrayValue.AsBsonArray)
                {
                    int parsed = value.IsNumeric ? value.ToInt32() :
                        (value.IsString && int.TryParse(value.AsString, out int number) ? number : 0);
                    if (parsed > 0) result.Add(parsed);
                }
            }

            if (result.Count == 0 && properties.TryGetValue(csvField, out BsonValue csvValue) && csvValue.IsString)
            {
                foreach (string token in csvValue.AsString.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    if (int.TryParse(token, out int parsed) && parsed > 0) result.Add(parsed);
            }
            return result;
        }

        private static int PickReward(
            BoltInventoryItemDefinitionDocument container,
            IReadOnlyList<int> candidates)
        {
            if (container?.properties == null || candidates == null || candidates.Count == 0)
                return 0;

            BsonDocument properties = container.properties;
            var enabled = new HashSet<int>(candidates);

            List<int> configuredIds = DefinitionIds(properties, "containsIds", "contains");
            List<double> weights = DropWeights(properties);

            if (configuredIds.Count > 0 && configuredIds.Count == weights.Count)
            {
                var ids = new List<int>();
                var values = new List<double>();

                for (int i = 0; i < configuredIds.Count; i++)
                {
                    if (!enabled.Contains(configuredIds[i]) || weights[i] <= 0)
                        continue;

                    ids.Add(configuredIds[i]);
                    values.Add(weights[i]);
                }

                if (ids.Count > 0)
                    return PickWeighted(ids, values);
            }

            var specialIds = new HashSet<int>(
                DefinitionIds(properties, "specialContains", "specialContains"));

            double specialChance = properties.TryGetValue("specialDropChance", out BsonValue specialRaw)
                ? NumericDouble(specialRaw)
                : 0;

            var special = candidates.Where(specialIds.Contains).ToList();
            if (special.Count > 0 &&
                specialChance > 0 &&
                Random.Shared.NextDouble() * 100 < specialChance)
            {
                return special[Random.Shared.Next(special.Count)];
            }

            var normal = candidates.Where(x => !specialIds.Contains(x)).ToList();
            if (normal.Count == 0)
                normal = candidates.ToList();

            return normal.Count == 0 ? 0 : normal[Random.Shared.Next(normal.Count)];
        }

        private static List<double> DropWeights(BsonDocument properties)
        {
            var result = new List<double>();
            if (properties == null ||
                !properties.TryGetValue("dropWeights", out BsonValue raw) ||
                raw == null ||
                raw.IsBsonNull)
            {
                return result;
            }

            if (raw.IsBsonArray)
            {
                foreach (BsonValue value in raw.AsBsonArray)
                    result.Add(Math.Max(0, NumericDouble(value)));

                return result;
            }

            string text = raw.IsString ? raw.AsString : raw.ToString();
            foreach (string token in text.Split(
                         new[] { ',', ';' },
                         StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                if (double.TryParse(
                        token,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out double weight))
                {
                    result.Add(Math.Max(0, weight));
                }
            }

            return result;
        }

        private static int PickWeighted(
            IReadOnlyList<int> ids,
            IReadOnlyList<double> weights)
        {
            if (ids == null || weights == null || ids.Count == 0 || ids.Count != weights.Count)
                return 0;

            double total = 0;
            for (int i = 0; i < weights.Count; i++)
                total += Math.Max(0, weights[i]);

            if (total <= 0)
                return 0;

            double roll = Random.Shared.NextDouble() * total;
            double current = 0;

            for (int i = 0; i < ids.Count; i++)
            {
                current += Math.Max(0, weights[i]);
                if (roll < current)
                    return ids[i];
            }

            return ids[ids.Count - 1];
        }

        private static bool IsFragment(int definitionId) =>
            definitionId >= 902 && definitionId <= 907;

        private static int GetFragmentRarity(int definitionId)
        {
            return definitionId switch
            {
                902 => 2,
                903 => 3,
                904 => 4,
                905 => 5,
                906 => 6,
                907 => 6,
                _ => 0
            };
        }

        private static int NextFragment(int definitionId)
        {
            return definitionId switch
            {
                902 => 903,
                903 => 904,
                904 => 905,
                905 => 906,
                906 => 907,
                _ => 0
            };
        }

        private static int PickFragmentItem(BoltGameDatabaseProvider database, int fragmentDefinitionId)
        {
            int rarity = GetFragmentRarity(fragmentDefinitionId);
            if (rarity <= 0) return 0;
            var candidates = database.GetInventoryItemDefinitions()
                .Where(x => x != null && x.enabled && x.properties != null)
                .Where(x =>
                {
                    if (!x.properties.TryGetValue("clientKind", out BsonValue kind) ||
                       !kind.IsString || kind.AsString != "skin") return false;
                    if (!x.properties.TryGetValue("value", out BsonValue value)) return false;
                    int candidateRarity = value.IsInt32 ? value.AsInt32 : 0;
                    if (!value.IsInt32) int.TryParse(value.ToString(), out candidateRarity);
                    return candidateRarity == rarity;
                })
                .Select(x => x.key)
                .ToList();
            return candidates.Count == 0 ? 0 : candidates[Random.Shared.Next(candidates.Count)];
        }

        private static bool IsFragmentExchange(
            PlayerInventoryDocument inventory,
            IReadOnlyList<int> inventoryItemIds,
            out int fragmentDefinitionId,
            out int totalQuantity)
        {
            fragmentDefinitionId = 0;
            totalQuantity = 0;
            if (inventory?.InventoryItems == null || inventoryItemIds == null || inventoryItemIds.Count == 0)
                return false;
            foreach (int inventoryId in inventoryItemIds)
            {
                if (!inventory.InventoryItems.TryGetValue(inventoryId.ToString(), out BsonValue raw) || !raw.IsBsonDocument)
                    return false;
                BsonDocument doc = raw.AsBsonDocument;
                int defId = doc.GetValue("itemDefinitionId", 0).ToInt32();
                if (!IsFragment(defId)) return false;
                if (fragmentDefinitionId == 0) fragmentDefinitionId = defId;
                if (fragmentDefinitionId != defId) return false;
                totalQuantity += Math.Max(0, doc.GetValue("quantity", 0).ToInt32());
            }
            return fragmentDefinitionId != 0;
        }

        private static void ConsumeFragments(
            BoltGameDatabaseProvider database,
            ObjectId playerObjectId,
            PlayerInventoryDocument inventory,
            IReadOnlyList<int> inventoryItemIds,
            int required,
            List<InventoryItem> changed)
        {
            int left = required;
            foreach (int inventoryId in inventoryItemIds)
            {
                if (left <= 0) break;
                string key = inventoryId.ToString();
                BsonDocument doc = inventory.InventoryItems[key].AsBsonDocument;
                int quantity = Math.Max(0, doc.GetValue("quantity", 0).ToInt32());
                int take = Math.Min(quantity, left);
                int remain = quantity - take;
                BoltInventoryItem stored = new BsonElement(key, doc).ToBoltInventory();
                if (remain <= 0) database.RemoveItemToPlayerInventoryDocument(playerObjectId, inventoryId);
                else database.SetPlayerInventoryItemQuantity(playerObjectId, inventoryId, remain);
                InventoryItem delta = stored.ToInventory(inventoryId);
                delta.Quantity = Math.Max(0, remain);
                changed.Add(delta);
                left -= take;
            }
            if (left != 0) throw new InvalidOperationException("fragment underflow");
        }
        private void ExecuteEncryptedRecipe(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            try
            {
                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, "executeRecipeEncrypted2");
                string recipeCode = ContractWire.ReadStringField(plainRequest, 1, string.Empty);
                List<int> inventoryItemIds = ContractWire.ReadRepeatedIntField(plainRequest, 3)
                    .Where(x => x > 0)
                    .Distinct()
                    .ToList();
                if (inventoryItemIds.Count == 0)
                {

                    ExecuteCurrencyRecipe(request, playerId, playerObjectId, recipeCode, plainRequest);
                    return;
                }

                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
                InventoryItem rewardProto;
                InventoryItem consumedDelta = null;
                int consumedInventoryId = inventoryItemIds[0];
                int consumedDefinitionId;
                int rewardDefinitionId;

                lock (InventoryPurchaseSync)
                {
                    PlayerInventoryDocument inventory = database.GetPlayerInventoryDocument(playerObjectId);
                    if (IsFragmentExchange(inventory, inventoryItemIds,
                            out int fragmentDefinitionId, out int fragmentTotal))
                    {
                        const int requiredFragments = 10;
                        if (fragmentTotal < requiredFragments)
                        {
                            ContractWire.SendException(_session, request.Id, 400);
                            return;
                        }

                        bool upgrade = !string.IsNullOrWhiteSpace(recipeCode) &&
                             recipeCode.IndexOf("upgrade", StringComparison.OrdinalIgnoreCase) >= 0;
                        int fragmentRewardDefinitionId = upgrade
                            ? NextFragment(fragmentDefinitionId)
                            : PickFragmentItem(database, fragmentDefinitionId);
                        if (fragmentRewardDefinitionId <= 0)
                        {
                            ContractWire.SendException(_session, request.Id, 404);
                            return;
                        }

                        if (!database.TryBeginInventoryMutation(
                                playerId, "executeRecipeEncrypted2", request.Id, out string fragmentMutationKey))
                        {
                            ContractWire.SendException(_session, request.Id, 409);
                            return;
                        }

                        var fragmentChanged = new List<InventoryItem>();
                        int fragmentRewardInventoryId = NextItemId(inventory.InventoryItems);
                        var fragmentReward = new BoltInventoryItem
                        {
                            itemDefinitionId = fragmentRewardDefinitionId,
                            quantity = 1,
                            flags = 0,
                            date = (BsonDateTime)DateTime.UtcNow
                        };
                        try
                        {
                            ConsumeFragments(database, playerObjectId, inventory,
                                inventoryItemIds, requiredFragments, fragmentChanged);
                            database.AddItemToPlayerInventoryDocument(
                                playerObjectId, fragmentReward, fragmentRewardInventoryId);
                        }
                        catch
                        {
                            database.AbortInventoryMutation(fragmentMutationKey);
                            throw;
                        }

                        database.CompleteInventoryMutation(fragmentMutationKey);
                        rewardProto = fragmentReward.ToInventory(fragmentRewardInventoryId);
                        byte[] fragmentExchangeResult = ContractWire.Build(w =>
                        {
                            w.Message(2, rewardProto);
                            foreach (InventoryItem changedItem in fragmentChanged)
                                w.Message(3, changedItem);
                        });
                        byte[] fragmentResponse = ContractWire.Build(w => w.Message(1, fragmentExchangeResult));
                        ContractWire.SendEncrypted(_session, request.Id, fragmentResponse, "executeRecipeEncrypted2");
                        InventoryEventBus.InventoryChanged(
                            playerId,
                            added: new[] { rewardProto },
                            changed: fragmentChanged,
                            source: upgrade ? "fragment-upgrade" : "fragment-skin-craft",
                            preferredUser: _session);
                        return;
                    }

                    string consumedKey = consumedInventoryId.ToString();
                    if (inventory?.InventoryItems == null ||
                        !inventory.InventoryItems.TryGetValue(consumedKey, out BsonValue consumedValue) ||
                        !consumedValue.IsBsonDocument)
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    BsonDocument consumedDocument = consumedValue.AsBsonDocument;
                    consumedDefinitionId = consumedDocument.GetValue("itemDefinitionId", 0).ToInt32();
                    int consumedQuantity = Math.Max(1, consumedDocument.GetValue("quantity", 1).ToInt32());
                    BoltInventoryItem originalItem = new BsonElement(consumedKey, consumedDocument).ToBoltInventory();

                    BoltInventoryItemDefinitionDocument containerDefinition =
                        database.GetInventoryItemDefinition(consumedDefinitionId, 1);
                    if (containerDefinition?.properties == null)
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    List<int> candidates = DefinitionIds(containerDefinition.properties, "containsIds", "contains");

                    if (candidates.Count == 0 &&
                        containerDefinition.properties.TryGetValue("graffitiRefId", out BsonValue graffitiRefRaw))
                    {
                        string graffitiRefText = graffitiRefRaw.IsString
                             ? graffitiRefRaw.AsString
                             : graffitiRefRaw.ToString();
                        if (int.TryParse(graffitiRefText,
                                System.Globalization.NumberStyles.Integer,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out int graffitiRefId) && graffitiRefId > 0)
                        {
                            candidates.Add(graffitiRefId);
                        }
                    }

                    var enabledCandidates = new List<int>();
                    for (int i = 0; i < candidates.Count; i++)
                    {
                        BoltInventoryItemDefinitionDocument candidate = database.GetInventoryItemDefinition(candidates[i], 1);
                        if (candidate == null || !candidate.enabled) continue;
                        enabledCandidates.Add(candidates[i]);
                    }

                    rewardDefinitionId = PickReward(containerDefinition, enabledCandidates);
                    if (rewardDefinitionId <= 0)
                    {
                        ContractWire.SendException(_session, request.Id, 404);
                        return;
                    }

                    string recipeMutationKey;
                    if (!database.TryBeginInventoryMutation(
                           playerId, "executeRecipeEncrypted2", request.Id, out recipeMutationKey))
                    {
                        ContractWire.SendException(_session, request.Id, 409);
                        return;
                    }

                    int rewardInventoryId = NextItemId(inventory.InventoryItems);

                    int rewardQuantity = 1;
                    BoltInventoryItemDefinitionDocument rewardDefinition =
                        database.GetInventoryItemDefinition(rewardDefinitionId, 1);
                    if (rewardDefinition?.properties != null)
                    {
                        string rewardKind = rewardDefinition.properties.TryGetValue("clientKind", out BsonValue kindRaw)
                            ? (kindRaw.IsString ? kindRaw.AsString : kindRaw.ToString())
                            : string.Empty;
                        string rewardRuntimeClass = rewardDefinition.properties.TryGetValue("clientRuntimeClass", out BsonValue classRaw)
                            ? (classRaw.IsString ? classRaw.AsString : classRaw.ToString())
                            : string.Empty;

                        if (string.Equals(rewardKind, "graffiti", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(rewardRuntimeClass, "GraffitiDefinition", StringComparison.OrdinalIgnoreCase))
                        {
                            rewardQuantity = 30;
                        }
                    }

                    var reward = new BoltInventoryItem
                    {
                        itemDefinitionId = rewardDefinitionId,
                        quantity = rewardQuantity,
                        flags = 0,
                        date = (BsonDateTime)DateTime.UtcNow
                    };

                    bool removedConsumed = consumedQuantity <= 1;
                    consumedDelta = originalItem.ToInventory(consumedInventoryId);
                    consumedDelta.Quantity = removedConsumed ? 0 : consumedQuantity - 1;
                    try
                    {
                        if (removedConsumed)
                            database.RemoveItemToPlayerInventoryDocument(playerObjectId, consumedInventoryId);
                        else
                            database.SetPlayerInventoryItemQuantity(playerObjectId, consumedInventoryId, consumedQuantity - 1);

                        database.AddItemToPlayerInventoryDocument(playerObjectId, reward, rewardInventoryId);
                    }
                    catch
                    {
                        try
                        {
                            if (removedConsumed)
                                database.AddItemToPlayerInventoryDocument(playerObjectId, originalItem, consumedInventoryId);
                            else
                                database.SetPlayerInventoryItemQuantity(playerObjectId, consumedInventoryId, consumedQuantity);
                            database.RemoveItemToPlayerInventoryDocument(playerObjectId, rewardInventoryId);
                        }
                        catch { }
                        database.AbortInventoryMutation(recipeMutationKey);
                        throw;
                    }
                    database.CompleteInventoryMutation(recipeMutationKey);
                    rewardProto = reward.ToInventory(rewardInventoryId);
                }

                byte[] exchangeResult = ContractWire.Build(w => w.Message(2, rewardProto));
                byte[] plainResponse = ContractWire.Build(w => w.Message(1, exchangeResult));
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, "executeRecipeEncrypted2");
                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: new[] { rewardProto },
                    changed: consumedDelta == null ? null : new[] { consumedDelta },
                    source: "execute-recipe",
                    preferredUser: _session);
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void ExecuteCurrencyRecipe(
            RpcRequest request,
           string playerId,
            ObjectId playerObjectId,
            string recipeCode,
            byte[] plainRequest)
        {
            const int SilverCurrencyId = 101;
            const int GoldCurrencyId = 102;
            const double GoldCost = 10d;
            const double SilverReward = 100d;

            recipeCode = (recipeCode ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(recipeCode))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            string mutationKey = null;
            bool committed = false;
            try
            {
                if (!database.TryBeginInventoryMutation(
                        playerId, "executeRecipeEncrypted2:currency", request.Id, out mutationKey))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                double goldBefore, goldAfter, silverBefore, silverAfter;
                lock (InventoryPurchaseSync)
                {
                    if (!database.TryExchangeCurrencyAtomic(
                            playerObjectId,
                            GoldCurrencyId, GoldCost,
                            SilverCurrencyId, SilverReward,
                            out goldBefore, out goldAfter,
                            out silverBefore, out silverAfter))
                    {
                        database.AbortInventoryMutation(mutationKey);
                        mutationKey = null;
                        ContractWire.SendException(_session, request.Id, 402);
                        return;
                    }
                }

                database.CompleteInventoryMutation(mutationKey);
                committed = true;
                var spentGold = new CurrencyAmount
                {
                    CurrencyId = GoldCurrencyId,
                    OldValue = (int)Math.Round(goldBefore),
                    Value = (float)(-GoldCost)
                };
                var grantedSilver = new CurrencyAmount
                {
                    CurrencyId = SilverCurrencyId,
                    OldValue = (int)Math.Round(silverBefore),
                    Value = (float)SilverReward
                };
                byte[] exchangeResult = ContractWire.Build(w =>
                {
                    w.Message(1, spentGold);
                    w.Message(1, grantedSilver);
                });
                byte[] plainResponse = ContractWire.Build(w => w.Message(1, exchangeResult));
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, "executeRecipeEncrypted2");

            }
            catch (System.Exception)
            {
                if (!committed && mutationKey != null)
                {
                    try { database.AbortInventoryMutation(mutationKey); } catch { }
                }
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void GetEncryptedRecipeStatus(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            try
            {
                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, "getRecipeStatusEncrypted");
                string recipeCode = ContractWire.ReadStringField(plainRequest, 1, string.Empty);
                byte[] plainResponse = ContractWire.Build(w =>
                {
                    w.Bool(1, true);
                    w.Bool(2, true);
                    w.Int32(3, 0);
                    w.Varint(4, 0);
                });
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, "getRecipeStatusEncrypted");
            }
            catch (InvalidDataException)
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
        }

        private void SendEmptyInventory(string guid, string methodName)
        {
            try
            {
                byte[] plainResponse = Array.Empty<byte>();
                byte[] key = _session.GetSessionKey();
                byte[] iv = _session.GetSessionIv();
                if (key == null || key.Length != 16 || iv == null || iv.Length != 16)
                    throw new InvalidOperationException("inventory aes not ready");

                byte[] cipher = Protocol.EncryptAesCbc(plainResponse, key, iv);

                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(cipher)
                        }
                    }
                });
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 500
                        }
                    }
                });
            }
        }

        private void GetPublicItems(RpcRequest request)
        {
            const string methodName = "getOtherPlayerPublicItemsEncrypted";
            try
            {
                byte[] plainRequest = ContractWire.DecryptParam(_session, request, 0, methodName);
                string targetGpid = string.Empty;
                int flagFilter = 0;

                var reader = new ContractWire.Reader(plainRequest);

                while (reader.TryReadField(out int field, out int wire))
                {

                    if (field == 1 && wire == 2)
                        targetGpid = reader.ReadString();
                    else if (field == 2 && wire == 0)
                        flagFilter = reader.ReadInt32();
                    else
                        reader.Skip(wire);
                }

                byte[] plainResponse = Array.Empty<byte>();
                ContractWire.SendEncrypted(_session, request.Id, plainResponse, methodName);
                string requesterId = ServerState.Users.TryGetValue(_session.TcpClient, out string currentPlayerId)
                    ? currentPlayerId ?? string.Empty
                    : string.Empty;
            }
            catch (System.Exception)
            {
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 500
                        }
                    }
                });
            }
        }
        private void ActivateCoupon(RpcRequest request)
        {
            bool encrypted = string.Equals(request.MethodName, "activateCouponEncrypted", StringComparison.Ordinal);
            try
            {
                byte[] requestBytes = encrypted
                        ? ContractWire.DecryptParam(_session, request, 0, "activateCouponEncrypted")
              : ContractWire.Param(request);
                byte[] response = CoreRemoteService.ActivateCoupon(_session, requestBytes);
                if (encrypted)
                    ContractWire.SendEncrypted(_session, request.Id, response, "activateCouponEncrypted");

                else
                    ContractWire.SendRaw(_session, request.Id, response);
            }
            catch (CoreRemoteService.FeatureRpcException ex)
            {
                ContractWire.SendException(_session, request.Id, ex.Code);
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }

        private void EnsureInventoryEvents()
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId))
                return;
            ServerState.EnsureConnectionEventSender(
                playerId, _session.TcpClient, () => new InventoryRemoteEventSender(_session));
        }

        public override void Invoke(RpcRequest request)
        {




            EnsureInventoryEvents();

            if (request.MethodName == "activateCoupon" || request.MethodName == "activateCouponEncrypted" || request.MethodName == "activatePromocode" || request.MethodName == "activatePromoCode") ActivateCoupon(request);
            else if (request.MethodName == "getPlayerInventoryEncrypted") GetPlayerInventoryV2(request.Id);
            else if (request.MethodName == "getInventoryItemDefinitionsEncrypted") SendInventory(request.Id, request.MethodName);
            else if (request.MethodName == "getInventoryItemPropertyDefinitionsEncrypted") SendInventory(request.Id, request.MethodName);
            else if (request.MethodName == "getRecipeStatusEncrypted") GetEncryptedRecipeStatus(request);
            else if (request.MethodName == "executeRecipeEncrypted2") ExecuteEncryptedRecipe(request);
            else if (request.MethodName == "buyInventoryItemEncrypted") BuyEncrypted(request);
            else if (request.MethodName == "setItemsModificationsEncrypted") SetModificationsEncrypted(request);
            else if (request.MethodName == "setInventoryItemsPropertiesEncrypted") SetPropertiesEncrypted(request);
            else if (request.MethodName == "removeItemModificationEncrypted") RemoveModificationEncrypted(request);
            else if (request.MethodName == "mountInventoryItemEncrypted") MountEncrypted(request);
            else if (request.MethodName == "inventoryModificationCompatEncrypted033") HandleModification(request);
            else if (request.MethodName == "unmountInventoryItemEncrypted") UnmountEncrypted(request);
            else if (request.MethodName == "setInventoryItemFlagsEncrypted") SetFlagsEncrypted(request);
            else if (request.MethodName == "getOtherPlayerPublicItemsEncrypted") GetPublicItems(request);
            else if (request.MethodName == "getPlayerInventory") GetPlayerInventory(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getInventoryItemPropertyDefinitions") GetInventoryItemPropertyDefinitions(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getInventoryItemDefinitions") GetInventoryItemDefinitions(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "exchangeInventoryItems") ExchangeInventoryItems(request);
            else if (request.MethodName == "executeRecipe") ExecuteRecipe(request);
            else if (request.MethodName == "buyInventoryItem") BuyInventoryItem(request);
            else if (request.MethodName == "getRecipeStatus") GetRecipeStatus(request);
            else if (request.MethodName == "setInventoryItemFlags") SetInventoryItemFlags(request);
            else if (request.MethodName == "setInventoryItemsProperties") SetInventoryItemsProperties(request);
            else if (request.MethodName == "applyInventoryItem") ApplyInventoryItem((int?)new RpcValueReader(typeof(int?)).FromBytes(request.Params[0]), (int?)new RpcValueReader(typeof(int?)).FromBytes(request.Params[1]), (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[2]), (bool)new RpcValueReader(typeof(bool)).FromBytes(request.Params[3]), request.Id);
            else if (request.MethodName == "removeInventoryItemProperty") RemoveInventoryItemProperty((int?)new RpcValueReader(typeof(int?)).FromBytes(request.Params[0]), (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[1]), request.Id);

            else if (request.MethodName == "getOtherPlayerItems") GetPlayerInventory((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), (int[])new RpcValueReader(typeof(int[])).FromBytes(request.Params[1]), request.Id);
            else _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }

    }


}



