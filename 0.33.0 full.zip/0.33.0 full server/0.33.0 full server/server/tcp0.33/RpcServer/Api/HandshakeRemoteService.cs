using System;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class HandshakeRemoteService : RpcHandler
    {
        public HandshakeRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request)
        {
            InvokeAsync(request).GetAwaiter().GetResult();
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            if (request == null)
                return Task.CompletedTask;

            if (string.Equals(request.MethodName, "logout", StringComparison.OrdinalIgnoreCase))
            {
                SendNull(request.Id);
                return Task.CompletedTask;
            }

            if (request.Params == null || request.Params.Count == 0)
            {
                SendError(request.Id, 400, "handshake payload missing");
                return Task.CompletedTask;
            }

            byte[] raw = Protocol.GetBinaryValueBytes(request.Params[0]);
            if (!ReadHandshake(raw, out Handshake handshake, out string mode))
            {
                SendError(request.Id, 400, "invalid handshake protobuf");
                return Task.CompletedTask;
            }

            string ticket = handshake.Ticket ?? string.Empty;
            if (!RestoreToken(ticket, out Token token))
            {
                SendError(request.Id, 2003, "invalid ticket");
                return Task.CompletedTask;
            }

            try
            {
                Bind(token);

                var response = new HandshakeResponse
                {
                    Country = string.IsNullOrWhiteSpace(ServerOptions.Current.Country)
                        ? "US"
                        : ServerOptions.Current.Country,
                    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                };

                SendProto(request.Id, response.ToByteArray(), mode);
                _session.SchedulePostHandshakeEvents(request.Id, token.playerId.ToString());
            }
            catch
            {
                SendError(request.Id, 2003, "handshake bind failed");
            }

            return Task.CompletedTask;
        }

        private bool RestoreToken(string ticket, out Token token)
        {
            if (SessionTicket.TryValidate(ticket, out ObjectId playerId, out _))
            {
                token = new Token
                {
                    playerId = playerId,
                    gameCode = _session.LastGameId ?? "e0eb8b95-72b3-4821-9dce-31bbb632da7c",
                    gameVersion = _session.LastGameVersion ?? "0.33.0"
                };

                lock (ServerState.Tokens)
                    ServerState.Tokens[ticket] = token;

                return true;
            }

            lock (ServerState.Tokens)
            {
                if (ServerState.Tokens.TryGetValue(ticket, out token))
                    return true;
            }

            try
            {
                LocalAccountDocument account = BoltMainDatabaseProvider.Instance.GetLocalAccount(ticket);
                if (account == null || !ObjectId.TryParse(account.playerId, out ObjectId localPlayerId))
                    return false;

                token = new Token
                {
                    playerId = localPlayerId,
                    gameCode = _session.LastGameId ?? "1",
                    gameVersion = _session.LastGameVersion ?? "0.33.0"
                };

                lock (ServerState.Tokens)
                    ServerState.Tokens[ticket] = token;

                return true;
            }
            catch
            {
                token = null;
                return false;
            }
        }

        private void Bind(Token token)
        {
            string playerId = token.playerId.ToString();

            BoltMainDatabaseProvider main = BoltMainDatabaseProvider.Instance;
            main.GetPlayerDocument(token.playerId);

            BoltGameDatabaseProvider game = BoltGameDatabaseProvider.Instance;

            try
            {
                game.GetPlayerStatsDocument(playerId);
            }
            catch
            {
                game.CreatePlayerStats(playerId);
            }

            try
            {
                game.GetFiles(token.playerId);
            }
            catch
            {
                game.CreatePlayerFiles(playerId);
            }

            try
            {
                game.GetPlayerInventoryDocument(token.playerId);
            }
            catch
            {
                game.CreatePlayerInventory(token.playerId);
            }

            if (ServerState.Users.TryGetValue(_session.TcpClient, out string existing))
            {
                if (existing == playerId)
                    return;

                throw new InvalidOperationException($"TCP connection is already bound to {existing}");
            }

            lock (ServerState.UsersLock)
                ServerState.Users[_session.TcpClient] = playerId;

            var status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.gpid = playerId;
            status.onlineStatus = TspServer.RpcServer.PlayerStatus.OnlineStatus.StateOnline;
            status.playInGame ??= new TspServer.RpcServer.PlayInGame();

            if (string.IsNullOrWhiteSpace(status.playInGame.gameCode))
                status.playInGame.gameCode = token.gameCode;

            if (string.IsNullOrWhiteSpace(status.playInGame.gameVersion))
                status.playInGame.gameVersion = token.gameVersion;

            ServerState.SetPlayerStatusSnapshot(playerId, status);
            main.SetPlayerStatus(token.playerId, status);

            _session.InitializeEventSenders(playerId);
            SocialProfileEventBridge.BroadcastStatus(playerId, status);
        }

        private bool ReadHandshake(byte[] raw, out Handshake handshake, out string mode)
        {
            if (ReadProto(raw, out handshake))
            {
                mode = "direct";
                return true;
            }

            byte[] key = _session.GetSessionKey();
            byte[] iv = _session.GetSessionIv();

            if (key?.Length == 16 &&
                iv?.Length == 16 &&
                Protocol.TryDecryptAesCbc(raw, key, iv, out byte[] plain) &&
                ReadProto(plain, out handshake))
            {
                mode = "inner-session-aes";
                return true;
            }

            mode = string.Empty;
            return false;
        }

        private static bool ReadProto(byte[] raw, out Handshake handshake)
        {
            handshake = null;

            try
            {
                Handshake parsed = Handshake.Parser.ParseFrom(raw ?? Array.Empty<byte>());
                if (parsed == null || string.IsNullOrWhiteSpace(parsed.Ticket))
                    return false;

                handshake = parsed;
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void SendProto(string requestId, byte[] payload, string mode)
        {
            byte[] body = payload ?? Array.Empty<byte>();

            if (mode == "inner-session-aes")
                body = Protocol.EncryptAesCbc(body, _session.GetSessionKey(), _session.GetSessionIv());

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.CopyFrom(body)
                    }
                }
            });
        }

        private void SendNull(string requestId)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string requestId, int code, string reason)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code,
                        Property = { ["reason"] = reason }
                    }
                }
            });
        }
    }
}
