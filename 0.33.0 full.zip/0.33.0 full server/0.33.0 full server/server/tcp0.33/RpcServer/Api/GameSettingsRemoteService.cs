using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;
using TspServer.MongoDB.Main.GameSettings;

namespace TspServer.RpcServer.Api
{
    public class GameSettingsRemoteService : RpcHandler
    {
        public GameSettingsRemoteService(ClientSession user) : base(user)
        {
        }

        private BsonDocument ReadSettingsDocument(out GameDocument game)
        {
            BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;
            string requestedVersion = string.IsNullOrWhiteSpace(_session.LastGameVersion)
                ? GameSettingsContract.TargetVersion
                : _session.LastGameVersion;

            game = database.GetGameInfo(requestedVersion);
            if (game == null)
                throw new InvalidOperationException("Game document was not found for this client version.");

             BsonDocument settings = game.androidSettings?.DeepClone().AsBsonDocument ?? new BsonDocument();

            MaterializeRankedSeasonAliases(settings);
            NormalizeRankedLobbyMmrValidation(settings);


            return settings;
        }

        private static void MaterializeRankedSeasonAliases(BsonDocument settings)
         {
            if (settings == null) return;
            string[] stems =
            {
                "ranked_profile_settings_season",
                "ranked_2v2_profile_settings_season",
                "ranked_duel_profile_settings_season",
                "clan_ranked_profile_settings_season"
            };

            foreach (string stem in stems)
            {

                string dashedSource = stem + "-1";
                 string nativeSource = stem + "1";
                BsonValue canonical = null;

                if (settings.TryGetValue(dashedSource, out BsonValue dashed) &&
                    dashed != null && !dashed.IsBsonNull)
                {
                    canonical = dashed;
                }
                 else if (settings.TryGetValue(nativeSource, out BsonValue native) &&
                         native != null && !native.IsBsonNull)
                {
                    canonical = native;
                }
                if (canonical == null)
                    continue;

                for (int season = 1; season <= 9; season++)
                {
                    string nativeKey = stem + season;
                    if (!settings.Contains(nativeKey))
                    {
                        settings[nativeKey] = canonical.DeepClone();
                    }
                    string dashedKey = stem + "-" + season;
                    if (!settings.Contains(dashedKey))
                    {
                         settings[dashedKey] = canonical.DeepClone();
                    }
                 }
            }
        }

        private static void NormalizeRankedLobbyMmrValidation(BsonDocument settings)
        {

            string[] keys = settings.Names
                .Where(key => key.StartsWith("ranked_profile_settings_season", StringComparison.Ordinal) ||
                              key.StartsWith("ranked_2v2_profile_settings_season", StringComparison.Ordinal) ||
                             key.StartsWith("ranked_duel_profile_settings_season", StringComparison.Ordinal))
                .ToArray();

            foreach (string key in keys)
            {
                if (!settings.TryGetValue(key, out BsonValue value) || !value.IsString)
                    continue;
                try
                {
                   BsonDocument root = BsonDocument.Parse(value.AsString);
                    root["LobbyMaxMmrDifference"] = 100000.0;
                    settings[key] = root.ToJson();
                }
                catch (System.Exception)
                 {
                }
           }
        }

        private static byte[] SerializeEncryptedResponse(BsonDocument settings)
        {
            using MemoryStream responseStream = new MemoryStream();
            using (CodedOutputStream response = new CodedOutputStream(responseStream))
            {
                foreach (BsonElement element in settings.Elements)
                {
                    byte[] gameSetting = SerializeGameSetting(element);
                    if (gameSetting == null || gameSetting.Length == 0)
                        continue;

                    response.WriteTag(1, WireFormat.WireType.LengthDelimited);
                    response.WriteBytes(ByteString.CopyFrom(gameSetting));
                }
                response.Flush();
            }
            return responseStream.ToArray();
        }

         private static byte[] SerializeGameSetting(BsonElement element)
        {
            if (element.Value == null || element.Value.IsBsonNull)
                return null;

            using MemoryStream settingStream = new MemoryStream();
            using (CodedOutputStream output = new CodedOutputStream(settingStream))
             {
                output.WriteTag(1, WireFormat.WireType.LengthDelimited);
                output.WriteString(element.Name);

                 switch (element.Value.BsonType)
                {
                    case BsonType.Int32:
                        output.WriteTag(3, WireFormat.WireType.Varint);
                       output.WriteInt32(element.Value.AsInt32);
                        WriteSettingType(output, 1);
                        break;
                     case BsonType.Double:
                        output.WriteTag(4, WireFormat.WireType.Fixed32);
                        output.WriteFloat((float)element.Value.AsDouble);
                        WriteSettingType(output, 2);
                        break;

                    case BsonType.Boolean:
                        output.WriteTag(5, WireFormat.WireType.Varint);
                        output.WriteBool(element.Value.AsBoolean);
                        WriteSettingType(output, 3);
                        break;

                    case BsonType.Int64:
                        output.WriteTag(7, WireFormat.WireType.Varint);
                        output.WriteInt64(element.Value.AsInt64);
                        WriteSettingType(output, 4);
                        break;

                    case BsonType.DateTime:
                        output.WriteTag(7, WireFormat.WireType.Varint);
                        output.WriteInt64(element.Value.AsBsonDateTime.MillisecondsSinceEpoch);
                        WriteSettingType(output, 4);
                        break;

                    case BsonType.String:
                        output.WriteTag(2, WireFormat.WireType.LengthDelimited);
                        output.WriteString(element.Value.AsString);
                        break;

                    case BsonType.Document:
                   case BsonType.Array:
                        output.WriteTag(2, WireFormat.WireType.LengthDelimited);
                        output.WriteString(element.Value.ToJson());
                        break;

                    default:
                        output.WriteTag(2, WireFormat.WireType.LengthDelimited);
                        output.WriteString(element.Value.ToString());
                       break;
                }

                output.Flush();
            }
            return settingStream.ToArray();
        }

        private static void WriteSettingType(CodedOutputStream output, int value)
        {
            output.WriteTag(6, WireFormat.WireType.Varint);
           output.WriteEnum(value);
         }

        private void GetGameSettingsEncrypted2(BinaryValue[] values, string guid)
        {
             try
            {
                BsonDocument settings = ReadSettingsDocument(out GameDocument game);
                byte[] plainResponseBytes = SerializeEncryptedResponse(settings);
                byte[] sessionKey = _session.GetSessionKey();
                 byte[] sessionIv = _session.GetSessionIv();

                if (sessionKey == null || sessionKey.Length != 16)
                    throw new InvalidOperationException(
                        $"0.33 session AES key is unavailable or invalid: {sessionKey?.Length ?? 0}");
                if (sessionIv == null || sessionIv.Length != 16)
                    throw new InvalidOperationException(
                        $"0.33 session AES IV is unavailable or invalid: {sessionIv?.Length ?? 0}");

                byte[] encryptedResponseBytes = Protocol.EncryptAesCbc(
                    plainResponseBytes, sessionKey, sessionIv);

                BinaryValue result = new BinaryValue
                {
                    IsNull = false,
                    One = ByteString.CopyFrom(encryptedResponseBytes)
                };


                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                         Id = guid,
                        Return = result
                    }
                });
            }
            catch (System.Exception)
            {
                SendError(guid, 500);
            }
        }

        private void GetGameSettingsEncryptedLegacy(BinaryValue[] values, string guid)
        {
            try
            {
                GameSetting[] settings = ReadLegacySettings(out GameDocument game);
                var response = new GetGameSettingsResponse();
                response.GameSettings.Add(settings);

               BinaryValue result =
                    new RpcValueWriter(typeof(GetGameSettingsResponse)).ToBytes(response);


                _session.SendResponse(new ResponseMessage
                 {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = result
                    }
                });
            }
            catch (System.Exception)
            {
                SendError(guid, 500);
            }
        }

        private GameSetting[] ReadLegacySettings(out GameDocument game)
        {
           BsonDocument settings = ReadSettingsDocument(out game);
            var result = new List<GameSetting>();

            foreach (BsonElement element in settings.Elements)
            {
                try
                {
                    result.Add(element.GetGameSetting());
                }
                catch (ArgumentOutOfRangeException)
                {
                }
            }

            return result.ToArray();
        }

        private void GetGameSettings(BinaryValue[] values, string guid)
        {
             try
             {
                GameSetting[] settings = ReadLegacySettings(out GameDocument game);
                BinaryValue result =
                    new RpcValueWriter(typeof(GameSetting[])).ToBytes(settings);


                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = result
                    }
                });
            }
            catch (System.Exception)
            {
                SendError(guid, 500);
            }
       }

        private void SendError(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        public override void Invoke(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getGameSettingsEncrypted2":
                    GetGameSettingsEncrypted2(request.Params.ToArray(), request.Id);
                    break;
                case "getGameSettingsEncrypted":
                    GetGameSettingsEncryptedLegacy(request.Params.ToArray(), request.Id);
                    break;
                case "getGameSettings":
                    GetGameSettings(request.Params.ToArray(), request.Id);
                    break;
                default:
                    SendError(request.Id, 404);
                    break;
            }
        }
    }
}
