using System;
using MongoDB.Bson;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public static class DeviceEconomyGuard
    {
         private static int StarterGold
        {
            get
            {
                string raw = System.Environment.GetEnvironmentVariable("BOLT_ANTIDUPE_STARTER_GOLD");
                return int.TryParse(raw, out int value) ? System.Math.Max(0, value) : 500;
            }
        }

        public static int PrepareNewAccountStarterGold(ObjectId playerId, DeviceInfo device, string provider)
            => StarterGold;

        public static void ObserveSuccessfulLogin(ObjectId playerId, DeviceInfo device, string provider, bool accountCreatedNow) { }

        public static bool AreStronglyLinked(string playerA, string playerB) => false;

        public static void RecordBlockedMarketAttempt(string buyerId, string sellerId, string buyRequestId,
            string saleRequestId, int itemDefinitionId, double price, string reason) { }

        public static void RecordMarketSettlement(string buyerId, string sellerId, string buyRequestId,
            string saleRequestId, int itemDefinitionId, double transactionPrice, double sellerReceive) { }
    }
}
