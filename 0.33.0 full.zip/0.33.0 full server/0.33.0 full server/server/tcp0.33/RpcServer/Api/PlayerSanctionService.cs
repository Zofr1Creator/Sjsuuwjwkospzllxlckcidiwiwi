using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    internal static class PlayerSanctionService
    {
        public const string ListenerName = "PlayerInternalRemoteEventListener";
       public const string PlayerBannedEvent = "onPlayerBanned";

        public static int Ban(string playerId, int banCode, string reason, long until, string source)
        {
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out ObjectId objectId)) return 0;
            banCode = Math.Clamp(banCode, 1, 1000000);
            reason = SanitizeReason(reason);
            until = Math.Max(0, until);

            BoltMainDatabaseProvider.Instance.BanPlayer(objectId, reason, banCode, until, source);
            PersistInboxFallback(playerId, banCode, reason, until, source);

            byte[] payload = ContractWire.Build(w =>
            {
                w.Int32(1, banCode, emitDefault: true);
                w.String(2, reason);
                w.Varint(3, until, emitDefault: true);
            });

            int delivered = 0;
            foreach (PlayerInternalRemoteEventSender sender in ServerState.GetLiveEventSenders<PlayerInternalRemoteEventSender>(playerId).Distinct())
           {
                try
                {
                    sender.SendPlayerBanned(payload, playerId, source);
                    delivered++;
                }
                catch (System.Exception)
                 {
                }
            }

           if (string.IsNullOrWhiteSpace(source) || !source.StartsWith("swiss-photon:", StringComparison.Ordinal))
                _ = SwissSanctionBridgeClient.NotifyAsync(playerId, reason, source);
            return delivered;
        }

        public static int NotifyPersistedBan(string playerId, int banCode, string reason, long until, string source)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return 0;
            banCode = Math.Clamp(banCode, 1, 1000000);
            reason = SanitizeReason(reason);
            until = Math.Max(0, until);
            PersistInboxFallback(playerId, banCode, reason, until, source);
            byte[] payload = ContractWire.Build(w =>
            {
                w.Int32(1, banCode, emitDefault: true);
                w.String(2, reason);
               w.Varint(3, until, emitDefault: true);
            });
            int delivered = 0;
            foreach (PlayerInternalRemoteEventSender sender in ServerState.GetLiveEventSenders<PlayerInternalRemoteEventSender>(playerId).Distinct())
            {
                try { sender.SendPlayerBanned(payload, playerId, source); delivered++; }
                catch (System.Exception) { }
            }
            _ = SwissSanctionBridgeClient.NotifyAsync(playerId, reason, source);
            return delivered;
        }

        private static string SanitizeReason(string reason)
        {
            reason = (reason ?? "Anti-cheat violation").Replace("\r", " ").Replace("\n", " ").Trim();
            if (reason.Length == 0) reason = "Anti-cheat violation";
            return reason.Length <= 240 ? reason : reason.Substring(0, 240);
        }

        private static void PersistInboxFallback(string playerId, int code, string reason, long until, string source)
        {
            try
            {
                IMongoCollection<BsonDocument> collection = BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("system_messages");
                long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                string id = "global-ban-" + code + "-" + (until > 0 ? until.ToString() : "permanent");
                var filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("messageId", id);
                var doc = new BsonDocument
                {
                    ["playerId"] = playerId,
                    ["messageId"] = id,
                    ["type"] = 11,
                    ["isRead"] = false,
                    ["deleted"] = false,
                    ["created"] = now,
                    ["updated"] = now,
                    ["deleteAt"] = 0,
                    ["body"] = reason,
                    ["properties"] = new BsonDocument
                    {
                        ["source"] = source ?? "anti-cheat",
                        ["banCode"] = code,
                        ["until"] = until
                    }
                };
                collection.ReplaceOne(filter, doc, new ReplaceOptions { IsUpsert = true });
            }
             catch (System.Exception) { }
       }
    }

    public sealed class PlayerInternalRemoteEventSender : IEventSender
    {
       private readonly ClientSession _session;
        public string eventListenerName { get; set; } = PlayerSanctionService.ListenerName;
        public PlayerInternalRemoteEventSender(ClientSession user) => _session = user;

        public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse response = BoltEventContract.Create(eventListenerName, eventName, parameters ?? Array.Empty<object>());
            _session.SendResponse(new ResponseMessage { EventResponse = response });
        }

        public void SendPlayerBanned(byte[] payload, string playerId, string source)
        {
            EventResponse response = BoltEventContract.CreateRaw(eventListenerName, PlayerSanctionService.PlayerBannedEvent, payload ?? Array.Empty<byte>());
            _session.SendResponse(new ResponseMessage { EventResponse = response });
        }
    }
}
