using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using MongoDB.Bson;
using MongoDB.Driver;

namespace TspServer.RpcServer.Api
{

    internal sealed class RankedAuthorityRepository
    {
        private static readonly Lazy<RankedAuthorityRepository> LazyInstance =
            new Lazy<RankedAuthorityRepository>(() => new RankedAuthorityRepository());

        public static RankedAuthorityRepository Instance => LazyInstance.Value;

        private readonly IMongoCollection<BsonDocument> _profiles;
        private readonly IMongoCollection<BsonDocument> _matches;
        private readonly IMongoCollection<BsonDocument> _ledger;

        private RankedAuthorityRepository()
        {
            string connection = Environment.GetEnvironmentVariable("RANKED_MONGO_URI") ?? "mongodb://localhost:2077/";
            string databaseName = Environment.GetEnvironmentVariable("RANKED_MONGO_DATABASE") ?? "Main";
            var settings = MongoClientSettings.FromConnectionString(connection);
            settings.ServerSelectionTimeout = TimeSpan.FromSeconds(5);
            settings.ConnectTimeout = TimeSpan.FromSeconds(5);
            var database = new MongoClient(settings).GetDatabase(databaseName);
            database.RunCommand<BsonDocument>(new BsonDocument("ping", 1));

            _profiles = database.GetCollection<BsonDocument>("ranked_profiles");
            _matches = database.GetCollection<BsonDocument>("ranked_matches");
            _ledger = database.GetCollection<BsonDocument>("ranked_ledger");
            EnsureIndexes();
        }

        private void EnsureIndexes()
        {
            EnsureIndex(_profiles,
                Builders<BsonDocument>.IndexKeys.Ascending("playerId"),
                new CreateIndexOptions { Unique = true, Name = "ux_playerId" },
                critical: true);
            EnsureIndex(_matches,
                Builders<BsonDocument>.IndexKeys.Ascending("matchId"),
                new CreateIndexOptions { Unique = true, Name = "ux_matchId" },
                critical: true);
            EnsureIndex(_matches,
                 Builders<BsonDocument>.IndexKeys.Ascending("players.playerId").Descending("createdAt"),
                 new CreateIndexOptions { Name = "ix_ranked_match_player_created" },
                 critical: false);
            EnsureIndex(_matches,
                Builders<BsonDocument>.IndexKeys.Ascending("roster.playerId").Descending("createdAt"),
                new CreateIndexOptions { Name = "ix_roster_created" },
                critical: false);
            EnsureIndex(_matches,
               Builders<BsonDocument>.IndexKeys.Ascending("status").Ascending("version"),
                new CreateIndexOptions { Name = "ix_status_version" },
                critical: false);
            EnsureIndex(_matches,
                Builders<BsonDocument>.IndexKeys.Ascending("status").Descending("lastHeartbeatAt"),
                new CreateIndexOptions { Name = "ix_ranked_match_status_heartbeat" },
                critical: false);
            EnsureIndex(_ledger,
                Builders<BsonDocument>.IndexKeys.Ascending("key"),
                new CreateIndexOptions { Unique = true, Name = "ux_key" },
                critical: true);
            EnsureIndex(_ledger,
                 Builders<BsonDocument>.IndexKeys.Ascending("playerId").Ascending("kind").Descending("completedAt"),
                  new CreateIndexOptions { Name = "ix_ranked_ledger_player_kind" },
                 critical: false);
        }

        private static int ReadEnvInt(string name, int fallback)
        {
            return int.TryParse(Environment.GetEnvironmentVariable(name), out int value) ? value : fallback;
        }

        private static void EnsureIndex(
            IMongoCollection<BsonDocument> collection,
            IndexKeysDefinition<BsonDocument> keys,
            CreateIndexOptions options,
            bool critical)
        {
            try
            {
                collection.Indexes.CreateOne(new CreateIndexModel<BsonDocument>(keys, options));
            }
            catch (MongoCommandException ex) when (
                ex.Code == 85 ||
                 ex.Code == 86)
            {
                if (critical)
                {
                    BsonDocument wantedKeys = keys.Render(
                        collection.DocumentSerializer,
                       collection.Settings.SerializerRegistry);
                    bool sameIndex = collection.Indexes.List().ToList().Any(index =>
                        index.TryGetValue("key", out BsonValue raw) &&
                        raw.IsBsonDocument &&
                        raw.AsBsonDocument.Equals(wantedKeys) &&
                         (!options.Unique.GetValueOrDefault() ||
                         (index.TryGetValue("unique", out BsonValue unique) && unique.IsBoolean && unique.AsBoolean)));
                    if (!sameIndex)
                        throw;
                }
            }
        }

        public RankedQueueStatus LoadQueueStatus(string playerId, RankedModeContract mode)
        {
            EnsureProfile(playerId);
            EnsureStats(playerId);
            BsonDocument profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            if (profile == null)
                return new RankedQueueStatus { Mode = mode.Id };

            FixActiveMatch(playerId, profile);
            profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            BsonDocument stats = profile != null && profile.TryGetValue("stats", out BsonValue statsValue) && statsValue.IsBsonDocument
                 ? statsValue.AsBsonDocument
                : new BsonDocument();
            RankedModeContract[] banModes =
            {
                RankedModeContracts.Ranked5v5,
                RankedModeContracts.Ranked2v2,
                RankedModeContracts.RankedDuel
           };
            foreach (RankedModeContract banMode in banModes)
                ClearExpiredBan(playerId, stats, banMode);

            long nowUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            long banUntil = 0;
            int banCode = -1;
            foreach (RankedModeContract banMode in banModes)
            {
                string bp = banMode.StatPrefix;
                long until = GetLong(stats, bp + "banned_until", 0);
                if (until > nowUnix && until > banUntil)
                {
                    banUntil = until;
                    banCode = Math.Max(1, GetInt(stats, bp + "ban_code", 1));
                }
            }

            string basePrefix = RankedModeContracts.Ranked5v5.StatPrefix;
            RankedModeContract activeBanMode = null;
            if (banUntil > nowUnix)
            {
                foreach (RankedModeContract candidate in banModes)
                {
                    if (GetLong(stats, candidate.StatPrefix + "banned_until", 0) == banUntil)
                    {
                        activeBanMode = candidate;
                        break;
                    }
                }
            }
            string banPrefix = activeBanMode != null ? activeBanMode.StatPrefix : basePrefix;
            _profiles.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                Builders<BsonDocument>.Update
                    .Set("stats." + basePrefix + "ban_code", banUntil > nowUnix ? Math.Max(1, GetInt(stats, banPrefix + "ban_code", 1)) : -1)
                    .Set("stats." + basePrefix + "ban_duration", banUntil > nowUnix ? Math.Max(0, GetInt(stats, banPrefix + "ban_duration", 0)) : 0)
                    .Set("stats." + basePrefix + "banned_match_no", banUntil > nowUnix ? Math.Max(0, GetInt(stats, banPrefix + "banned_match_no", 0)) : 0)
                    .Set("stats." + basePrefix + "ban_reason", banUntil > nowUnix ? Math.Max(0, GetInt(stats, banPrefix + "ban_reason", 0)) : 0)
                    .Set("stats." + basePrefix + "banned_until", banUntil > nowUnix ? ToClientStatInt(banUntil) : 0)
                    .Set("updatedAt", DateTime.UtcNow));

            string prefix = mode.StatPrefix;

            var status = new RankedQueueStatus
            {
                Mode = mode.Id,
                Mmr = Math.Max(RankedSettings.For(mode).MmrLowerThreshold, GetInt(stats, prefix + "current_mmr", 500)),
                Rank = GetInt(stats, prefix + "rank", 0),
                BannedUntil = banUntil,
                BanCode = banCode,
                LastMatchRunning = GetInt(stats, prefix + "last_match_running", 0),
                LastMatchStatus = GetInt(stats, prefix + "last_match_status", 0),
                LastMatchStartTime = GetLong(stats, prefix + "last_match_start_time", 0)
            };

            bool hasDurableActiveMatch = false;
            if (profile != null && profile.TryGetValue("activeMatch", out BsonValue activeValue) && activeValue.IsBsonDocument)
            {
                BsonDocument active = activeValue.AsBsonDocument;
                string activeStatus = active.GetValue("status", string.Empty).ToString();
                string activeMatchId = active.GetValue("matchId", string.Empty).ToString();
                hasDurableActiveMatch = !string.IsNullOrWhiteSpace(activeMatchId) && !IsTerminalStatus(activeStatus);
                if (hasDurableActiveMatch)
                {

                    status.LastMatchRunning = 1;
                    status.ActiveMatchId = activeMatchId;
                    status.ActiveRoomId = active.GetValue("roomId", string.Empty).ToString();
                    status.ActiveMode = active.GetValue("mode", string.Empty).ToString();
                    status.ActiveMatchStatus = activeStatus;
                }
            }

            if (status.LastMatchRunning != 0 && !hasDurableActiveMatch)
            {
                _profiles.UpdateOne(
                   Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                    Builders<BsonDocument>.Update
                        .Set("stats." + prefix + "last_match_running", 0)
                        .Set("stats." + prefix + "last_match_status", 0)
                        .Set("updatedAt", DateTime.UtcNow));
                status.LastMatchRunning = 0;
                status.LastMatchStatus = 0;
            }
            return status;
        }

        public void PromoteActiveMatchFromPhotonPresence(string playerId, string roomId, string modeName, string region, string gameVersion)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(roomId))
                return;

            EnsureProfile(playerId);
            EnsureStats(playerId);
            BsonDocument profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            if (profile == null || !profile.TryGetValue("activeMatch", out BsonValue activeValue) || !activeValue.IsBsonDocument)
                return;

            BsonDocument active = activeValue.AsBsonDocument;
            string matchId = active.GetValue("matchId", string.Empty).ToString();
            string currentStatus = active.GetValue("status", string.Empty).ToString();
            if (string.IsNullOrWhiteSpace(matchId) || IsTerminalStatus(currentStatus))
                return;

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
            if (match == null || GetBool(match, "finalized", false))
                return;

            string dbStatus = match.GetValue("status", currentStatus).ToString();
            if (IsTerminalStatus(dbStatus))
                return;

            string durableMode = active.GetValue("mode", match.GetValue("mode", modeName ?? string.Empty)).ToString();
            RankedModeContract contract = ResolveMode(durableMode);

            string promotedStatus = string.Equals(dbStatus, "Running", StringComparison.OrdinalIgnoreCase) ||
                                     string.Equals(dbStatus, "Disconnected", StringComparison.OrdinalIgnoreCase)
                 ? "Running"
                 : "Joined";

            DateTime now = DateTime.UtcNow;
            var updates = Builders<BsonDocument>.Update
                .Set("activeMatch.roomId", roomId)
                .Set("activeMatch.status", promotedStatus)
               .Set("activeMatch.lastSeenAt", now)
                .Set("activeMatch.photonJoined", true)
                .Set("activeMatch.region", region ?? string.Empty)
                .Set("activeMatch.gameVersion", "0.33.0F1")
                .Set("stats." + contract.StatPrefix + "last_match_running", 1)
                .Set("stats." + contract.StatPrefix + "last_match_status", 0)
                .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 1)
                .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                .Set("updatedAt", now);

            UpdateResult write = _profiles.UpdateOne(
                Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                    Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                    Builders<BsonDocument>.Filter.In("activeMatch.status", new[] { "Ready", "Joined", "Running", "Disconnected" }),
                    Builders<BsonDocument>.Filter.Ne("activeMatch.terminalExit", true)),
                updates);

        }

        public BsonDocument GetActiveRejoinDescriptor(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return null;

            EnsureProfile(playerId);
            EnsureStats(playerId);
            BsonDocument profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            if (profile == null)
                return null;

            FixActiveMatch(playerId, profile);

            RefreshFromRoster(playerId);

            profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();

            if (profile == null || !profile.TryGetValue("activeMatch", out BsonValue activeValue) || !activeValue.IsBsonDocument)
            {
                if (!RecoverFromRoster(playerId))
                    return null;
                profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
                if (profile == null || !profile.TryGetValue("activeMatch", out activeValue) || !activeValue.IsBsonDocument)
                    return null;
            }

            BsonDocument active = activeValue.AsBsonDocument;
            string status = active.GetValue("status", string.Empty).ToString();
            string matchId = active.GetValue("matchId", string.Empty).ToString();
            string roomId = active.GetValue("roomId", string.Empty).ToString();
            string mode = active.GetValue("mode", string.Empty).ToString();
            if (string.IsNullOrWhiteSpace(matchId) || string.IsNullOrWhiteSpace(roomId) || IsTerminalStatus(status))
                return null;

            if (GetBool(active, "terminalExit", false) && !GetBool(active, "penaltyApplied", false) &&
                IsClientRejoinableStatus(status))
            {
                DateTime lastSeen = DateTime.MinValue;
                if (active.TryGetValue("disconnectedAt", out BsonValue dv) && dv.IsBsonDateTime)
                    lastSeen = dv.AsBsonDateTime.ToUniversalTime();
                else if (active.TryGetValue("lastSeenAt", out BsonValue lv) && lv.IsBsonDateTime)
                    lastSeen = lv.AsBsonDateTime.ToUniversalTime();
                if (lastSeen == DateTime.MinValue || lastSeen >= DateTime.UtcNow.AddSeconds(-3360))
                {
                    _profiles.UpdateOne(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Update
                            .Set("activeMatch.terminalExit", false)
                            .Set("activeMatch.penaltyApplied", false)
                            .Set("updatedAt", DateTime.UtcNow));
                    active["terminalExit"] = false;
                }
            }

            if (!IsClientRejoinableActiveMatch(active, status))
                return null;

            if (!IsClientFacingRankedRoomAlias(mode, roomId))
            {
                return null;
            }

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
            if (match == null || GetBool(match, "finalized", false))
                return null;

            string dbStatus = match.GetValue("status", status).ToString();
            if (IsTerminalStatus(dbStatus) || string.Equals(dbStatus, "Finalizing", StringComparison.OrdinalIgnoreCase))
                return null;

            string region = active.GetValue("region", match.GetValue("region", string.Empty)).ToString();

            const string gameVersion = "0.33.0F1";
            string wireMode = mode;
            if (string.Equals(mode, "Ranked5v5", StringComparison.OrdinalIgnoreCase)) wireMode = "RankedDefuse";
            else if (string.Equals(mode, "Ranked2v2", StringComparison.OrdinalIgnoreCase)) wireMode = "Ranked2v2";
            else if (string.Equals(mode, "RankedDuel", StringComparison.OrdinalIgnoreCase)) wireMode = "RankedDuel";


            return new BsonDocument
            {
                ["matchId"] = matchId,
                ["roomName"] = roomId,
                ["region"] = region,
                ["gameModeId"] = wireMode,
                ["status"] = status,
                ["dbStatus"] = dbStatus,
                ["gameType"] = 0,
                ["gameVersion"] = gameVersion
            };
        }

        private bool RefreshFromRoster(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return false;

            try
            {
                FilterDefinition<BsonDocument> live = Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Ne("finalized", true),
                    Builders<BsonDocument>.Filter.In("status", new[] { "Ready", "Running", "Disconnected" }),
                    Builders<BsonDocument>.Filter.Eq("roster.playerId", playerId));

                BsonDocument match = _matches.Find(live)
                   .Sort(Builders<BsonDocument>.Sort.Descending("createdAt"))
                    .FirstOrDefault();
                if (match == null)
                    return false;

                string matchId = match.GetValue("matchId", string.Empty).ToString();
                string roomId = match.GetValue("roomId", matchId).ToString();
                string modeName = match.GetValue("mode", "RankedDefuse").ToString();
                if (string.IsNullOrWhiteSpace(matchId) || string.IsNullOrWhiteSpace(roomId))
                    return false;

                BsonDocument runtimePlayer = null;
                if (match.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray)
                {
                    runtimePlayer = playersValue.AsBsonArray
                       .Where(x => x.IsBsonDocument)
                       .Select(x => x.AsBsonDocument)
                       .FirstOrDefault(x => string.Equals(
                           x.GetValue("playerId", string.Empty).ToString(),
                           playerId,
                           StringComparison.Ordinal));
                }

                if (runtimePlayer != null &&
                    (GetBool(runtimePlayer, "kicked", false) ||
                     GetBool(runtimePlayer, "penaltyApplied", false)))
                {
                    return false;
                }
                string dbStatus = match.GetValue("status", "Running").ToString();
                bool inactive = runtimePlayer != null && GetBool(runtimePlayer, "inactive", false);
                DateTime? disconnectedAt = null;
                if (runtimePlayer != null &&
                    runtimePlayer.TryGetValue("disconnectedAt", out BsonValue disconnectedValue) &&
                    disconnectedValue.IsBsonDateTime)
                {
                    disconnectedAt = disconnectedValue.AsBsonDateTime.ToUniversalTime();
                    inactive = true;
                }

                string profileStatus;
                if (string.Equals(dbStatus, "Ready", StringComparison.OrdinalIgnoreCase))
                    profileStatus = "Ready";
                else if (inactive || string.Equals(dbStatus, "Disconnected", StringComparison.OrdinalIgnoreCase))
                    profileStatus = "Disconnected";
                else
                    profileStatus = "Running";

                RankedModeContract mode = ResolveMode(modeName);
                DateTime observed = DateTime.UtcNow;
                if (runtimePlayer != null &&
                    runtimePlayer.TryGetValue("lastSeenAt", out BsonValue seenValue) &&
                    seenValue.IsBsonDateTime)
                    observed = seenValue.AsBsonDateTime.ToUniversalTime();
                if (disconnectedAt.HasValue)
                    observed = disconnectedAt.Value;

                var active = new BsonDocument
                {
                    ["matchId"] = matchId,
                    ["roomId"] = roomId,
                    ["mode"] = modeName,
                    ["region"] = match.GetValue("region", "Europe").ToString(),
                    ["selectedLevel"] = match.GetValue("selectedLevel", string.Empty).ToString(),
                    ["status"] = profileStatus,
                    ["lastSeenAt"] = observed,
                    ["terminalExit"] = false,
                    ["penaltyApplied"] = false,
                    ["photonJoined"] = !string.Equals(profileStatus, "Ready", StringComparison.OrdinalIgnoreCase),
                    ["refreshedFromRoster"] = true,
                    ["updatedAt"] = DateTime.UtcNow
                };
                if (disconnectedAt.HasValue)
                    active["disconnectedAt"] = disconnectedAt.Value;

                EnsureProfile(playerId);
                UpdateResult write = _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Filter.Or(
                            Builders<BsonDocument>.Filter.Exists("activeMatch", false),
                            Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                            Builders<BsonDocument>.Filter.In("activeMatch.status", new[] { "Finished", "Cancelled", "Annulled", "Kicked", "Abandoned" }))),
                    Builders<BsonDocument>.Update
                        .Set("activeMatch", active)
                        .Set("stats." + mode.StatPrefix + "last_match_running", 1)
                        .Set("stats." + mode.StatPrefix + "last_match_status", 0)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 1)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                        .Set("updatedAt", DateTime.UtcNow));

                bool refreshed = write.MatchedCount > 0;
                return refreshed;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        private bool RecoverFromRoster(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return false;

            try
            {
                FilterDefinition<BsonDocument> live = Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Ne("finalized", true),
                    Builders<BsonDocument>.Filter.In("status", new[] { "Ready", "Joined", "Running", "Disconnected" }),
                    Builders<BsonDocument>.Filter.Or(
                        Builders<BsonDocument>.Filter.Eq("roster.playerId", playerId),
                        Builders<BsonDocument>.Filter.Eq("players.playerId", playerId)));

                BsonDocument match = _matches.Find(live)
                    .Sort(Builders<BsonDocument>.Sort.Descending("createdAt"))
                    .FirstOrDefault();
                if (match == null)
                    return false;

                string matchId = match.GetValue("matchId", string.Empty).ToString();
                string roomId = match.GetValue("roomId", matchId).ToString();
                string modeName = match.GetValue("mode", "RankedDefuse").ToString();
                string status = match.GetValue("status", "Ready").ToString();
                if (string.IsNullOrWhiteSpace(matchId) || string.IsNullOrWhiteSpace(roomId) || IsTerminalStatus(status))
                    return false;

                RankedModeContract mode = ResolveMode(modeName);
                DateTime now = DateTime.UtcNow;
                var active = new BsonDocument
                {
                    ["matchId"] = matchId,
                    ["roomId"] = roomId,
                    ["mode"] = modeName,
                    ["region"] = match.GetValue("region", "Europe").ToString(),
                    ["selectedLevel"] = match.GetValue("selectedLevel", string.Empty).ToString(),
                    ["status"] = status,
                    ["lastSeenAt"] = now,
                    ["terminalExit"] = false,
                    ["penaltyApplied"] = false,
                    ["photonJoined"] = !string.Equals(status, "Ready", StringComparison.OrdinalIgnoreCase),
                    ["recoveredFromRoster"] = true,
                    ["updatedAt"] = now
                };

                EnsureProfile(playerId);
                UpdateResult write = _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Filter.Or(
                            Builders<BsonDocument>.Filter.Exists("activeMatch", false),
                             Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                            Builders<BsonDocument>.Filter.In("activeMatch.status", new[] { "Finished", "Cancelled", "Annulled" }))),
                    Builders<BsonDocument>.Update
                       .Set("activeMatch", active)
                        .Set("stats." + mode.StatPrefix + "last_match_running", 1)
                         .Set("stats." + mode.StatPrefix + "last_match_status", 0)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 1)
                         .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                         .Set("updatedAt", now));

                bool recovered = write.MatchedCount == 1;
                return recovered;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        private static bool GetBool(BsonDocument doc, string key, bool fallback)
        {
            if (doc == null || !doc.TryGetValue(key, out BsonValue value) || value.IsBsonNull) return fallback;
            if (value.IsBoolean) return value.AsBoolean;
            if (value.IsInt32) return value.AsInt32 != 0;
            if (value.IsInt64) return value.AsInt64 != 0;
            return bool.TryParse(value.ToString(), out bool parsed) ? parsed : fallback;
        }

        public BsonDocument GetLegacyStats(string playerId)
        {
            EnsureProfile(playerId);
            EnsureStats(playerId);

            BsonDocument liveRejoin = GetActiveRejoinDescriptor(playerId);
            BsonDocument profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            if (profile == null || !profile.TryGetValue("stats", out BsonValue value) || !value.IsBsonDocument)
                return new BsonDocument();

            BsonDocument stats = value.AsBsonDocument.DeepClone().AsBsonDocument;
            RankedModeContract[] rankedModes =
            {
                RankedModeContracts.Ranked5v5,
                RankedModeContracts.Ranked2v2,
               RankedModeContracts.RankedDuel
            };
            foreach (RankedModeContract contract in rankedModes)
                ClearExpiredBan(playerId, stats, contract);

            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            RankedModeContract? effectiveMode = null;
            long effectiveUntil = 0;
            foreach (RankedModeContract contract in rankedModes)
            {
                long until = GetLong(stats, contract.StatPrefix + "banned_until", 0);
                if (until > now && until > effectiveUntil)
                {
                    effectiveUntil = until;
                    effectiveMode = contract;
                }
            }

            string generic = RankedModeContracts.Ranked5v5.StatPrefix;
            if (effectiveMode != null)
            {
                string source = effectiveMode.StatPrefix;
                stats[generic + "banned_until"] = ToClientStatInt(effectiveUntil);
                stats[generic + "ban_code"] = Math.Max(1, GetInt(stats, source + "ban_code", 1));
                stats[generic + "ban_duration"] = Math.Max(0, GetInt(stats, source + "ban_duration", 0));
                stats[generic + "banned_match_no"] = Math.Max(0, GetInt(stats, source + "banned_match_no", 0));
                stats[generic + "ban_reason"] = Math.Max(0, GetInt(stats, source + "ban_reason", 0));
            }
            else
            {
                stats[generic + "ban_code"] = -1;
                stats[generic + "ban_duration"] = 0;
                stats[generic + "banned_match_no"] = 0;
                stats[generic + "ban_reason"] = 0;
                stats[generic + "banned_until"] = 0;
            }

            _profiles.UpdateOne(
                 Builders<BsonDocument>.Filter.Eq("playerId", playerId),
               Builders<BsonDocument>.Update
                    .Set("stats." + generic + "ban_code", GetInt(stats, generic + "ban_code", -1))
                    .Set("stats." + generic + "ban_duration", GetInt(stats, generic + "ban_duration", 0))
                    .Set("stats." + generic + "banned_match_no", GetInt(stats, generic + "banned_match_no", 0))
                    .Set("stats." + generic + "ban_reason", GetInt(stats, generic + "ban_reason", 0))
                    .Set("stats." + generic + "banned_until", GetInt(stats, generic + "banned_until", 0))
                    .Set("updatedAt", DateTime.UtcNow));

            if (profile.TryGetValue("activeMatch", out BsonValue activeValue) && activeValue.IsBsonDocument)
            {
                BsonDocument active = activeValue.AsBsonDocument;
                string activeStatus = active.GetValue("status", string.Empty).ToString();
                string activeMode = active.GetValue("mode", string.Empty).ToString();
                if (IsClientRejoinableActiveMatch(active, activeStatus) && !IsTerminalStatus(activeStatus))
                {
                    RankedModeContract contract = string.Equals(activeMode, "Ranked2v2", StringComparison.OrdinalIgnoreCase)
                        ? RankedModeContracts.Ranked2v2
                        : string.Equals(activeMode, "RankedDuel", StringComparison.OrdinalIgnoreCase)
                            ? RankedModeContracts.RankedDuel
                            : RankedModeContracts.Ranked5v5;
                    stats[contract.StatPrefix + "last_match_running"] = 1;
                    stats[contract.StatPrefix + "last_match_status"] = 0;

                    string genericLifecycle = RankedModeContracts.Ranked5v5.StatPrefix;
                    stats[genericLifecycle + "last_match_running"] = 1;
                    stats[genericLifecycle + "last_match_status"] = 0;
                    stats[genericLifecycle + "last_match_start_time"] =
                        ToClientStatInt(GetLong(stats, contract.StatPrefix + "last_match_start_time", 0));
                    stats[genericLifecycle + "last_activity_time1"] =
                        GetInt(stats, contract.StatPrefix + "last_activity_time1", 0);
                    stats[genericLifecycle + "last_activity_time2"] =
                        GetInt(stats, contract.StatPrefix + "last_activity_time2", 0);
                }
            }
            return stats;
        }

        private void EnsureStats(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;

            var required = new Dictionary<string, BsonValue>();
            Action<RankedModeContract> add = mode =>
            {
                string p = mode.StatPrefix;
                required[p + "current_mmr"] = 500;
                required[p + "rank"] = 0;
                required[p + "best_rank"] = 0;
                required[p + "best_rank_history1"] = 0;
                required[p + "played_matches"] = 0;
                required[p + "won_match_count"] = 0;
                required[p + "calibration_match_count"] = 0;
                required[p + "calibration_won_match_count"] = 0;
                required[p + "calibration_status"] = 0;
                required[p + "client_key_contract"] = 1;
                required[p + "ban_code"] = -1;
                required[p + "ban_duration"] = 0;
                required[p + "banned_match_no"] = 0;
                required[p + "ban_reason"] = 0;
                required[p + "banned_until"] = 0;
                required[p + "last_match_status"] = 0;
                required[p + "last_match_running"] = 0;
                required[p + "last_match_start_time"] = 0;
                required[p + "last_activity_time1"] = 0;
                required[p + "last_activity_time2"] = 0;
            };
            add(RankedModeContracts.Ranked5v5);
            add(RankedModeContracts.Ranked2v2);
            add(RankedModeContracts.RankedDuel);

            BsonDocument profile = _profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId))
                .Project(Builders<BsonDocument>.Projection.Include("stats"))
                .FirstOrDefault();
            BsonDocument stats = profile != null && profile.TryGetValue("stats", out BsonValue sv) && sv.IsBsonDocument
                ? sv.AsBsonDocument
                : new BsonDocument();

            var updates = new List<UpdateDefinition<BsonDocument>>();
            foreach (KeyValuePair<string, BsonValue> item in required)
            {
                if (!stats.Contains(item.Key))
                {
                    updates.Add(Builders<BsonDocument>.Update.Set("stats." + item.Key, item.Value));
                    continue;
                }

                if (item.Key.EndsWith("current_mmr", StringComparison.Ordinal))
                {
                    int existingMmr = GetInt(stats, item.Key, 0);
                    if (existingMmr <= 0)
                        updates.Add(Builders<BsonDocument>.Update.Set("stats." + item.Key, 500));
                }
            }
            if (updates.Count == 0) return;

            updates.Add(Builders<BsonDocument>.Update.Set("updatedAt", DateTime.UtcNow));
            _profiles.UpdateOne(
               Builders<BsonDocument>.Filter.Eq("playerId", playerId),
               Builders<BsonDocument>.Update.Combine(updates));
        }

        private void ClearExpiredBan(string playerId, BsonDocument stats, RankedModeContract mode)
        {
            string p = mode.StatPrefix;
            long until = GetLong(stats, p + "banned_until", 0);
            if (until <= 0 || until > DateTimeOffset.UtcNow.ToUnixTimeSeconds())
                return;

            stats[p + "ban_code"] = -1;
            stats[p + "ban_duration"] = 0;
            stats[p + "ban_reason"] = 0;
            stats[p + "banned_until"] = 0;
            _profiles.UpdateOne(
                 Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                Builders<BsonDocument>.Update
                    .Set("stats." + p + "ban_code", -1)
                    .Set("stats." + p + "ban_duration", 0)
                    .Set("stats." + p + "ban_reason", 0)
                     .Set("stats." + p + "banned_until", 0)
                    .Set("updatedAt", DateTime.UtcNow));
        }

        private void FixActiveMatch(string playerId, BsonDocument profile)
        {
            if (!profile.TryGetValue("activeMatch", out BsonValue activeValue) || !activeValue.IsBsonDocument)
                return;
            BsonDocument active = activeValue.AsBsonDocument;
            string matchId = active.GetValue("matchId", string.Empty).ToString();
            if (string.IsNullOrWhiteSpace(matchId))
                return;

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId))
                .Project(Builders<BsonDocument>.Projection
                    .Include("status")
                    .Include("finalized")
                    .Include("mode")
                    .Include("confirmationDeadlineAt"))
                .FirstOrDefault();
            if (match == null)
            {
                string orphanModeName = active.GetValue("mode", string.Empty).ToString();
                RankedModeContract orphanMode = ResolveMode(orphanModeName);
                _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId)),
                    Builders<BsonDocument>.Update
                        .Unset("activeMatch")
                        .Set("stats." + orphanMode.StatPrefix + "last_match_running", 0)
                        .Set("stats." + orphanMode.StatPrefix + "last_match_status", 0)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 0)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                        .Set("updatedAt", DateTime.UtcNow));
                return;
            }
            string status = match.GetValue("status", string.Empty).ToString();

            if (string.Equals(status, "Confirmation", StringComparison.OrdinalIgnoreCase) &&
               match.TryGetValue("confirmationDeadlineAt", out BsonValue deadlineValue) &&
              deadlineValue.IsBsonDateTime &&
               deadlineValue.AsBsonDateTime.ToUniversalTime() <= DateTime.UtcNow)
            {
                TryCancelPreRunningMatch(matchId, "confirmation-expired-after-recovery");
                return;
            }

            bool terminal = match.GetValue("finalized", false).ToBoolean() || IsTerminalStatus(status);
            if (!terminal)
                return;

            string modeName = active.GetValue("mode", match.GetValue("mode", string.Empty)).ToString();
            RankedModeContract mode = ResolveMode(modeName);
            _profiles.UpdateOne(
                Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                    Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId)),
                Builders<BsonDocument>.Update
                    .Unset("activeMatch")
                    .Set("stats." + mode.StatPrefix + "last_match_running", 0)
                     .Set("stats." + mode.StatPrefix + "last_match_status", 0)
                    .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 0)
                    .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                    .Set("updatedAt", DateTime.UtcNow));
        }

        private static RankedModeContract ResolveMode(string modeName)
        {
            if (string.Equals(modeName, RankedModeContracts.Ranked2v2.WireName, StringComparison.OrdinalIgnoreCase))
                return RankedModeContracts.Ranked2v2;
            if (string.Equals(modeName, RankedModeContracts.RankedDuel.WireName, StringComparison.OrdinalIgnoreCase))
                return RankedModeContracts.RankedDuel;
            return RankedModeContracts.Ranked5v5;
        }

        private static bool IsClientFacingRankedRoomAlias(string mode, string roomId)
        {
            if (string.IsNullOrWhiteSpace(roomId)) return false;
            if (string.Equals(mode, "Ranked2v2", StringComparison.OrdinalIgnoreCase))
                return roomId.StartsWith("Ranked2v2_", StringComparison.OrdinalIgnoreCase);
            if (string.Equals(mode, "RankedDuel", StringComparison.OrdinalIgnoreCase))
                return roomId.StartsWith("RankedDuel_", StringComparison.OrdinalIgnoreCase);
            return roomId.StartsWith("RankedDefuse_", StringComparison.OrdinalIgnoreCase) ||
                    roomId.StartsWith("Ranked5v5_", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsClientRejoinableStatus(string status)
        {

            return string.Equals(status, "Ready", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Joined", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Running", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Disconnected", StringComparison.OrdinalIgnoreCase);
        }
        private static bool IsClientRejoinableActiveMatch(BsonDocument active, string status)
        {
            if (GetBool(active, "penaltyApplied", false))
                return false;

            bool terminalExit = GetBool(active, "terminalExit", false);
            if (terminalExit)
            {
                if (!string.Equals(status, "Disconnected", StringComparison.OrdinalIgnoreCase))
                    return false;

                DateTime disconnectedAt = DateTime.MinValue;
                if (active.TryGetValue("disconnectedAt", out BsonValue disconnectedValue) &&
                    disconnectedValue.IsBsonDateTime)
                    disconnectedAt = disconnectedValue.AsBsonDateTime.ToUniversalTime();
                else if (active.TryGetValue("lastSeenAt", out BsonValue lastSeenValue) &&
                         lastSeenValue.IsBsonDateTime)
                    disconnectedAt = lastSeenValue.AsBsonDateTime.ToUniversalTime();

                return disconnectedAt != DateTime.MinValue &&
                       disconnectedAt >= DateTime.UtcNow.AddSeconds(-3360);
            }
            if (string.Equals(status, "Disconnected", StringComparison.OrdinalIgnoreCase))
            {
                DateTime disconnectedAt = DateTime.MinValue;
                if (active.TryGetValue("disconnectedAt", out BsonValue disconnectedValue) &&
                   disconnectedValue.IsBsonDateTime)
                    disconnectedAt = disconnectedValue.AsBsonDateTime.ToUniversalTime();
                else if (active.TryGetValue("lastSeenAt", out BsonValue lastSeenValue) &&
                         lastSeenValue.IsBsonDateTime)
                    disconnectedAt = lastSeenValue.AsBsonDateTime.ToUniversalTime();

                return disconnectedAt != DateTime.MinValue &&
                       disconnectedAt >= DateTime.UtcNow.AddSeconds(-3360);
            }

            if (string.Equals(status, "Joined", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "Running", StringComparison.OrdinalIgnoreCase))
                return true;

            if (string.Equals(status, "Ready", StringComparison.OrdinalIgnoreCase))
            {

                DateTime readySeenAt = DateTime.MinValue;
                if (active.TryGetValue("lastSeenAt", out BsonValue readyLastSeen) && readyLastSeen.IsBsonDateTime)
                    readySeenAt = readyLastSeen.AsBsonDateTime.ToUniversalTime();
                else if (active.TryGetValue("updatedAt", out BsonValue readyUpdated) && readyUpdated.IsBsonDateTime)
                    readySeenAt = readyUpdated.AsBsonDateTime.ToUniversalTime();

                return GetBool(active, "photonJoined", false) ||
                       (readySeenAt != DateTime.MinValue && readySeenAt >= DateTime.UtcNow.AddSeconds(-135));
            }

            return false;
        }

        private static bool IsTerminalStatus(string status)
        {
            return string.Equals(status, "Finished", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(status, "Cancelled", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Canceled", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Annulled", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Failed", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "GameFailed", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Kicked", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(status, "Abandoned", StringComparison.OrdinalIgnoreCase);
        }

        private void EnsureProfile(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;
            if (_profiles.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId))
                .Project(Builders<BsonDocument>.Projection.Include("_id"))
                .FirstOrDefault() != null)
                return;

            var stats = new BsonDocument();
            Action<RankedModeContract> defaults = mode =>
            {
                string p = mode.StatPrefix;
                stats[p + "current_mmr"] = 500;
                stats[p + "rank"] = 0;
                stats[p + "best_rank"] = 0;
                stats[p + "best_rank_history1"] = 0;
                stats[p + "played_matches"] = 0;
                stats[p + "won_match_count"] = 0;
                stats[p + "calibration_match_count"] = 0;
                stats[p + "calibration_won_match_count"] = 0;
                stats[p + "calibration_status"] = 0;
                stats[p + "client_key_contract"] = 1;
                stats[p + "ban_code"] = -1;
                stats[p + "ban_duration"] = 0;
                stats[p + "banned_match_no"] = 0;
                stats[p + "ban_reason"] = 0;
                stats[p + "banned_until"] = 0;
                stats[p + "last_match_status"] = 0;
                stats[p + "last_match_running"] = 0;
                stats[p + "last_match_start_time"] = 0;
                stats[p + "last_activity_time1"] = 0;
                stats[p + "last_activity_time2"] = 0;
            };
            defaults(RankedModeContracts.Ranked5v5);
            defaults(RankedModeContracts.Ranked2v2);
            defaults(RankedModeContracts.RankedDuel);

            var applied = new HashSet<RankedModeId>();
            foreach (BsonDocument row in _ledger.Find(Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("kind", "result"),
                    Builders<BsonDocument>.Filter.Eq("status", "Done"),
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId)))
                .Sort(Builders<BsonDocument>.Sort.Descending("completedAt").Descending("createdAt"))
                .Limit(32).ToList())
            {
                RankedModeContract mode = ResolveMode(row.GetValue("mode", string.Empty).ToString());
                if (!applied.Add(mode.Id) || !row.TryGetValue("result", out BsonValue rv) || !rv.IsBsonDocument)
                    continue;
                BsonDocument result = rv.AsBsonDocument;
                int Get(string key, int fallback = 0)
                {
                    try { return result.TryGetValue(key, out BsonValue value) && value.IsNumeric ? value.ToInt32() : fallback; }
                    catch { return fallback; }
                }
                string p = mode.StatPrefix;
                stats[p + "current_mmr"] = Get("newMmr", 500);
                stats[p + "rank"] = Get("newRank");
                stats[p + "best_rank"] = Get("bestRank");
                stats[p + "played_matches"] = Get("playedMatches");
                stats[p + "won_match_count"] = Get("wonMatches");
                stats[p + "calibration_match_count"] = Get("calibrationMatchCount");
                stats[p + "calibration_won_match_count"] = Get("calibrationWonMatches");
                int requiredCalibration = Math.Max(1, RankedSettings.For(mode).CalibrationMatchesCount);
                int calibrationPlayed = Get("calibrationMatchCount");
                int playedMatches = Get("playedMatches");
                stats[p + "calibration_status"] = calibrationPlayed < requiredCalibration
                    ? 0
                    : playedMatches <= requiredCalibration
                        ? 1
                        : 2;
                stats[p + "last_match_status"] = Get("lastMatchStatus");
            }

            foreach (RankedModeContract mode in new[] { RankedModeContracts.Ranked5v5, RankedModeContracts.Ranked2v2, RankedModeContracts.RankedDuel })
            {
                long finalizedCount = _matches.CountDocuments(Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("players.playerId", playerId),
                    Builders<BsonDocument>.Filter.Eq("finalized", true),
                    Builders<BsonDocument>.Filter.Eq("status", "Finished"),
                    Builders<BsonDocument>.Filter.Eq("mode", mode.WireName)));
                string playedKey = mode.StatPrefix + "played_matches";
                int currentPlayed = GetInt(stats, playedKey, 0);
                stats[playedKey] = Math.Max(currentPlayed, ToClientStatInt(finalizedCount));
            }

            var penaltyModes = new HashSet<RankedModeId>();
            foreach (BsonDocument row in _ledger.Find(Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("kind", "penalty"),
                     Builders<BsonDocument>.Filter.Eq("status", "Done"),
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId)))
                .Sort(Builders<BsonDocument>.Sort.Descending("completedAt").Descending("createdAt"))
                .Limit(16).ToList())
            {
                RankedModeContract mode = ResolveMode(row.GetValue("mode", string.Empty).ToString());
                if (!penaltyModes.Add(mode.Id)) continue;
                string p = mode.StatPrefix;
                stats[p + "ban_code"] = 1;
                stats[p + "ban_duration"] = GetInt(row, "banSeconds", 0);
                stats[p + "banned_match_no"] = GetInt(row, "banNumber", 1);
                stats[p + "ban_reason"] = GetInt(row, "banReason",
                     string.Equals(row.GetValue("penaltyKind", string.Empty).ToString(), "Kick", StringComparison.OrdinalIgnoreCase) ? 2 : 1);
                stats[p + "banned_until"] = GetLong(row, "bannedUntil", 0);
            }
            try
            {
                _profiles.InsertOne(new BsonDocument
                {
                    ["playerId"] = playerId,
                    ["schemaVersion"] = 1,
                    ["stats"] = stats,
                    ["createdAt"] = DateTime.UtcNow,
                    ["updatedAt"] = DateTime.UtcNow,
                });
            }
            catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
            }
        }

        public static string ComputeRosterHash(IEnumerable<RankedReservationPlayer> players)
        {
            string canonical = string.Join("|", (players ?? Enumerable.Empty<RankedReservationPlayer>())
                .Where(x => x != null)
                .OrderBy(x => x.PlayerId, StringComparer.Ordinal)
                .Select(x => string.Join(":", new[]
                {
                    x.PlayerId ?? string.Empty,
                     x.TeamIndex.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    x.Mmr.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    x.Generation.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    x.GroupId ?? string.Empty,
                    x.GroupSize.ToString(System.Globalization.CultureInfo.InvariantCulture)
                })));
            byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(canonical));
            return Convert.ToHexString(hash).ToLowerInvariant();
        }

        private bool ReserveProfiles(
            BsonDocument match,
            IEnumerable<RankedReservationPlayer> roster,
            DateTime now)
        {
            if (match == null) return false;
            string matchId = match.GetValue("matchId", string.Empty).ToString();
            string roomId = match.GetValue("roomId", matchId).ToString();
            string modeName = match.GetValue("mode", "RankedDefuse").ToString();
            string rosterHash = match.GetValue("rosterHash", string.Empty).ToString();
            var reserved = new List<string>();

            foreach (RankedReservationPlayer player in (roster ?? Enumerable.Empty<RankedReservationPlayer>())
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.PlayerId)))
            {
                EnsureProfile(player.PlayerId);
                FilterDefinition<BsonDocument> filter = Builders<BsonDocument>.Filter.And(
                     Builders<BsonDocument>.Filter.Eq("playerId", player.PlayerId),
                     Builders<BsonDocument>.Filter.Or(
                         Builders<BsonDocument>.Filter.Exists("activeMatch", false),
                        Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                         Builders<BsonDocument>.Filter.In("activeMatch.status", new[] { "Finished", "Cancelled", "Annulled" })));
                UpdateResult write = _profiles.UpdateOne(
                    filter,
                    Builders<BsonDocument>.Update
                         .Set("activeMatch", new BsonDocument
                         {
                             ["matchId"] = matchId,
                             ["roomId"] = roomId,
                             ["mode"] = modeName,
                             ["status"] = "Confirmation",
                             ["rosterHash"] = rosterHash,
                             ["queueGeneration"] = player.Generation,
                             ["updatedAt"] = now
                         })
                        .Set("updatedAt", now));
                if (write.MatchedCount != 1)
                {
                    foreach (string reservedPlayerId in reserved)
                    {
                        _profiles.UpdateOne(
                            Builders<BsonDocument>.Filter.And(
                                Builders<BsonDocument>.Filter.Eq("playerId", reservedPlayerId),
                                Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId)),
                           Builders<BsonDocument>.Update.Unset("activeMatch").Set("updatedAt", now));
                    }
                    return false;
                }
                reserved.Add(player.PlayerId);
            }
            return reserved.Count == (roster ?? Enumerable.Empty<RankedReservationPlayer>())
                .Count(x => x != null && !string.IsNullOrWhiteSpace(x.PlayerId));
        }
        private void RollbackReservation(string matchId, string reason, DateTime now)
        {
            _matches.UpdateOne(
                Builders<BsonDocument>.Filter.And(
                     Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                    Builders<BsonDocument>.Filter.Eq("status", "Confirmation"),
                    Builders<BsonDocument>.Filter.Ne("finalized", true)),
                Builders<BsonDocument>.Update
                    .Set("status", "Cancelled")
                    .Set("matchState", "Cancelled")
                     .Set("finalized", true)
                    .Set("cancelReason", reason ?? "confirmation-reservation-failed")
                   .Set("cancelledAt", now)
                    .Set("finishedAt", now)
                    .Set("lastHeartbeatAt", now)
                     .Inc("version", 1L));
            _profiles.UpdateMany(
                Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                Builders<BsonDocument>.Update.Unset("activeMatch").Set("updatedAt", now));
        }

        public bool TryReserveConfirmation(
            string matchId,
            string roomId,
            RankedModeContract mode,
            string profile,
            string filter,
            string queueKey,
            string region,
             string selectedLevel,
           int requiredPlayers,
            IEnumerable<RankedReservationPlayer> players,
            string confirmationId,
           string rosterHash,
            DateTime confirmationDeadlineUtc)
        {
            if (string.IsNullOrWhiteSpace(matchId) || mode == null)
                return false;

            RankedReservationPlayer[] roster = (players ?? Enumerable.Empty<RankedReservationPlayer>())
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.PlayerId))
                .ToArray();
            if (roster.Length != requiredPlayers || roster.Select(x => x.PlayerId).Distinct(StringComparer.Ordinal).Count() != requiredPlayers)
                return false;
            string computedHash = ComputeRosterHash(roster);
            if (string.IsNullOrWhiteSpace(rosterHash)) rosterHash = computedHash;
            if (!string.Equals(rosterHash, computedHash, StringComparison.Ordinal))
                return false;

            DateTime now = DateTime.UtcNow;
            var rosterDoc = new BsonArray(roster.Select(x => new BsonDocument
            {
                ["playerId"] = x.PlayerId,
                ["name"] = x.PlayerName ?? string.Empty,
                ["matchTeam"] = x.TeamIndex,
                ["mmr"] = x.Mmr,
                ["queueGeneration"] = x.Generation,
                ["groupId"] = x.GroupId ?? string.Empty,
                ["groupSize"] = Math.Max(1, x.GroupSize),
                ["confirmState"] = "Pending",
                ["confirmed"] = false
            }));

            var playersDoc = rosterDoc.DeepClone().AsBsonArray;
            var document = new BsonDocument
            {
                ["matchId"] = matchId,
                ["roomId"] = roomId,
                ["schemaVersion"] = 2,
                ["version"] = 1L,
                ["mode"] = mode.WireName,
                ["modeId"] = (int)mode.Id,
                ["profile"] = profile ?? string.Empty,
                ["filter"] = filter ?? string.Empty,
                ["queueKey"] = queueKey ?? string.Empty,
                ["region"] = string.IsNullOrWhiteSpace(region) ? "Europe" : region,
                ["selectedLevel"] = selectedLevel ?? string.Empty,
                ["requiredPlayers"] = requiredPlayers,
                ["confirmationId"] = confirmationId ?? string.Empty,
                ["rosterHash"] = rosterHash,
                ["roster"] = rosterDoc,
                ["players"] = playersDoc,
                ["status"] = "Confirmation",
                ["matchState"] = "Confirmation",
                ["finalized"] = false,
                ["createdAt"] = now,
                ["confirmationDeadlineAt"] = confirmationDeadlineUtc,
                ["lastHeartbeatAt"] = now,
                ["owner"] = "Bolt"
            };

            try
            {
                _matches.InsertOne(document);
                if (!ReserveProfiles(document, roster, now))
                {
                    RollbackReservation(matchId, "player-already-reserved", now);
                    return false;
                }
                return true;
            }
            catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
                BsonDocument existing = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
                bool same = existing != null &&
                    !existing.GetValue("finalized", false).ToBoolean() &&
                    string.Equals(existing.GetValue("status", string.Empty).ToString(), "Confirmation", StringComparison.OrdinalIgnoreCase) &&
                     string.Equals(existing.GetValue("rosterHash", string.Empty).ToString(), rosterHash, StringComparison.Ordinal) &&
                    string.Equals(existing.GetValue("confirmationId", string.Empty).ToString(), confirmationId ?? string.Empty, StringComparison.Ordinal);
                if (!same) return false;
                if (!ReserveProfiles(existing, roster, now))
                {
                    RollbackReservation(matchId, "player-already-reserved", now);
                    return false;
                }
                return true;

            }
        }

        public bool TryConfirmParticipant(
            string matchId,
            string playerId,
            long queueGeneration,
            string confirmationId,
            out bool allConfirmed)
        {

            allConfirmed = false;
            for (int attempt = 0; attempt < 8; attempt++)
            {
                BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.And(
                       Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                        Builders<BsonDocument>.Filter.Eq("status", "Confirmation"),
                        Builders<BsonDocument>.Filter.Ne("finalized", true)))
                    .FirstOrDefault();
                if (match == null)
                    return false;
                if (!string.Equals(match.GetValue("confirmationId", string.Empty).ToString(), confirmationId ?? string.Empty, StringComparison.Ordinal))
                    return false;
                if (!match.TryGetValue("roster", out BsonValue rosterValue) || !rosterValue.IsBsonArray)
                    return false;

                BsonArray roster = rosterValue.AsBsonArray.DeepClone().AsBsonArray;
                BsonDocument target = roster.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                    .FirstOrDefault(x => string.Equals(x.GetValue("playerId", string.Empty).ToString(), playerId, StringComparison.Ordinal));
                if (target == null || GetLong(target, "queueGeneration", -1) != queueGeneration)
                    return false;

                string state = target.GetValue("confirmState", "Pending").ToString();
                if (string.Equals(state, "Declined", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(state, "TimedOut", StringComparison.OrdinalIgnoreCase))
                    return false;
                target["confirmState"] = "Confirmed";
                target["confirmed"] = true;
                target["confirmedAt"] = DateTime.UtcNow;
                allConfirmed = roster.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                    .All(x => string.Equals(x.GetValue("confirmState", "Pending").ToString(), "Confirmed", StringComparison.OrdinalIgnoreCase));

                BsonArray players = match.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray
                    ? playersValue.AsBsonArray.DeepClone().AsBsonArray
                    : roster.DeepClone().AsBsonArray;
                BsonDocument runtimeTarget = players.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                    .FirstOrDefault(x => string.Equals(x.GetValue("playerId", string.Empty).ToString(), playerId, StringComparison.Ordinal));
                if (runtimeTarget != null)
                {
                    runtimeTarget["confirmed"] = true;
                    runtimeTarget["confirmState"] = "Confirmed";
                }

                long version = GetLong(match, "version", 1);
                UpdateResult write = _matches.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                        Builders<BsonDocument>.Filter.Eq("status", "Confirmation"),
                         Builders<BsonDocument>.Filter.Eq("version", version),
                        Builders<BsonDocument>.Filter.Ne("finalized", true)),
                    Builders<BsonDocument>.Update
                        .Set("roster", roster)
                        .Set("players", players)
                        .Set("lastHeartbeatAt", DateTime.UtcNow)
                        .Inc("version", 1L));
                if (write.ModifiedCount == 1)
                    return true;
            }
            return false;
        }


        private void SetReadyProfiles(BsonDocument match, DateTime now)
        {
            if (match == null) return;
            string matchId = match.GetValue("matchId", string.Empty).ToString();
            string roomId = match.GetValue("roomId", matchId).ToString();
            string modeName = match.GetValue("mode", "RankedDefuse").ToString();
            string region = match.GetValue("region", "Europe").ToString();
            string selectedLevel = match.GetValue("selectedLevel", string.Empty).ToString();
            BsonArray identity = match.TryGetValue("roster", out BsonValue rosterValue) && rosterValue.IsBsonArray
                 ? rosterValue.AsBsonArray
                 : match.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray
                     ? playersValue.AsBsonArray
                     : new BsonArray();
            RankedModeContract lifecycleMode = ResolveMode(modeName);
            string lifecyclePrefix = lifecycleMode.StatPrefix;
            string genericPrefix = RankedModeContracts.Ranked5v5.StatPrefix;

            foreach (BsonDocument player in identity.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument))
            {
                string playerId = player.GetValue("playerId", string.Empty).ToString();

                if (string.IsNullOrWhiteSpace(playerId)) continue;

                EnsureProfile(playerId);
                _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                    Builders<BsonDocument>.Update
                        .Set("activeMatch", new BsonDocument
                        {
                            ["matchId"] = matchId,
                            ["roomId"] = roomId,
                            ["mode"] = modeName,
                            ["region"] = region,
                            ["selectedLevel"] = selectedLevel,
                            ["status"] = "Ready",
                            ["lastSeenAt"] = now,
                            ["terminalExit"] = false,
                            ["penaltyApplied"] = false,
                            ["updatedAt"] = now
                        })

                         .Set("stats." + lifecyclePrefix + "last_match_running", 1)
                        .Set("stats." + lifecyclePrefix + "last_match_status", 0)
                        .Set("stats." + genericPrefix + "last_match_running", 1)
                        .Set("stats." + genericPrefix + "last_match_status", 0)
                       .Set("updatedAt", now));
            }
        }

        public bool TryMarkReady(string matchId, string confirmationId, string rosterHash)
        {
            for (int attempt = 0; attempt < 8; attempt++)
            {
                BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
                if (match == null || match.GetValue("finalized", false).ToBoolean())
                    return false;
                string status = match.GetValue("status", string.Empty).ToString();
                if (string.Equals(status, "Ready", StringComparison.OrdinalIgnoreCase))
                {
                    bool sameReady = string.Equals(match.GetValue("confirmationId", string.Empty).ToString(), confirmationId ?? string.Empty, StringComparison.Ordinal) &&
                                     string.Equals(match.GetValue("rosterHash", string.Empty).ToString(), rosterHash ?? string.Empty, StringComparison.Ordinal);
                    if (sameReady)
                        SetReadyProfiles(match, DateTime.UtcNow);
                    return sameReady;
                }
                if (!string.Equals(status, "Confirmation", StringComparison.OrdinalIgnoreCase) ||
                    !string.Equals(match.GetValue("confirmationId", string.Empty).ToString(), confirmationId ?? string.Empty, StringComparison.Ordinal) ||
                    !string.Equals(match.GetValue("rosterHash", string.Empty).ToString(), rosterHash ?? string.Empty, StringComparison.Ordinal))
                    return false;
                if (!match.TryGetValue("roster", out BsonValue rv) || !rv.IsBsonArray ||
                    !rv.AsBsonArray.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                        .All(x => string.Equals(x.GetValue("confirmState", "Pending").ToString(), "Confirmed", StringComparison.OrdinalIgnoreCase)))
                    return false;

                long version = GetLong(match, "version", 1);
                DateTime now = DateTime.UtcNow;
                UpdateResult write = _matches.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                        Builders<BsonDocument>.Filter.Eq("status", "Confirmation"),
                        Builders<BsonDocument>.Filter.Eq("version", version),
                        Builders<BsonDocument>.Filter.Ne("finalized", true)),
                    Builders<BsonDocument>.Update
                        .Set("status", "Ready")
                        .Set("matchState", "Ready")
                        .Set("readyAt", now)
                        .Set("lastHeartbeatAt", now)
                        .Set("owner", "BoltHandoff")
                         .Inc("version", 1L));
                if (write.ModifiedCount == 1)
                {
                    SetReadyProfiles(match, now);
                    return true;
                }
            }
            return false;
        }

        public bool TryReleaseExpiredDisconnectedMatch(string playerId, string matchId, TimeSpan staleAfter, string reason)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(matchId))
                return false;

            DateTime now = DateTime.UtcNow;
            DateTime cutoff = now.Subtract(staleAfter <= TimeSpan.Zero ? TimeSpan.FromSeconds(60) : staleAfter);

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
            if (match == null || match.GetValue("finalized", false).ToBoolean())
                return false;

            string lifecycle = match.GetValue("status", string.Empty).ToString();
            if (!string.Equals(lifecycle, "Disconnected", StringComparison.OrdinalIgnoreCase))
                return false;

            List<BsonDocument> attached = _profiles.Find(
                   Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId))
               .Project(Builders<BsonDocument>.Projection
                   .Include("playerId")
                   .Include("activeMatch")
                   .Include("stats"))
               .ToList();
            if (attached.Count == 0)
                return false;

            foreach (BsonDocument profile in attached)
            {
                if (!profile.TryGetValue("activeMatch", out BsonValue av) || !av.IsBsonDocument)
                    return false;
                BsonDocument active = av.AsBsonDocument;
                string activeStatus = active.GetValue("status", string.Empty).ToString();
                if (!string.Equals(activeStatus, "Disconnected", StringComparison.OrdinalIgnoreCase))
                    return false;

                DateTime disconnectedAt = DateTime.MaxValue;
                if (active.TryGetValue("disconnectedAt", out BsonValue dv) && dv.IsBsonDateTime)
                    disconnectedAt = dv.AsBsonDateTime.ToUniversalTime();
                else if (active.TryGetValue("lastSeenAt", out BsonValue lv) && lv.IsBsonDateTime)
                    disconnectedAt = lv.AsBsonDateTime.ToUniversalTime();

                if (disconnectedAt == DateTime.MaxValue || disconnectedAt > cutoff)
                    return false;
            }

            UpdateResult write = _matches.UpdateOne(
                Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                    Builders<BsonDocument>.Filter.Eq("status", "Disconnected"),
                     Builders<BsonDocument>.Filter.Ne("finalized", true)),
                Builders<BsonDocument>.Update
                    .Set("status", "Cancelled")
                    .Set("matchState", "Cancelled")
                    .Set("finalized", true)
                    .Set("cancelReason", reason ?? "stale-disconnected-expired-on-new-start")
                    .Set("cancelledAt", now)
                    .Set("finishedAt", now)
                   .Set("lastHeartbeatAt", now)
                    .Inc("version", 1L));
            if (write.ModifiedCount != 1)
                return false;

            foreach (BsonDocument profile in attached)
            {
                string attachedPlayerId = profile.GetValue("playerId", string.Empty).ToString();
                if (string.IsNullOrWhiteSpace(attachedPlayerId))
                    continue;
                BsonDocument active = profile.GetValue("activeMatch", new BsonDocument()).AsBsonDocument;
                RankedModeContract mode = ResolveMode(active.GetValue("mode", match.GetValue("mode", string.Empty)).ToString());
                _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("playerId", attachedPlayerId),
                        Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId),
                       Builders<BsonDocument>.Filter.Eq("activeMatch.status", "Disconnected")),
                    Builders<BsonDocument>.Update
                        .Unset("activeMatch")
                        .Set("stats." + mode.StatPrefix + "last_match_running", 0)
                        .Set("stats." + mode.StatPrefix + "last_match_status", 0)
                         .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_running", 0)
                        .Set("stats." + RankedModeContracts.Ranked5v5.StatPrefix + "last_match_status", 0)
                        .Set("updatedAt", now));
            }

            return true;
        }

        public bool TryCancelPreRunningMatch(string matchId, string reason, string culpritPlayerId = null)
        {
            if (string.IsNullOrWhiteSpace(matchId)) return false;

            if (string.Equals(reason, "group-member-disconnected", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(reason, "handoff-expired", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
            BsonDocument current = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId)).FirstOrDefault();
            if (current == null) return false;
            string currentStatus = current.GetValue("status", string.Empty).ToString();
            if (string.Equals(currentStatus, "Cancelled", StringComparison.OrdinalIgnoreCase))
                return true;
            if (current.GetValue("finalized", false).ToBoolean() ||
                (!string.Equals(currentStatus, "Confirmation", StringComparison.OrdinalIgnoreCase) &&
                 !string.Equals(currentStatus, "Ready", StringComparison.OrdinalIgnoreCase)))
                return false;

            DateTime now = DateTime.UtcNow;
            var updates = new List<UpdateDefinition<BsonDocument>>
            {
                Builders<BsonDocument>.Update.Set("status", "Cancelled"),
                Builders<BsonDocument>.Update.Set("matchState", "Cancelled"),
                Builders<BsonDocument>.Update.Set("finalized", true),
                Builders<BsonDocument>.Update.Set("cancelReason", reason ?? string.Empty),
                Builders<BsonDocument>.Update.Set("cancelledAt", now),
                Builders<BsonDocument>.Update.Set("finishedAt", now),
                Builders<BsonDocument>.Update.Set("lastHeartbeatAt", now),
                Builders<BsonDocument>.Update.Inc("version", 1L)
            };
            if (!string.IsNullOrWhiteSpace(culpritPlayerId))
                updates.Add(Builders<BsonDocument>.Update.Set("confirmationCulpritPlayerId", culpritPlayerId));

            UpdateResult result = _matches.UpdateOne(
         Builders<BsonDocument>.Filter.And(
           Builders<BsonDocument>.Filter.Eq("matchId", matchId),
          Builders<BsonDocument>.Filter.In("status", new[] { "Confirmation", "Ready" }),
          Builders<BsonDocument>.Filter.Ne("finalized", true)),
      Builders<BsonDocument>.Update.Combine(updates));
            if (result.ModifiedCount != 1)

                return false;

            IEnumerable<BsonDocument> roster = current.TryGetValue("roster", out BsonValue rv) && rv.IsBsonArray
                ? rv.AsBsonArray.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                : current.TryGetValue("players", out BsonValue pv) && pv.IsBsonArray
                    ? pv.AsBsonArray.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                    : Enumerable.Empty<BsonDocument>();
            foreach (BsonDocument player in roster)
            {
                string playerId = player.GetValue("playerId", string.Empty).ToString();
                if (string.IsNullOrWhiteSpace(playerId)) continue;
                _profiles.UpdateOne(
                    Builders<BsonDocument>.Filter.And(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Filter.Eq("activeMatch.matchId", matchId)),
                    Builders<BsonDocument>.Update
                        .Unset("activeMatch")
                        .Set("updatedAt", now));
            }
            return true;
        }

        public void ReserveMatch(
             string matchId,
            string roomId,
            RankedModeContract mode,
            string profile,
            string filter,
            string queueKey,
            int requiredPlayers,
            IEnumerable<RankedReservationPlayer> players,
            string status)
        {
            BsonDocument existing = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId))
                .Project(Builders<BsonDocument>.Projection.Include("status").Include("finalized"))
                .FirstOrDefault();
            if (existing != null)
            {
                string current = existing.GetValue("status", string.Empty).ToString();
                if (existing.GetValue("finalized", false).ToBoolean() ||
                    string.Equals(current, "Running", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(current, "Disconnected", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(current, "Finalizing", StringComparison.OrdinalIgnoreCase) ||
                    IsTerminalStatus(current))
                    return;
            }

            var playerArray = new BsonArray(players.Select(x => new BsonDocument
            {
                ["playerId"] = x.PlayerId,
                ["name"] = x.PlayerName ?? string.Empty,
                ["matchTeam"] = x.TeamIndex,
                ["mmr"] = x.Mmr,
                ["confirmed"] = x.Confirmed
            }));

            var update = Builders<BsonDocument>.Update
                .SetOnInsert("matchId", matchId)
                .SetOnInsert("createdAt", DateTime.UtcNow)
                .SetOnInsert("finalized", false)
                .Set("roomId", roomId)
                .Set("mode", mode.WireName)
                .Set("modeId", (int)mode.Id)
                .Set("profile", profile)
                .Set("filter", filter)
                .Set("queueKey", queueKey)
                .Set("requiredPlayers", requiredPlayers)
                .Set("players", playerArray)
                .Set("status", status)
                .Set("lastHeartbeatAt", DateTime.UtcNow);
            _matches.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                update,
                new UpdateOptions { IsUpsert = existing == null });
        }

        public void MarkMatchCancelled(string matchId, string reason)
        {
            if (string.IsNullOrWhiteSpace(matchId)) return;
            _matches.UpdateOne(
                Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                    Builders<BsonDocument>.Filter.Ne("finalized", true),
                    Builders<BsonDocument>.Filter.In("status", new[] { "Confirmation", "Ready" })),
               Builders<BsonDocument>.Update
                    .Set("status", "Cancelled")
                    .Set("matchState", "Cancelled")
                    .Set("finalized", true)
                    .Set("cancelReason", reason ?? string.Empty)
                    .Set("cancelledAt", DateTime.UtcNow)
                    .Set("finishedAt", DateTime.UtcNow)
                    .Set("lastHeartbeatAt", DateTime.UtcNow));
        }

        public bool IsRecoverableHandoff(string matchId, string playerId, out string lifecycleStatus)
        {
            lifecycleStatus = string.Empty;
            if (string.IsNullOrWhiteSpace(matchId) || string.IsNullOrWhiteSpace(playerId))
                return false;

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId))
                .FirstOrDefault();
            if (match == null)
            {
                lifecycleStatus = "Missing";
                return false;
            }

            lifecycleStatus = match.GetValue("status", string.Empty).ToString();
            if (match.GetValue("finalized", false).ToBoolean() || IsTerminalStatus(lifecycleStatus))
                return false;

            bool lifecycleRecoverable =
                string.Equals(lifecycleStatus, "Ready", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(lifecycleStatus, "Running", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(lifecycleStatus, "Disconnected", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(lifecycleStatus, "Finalizing", StringComparison.OrdinalIgnoreCase);
            if (!lifecycleRecoverable)
                return false;

            BsonArray identityArray = match.TryGetValue("roster", out BsonValue rosterValue) && rosterValue.IsBsonArray
                ? rosterValue.AsBsonArray
                : match.TryGetValue("players", out BsonValue playersIdentity) && playersIdentity.IsBsonArray
                    ? playersIdentity.AsBsonArray
                    : null;
            if (identityArray == null)
                return false;
            bool rosterMember = identityArray.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                .Any(x => string.Equals(x.GetValue("playerId", string.Empty).ToString(), playerId, StringComparison.Ordinal));
            if (!rosterMember)
                return false;

            BsonDocument runtimePlayer = match.TryGetValue("players", out BsonValue playersValue) && playersValue.IsBsonArray
                 ? playersValue.AsBsonArray.Where(x => x.IsBsonDocument).Select(x => x.AsBsonDocument)
                     .FirstOrDefault(x => string.Equals(x.GetValue("playerId", string.Empty).ToString(), playerId, StringComparison.Ordinal))
                 : null;
            return runtimePlayer == null ||
                   (!GetBool(runtimePlayer, "terminalExit") &&
                    !GetBool(runtimePlayer, "kicked") &&
                    !GetBool(runtimePlayer, "penaltyApplied"));
        }

        public BsonDocument GetRecoverableHandoff(string matchId, string playerId)
        {
            if (!IsRecoverableHandoff(matchId, playerId, out _))
                return null;

            return _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId))
               .FirstOrDefault();
        }

        public string GetMatchLifecycleStatus(string matchId, out bool finalized)
        {
            finalized = false;
            if (string.IsNullOrWhiteSpace(matchId)) return "Missing";

            BsonDocument match = _matches.Find(Builders<BsonDocument>.Filter.Eq("matchId", matchId))
                .Project(Builders<BsonDocument>.Projection.Include("status").Include("finalized"))
                .FirstOrDefault();
            if (match == null) return "Missing";

            finalized = match.GetValue("finalized", false).ToBoolean();
            return match.GetValue("status", string.Empty).ToString();
        }

        public BsonDocument GetMatch(string matchId)
        {
            if (string.IsNullOrWhiteSpace(matchId)) return null;
            return _matches.Find(Builders<BsonDocument>.Filter.Or(
                    Builders<BsonDocument>.Filter.Eq("matchId", matchId),
                    Builders<BsonDocument>.Filter.Eq("_id", matchId)))
                .FirstOrDefault();
        }

        public List<BsonDocument> GetPlayerMatches(string playerId, int offset, int length)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return new List<BsonDocument>();
            offset = Math.Max(0, offset);

            length = Math.Max(1, Math.Min(length <= 0 ? 20 : length, 50));
            return _matches.Find(Builders<BsonDocument>.Filter.And(

                Builders<BsonDocument>.Filter.Eq("players.playerId", playerId),

                    Builders<BsonDocument>.Filter.Eq("finalized", true),
                   Builders<BsonDocument>.Filter.Eq("status", "Finished"),
                   Builders<BsonDocument>.Filter.In("mode", new[] { "RankedDefuse", "Ranked2v2", "RankedDuel" })))
               .Sort(Builders<BsonDocument>.Sort.Descending("finishedAt").Descending("createdAt"))
               .Skip(offset)
               .Limit(length)
               .ToList();
        }

        public BsonDocument GetLastPlayerMatch(string playerId)
        {
            return _matches.Find(Builders<BsonDocument>.Filter.And(
                    Builders<BsonDocument>.Filter.Eq("players.playerId", playerId),
                    Builders<BsonDocument>.Filter.Eq("finalized", true),
                    Builders<BsonDocument>.Filter.Eq("status", "Finished")))
                .Sort(Builders<BsonDocument>.Sort.Descending("finishedAt").Descending("createdAt"))
                .FirstOrDefault();
        }

        private static int ToClientStatInt(long value)
        {
            if (value > int.MaxValue) return int.MaxValue;
            if (value < int.MinValue) return int.MinValue;
            return (int)value;
        }

        private static int GetInt(BsonDocument document, string key, int fallback)
        {
            try
            {
                if (!document.TryGetValue(key, out BsonValue value) || value.IsBsonNull) return fallback;
                return value.ToInt32();
            }
            catch { return fallback; }
        }

        private static bool GetBool(BsonDocument document, string key)
        {
            try
            {
                return document != null &&
            document.TryGetValue(key, out BsonValue value) &&
                        !value.IsBsonNull &&
                       value.ToBoolean();
            }
            catch
            {

                return false;
            }
        }

        private static long GetLong(BsonDocument document, string key, long fallback)
        {
            try
            {
                if (!document.TryGetValue(key, out BsonValue value) || value.IsBsonNull) return fallback;
                return value.ToInt64();
            }
            catch { return fallback; }
        }
    }

    internal sealed class RankedReservationPlayer
    {
        public string PlayerId;
        public string PlayerName;
        public int TeamIndex;
        public int Mmr;
        public bool Confirmed;
        public long Generation;
        public string GroupId = string.Empty;
        public int GroupSize = 1;
    }
}
