using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

     public sealed class StartupRemoteService : RpcHandler
    {
        private readonly string _serviceName;

        public StartupRemoteService(ClientSession user, string serviceName) : base(user)
        {
            _serviceName = serviceName ?? string.Empty;
        }

        public override void Invoke(RpcRequest request)
         {
            string method = request?.MethodName ?? string.Empty;
            string id = request?.Id ?? string.Empty;

            if (_serviceName == "MenuBootstrap033RemoteService")
             {
                BootstrapContracts.Result result = BootstrapContracts.Build(_session, method, request);
               SendBytes(id, result.Bytes);
                return;
            }

            if (_serviceName == "AvatarRemoteService" && method == "getDefaultAvatars")
            {
                DefaultAvatars(request);
               return;
            }

            if (_serviceName == "AvatarRemoteService" && method == "getAvatars2")
            {
                Avatars(request);
                return;
            }

            if (_serviceName == "SystemMessagesRemoteService" && method == "getSystemMessages")
            {
                SystemMessages(request);
                return;
            }

            if (_serviceName == "SystemMessagesRemoteService" && method == "countUnreadSystemMessages")
            {
                UnreadCount(request);
                return;
            }

            if (_serviceName == "SystemMessagesRemoteService" && method == "getSystemMessageDetails")
           {
                MessageDetails(request);
                return;
             }

            if (_serviceName == "SystemMessagesRemoteService" && method == "readSystemMessages")
            {
                ReadMessages(request);
                return;
            }

            if (_serviceName == "SystemMessagesRemoteService" && method == "deleteSystemMessages")
            {
               DeleteMessages(request);
                return;
            }

            SendNotFound(id, method);
        }

        private void DefaultAvatars(RpcRequest request)
        {
            IMongoCollection<BsonDocument> collection = BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("default_avatars");
            if (collection.CountDocuments(Builders<BsonDocument>.Filter.Empty) == 0)
            {
                collection.InsertOne(new BsonDocument
                {
                    ["avatarId"] = "1",
                    ["enabled"] = true,
                    ["order"] = 1,
                    ["updatedAt"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                });
            }

            List<BsonDocument> docs = collection.Find(Builders<BsonDocument>.Filter.Ne("enabled", false))
                .Sort(Builders<BsonDocument>.Sort.Ascending("order")).ToList();
            long latest = docs.Count == 0 ? 0 : docs.Max(x => ReadLong(x, "updatedAt"));
            string lastUpdated = latest.ToString();
            byte[] response = ContractWire.Build(w =>
            {
                foreach (BsonDocument doc in docs)
                {
                    byte[] avatar = ContractWire.Build(a => a.String(1, ReadString(doc, "avatarId", "1")));
                    w.Message(1, avatar);
                }
                w.String(2, lastUpdated);
            });
            SendBytes(request.Id, response);
        }

        private void Avatars(RpcRequest request)
        {
            string playerId = PlayerId();
            if (string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            List<string> ids = ContractWire.ReadRepeatedStringField(ContractWire.Param(request), 1);
            Axlebolt.Bolt.Protobuf2.AvatarBinary[] avatars = BoltGameDatabaseProvider.Instance
                .GetAvatars(ids.ToArray());
             byte[] response = ContractWire.WrapRepeated(1, avatars);
            SendBytes(request.Id, response);
        }

        private IMongoCollection<BsonDocument> Messages()
        {
            return BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("system_messages");
        }

        private string PlayerId()
        {
            return ServerState.Users.TryGetValue(_session.TcpClient, out string playerId)
                ? playerId ?? string.Empty
                : string.Empty;
        }

        private void UnreadCount(RpcRequest request)
        {
             string playerId = PlayerId();
            if (string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }

            WelcomeMessage(playerId);

            long count = Messages().CountDocuments(
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Ne("isRead", true) &
                Builders<BsonDocument>.Filter.Ne("deleted", true));
            byte[] response = ContractWire.Build(w => w.Int32(1, checked((int)Math.Min(int.MaxValue, count))));
            SendBytes(request.Id, response);
       }

        private void SystemMessages(RpcRequest request)
        {
            string playerId = PlayerId();
            if (string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            WelcomeMessage(playerId);
           byte[] raw = ContractWire.Param(request);
            bool unreadOnly = ContractWire.ReadBoolField(raw, 2, false);
            int offset = 0;
            int length = 50;
            try
            {
                var outer = new ContractWire.Reader(raw);
                while (outer.TryReadField(out int field, out int wire))
                 {
                    if (field == 1 && wire == 2)
                    {
                        byte[] tokenMessage = outer.ReadBytes();
                        length = Math.Max(1, Math.Min(ContractWire.ReadIntField(tokenMessage, 1, 50), 200));
                        string token = ContractWire.ReadStringField(tokenMessage, 2, "0");
                        int.TryParse(token, out offset);
                        offset = Math.Max(0, offset);
                    }
                    else outer.Skip(wire);
                }
            }
            catch
            {
            }
            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Ne("deleted", true);
            if (unreadOnly) filter &= Builders<BsonDocument>.Filter.Ne("isRead", true);

            List<BsonDocument> docs = Messages()
                .Find(filter)
                .Sort(Builders<BsonDocument>.Sort.Descending("created"))
                .Skip(offset)
                .Limit(length)
                .ToList();

            string nextToken = docs.Count == length ? (offset + docs.Count).ToString() : string.Empty;
            byte[] response = ContractWire.Build(w =>
            {
                foreach (BsonDocument doc in docs)
                {
                    byte[] preview = ContractWire.Build(p =>
                    {
                        p.String(1, ReadString(doc, "messageId", doc.GetValue("_id", BsonNull.Value).ToString()));
                        p.Int32(2, ReadInt(doc, "type"));
                        p.Bool(3, ReadBool(doc, "isRead"));
                        p.Varint(4, ReadLong(doc, "created"));
                        p.Varint(5, ReadLong(doc, "deleteAt"));
                        p.Varint(6, ReadLong(doc, "updated"));
                    });
                    w.Message(1, preview);
                }
                w.String(2, nextToken);
            });

            SendBytes(request.Id, response);
        }

        private void WelcomeMessage(string playerId)
        {
            const string messageId = "welcome-033";

            IMongoCollection<BsonDocument> collection = Messages();
            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Eq("messageId", messageId);

            if (collection.CountDocuments(filter) > 0)
                return;

            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            try
            {
                collection.InsertOne(new BsonDocument
                {
                    ["playerId"] = playerId,
                    ["messageId"] = messageId,
                    ["type"] = 11,
                    ["isRead"] = false,
                    ["deleted"] = false,
                    ["created"] = now,
                    ["updated"] = now,
                    ["deleteAt"] = 0,
                    ["body"] = "Welcome to StandLine 0.33.0",
                    ["properties"] = new BsonDocument { ["source"] = "server" }
                });
            }
            catch (MongoWriteException)
            {
                // Another session may have created it first.
            }
        }

        private void MessageDetails(RpcRequest request)
        {
           string playerId = PlayerId();
            if (string.IsNullOrWhiteSpace(playerId)) { ContractWire.SendException(_session, request.Id, 401); return; }
            string messageId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            BsonDocument doc = Messages().Find(
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Eq("messageId", messageId) &
                Builders<BsonDocument>.Filter.Ne("deleted", true)).FirstOrDefault();
            if (doc == null) { ContractWire.SendException(_session, request.Id, 404); return; }

            int type = ReadInt(doc, "type");
            byte[] details = ContractWire.Build(w =>
            {
                w.String(1, ReadString(doc, "messageId", messageId));
                w.Int32(2, type);
                w.Varint(3, ReadLong(doc, "created"));
                w.Varint(4, ReadLong(doc, "deleteAt"));
                w.Varint(25, ReadLong(doc, "updated"));

                byte[] rawPayload = doc.TryGetValue("detailsPayload", out BsonValue payload) && payload.IsBsonBinaryData
                    ? payload.AsBsonBinaryData.Bytes
                    : Array.Empty<byte>();
                if (rawPayload.Length > 0)
                {
                    int field = ReadInt(doc, "detailsField", 9);
                    w.Message(field, rawPayload);
                }
                else
                {
                    byte[] developerMessage = ContractWire.Build(m =>
                    {
                        m.String(1, ReadString(doc, "body"));
                        if (doc.TryGetValue("properties", out BsonValue props) && props.IsBsonDocument)
                       {
                            foreach (BsonElement e in props.AsBsonDocument.Elements)
                            {
                                byte[] entry = ContractWire.Build(x => { x.String(1, e.Name); x.String(2, e.Value.ToString()); });
                               m.Message(2, entry);
                             }
                        }
                    });
                    w.Message(9, developerMessage);
                }
            });
            SendBytes(request.Id, ContractWire.Build(w => w.Message(1, details)));
        }

        private void ReadMessages(RpcRequest request)
        {
           string playerId = PlayerId();
           if (string.IsNullOrWhiteSpace(playerId)) { ContractWire.SendException(_session, request.Id, 401); return; }
            byte[] raw = ContractWire.Param(request);
            List<string> ids = ContractWire.ReadRepeatedStringField(raw, 1);
            bool readAll = ContractWire.ReadBoolField(raw, 2, false);
            FilterDefinition<BsonDocument> filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Ne("deleted", true);
            if (!readAll) filter &= Builders<BsonDocument>.Filter.In("messageId", ids);
            Messages().UpdateMany(filter, Builders<BsonDocument>.Update.Set("isRead", true).Set("updated", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()));
            ContractWire.SendEmpty(_session, request.Id);
         }

        private void DeleteMessages(RpcRequest request)
        {
            string playerId = PlayerId();
            if (string.IsNullOrWhiteSpace(playerId)) { ContractWire.SendException(_session, request.Id, 401); return; }
            byte[] raw = ContractWire.Param(request);
           List<string> ids = ContractWire.ReadRepeatedStringField(raw, 1);
            bool deleteAll = ContractWire.ReadBoolField(raw, 2, false);
            FilterDefinition<BsonDocument> filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId);
            if (!deleteAll) filter &= Builders<BsonDocument>.Filter.In("messageId", ids);
            Messages().UpdateMany(filter, Builders<BsonDocument>.Update.Set("deleted", true).Set("updated", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()));
            ContractWire.SendEmpty(_session, request.Id);
        }

        private static string ReadString(BsonDocument doc, string key, string fallback = "")
        {
            try { return doc != null && doc.TryGetValue(key, out BsonValue value) && !value.IsBsonNull ? value.ToString() : fallback; }
            catch { return fallback; }
        }

        private static int ReadInt(BsonDocument doc, string key, int fallback = 0)
        {
            try { return doc != null && doc.TryGetValue(key, out BsonValue value) && !value.IsBsonNull ? value.ToInt32() : fallback; }
            catch { return fallback; }
        }

        private static long ReadLong(BsonDocument doc, string key)
        {
            try
            {
                if (doc == null || !doc.TryGetValue(key, out BsonValue value) || value.IsBsonNull) return 0;
                if (value.IsBsonDateTime) return value.AsBsonDateTime.MillisecondsSinceEpoch;
                return value.ToInt64();
            }
            catch { return 0; }
        }

       private static bool ReadBool(BsonDocument doc, string key)
        {
            try { return doc != null && doc.TryGetValue(key, out BsonValue value) && !value.IsBsonNull && value.ToBoolean(); }
            catch { return false; }
        }

        private void SendBytes(string id, byte[] bytes)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = new BinaryValue
                     {
                        IsNull = false,
                        One = ByteString.CopyFrom(bytes ?? Array.Empty<byte>())
                    }
                }
            });
       }

       private void SendNotFound(string id, string method)
        {
            _session.SendResponse(new ResponseMessage
            {
                 RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 404,
                        Property =
                        {
                            ["service"] = _serviceName,
                            ["method"] = method ?? string.Empty,
                            ["reason"] = "not implemented"
                        }
                    }
                 }
            });
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }
    }
}
