using System;
using Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer.Api
{

    public sealed class MarketplaceRemoteEventSender : IEventSender
    {
        private readonly ClientSession _session;
        public ClientSession User => _session;
        public string eventListenerName { get; set; } = "MarketplaceRemoteEventListener";

        public MarketplaceRemoteEventSender(ClientSession user)
        {
            _session = user;
        }

        public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse eventResponse = BoltEventContract.Create(
                eventListenerName, eventName, parameters ?? Array.Empty<object>());
            SendEnvelope(eventResponse, "legacy-object");
        }

        public void SendRawEvent(string eventName, byte[] exactEventPayload, string targetPlayerId, string source)
        {
            EventResponse eventResponse = BoltEventContract.CreateRaw(
                eventListenerName, eventName, exactEventPayload ?? Array.Empty<byte>());
            SendEnvelope(eventResponse, $"{source};target={targetPlayerId}");
        }

        private void SendEnvelope(EventResponse eventResponse, string source)
        {

            _session.SendResponse(new ResponseMessage { EventResponse = eventResponse });
       }

    }
}
