using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public class FriendsRemoteService : RpcHandler
    {
        private static readonly object FriendsLock = new();

        public FriendsRemoteService(ClientSession session) : base(session)
        {
        }

        public void GetAvatars(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            try
            {
                string[] ids = Array.Empty<string>();
                if (values is { Length: > 0 } && values[0] != null)
                    ids = (string[])new RpcValueReader(typeof(string[])).FromBytes(values[0]) ?? Array.Empty<string>();

                AvatarBinary[] avatars = BoltGameDatabaseProvider.Instance.GetAvatars(ids);
                SendValue(requestId, avatars);
            }
            catch (System.Exception)
            {
                AvatarBinary[] fallback = { BoltGameDatabaseProvider.Instance.GetAvatar("1") };
                SendValue(requestId, fallback);
            }
        }

        protected void GetPlayerFriendsIds(BinaryValue[] values, string requestId)
        {
             if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
               return;
            }

            RelationshipStatus[] statuses = (RelationshipStatus[])new EnumValueReader(typeof(RelationshipStatus[]))
               .FromBytes(values[0]);

             List<FriendDocument> relations = GetRelations(playerId, statuses);
            string[] playerIds = relations
               .Select(relation => relation.playerInitiatorId == playerId
                    ? relation.playerId
                    : relation.playerInitiatorId)
                 .ToArray();

            SendValue(requestId, playerIds);
        }

        protected void GetPlayerFriends(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            RelationshipStatus[] statuses = (RelationshipStatus[])new EnumValueReader(typeof(RelationshipStatus[]))
                .FromBytes(values[0]);
            int page = (int)new RpcValueReader(typeof(int)).FromBytes(values[1]);
            int size = (int)new RpcValueReader(typeof(int)).FromBytes(values[2]);

            PlayerFriend[] result = GetRelations(playerId, statuses)
                .Select(relation => relation.GetPlayerFriend(playerId))
                .Skip(page * size)
                .Take(size)
                .ToArray();

            SendValue(requestId, result);
        }

        protected void GetPlayerFriendById(string targetPlayerId, string requestId)
        {
           if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            PlayerFriend friend = BoltMainDatabaseProvider.Instance
                .GetPlayerDocument(ObjectId.Parse(targetPlayerId))
                .GetPlayerFriend(playerId);

            SendValue(requestId, friend);
        }

        protected void SendFriendRequest(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            string friendId = ReadPlayerId(values);
            if (string.IsNullOrWhiteSpace(friendId) || friendId == playerId)
            {
                 SendException(requestId, 500);
                return;
            }

            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null)
            {
                relation = database.CreatePlayerFriendDocument(new FriendDocument
                {
                   playerId = friendId,
                    playerInitiatorId = playerId,
                    relationshipStatus = RelationshipStatusCustom.Request,
                    msg = string.Empty
                });

                PushFriendEvent(
                    friendId,
                    "onNewFriendshipRequest",
                    relation.GetPlayerFriend(friendId),
                    relation.msg ?? string.Empty);
                SendRelationshipStatus(requestId, RelationshipStatus.RequestInitiator);
                return;
            }

            if (relation.relationshipStatus == RelationshipStatusCustom.Friend)
            {
                SendRelationshipStatus(requestId, RelationshipStatus.Friend);
                return;
            }

            if (relation.relationshipStatus == RelationshipStatusCustom.Blocked &&
                relation.playerInitiatorId != playerId)
            {
                SendException(requestId, 3102);
                return;
            }

            if (relation.relationshipStatus == RelationshipStatusCustom.Request)
            {
                 if (relation.playerInitiatorId == playerId)
                {
                    SendRelationshipStatus(requestId, RelationshipStatus.RequestInitiator);
                    return;
                }

                relation.relationshipStatus = RelationshipStatusCustom.Friend;
                database.UpdatePlayerFriendDocument(playerId, friendId, relation);
               PushFriendEvent(friendId, "onFriendAdded", relation.GetPlayerFriend(friendId));
                SendRelationshipStatus(requestId, RelationshipStatus.Friend);
                return;
             }

            relation.playerInitiatorId = playerId;
             relation.playerId = friendId;
            relation.relationshipStatus = RelationshipStatusCustom.Request;
             database.UpdatePlayerFriendDocument(playerId, friendId, relation);

            PushFriendEvent(
                friendId,
               "onNewFriendshipRequest",
                relation.GetPlayerFriend(friendId),
                relation.msg ?? string.Empty);
            SendRelationshipStatus(requestId, RelationshipStatus.RequestInitiator);
        }

        protected void AcceptFriendRequest(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
               return;
            }

            string friendId = ReadPlayerId(values);
            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null ||
                relation.relationshipStatus != RelationshipStatusCustom.Request ||
                relation.playerInitiatorId == playerId)
            {
                 SendException(requestId, 500);
               return;
            }

            relation.relationshipStatus = RelationshipStatusCustom.Friend;
             database.UpdatePlayerFriendDocument(playerId, friendId, relation);
            PushFriendEvent(friendId, "onFriendAdded", relation.GetPlayerFriend(friendId));
            SendRelationshipStatus(requestId, RelationshipStatus.Friend);
        }

        protected void IgnoreFriendRequest(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

           string friendId = ReadPlayerId(values);
            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null || relation.playerInitiatorId == playerId)
            {
                SendException(requestId, 500);
                return;
            }

            relation.relationshipStatus = RelationshipStatusCustom.Ignored;
            database.UpdatePlayerFriendDocument(playerId, friendId, relation);
            SendRelationshipStatus(
                requestId,
                relation.relationshipStatus.GetRelationshipStatus(relation.playerInitiatorId == playerId));
        }

       protected void RevokeFriendRequest(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            string friendId = ReadPlayerId(values);
            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
             FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null || relation.playerId == playerId)
            {
                SendException(requestId, 500);
                return;
             }

            relation.relationshipStatus = RelationshipStatusCustom.None;
           database.UpdatePlayerFriendDocument(playerId, friendId, relation);
            PushFriendEvent(friendId, "onRevokeFriendshipRequest", playerId);
            SendRelationshipStatus(requestId, RelationshipStatus.None);
        }

        protected void UnblockFriend(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            string friendId = ReadPlayerId(values);
            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null || relation.playerId == playerId)
            {
               SendException(requestId, 500);
                return;
            }

            relation.relationshipStatus = RelationshipStatusCustom.None;
             database.UpdatePlayerFriendDocument(playerId, friendId, relation);
            SendRelationshipStatus(
                requestId,
                relation.relationshipStatus.GetRelationshipStatus(relation.playerInitiatorId == playerId));
        }

        protected void RemoveFriend(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
           {
                SendException(requestId, 401);
                return;
            }

            string friendId = ReadPlayerId(values);
             BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

             if (relation == null || relation.relationshipStatus != RelationshipStatusCustom.Friend)
            {
                SendException(requestId, 500);
                return;
             }

            relation.playerInitiatorId = playerId;
            relation.playerId = friendId;
            relation.relationshipStatus = RelationshipStatusCustom.None;
            database.UpdatePlayerFriendDocument(playerId, friendId, relation);

            PushFriendEvent(friendId, "onFriendRemoved", playerId);
            SendRelationshipStatus(requestId, RelationshipStatus.None);
        }

        protected void BlockFriend(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
               return;
            }

            string friendId = ReadPlayerId(values);
            BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
            FriendDocument? relation = FindRelation(database, playerId, friendId);

            if (relation == null)
            {
                database.CreatePlayerFriendDocument(new FriendDocument
                {
                    playerId = friendId,
                   playerInitiatorId = playerId,
                    relationshipStatus = RelationshipStatusCustom.Blocked
                });
            }
            else
            {
                if (relation.playerInitiatorId == friendId)
                   (relation.playerId, relation.playerInitiatorId) = (relation.playerInitiatorId, relation.playerId);

                 relation.relationshipStatus = RelationshipStatusCustom.Blocked;
                database.UpdatePlayerFriendDocument(playerId, friendId, relation);
                PushFriendEvent(friendId, "onFriendRemoved", playerId);
            }

             SendRelationshipStatus(requestId, RelationshipStatus.Blocked);
        }

        protected void SearchPlayers(BinaryValue[] values, string requestId)
        {
            if (!TryGetCurrentPlayer(out string playerId))
            {
                SendException(requestId, 401);
                return;
            }

            string query = (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
            int page = (int)new RpcValueReader(typeof(int)).FromBytes(values[1]);
            int size = (int)new RpcValueReader(typeof(int)).FromBytes(values[2]);

            List<FriendDocument> relations = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
            PlayerFriend[] result = BoltMainDatabaseProvider.Instance
                .GetPlayersDocumentsByUid(query)
                .Select(player =>
                {
                    string candidateId = player._id.ToString();
                    FriendDocument? relation = relations.FirstOrDefault(document =>
                        document.playerId == candidateId ||
                        document.playerInitiatorId == candidateId);

                    return relation != null
                        ? relation.GetPlayerFriend(playerId)
                        : player.GetPlayerFriend();
                })
                .Skip(page * size)
                .Take(size)
                .ToArray();

           SendValue(requestId, result);
       }

        private bool TryGetCurrentPlayer(out string playerId)
        {
            return ServerState.Users.TryGetValue(_session.TcpClient, out playerId!) &&
                   !string.IsNullOrWhiteSpace(playerId);
        }

        private static string ReadPlayerId(BinaryValue[] values)
         {
            return (string)new RpcValueReader(typeof(string)).FromBytes(values[0]);
        }

         private static FriendDocument? FindRelation(
            BoltGameDatabaseProvider database,
            string playerId,
            string friendId)
        {
            return database.GetPlayerFriends(playerId).FirstOrDefault(relation =>
                relation.playerId == friendId ||
                relation.playerInitiatorId == friendId);
        }

        private static List<FriendDocument> GetRelations(
             string playerId,
            IEnumerable<RelationshipStatus> statuses)
        {
            List<FriendDocument> relations = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
            var result = new List<FriendDocument>();

             foreach (RelationshipStatus status in statuses)
            {
                result.AddRange(relations.Where(relation =>
                     relation.relationshipStatus.GetRelationshipStatus(relation.playerInitiatorId == playerId) == status));
            }

            return result;
        }

        private void SendValue<T>(string requestId, T value)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
               {
                    Id = requestId,
                    Return = new RpcValueWriter(typeof(T)).ToBytes(value)
                }
            });
        }

        private void PushFriendEvent(string playerId, string eventName, params object[] payloads)
        {
            SocialEventDelivery.Send<FriendsRemoteEventSender>(
               playerId,
                 "friends",
                eventName,
                payloads ?? Array.Empty<object>());
       }

        private void SendRelationshipStatus(string guid, RelationshipStatus status)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new EnumValueWriter(typeof(RelationshipStatus)).ToBytes(status)
                }
            });
        }

        private void SendException(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
             {
                RpcResponse = new RpcResponse
               {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private void GetPlayerFriendsIdsV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
             {
                ContractWire.SendException(_session, request.Id, 401);
                 return;
            }

           List<int> requested = ContractWire.ReadRepeatedIntField(ContractWire.Param(request), 1);
           HashSet<int> statuses = requested.Count == 0 ? null : new HashSet<int>(requested);
            List<FriendDocument> relations = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
            string[] ids = relations
                .Where(x => x != null && (statuses == null || statuses.Contains((int)x.relationshipStatus.GetRelationshipStatus(x.playerInitiatorId == playerId))))
                .Select(x => x.playerInitiatorId == playerId ? x.playerId : x.playerInitiatorId)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                 .Distinct()
                .ToArray();
            byte[] response = ContractWire.Build(w =>
            {
                foreach (string id in ids) w.String(1, id);
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private static void RefreshJoinStatus(string friendId)
        {
            if (string.IsNullOrWhiteSpace(friendId)) return;

            BoltLobby liveLobby = null;
           lock (ServerState.Lobbies)
            {
                 TspServer.RpcServer.PlayerStatus current = ServerState.GetPlayerStatusSnapshot(friendId);
                string currentLobbyId = current?.playInGame?.lobbyId ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(currentLobbyId))
                     ServerState.Lobbies.TryGetValue(currentLobbyId, out liveLobby);

                if (liveLobby == null)
                {
                    liveLobby = ServerState.Lobbies.Values.FirstOrDefault(lobby =>
                        lobby != null && (lobby.IsLobbyMember(friendId) || lobby.IsLobbySpectator(friendId)));
                }
            }

            if (liveLobby == null) return;

            TspServer.RpcServer.PlayerStatus status = ServerState.GetOrCreatePlayerStatus(friendId);
            status.gpid = friendId;
            status.onlineStatus = TspServer.RpcServer.PlayerStatus.OnlineStatus.StateOnline;
            status.playInGame ??= new TspServer.RpcServer.PlayInGame();
            if (string.IsNullOrWhiteSpace(status.playInGame.gameCode))
                status.playInGame.gameCode = "standoff2";
            if (string.IsNullOrWhiteSpace(status.playInGame.gameVersion))
                status.playInGame.gameVersion = "0.33.0";
            status.playInGame.lobbyId = liveLobby.Id ?? string.Empty;
            status.playInGame.lobbyName = liveLobby.Name ?? string.Empty;

            if (liveLobby.PhotonGame != null)
            {
                status.playInGame.photonGame = new TspServer.RpcServer.PhotonGame
                {
                    region = liveLobby.PhotonGame.region ?? string.Empty,
                    roomId = liveLobby.PhotonGame.roomId ?? string.Empty,
                    appVersion = liveLobby.PhotonGame.appVersion ?? string.Empty,
                    customProperties = liveLobby.PhotonGame.customProperties == null
                       ? new Dictionary<string, string>()
                        : new Dictionary<string, string>(liveLobby.PhotonGame.customProperties, StringComparer.Ordinal)
                };
           }

            ServerState.SetPlayerStatusSnapshot(friendId, status);
            if (ObjectId.TryParse(friendId, out ObjectId objectId))
            {
                try { BoltMainDatabaseProvider.Instance.SetPlayerStatus(objectId, status); }
                catch { }
            }

        }

        private void GetPlayerFriendsV2(RpcRequest request)
        {
             if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

             byte[] raw = ContractWire.Param(request);
            List<int> requested = ContractWire.ReadRepeatedIntField(raw, 1);
            HashSet<int> statuses = requested.Count == 0 ? null : new HashSet<int>(requested);
            int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int size = ContractWire.ReadIntField(raw, 3, 100);
            size = Math.Max(1, Math.Min(size, 500));

            FriendDocument[] relations = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId)
                .Where(x => x != null && (statuses == null || statuses.Contains((int)x.relationshipStatus.GetRelationshipStatus(x.playerInitiatorId == playerId))))
                .Skip(page * size)
                .Take(size)
                .ToArray();

            byte[] response = ContractWire.Build(w =>
            {
                foreach (FriendDocument relation in relations)
                {
                    string friendId = relation.playerInitiatorId == playerId ? relation.playerId : relation.playerInitiatorId;
                    RefreshJoinStatus(friendId);
                    PlayerFriend friend = relation.GetPlayerFriend(playerId);
                    if (friend != null)
                        w.Message(1, SocialContract.SerializePlayerFriend(friend, relation.msg ?? string.Empty));
                }
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerFriendsCount(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            byte[] raw = ContractWire.Param(request);
            List<int> requestedStatuses = ContractWire.ReadRepeatedIntField(raw, 1);
             HashSet<int> statuses = requestedStatuses.Count == 0 ? null : new HashSet<int>(requestedStatuses);

            long count = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId)
                .Where(x => x != null && (statuses == null || statuses.Contains(
                    (int)x.relationshipStatus.GetRelationshipStatus(x.playerInitiatorId == playerId))))
                .LongCount();

            byte[] response = ContractWire.Build(w => w.Varint(1, count, true));
            ContractWire.SendRaw(_session, request.Id, response);
       }

         private void GetOnlineStatus(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out _)) return;
            string targetId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(targetId))
           {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }

            TspServer.RpcServer.PlayerStatus snapshot = ServerState.GetPlayerStatusSnapshot(targetId);
            int status = snapshot == null ? (int)TspServer.RpcServer.PlayerStatus.OnlineStatus.StateOffline : (int)snapshot.onlineStatus;
            byte[] response = ContractWire.Build(w => w.Int32(1, status, true));
            ContractWire.SendRaw(_session, request.Id, response);
        }
        private void GetPlayersCount(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string viewerId)) return;
            string value = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            long count = 0;
            if (!string.IsNullOrWhiteSpace(value))
            {
                try
               {
                    count = BoltMainDatabaseProvider.Instance.GetPlayersDocumentsByUid(value)?.LongLength ?? 0L;
                }
                catch { }
            }

            byte[] response = ContractWire.Build(w => w.Varint(1, count, true));
             ContractWire.SendRaw(_session, request.Id, response);
        }

         private bool TryGetPlayer(string requestId, out string playerId)
        {
           if (SessionIdentity.TryGetPlayerId(_session, out playerId) && !string.IsNullOrWhiteSpace(playerId))
                 return true;
            ContractWire.SendException(_session, requestId, 401);
            playerId = string.Empty;
            return false;
        }

        private bool TryGetPlayerDocument(string gpid, string requestId, out PlayerDocument player)
        {
            player = null;
            if (string.IsNullOrWhiteSpace(gpid) || !ObjectId.TryParse(gpid, out ObjectId objectId))
            {
                ContractWire.SendException(_session, requestId, 404);
               return false;
            }

            try
            {
                player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId);
                if (player != null) return true;
            }
            catch { }

            ContractWire.SendException(_session, requestId, 404);
            return false;
       }

        private static FriendDocument LoadRelation(string playerId, string friendId)
        {
            return BoltGameDatabaseProvider.Instance
                .GetPlayerFriendRelationship(playerId, friendId);
        }
private void SendStatusV2(string requestId, RelationshipStatus status)
        {
            byte[] response = ContractWire.Build(w => w.Int32(1, (int)status, true));
            ContractWire.SendRaw(_session, requestId, response);
        }
        private void GetPlayerById(RpcRequest request)
        {
             if (!TryGetPlayer(request.Id, out string viewerId)) return;
            string targetId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (!TryGetPlayerDocument(targetId, request.Id, out PlayerDocument document)) return;

            RefreshJoinStatus(targetId);
            Player player = FriendHelper.GetPlayer(document);
            byte[] response = ContractWire.Build(w => w.Message(1, SocialContract.SerializePlayer(player)));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerFriendByIdV2(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string viewerId)) return;
            string targetId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (!TryGetPlayerDocument(targetId, request.Id, out PlayerDocument document)) return;

            RefreshJoinStatus(targetId);
            FriendDocument relation = LoadRelation(viewerId, targetId);
            PlayerFriend playerFriend = relation != null
                ? relation.GetPlayerFriend(viewerId)
                : document.GetPlayerFriend();
            byte[] response = ContractWire.Build(w =>
                w.Message(1, SocialContract.SerializePlayerFriend(playerFriend, relation?.msg ?? string.Empty)));
            ContractWire.SendRaw(_session, request.Id, response);
       }

        private void SearchPlayersV2(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string viewerId)) return;
            byte[] raw = ContractWire.Param(request);
           string value = ContractWire.ReadStringField(raw, 1, string.Empty).Trim();
            int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int size = Math.Max(1, Math.Min(ContractWire.ReadIntField(raw, 3, 20), 100));
            if (string.IsNullOrWhiteSpace(value))
            {
                ContractWire.SendRaw(_session, request.Id, Array.Empty<byte>());
                return;
            }

            PlayerDocument[] documents = BoltMainDatabaseProvider.Instance.GetPlayersDocumentsByUid(value)
                .Where(x => x != null && !string.Equals(x._id.ToString(), viewerId, StringComparison.Ordinal))
                .Skip(page * size)
               .Take(size)
                .ToArray();
            byte[] response = ContractWire.Build(w =>
            {
                foreach (PlayerDocument document in documents)
                {
                    string targetId = document._id.ToString();
                    RefreshJoinStatus(targetId);
                    FriendDocument relation = LoadRelation(viewerId, targetId);
                    PlayerFriend friend = relation != null ? relation.GetPlayerFriend(viewerId) : document.GetPlayerFriend();
                    w.Message(1, SocialContract.SerializePlayerFriend(friend, relation?.msg ?? string.Empty));
                }
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerFriendByUid(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string viewerId)) return;
            string uid = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            PlayerDocument document = BoltMainDatabaseProvider.Instance.GetPlayersDocumentsByUid(uid).FirstOrDefault();
            if (document == null)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            string targetId = document._id.ToString();
            RefreshJoinStatus(targetId);
            FriendDocument relation = LoadRelation(viewerId, targetId);
             PlayerFriend friend = relation != null ? relation.GetPlayerFriend(viewerId) : document.GetPlayerFriend();
            byte[] response = ContractWire.Build(w =>
                 w.Message(1, SocialContract.SerializePlayerFriend(friend, relation?.msg ?? string.Empty)));
             ContractWire.SendRaw(_session, request.Id, response);
       }

        private void SendFriendRequestV2(RpcRequest request)
       {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            byte[] raw = ContractWire.Param(request);
            string friendId = ContractWire.ReadStringField(raw, 1, string.Empty);
            string message = ContractWire.ReadStringField(raw, 2, string.Empty) ?? string.Empty;
           if (string.IsNullOrWhiteSpace(friendId) ||
                string.Equals(friendId, playerId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            if (!TryGetPlayerDocument(friendId, request.Id, out _)) return;

            RelationshipStatus result;
            FriendDocument relation;
            bool notifyRequest = false;
            bool notifyAdded = false;

            lock (FriendsLock)
            {
                BoltGameDatabaseProvider game = BoltGameDatabaseProvider.Instance;
                relation = LoadRelation(playerId, friendId);

                if (relation == null)
                {
                    relation = game.CreatePlayerFriendDocument(new FriendDocument
                    {
                        playerInitiatorId = playerId,
                        playerId = friendId,
                        relationshipStatus = RelationshipStatusCustom.Request,
                        msg = message
                    });
                    result = RelationshipStatus.RequestInitiator;
                    notifyRequest = true;
                }
                else
                {
                    bool actorIsInitiator = string.Equals(
                        relation.playerInitiatorId,
                        playerId,
                        StringComparison.Ordinal);

                    switch (relation.relationshipStatus)
                     {
                        case RelationshipStatusCustom.Friend:
                            result = RelationshipStatus.Friend;
                            break;

                        case RelationshipStatusCustom.Blocked:
                           ContractWire.SendException(_session, request.Id, 3102);
                            return;

                        case RelationshipStatusCustom.Request when actorIsInitiator:
                            relation.msg = message;
                            game.UpdatePlayerFriendDocument(playerId, friendId, relation);
                            result = RelationshipStatus.RequestInitiator;
                            notifyRequest = true;
                            break;

                        case RelationshipStatusCustom.Request:
                            relation.relationshipStatus = RelationshipStatusCustom.Friend;
                            relation.msg = string.Empty;
                            game.UpdatePlayerFriendDocument(playerId, friendId, relation);
                            result = RelationshipStatus.Friend;
                            notifyAdded = true;
                            break;

                        case RelationshipStatusCustom.None:
                         case RelationshipStatusCustom.Ignored:
                        default:
                            relation.playerInitiatorId = playerId;
                            relation.playerId = friendId;
                            relation.relationshipStatus = RelationshipStatusCustom.Request;
                            relation.msg = message;
                            game.UpdatePlayerFriendDocument(playerId, friendId, relation);
                            result = RelationshipStatus.RequestInitiator;
                            notifyRequest = true;
                            break;
                     }
                 }
            }

            SendStatusV2(request.Id, result);

            if (notifyRequest)
                PushFriendEvent(
                    friendId,
                    "onNewFriendshipRequest",
                    relation.GetPlayerFriend(friendId),
                    message);
            else if (notifyAdded)
            {
                PushFriendEvent(friendId, "onFriendAdded", relation.GetPlayerFriend(friendId));
                PushFriendEvent(playerId, "onFriendAdded", relation.GetPlayerFriend(playerId));
                SocialProfileEventBridge.ResyncFriendStatusesTo(friendId);
               SocialProfileEventBridge.ResyncFriendStatusesTo(playerId);
            }
        }

        private void RevokeFriendRequestV2(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);
            lock (FriendsLock)
            {
               FriendDocument relation = LoadRelation(playerId, friendId);
                if (relation == null ||
                    relation.relationshipStatus != RelationshipStatusCustom.Request ||
                    !string.Equals(relation.playerInitiatorId, playerId, StringComparison.Ordinal))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                relation.relationshipStatus = RelationshipStatusCustom.None;
                relation.msg = string.Empty;
                BoltGameDatabaseProvider.Instance.UpdatePlayerFriendDocument(
                    playerId, friendId, relation);
           }

            SendStatusV2(request.Id, RelationshipStatus.None);
             PushFriendEvent(friendId, "onRevokeFriendshipRequest", playerId);
        }

        private void AcceptFriendRequestV2(RpcRequest request)
        {
           if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                 ContractWire.Param(request), 1, string.Empty);
            FriendDocument relation;

            lock (FriendsLock)
            {
                relation = LoadRelation(playerId, friendId);
                if (relation == null ||
                    relation.relationshipStatus != RelationshipStatusCustom.Request ||
                    string.Equals(relation.playerInitiatorId, playerId, StringComparison.Ordinal) ||
                    !string.Equals(relation.playerId, playerId, StringComparison.Ordinal))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                 relation.relationshipStatus = RelationshipStatusCustom.Friend;
                relation.msg = string.Empty;
                BoltGameDatabaseProvider.Instance.UpdatePlayerFriendDocument(
                    playerId, friendId, relation);
            }

            SendStatusV2(request.Id, RelationshipStatus.Friend);
            PushFriendEvent(friendId, "onFriendAdded", relation.GetPlayerFriend(friendId));
            PushFriendEvent(playerId, "onFriendAdded", relation.GetPlayerFriend(playerId));
            SocialProfileEventBridge.ResyncFriendStatusesTo(friendId);
             SocialProfileEventBridge.ResyncFriendStatusesTo(playerId);
        }

        private void IgnoreFriendRequestV2(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);

            lock (FriendsLock)
            {
                FriendDocument relation = LoadRelation(playerId, friendId);
                if (relation == null ||
                    relation.relationshipStatus != RelationshipStatusCustom.Request ||
                    string.Equals(relation.playerInitiatorId, playerId, StringComparison.Ordinal) ||
                    !string.Equals(relation.playerId, playerId, StringComparison.Ordinal))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                relation.relationshipStatus = RelationshipStatusCustom.Ignored;
                relation.msg = string.Empty;
                BoltGameDatabaseProvider.Instance.UpdatePlayerFriendDocument(
                    playerId, friendId, relation);
            }

            SendStatusV2(request.Id, RelationshipStatus.Ignored);
            PushFriendEvent(friendId, "onRevokeFriendshipRequest", playerId);
        }

        private void RemoveFriendV2(RpcRequest request)
         {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);

            lock (FriendsLock)
            {
                FriendDocument relation = LoadRelation(playerId, friendId);
                if (relation == null ||
                    relation.relationshipStatus != RelationshipStatusCustom.Friend)
                {
                    ContractWire.SendException(_session, request.Id, 409);
                   return;
                }

                relation.relationshipStatus = RelationshipStatusCustom.None;
               relation.msg = string.Empty;
                BoltGameDatabaseProvider.Instance.UpdatePlayerFriendDocument(
                    playerId, friendId, relation);
            }

            SendStatusV2(request.Id, RelationshipStatus.None);
            PushFriendEvent(friendId, "onFriendRemoved", playerId);
        }

        private void BlockFriendV2(RpcRequest request)
        {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(friendId) ||
                string.Equals(friendId, playerId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            if (!TryGetPlayerDocument(friendId, request.Id, out _)) return;

            lock (FriendsLock)
            {
                 BoltGameDatabaseProvider game = BoltGameDatabaseProvider.Instance;
                FriendDocument relation = LoadRelation(playerId, friendId);
                if (relation == null)
                {
                    relation = game.CreatePlayerFriendDocument(new FriendDocument
                    {
                        playerInitiatorId = playerId,
                        playerId = friendId,
                        relationshipStatus = RelationshipStatusCustom.Blocked,
                        msg = string.Empty
                     });
                }
                else
                {
                    relation.playerInitiatorId = playerId;
                    relation.playerId = friendId;
                     relation.relationshipStatus = RelationshipStatusCustom.Blocked;
                    relation.msg = string.Empty;
                    game.UpdatePlayerFriendDocument(playerId, friendId, relation);
                }
            }

            SendStatusV2(request.Id, RelationshipStatus.Blocked);
            PushFriendEvent(friendId, "onFriendRemoved", playerId);
        }

        private void UnblockFriendV2(RpcRequest request)
         {
            if (!TryGetPlayer(request.Id, out string playerId)) return;
            string friendId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);

            lock (FriendsLock)
            {
                FriendDocument relation = LoadRelation(playerId, friendId);
                if (relation == null ||
                    relation.relationshipStatus != RelationshipStatusCustom.Blocked ||
                     !string.Equals(relation.playerInitiatorId, playerId, StringComparison.Ordinal))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                    return;
                }

                relation.relationshipStatus = RelationshipStatusCustom.None;
                relation.msg = string.Empty;
                BoltGameDatabaseProvider.Instance.UpdatePlayerFriendDocument(
                    playerId, friendId, relation);
            }

            SendStatusV2(request.Id, RelationshipStatus.None);
        }

       private void EnsureFriendEvents()
        {
           if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId)) return;
            ServerState.EnsureConnectionEventSender(
                playerId, _session.TcpClient, () => new FriendsRemoteEventSender(_session));
        }

        public override void Invoke(RpcRequest request)
        {
            EnsureFriendEvents();
            if (request.MethodName == "getPlayerFriendsIds2") GetPlayerFriendsIdsV2(request);
            else if (request.MethodName == "getPlayerFriends2") GetPlayerFriendsV2(request);
            else if (request.MethodName == "getPlayerFriendsCount2") GetPlayerFriendsCount(request);
            else if (request.MethodName == "getOnlineStatus2") GetOnlineStatus(request);
            else if (request.MethodName == "getPlayersCount2") GetPlayersCount(request);
            else if (request.MethodName == "getPlayerById2") GetPlayerById(request);
            else if (request.MethodName == "getPlayerFriendById2") GetPlayerFriendByIdV2(request);
            else if (request.MethodName == "getPlayerFriendByUid2") GetPlayerFriendByUid(request);
            else if (request.MethodName == "searchPlayers2") SearchPlayersV2(request);
            else if (request.MethodName == "sendFriendRequest2") SendFriendRequestV2(request);
            else if (request.MethodName == "revokeFriendRequest2") RevokeFriendRequestV2(request);
            else if (request.MethodName == "acceptFriendRequest2") AcceptFriendRequestV2(request);
           else if (request.MethodName == "ignoreFriendRequest2") IgnoreFriendRequestV2(request);
            else if (request.MethodName == "removeFriend2") RemoveFriendV2(request);
            else if (request.MethodName == "blockFriend2") BlockFriendV2(request);
            else if (request.MethodName == "unblockFriend2") UnblockFriendV2(request);
            else if (request.MethodName == "getAvatars") GetAvatars(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayerFriendsIds") GetPlayerFriendsIds(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayerFriends") GetPlayerFriends(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getPlayerFriend" || request.MethodName == "getPlayerFriendById") GetPlayerFriendById((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "searchPlayers") SearchPlayers(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "blockFriend") BlockFriend(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "removeFriend") RemoveFriend(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "unblockFriend") UnblockFriend(request.Params.ToArray(), request.Id);
             else if (request.MethodName == "revokeFriendRequest") RevokeFriendRequest(request.Params.ToArray(), request.Id);
           else if (request.MethodName == "ignoreFriendRequest") IgnoreFriendRequest(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "acceptFriendRequest") AcceptFriendRequest(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "sendFriendRequest") SendFriendRequest(request.Params.ToArray(), request.Id);
            else
            {
                ContractWire.SendException(_session, request.Id, 404);
            }
        }
    }
    public class FriendsRemoteEventSender : IEventSender
    {
        private readonly ClientSession User;
        public string eventListenerName { get; set; } = "FriendsRemoteEventListener";

        public FriendsRemoteEventSender(ClientSession user) { User = user; }

       public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse envelope = BoltEventContract.Create(
                eventListenerName, eventName, parameters ?? Array.Empty<object>());
            User.SendResponse(new ResponseMessage { EventResponse = envelope });
        }
    }
}
