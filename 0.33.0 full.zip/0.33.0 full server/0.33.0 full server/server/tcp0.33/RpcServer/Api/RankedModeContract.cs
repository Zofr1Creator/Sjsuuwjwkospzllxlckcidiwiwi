using System;

namespace TspServer.RpcServer.Api
{
    internal enum RankedModeId
    {
       Ranked5v5 = 0,
        Ranked2v2 = 1,
        RankedDuel = 2
    }

   internal sealed class RankedModeContract
    {
        public RankedModeId Id;
        public string WireName;
        public string Profile;
        public string RoomPrefix;
        public string StatPrefix;
        public int ProductionPlayers;
        public int TestPlayers;

        public string QueueKey(string profile, string filter, string region, string season)
        {
            return string.Join("|", new[]
            {
                Id == RankedModeId.Ranked2v2 ? "ranked2v2" :
                Id == RankedModeId.RankedDuel ? "rankedduel" : "ranked5v5",
                Normalize(profile), Normalize(filter), Normalize(region), Normalize(season)
           });
       }

        public string CreateRoomId()
        {
            return RoomPrefix + Guid.NewGuid().ToString("N");
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Trim().ToLowerInvariant();
         }
    }

    internal static class RankedModeContracts
    {
        public static readonly RankedModeContract Ranked5v5 = new RankedModeContract
        {
            Id = RankedModeId.Ranked5v5,
            WireName = "RankedDefuse",
            Profile = "eur_ranked_defuse_s3",
            RoomPrefix = "RankedDefuse_ranked5v5_",
            StatPrefix = "ranked_",
             ProductionPlayers = 10,
            TestPlayers = 3
        };

        public static readonly RankedModeContract Ranked2v2 = new RankedModeContract
        {
            Id = RankedModeId.Ranked2v2,
            WireName = "Ranked2v2",
            Profile = "eur_ranked_defuse_2v2_s3",
            RoomPrefix = "Ranked2v2_ranked2v2_",
            StatPrefix = "ranked_2v2_",
            ProductionPlayers = 4,
            TestPlayers = 2
        };

        public static readonly RankedModeContract RankedDuel = new RankedModeContract
        {
            Id = RankedModeId.RankedDuel,
            WireName = "RankedDuel",
            Profile = "eur_ranked_duel_s3",
            RoomPrefix = "RankedDuel_rankedduel_",
            StatPrefix = "ranked_duel_",
           ProductionPlayers = 2,
            TestPlayers = 2
        };

        public static bool TryResolve(string profile, string filter, out RankedModeContract contract)
       {
            string p = (profile ?? string.Empty).Trim();
            string f = (filter ?? string.Empty).Trim();

            if (string.Equals(p, Ranked5v5.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, Ranked5v5.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p, Ranked5v5.WireName, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, Ranked5v5.WireName, StringComparison.OrdinalIgnoreCase))
            {
                contract = Ranked5v5;
                return true;
           }

            if (string.Equals(p, Ranked2v2.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, Ranked2v2.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p, Ranked2v2.WireName, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, Ranked2v2.WireName, StringComparison.OrdinalIgnoreCase))
            {
                contract = Ranked2v2;
                 return true;
            }

            if (string.Equals(p, RankedDuel.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, RankedDuel.Profile, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p, RankedDuel.WireName, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(f, RankedDuel.WireName, StringComparison.OrdinalIgnoreCase))
            {
                contract = RankedDuel;
                return true;
            }

            contract = null;
             return false;
        }

        public static RankedModeContract FromId(RankedModeId id)
        {
            if (id == RankedModeId.Ranked2v2) return Ranked2v2;
            if (id == RankedModeId.RankedDuel) return RankedDuel;
            return Ranked5v5;
        }

        public static int GetRequiredPlayers(RankedModeContract contract)
         {
            string[] perModeNames = contract.Id == RankedModeId.Ranked2v2
                ? new[] { "RANKED_2V2_REQUIRED_PLAYERS", "BOLT_RANKED_2V2_REQUIRED_PLAYERS", "UDP_RANKED_2V2_REQUIRED_PLAYERS" }
                : contract.Id == RankedModeId.RankedDuel
                    ? new[] { "RANKED_DUEL_REQUIRED_PLAYERS", "BOLT_RANKED_DUEL_REQUIRED_PLAYERS", "UDP_RANKED_DUEL_REQUIRED_PLAYERS" }
                    : new[] { "RANKED_5V5_REQUIRED_PLAYERS", "BOLT_RANKED_5V5_REQUIRED_PLAYERS", "UDP_RANKED_5V5_REQUIRED_PLAYERS" };

           int parsed;
            foreach (string name in perModeNames)
            {
                string rawValue = Environment.GetEnvironmentVariable(name);
                if (int.TryParse(rawValue, out parsed) && parsed > 0)
                    return Math.Max(1, Math.Min(parsed, contract.ProductionPlayers));
            }

            string test = Environment.GetEnvironmentVariable("RANKED_TEST_MODE");
            if (string.Equals(test, "1", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(test, "true", StringComparison.OrdinalIgnoreCase))
                return contract.TestPlayers;

            return contract.ProductionPlayers;
        }
    }
}
