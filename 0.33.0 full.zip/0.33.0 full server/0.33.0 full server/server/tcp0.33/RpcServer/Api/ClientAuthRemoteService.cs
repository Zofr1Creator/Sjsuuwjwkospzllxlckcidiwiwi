using System;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class ClientAuthRemoteService : RpcHandler
    {
        private const int PasswordIterations = 120_000;
        public ClientAuthRemoteService(ClientSession session)
            : base(session)
        {
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            if (request == null ||
               (request.MethodName != "auth" && request.MethodName != "auth_up"))
                return Task.CompletedTask;
            string result;

            try
            {
                BinaryValue[] parameters = request.Params.ToArray();
                if (parameters.Length < 4)
                    throw new AuthException("BAD_PARAMS");

                string gameId = ReadString(parameters[0]);
                string gameVersion = ReadString(parameters[1]);
                string token = ReadString(parameters[3]).Trim();

                result = request.MethodName == "auth"
                     ? LoginWithToken(gameId, gameVersion, token)
                    : LoginWithCredentials(gameId, gameVersion, token, parameters);

                _session.LastAuthToken = result;
                _session.LastGameId = gameId;
                _session.LastGameVersion = gameVersion;

            }
            catch (AuthException ex)
            {
                result = "ERR|" + ex.Code;
            }
            catch
            {
                result = "ERR|SERVER";
            }

            SendResult(request.Id, result);
            return Task.CompletedTask;
        }

        public override void Invoke(RpcRequest request)
        {
             InvokeAsync(request).GetAwaiter().GetResult();
        }

        private string LoginWithToken(
            string gameId,
           string gameVersion,
            string token)
        {
            BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;

            if (string.IsNullOrWhiteSpace(token))
                return CreateLocalPlayer(database, gameId, gameVersion);

            if (ServerState.Tokens.TryGetValue(token, out Token cached))
            {
                if (!string.Equals(cached.gameCode, gameId, StringComparison.Ordinal))
                    throw new AuthException("TOKEN_GAME_MISMATCH");

                cached.gameVersion = gameVersion;
                EnsurePlayerDocuments(cached.playerId.ToString());

                 return token;
            }

            LocalAccountDocument account;
            try
             {
                account = database.GetLocalAccount(token);
            }
            catch (AccountNotFoundException)
            {
                 throw new AuthException("INVALID_TOKEN");
            }

            if (account == null)
                throw new AuthException("INVALID_TOKEN");

           ObjectId playerId = ParsePlayerId(account.playerId);
            CacheToken(token, playerId, gameId, gameVersion);
           EnsurePlayerDocuments(account.playerId);


            return token;
        }

        private string LoginWithCredentials(
            string gameId,
            string gameVersion,
            string token,
            BinaryValue[] parameters)
        {
             if (parameters.Length < 6)
                throw new AuthException("BAD_PARAMS");

            string username = ReadString(parameters[4]).Trim().ToLowerInvariant();
            string password = ReadString(parameters[5]);

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                throw new AuthException("BAD_INPUT");

           BoltMainDatabaseProvider database = BoltMainDatabaseProvider.Instance;

            string? restoredToken = RestoreToken(
                database,
                gameId,
                gameVersion,
                token);

            if (restoredToken != null)
                return restoredToken;

            LocalAccountDocument? account = database.GetLocalAccountByUsername(username);
            if (account != null)
                return LoginExisting(database, account, gameId, gameVersion, password, username);

            return CreateAccount(
                 database,
                gameId,
                gameVersion,
                username,
                password);
        }

        private static string? RestoreToken(
            BoltMainDatabaseProvider database,
            string gameId,
            string gameVersion,
            string token)
        {
            if (string.IsNullOrWhiteSpace(token))
                return null;

            try
            {
                LocalAccountDocument account = database.GetLocalAccount(token);
                if (account == null || !ObjectId.TryParse(account.playerId, out ObjectId playerId))
                    return null;

                CacheToken(token, playerId, gameId, gameVersion);
                EnsurePlayerDocuments(account.playerId);
                return token;
            }
            catch (AccountNotFoundException)
            {
                return null;
            }
        }

        private static string LoginExisting(
            BoltMainDatabaseProvider database,
            LocalAccountDocument account,
            string gameId,
            string gameVersion,
            string password,
            string username)
        {
            if (!VerifyPassword(password, account.passSalt, account.passHash))
                throw new AuthException("WRONG_PASSWORD");
            string token = account.token;
            if (string.IsNullOrWhiteSpace(token))
            {
                token = CreateToken();
                database.UpdateAccountTokenByUsername(username, token);
            }

             ObjectId playerId = ParsePlayerId(account.playerId);
            CacheToken(token, playerId, gameId, gameVersion);
            EnsurePlayerDocuments(account.playerId);

            return token;
        }

        private static string CreateAccount(
            BoltMainDatabaseProvider database,
            string gameId,
            string gameVersion,
            string username,
            string password)
         {
             string token = CreateToken();
            int numericGameId = ParseGameId(gameId);
            string uid = database.GetNextUid100k().ToString();

            database.CreateLocalAccountWithPlayer(
                username,
                uid,
                token,
                numericGameId);

            PasswordData passwordData = HashPassword(password);
            database.SetUsernamePasswordForToken(
                token,
                username,
                 passwordData.Salt,
                passwordData.Hash);

            LocalAccountDocument account = database.GetLocalAccount(token);
            if (account == null)
                throw new AuthException("ACCOUNT_CREATE_FAILED");
            ObjectId playerId = ParsePlayerId(account.playerId);
            CacheToken(token, playerId, gameId, gameVersion);
            EnsurePlayerDocuments(account.playerId);

            return token;
        }

        private static string CreateLocalPlayer(
            BoltMainDatabaseProvider database,
           string gameId,
            string gameVersion)
        {
            string token = CreateToken();
            string uid = database.GetNextUid100k().ToString();
            database.CreateLocalAccountWithPlayer(
                "T_" + uid,
                uid,
                token,
                ParseGameId(gameId));

            LocalAccountDocument account = database.GetLocalAccount(token);
            if (account == null)
                throw new AuthException("ACCOUNT_CREATE_FAILED");

            ObjectId playerId = ParsePlayerId(account.playerId);
            CacheToken(token, playerId, gameId, gameVersion);
            EnsurePlayerDocuments(account.playerId);


            return token;
        }

        private static void CacheToken(
            string token,
            ObjectId playerId,
            string gameId,
            string gameVersion)
         {
            ServerState.Tokens[token] = new Token
            {
                playerId = playerId,
                gameCode = gameId,
                gameVersion = gameVersion
            };
        }

        private static void EnsurePlayerDocuments(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return;

            ObjectId objectId = ParsePlayerId(playerId);
            BoltGameDatabaseProvider gameDatabase = BoltGameDatabaseProvider.Instance;

            try
            {
                gameDatabase.GetPlayerStatsDocument(playerId);
             }
             catch
            {
                 gameDatabase.CreatePlayerStats(playerId);
            }

           try
            {
               gameDatabase.GetFiles(objectId);
            }
            catch
            {
                 gameDatabase.CreatePlayerFiles(playerId);
            }

            try
            {
                gameDatabase.GetPlayerInventoryDocument(objectId);
            }
            catch
            {
                gameDatabase.CreatePlayerInventory(objectId);
            }
        }

        private void SendResult(string requestId, string result)
        {
            BinaryValue value = new RpcValueWriter(typeof(string)).ToBytes(result);
            _session.SendResponse(
                new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = requestId,
                        Return = value
                    }
                });
         }

        private static string ReadString(BinaryValue value)
        {
            return (string?)new RpcValueReader(typeof(string)).FromBytes(value) ?? string.Empty;
        }

        private static int ParseGameId(string gameId)
        {
            return int.TryParse(gameId, out int value) ? value : 1;
        }

        private static ObjectId ParsePlayerId(string playerId)
        {
             if (!string.IsNullOrWhiteSpace(playerId) && ObjectId.TryParse(playerId, out ObjectId parsed))
                return parsed;

            throw new AuthException("INVALID_PLAYER_ID");
        }

        private static string CreateToken()
       {
            byte[] bytes = RandomNumberGenerator.GetBytes(32);
            return Convert.ToBase64String(bytes)
                .TrimEnd('=')
                .Replace('+', '-')
                 .Replace('/', '_');
        }

        private static PasswordData HashPassword(string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);
            byte[] hash;

            using (var deriveBytes = new Rfc2898DeriveBytes(
                       password,
                       salt,
                       PasswordIterations,
                       HashAlgorithmName.SHA256))
            {
               hash = deriveBytes.GetBytes(32);
            }

            return new PasswordData(
                Convert.ToBase64String(salt),
                Convert.ToBase64String(hash));
        }

        private static bool VerifyPassword(
           string password,
            string saltBase64,
            string hashBase64)
        {
            if (string.IsNullOrWhiteSpace(saltBase64) || string.IsNullOrWhiteSpace(hashBase64))
                return false;

            try
            {
                 byte[] salt = Convert.FromBase64String(saltBase64);
                byte[] expectedHash = Convert.FromBase64String(hashBase64);
               byte[] actualHash;

                using (var deriveBytes = new Rfc2898DeriveBytes(
                           password,
                           salt,
                           PasswordIterations,
                           HashAlgorithmName.SHA256))
                {
                   actualHash = deriveBytes.GetBytes(32);
                }

                return CryptographicOperations.FixedTimeEquals(actualHash, expectedHash);
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private readonly record struct PasswordData(string Salt, string Hash);

        private sealed class AuthException : System.Exception
        {
           public AuthException(string code)
                : base(code)
            {
                Code = code;
            }

            public string Code { get; }
        }
    }
}
