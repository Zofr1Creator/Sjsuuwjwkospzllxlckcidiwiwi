using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace TspServer.RpcServer.Api
{

   public sealed class InventoryRemoteEventSender : IEventSender
    {
        private readonly ClientSession _session;
        public ClientSession User => _session;
        public string eventListenerName { get; set; } = InventoryEventBus.ListenerName;

        public InventoryRemoteEventSender(ClientSession user) => _session = user;

        public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse response = BoltEventContract.Create(
                eventListenerName, eventName, parameters ?? Array.Empty<object>());
            SendEnvelope(response, "legacy-object");
        }

        public void SendRawEvent(string eventName, byte[] payload, string targetPlayerId, string source)
        {
            EventResponse response = BoltEventContract.CreateRaw(
                eventListenerName, eventName, payload ?? Array.Empty<byte>());
            SendEnvelope(response, $"{source};target={targetPlayerId}");
        }

        private void SendEnvelope(EventResponse response, string source)
       {

            _session.SendResponse(new ResponseMessage { EventResponse = response });
        }
     }

    internal static class InventoryEventBus
    {
        public const string ListenerName = "InventoryRemoteEventListener";

        public static int InventoryChanged(
            string playerId,
            IEnumerable<InventoryItem> added = null,
            IEnumerable<InventoryItem> changed = null,
            IEnumerable<CurrencyAmount> currencies = null,
            string source = "mutation",
            ClientSession preferredUser = null)
        {
           InventoryItem[] addedItems = (added ?? Enumerable.Empty<InventoryItem>())
                .Where(x => x != null).ToArray();
            InventoryItem[] changedItems = (changed ?? Enumerable.Empty<InventoryItem>())
                .Where(x => x != null).ToArray();
            CurrencyAmount[] currencyItems = (currencies ?? Enumerable.Empty<CurrencyAmount>())
                .Where(x => x != null).ToArray();

            byte[] payload = ContractWire.Build(w =>
            {
                foreach (InventoryItem item in addedItems) w.Message(1, item);
               foreach (InventoryItem item in changedItems) w.Message(2, item);
                foreach (CurrencyAmount currency in currencyItems) w.Message(3, currency);
            });
            return SendRaw(playerId, "onInventoryChanged", payload,
                $"{source};added={addedItems.Length};changed={changedItems.Length};currencies={currencyItems.Length}",
                preferredUser);
       }

        public static int CouponActivated(
            string playerId,
            IEnumerable<InventoryItem> items,
            IEnumerable<CurrencyAmount> currencies,
            string source = "coupon")
        {
            InventoryItem[] itemArray = (items ?? Enumerable.Empty<InventoryItem>())
                .Where(x => x != null).ToArray();
            CurrencyAmount[] currencyArray = (currencies ?? Enumerable.Empty<CurrencyAmount>())
               .Where(x => x != null).ToArray();
            byte[] reward = ContractWire.Build(w =>
            {
                foreach (InventoryItem item in itemArray) w.Message(1, item);
                foreach (CurrencyAmount currency in currencyArray) w.Message(2, currency);
            });
            byte[] payload = ContractWire.Build(w => w.Message(1, reward));
            return SendRaw(playerId, "onCouponActivated", payload,
                $"{source};items={itemArray.Length};currencies={currencyArray.Length}");
        }

        private static int SendRaw(
            string playerId,
            string eventName,
            byte[] payload,
            string source,
            ClientSession preferredUser = null)
         {
            if (string.IsNullOrWhiteSpace(playerId)) return 0;
            List<InventoryRemoteEventSender> senders =
                ServerState.GetLiveEventSenders<InventoryRemoteEventSender>(playerId);

             if (preferredUser != null)
            {
                InventoryRemoteEventSender preferred = senders
                   .FirstOrDefault(x => ReferenceEquals(x.User, preferredUser));
                senders = preferred == null
                    ? new List<InventoryRemoteEventSender>()
                    : new List<InventoryRemoteEventSender> { preferred };
            }

            int delivered = 0;
            foreach (InventoryRemoteEventSender sender in senders.Distinct())
             {
                try
                {
                    sender.SendRawEvent(eventName, payload, playerId, source);
                    delivered++;
                }
                catch (System.Exception)
                {
                }
            }
            return delivered;
        }
    }
}
