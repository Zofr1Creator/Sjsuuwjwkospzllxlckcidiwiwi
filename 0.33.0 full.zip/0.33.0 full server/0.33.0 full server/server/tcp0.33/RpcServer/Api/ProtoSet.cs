using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace TspServer.RpcServer.Api
{
    internal static class ProtoSet
    {
        public static void Set(object obj, string name, object value)
        {
            if (obj == null) return;

            var t = obj.GetType();
            bool assigned = false;

            var p = t.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (p != null && p.CanWrite)
            {
                assigned = TryAssign(obj, p.PropertyType, v => p.SetValue(obj, v), value);
                if (assigned)
                {
                    TrySetHasFlag(obj, name, value != null);
                    return;
                }
            }

            foreach (var fName in GetFieldCandidates(name))
            {
                var f = t.GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                if (f == null) continue;

                assigned = TryAssign(obj, f.FieldType, v => f.SetValue(obj, v), value);
                if (assigned)
                {
                   TrySetHasFlag(obj, name, value != null);
                    return;
                }
            }

        }

        private static IEnumerable<string> GetFieldCandidates(string propName)
        {
            var lowerCamel = char.ToLowerInvariant(propName[0]) + propName.Substring(1);

            yield return lowerCamel + "_";
            yield return propName + "_";

            yield return lowerCamel;
           yield return propName;

            yield return "_" + lowerCamel;
            yield return "_" + propName;
        }

       private static bool TryAssign(object target, Type targetType, Action<object> setter, object value)
        {
            try
            {
                if (value == null)
               {
                    if ((Nullable.GetUnderlyingType(targetType) ?? targetType).IsValueType &&
                        Nullable.GetUnderlyingType(targetType) == null)
                        return false;

                    setter(null);
                    return true;
                }

                var nn = Nullable.GetUnderlyingType(targetType) ?? targetType;

                if (nn.IsEnum)
               {
                    if (value.GetType().IsEnum)
                    {
                        setter(System.Enum.ToObject(nn, Convert.ToInt32(value)));
                        return true;
                    }
                    setter(System.Enum.ToObject(nn, Convert.ToInt32(value)));
                    return true;
                }
                if (nn.IsAssignableFrom(value.GetType()))
                {
                    setter(value);
                    return true;
                }

                if (nn == typeof(int)) { setter(Convert.ToInt32(value)); return true; }
                if (nn == typeof(long)) { setter(Convert.ToInt64(value)); return true; }
                if (nn == typeof(double)) { setter(Convert.ToDouble(value)); return true; }
                if (nn == typeof(float)) { setter(Convert.ToSingle(value)); return true; }
                if (nn == typeof(bool)) { setter(Convert.ToBoolean(value)); return true; }
                if (nn == typeof(string)) { setter(Convert.ToString(value)); return true; }

                setter(Convert.ChangeType(value, nn));
                return true;
           }
            catch
            {
                return false;
            }
        }

        private static void TrySetHasFlag(object obj, string propName, bool flag)
        {
            var t = obj.GetType();
             var upper = propName;
            var lowerCamel = char.ToLowerInvariant(propName[0]) + propName.Substring(1);

            foreach (var cand in GetHasCandidates(upper, lowerCamel))
            {
                var f = t.GetField(cand, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                if (f != null && (Nullable.GetUnderlyingType(f.FieldType) ?? f.FieldType) == typeof(bool))
                {
                    try { f.SetValue(obj, flag); } catch { }
                    return;
                }

                var p = t.GetProperty(cand, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                if (p != null && p.CanWrite && (Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType) == typeof(bool))
                {
                    try { p.SetValue(obj, flag); } catch { }
                    return;
                }
            }
        }

        private static IEnumerable<string> GetHasCandidates(string upper, string lowerCamel)
        {
            yield return "has" + upper;
            yield return "has" + lowerCamel;

            yield return "has" + upper + "_";
            yield return "has" + lowerCamel + "_";

            yield return "Has" + upper;
            yield return "Has" + lowerCamel;
        }
    }
}
