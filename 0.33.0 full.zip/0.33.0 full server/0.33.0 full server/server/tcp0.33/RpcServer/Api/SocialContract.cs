using System;
using Axlebolt.Bolt.Protobuf2;
using Google.Protobuf;

namespace TspServer.RpcServer.Api
{

    internal static class SocialContract
   {
        internal static byte[] SerializeMessage(IMessage message)
        {
            return message?.ToByteArray() ?? Array.Empty<byte>();
        }

        internal static byte[] SerializePlayer(Player player)
        {
            return SerializeMessage(player);
        }

        internal static byte[] SerializeUserMessage(UserMessage message)
        {
            return SerializeMessage(message);
        }

        internal static byte[] SerializePlayerFriend(PlayerFriend friend, string requestMessage = "")
        {
            if (friend == null) return Array.Empty<byte>();

            return ContractWire.Build(w =>
            {
                w.Message(1, friend.Player);
                w.Int32(2, (int)friend.RelationshipStatus);
                w.Varint(3, friend.LastRelationshipUpdate);
                w.String(4, requestMessage ?? string.Empty);
            });
        }

        internal static byte[] SerializeLobbyInvite(LobbyInvite invite, string lobbyName = "")
        {
            if (invite == null) return Array.Empty<byte>();

            return ContractWire.Build(w =>
             {
                w.String(1, invite.LobbyId);
                w.Message(2, invite.InviteSender == null
                    ? null
                    : SerializePlayerFriend(invite.InviteSender));
                w.Varint(3, invite.Date);
                w.Int32(4, (int)invite.PlayerType);
                w.String(5, lobbyName ?? string.Empty);
            });
        }
    }
}
