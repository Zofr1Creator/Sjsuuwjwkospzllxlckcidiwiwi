using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;


namespace TspServer.RpcServer.Api
{
    public partial class MatchmakingRemoteService : RpcHandler
    {
        private static int _lobbyRouteProbeSent;
        private const string RankedListenerName = "MatchmakingRemoteListener";
        private const string RankedPlayersConfirmedEvent = "onPlayersConfirmed";
         private const string RankedProgressEvent = "onMatchmakingProgress";
        private const string RankedDoneEvent = "onMatchmakingDone";
        private const string RankedFailEvent = "onMatchmakingFail";

        private const int RankedStateGroupWait = 10;

        private const int RankedStateMatchmaking = 20;

        private const int RankedStateConfirmation = 30;

        private const int RankedStateNotConfirmed = 40;

         private const int DefaultRankedReadyRetentionSeconds = 120;

        private static readonly object RankedSync = new();
        private static readonly List<RankedParticipant> RankedWaiting = new List<RankedParticipant>();

         private static readonly Dictionary<string, RankedParticipant> RankedByPlayer =
             new Dictionary<string, RankedParticipant>(StringComparer.Ordinal);

        private static readonly Dictionary<string, long> RankedGenerationByPlayer =
            new Dictionary<string, long>(StringComparer.Ordinal);

        private static readonly Dictionary<string, string> RankedLastLevelByQueue =
            new Dictionary<string, string>(StringComparer.Ordinal);

        private static readonly Timer RankedMatchmakerTimer =
            new Timer(_ => TickRankedMatchmaker(), null, 1000, 1000);

        private string _rankedFilterCondition = "eur_ranked_defuse_s3";

         private string _rankedRoomId;
        private int _rankedStateCode;
       private byte[] _rankedPlayerBytes;
        private bool _rankedActive;
        private RankedParticipant _rankedParticipant;
       private long _rankedGeneration;

        public MatchmakingRemoteService(ClientSession user) : base(user) { }
        protected void SetLobbyMaxMembers(int maxMembers, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
               var boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" &&
                    ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    lobby.MaxMembers = maxMembers;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                       {
                            eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                                .SendEvent("onLobbyMaxMembersChanged", new object[] { (byte)maxMembers });
                       }

                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                                .SendEvent("onLobbyMaxMembersChanged", new object[] { (byte)maxMembers });
                        }

                    ServerState.Lobbies[lobby.Id] = lobby;
                   PersistLobby(lobby);
                    _session.SendResponse(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                 RpcResponse = new RpcResponse
                {
                     Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                     }
                }
            });
        }
        protected void SetLobbyType(BinaryValue[] values, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
               
                var from = new EnumValueReader(typeof(Axlebolt.Bolt.Protobuf2.LobbyType));

                 var type = (Axlebolt.Bolt.Protobuf2.LobbyType)from.FromBytes(values[0]);
                var boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    ServerState.Lobbies[lobby.Id].Type = (BoltLobby.LobbyType)type;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                       
                     if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyTypeChanged", new object[] { type });
                        }
                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyTypeChanged", new object[] { type });
                        }
                    PersistLobby(lobby);
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
             _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
         }

       protected void SetLobbyMaxSpectators(int maxMembers, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" &&
                    ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    lobby.MaxSpectators = maxMembers;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                                .SendEvent("onLobbyMaxSpectatorsChanged", new object[] { (byte)maxMembers });
                        }

                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                               .SendEvent("onLobbyMaxSpectatorsChanged", new object[] { (byte)maxMembers });
                        }

                    ServerState.Lobbies[lobby.Id] = lobby;
                    PersistLobby(lobby);

                    _session.SendResponse(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });


                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                   {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void CreateLobbyWithSpectators(string name, LobbyType lobbyType, int maxMembers, int maxSpectators, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
             {
                var boltMain = BoltMainDatabaseProvider.Instance;
                 var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                var lobby = new BoltLobby(Guid.NewGuid().ToString(),
                    Id,
                    name,
                   EnumMapper<Axlebolt.Bolt.Protobuf2.LobbyType, BoltLobby.LobbyType>.ToOriginal(
                        (Axlebolt.Bolt.Protobuf2.LobbyType)lobbyType),
                     true, maxMembers,
                     maxSpectators,
                    new System.Collections.Concurrent.ConcurrentDictionary<string, string>(),
                    new List<BoltFriend> { playerDocument.GetBoltFriend() },
                    new List<BoltFriend>(), new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    new GameServer() { Ip = "", Port = 5055 },
                    null)
                {
                    LobbyOwnerId = Id
                };
                var stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "")
                {
                    _session.SendResponse(new ResponseMessage
                     {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 401
                            }
                        }
                    });
                     return;
                }

                stat.playInGame.lobbyId = lobby.Id;
                stat.playInGame.lobbyName = lobby.Name;
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                ServerState.Lobbies.Add(lobby.Id, lobby);
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                   { Id = guid, Return = new RpcValueWriter(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id)) }
                });
                 return;
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                   Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void CreateLobby(string name, LobbyType lobbyType, int maxMembers, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                var lobby = new BoltLobby(Guid.NewGuid().ToString(),
                    Id,
                    name,
                    EnumMapper<Axlebolt.Bolt.Protobuf2.LobbyType, BoltLobby.LobbyType>.ToOriginal(
                         (Axlebolt.Bolt.Protobuf2.LobbyType)lobbyType),
                    lobbyType == LobbyType.Public ? true : false, maxMembers,
                    0,
                    new System.Collections.Concurrent.ConcurrentDictionary<string, string>(),
                    new List<BoltFriend> { playerDocument.GetBoltFriend() },
                    new List<BoltFriend>(), new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    new GameServer() { Ip = "", Port = 5055 },
                    null)
                {
                    LobbyOwnerId = Id
                };
                var stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "")
               {
                    _session.SendResponse(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 401
                            }
                        }
                    });
                    return;
                }

                stat.playInGame.lobbyId = lobby.Id;
                stat.playInGame.lobbyName = lobby.Name;
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                ServerState.Lobbies.Add(lobby.Id, lobby);
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    { Id = guid, Return = new RpcValueWriter(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id)) }
                });
                return;
            }
            _session.SendResponse(new ResponseMessage
           {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetLobbyData(Dictionary dictionary, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    var mergedData = new Dictionary<string, string>(
                        BoltLobby.NormalizeLobbyData(lobby.Data),
                        StringComparer.Ordinal);

                    if (dictionary != null)
                    {
                        foreach (KeyValuePair<string, string> item in dictionary.Content)
                        {
                            if (string.IsNullOrEmpty(item.Value))
                            {
                                if (!BoltLobby.IsRequiredLobbyKey(item.Key))
                                    mergedData.Remove(item.Key);
                            }
                            else
                            {
                                mergedData[item.Key] = item.Value;
                             }
                        }
                    }

                    lobby.Data = BoltLobby.NormalizeLobbyData(mergedData);
                   ServerState.Lobbies[lobby.Id] = lobby;

                    var normalizedEventData = new Axlebolt.Bolt.Protobuf2.Dictionary();
                    normalizedEventData.Content.Add(lobby.Data);

                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault()?.SendEvent(
                                "onLobbyDataChanged", new object[] { normalizedEventData });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault()?.SendEvent(
                                 "onLobbyDataChanged", new object[] { normalizedEventData });
                        }
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetLobbyOwner(string playerId, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                var stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" &&
                    ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out var lobby))
                {
                    lobby.AddLobbyMember(lobby.LobbyOwner);
                    lobby.LobbyOwnerId = playerId;
                    lobby.TryRemoveMember(playerId);
                    lobby.TryRemoveSpectator(playerId);
                    foreach (var player in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault()
                                .SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                        }

                    foreach (var player in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault()
                                .SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                        }

                    ServerState.Lobbies[lobby.Id] = lobby;
                    _session.SendResponse(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                         Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });

        }
         protected void GetLobbyOwner(string lobbyId, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                if (ServerState.Lobbies.TryGetValue(lobbyId, out var lobby))
                {
                    var owner = lobby.LobbyOwner;
                    var protoOwner = FriendHelper.GetPlayer(owner.GetPlayerDocument());
                    _session.SendResponse(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        { Id = guid, Return = new RpcValueWriter(typeof(Axlebolt.Bolt.Protobuf2.Player)).ToBytes(protoOwner) }
                   });
                }
            }
        }
        protected void SetLobbyJoinable(bool joinable, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
               PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                     lobby.Data = BoltLobby.NormalizeLobbyData(lobby.Data);
                    lobby.Joinable = joinable;
                    ServerState.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                       {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyJoinableChanged", new object[] { joinable });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                       {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyJoinableChanged", new object[] { joinable });
                        }
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                   Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SendLobbyChatMsg(string message, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    _ = Task.Run(() =>
                    {
                        foreach (BoltFriend player in lobby.LobbyMembers)
                            if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                            {
                                eventSenders[1].SendEvent("onLobbyChatMessage", new object[] { Id, message });
                             }
                        foreach (BoltFriend player in lobby.LobbySpectators)
                            if (ServerState.EventSenders.TryGetValue(player.Id, out var eventSenders))
                            {
                                eventSenders[1].SendEvent("onLobbyChatMessage", new object[] { Id, message });
                            }
                    });
                     _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
        }
        protected void LeaveLobby(string guid)
        {
           if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
           {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                 PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    stat.playInGame.lobbyId = "";
                stat.playInGame.lobbyName = string.Empty;
                    BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                    lobby.TryRemoveMember(Id);
                    lobby.TryRemoveSpectator(Id);
                    if (lobby.LobbyMembers.Length == 0)
                    {
                        ServerState.Lobbies.Remove(lobby.Id);
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                        return;
                    }
                    if (lobby.LobbyOwnerId == Id)
                    {
                        lobby.LobbyOwnerId = lobby.LobbyMembers.First().Id;
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                            {
                                eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                            {
                                eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                            }
                    }
                    ServerState.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onPlayerLeftLobby", new object[] { Id });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onPlayerLeftLobby", new object[] { Id });
                        }
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
               }
           }
             _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                       Code = 401
                    }
                }
            });
        }

        protected void InvitePlayerToLobby(string invitedPlayerId, LobbyPlayerType playerType, string guid)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string inviterId))
            {
                SendLobbyException(guid, 401);
                return;
            }

            try
            {
                var main = BoltMainDatabaseProvider.Instance;
                var inviter = main.GetPlayerDocument(ObjectId.Parse(inviterId));
                var invited = main.GetPlayerDocument(ObjectId.Parse(invitedPlayerId));
                var status = ServerState.GetOrCreatePlayerStatus(inviterId);
                if (string.IsNullOrEmpty(status.playInGame.lobbyId) ||
                    !ServerState.Lobbies.TryGetValue(status.playInGame.lobbyId, out BoltLobby lobby))
                {
                   SendLobbyException(guid, 5005);
                    return;
                }

                if (playerType == LobbyPlayerType.Spectator)
                    lobby.AddLobbySpectatorInvite(invited.GetBoltFriend());
                else
                {
                    playerType = LobbyPlayerType.Member;
                    lobby.AddLobbyMemberInvite(invited.GetBoltFriend());
                }

                ServerState.Lobbies[lobby.Id] = lobby;
                LobbyInvite invite = LobbyInviteRuntimeStore.Save(invitedPlayerId, lobby.Id, inviterId, playerType);

                foreach (BoltFriend target in lobby.LobbyMembers.Concat(lobby.LobbySpectators))
                {
                    if (!ServerState.EventSenders.TryGetValue(target.Id, out List<IEventSender> senders)) continue;
                    var sender = senders.OfType<MatchmakingEventSender>().FirstOrDefault();
                    if (playerType == LobbyPlayerType.Spectator)
                        sender?.SendEvent("onNewSpectatorInvitedToLobby", new object[] { inviterId, invited.GetPlayerFriend(target.Id) });
                    else
                        sender?.SendEvent("onNewPlayerInvitedToLobby", new object[] { inviterId, invited.GetPlayerFriend(target.Id) });
                }

                if (ServerState.EventSenders.TryGetValue(invitedPlayerId, out List<IEventSender> invitedSenders))
                {
                    var sender = invitedSenders.OfType<MatchmakingEventSender>().FirstOrDefault();
                    if (playerType == LobbyPlayerType.Spectator)
                    {
                        sender?.SendEvent("onReceivedSpectatorInviteToLobbyEvent", new object[] { invite });
                    }
                    else
                     {
                        sender?.SendEvent("onReceivedInviteToLobbyEvent", new object[] { invite });
                    }
                }

                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
            }
            catch
            {
                SendLobbyException(guid, 500);
            }
        }

        private void RefuseInvitationToLobby(string lobbyId, string guid)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                SendLobbyException(guid, 401);
                return;
            }

             try
            {
                PlayerDocument player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
                if (ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
                {
                    lobby.RemoveLobbyAnyInvite(player.GetBoltFriend());
                    ServerState.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend target in lobby.LobbyMembers.Concat(lobby.LobbySpectators))
                    {
                        if (!ServerState.EventSenders.TryGetValue(target.Id, out List<IEventSender> senders)) continue;
                       senders.OfType<MatchmakingEventSender>().FirstOrDefault()
                            ?.SendEvent("onRefuseInviteToLobby", new object[] { lobby.LobbyOwnerId, playerId });
                    }
                 }
                LobbyInviteRuntimeStore.Remove(playerId, lobbyId);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
            }
            catch
            {
                SendLobbyException(guid, 500);
            }
         }

         private void GetInvitesToLobby(string guid)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                SendLobbyException(guid, 401);
                return;
            }
            LobbyInvite[] invites = LobbyInviteRuntimeStore.GetForPlayer(playerId);
            _session.SendResponse(new ResponseMessage
             {
                RpcResponse = new RpcResponse { Id = guid, Return = new RpcValueWriter(typeof(LobbyInvite[])).ToBytes(invites) }
            });
        }

        private void SendLobbyException(string guid, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                     Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                         Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        protected void JoinLobby(string lobbyId, object rawPlayerTypeParam, string guid)
        {
           if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);

                if (ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
                {
                    if (lobby.Joinable)
                    {
                        if ((lobby.LobbyMembers.Length + 1) == lobby.MaxMembers)
                        {
                            _session.SendResponse(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                    {
                                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                        Code = 5006
                                    }
                                }
                            });
                            return;
                        }

                        if (lobby.Type == BoltLobby.LobbyType.Public ||
                            (lobby.Type == BoltLobby.LobbyType.FriendsOnly && playerDocument.IsContainsFriend(lobby.LobbyOwnerId)) ||
                            (lobby.Type == BoltLobby.LobbyType.Private && lobby.IsMemberInvited(Id)))
                        {
                            lobby.RemoveLobbyAnyInvite(playerDocument.GetBoltFriend());
                            LobbyInviteRuntimeStore.Remove(Id, lobby.Id);

                            lobby.AddLobbyMember(playerDocument.GetBoltFriend());

                            foreach (BoltFriend playerId in lobby.LobbyMembers)
                            {
                                if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                 {
                                    eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                                        ?.SendEvent("onNewPlayerJoinedLobby", new object[] { playerDocument.GetPlayerFriend(playerId.Id) });
                                }
                            }
                            foreach (BoltFriend playerId in lobby.LobbySpectators)
                            {
                               if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                {
                                    eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault()
                                        ?.SendEvent("onNewPlayerJoinedLobby", new object[] { playerDocument.GetPlayerFriend(playerId.Id) });
                               }
                            }

                            ServerState.Lobbies[lobby.Id] = lobby;
                            stat.playInGame.lobbyId = lobby.Id;
                stat.playInGame.lobbyName = lobby.Name;

                            BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);

                            _session.SendResponse(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Return = new RpcValueWriter(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id))
                                }
                            });
                            return;
                        }
                    }

                    _session.SendResponse(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                 Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 5005
                            }
                       }
                    });
                    return;
                }
            }

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                 {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                   {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 5001
                    }
                }
             });
        }

        protected void RevokePlayerInvitationToLobby(string revokedPlayerId, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
             {
               BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
               PlayerDocument playerInvited = boltMain.GetPlayerDocument(ObjectId.Parse(revokedPlayerId));
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    _ = Task.Run(() =>
                    {

                        lobby.RemoveLobbyAnyInvite(playerInvited.GetBoltFriend());
                        LobbyInviteRuntimeStore.Remove(revokedPlayerId, lobby.Id);
                       foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onRevokeInviteToLobby", new object[] { Id, revokedPlayerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onRevokeInviteToLobby", new object[] { Id, revokedPlayerId });
                            }
                        ServerState.Lobbies[lobby.Id] = lobby;
                    });
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
               RpcResponse = new RpcResponse
                {
                     Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
             });
        }

        protected void SetLobbyPhotonGame(Axlebolt.Bolt.Protobuf2.PhotonGame photonGame, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
            {
               BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    _ = Task.Run(() =>
                   {
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyPhotonGameChanged", new object[] { photonGame });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                           if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onLobbyPhotonGameChanged", new object[] { photonGame });
                            }
                        var presenceGame = new RpcServer.PhotonGame
                        {
                            region = photonGame.Region,
                            appVersion = photonGame.AppVersion,
                           roomId = photonGame.RoomId,
                            customProperties = photonGame.CustomProperties.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal)
                        };
                        ServerState.Lobbies[lobby.Id].PhotonGame = presenceGame;

                        foreach (BoltFriend member in lobby.LobbyMembers.Concat(lobby.LobbySpectators))
                        {
                            try
                            {
                                ServerState.SetPlayerPhotonPresence(member.Id, photonGame.RoomId, photonGame.Region, photonGame.AppVersion, presenceGame.customProperties);
                                BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(member.Id), ServerState.GetOrCreatePlayerStatus(member.Id));
                            }
                            catch
                            {
                            }
                         }
                    });
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
               }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                         Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                         Code = 401
                    }
                }
            });
        }

       protected void KickPlayerFromLobby(string kickedPlayerId, string guid)
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string Id))
           {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument kickedPlayer = boltMain.GetPlayerDocument(ObjectId.Parse(kickedPlayerId));
                PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(Id);
                if (stat.playInGame.lobbyId != "" && ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    _ = Task.Run(() =>
                    {
                         lobby.RemoveLobbyAny(kickedPlayer.GetBoltFriend());
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onPlayerKickedFromLobby", new object[] { Id, kickedPlayerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (ServerState.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.OfType<MatchmakingEventSender>().FirstOrDefault().SendEvent("onPlayerKickedFromLobby", new object[] { Id, kickedPlayerId });
                            }
                        ServerState.Lobbies[lobby.Id] = lobby;
                    });
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                     {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                   }
                }
           });
        }
        protected void JoinLobby(string lobbyId, string guid)
        {
            JoinLobby(lobbyId, Axlebolt.Bolt.Protobuf2.LobbyType.Public, guid);
        }

        protected void JoinLobbyAs(string lobbyId, object rawPlayerTypeParam, string guid)
       {
            JoinLobby(lobbyId, guid);
        }

        private sealed class RankedStartData
        {
            public string GameMode = string.Empty;
             public readonly List<string> Regions = new List<string>();
             public readonly List<string> FiltersOrLevels = new List<string>();
             public string GroupId = string.Empty;
            public int GroupSize = 1;
        }

        private sealed class RankedSearchStatus
        {
             public int TotalSearchingPlayers { get; set; }
            public List<RankedSearchModeStatus> Modes { get; set; } = new List<RankedSearchModeStatus>();
            public DateTimeOffset UpdatedAtUtc { get; set; }
        }

        private sealed class RankedSearchModeStatus
       {
            public string Mode { get; set; } = string.Empty;
            public int SearchingPlayers { get; set; }
            public int AnyMapPlayers { get; set; }
            public Dictionary<string, int> Maps { get; set; } = new Dictionary<string, int>(StringComparer.Ordinal);
       }

        private static void SaveRankedSearchStatusLocked()
        {
            try
            {

                RankedParticipant[] live = RankedWaiting
                    .Where(x => x != null && x.Match == null && IsParticipantConnected(x))
                    .GroupBy(x => x.PlayerId ?? string.Empty, StringComparer.Ordinal)
                    .Where(g => !string.IsNullOrWhiteSpace(g.Key))
                    .Select(g => g.OrderByDescending(x => x.Generation).First())
                    .ToArray();

                var snapshot = new RankedSearchStatus
                {
                   TotalSearchingPlayers = live.Length,
                    UpdatedAtUtc = DateTimeOffset.UtcNow
                 };

                foreach (IGrouping<string, RankedParticipant> modeGroup in live
                    .GroupBy(
                        x => x.Mode?.WireName ?? "Unknown",
                        StringComparer.OrdinalIgnoreCase)
                    .OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase))
                {
                    var modeStatus = new RankedSearchModeStatus
                    {
                        Mode = modeGroup.Key,
                        SearchingPlayers = modeGroup.Count()
                    };

                    foreach (RankedParticipant participant in modeGroup)
                    {
                        string[] levels = participant.RequestedLevels ?? Array.Empty<string>();
                        string[] requested = levels
                             .Where(x => !string.IsNullOrWhiteSpace(x))
                            .Select(x => x.Trim())
                            .Distinct(StringComparer.OrdinalIgnoreCase)
                            .ToArray();

                        if (requested.Length == 0)
                        {
                            modeStatus.AnyMapPlayers++;
                            continue;
                        }

                        foreach (string level in requested)
                         {
                            string existingKey = modeStatus.Maps.Keys
                                .FirstOrDefault(x => string.Equals(x, level, StringComparison.OrdinalIgnoreCase));
                            string key = existingKey ?? level;
                           modeStatus.Maps.TryGetValue(key, out int count);
                            modeStatus.Maps[key] = count + 1;
                        }
                    }

                    snapshot.Modes.Add(modeStatus);
                }

                string configured = (Environment.GetEnvironmentVariable("STANDLINE_TCP_RANKED_STATUS_FILE") ?? string.Empty).Trim();
                string statusPath = configured;
                if (string.IsNullOrWhiteSpace(statusPath))
                    statusPath = Path.Combine(Directory.GetCurrentDirectory(), "runtime", "ranked_search_status.json");
                else if (!Path.IsPathRooted(statusPath))
                    statusPath = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), statusPath));

                string directory = Path.GetDirectoryName(statusPath);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);

                string json = System.Text.Json.JsonSerializer.Serialize(
                    snapshot,
                   new System.Text.Json.JsonSerializerOptions
                    {
                         WriteIndented = true
                    });

                string tempPath = statusPath + ".tmp";
                File.WriteAllText(tempPath, json, new UTF8Encoding(false));
                File.Move(tempPath, statusPath, true);
            }
            catch
           {

            }
        }

       private sealed class RankedParticipant
        {
            public MatchmakingRemoteService Service;
            public string PlayerId = string.Empty;
            public string PlayerName = "Player";
            public string Profile = string.Empty;
           public string FilterCondition = string.Empty;
            public string GroupId = string.Empty;
            public int GroupSize = 1;
            public string Region = string.Empty;
            public string[] RequestedLevels = Array.Empty<string>();
            public int TeamIndex;
            public int Mmr = 500;
            public RankedModeContract Mode;
            public string QueueKey = string.Empty;
            public DateTime QueuedUtc = DateTime.UtcNow;
            public DateTime OriginalQueuedUtc = DateTime.UtcNow;
            public long Generation;
            public bool Confirmed;
            public bool ConfirmationTimedOut;
            public bool SyntheticLobbyMember;
            public RankedMatch Match;
        }

        private sealed class RankedMatch
        {
            public string RoomId = string.Empty;
            public string Profile = string.Empty;
             public string FilterCondition = string.Empty;
            public string Region = string.Empty;
            public string SelectedLevelId = string.Empty;
            public RankedModeContract Mode;
            public string QueueKey = string.Empty;
            public int RequiredPlayers;
           public string ConfirmationId = Guid.NewGuid().ToString("N");
            public string RosterHash = string.Empty;
            public DateTime CreatedUtc = DateTime.UtcNow;
            public DateTime ConfirmationDeadlineUtc = DateTime.UtcNow.AddSeconds(RankedStatGuard.ConfirmationSeconds);
            public DateTime? ReadyUtc;
             public DateTime? ReadyExpiresUtc;
             public bool Ready;
            public bool DoneSent;
            public bool Completed;
            public readonly List<RankedParticipant> Players = new List<RankedParticipant>();
        }

        private static RankedStartData ParseRankedStart(BinaryValue value)
        {
             var result = new RankedStartData();
            if (value == null || value.IsNull || value.One == null || value.One.Length == 0)
                return result;

            try
            {
                 var input = new CodedInputStream(value.One.ToByteArray());
                uint tag;
               while ((tag = input.ReadTag()) != 0)
                {
                    switch (tag)
                     {
                        case 10:
                            result.GameMode = input.ReadString();
                            break;

                         case 18:
                            result.Regions.Add(input.ReadString());
                            break;

                         case 26:
                        {
                            byte[] filterBytes = input.ReadBytes().ToByteArray();
                            var filterInput = new CodedInputStream(filterBytes);
                           uint filterTag;
                            while ((filterTag = filterInput.ReadTag()) != 0)
                            {
                                if (filterTag == 10)
                                    result.FiltersOrLevels.Add(filterInput.ReadString());
                                else
                                    filterInput.SkipLastField();
                            }
                            break;
                        }

                        case 34:
                            result.GroupId = input.ReadString();
                            break;

                        case 40:
                           result.GroupSize = input.ReadInt32();
                            break;

                        default:
                            input.SkipLastField();
                            break;
                    }
                }
            }
            catch
            {
            }

            result.Regions.RemoveAll(string.IsNullOrWhiteSpace);
            result.FiltersOrLevels.RemoveAll(string.IsNullOrWhiteSpace);
             return result;
        }

        public static bool LooksLikeDedicatedRankedStart(BinaryValue value, out string gameMode)
        {
            gameMode = string.Empty;
            RankedStartData parsed = ParseRankedStart(value);
           string mode = (parsed.GameMode ?? string.Empty).Trim();
            if (mode.Equals("RankedDefuse", StringComparison.OrdinalIgnoreCase) ||
                mode.Equals("Ranked2v2", StringComparison.OrdinalIgnoreCase) ||
                mode.Equals("RankedDuel", StringComparison.OrdinalIgnoreCase))
            {
                gameMode = mode;
                return true;
             }
            return false;
        }

        public bool TryResolveDedicatedZeroParam(out string method)
         {
            method = string.Empty;
            RankedParticipant participant = _rankedParticipant;
            if (participant == null)
                return false;

            lock (RankedSync)
            {
                if (participant.Match != null && !participant.Match.Completed)
                {
                    if (!participant.Confirmed)
                     {
                        method = "confirm";
                        return true;
                    }
                    return false;
                }

                if (_rankedActive || RankedWaiting.Contains(participant))
                {
                    method = "cancel";
                    return true;
                }
           }

           return false;
        }

        private static string NormalizeClientRegion(string value)
        {
            string region = string.IsNullOrWhiteSpace(value) ? "Europe" : value.Trim();
            if (region.Equals("Europe", StringComparison.OrdinalIgnoreCase) ||
                region.Equals("EU", StringComparison.OrdinalIgnoreCase) ||
                region.Equals("EUR", StringComparison.OrdinalIgnoreCase))
                return "Europe";
            return region;
        }

         private static string PickClientRegion(IEnumerable<string> regions)
         {
            string raw = regions?.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));
            return NormalizeClientRegion(raw);
        }

        private static string GetRegionKey(string clientRegion)
        {
           string value = string.IsNullOrWhiteSpace(clientRegion) ? "Europe" : clientRegion.Trim();
            if (value.Equals("Europe", StringComparison.OrdinalIgnoreCase) ||
                value.Equals("EU", StringComparison.OrdinalIgnoreCase) ||
                value.Equals("EUR", StringComparison.OrdinalIgnoreCase))
                return "eur";
            return value.ToLowerInvariant();
        }

        private static string[] NormalizeLevels(IEnumerable<string> values)
       {
            return (values ?? Enumerable.Empty<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
               .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private static string BuildLevelKey(IEnumerable<string> levels)
        {
            string[] normalized = NormalizeLevels(levels)
               .Select(x => x.ToLowerInvariant())
                .OrderBy(x => x, StringComparer.Ordinal)
                .ToArray();
            return normalized.Length == 0 ? "any" : string.Join(",", normalized);
        }

         private static string PickLevel(IEnumerable<RankedParticipant> source, string queueKey)
        {
            RankedParticipant[] participants = (source ?? Enumerable.Empty<RankedParticipant>())
                 .Where(x => x != null)
                .ToArray();
            if (participants.Length == 0)
                return string.Empty;

            string[] first = NormalizeLevels(participants[0].RequestedLevels);
            string[] candidates;
             if (first.Length == 0)
            {

                candidates = participants
                    .SelectMany(x => NormalizeLevels(x.RequestedLevels))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();
            }
            else
            {

                candidates = first
                    .Where(candidate => participants.All(p =>
                    {
                        string[] requested = NormalizeLevels(p.RequestedLevels);
                        return requested.Length == 0 || requested.Contains(candidate, StringComparer.OrdinalIgnoreCase);
                    }))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();
            }

            if (candidates.Length == 0)
                return string.Empty;
            string[] drawPool = candidates;
            if (candidates.Length > 1 &&
                !string.IsNullOrWhiteSpace(queueKey) &&
                RankedLastLevelByQueue.TryGetValue(queueKey, out string? previous))
           {
                string[] withoutPrevious = candidates
                    .Where(x => !string.Equals(x, previous, StringComparison.OrdinalIgnoreCase))
                   .ToArray();
                if (withoutPrevious.Length > 0)
                    drawPool = withoutPrevious;
           }

            string selected = drawPool.Length == 1
                ? drawPool[0]
                : drawPool[Random.Shared.Next(drawPool.Length)];
            if (!string.IsNullOrWhiteSpace(queueKey))
                RankedLastLevelByQueue[queueKey] = selected;
           return selected;
       }

        private static int GetReadyRetentionSeconds()
        {
            int configured;
            string raw = Environment.GetEnvironmentVariable("BOLT_RANKED_READY_RETENTION_SECONDS");
            if (int.TryParse(raw, out configured) && configured > 0)
                return Math.Max(30, Math.Min(configured, 600));
            return DefaultRankedReadyRetentionSeconds;
        }

        private static byte[] BuildProto(Action<CodedOutputStream> writer)
         {
            using (var stream = new MemoryStream())
            {
                using (var output = new CodedOutputStream(stream, true))
                {
                     writer(output);
                    output.Flush();
                }
                return stream.ToArray();
            }
         }

        private static void WriteMessage(CodedOutputStream output, int fieldNumber, byte[] value)
        {
            if (value == null) return;
            output.WriteTag(fieldNumber, WireFormat.WireType.LengthDelimited);
            output.WriteBytes(ByteString.CopyFrom(value));
        }

        private static void WriteString(CodedOutputStream output, int fieldNumber, string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            output.WriteTag(fieldNumber, WireFormat.WireType.LengthDelimited);
            output.WriteString(value);
        }

        private static void WriteBool(CodedOutputStream output, int fieldNumber, bool value)
        {
            if (!value) return;
            output.WriteTag(fieldNumber, WireFormat.WireType.Varint);
            output.WriteBool(value);
        }

        private static byte[] BuildRankedPlayer(RankedParticipant participant)
        {
            return BuildProto(output =>
            {
                WriteString(output, 1, participant.PlayerId);
                WriteString(output, 2, string.IsNullOrEmpty(participant.PlayerName) ? "Player" : participant.PlayerName);
                 WriteBool(output, 3, true);
                WriteBool(output, 4, participant.Confirmed);
            });
        }

        private static byte[] BuildRankedGroup(IEnumerable<RankedParticipant> participants)
        {
            return BuildProto(output =>
            {
                 foreach (RankedParticipant participant in participants)
                    WriteMessage(output, 1, BuildRankedPlayer(participant));
             });
         }

        private static byte[] BuildRankedTeam(IEnumerable<RankedParticipant> participants)
        {
            byte[] group = BuildRankedGroup(participants);
           return BuildProto(output => WriteMessage(output, 1, group));
        }

        private static byte[] BuildRankedMatchGroup(IEnumerable<RankedParticipant> source, string selectedLevelId, string region)
        {
            RankedParticipant[] participants = source == null
                ? new RankedParticipant[0]
                : source.Where(x => x != null).ToArray();

            RankedParticipant[] team0 = participants.Where(x => x.TeamIndex == 0).ToArray();
             RankedParticipant[] team1 = participants.Where(x => x.TeamIndex == 1).ToArray();

            return BuildProto(output =>
            {
                WriteMessage(output, 1, BuildRankedTeam(team0));
                WriteMessage(output, 1, BuildRankedTeam(team1));
                WriteString(output, 2, selectedLevelId);
                WriteString(output, 3, region);
            });
        }

        private void SendRankedEvent(string eventName, byte[] payload)
        {
            EventResponse envelope = BoltEventContract.CreateRaw(
                RankedListenerName, eventName, payload ?? Array.Empty<byte>());
            _session.SendResponse(new ResponseMessage { EventResponse = envelope });
        }

        private void SendMatchmakingBanned(string requestId, long bannedUntilUnixSeconds)
        {
            var rpcException = new Axlebolt.RpcSupport.Protobuf.Exception
            {
                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                Code = 3004
             };
            long nowUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            rpcException.Property.Add("until", bannedUntilUnixSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture));
            rpcException.Property.Add("duration", Math.Max(0, bannedUntilUnixSeconds - nowUnix).ToString(System.Globalization.CultureInfo.InvariantCulture));
            rpcException.Property.Add("reason", "ranked-abandon");

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId,
                    Exception = rpcException
                }
            });
        }

        private void SendMatchmakingAlreadyStarted(string requestId, string matchId, string lifecycle)
        {
            var rpcException = new Axlebolt.RpcSupport.Protobuf.Exception
            {
                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                Code = 3002
            };
            if (!string.IsNullOrWhiteSpace(matchId))
                rpcException.Property.Add("matchId", matchId);
            if (!string.IsNullOrWhiteSpace(lifecycle))
                rpcException.Property.Add("lifecycle", lifecycle);

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId,
                    Exception = rpcException
                }
            });
        }

        private void SendRankedFail(RankedParticipant recipient, int cause, string message)
        {
            RankedParticipant[] players = recipient != null && recipient.Match != null
                ? recipient.Match.Players.ToArray()
                : new[] { recipient };
            string filter = recipient?.Match?.FilterCondition ?? recipient?.FilterCondition ?? string.Empty;
            byte[] group = BuildRankedGroup(players.Where(x => x != null));
            byte[] payload = BuildProto(output =>
           {
                output.WriteTag(1, WireFormat.WireType.Varint);
                output.WriteEnum(cause);
                WriteString(output, 2, message ?? string.Empty);
                WriteMessage(output, 3, group);
            });
            recipient?.Service?.SendRankedEvent(RankedFailEvent, payload);
        }

        private void SendRankedProgress(RankedParticipant recipient, int stateCode)
        {
             RankedParticipant[] players;
            string filter;
            string region;
            string selectedLevelId;
            if (recipient.Match != null)
           {
               lock (RankedSync)
                {
                    players = recipient.Match.Players.ToArray();
                    filter = recipient.Match.FilterCondition;
                    region = recipient.Match.Region;
                    selectedLevelId = recipient.Match.SelectedLevelId;
                }
            }
            else
            {
                players = new[] { recipient };
                filter = recipient.FilterCondition;
                region = recipient.Region;
                selectedLevelId = recipient.RequestedLevels != null && recipient.RequestedLevels.Length > 0
                    ? recipient.RequestedLevels[0]
                    : string.Empty;
            }

            byte[] matchGroup = BuildRankedMatchGroup(players, selectedLevelId, region);
            byte[] progress = BuildProto(output =>
            {
                output.WriteTag(1, WireFormat.WireType.Varint);
                output.WriteInt32(stateCode);
                WriteMessage(output, 2, matchGroup);
            });

            recipient.Service._rankedStateCode = stateCode;
            recipient.Service.SendRankedEvent(RankedProgressEvent, progress);
        }

        private static void SendPlayersConfirmed(RankedMatch match)
        {
            RankedParticipant[] players;
            RankedParticipant[] confirmedPlayers;
            lock (RankedSync)
            {
                players = match.Players.ToArray();
                confirmedPlayers = players.Where(x => x != null && x.Confirmed).ToArray();
            }

            byte[] matchGroup = BuildRankedMatchGroup(players, match.SelectedLevelId, match.Region);
            byte[] payload = BuildProto(output =>
            {
                WriteMessage(output, 1, matchGroup);
                foreach (RankedParticipant confirmed in confirmedPlayers)
                    WriteMessage(output, 2, BuildRankedPlayer(confirmed));
            });

            foreach (RankedParticipant participant in players)
            {
                if (participant?.Service != null && IsParticipantConnected(participant))
                   participant.Service.SendRankedEvent(RankedPlayersConfirmedEvent, payload);
            }
        }

        private static byte[] BuildRankedDonePayload(RankedMatch match, RankedParticipant[] players)
        {
            byte[] matchGroup = BuildRankedMatchGroup(players, match.SelectedLevelId, match.Region);
            return BuildProto(output =>
             {
                WriteString(output, 1, match.SelectedLevelId);
                WriteMessage(output, 2, matchGroup);
            });
        }

        private static void SendRankedDoneToParticipant(
            RankedMatch match,
            RankedParticipant participant,
            RankedParticipant[] players = null,
             byte[] payload = null)
        {
            if (match == null || participant == null)
                return;

            players = players ?? match.Players.ToArray();
            payload = payload ?? BuildRankedDonePayload(match, players);

            try
            {
                ServerState.SetPlayerPhotonPresence(
                    participant.PlayerId,
                    match.RoomId,
                    "eur",
                    "0.33.0",
                    new Dictionary<string, string>
                   {
                         ["mode"] = match.Mode == null ? string.Empty : match.Mode.WireName,
                        ["profile"] = match.Profile ?? string.Empty
                    });
                 BoltMainDatabaseProvider.Instance.SetPlayerStatus(
                    ObjectId.Parse(participant.PlayerId),
                    ServerState.GetOrCreatePlayerStatus(participant.PlayerId));
            }
            catch
            {
            }

            StorageRemoteService.ArmRankedRejoin(participant.PlayerId, "ready-handoff-all-participants");

            if (participant.Service == null || !IsParticipantConnected(participant))
            {
                return;
             }

            participant.Service._rankedParticipant = participant;
            participant.Service._rankedRoomId = match.RoomId;
           participant.Service._rankedActive = false;
           participant.Service.SendRankedEvent(RankedDoneEvent, payload);
        }

        private static void SendRankedDone(RankedMatch match)
        {
            RankedParticipant[] players;
            lock (RankedSync)
                players = match.Players.ToArray();

            byte[] payload = BuildRankedDonePayload(match, players);
            foreach (RankedParticipant participant in players)
                SendRankedDoneToParticipant(match, participant, players, payload);
         }

        private static bool IsParticipantConnected(RankedParticipant participant)
        {
            try
            {
                return participant != null &&
                    participant.Service != null &&
                    participant.Service._session != null &&
                    participant.Service._session.TcpClient != null &&
                    participant.Service._session.TcpClient.Client != null &&
                    participant.Service._session.TcpClient.Client.Connected;
            }
            catch
            {
                return false;
           }
        }

        private static List<RankedParticipant> RemoveParticipantLocked(RankedParticipant participant, bool requeueMatchPlayers)
        {
            var requeued = new List<RankedParticipant>();
            if (participant == null) return requeued;

            RankedWaiting.Remove(participant);
            if (!string.IsNullOrEmpty(participant.PlayerId))
                 RankedByPlayer.Remove(participant.PlayerId);

             RankedMatch match = participant.Match;
            participant.Match = null;
            participant.Confirmed = false;
            participant.Service._rankedActive = false;
            participant.Service._rankedParticipant = null;

            if (match != null && !match.Completed)
            {
                if (match.Ready)
                {
                     participant.Match = match;
                    return requeued;
                 }

                match.Players.Remove(participant);
                if (requeueMatchPlayers)
                {
                    foreach (RankedParticipant other in match.Players.ToArray())
                    {
                       other.Match = null;
                        other.Confirmed = false;
                        other.TeamIndex = 0;
                        other.Service._rankedRoomId = null;
                        if (IsParticipantConnected(other) && !RankedWaiting.Contains(other))
                        {
                            other.QueuedUtc = other.OriginalQueuedUtc;
                            RankedWaiting.Add(other);
                            RankedByPlayer[other.PlayerId] = other;
                            requeued.Add(other);
                        }
                    }
                }
                match.Players.Clear();
                match.Completed = true;
            }

            return requeued;
        }

        private static void ClearMatchHandoffLocked(RankedMatch match)
        {
            if (match == null)
                return;

            foreach (RankedParticipant participant in match.Players.ToArray())
            {
                if (participant == null)
                    continue;

                RankedWaiting.Remove(participant);
                if (!string.IsNullOrEmpty(participant.PlayerId) &&
                    RankedByPlayer.TryGetValue(participant.PlayerId, out RankedParticipant current) &&
                    ReferenceEquals(current.Match, match))
                {
                    RankedByPlayer.Remove(participant.PlayerId);
                }

                participant.Match = null;
                participant.Confirmed = false;
                if (participant.Service != null &&
                    ReferenceEquals(participant.Service._rankedParticipant, participant))
                {
                    participant.Service._rankedRoomId = null;
                    participant.Service._rankedParticipant = null;
                    participant.Service._rankedActive = false;
                }
            }

            match.Players.Clear();
            match.Completed = true;
        }

       private static List<RankedParticipant> RemoveWaitingPartyLocked(RankedParticipant participant)
        {
            var removed = new List<RankedParticipant>();
            if (participant == null || participant.Match != null)
                return removed;
            string partyKey = PartyKey(participant);
            RankedParticipant[] members = RankedWaiting
                .Where(x => x != null && x.Match == null && string.Equals(PartyKey(x), partyKey, StringComparison.Ordinal))
                .ToArray();
            if (members.Length == 0)
                members = new[] { participant };

             foreach (RankedParticipant member in members)
            {
                RankedWaiting.Remove(member);
                if (!string.IsNullOrWhiteSpace(member.PlayerId) &&
                    RankedByPlayer.TryGetValue(member.PlayerId, out RankedParticipant current) &&
                    ReferenceEquals(current, member))
                    RankedByPlayer.Remove(member.PlayerId);
                member.Confirmed = false;
                if (member.Service != null)
                {
                    member.Service._rankedActive = false;
                    if (ReferenceEquals(member.Service._rankedParticipant, member))
                         member.Service._rankedParticipant = null;
                }
                removed.Add(member);
            }
            return removed;
        }

        private static void PruneDisconnectedLocked()
        {
            foreach (RankedParticipant participant in RankedWaiting.ToArray())
             {
                if (!IsParticipantConnected(participant) && RankedWaiting.Contains(participant))
                    RemoveWaitingPartyLocked(participant);
            }
        }

        private static List<RankedParticipant> PruneExpiredMatchesLocked()
        {
            var requeued = new List<RankedParticipant>();
             DateTime now = DateTime.UtcNow;
            RankedMatch[] expired = RankedByPlayer.Values
                .Where(x => x != null && x.Match != null && !x.Match.Completed &&
                    ((!x.Match.Ready && x.Match.ConfirmationDeadlineUtc <= now) ||
                     (x.Match.Ready && x.Match.ReadyExpiresUtc.HasValue && x.Match.ReadyExpiresUtc.Value <= now)))
                 .Select(x => x.Match)
                .Distinct()
                .ToArray();

            foreach (RankedMatch match in expired)
            {
               bool wasReady = match.Ready;
                if (wasReady)
                {
                    string lifecycle = "Unknown";
                    bool finalized = false;
                    try
                    {
                        lifecycle = RankedAuthorityRepository.Instance.GetMatchLifecycleStatus(match.RoomId, out finalized);
                    }
                    catch
                    {
                        match.ReadyExpiresUtc = now.AddSeconds(GetReadyRetentionSeconds());
                       continue;
                    }

                    bool photonOwnsLifecycle =
                        !finalized &&
                        (string.Equals(lifecycle, "Running", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(lifecycle, "Disconnected", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(lifecycle, "Finalizing", StringComparison.OrdinalIgnoreCase));
                    if (photonOwnsLifecycle)
                    {
                        match.ReadyExpiresUtc = now.AddSeconds(GetReadyRetentionSeconds());
                        continue;
                    }

                    if (!finalized && string.Equals(lifecycle, "Ready", StringComparison.OrdinalIgnoreCase))
                    {
                        match.ReadyExpiresUtc = now.AddSeconds(GetReadyRetentionSeconds());
                        continue;
                    }
                    ClearMatchHandoffLocked(match);
                    continue;
                }

                string culpritPlayerId = match.Players.FirstOrDefault(x => !x.Confirmed)?.PlayerId;
                bool cancelled;
                try
                {
                    cancelled = RankedAuthorityRepository.Instance.TryCancelPreRunningMatch(
                        match.RoomId, "confirmation-timeout", culpritPlayerId);
                }
                catch
                {
                    match.ConfirmationDeadlineUtc = now.AddSeconds(2);
                    continue;
                }
                if (!cancelled)
                {
                    match.ConfirmationDeadlineUtc = now.AddSeconds(2);
                    continue;
                }

                foreach (RankedParticipant participant in match.Players.ToArray())
                {
                    bool culprit = !participant.Confirmed;
                    participant.ConfirmationTimedOut = culprit;
                    participant.Match = null;
                    participant.Confirmed = false;
                    participant.TeamIndex = 0;
                    if (participant.Service != null)
                   {
                        participant.Service._rankedRoomId = null;
                        participant.Service._rankedParticipant = null;
                        participant.Service._rankedActive = false;
                    }
                    RankedByPlayer.Remove(participant.PlayerId);
                    if (IsParticipantConnected(participant))
                    {
                        if (!culprit && !RankedWaiting.Contains(participant))
                        {
                            participant.QueuedUtc = participant.OriginalQueuedUtc;
                            RankedWaiting.Add(participant);
                            RankedByPlayer[participant.PlayerId] = participant;
                        }
                        requeued.Add(participant);
                    }
                }

                 match.Players.Clear();
                match.Completed = true;
            }
            return requeued;
        }

        private static string PartyKey(RankedParticipant participant) =>
             string.IsNullOrEmpty(participant?.GroupId) ? "solo:" + participant?.PlayerId : "party:" + participant.GroupId;

        private static RankedParticipant[] SelectRankedCandidates(
            RankedParticipant[] pool,
            RankedModeContract mode,
            int required,
           DateTime now)
        {
            if (pool == null || pool.Length < required || mode == null)
                return Array.Empty<RankedParticipant>();

           int teamCapacity = Math.Max(1, required / 2);
            RankedMatchmakingSettings settings = RankedSettings.For(mode);
            var groups = pool
                .GroupBy(PartyKey)
                .Select(g =>
                {
                    RankedParticipant[] members = g.OrderBy(x => x.OriginalQueuedUtc).ThenBy(x => x.PlayerId, StringComparer.Ordinal).ToArray();
                    int declared = members[0].GroupId.Length == 0 ? 1 : Math.Max(1, members.Max(x => x.GroupSize));
                    if (declared > teamCapacity || members.Length > declared ||
                        members.Any(x => Math.Max(1, x.GroupSize) != declared))
                        return null;
                    if (members.Length != declared) return Array.Empty<RankedParticipant>();
                    return members;
                 })
                .Where(g => g != null && g.Length > 0)
                .OrderBy(g => g.Min(x => x.OriginalQueuedUtc))
                .ThenBy(g => g[0].PlayerId, StringComparer.Ordinal)
                 .ToArray();

            for (int seedIndex = 0; seedIndex < groups.Length; seedIndex++)
            {
                RankedParticipant[] seedGroup = groups[seedIndex];
                int seedMin = seedGroup.Min(x => x.Mmr);
                int seedMax = seedGroup.Max(x => x.Mmr);
                if (seedMax - seedMin > settings.LobbyMaxMmrDifference)
                   continue;
                double seedMmr = seedGroup.Average(x => x.Mmr);
                var compatible = new List<RankedParticipant[]> { seedGroup };
                for (int i = 0; i < groups.Length; i++)
                {
                    if (i == seedIndex) continue;
                    RankedParticipant[] group = groups[i];
                    int internalMin = group.Min(x => x.Mmr);
                    int internalMax = group.Max(x => x.Mmr);
                    if (internalMax - internalMin > settings.LobbyMaxMmrDifference)
                        continue;
                    int range = Math.Max(
                        seedGroup.Max(x => RankedStatGuard.GetSearchRange(mode, x.QueuedUtc, now)),
                        group.Max(x => RankedStatGuard.GetSearchRange(mode, x.QueuedUtc, now)));
                    if (group.All(x => Math.Abs(x.Mmr - seedMmr) <= range))
                        compatible.Add(group);
                }

                var chosen = new List<RankedParticipant[]> { seedGroup };
                bool Search(int index, int remaining)
                {
                    if (remaining == 0) return true;
                    if (remaining < 0 || index >= compatible.Count) return false;
                    for (int i = index; i < compatible.Count; i++)
                    {
                        RankedParticipant[] group = compatible[i];
                       if (group.Length > remaining) continue;
                        chosen.Add(group);
                        if (Search(i + 1, remaining - group.Length)) return true;
                        chosen.RemoveAt(chosen.Count - 1);
                    }
                    return false;
                }

                if (Search(1, required - seedGroup.Length))
                    return chosen.SelectMany(x => x).OrderBy(x => x.OriginalQueuedUtc).ToArray();
            }

           return Array.Empty<RankedParticipant>();
         }

        private static bool AssignBalancedTeams(RankedMatch match, RankedParticipant[] candidates)
        {
            if (match == null || candidates == null || candidates.Length != match.RequiredPlayers)
                return false;
            int teamCapacity = Math.Max(1, match.RequiredPlayers / 2);
            RankedParticipant[][] groups = candidates
                .GroupBy(PartyKey)
                .Select(g => g.ToArray())
                .OrderByDescending(g => g.Length)
                 .ThenByDescending(g => g.Sum(x => x.Mmr))
                .ToArray();

            int[] assignment = new int[groups.Length];
            int[] best = null;
            long bestDiff = long.MaxValue;
            void Search(int index, int count0, int count1, long mmr0, long mmr1)
             {
                if (index == groups.Length)
                {
                    if (count0 != teamCapacity || count1 != teamCapacity) return;
                    long diff = Math.Abs(mmr0 - mmr1);
                    if (diff < bestDiff)
                    {
                        bestDiff = diff;
                        best = (int[])assignment.Clone();
                    }
                    return;
                }

                RankedParticipant[] group = groups[index];
                long groupMmr = group.Sum(x => (long)x.Mmr);
                if (count0 + group.Length <= teamCapacity)
                {
                    assignment[index] = 0;
                    Search(index + 1, count0 + group.Length, count1, mmr0 + groupMmr, mmr1);
                }
                if (count1 + group.Length <= teamCapacity)
                {
                    assignment[index] = 1;
                    Search(index + 1, count0, count1 + group.Length, mmr0, mmr1 + groupMmr);
                }
            }
            Search(0, 0, 0, 0, 0);
            if (best == null)
                return false;

            int[] teamCount = { 0, 0 };
            long[] teamMmr = { 0, 0 };
            for (int i = 0; i < groups.Length; i++)
           {
                int team = best[i];
                foreach (RankedParticipant participant in groups[i])
               {
                     participant.TeamIndex = team;
                    teamCount[team]++;
                    teamMmr[team] += participant.Mmr;
                }
           }

            return true;
        }

        private static void TickRankedMatchmaker()
        {
            try
            {
               List<RankedParticipant> timedOut;
                var matches = new List<RankedMatch>();
               lock (RankedSync)
                {
                    timedOut = PruneExpiredMatchesLocked();
                    PruneDisconnectedLocked();
                    SaveRankedSearchStatusLocked();

                    var queues = RankedWaiting
                         .Where(x => IsParticipantConnected(x))
                        .GroupBy(x => x.QueueKey, StringComparer.Ordinal)
                        .Select(x => x.First())
                        .ToArray();
                    foreach (var queue in queues)
                    {
                        RankedMatch match;
                        while ((match = TryCreateRankedMatchLocked(queue.QueueKey, queue.FilterCondition, queue.Profile, queue.Mode)) != null)
                            matches.Add(match);
                    }
                }

                foreach (RankedParticipant expired in timedOut)
                {
                    if (expired?.Service == null || !IsParticipantConnected(expired)) continue;
                    expired.Service.SendRankedFail(expired, 3, "group-member-not-confirmed");
                    expired.Service.SendRankedProgress(expired, RankedStateNotConfirmed);
                    if (!expired.ConfirmationTimedOut)
                        expired.Service.SendRankedProgress(expired, RankedStateMatchmaking);
                }
                foreach (RankedMatch match in matches)
                {
                    foreach (RankedParticipant participant in match.Players.ToArray())
                        participant.Service.SendRankedProgress(participant, RankedStateConfirmation);
                }
            }
            catch
            {
            }
        }

        private static RankedMatch TryCreateRankedMatchLocked(string queueKey, string filterCondition, string profile, RankedModeContract mode)
        {
            PruneDisconnectedLocked();
           if (mode == null) return null;
            int required = RankedModeContracts.GetRequiredPlayers(mode);
            DateTime now = DateTime.UtcNow;
            RankedParticipant[] pool = RankedWaiting
                 .Where(x => IsParticipantConnected(x) &&
                    string.Equals(x.QueueKey, queueKey, StringComparison.Ordinal))
                .OrderBy(x => x.OriginalQueuedUtc)
                .ToArray();

            if (pool.Length < required)
                return null;

            RankedParticipant[] candidates = SelectRankedCandidates(pool, mode, required, now);
            if (candidates.Length != required)
                return null;

            RankedMatchmakingSettings settings = RankedSettings.For(mode);
            string selectedLevel = PickLevel(candidates, queueKey);
            if (string.IsNullOrWhiteSpace(selectedLevel))
           {
                return null;
            }
            string selectedRegion = candidates
                .Select(x => x.Region)
                .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "Europe";

            var match = new RankedMatch
            {
                RoomId = mode.CreateRoomId(),
                Profile = profile,
                FilterCondition = filterCondition,
                Region = selectedRegion,
               SelectedLevelId = selectedLevel,
                Mode = mode,
                QueueKey = queueKey,
                RequiredPlayers = required,
                CreatedUtc = now,
                ConfirmationDeadlineUtc = now.AddSeconds(settings.ConfirmationSeconds)
           };

            if (!AssignBalancedTeams(match, candidates))
             {
                return null;
            }

            RankedReservationPlayer[] reservation = candidates.Select(x => new RankedReservationPlayer
            {
                PlayerId = x.PlayerId,
                PlayerName = x.PlayerName,
               TeamIndex = x.TeamIndex,
                Mmr = x.Mmr,
                Confirmed = false,
                Generation = x.Generation,
                GroupId = x.GroupId,
                GroupSize = x.GroupSize
            }).ToArray();
            match.RosterHash = RankedAuthorityRepository.ComputeRosterHash(reservation);

            bool reserved;
            try
             {
                reserved = RankedAuthorityRepository.Instance.TryReserveConfirmation(
                    match.RoomId, match.RoomId, mode, profile, filterCondition, queueKey,
                    match.Region, match.SelectedLevelId, required, reservation,
                     match.ConfirmationId, match.RosterHash, match.ConfirmationDeadlineUtc);
            }
            catch
            {
                return null;
            }
            if (!reserved)
            {
                return null;
            }

            foreach (RankedParticipant participant in candidates)
             {
                RankedWaiting.Remove(participant);
                participant.Confirmed = false;
               participant.Match = match;
                participant.Service._rankedRoomId = match.RoomId;
                participant.Service._rankedGeneration = participant.Generation;
                match.Players.Add(participant);
            }

            return match;
        }

        private bool TryRecoverInMemoryHandoff(
            string playerId,
            RankedModeContract mode,
            string queueKey,
            out RankedParticipant participant,
            out string lifecycle)
        {
            participant = null;
            lifecycle = string.Empty;
            RankedParticipant candidate = null;

            lock (RankedSync)
            {
                PruneExpiredMatchesLocked();
                if (RankedByPlayer.TryGetValue(playerId, out RankedParticipant existing) &&
                    existing.Match != null &&
                    existing.Match.Ready &&
                    !existing.Match.Completed &&
                   string.Equals(existing.QueueKey, queueKey, StringComparison.Ordinal) &&
                    existing.Mode != null &&
                    existing.Mode.Id == mode.Id)
                {
                    candidate = existing;
                }
            }

             if (candidate == null)
                return false;

            bool recoverable;
            try
            {
                recoverable = RankedAuthorityRepository.Instance.IsRecoverableHandoff(
                    candidate.Match.RoomId,
                    playerId,
                    out lifecycle);
            }
           catch
            {
                return false;
            }

            if (!recoverable)
            {
               lock (RankedSync)
                {
                    if (candidate.Match != null && !candidate.Match.Completed)
                        ClearMatchHandoffLocked(candidate.Match);
                }
                return false;
            }

            lock (RankedSync)
            {
                if (candidate.Match == null || candidate.Match.Completed)
                    return false;

                candidate.Service = this;
                _rankedParticipant = candidate;
                _rankedRoomId = candidate.Match.RoomId;
                _rankedActive = false;
                participant = candidate;
                return true;
             }
        }
        private RankedParticipant TryRecoverDurableHandoff(
            RankedQueueStatus queueStatus,
            string playerId,
            string playerName,
            RankedModeContract mode,
            string queueKey,
            string profile,
            string filterCondition)
        {
            if (queueStatus == null || string.IsNullOrWhiteSpace(queueStatus.ActiveMatchId))
                return null;

            BsonDocument document;
            try
            {
                document = RankedAuthorityRepository.Instance.GetRecoverableHandoff(
                    queueStatus.ActiveMatchId,
                    playerId);
           }
           catch
            {
                return null;
            }

            if (document == null)
                 return null;

           string durableMode = document.GetValue("mode", string.Empty).ToString();
            if (!string.Equals(durableMode, mode.WireName, StringComparison.OrdinalIgnoreCase))
                return null;

            lock (RankedSync)
            {
                if (RankedByPlayer.TryGetValue(playerId, out RankedParticipant existing) &&
                    existing.Match != null &&
                    existing.Match.Ready &&
                    !existing.Match.Completed)
                {
                    existing.Service = this;
                    _rankedParticipant = existing;
                    _rankedRoomId = existing.Match.RoomId;
                    _rankedActive = false;
                    return existing;
                }

                string roomId = document.GetValue("roomId", document.GetValue("matchId", queueStatus.ActiveMatchId)).ToString();
                 var match = new RankedMatch
                {
                    RoomId = roomId,
                    Profile = document.GetValue("profile", profile ?? string.Empty).ToString(),
                    FilterCondition = document.GetValue("filter", filterCondition ?? string.Empty).ToString(),
                    Region = NormalizeClientRegion(document.GetValue("region", "Europe").ToString()),
                    SelectedLevelId = document.GetValue("selectedLevel", string.Empty).ToString(),
                    QueueKey = document.GetValue("queueKey", queueKey ?? string.Empty).ToString(),
                    Mode = mode,
                    RequiredPlayers = document.GetValue("requiredPlayers", 0).ToInt32(),
                    CreatedUtc = DateTime.UtcNow,
                    ReadyUtc = DateTime.UtcNow,
                    ReadyExpiresUtc = DateTime.UtcNow.AddSeconds(GetReadyRetentionSeconds()),
                    Ready = true,
                    DoneSent = true,
                    Completed = false
                };

                if (!document.TryGetValue("players", out BsonValue playersValue) || !playersValue.IsBsonArray)
                    return null;

                foreach (BsonValue value in playersValue.AsBsonArray)
                {
                     if (!value.IsBsonDocument)
                        continue;

                    BsonDocument player = value.AsBsonDocument;
                    string durablePlayerId = player.GetValue("playerId", string.Empty).ToString();
                     if (string.IsNullOrWhiteSpace(durablePlayerId))
                        continue;

                    var recovered = new RankedParticipant
                    {
                       Service = string.Equals(durablePlayerId, playerId, StringComparison.Ordinal) ? this : null,
                        PlayerId = durablePlayerId,
                        PlayerName = player.GetValue("name",
                            string.Equals(durablePlayerId, playerId, StringComparison.Ordinal) ? playerName : "Player").ToString(),
                        Profile = match.Profile,
                        FilterCondition = match.FilterCondition,
                        GroupId = string.Empty,
                        GroupSize = 1,
                        Region = match.Region,
                        RequestedLevels = string.IsNullOrWhiteSpace(match.SelectedLevelId) ? Array.Empty<string>() : new[] { match.SelectedLevelId },
                       TeamIndex = player.GetValue("matchTeam", 0).ToInt32(),
                        Mmr = player.GetValue("mmr", 500).ToInt32(),
                        Mode = mode,
                        QueueKey = match.QueueKey,
                        QueuedUtc = DateTime.UtcNow,
                        Confirmed = player.GetValue("confirmed", true).ToBoolean(),
                        Match = match
                    };
                    match.Players.Add(recovered);
                    RankedByPlayer[durablePlayerId] = recovered;
                }

                if (match.RequiredPlayers <= 0)
                    match.RequiredPlayers = match.Players.Count;

                RankedParticipant current = match.Players.FirstOrDefault(x =>
                    string.Equals(x.PlayerId, playerId, StringComparison.Ordinal));
                if (current == null)
                {
                    ClearMatchHandoffLocked(match);
                    return null;
                }

                _rankedParticipant = current;
                _rankedRoomId = match.RoomId;
                _rankedActive = false;
                return current;
             }
        }

        private void StartRanked(RpcRequest request)
        {
            RankedStartData start = request.Params.Count > 0
                ? ParseRankedStart(request.Params[0])
                 : new RankedStartData();

            string requestedGameMode = (start.GameMode ?? string.Empty).Trim();
            string playerId = GetCurrentPlayerId();
           string playerName = GetCurrentPlayerName();
            RankedModeContract mode;
            if (!RankedModeContracts.TryResolve(requestedGameMode, requestedGameMode, out mode))
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                var unknown = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Profile = requestedGameMode, FilterCondition = requestedGameMode };
                SendRankedFail(unknown, 0, "unsupported-ranked-game-mode");
                return;
            }

            string profile = mode.Profile;
            _rankedFilterCondition = mode.Profile;
            string clientRegion = PickClientRegion(start.Regions);
            string queueRegion = GetRegionKey(clientRegion);
            string[] requestedLevels = NormalizeLevels(start.FiltersOrLevels);
            string levelQueueKey = BuildLevelKey(requestedLevels);


            RankedMatchmakingSettings settings = RankedSettings.For(mode);
            int requiredPlayers = RankedModeContracts.GetRequiredPlayers(mode);
            int teamCapacity = Math.Max(1, requiredPlayers / 2);
            string groupId = start.GroupId ?? string.Empty;
            int requestedGroupSize = start.GroupSize <= 0 ? 1 : start.GroupSize;
            int groupSize = string.IsNullOrEmpty(groupId) ? 1 : requestedGroupSize;
            BoltLobby liveRankedLobby = null;

            try
            {
                PlayerStatus lobbyStatus = ServerState.GetOrCreatePlayerStatus(playerId);
                string liveLobbyId = lobbyStatus?.playInGame?.lobbyId ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(liveLobbyId) && ServerState.Lobbies.TryGetValue(liveLobbyId, out BoltLobby liveLobby) &&
                    liveLobby != null && liveLobby.IsLobbyMember(playerId))
                {
                    liveRankedLobby = liveLobby;
                    int liveMembers = Math.Max(1, liveLobby.LobbyMembers?.Length ?? 1);
                   string requestGroupId = groupId;
                    int requestGroupSize = groupSize;
                    groupId = liveLobby.Id;
                    groupSize = liveMembers;
                }
            }
            catch
            {
            }

            string queueKey = mode.QueueKey(profile, _rankedFilterCondition + "|levels=" + levelQueueKey, queueRegion, "s3");

            if (groupSize < 1 || groupSize > teamCapacity)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                SendRankedFail(denied, 0, "invalid-ranked-group-size");
                return;
            }

            RankedParticipant existingLifecycle = null;
            int existingLifecycleState = 0;
            string existingReadyRoom = null;
            lock (RankedSync)
            {
                if (RankedByPlayer.TryGetValue(playerId, out RankedParticipant existing) && existing != null)
                 {
                    if (existing.Match != null && !existing.Match.Completed)
                    {
                        if (existing.Match.Ready)
                        {
                             existingReadyRoom = existing.Match.RoomId;
                        }
                        else
                        {
                            existing.Service = this;
                            _rankedParticipant = existing;
                            _rankedRoomId = existing.Match.RoomId;
                            _rankedGeneration = existing.Generation;
                            existingLifecycle = existing;
                            existingLifecycleState = RankedStateConfirmation;
                        }
                    }
                    else if (existing.Match == null && RankedWaiting.Contains(existing) &&
                             existing.Mode != null && existing.Mode.Id == mode.Id &&
                             string.Equals(existing.QueueKey, queueKey, StringComparison.Ordinal))
                    {
                        existing.Service = this;
                        _rankedParticipant = existing;
                         _rankedRoomId = null;
                        _rankedGeneration = existing.Generation;
                        existingLifecycle = existing;
                        existingLifecycleState = RankedStateMatchmaking;
                    }
                }
            }
            if (!string.IsNullOrWhiteSpace(existingReadyRoom))
            {
                string lifecycle = "Unknown";
                bool finalized = false;
                bool releaseReady = false;
                try
                 {
                   lifecycle = RankedAuthorityRepository.Instance.GetMatchLifecycleStatus(existingReadyRoom, out finalized);
                    if (finalized ||
                        string.Equals(lifecycle, "Cancelled", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(lifecycle, "Canceled", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(lifecycle, "Finished", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(lifecycle, "Annulled", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(lifecycle, "Failed", StringComparison.OrdinalIgnoreCase))
                    {
                        releaseReady = true;
                    }
                    else if (string.Equals(lifecycle, "Ready", StringComparison.OrdinalIgnoreCase))
                    {
                        BsonDocument activeRejoin = RankedAuthorityRepository.Instance.GetActiveRejoinDescriptor(playerId);
                        if (activeRejoin != null &&
                            string.Equals(activeRejoin.GetValue("matchId", string.Empty).ToString(), existingReadyRoom, StringComparison.Ordinal))
                        {
                            releaseReady = false;
                            lifecycle = activeRejoin.GetValue("status", "Joined").ToString();
                        }
                        else
                        {
                            releaseReady = RankedAuthorityRepository.Instance.TryCancelPreRunningMatch(
                                existingReadyRoom, "superseded-by-new-start", playerId);
                        }
                    }
                    else if (string.Equals(lifecycle, "Disconnected", StringComparison.OrdinalIgnoreCase))
                    {
                        releaseReady = RankedAuthorityRepository.Instance.TryReleaseExpiredDisconnectedMatch(
                            playerId, existingReadyRoom, TimeSpan.FromSeconds(105),
                            "stale-disconnected-expired-on-new-start");
                    }
                }
                catch
                {
                }

                if (releaseReady)
               {
                    lock (RankedSync)
                    {
                        if (RankedByPlayer.TryGetValue(playerId, out RankedParticipant stale) &&
                           stale?.Match != null &&
                            string.Equals(stale.Match.RoomId, existingReadyRoom, StringComparison.Ordinal))
                        {
                            ClearMatchHandoffLocked(stale.Match);
                        }
                   }
                }
                else
                {
                    StorageRemoteService.ArmRankedRejoin(playerId, "start-blocked-ready-handoff");
                    SendMatchmakingAlreadyStarted(request.Id, existingReadyRoom, lifecycle);
                    return;
                }
            }
            if (existingLifecycle != null)
            {
                _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Return = new BinaryValue { IsNull = true }
                    }
                });
                SendRankedProgress(existingLifecycle, existingLifecycleState);
                return;
            }

            RankedQueueStatus queueStatus;
            try
            {
                queueStatus = RankedStatGuard.LoadQueueStatus(playerId, mode);
            }
            catch
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                 SendRankedFail(denied, 0, "ranked-db-unavailable");
                return;
            }

            long nowUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            if (queueStatus.IsBanned(nowUnix))
            {
                SendMatchmakingBanned(request.Id, queueStatus.BannedUntil);
                return;
            }
            if (queueStatus.LastMatchRunning != 0)
            {
                bool preRunning =
                    string.Equals(queueStatus.ActiveMatchStatus, "Ready", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(queueStatus.ActiveMatchStatus, "Confirmation", StringComparison.OrdinalIgnoreCase);
                bool expiredDisconnected =
                    string.Equals(queueStatus.ActiveMatchStatus, "Disconnected", StringComparison.OrdinalIgnoreCase) &&
                    !string.IsNullOrWhiteSpace(queueStatus.ActiveMatchId) &&
                    RankedAuthorityRepository.Instance.TryReleaseExpiredDisconnectedMatch(
                        playerId, queueStatus.ActiveMatchId, TimeSpan.FromSeconds(105),
                        "stale-disconnected-expired-on-new-start");
                if (expiredDisconnected)
                {
                    string releasedMatchId = queueStatus.ActiveMatchId;
                    lock (RankedSync)
                    {
                        if (RankedByPlayer.TryGetValue(playerId, out RankedParticipant stale) &&
                            stale?.Match != null &&
                            string.Equals(stale.Match.RoomId, releasedMatchId, StringComparison.Ordinal))
                            ClearMatchHandoffLocked(stale.Match);
                    }
                    queueStatus = RankedStatGuard.LoadQueueStatus(playerId, mode);
                }
                if (preRunning &&
                    !string.IsNullOrWhiteSpace(queueStatus.ActiveMatchId) &&
                    RankedAuthorityRepository.Instance.GetActiveRejoinDescriptor(playerId) == null &&
                    RankedAuthorityRepository.Instance.TryCancelPreRunningMatch(queueStatus.ActiveMatchId, "stale-prerunning-on-new-start", playerId))
                {
                    queueStatus = RankedStatGuard.LoadQueueStatus(playerId, mode);
               }

                if (queueStatus.LastMatchRunning != 0)
                {
                    BsonDocument rejoin = RankedAuthorityRepository.Instance.GetActiveRejoinDescriptor(playerId);
                    if (rejoin == null && string.IsNullOrWhiteSpace(queueStatus.ActiveMatchId))
                    {
                        queueStatus = RankedStatGuard.LoadQueueStatus(playerId, mode);
                    }
                }

                if (queueStatus.LastMatchRunning != 0)
                {
                    StorageRemoteService.ArmRankedRejoin(playerId, "start-blocked-active-match");
                    SendMatchmakingAlreadyStarted(request.Id, queueStatus.ActiveMatchId ?? string.Empty, queueStatus.ActiveMatchStatus ?? string.Empty);
                    return;
                }
            }

            var lobbyPartySeeds = new List<(string PlayerId, string PlayerName, RankedQueueStatus QueueStatus, MatchmakingRemoteService Service)>();
            if (liveRankedLobby != null && groupSize > 1)
            {
                foreach (BoltFriend member in liveRankedLobby.LobbyMembers ?? Array.Empty<BoltFriend>())
                {
                    if (member == null || string.IsNullOrWhiteSpace(member.Id) ||
                        string.Equals(member.Id, playerId, StringComparison.Ordinal))
                        continue;

                    List<MatchmakingEventSender> liveSenders = ServerState.GetLiveEventSenders<MatchmakingEventSender>(member.Id);
                    MatchmakingEventSender liveSender = liveSenders.FirstOrDefault(x => x?.User != null);
                    if (liveSender == null)
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                        var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                        SendRankedFail(denied, 0, "ranked-lobby-member-offline");
                        return;
                    }

                    RankedQueueStatus memberStatus;
                    try { memberStatus = RankedStatGuard.LoadQueueStatus(member.Id, mode); }
                    catch
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                        var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                        SendRankedFail(denied, 0, "ranked-lobby-member-db-unavailable");
                        return;
                     }

                   if (memberStatus.IsBanned(nowUnix) || memberStatus.LastMatchRunning != 0)
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                        var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                        SendRankedFail(denied, 0, memberStatus.IsBanned(nowUnix) ? "ranked-lobby-member-banned" : "ranked-lobby-member-active-match");
                        return;
                    }
                    int memberLevel;
                     try { memberLevel = PlayerLevelRuntime.GetSnapshot(member.Id).Level; }
                     catch { memberLevel = 0; }
                    if (memberLevel < settings.RequiredLevel)
                    {
                        _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                        var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                       SendRankedFail(denied, 0, "ranked-lobby-member-required-level");
                        return;
                    }

                    string memberName = "Player";
                    try
                    {
                        if (ObjectId.TryParse(member.Id, out ObjectId memberObjectId))
                        {
                            var memberDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(memberObjectId);
                            if (memberDoc != null && !string.IsNullOrWhiteSpace(memberDoc.name))
                               memberName = memberDoc.name;
                        }
                    }
                    catch { }

                    lobbyPartySeeds.Add((member.Id, memberName, memberStatus, new MatchmakingRemoteService(liveSender.User)));
                }
                if (lobbyPartySeeds.Count != groupSize - 1)
                {
                    _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                    var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                    SendRankedFail(denied, 0, "ranked-lobby-roster-incomplete");
                    return;
                }
           }

            int playerLevel;
            try { playerLevel = PlayerLevelRuntime.GetSnapshot(playerId).Level; }
            catch
             {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
               var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                SendRankedFail(denied, 0, "ranked-level-unavailable");
                return;
            }
            if (playerLevel < settings.RequiredLevel)
            {
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
                var denied = new RankedParticipant { Service = this, PlayerId = playerId, PlayerName = playerName, Mode = mode, QueueKey = queueKey, Profile = profile, FilterCondition = _rankedFilterCondition };
                 SendRankedFail(denied, 0, "required-level");
                return;
            }

            _session.SendResponse(new ResponseMessage
            {
                 RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                   Return = new BinaryValue { IsNull = true }
               }
           });

            DateTime queuedAt = DateTime.UtcNow;
            long generation;
            RankedParticipant participant;
            List<RankedParticipant> requeued = new List<RankedParticipant>();
             List<RankedParticipant> timedOut;
            RankedMatch match;
            lock (RankedSync)
           {
                 timedOut = PruneExpiredMatchesLocked();
                 RankedGenerationByPlayer.TryGetValue(playerId, out long previousGeneration);
                generation = previousGeneration + 1L;
                RankedGenerationByPlayer[playerId] = generation;
                _rankedGeneration = generation;

                RankedParticipant existing;
                if (RankedByPlayer.TryGetValue(playerId, out existing))
                {
                    if (existing?.Match != null && !existing.Match.Completed)
                       throw new InvalidOperationException("active ranked lifecycle escaped start preflight");
                    requeued = RemoveParticipantLocked(existing, true);
                }

                participant = new RankedParticipant
                {
                    Service = this,
                    PlayerId = playerId,
                    PlayerName = playerName,
                    Profile = profile,
                    FilterCondition = _rankedFilterCondition,
                    GroupId = groupId,
                     GroupSize = groupSize,
                    Region = clientRegion,
                     RequestedLevels = requestedLevels,
                    TeamIndex = 0,
                    Mmr = queueStatus.Mmr,
                    Mode = mode,
                    QueueKey = queueKey,
                    QueuedUtc = queuedAt,
                    OriginalQueuedUtc = queuedAt,
                    Generation = generation,
                    Confirmed = false
                };

                _rankedParticipant = participant;
                _rankedActive = true;
                _rankedStateCode = RankedStateMatchmaking;
                RankedWaiting.Add(participant);
                RankedByPlayer[playerId] = participant;

                foreach (var seed in lobbyPartySeeds)
                {
                    if (RankedByPlayer.TryGetValue(seed.PlayerId, out RankedParticipant partyExisting) && partyExisting != null)
                    {
                        if (partyExisting.Match != null && !partyExisting.Match.Completed)
                            continue;
                        if (RankedWaiting.Contains(partyExisting))
                            RankedWaiting.Remove(partyExisting);
                    }

                    RankedGenerationByPlayer.TryGetValue(seed.PlayerId, out long seedPreviousGeneration);
                     long seedGeneration = seedPreviousGeneration + 1L;
                    RankedGenerationByPlayer[seed.PlayerId] = seedGeneration;

                    var partyMember = new RankedParticipant
                    {
                        Service = seed.Service,
                        PlayerId = seed.PlayerId,
                        PlayerName = seed.PlayerName,
                        Profile = profile,
                        FilterCondition = _rankedFilterCondition,
                        GroupId = groupId,
                        GroupSize = groupSize,
                        Region = clientRegion,
                        RequestedLevels = requestedLevels,
                       TeamIndex = 0,
                        Mmr = seed.QueueStatus.Mmr,
                        Mode = mode,
                        QueueKey = queueKey,
                        QueuedUtc = queuedAt,
                       OriginalQueuedUtc = queuedAt,
                        Generation = seedGeneration,
                        Confirmed = false,
                        SyntheticLobbyMember = true
                    };
                    RankedWaiting.Add(partyMember);
                    RankedByPlayer[partyMember.PlayerId] = partyMember;
                }

                match = TryCreateRankedMatchLocked(participant.QueueKey, participant.FilterCondition, participant.Profile, participant.Mode);
            }
            foreach (RankedParticipant expired in timedOut)
            {
                if (expired?.Service == null || !IsParticipantConnected(expired)) continue;
                expired.Service.SendRankedFail(expired, 3, "group-member-not-confirmed");
                expired.Service.SendRankedProgress(expired, RankedStateNotConfirmed);
                if (!expired.ConfirmationTimedOut)
                    expired.Service.SendRankedProgress(expired, RankedStateMatchmaking);
            }
            lock (RankedSync) SaveRankedSearchStatusLocked();
            SendRankedProgress(participant, RankedStateMatchmaking);
           foreach (var seed in lobbyPartySeeds)
            {
                RankedParticipant partyQueued = null;
                 lock (RankedSync) { RankedByPlayer.TryGetValue(seed.PlayerId, out partyQueued); }
                if (partyQueued?.Service != null && IsParticipantConnected(partyQueued))
                     partyQueued.Service.SendRankedProgress(partyQueued, partyQueued.Match != null ? RankedStateConfirmation : RankedStateMatchmaking);
            }
           foreach (RankedParticipant other in requeued)
                if (other?.Service != null && IsParticipantConnected(other))
                    other.Service.SendRankedProgress(other, RankedStateMatchmaking);

            if (match != null)
            {
                 foreach (RankedParticipant matched in match.Players.ToArray())
                    if (matched?.Service != null && IsParticipantConnected(matched))
                        matched.Service.SendRankedProgress(matched, RankedStateConfirmation);

                SendPlayersConfirmed(match);
            }
        }

        private void ConfirmRanked(RpcRequest request)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                     Id = request.Id,
                    Return = new BinaryValue { IsNull = true }
                }
            });

            string playerId = GetCurrentPlayerId();
            RankedParticipant participant;
            RankedMatch match;
            bool resendDone = false;
           bool alreadyConfirmed = false;
            List<RankedParticipant> timedOut;

            lock (RankedSync)
            {
                timedOut = PruneExpiredMatchesLocked();
                participant = _rankedParticipant;
                if (participant == null || !string.Equals(participant.PlayerId, playerId, StringComparison.Ordinal))
                    RankedByPlayer.TryGetValue(playerId, out participant);
                match = participant?.Match;

               if (participant == null || match == null || match.Completed)
                {
                }
                else
                {
                     RankedGenerationByPlayer.TryGetValue(playerId, out long currentGeneration);
                    if (participant.SyntheticLobbyMember && currentGeneration == participant.Generation &&
                       (_rankedGeneration == 0 || _rankedGeneration != participant.Generation))
                    {
                        participant.Service = this;
                         participant.SyntheticLobbyMember = false;
                        _rankedParticipant = participant;
                         _rankedGeneration = participant.Generation;
                        _rankedRoomId = match.RoomId;
                    }
                    if (participant.Generation <= 0 || participant.Generation != _rankedGeneration || currentGeneration != participant.Generation)
                    {
                        participant = null;
                        match = null;
                    }
                    else if (match.Ready)
                    {
                        participant.Service = this;
                        _rankedParticipant = participant;
                        _rankedRoomId = match.RoomId;
                        resendDone = true;
                    }
                    else
                    {
                        alreadyConfirmed = participant.Confirmed;
                   }
                }
            }

            foreach (RankedParticipant expired in timedOut)
             {
                if (expired?.Service == null || !IsParticipantConnected(expired)) continue;
                expired.Service.SendRankedFail(expired, 3, "group-member-not-confirmed");
                expired.Service.SendRankedProgress(expired, RankedStateNotConfirmed);
                if (!expired.ConfirmationTimedOut)
                    expired.Service.SendRankedProgress(expired, RankedStateMatchmaking);
            }
            if (participant == null || match == null || match.Completed)
                return;

            if (resendDone)
             {
                try
                {
                    if (RankedAuthorityRepository.Instance.IsRecoverableHandoff(match.RoomId, participant.PlayerId, out string lifecycle))
                    {
                        SendRankedDoneToParticipant(match, participant);
                    }
                    else
                    {
                        lock (RankedSync) ClearMatchHandoffLocked(match);
                    }
                }
                catch
                {
                }
                return;
            }

             bool dbAllConfirmed;
            bool persisted;
            try
            {
                persisted = RankedAuthorityRepository.Instance.TryConfirmParticipant(
                    match.RoomId, participant.PlayerId, participant.Generation, match.ConfirmationId, out dbAllConfirmed);
            }
            catch
            {
                SendRankedFail(participant, 0, "ranked-db-unavailable");
                return;
            }
           if (!persisted)
            {
                SendRankedFail(participant, 0, "stale-confirmation");
                 return;
             }

            bool localAllConnected;
            lock (RankedSync)
            {
                if (participant.Match != match || match.Completed || match.Ready)
                    return;
                participant.Confirmed = true;
                participant.Service = this;
                _rankedParticipant = participant;
                _rankedRoomId = match.RoomId;
                localAllConnected = match.Players.Count == match.RequiredPlayers &&
                    match.Players.All(x => x.Confirmed && IsParticipantConnected(x));
            }

            if (!alreadyConfirmed)
                 SendPlayersConfirmed(match);
             foreach (RankedParticipant matched in match.Players.ToArray())
                if (matched?.Service != null && IsParticipantConnected(matched))
                    matched.Service.SendRankedProgress(matched, RankedStateConfirmation);

            bool shouldSendDone = false;
            if (dbAllConfirmed && localAllConnected)
            {
                bool readyPersisted;
                try
                 {
                    readyPersisted = RankedAuthorityRepository.Instance.TryMarkReady(match.RoomId, match.ConfirmationId, match.RosterHash);
                }
                catch
                {
                    SendRankedFail(participant, 0, "ranked-db-unavailable");
                    return;
                }

                if (!readyPersisted)
                {
                    SendRankedFail(participant, 0, "ranked-ready-rejected");
                    return;
                }

                lock (RankedSync)
                {
                    if (!match.Completed)
                   {
                        match.Ready = true;
                        match.ReadyUtc = DateTime.UtcNow;
                        match.ReadyExpiresUtc = DateTime.UtcNow.AddSeconds(GetReadyRetentionSeconds());
                        if (!match.DoneSent)
                        {
                            match.DoneSent = true;
                            shouldSendDone = true;
                        }
                    }
                }
            }

            if (shouldSendDone)
                SendRankedDone(match);
        }

        private void CancelRanked(RpcRequest request)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                    Return = new BinaryValue { IsNull = true }
                }
            });

            string playerId = GetCurrentPlayerId();
            RankedParticipant current;
            RankedMatch cancelledMatch;
            lock (RankedSync)
            {
               current = _rankedParticipant;
                if (current == null || !string.Equals(current.PlayerId, playerId, StringComparison.Ordinal))
                    RankedByPlayer.TryGetValue(playerId, out current);
                cancelledMatch = current?.Match;
            }

            if (cancelledMatch != null && !cancelledMatch.Ready && !cancelledMatch.Completed)
            {
                try
                {
                    if (!RankedAuthorityRepository.Instance.TryCancelPreRunningMatch(cancelledMatch.RoomId, "client-cancel", playerId))
                    {
                        SendRankedFail(current, 0, "ranked-cancel-rejected");
                        return;
                    }
                }
                catch
                {
                    SendRankedFail(current, 0, "ranked-db-unavailable");
                    return;
                }
            }
            else if (cancelledMatch != null && cancelledMatch.Ready)
            {
                return;
            }

            List<RankedParticipant> requeued;
            lock (RankedSync)
                requeued = current != null && current.Match == null
                    ? RemoveWaitingPartyLocked(current)
                    : RemoveParticipantLocked(current, true);

            lock (RankedSync) SaveRankedSearchStatusLocked();
            foreach (RankedParticipant participant in requeued)
            {
                if (participant?.Service == null || !IsParticipantConnected(participant) ||
                    string.Equals(participant.PlayerId, playerId, StringComparison.Ordinal)) continue;
                participant.Service.SendRankedFail(participant, 2, "group-member-cancelled");
               participant.Service.SendRankedProgress(participant, RankedStateMatchmaking);
           }
        }

        public static void OnUserDisconnected(ClientSession user)
        {
            if (user == null) return;
            RankedParticipant participant;
           RankedMatch confirmationMatch = null;

            lock (RankedSync)
            {
                participant = RankedWaiting.FirstOrDefault(x => x.Service != null && ReferenceEquals(x.Service._session, user));
                if (participant == null)
                    participant = RankedByPlayer.Values.FirstOrDefault(x => x.Service != null && ReferenceEquals(x.Service._session, user));

                if (participant != null)
                {

                    MatchmakingRemoteService failoverService = null;
                   foreach (MatchmakingEventSender sender in ServerState.GetLiveEventSenders<MatchmakingEventSender>(participant.PlayerId))
                    {
                        ClientSession candidateUser = sender?.User;
                        if (candidateUser == null || ReferenceEquals(candidateUser, user)) continue;
                        if (candidateUser.TryGetRpcHandler("MatchmakingRemoteService", out MatchmakingRemoteService candidate))
                        {
                            failoverService = candidate;
                            break;
                         }
                    }

                    if (failoverService != null)
                    {
                        participant.Service = failoverService;
                        failoverService._rankedParticipant = participant;
                        failoverService._rankedRoomId = participant.Match?.RoomId;
                        failoverService._rankedGeneration = participant.Generation;
                       failoverService._rankedActive = participant.Match == null;
                        return;
                    }
                }

                if (participant?.Match != null && !participant.Match.Completed)
                {
                    confirmationMatch = participant.Match;
                    return;
                }
            }

             List<RankedParticipant> affected;
            lock (RankedSync)
                affected = participant != null && participant.Match == null
                    ? RemoveWaitingPartyLocked(participant)
                    : RemoveParticipantLocked(participant, true);

            foreach (RankedParticipant affectedParticipant in affected)
            {
                if (affectedParticipant.Service == null || !IsParticipantConnected(affectedParticipant)) continue;
                affectedParticipant.Service.SendRankedFail(affectedParticipant, 2, "group-member-disconnected");
               affectedParticipant.Service.SendRankedProgress(affectedParticipant, RankedStateMatchmaking);
            }
        }

        private string GetCurrentPlayerId()
        {
            string id;
            if (ServerState.Users.TryGetValue(_session.TcpClient, out id) && !string.IsNullOrEmpty(id))
                return id;
            return "local-player";
         }

        private string GetCurrentPlayerName()
        {
            try
            {
                var id = GetCurrentPlayerId();
                ObjectId objectId;
                if (ObjectId.TryParse(id, out objectId))
                {
                    var player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId);
                     if (player != null && !string.IsNullOrEmpty(player.name))
                        return player.name;
                }
            }
            catch
            {
            }
            return "Player";
        }

        private static byte[] SerializeLobby(BoltLobby lobby, string viewerId)
        {
            return BuildGeneratedLobby(lobby, viewerId).ToByteArray();
        }

        private static Axlebolt.Bolt.Protobuf2.Lobby BuildGeneratedLobby(BoltLobby lobby, string viewerId)
        {
             var result = new Axlebolt.Bolt.Protobuf2.Lobby();
            if (lobby == null) return result;

            result.Id = lobby.Id ?? string.Empty;
            result.OwnerGpid = lobby.LobbyOwnerId ?? string.Empty;
            result.Name = lobby.Name ?? string.Empty;
            result.LobbyType = (Axlebolt.Bolt.Protobuf2.LobbyType)(int)lobby.Type;
            result.Joinable = lobby.Joinable;
            result.MaxMembers = Math.Max(0, lobby.MaxMembers);
            result.MaxSpectators = Math.Max(0, lobby.MaxSpectators);
            result.NumberOfMembers = lobby.LobbyMembers?.Length ?? 0;
            result.NumberOfSpectators = lobby.LobbySpectators?.Length ?? 0;
             result.Token = string.Empty;
            result.Data.Add(lobby.Data);

             foreach (BoltFriend entry in lobby.LobbyMembers ?? Array.Empty<BoltFriend>())
            {
                PlayerDocument document = entry?.GetPlayerDocument();
                if (document != null) result.Members.Add(document.GetPlayerFriend(viewerId));
            }
            foreach (BoltFriend entry in lobby.LobbyMemberInvites ?? Array.Empty<BoltFriend>())
            {
                PlayerDocument document = entry?.GetPlayerDocument();
                if (document != null) result.Invites.Add(document.GetPlayerFriend(viewerId));
           }
             foreach (BoltFriend entry in lobby.LobbySpectators ?? Array.Empty<BoltFriend>())
            {
                PlayerDocument document = entry?.GetPlayerDocument();
                 if (document != null) result.Spectators.Add(document.GetPlayerFriend(viewerId));
            }
            foreach (BoltFriend entry in lobby.LobbySpectatorInvites ?? Array.Empty<BoltFriend>())
            {
                PlayerDocument document = entry?.GetPlayerDocument();
                if (document != null) result.SpectatorInvites.Add(document.GetPlayerFriend(viewerId));
            }

            if (lobby.GameServer != null) result.GameServer = lobby.GameServer.Clone();
            if (lobby.PhotonGame != null) result.PhotonGame = RpcServer.PhotonGame.GetByDocument(lobby.PhotonGame);
            return result;
        }

        private static byte[] SerializeLobbyInviteV2(LobbyInvite invite)
        {
            string lobbyName = string.Empty;
            if (invite != null && ServerState.Lobbies.TryGetValue(invite.LobbyId, out BoltLobby lobby))
                lobbyName = lobby?.Name ?? string.Empty;
            return SocialContract.SerializeLobbyInvite(invite, lobbyName);
        }

        private void GetInvitesToLobbyV2(RpcRequest request)
       {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            LobbyInvite[] invites = LobbyInviteRuntimeStore.GetForPlayer(playerId);
            byte[] response = ContractWire.Build(w =>
             {
                foreach (LobbyInvite invite in invites) w.Message(1, SerializeLobbyInviteV2(invite));
            });
            ContractWire.SendRaw(_session, request.Id, response);
       }

        private static string ResolvePhotonHost()
        {
            string configured = ServerOptions.Current.PublicHost;
            if (!string.IsNullOrWhiteSpace(configured))
                return configured.Trim();

            throw new InvalidOperationException("PublicHost is not configured in serverconfig.json.");
        }

       private void CreateLobbyWithSpectatorsV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] raw = ContractWire.Param(request);
            string name = ContractWire.ReadStringField(raw, 1, "Lobby");
            int lobbyTypeValue = ContractWire.ReadIntField(raw, 2, (int)LobbyType.Private);
           int maxMembers = Math.Max(1, Math.Min(ContractWire.ReadIntField(raw, 3, 5), 10));
            int maxSpectators = Math.Max(0, Math.Min(ContractWire.ReadIntField(raw, 4, 0), 10));
            List<string> visibleKeys = ContractWire.ReadRepeatedStringField(raw, 5);

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            string currentLobbyId = status.playInGame?.lobbyId ?? string.Empty;
             if (!string.IsNullOrWhiteSpace(currentLobbyId))
            {
                if (ServerState.Lobbies.TryGetValue(currentLobbyId, out BoltLobby currentLobby) &&
                    LobbyContainsPlayer(currentLobby, playerId))
                {
                    byte[] existingResponse = ContractWire.Build(w => w.Message(1, SerializeLobby(currentLobby, playerId)));
                    ContractWire.SendRaw(_session, request.Id, existingResponse);
                    return;
                }
                ClearPlayerLobbyState(playerId, "create-stale-or-detached");
                status = ServerState.GetOrCreatePlayerStatus(playerId);
            }

            PlayerDocument player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(playerObjectId);
            if (player == null)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
           }

            LobbyType protoType = System.Enum.IsDefined(typeof(LobbyType), lobbyTypeValue)
                ? (LobbyType)lobbyTypeValue
                : LobbyType.Private;
            var data = new System.Collections.Concurrent.ConcurrentDictionary<string, string>();

            var lobby = new BoltLobby(
                Guid.NewGuid().ToString(), playerId, name,
                EnumMapper<LobbyType, BoltLobby.LobbyType>.ToOriginal(protoType),
                protoType != LobbyType.Invisible, maxMembers, maxSpectators,
                data,
                new List<BoltFriend> { player.GetBoltFriend() },
                new List<BoltFriend>(), new List<BoltFriend>(), new List<BoltFriend>(),
                null,
                null)
            {
                LobbyOwnerId = playerId,
                DataVisibleInSearch = new HashSet<string>(
                    visibleKeys.Where(x => !string.IsNullOrWhiteSpace(x)),
                    StringComparer.Ordinal)
            };

            status.playInGame ??= new PlayInGame();
            status.playInGame.lobbyId = lobby.Id;
                status.playInGame.lobbyName = lobby.Name;
            status.playInGame.photonGame = null;
           BoltMainDatabaseProvider.Instance.SetPlayerStatus(playerObjectId, status);
            PersistLobby(lobby);

            byte[] response = ContractWire.Build(w => w.Message(1, SerializeLobby(lobby, playerId)));
            ContractWire.SendRaw(_session, request.Id, response);
        }

         private void SearchLobby(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            SearchLobbyRequest parsed;
            try
            {
                byte[] raw = ContractWire.Param(request);
                 parsed = raw.Length == 0 ? new SearchLobbyRequest() : SearchLobbyRequest.Parser.ParseFrom(raw);
            }
            catch
           {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            int amount = Math.Max(1, Math.Min(parsed.Amount <= 0 ? 20 : parsed.Amount, 100));
            BoltLobby[] snapshot;
            lock (ServerState.Lobbies) snapshot = ServerState.Lobbies.Values.ToArray();
            BoltLobby[] lobbies = snapshot
                 .Where(x => x != null &&
                            x.Joinable &&
                            x.Type == BoltLobby.LobbyType.Public &&
                            x.LobbyMembers.Length < x.MaxMembers &&
                            MatchesLobbyFilters(x, parsed.Filters))
                .Take(amount)
                .ToArray();

            byte[] response = ContractWire.Build(w =>
            {
                 foreach (BoltLobby lobby in lobbies)
                    w.Message(1, SerializeLobby(lobby, playerId));
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void SetLobbyDataV2(RpcRequest request)
        {
             if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

             try
            {
                 byte[] nested = ContractWire.ReadBytesField(ContractWire.Param(request), 1);
                var changes = nested.Length == 0
                    ? new Axlebolt.Bolt.Protobuf2.Dictionary()
                    : Axlebolt.Bolt.Protobuf2.Dictionary.Parser.ParseFrom(nested);
                PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
                string lobbyId = status.playInGame?.lobbyId ?? string.Empty;
                if (string.IsNullOrWhiteSpace(lobbyId) || !ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
                {
                    if (!string.IsNullOrWhiteSpace(lobbyId))
                        ClearPlayerLobbyState(playerId, "set-data-missing-lobby");
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }
                if (!LobbyContainsPlayer(lobby, playerId))
                {
                    ClearPlayerLobbyState(playerId, "set-data-detached-player");
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }

                bool callerIsOwner = string.Equals(lobby.LobbyOwnerId, playerId, StringComparison.Ordinal);
                 if (!callerIsOwner && !lobby.IsLobbyMember(playerId))
                {
                    ContractWire.SendException(_session, request.Id, 403);
                   return;
                 }

                var updated = new System.Collections.Generic.Dictionary<string, string>(lobby.Data, StringComparer.Ordinal);
                foreach (KeyValuePair<string, string> pair in changes.Content)
                {
                    if (string.IsNullOrWhiteSpace(pair.Key)) continue;
                    updated[pair.Key] = pair.Value ?? string.Empty;
                }
                 lobby.Data = updated;
                if (lobby.PhotonGame != null)
                {
                    lobby.PhotonGame.customProperties ??= new Dictionary<string, string>();
                    lobby.PhotonGame.customProperties["lobby_id"] = lobby.Id;
                    if (lobby.Data.TryGetValue("game_mode", out string lobbyGameMode))
                        lobby.PhotonGame.customProperties["game_mode"] = lobbyGameMode ?? string.Empty;
                    if (lobby.Data.TryGetValue("region", out string lobbyRegion))
                        lobby.PhotonGame.customProperties["region"] = lobbyRegion ?? string.Empty;
                    if (lobby.Data.TryGetValue("custom_game_settings", out string customGameSettings))
                         lobby.PhotonGame.customProperties["custom_game_settings"] = customGameSettings ?? "{}";
                }
                 PersistLobby(lobby);

                var normalizedEventData = new Axlebolt.Bolt.Protobuf2.Dictionary();
                normalizedEventData.Content.Add(lobby.Data);
                ContractWire.SendEmpty(_session, request.Id);
                BroadcastLobbyEvent(lobby, "onLobbyDataChanged", normalizedEventData);
                string changedKeys = string.Join(",", changes.Content.Select(x => $"{x.Key}:{(x.Value ?? string.Empty).Length}"));
           }
            catch
            {
                ContractWire.SendException(_session, request.Id, 400);
            }
        }

        private void SetLobbyJoinableV2(RpcRequest request)
         {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
           {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            byte[] payload = ContractWire.Param(request);
            bool joinable = ContractWire.ReadIntField(payload, 1, 0) != 0;
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby))
                return;

            bool changed = lobby.Joinable != joinable;
            lobby.Joinable = joinable;
            PersistLobby(lobby);
             ContractWire.SendEmpty(_session, request.Id);
            if (changed)
                BroadcastLobbyEvent(lobby, "onLobbyJoinableChanged", joinable);
        }

        private static bool MatchesLobbyFilters(
            BoltLobby lobby,
            IEnumerable<Axlebolt.Bolt.Protobuf2.Filter> filters)
        {
            if (lobby == null) return false;
            foreach (Axlebolt.Bolt.Protobuf2.Filter filter in filters ?? Enumerable.Empty<Axlebolt.Bolt.Protobuf2.Filter>())
            {
                if (filter == null || string.IsNullOrWhiteSpace(filter.Name)) continue;

                if (lobby.DataVisibleInSearch != null &&
                    lobby.DataVisibleInSearch.Count > 0 &&
                    !lobby.DataVisibleInSearch.Contains(filter.Name))
                    return false;

               bool hasValue = lobby.Data.TryGetValue(filter.Name, out string actual);
                actual ??= string.Empty;

                switch (filter.ValueCase)
                {
                    case Axlebolt.Bolt.Protobuf2.Filter.ValueOneofCase.StringValue:
                        if (!MatchStringFilter(hasValue, actual, filter.StringValue ?? string.Empty, filter.Comparison))
                           return false;
                        break;

                    case Axlebolt.Bolt.Protobuf2.Filter.ValueOneofCase.IntValue:
                        if (!hasValue || !long.TryParse(actual, out long actualInt) ||
                            !MatchNumberFilter(actualInt, filter.IntValue, filter.Comparison))
                            return false;
                        break;

                    case Axlebolt.Bolt.Protobuf2.Filter.ValueOneofCase.FloatValue:
                        if (!hasValue || !double.TryParse(actual,
                                System.Globalization.NumberStyles.Float,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out double actualFloat) ||
                             !MatchNumberFilter(actualFloat, filter.FloatValue, filter.Comparison))
                            return false;
                        break;

                    case Axlebolt.Bolt.Protobuf2.Filter.ValueOneofCase.Strings:
                        string[] values = filter.Strings?.Value?.ToArray() ?? Array.Empty<string>();
                       bool inSet = hasValue && values.Contains(actual, StringComparer.Ordinal);
                        if (filter.Comparison == Axlebolt.Bolt.Protobuf2.Comparison.InOrNull)
                        {
                            if (hasValue && !inSet) return false;
                        }
                        else if (!inSet)
                        {
                            return false;
                        }
                        break;

                    case Axlebolt.Bolt.Protobuf2.Filter.ValueOneofCase.None:
                        if (!hasValue) return false;
                        break;
                }
            }
             return true;
        }

        private static bool MatchStringFilter(
           bool hasValue,
            string actual,
            string expected,
            Axlebolt.Bolt.Protobuf2.Comparison comparison)
        {
            switch (comparison)
            {
                case Axlebolt.Bolt.Protobuf2.Comparison.NotEqual:
                    return !hasValue || !string.Equals(actual, expected, StringComparison.Ordinal);
                case Axlebolt.Bolt.Protobuf2.Comparison.StartWith:
                    return hasValue && actual.StartsWith(expected, StringComparison.Ordinal);
                case Axlebolt.Bolt.Protobuf2.Comparison.InOrNull:
                    return !hasValue || string.Equals(actual, expected, StringComparison.Ordinal);
                default:
                    return hasValue && string.Equals(actual, expected, StringComparison.Ordinal);
            }
        }

        private static bool MatchNumberFilter(
             double actual,
            double expected,
            Axlebolt.Bolt.Protobuf2.Comparison comparison)
        {
            return comparison switch
            {
                Axlebolt.Bolt.Protobuf2.Comparison.LessThan => actual < expected,
                Axlebolt.Bolt.Protobuf2.Comparison.Equal => actual == expected,
                Axlebolt.Bolt.Protobuf2.Comparison.GreaterThan => actual > expected,
                Axlebolt.Bolt.Protobuf2.Comparison.EqualToOrGreaterThan => actual >= expected,
                Axlebolt.Bolt.Protobuf2.Comparison.NotEqual => actual != expected,
                _ => actual <= expected,
            };
        }

        private static void PersistLobby(BoltLobby lobby)
        {
            if (lobby == null || string.IsNullOrWhiteSpace(lobby.Id))
                return;
            lock (ServerState.Lobbies)
                ServerState.Lobbies[lobby.Id] = lobby;
            try
            {
                BoltGameDatabaseProvider.Instance?.UpsertLobbyRuntime(lobby);
            }
            catch
             {
            }
        }

        private static void DeleteLobby(string lobbyId)
        {
            if (string.IsNullOrWhiteSpace(lobbyId))
                return;
            lock (ServerState.Lobbies)
                ServerState.Lobbies.Remove(lobbyId);
            try
            {
                BoltGameDatabaseProvider.Instance?.DeleteLobbyRuntime(lobbyId);
            }
            catch
            {
            }
        }

        private static void ClearPlayerLobbyState(string playerId, string reason)
         {
            if (string.IsNullOrWhiteSpace(playerId))
                return;
            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.playInGame ??= new PlayInGame();
            string staleLobbyId = status.playInGame.lobbyId ?? string.Empty;
            status.playInGame.lobbyId = string.Empty;
                status.playInGame.lobbyName = string.Empty;
            status.playInGame.photonGame = null;
            if (ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                try { BoltMainDatabaseProvider.Instance.SetPlayerStatus(objectId, status); }
                catch
                {
                }
             }
        }

        private static bool LobbyContainsPlayer(BoltLobby lobby, string playerId)
        {
            return lobby != null &&
                   (lobby.IsLobbyMember(playerId) || lobby.IsLobbySpectator(playerId));
        }

         private static void BroadcastLobbyEvent(BoltLobby lobby, string eventName, params object[] payloads)
        {
            BroadcastLobbyEventExcept(lobby, null, eventName, payloads);
        }

        private static void BroadcastLobbyEventExcept(BoltLobby lobby, string excludePlayerId,
            string eventName, params object[] payloads)
        {
            if (lobby == null || string.IsNullOrWhiteSpace(eventName)) return;
            IEnumerable<BoltFriend> recipients = (lobby.LobbyMembers ?? Array.Empty<BoltFriend>())
                .Concat(lobby.LobbySpectators ?? Array.Empty<BoltFriend>())
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.Id))
                .Where(x => string.IsNullOrWhiteSpace(excludePlayerId) ||
                            !string.Equals(x.Id, excludePlayerId, StringComparison.Ordinal))
                .GroupBy(x => x.Id, StringComparer.Ordinal)
                .Select(x => x.First());

            foreach (BoltFriend recipient in recipients)
            {
                SocialEventDelivery.Send<MatchmakingEventSender>(
                    recipient.Id, "lobby", eventName, payloads ?? Array.Empty<object>());
            }
        }

        private static bool TryRestoreLobbyRuntime(string lobbyId, out BoltLobby lobby)
        {
            lobby = null;
            if (string.IsNullOrWhiteSpace(lobbyId)) return false;
            try
            {
                BsonDocument d = BoltGameDatabaseProvider.Instance?.GetLobbyRuntime(lobbyId);
                if (d == null) return false;

                string Str(string key) => d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToString() : string.Empty;
                int Int(string key, int fallback = 0) => d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToInt32() : fallback;
                bool Bool(string key, bool fallback = false) => d.TryGetValue(key, out BsonValue v) && !v.IsBsonNull ? v.ToBoolean() : fallback;
                List<BoltFriend> Friends(string key)
                {
                    var result = new List<BoltFriend>();
                    if (!d.TryGetValue(key, out BsonValue value) || !value.IsBsonArray) return result;
                    foreach (BsonValue idValue in value.AsBsonArray)
                    {
                        string id = idValue?.ToString() ?? string.Empty;
                        if (!ObjectId.TryParse(id, out ObjectId oid)) continue;
                        PlayerDocument pd = BoltMainDatabaseProvider.Instance.GetPlayerDocument(oid);
                        if (pd != null) result.Add(pd.GetBoltFriend());
                    }
                    return result;
                }

                List<BoltFriend> members = Friends("members");
                string ownerId = Str("ownerId");
                if (members.Count == 0 || !members.Any(x => string.Equals(x.Id, ownerId, StringComparison.Ordinal)))
                    return false;

                var data = new System.Collections.Concurrent.ConcurrentDictionary<string, string>(StringComparer.Ordinal);
                if (d.TryGetValue("data", out BsonValue dataValue) && dataValue.IsBsonDocument)
                    foreach (BsonElement e in dataValue.AsBsonDocument.Elements) data[e.Name] = e.Value?.ToString() ?? string.Empty;

                GameServer gameServer = null;
                if (d.TryGetValue("gameServer", out BsonValue gsValue) && gsValue.IsBsonDocument)
                {
                    BsonDocument gs = gsValue.AsBsonDocument;
                    string id = gs.GetValue("id", "").ToString();
                    string ip = gs.GetValue("ip", "").ToString();
                    int port = gs.GetValue("port", 0).ToInt32();
                    if (!string.IsNullOrWhiteSpace(id) || !string.IsNullOrWhiteSpace(ip) || port != 0)
                        gameServer = new GameServer { Id = id, Ip = ip, Port = port };
                }

                TspServer.RpcServer.PhotonGame photonGame = null;
                if (d.TryGetValue("photonGame", out BsonValue pgValue) && pgValue.IsBsonDocument)
                {
                    BsonDocument pg = pgValue.AsBsonDocument;
                    string region = pg.GetValue("region", "").ToString();
                    string roomId = pg.GetValue("roomId", "").ToString();
                    string appVersion = pg.GetValue("appVersion", "").ToString();
                    if (!string.IsNullOrWhiteSpace(region) || !string.IsNullOrWhiteSpace(roomId) || !string.IsNullOrWhiteSpace(appVersion))
                    {
                        photonGame = new TspServer.RpcServer.PhotonGame
                       {
                            region = region,
                            roomId = roomId,
                            appVersion = appVersion,
                            customProperties = new Dictionary<string, string>(StringComparer.Ordinal)
                        };
                        if (pg.TryGetValue("customProperties", out BsonValue cpValue) && cpValue.IsBsonDocument)
                            foreach (BsonElement e in cpValue.AsBsonDocument.Elements) photonGame.customProperties[e.Name] = e.Value?.ToString() ?? string.Empty;
                    }
                }

                var restored = new BoltLobby(
                    lobbyId, ownerId, Str("name"),
                    (BoltLobby.LobbyType)Int("type", 0), Bool("joinable", true),
                    Math.Max(1, Int("maxMembers", 5)), Math.Max(0, Int("maxSpectators", 0)),
                    data, members, Friends("spectators"), Friends("memberInvites"), Friends("spectatorInvites"),
                    gameServer, photonGame);
                if (d.TryGetValue("visibleDataKeys", out BsonValue keys) && keys.IsBsonArray)
                   restored.DataVisibleInSearch = new HashSet<string>(keys.AsBsonArray.Select(x => x.ToString()).Where(x => !string.IsNullOrWhiteSpace(x)), StringComparer.Ordinal);

                lock (ServerState.Lobbies) ServerState.Lobbies[lobbyId] = restored;
                lobby = restored;
               return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool TryResolveLiveLobby(string lobbyId, out BoltLobby lobby)
        {
            if (!string.IsNullOrWhiteSpace(lobbyId) && ServerState.Lobbies.TryGetValue(lobbyId, out lobby) && lobby != null)
                return true;
            return TryRestoreLobbyRuntime(lobbyId, out lobby);
        }

         private bool TryGetOwnedLobby(string playerId, string requestId, out BoltLobby lobby)
        {
            lobby = null;
            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            string lobbyId = status.playInGame?.lobbyId ?? string.Empty;
            if (string.IsNullOrWhiteSpace(lobbyId) || !TryResolveLiveLobby(lobbyId, out lobby))
            {
                if (!string.IsNullOrWhiteSpace(lobbyId))
                    ClearPlayerLobbyState(playerId, "owned-lobby-missing");
                ContractWire.SendException(_session, requestId, 404);
                return false;
            }
            if (!LobbyContainsPlayer(lobby, playerId))
            {
                ClearPlayerLobbyState(playerId, "owned-lobby-detached");
                ContractWire.SendException(_session, requestId, 404);
                lobby = null;
                return false;
            }
            if (!string.Equals(lobby.LobbyOwnerId, playerId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, requestId, 403);
                lobby = null;
                return false;
            }
            return true;
        }

        private void SetLobbyMaxMembersV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            int value = Math.Max(1, Math.Min(ContractWire.ReadIntField(ContractWire.Param(request), 1, lobby.MaxMembers), 10));
            lobby.MaxMembers = value;
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyMaxMembersChanged", value);
        }

        private void SetLobbyMaxSpectatorsV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
           if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            int value = Math.Max(0, Math.Min(ContractWire.ReadIntField(ContractWire.Param(request), 1, 0), 10));
            lobby.MaxSpectators = value;
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyMaxSpectatorsChanged", value);
        }

        private static IEnumerable<BoltFriend> LobbyAudience(BoltLobby lobby)
         {
           if (lobby == null) return Array.Empty<BoltFriend>();
            return (lobby.LobbyMembers ?? Array.Empty<BoltFriend>())
                .Concat(lobby.LobbySpectators ?? Array.Empty<BoltFriend>())
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.Id))
                 .GroupBy(x => x.Id, StringComparer.Ordinal)
                .Select(x => x.First());
        }
        private static void SendLobbyEventToPlayer(string playerId, string eventName, params object[] payloads)
        {
            SocialEventDelivery.Send<MatchmakingEventSender>(
                playerId, "lobby", eventName, payloads ?? Array.Empty<object>());
        }
        private bool TryGetCurrentLobby(string playerId, string requestId, out BoltLobby lobby)
        {
            lobby = null;
             PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            string lobbyId = status.playInGame?.lobbyId ?? string.Empty;
             if (!string.IsNullOrWhiteSpace(lobbyId) && TryResolveLiveLobby(lobbyId, out lobby))
            {
                if (LobbyContainsPlayer(lobby, playerId))
                    return true;
               ClearPlayerLobbyState(playerId, "current-lobby-detached");
            }
            else if (!string.IsNullOrWhiteSpace(lobbyId))
            {
                ClearPlayerLobbyState(playerId, "current-lobby-missing");
             }
            ContractWire.SendException(_session, requestId, 404);
            lobby = null;
            return false;
        }

        private static PlayerDocument GetPlayerDocumentOrNull(string playerId)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId objectId)) return null;
            try { return BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId); }
            catch { return null; }
        }

        private void SetLobbyTypeV2(RpcRequest request)
         {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            int rawType = ContractWire.ReadIntField(ContractWire.Param(request), 1, 0);
             if (rawType < 0 || rawType > 3)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            bool changed = (int)lobby.Type != rawType;
            lobby.Type = (BoltLobby.LobbyType)rawType;
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            if (changed)
                BroadcastLobbyEvent(lobby, "onLobbyTypeChanged", rawType);
        }

        private void GetLobby(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                 return;
            }
           string lobbyId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(lobbyId))
                lobbyId = ServerState.GetOrCreatePlayerStatus(playerId).playInGame?.lobbyId ?? string.Empty;

            if (string.IsNullOrWhiteSpace(lobbyId) || !TryResolveLiveLobby(lobbyId, out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
           byte[] response = ContractWire.Build(w => w.Message(1, SerializeLobby(lobby, playerId)));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void InvitePlayerToLobbyAs(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string inviterId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetCurrentLobby(inviterId, request.Id, out BoltLobby lobby)) return;
            if (!string.Equals(lobby.LobbyOwnerId, inviterId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, request.Id, 403);
                return;
            }
            byte[] raw = ContractWire.Param(request);
            string invitedId = ContractWire.ReadStringField(raw, 1, string.Empty);
            int rawPlayerType = ContractWire.ReadIntField(raw, 2, 0);
            LobbyPlayerType playerType = rawPlayerType == (int)LobbyPlayerType.Spectator
                ? LobbyPlayerType.Spectator : LobbyPlayerType.Member;
            PlayerDocument invited = GetPlayerDocumentOrNull(invitedId);
            if (invited == null || string.Equals(invitedId, inviterId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            BoltFriend invitedFriend = invited.GetBoltFriend();
            lobby.RemoveLobbyAnyInvite(invitedFriend);
            if (playerType == LobbyPlayerType.Spectator) lobby.AddLobbySpectatorInvite(invitedFriend);
            else lobby.AddLobbyMemberInvite(invitedFriend);
            PersistLobby(lobby);
            LobbyInvite invite = LobbyInviteRuntimeStore.Save(invitedId, lobby.Id, inviterId, playerType);

            ContractWire.SendEmpty(_session, request.Id);
            foreach (BoltFriend viewer in LobbyAudience(lobby))
            {
                PlayerFriend exactFriend = invited.GetPlayerFriend(viewer.Id);
                 SendLobbyEventToPlayer(viewer.Id,
                    playerType == LobbyPlayerType.Spectator ? "onNewSpectatorInvitedToLobby" : "onNewPlayerInvitedToLobby",
                    inviterId, exactFriend);
           }
            SendLobbyEventToPlayer(invitedId,
                playerType == LobbyPlayerType.Spectator ? "onReceivedSpectatorInviteToLobby" : "onReceivedInviteToLobby",
                invite);
        }

        private void SendLobbyChatMsgV2(RpcRequest request)
         {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
           {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetCurrentLobby(playerId, request.Id, out BoltLobby lobby)) return;
            string message = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(message))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
             }
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyChatMessage", playerId, message);
        }

        private void JoinLobbyAsV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
               ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            byte[] raw = ContractWire.Param(request);
           string lobbyId = ContractWire.ReadStringField(raw, 1, string.Empty);
            LobbyPlayerType playerType = ContractWire.ReadIntField(raw, 2, 0) == (int)LobbyPlayerType.Spectator
                ? LobbyPlayerType.Spectator : LobbyPlayerType.Member;
            string token = ContractWire.ReadStringField(raw, 3, string.Empty);

            if (string.IsNullOrWhiteSpace(lobbyId) || !TryResolveLiveLobby(lobbyId, out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }

            PlayerStatus currentStatus = ServerState.GetOrCreatePlayerStatus(playerId);
            string currentLobbyId = currentStatus.playInGame?.lobbyId ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(currentLobbyId))
            {
                if (string.Equals(currentLobbyId, lobbyId, StringComparison.Ordinal) &&
                    LobbyContainsPlayer(lobby, playerId))
                {
                    byte[] idempotentResponse = ContractWire.Build(w => w.Message(1, SerializeLobby(lobby, playerId)));
                    LobbyInviteRuntimeStore.Remove(playerId, lobby.Id);
                     ContractWire.SendRaw(_session, request.Id, idempotentResponse);
                    return;
                }

                if (ServerState.Lobbies.TryGetValue(currentLobbyId, out BoltLobby otherLobby) &&
                    LobbyContainsPlayer(otherLobby, playerId))
                {
                    ContractWire.SendException(_session, request.Id, 409);
                     return;
                }
                ClearPlayerLobbyState(playerId, "join-stale-or-detached");
             }

            PlayerDocument player = GetPlayerDocumentOrNull(playerId);
            if (player == null)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            bool invited = playerType == LobbyPlayerType.Spectator
                ? lobby.IsSpectatorInvited(playerId)
                : lobby.IsMemberInvited(playerId);
            PlayerDocument ownerDocument = GetPlayerDocumentOrNull(lobby.LobbyOwnerId);
            bool isOwnerFriend = ownerDocument != null && ownerDocument.IsContainsFriend(playerId);
            bool tokenMatches = string.Equals(token, lobby.Id, StringComparison.Ordinal);
            bool accessAllowed =
                lobby.Type == BoltLobby.LobbyType.Public ||
                (lobby.Type == BoltLobby.LobbyType.FriendsOnly && isOwnerFriend) ||
                invited ||
                tokenMatches;
            bool allowed = lobby.Joinable && accessAllowed;
            if (!allowed)
            {
                ContractWire.SendException(_session, request.Id, 5005);
                return;
            }
            if (playerType == LobbyPlayerType.Member && !lobby.IsLobbyMember(playerId) && lobby.LobbyMembers.Length >= lobby.MaxMembers)
             {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }
            if (playerType == LobbyPlayerType.Spectator && !lobby.IsLobbySpectator(playerId) && lobby.LobbySpectators.Length >= lobby.MaxSpectators)
            {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }

            BoltFriend playerFriend = player.GetBoltFriend();
            lobby.RemoveLobbyAny(playerFriend);
            lobby.RemoveLobbyAnyInvite(playerFriend);
            if (playerType == LobbyPlayerType.Spectator) lobby.AddLobbySpectator(playerFriend);
            else lobby.AddLobbyMember(playerFriend);
            PersistLobby(lobby);
            LobbyInviteRuntimeStore.Remove(playerId, lobby.Id);
            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.playInGame ??= new PlayInGame();
            status.playInGame.lobbyId = lobby.Id;
                status.playInGame.lobbyName = lobby.Name;
            status.playInGame.photonGame = lobby.PhotonGame == null ? null : new RpcServer.PhotonGame
            {
                region = lobby.PhotonGame.region,
                roomId = lobby.PhotonGame.roomId,
                appVersion = lobby.PhotonGame.appVersion,
                customProperties = new Dictionary<string, string>(lobby.PhotonGame.customProperties ?? new Dictionary<string, string>(), StringComparer.Ordinal)
            };
            if (ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(playerObjectId, status);

            byte[] response = ContractWire.Build(w => w.Message(1, SerializeLobby(lobby, playerId)));
            ContractWire.SendRaw(_session, request.Id, response);
            foreach (BoltFriend viewer in LobbyAudience(lobby))
            {
                if (string.Equals(viewer.Id, playerId, StringComparison.Ordinal)) continue;
                PlayerFriend exactFriend = player.GetPlayerFriend(viewer.Id);
                SendLobbyEventToPlayer(viewer.Id,
                    playerType == LobbyPlayerType.Spectator ? "onNewSpectatorJoinedLobby" : "onNewPlayerJoinedLobby",
                    exactFriend);
            }
        }

        private void SetLobbyPhotonGameV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            byte[] nested = ContractWire.ReadBytesField(ContractWire.Param(request), 1);
            Axlebolt.Bolt.Protobuf2.PhotonGame photonGame;
            try { photonGame = nested.Length == 0 ? new Axlebolt.Bolt.Protobuf2.PhotonGame() : Axlebolt.Bolt.Protobuf2.PhotonGame.Parser.ParseFrom(nested); }
            catch
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            string region = string.IsNullOrWhiteSpace(photonGame.Region) ? "eu" : photonGame.Region;
            string roomId = string.IsNullOrWhiteSpace(photonGame.RoomId) ? lobby.Id : photonGame.RoomId;
            string appVersion = string.IsNullOrWhiteSpace(photonGame.AppVersion) ? "0.33.0" : photonGame.AppVersion;
            var customProperties = photonGame.CustomProperties.ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            customProperties["lobby_id"] = lobby.Id;
            if (lobby.Data.TryGetValue("game_mode", out string gameMode)) customProperties["game_mode"] = gameMode ?? string.Empty;
            if (lobby.Data.TryGetValue("region", out string lobbyRegion)) customProperties["region"] = lobbyRegion ?? string.Empty;
            lobby.PhotonGame = new RpcServer.PhotonGame
            {
                region = region,
                 roomId = roomId,
                appVersion = appVersion,
                customProperties = customProperties
            };
            var exactPhotonGame = RpcServer.PhotonGame.GetByDocument(lobby.PhotonGame);
            foreach (BoltFriend participant in LobbyAudience(lobby))
            {
                PlayerStatus participantStatus = ServerState.GetOrCreatePlayerStatus(participant.Id);
               participantStatus.playInGame ??= new PlayInGame();
                participantStatus.playInGame.lobbyId = lobby.Id;
                participantStatus.playInGame.lobbyName = lobby.Name;
                participantStatus.playInGame.photonGame = new RpcServer.PhotonGame
                {
                    region = region,
                    roomId = roomId,
                    appVersion = appVersion,
                     customProperties = new Dictionary<string, string>(customProperties, StringComparer.Ordinal)
                };
                if (ObjectId.TryParse(participant.Id, out ObjectId participantObjectId))
                    BoltMainDatabaseProvider.Instance.SetPlayerStatus(participantObjectId, participantStatus);
            }
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyPhotonGameChanged", exactPhotonGame);
        }

        private void KickPlayerFromLobbyV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
           string kickedId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(kickedId) || string.Equals(kickedId, playerId, StringComparison.Ordinal))
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            BoltFriend kicked = lobby.GetLobbyAny(kickedId);
            if (kicked == null)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            lobby.RemoveLobbyAny(kicked);
            PersistLobby(lobby);
            PlayerStatus kickedStatus = ServerState.GetOrCreatePlayerStatus(kickedId);
            kickedStatus.playInGame ??= new PlayInGame();
            kickedStatus.playInGame.lobbyId = string.Empty;
                kickedStatus.playInGame.lobbyName = string.Empty;
            kickedStatus.playInGame.photonGame = null;
           if (ObjectId.TryParse(kickedId, out ObjectId kickedObjectId))
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(kickedObjectId, kickedStatus);
            ContractWire.SendEmpty(_session, request.Id);
             BroadcastLobbyEvent(lobby, "onPlayerKickedFromLobby", playerId, kickedId);
             SendLobbyEventToPlayer(kickedId, "onPlayerKickedFromLobby", playerId, kickedId);
        }

        private void RefuseInvitationToLobbyV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                 return;
            }
             string lobbyId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            LobbyInvite invite = LobbyInviteRuntimeStore.GetForPlayer(playerId)
                .FirstOrDefault(x => string.Equals(x.LobbyId, lobbyId, StringComparison.Ordinal));
            string inviterId = invite?.InviteSender?.Player?.Id ?? string.Empty;
            LobbyInviteRuntimeStore.Remove(playerId, lobbyId);
            if (ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
            {
                PlayerDocument document = GetPlayerDocumentOrNull(playerId);
               if (document != null) lobby.RemoveLobbyAnyInvite(document.GetBoltFriend());
                PersistLobby(lobby);
            }
            ContractWire.SendEmpty(_session, request.Id);
            if (ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby notifyLobby))
                BroadcastLobbyEvent(notifyLobby, "onRefuseInviteToLobby", inviterId, playerId);
        }

         private void RevokePlayerInvitationToLobbyV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            string revokedId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
           PlayerDocument document = GetPlayerDocumentOrNull(revokedId);
            if (document != null) lobby.RemoveLobbyAnyInvite(document.GetBoltFriend());
            LobbyInviteRuntimeStore.Remove(revokedId, lobby.Id);
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onRevokeInviteToLobby", playerId, revokedId);
            SendLobbyEventToPlayer(revokedId, "onRevokeInviteToLobby", playerId, revokedId);
        }

        private void ChangeLobbyOtherPlayerType(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            byte[] raw = ContractWire.Param(request);
            string targetId = ContractWire.ReadStringField(raw, 1, string.Empty);
            LobbyPlayerType type = ContractWire.ReadIntField(raw, 2, 0) == (int)LobbyPlayerType.Spectator
                ? LobbyPlayerType.Spectator : LobbyPlayerType.Member;
            if (lobby.GetLobbyAny(targetId) == null)
             {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            if (type == LobbyPlayerType.Member && !lobby.IsLobbyMember(targetId) && lobby.LobbyMembers.Length >= lobby.MaxMembers)
            {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }
            if (type == LobbyPlayerType.Spectator && !lobby.IsLobbySpectator(targetId) && lobby.LobbySpectators.Length >= lobby.MaxSpectators)
            {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }
            lobby.ChangeMemberType(targetId, type);
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyPlayerTypeChanged", targetId, (int)type);
        }

       private void SetLobbyOwnerV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
               ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            string newOwnerId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            if (!lobby.IsLobbyMember(newOwnerId))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            lobby.LobbyOwnerId = newOwnerId;
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyOwnerChanged", newOwnerId);
        }

         private void LeaveLobbyV2(RpcRequest request)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
           status.playInGame ??= new PlayInGame();
            string lobbyId = status.playInGame.lobbyId ?? string.Empty;
            status.playInGame.lobbyId = string.Empty;
                status.playInGame.lobbyName = string.Empty;
            status.playInGame.photonGame = null;
            BoltMainDatabaseProvider.Instance.SetPlayerStatus(playerObjectId, status);

            if (string.IsNullOrWhiteSpace(lobbyId) || !ServerState.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
            {
                ContractWire.SendEmpty(_session, request.Id);
                return;
             }

            bool wasOwner = string.Equals(lobby.LobbyOwnerId, playerId, StringComparison.Ordinal);
            lobby.TryRemoveMember(playerId);
            lobby.TryRemoveSpectator(playerId);

            BoltFriend[] remaining = lobby.LobbyMembers.Concat(lobby.LobbySpectators).ToArray();
            string newOwnerId = string.Empty;
            if (lobby.LobbyMembers.Length == 0)
            {
                DeleteLobby(lobby.Id);
            }
            else
            {
                 if (wasOwner)
                {
                    newOwnerId = lobby.LobbyMembers.First().Id;
                    lobby.LobbyOwnerId = newOwnerId;
                }
                PersistLobby(lobby);
            }

            ContractWire.SendEmpty(_session, request.Id);

            SendLobbyEventToPlayer(playerId, "onPlayerLeftLobby", playerId);

            foreach (BoltFriend recipient in remaining)
            {
                if (!string.IsNullOrWhiteSpace(newOwnerId))
                    SendLobbyEventToPlayer(recipient.Id, "onLobbyOwnerChanged", newOwnerId);
                SendLobbyEventToPlayer(recipient.Id, "onPlayerLeftLobby", playerId);
             }

        }

        private void EnsureMatchmakingEventSender()
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId)) return;
            ServerState.EnsureConnectionEventSender(
                playerId, _session.TcpClient, () => new MatchmakingEventSender(_session));
        }

        public override void Invoke(RpcRequest request)
        {
            EnsureMatchmakingEventSender();
            if (request.MethodName == "getLobbyGameServer2")
                GetLobbyGameServer(request);
            else if (request.MethodName == "getGameServerDetails2")
                GetGameServerDetails(request);
            else if (request.MethodName == "setLobbyName2")
                SetLobbyName(request);
            else if (request.MethodName == "setLobbyGameServer2")
                SetLobbyGameServer(request);
            else if (request.MethodName == "deleteLobbyData2")
                DeleteLobbyData(request);
            else if (request.MethodName == "invitePlayerToLobby2")
                InvitePlayerToLobbyV2(request);
            else if (request.MethodName == "getGameServerPlayers2")
                GetGameServerPlayers(request);
            else if (request.MethodName == "requestInternetServerList2")
                RequestInternetServerList(request);
            else if (request.MethodName == "changeLobbyPlayerType2")
                ChangeLobbyPlayerType(request);
            else if (request.MethodName == "joinLobby2")
                JoinLobbyV2(request);
            else if (request.MethodName == "requestLobbyList2")
                RequestLobbyList(request);
            else if (request.MethodName == "getLobbyMembers2")
                GetLobbyMembers(request);
            else if (request.MethodName == "getLobbyPhotonGame2")
                GetLobbyPhotonGame(request);
            else if (request.MethodName == "getLobbyOwner2")
                GetLobbyOwnerV2(request);
            else if (request.MethodName == "getInvitesToLobby2")
                GetInvitesToLobbyV2(request);
            else if (request.MethodName == "createLobbyWithSpectators2")
               CreateLobbyWithSpectatorsV2(request);
            else if (request.MethodName == "searchLobby")
                SearchLobby(request);
            else if (request.MethodName == "setLobbyData2")
               SetLobbyDataV2(request);
            else if (request.MethodName == "leaveLobby2")
                LeaveLobbyV2(request);
            else if (request.MethodName == "setLobbyJoinable2")
                SetLobbyJoinableV2(request);
            else if (request.MethodName == "setLobbyMaxMembers2")
                SetLobbyMaxMembersV2(request);
           else if (request.MethodName == "setLobbyMaxSpectators2")
                SetLobbyMaxSpectatorsV2(request);
            else if (request.MethodName == "setLobbyType2")
                SetLobbyTypeV2(request);
            else if (request.MethodName == "getLobby2")
                GetLobby(request);
            else if (request.MethodName == "invitePlayerToLobbyAs2")
                 InvitePlayerToLobbyAs(request);
           else if (request.MethodName == "sendLobbyChatMsg2")
                SendLobbyChatMsgV2(request);
            else if (request.MethodName == "joinLobbyAs2")
               JoinLobbyAsV2(request);
           else if (request.MethodName == "setLobbyPhotonGame2")
                SetLobbyPhotonGameV2(request);
            else if (request.MethodName == "kickPlayerFromLobby2")
                KickPlayerFromLobbyV2(request);
            else if (request.MethodName == "refuseInvitationToLobby2")
                RefuseInvitationToLobbyV2(request);
            else if (request.MethodName == "revokePlayerInvitationToLobby2")
                RevokePlayerInvitationToLobbyV2(request);
           else if (request.MethodName == "changeLobbyOtherPlayerType2")
                ChangeLobbyOtherPlayerType(request);
            else if (request.MethodName == "setLobbyOwner2")
                SetLobbyOwnerV2(request);
            else if (request.MethodName == "start")
                StartRanked(request);
            else if (request.MethodName == "confirm")
                ConfirmRanked(request);
            else if (request.MethodName == "cancel")
                CancelRanked(request);
            else if (request.MethodName == "getInvitesToLobby")
                GetInvitesToLobby(request.Id);

            else if (request.MethodName == "kickPlayerFromLobby")
                 KickPlayerFromLobby((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "setLobbyPhotonGame")
                SetLobbyPhotonGame((Axlebolt.Bolt.Protobuf2.PhotonGame)new RpcValueReader(typeof(Axlebolt.Bolt.Protobuf2.PhotonGame)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "revokePlayerInvitationToLobby")
                RevokePlayerInvitationToLobby((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "refuseInvitationToLobby")
               RefuseInvitationToLobby((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);

             else if (request.MethodName == "joinLobby")
               JoinLobby((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "joinLobbyAs")
                JoinLobbyAs((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Params[1], request.Id);

            else if (request.MethodName == "invitePlayerToLobbyAs" || request.MethodName == "invitePlayerToLobby")
            {
                 string invitedId = (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]);
                LobbyPlayerType type = request.Params.Count > 1
                     ? (LobbyPlayerType)new EnumValueReader(typeof(LobbyPlayerType)).FromBytes(request.Params[1])
                    : LobbyPlayerType.Member;
                InvitePlayerToLobby(invitedId, type, request.Id);
            }

            else if (request.MethodName == "leaveLobby")
                LeaveLobby(request.Id);

           else if (request.MethodName == "setLobbyJoinable")
                SetLobbyJoinable((bool)new RpcValueReader(typeof(bool)).FromBytes(request.Params[0]), request.Id);

           else if (request.MethodName == "setLobbyData")
                SetLobbyData((Dictionary)new RpcValueReader(typeof(Dictionary)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "createLobby")
                CreateLobby(
                    (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]),
                    (LobbyType)new EnumValueReader(typeof(LobbyType)).FromBytes(request.Params[1]),
                    (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[2]),
                    request.Id);

           else if (request.MethodName == "createLobbyWithSpectators")
                CreateLobbyWithSpectators(
                    (string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]),
                    (LobbyType)new EnumValueReader(typeof(LobbyType)).FromBytes(request.Params[1]),
                    (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[2]),
                    (int)new RpcValueReader(typeof(int)).FromBytes(request.Params[3]),
                    request.Id);

            else if (request.MethodName == "setLobbyMaxMembers")
                SetLobbyMaxMembers((int)new RpcValueReader(typeof(int)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "setLobbyMaxSpectators")
                SetLobbyMaxSpectators((int)new RpcValueReader(typeof(int)).FromBytes(request.Params[0]), request.Id);

            else if (request.MethodName == "setLobbyType")
                SetLobbyType(request.Params.ToArray(), request.Id);

            else if (request.MethodName == "sendLobbyChatMsg")
                SendLobbyChatMsg((string)new RpcValueReader(typeof(string)).FromBytes(request.Params[0]), request.Id);

            else
            {
                 _session.SendResponse(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = request.Id,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                             Code = 404
                        }
                    }
                });
            }
        }
     }

    public class MatchmakingEventSender : IEventSender
    {
        public ClientSession User { get; }
        public string eventListenerName { get; set; } = "MatchmakingRemoteEventListener";
        public MatchmakingEventSender(ClientSession user) { User = user; }

         public void SendValidRouteProbe(uint route, string kind, string eventName, object[] parameters, string targetPlayerId)
        {
            EventResponse envelope = BoltEventContract.Create(
                 eventListenerName, eventName, parameters ?? Array.Empty<object>());
            envelope.Route = route;
            User.SendResponse(new ResponseMessage { EventResponse = envelope });
            int payloadBytes = envelope.Params.Count > 0 && envelope.Params[0].One != null
                ? envelope.Params[0].One.Length
               : 0;
        }

        public void SendEvent(string eventName, object[] parameters)
        {
           object[] args = parameters ?? Array.Empty<object>();
            EventResponse envelope = BoltEventContract.Create(eventListenerName, eventName, args);

            if (envelope.Params.Count == 1 && envelope.Params[0].One.Length == 0 &&
                (string.Equals(eventName, "onLobbyJoinableChanged", StringComparison.OrdinalIgnoreCase) ||
                 string.Equals(eventName, "onLobbyTypeChanged", StringComparison.OrdinalIgnoreCase)))
             {
                 envelope.Params[0].One = ByteString.CopyFrom(new byte[] { 0x08, 0x00 });
            }

            User.SendResponse(new ResponseMessage { EventResponse = envelope });

        }
    }
}
