using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{
    internal static class StatTrackBridge
    {
        internal readonly record struct Result(bool Accepted, int Value, int Delivered, string Reason);

        internal readonly record struct Candidate(int ItemDefinitionId, int InventoryItemId, int Value);
        internal readonly record struct ResolveResult(Candidate[] Candidates, string Reason);

        public static int RepairOwnedInventoryForPlayer(string playerId)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId playerObjectId)) return 0;
            BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
            return RepairLegacyOwnership(provider, playerObjectId);
        }

        public static ResolveResult ResolveOwned(string playerId, IEnumerable<int> selectedDefinitionIds)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                return new ResolveResult(Array.Empty<Candidate>(), "bad-player-id");

            BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
            PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
            if (inventory?.InventoryItems == null)
                return new ResolveResult(Array.Empty<Candidate>(), "inventory-missing");

            HashSet<int> selected = selectedDefinitionIds?.Where(x => x > 0).ToHashSet() ?? new HashSet<int>();
            List<Candidate> allStatTrack = FindCandidates(provider, inventory);

            if (allStatTrack.Count == 0)
            {
                int repaired = RepairLegacyOwnership(provider, playerObjectId);
                 if (repaired > 0)
                {
                    inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    allStatTrack = FindCandidates(provider, inventory);
                }
             }

            bool MatchesSelected(Candidate candidate)
            {
                if (selected.Contains(candidate.ItemDefinitionId)) return true;
                if (candidate.ItemDefinitionId >= 1_000_000 && candidate.ItemDefinitionId < 2_000_000)
                 {
                    int baseId = candidate.ItemDefinitionId - 1_000_000;
                    if (selected.Contains(baseId)) return true;
                }
                else if (candidate.ItemDefinitionId > 0 && candidate.ItemDefinitionId < 1_000_000)
                {
                    int statTrackId = candidate.ItemDefinitionId + 1_000_000;
                    if (selected.Contains(statTrackId)) return true;
                }
                return false;
            }

            Candidate[] selectedMatches = selected.Count == 0
                ? Array.Empty<Candidate>()
                : allStatTrack.Where(MatchesSelected).OrderBy(x => x.InventoryItemId).ToArray();
            if (selectedMatches.Length > 0)
                return new ResolveResult(selectedMatches, selectedMatches.Length == 1 ? "selected-exact" : "selected-multiple");

             if (allStatTrack.Count == 1)
               return new ResolveResult(new[] { allStatTrack[0] }, "unique-owned");

            return new ResolveResult(Array.Empty<Candidate>(), allStatTrack.Count == 0 ? "no-stattrack-owned" : "ambiguous-owned");
        }

       public static Result GetCurrent(string playerId, int itemDefinitionId, int inventoryItemId)
        {
             if (!ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                return new Result(false, 0, 0, "bad-player-id");
            if (itemDefinitionId <= 0 || inventoryItemId <= 0)
                return new Result(false, 0, 0, "bad-arguments");

            BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
             PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
            string itemKey = inventoryItemId.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (inventory?.InventoryItems == null ||
                !inventory.InventoryItems.TryGetValue(itemKey, out BsonValue rawItem) || !rawItem.IsBsonDocument)
            {
                if (RepairLegacyOwnership(provider, playerObjectId, itemDefinitionId, inventoryItemId))
                {
                    inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    if (inventory?.InventoryItems == null ||
                        !inventory.InventoryItems.TryGetValue(itemKey, out rawItem) || !rawItem.IsBsonDocument)
                        return new Result(false, 0, 0, "item-not-owned-after-repair");
                }
                else
               {
                    return new Result(false, 0, 0, "item-not-owned");
                }
            }

            BsonDocument item = rawItem.AsBsonDocument;
            int actualDefinitionId = item.GetValue("itemDefinitionId", 0).ToInt32();
            if (actualDefinitionId != itemDefinitionId)
                return new Result(false, 0, 0, "definition-mismatch");
            if (!IsStatTrack(provider, item, actualDefinitionId))
                return new Result(false, 0, 0, "not-stattrack");

            int current = ReadValue(item);
            return new Result(true, current, 0, "ok");
        }

        public static Result ApplyAbsolute(string playerId, int itemDefinitionId, int inventoryItemId, int requested)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId playerObjectId))
               return new Result(false, 0, 0, "bad-player-id");
            if (itemDefinitionId <= 0 || inventoryItemId <= 0 || requested < 0)
                return new Result(false, 0, 0, "bad-arguments");

            BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
            PlayerInventoryDocument inventory = provider.GetPlayerInventoryDocument(playerObjectId);
            string itemKey = inventoryItemId.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (inventory?.InventoryItems == null ||
                !inventory.InventoryItems.TryGetValue(itemKey, out BsonValue rawItem) || !rawItem.IsBsonDocument)
            {
                if (RepairLegacyOwnership(provider, playerObjectId, itemDefinitionId, inventoryItemId))
                 {
                    inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                    if (inventory?.InventoryItems == null ||
                        !inventory.InventoryItems.TryGetValue(itemKey, out rawItem) || !rawItem.IsBsonDocument)
                        return new Result(false, 0, 0, "item-not-owned-after-repair");
                }
                else
                {
                    return new Result(false, 0, 0, "item-not-owned");
                }
            }
             BsonDocument item = rawItem.AsBsonDocument;
           int actualDefinitionId = item.GetValue("itemDefinitionId", 0).ToInt32();
            if (actualDefinitionId != itemDefinitionId)
                return new Result(false, 0, 0, "definition-mismatch");

             if (!IsStatTrack(provider, item, actualDefinitionId))
                return new Result(false, 0, 0, "not-stattrack");
            int current = ReadValue(item);
            int next = Math.Max(current, requested);

            IMongoCollection<BsonDocument> collection = provider.GetDatabase()
                .GetCollection<BsonDocument>(InventoryCatalog.PlayerInventoryCollection);
            FilterDefinition<BsonDocument> filter =
               Builders<BsonDocument>.Filter.Eq("playerId", playerObjectId.ToString()) &
                Builders<BsonDocument>.Filter.Eq($"InventoryItems.{itemKey}.itemDefinitionId", itemDefinitionId);
           UpdateDefinition<BsonDocument> update = Builders<BsonDocument>.Update
                 .Max($"InventoryItems.{itemKey}.properties.stattrack_value", next)
                .Unset($"InventoryItems.{itemKey}.properties.stattrack_property");
             UpdateResult updated = collection.UpdateOne(filter, update);
            if (updated.MatchedCount == 0)
                return new Result(false, current, 0, "ownership-race");

            PlayerInventoryDocument refreshed = provider.GetPlayerInventoryDocument(playerObjectId);
            if (!refreshed.InventoryItems.TryGetValue(itemKey, out BsonValue refreshedRaw) || !refreshedRaw.IsBsonDocument)
                return new Result(false, next, 0, "refresh-missing");
            InventoryItem changed = new BsonElement(itemKey, refreshedRaw.AsBsonDocument).ToInventory();
           int delivered = InventoryEventBus.InventoryChanged(playerId, changed: new[] { changed }, source: "stattrack-bridge");
            return new Result(true, next, delivered, next == current ? "idempotent" : "updated");
         }

        private static List<Candidate> FindCandidates(
            BoltGameDatabaseProvider provider,
            PlayerInventoryDocument inventory)
        {
            var result = new List<Candidate>();
            if (inventory?.InventoryItems == null) return result;

             foreach (BsonElement pair in inventory.InventoryItems)
            {
                 if (!int.TryParse(pair.Name, NumberStyles.Integer, CultureInfo.InvariantCulture, out int inventoryItemId) ||
                    inventoryItemId <= 0 || !pair.Value.IsBsonDocument)
                    continue;

                BsonDocument item = pair.Value.AsBsonDocument;
                int definitionId = ReadInt(item.GetValue("itemDefinitionId", 0));
                if (definitionId <= 0 || !IsStatTrack(provider, item, definitionId))
                    continue;

                result.Add(new Candidate(definitionId, inventoryItemId, ReadValue(item)));
            }

            return result;
        }

        private static int RepairLegacyOwnership(
           BoltGameDatabaseProvider provider,
            ObjectId playerObjectId)
        {
            try
            {
                IMongoDatabase db = provider.GetDatabase();
                FilterDefinition<BsonDocument> playerFilter =
                    Builders<BsonDocument>.Filter.Eq("playerId", playerObjectId.ToString());

                BsonDocument legacy = db.GetCollection<BsonDocument>("inventory")
                    .Find(playerFilter)
                    .FirstOrDefault();
                if (legacy == null ||
                    !legacy.TryGetValue("InventoryItems", out BsonValue legacyItemsValue) ||
                    !legacyItemsValue.IsBsonDocument)
                    return 0;

                PlayerInventoryDocument runtime = provider.GetPlayerInventoryDocument(playerObjectId);
                BsonDocument runtimeItems = runtime?.InventoryItems ?? new BsonDocument();
                var toCopy = new List<(string Key, BsonDocument Item)>();

                foreach (BsonElement e in legacyItemsValue.AsBsonDocument)
                {
                    if (!e.Value.IsBsonDocument) continue;
                    BsonDocument legacyItem = e.Value.AsBsonDocument;
                    int definitionId = ReadInt(legacyItem.GetValue("itemDefinitionId", 0));
                    if (definitionId <= 0 || !IsStatTrack(provider, legacyItem, definitionId))
                       continue;

                    if (runtimeItems.TryGetValue(e.Name, out BsonValue existingValue))
                    {
                        if (existingValue.IsBsonDocument &&
                            ReadInt(existingValue.AsBsonDocument.GetValue("itemDefinitionId", 0)) == definitionId)
                            continue;
                        continue;
                   }

                    BsonDocument copy = legacyItem.DeepClone().AsBsonDocument;
                    EnsureValueProperty(copy);
                    toCopy.Add((e.Name, copy));
                }

                if (toCopy.Count == 0) return 0;

                IMongoCollection<BsonDocument> target =
                    db.GetCollection<BsonDocument>(InventoryCatalog.PlayerInventoryCollection);
                var updates = new List<UpdateDefinition<BsonDocument>>();
                foreach (var entry in toCopy)
                    updates.Add(Builders<BsonDocument>.Update.Set($"InventoryItems.{entry.Key}", entry.Item));

                UpdateResult result = target.UpdateOne(
                    playerFilter,
                    Builders<BsonDocument>.Update.Combine(updates),
                    new UpdateOptions { IsUpsert = true });

                return result.MatchedCount > 0 || result.UpsertedId != null ? toCopy.Count : 0;
            }
            catch (System.Exception)
            {
                return 0;
            }
        }

        private static bool RepairLegacyOwnership(
            BoltGameDatabaseProvider provider,
            ObjectId playerObjectId,
            int itemDefinitionId,
           int inventoryItemId)
        {
            try
            {
                IMongoDatabase db = provider.GetDatabase();
                string itemKey = inventoryItemId.ToString(CultureInfo.InvariantCulture);
                FilterDefinition<BsonDocument> playerFilter =
                   Builders<BsonDocument>.Filter.Eq("playerId", playerObjectId.ToString());

                BsonDocument legacy = db.GetCollection<BsonDocument>("inventory")
                    .Find(playerFilter)
                   .FirstOrDefault();
                if (legacy == null ||
                     !legacy.TryGetValue("InventoryItems", out BsonValue itemsValue) ||
                   !itemsValue.IsBsonDocument ||
                    !itemsValue.AsBsonDocument.TryGetValue(itemKey, out BsonValue raw) ||
                    !raw.IsBsonDocument)
                   return false;

                BsonDocument item = raw.AsBsonDocument.DeepClone().AsBsonDocument;
                int actualDefinitionId = ReadInt(item.GetValue("itemDefinitionId", 0));
                if (actualDefinitionId != itemDefinitionId ||
                   !IsStatTrack(provider, item, actualDefinitionId))
                    return false;

                EnsureValueProperty(item);
                UpdateResult result = db.GetCollection<BsonDocument>(InventoryCatalog.PlayerInventoryCollection)
                    .UpdateOne(
                        playerFilter,
                        Builders<BsonDocument>.Update.Set($"InventoryItems.{itemKey}", item),
                        new UpdateOptions { IsUpsert = true });

                if (result.MatchedCount > 0 || result.UpsertedId != null)
               {
                    return true;
                }
            }
             catch (System.Exception)
            {
            }
            return false;
        }

        private static void EnsureValueProperty(BsonDocument item)
        {
            if (!item.TryGetValue("properties", out BsonValue propsValue) || !propsValue.IsBsonDocument)
            {
                item["properties"] = new BsonDocument("stattrack_value", 0);
                return;
            }

            BsonDocument props = propsValue.AsBsonDocument;
            int value = Math.Max(
                ReadInt(props.GetValue("stattrack_value", 0)),
                ReadInt(props.GetValue("stattrack_property", 0)));
            props["stattrack_value"] = value;
            props.Remove("stattrack_property");
        }

        private static bool IsStatTrack(BoltGameDatabaseProvider provider, BsonDocument item, int definitionId)
        {

            if (definitionId >= 1_000_000 && definitionId < 2_000_000)
                return true;
            if (item.TryGetValue("properties", out BsonValue propsValue) && propsValue.IsBsonDocument)
            {
                BsonDocument props = propsValue.AsBsonDocument;
                if (props.Contains("stattrack_value") || props.Contains("stattrack_property"))
                    return true;
             }
           try
            {
                BoltInventoryItemDefinitionDocument definition = provider.GetInventoryItemDefinition(definitionId, 1);
                if (definition == null)
                    return false;

                if (HasStatTrackFlag(definition))
                    return true;

                if (!string.IsNullOrWhiteSpace(definition.displayName) &&
                    definition.displayName.IndexOf("StatTrack", StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;

                if (definition.properties != null)
                {
                    foreach (string marker in new[] { "clientRuntimeClass", "runtimeClass", "clientEnumName", "catalogCode" })
                    {
                        if (definition.properties.TryGetValue(marker, out BsonValue markerValue) && markerValue != null &&
                            !markerValue.IsBsonNull && markerValue.ToString().IndexOf("StatTrack", StringComparison.OrdinalIgnoreCase) >= 0)
                            return true;
                    }
                }
            }
            catch
            {
            }
            return false;
        }

         private static bool HasStatTrackFlag(BoltInventoryItemDefinitionDocument definition)
        {
            if (definition?.properties == null ||
                !definition.properties.TryGetValue("stattrack", out BsonValue value) ||
                value == null ||
                value.IsBsonNull)
            {
                return false;
            }

            if (value.IsBoolean)
                return value.AsBoolean;
            if (value.IsInt32)
                return value.AsInt32 != 0;
            if (value.IsInt64)
                return value.AsInt64 != 0;
            if (value.IsDouble)
                return Math.Abs(value.AsDouble) > double.Epsilon;

            if (value.IsString)
            {
                string raw = value.AsString.Trim();
                if (bool.TryParse(raw, out bool flag))
                    return flag;
                if (long.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out long number))
                    return number != 0;
            }

            return false;
        }

        private static int ReadValue(BsonDocument item)
        {
            if (!item.TryGetValue("properties", out BsonValue propsValue) || !propsValue.IsBsonDocument) return 0;
            BsonDocument props = propsValue.AsBsonDocument;
             return Math.Max(ReadInt(props.GetValue("stattrack_value", 0)),
                ReadInt(props.GetValue("stattrack_property", 0)));
        }

        private static int ReadInt(BsonValue value)
        {
            try
            {
                if (value == null || value.IsBsonNull) return 0;
                if (value.IsInt32) return Math.Max(0, value.AsInt32);
                if (value.IsInt64) return (int)Math.Clamp(value.AsInt64, 0L, int.MaxValue);
                if (value.IsDouble) return (int)Math.Clamp(value.AsDouble, 0d, int.MaxValue);
                if (value.IsString && int.TryParse(value.AsString, out int parsed)) return Math.Max(0, parsed);
                return Math.Max(0, Convert.ToInt32(value.ToString(), System.Globalization.CultureInfo.InvariantCulture));
            }
            catch { return 0; }
        }
    }
}
