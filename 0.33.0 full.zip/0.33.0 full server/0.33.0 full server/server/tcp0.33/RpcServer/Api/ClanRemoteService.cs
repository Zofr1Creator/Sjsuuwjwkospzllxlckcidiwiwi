using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using SysException = System.Exception;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{

    public sealed class ClanRemoteService : RpcHandler
    {
        public ClanRemoteService(ClientSession user) : base(user) { }

        internal static class RoleIds
        {
            public const int Leader = 0;
            public const int CoLeader = 10;
            public const int Elder = 100;
            public const int Member = 1000;

            public static bool IsValid(int roleId) =>
                roleId == Leader || roleId == CoLeader || roleId == Elder || roleId == Member;

            public static bool IsHigher(int left, int right) => left < right;
            public static bool IsHigherOrEqual(int left, int right) => left <= right;
        }

        internal static class ExecutionStates
        {
            public const int None = 0;
            public const int Accepted = 1;
            public const int Rejected = 2;
            public const int Canceled = 3;
            public const int Read = 4;
        }

        internal static class ErrorCodes
        {
            public const int NotEnoughPermission = 2002;

            public const int ClanNotFound = 2008;
            public const int ClanMemberNotFound = 2009;

            public const int RequestToJoinAlreadySent = 2010;
            public const int PlayerAlreadyInClan = 2011;
            public const int ClanAlreadyFilled = 2013;

            public const int InvalidClanTag = 2016;
            public const int InvalidClanName = 2017;
            public const int ClanNameAlreadyExists = 2018;

            public const int ClanTagAlreadyExists = 2019;
            public const int InviteRequestAlreadySent = 2020;

            public const int ClanRestrictedWord = 2022;
            public const int ChangeClanLeaderNotAllowed = 2023;

            public const int NotClanMember = 2024;

            public const int NotEnoughFunds = 3303;

            public const int RequestNotFound = 3306;

            public const int InvalidRequest = 3311;
        }

        private const int CurrencyId = 102;

        private const int CreateClanCost = 500;
        private const int RenameClanCost = 100;
        private const int UpgradeMembersCost = 200;
        private const int InitialMembersCount = 10;

        private const int MembersLimit = 50;
        private const int MaxPageSize = 100;

        private const int MaxAvatarBytes = 512 * 1024;

        private static readonly ConcurrentDictionary<string, object> Locks =
            new ConcurrentDictionary<string, object>(StringComparer.Ordinal);

        private static readonly ConcurrentDictionary<string, long> SeenRequestActions =
            new ConcurrentDictionary<string, long>(StringComparer.Ordinal);
        private const long SeenRequestTtlMs = 10 * 60 * 1000;

        private static readonly object InitLock = new();
        private static bool _initialized;

        private IMongoDatabase Db => BoltGameDatabaseProvider.Instance.GetDatabase();
        private IMongoCollection<ClanDoc> Clans => Db.GetCollection<ClanDoc>("clans");
        private IMongoCollection<ClanMemberDoc> Members => Db.GetCollection<ClanMemberDoc>("clan_members");
        private IMongoCollection<JoinRequestDoc> JoinRequests => Db.GetCollection<JoinRequestDoc>("clan_join_requests");
        private IMongoCollection<InviteRequestDoc> InviteRequests => Db.GetCollection<InviteRequestDoc>("clan_invite_requests");
        private IMongoCollection<ClanLogDoc> Logs => Db.GetCollection<ClanLogDoc>("clan_messages");

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }

        public override void Invoke(RpcRequest request)
        {
            try
            {
                EnsureInitialized();
                EnsureClanEvents();

                BinaryValue[] args = request.Params?.ToArray() ?? Array.Empty<BinaryValue>();

                switch (request.MethodName)
                {
                    case "getClan2": GetClanV2(request.Id); return;
                    case "getRecommendedClans2": GetRecommendedClansV2(request); return;
                    case "getClanById2": GetClanByIdV2(request); return;
                    case "getPlayerInviteRequests2": GetPlayerInviteRequestsV2(request); return;
                    case "getPlayerJoinRequests2": GetPlayerJoinRequestsV2(request); return;
                    case "getClanInviteRequests2": GetClanInviteRequestsV2(request); return;
                    case "getClanJoinRequests2": GetClanJoinRequestsV2(request); return;
                    case "getPlayerInviteRequestsCount2": GetPlayerInviteRequestsCountV2(request.Id); return;
                    case "getPlayerClosedJoinRequestsCount2": GetPlayerClosedJoinRequestsCountV2(request.Id); return;
                    case "getClanJoinRequestsCount2": GetClanJoinRequestsCountV2(request.Id); return;
                    case "getClanClosedInviteRequestsCount2": GetClanClosedInviteRequestsCountV2(request.Id); return;
                    case "getRoles2": GetRolesV2(request.Id); return;
                    case "getRoles": GetRoles(request.Id); return;
                    case "getClanSettings2": GetClanSettingsV2(request.Id); return;
                    case "getClanSettings":
                    case "GetClanSettings": GetClanSettings(request.Id); return;

                    case "validateClanTag2": ValidateClanTagV2(request); return;
                    case "validateClanName2": ValidateClanNameV2(request); return;
                    case "validateClanTag": ValidateClanTag(args, request.Id); return;
                    case "validateClanName": ValidateClanName(args, request.Id); return;

                    case "createClan2": CreateClanV2(request); return;
                    case "createClan": CreateClan(args, request.Id); return;
                    case "getClan": GetClan(request.Id); return;
                    case "getClanByTag": GetClanByTag(request); return;
                    case "getClanById": GetClanById(args, request.Id); return;
                    case "getRecommendedClans": GetRecommendedClans(args, request.Id); return;
                    case "findClan2": FindClanV2(request); return;
                    case "findClan": FindClan(args, request.Id); return;

                    case "getClanMembers2":
                    case "getClanMembers": GetClanMembers(request.Id); return;
                    case "getClanMembersByClanId":
                    case "getClanMembersById": GetClanMembersByClanId(args, request.Id); return;
                    case "getClanMembersById2": GetClanMembersByClanIdV2(request); return;

                    case "getPlayerJoinRequests": GetPlayerJoinRequests(args, request.Id); return;
                    case "getPlayerInviteRequests": GetPlayerInviteRequests(args, request.Id); return;
                    case "getClanJoinRequests": GetClanJoinRequests(args, request.Id); return;
                    case "getClanInviteRequests": GetClanInviteRequests(args, request.Id); return;

                    case "getPlayerInviteRequestsCount": GetPlayerInviteRequestsCount(request.Id); return;
                    case "getPlayerClosedJoinRequestsCount": GetPlayerClosedJoinRequestsCount(request.Id); return;
                    case "getPlayerUnreadJoinRequestsCount": GetPlayerClosedJoinRequestsCount(request.Id); return;
                    case "getClanJoinRequestsCount": GetClanJoinRequestsCount(request.Id); return;
                    case "getClanUnreadInviteRequestsCount": GetClanUnreadInviteRequestsCount(request.Id); return;
                    case "getClanClosedInviteRequestsCount": GetClanClosedInviteRequestsCount(request.Id); return;
                    case "getClanInviteRequestsCount": GetClanInviteRequestsCount(request.Id); return;

                    case "requestToJoinClan2": RequestToJoinClanV2(request); return;
                    case "requestToJoinClan": RequestToJoinClan(args, request.Id); return;
                    case "inviteToClan2": InviteToClanV2(request); return;
                    case "inviteToClan": InviteToClan(args, request.Id); return;
                    case "cancelJoinRequest2": CancelJoinRequestV2(request); return;
                    case "cancelJoinRequest": CancelJoinRequest(args, request.Id); return;
                    case "cancelInviteRequest2": CancelInviteRequestV2(request); return;
                    case "cancelInviteRequest": CancelInviteRequest(args, request.Id); return;
                    case "declineJoinRequest2": DeclineJoinRequestV2(request); return;
                    case "declineJoinRequest": DeclineJoinRequest(args, request.Id); return;
                    case "declineInviteRequest2": DeclineInviteRequestV2(request); return;
                    case "declineInviteRequest": DeclineInviteRequest(args, request.Id); return;
                    case "deleteClosedJoinRequest2": DeleteClosedJoinRequestV2(request); return;
                    case "deleteClosedJoinRequest": DeleteClosedJoinRequest(args, request.Id); return;
                    case "deleteClosedInviteRequest2": DeleteClosedInviteRequestV2(request); return;
                    case "deleteClosedInviteRequest": DeleteClosedInviteRequest(args, request.Id); return;
                    case "leaveClan2": LeaveClanV2(request); return;
                    case "leaveClan": LeaveClan(request.Id); return;
                    case "kickMember2": KickMemberV2(request); return;
                    case "kickMember": KickMember(args, request.Id); return;
                    case "assignRoleToMember2": AssignRoleToMemberV2(request); return;
                    case "assignRoleToMember": AssignRoleToMember(args, request.Id); return;
                    case "assignLeaderRole2": AssignLeaderRoleV2(request); return;
                    case "assignLeaderRole": AssignLeaderRole(args, request.Id); return;
                    case "renameClan2": RenameClanV2(request); return;
                    case "renameClan": RenameClan(args, request.Id); return;
                    case "changeClanType2": ChangeClanTypeV2(request); return;
                    case "changeClanType": ChangeClanType(args, request.Id); return;
                    case "setClanAvatar2": SetClanAvatarV2(request); return;
                    case "setClanAvatar": SetClanAvatar(args, request.Id); return;
                    case "setClanDescription2": SetClanDescriptionV2(request); return;
                    case "setClanDescription": SetClanDescription(args, request.Id); return;
                    case "increaseMaxMembersCount2": IncreaseMaxMembersCountV2(request); return;
                    case "increaseMaxMembersCount": IncreaseMaxMembersCount(args, request.Id); return;
                    default:
                     SendException(request.Id, 404);
                    return;
                }
            }
            catch (ClanLogicException ex)
            {
                SendException(request.Id, ex.Code);
            }
            catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
                int code = MapDuplicateError(ex);
                SendException(request.Id, code);
            }
            catch (SysException)
            {
                SendException(request.Id, 500);
            }
        }

        private void EnsureInitialized()
        {
            if (_initialized) return;

            lock (InitLock)
            {
                if (_initialized) return;

                MigrateLegacyRoles();
                MigrateLegacyRequests();
                DedupeRelations();
                FixClanCounts();
                FixClanLeaders();

                CreateIndex(Clans, new CreateIndexModel<ClanDoc>(
                    Builders<ClanDoc>.IndexKeys.Ascending(x => x.TagLower),
                    new CreateIndexOptions { Unique = true, Name = "uniq_clan_tag_lower" }));
                CreateIndex(Clans, new CreateIndexModel<ClanDoc>(
                    Builders<ClanDoc>.IndexKeys.Ascending(x => x.NameLower),
                    new CreateIndexOptions { Name = "idx_clan_name_lower" }));
                CreateIndex(Members, new CreateIndexModel<ClanMemberDoc>(
                    Builders<ClanMemberDoc>.IndexKeys.Ascending(x => x.PlayerId),
                    new CreateIndexOptions { Unique = true, Name = "uniq_player_clan_membership" }));
                CreateIndex(Members, new CreateIndexModel<ClanMemberDoc>(
                    Builders<ClanMemberDoc>.IndexKeys.Ascending(x => x.ClanId).Ascending(x => x.PlayerId),
                    new CreateIndexOptions { Unique = true, Name = "uniq_clan_member_pair" }));
                CreateIndex(JoinRequests, new CreateIndexModel<JoinRequestDoc>(
                    Builders<JoinRequestDoc>.IndexKeys.Ascending(x => x.ClanId).Ascending(x => x.PlayerId),
                    new CreateIndexOptions { Unique = true, Name = "uniq_clan_join_pair" }));
                CreateIndex(InviteRequests, new CreateIndexModel<InviteRequestDoc>(
                    Builders<InviteRequestDoc>.IndexKeys.Ascending(x => x.ClanId).Ascending(x => x.InvitedPlayerId),
                    new CreateIndexOptions { Unique = true, Name = "uniq_clan_invite_pair" }));
                CreateIndex(Logs, new CreateIndexModel<ClanLogDoc>(
                    Builders<ClanLogDoc>.IndexKeys.Ascending(x => x.ClanId).Descending(x => x.Timestamp),
                    new CreateIndexOptions { Name = "idx_clan_log_time" }));

                _initialized = true;
            }
        }

        private static void CreateIndex<T>(IMongoCollection<T> collection, CreateIndexModel<T> model)
        {
            try { collection.Indexes.CreateOne(model); }
            catch { }
        }

        private static int MapDuplicateError(MongoWriteException ex)
        {
            string message = ((ex?.WriteError?.Message ?? string.Empty) + " " +
                              (ex?.Message ?? string.Empty)).ToLowerInvariant();

            if (message.Contains("uniq_clan_tag_lower"))
                return ErrorCodes.ClanTagAlreadyExists;
            if (message.Contains("uniq_player_clan_membership") || message.Contains("uniq_clan_member_pair"))
                return ErrorCodes.PlayerAlreadyInClan;
            if (message.Contains("uniq_clan_join_pair"))
                return ErrorCodes.RequestToJoinAlreadySent;
            if (message.Contains("uniq_clan_invite_pair"))
                return ErrorCodes.InviteRequestAlreadySent;

            return ErrorCodes.InvalidRequest;
        }

        private void MigrateLegacyRoles()
        {
            Members.UpdateMany(x => x.RoleId == 1,
                Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Member));
            Members.UpdateMany(x => x.RoleId == 2,
                Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Elder));
            Members.UpdateMany(x => x.RoleId == 3,
                Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
        }

        private void MigrateLegacyRequests()
        {
            foreach (JoinRequestDoc doc in JoinRequests.Find(Builders<JoinRequestDoc>.Filter.Empty).ToList())
            {
                bool isOpen = doc.CloseDate <= 0;
                int execution = isOpen
                    ? ExecutionStates.None
                    : OldExecutionState(doc.RequestType);

                JoinRequests.UpdateOne(x => x._id == doc._id,
                    Builders<JoinRequestDoc>.Update
                        .Set(x => x.RequestType, isOpen ? (int)RequestType.OpenRequest : (int)RequestType.ClosedRequest)
                        .Set(x => x.ExecutionState, doc.ExecutionState == 0 ? execution : doc.ExecutionState)
                        .Set(x => x.IsRead, doc.IsRead || execution == ExecutionStates.Read));
            }

            foreach (InviteRequestDoc doc in InviteRequests.Find(Builders<InviteRequestDoc>.Filter.Empty).ToList())
            {
                bool isOpen = doc.CloseDate <= 0;
                int execution = isOpen
                    ? ExecutionStates.None
                    : OldExecutionState(doc.RequestType);

                InviteRequests.UpdateOne(x => x._id == doc._id,
                    Builders<InviteRequestDoc>.Update
                        .Set(x => x.RequestType, isOpen ? (int)RequestType.OpenRequest : (int)RequestType.ClosedRequest)
                        .Set(x => x.ExecutionState, doc.ExecutionState == 0 ? execution : doc.ExecutionState)
                        .Set(x => x.IsRead, doc.IsRead || execution == ExecutionStates.Read));
            }
        }

        private static int OldExecutionState(int oldValue)
        {
            switch (oldValue)
            {
                case 1: return ExecutionStates.Accepted;
                case 2: return ExecutionStates.Rejected;
                case 3: return ExecutionStates.Canceled;
                case 4: return ExecutionStates.Read;
                default: return ExecutionStates.Rejected;
            }
        }

        private void DedupeRelations()
        {
            foreach (var group in Members.Find(Builders<ClanMemberDoc>.Filter.Empty).ToList()
                         .Where(x => !string.IsNullOrWhiteSpace(x.PlayerId))
                         .GroupBy(x => x.PlayerId, StringComparer.Ordinal)
                         .Where(x => x.Count() > 1))
            {
                ClanMemberDoc keep = group.OrderBy(x => x.RoleId).ThenBy(x => x.CreateDate).First();
                ObjectId[] remove = group.Where(x => x._id != keep._id).Select(x => x._id).ToArray();
                Members.DeleteMany(Builders<ClanMemberDoc>.Filter.In(x => x._id, remove));
            }

            foreach (var group in JoinRequests.Find(Builders<JoinRequestDoc>.Filter.Empty).ToList()
                         .GroupBy(x => (x.ClanId ?? string.Empty) + "\n" + (x.PlayerId ?? string.Empty), StringComparer.Ordinal)
                         .Where(x => x.Count() > 1))
            {
                JoinRequestDoc keep = group.OrderByDescending(x => x.CreateDate).First();
                ObjectId[] remove = group.Where(x => x._id != keep._id).Select(x => x._id).ToArray();
                JoinRequests.DeleteMany(Builders<JoinRequestDoc>.Filter.In(x => x._id, remove));
            }

            foreach (var group in InviteRequests.Find(Builders<InviteRequestDoc>.Filter.Empty).ToList()
                         .GroupBy(x => (x.ClanId ?? string.Empty) + "\n" + (x.InvitedPlayerId ?? string.Empty), StringComparer.Ordinal)
                         .Where(x => x.Count() > 1))
            {
                InviteRequestDoc keep = group.OrderByDescending(x => x.CreateDate).First();
                ObjectId[] remove = group.Where(x => x._id != keep._id).Select(x => x._id).ToArray();
                InviteRequests.DeleteMany(Builders<InviteRequestDoc>.Filter.In(x => x._id, remove));
            }
        }

        private void FixClanLeaders()
        {
            foreach (ClanDoc clan in Clans.Find(Builders<ClanDoc>.Filter.Empty).ToList())
            {
                List<ClanMemberDoc> clanMembers = Members.Find(x => x.ClanId == clan.Id)
                    .SortBy(x => x.CreateDate).ToList();
                if (clanMembers.Count == 0) continue;

                List<ClanMemberDoc> leaders = clanMembers.Where(x => x.RoleId == RoleIds.Leader).ToList();
                if (leaders.Count == 0)
                {
                    ClanMemberDoc promote = clanMembers.OrderBy(x => x.RoleId).ThenBy(x => x.CreateDate).First();
                    Members.UpdateOne(x => x._id == promote._id,
                        Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
                }
                else if (leaders.Count > 1)
                {
                    ClanMemberDoc keep = leaders.OrderBy(x => x.CreateDate).First();
                    foreach (ClanMemberDoc extra in leaders.Where(x => x._id != keep._id))
                    {
                        Members.UpdateOne(x => x._id == extra._id,
                            Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.CoLeader));
                    }
                }
            }
        }

        private void FixClanCounts()
        {
            foreach (ClanDoc clan in Clans.Find(Builders<ClanDoc>.Filter.Empty).ToList())
            {
                string stableId = string.IsNullOrWhiteSpace(clan.Id) ? clan._id.ToString() : clan.Id;
                int count = (int)Members.CountDocuments(x => x.ClanId == stableId);
                int max = clan.MaxMemberCount <= 0 ? InitialMembersCount : clan.MaxMemberCount;
                long created = clan.CreateDate > 0 ? clan.CreateDate : clan.CreatedAt;
                Clans.UpdateOne(x => x._id == clan._id,
                    Builders<ClanDoc>.Update
                        .Set(x => x.Id, stableId)
                        .Set(x => x.MembersCount, count)
                        .Set(x => x.MaxMemberCount, max)
                        .Set(x => x.CreateDate, created > 0 ? created : NowMs())
                        .Set(x => x.Name, clan.Name ?? string.Empty)
                        .Set(x => x.Tag, clan.Tag ?? string.Empty)
                        .Set(x => x.AvatarId, clan.AvatarId ?? string.Empty)
                        .Set(x => x.Description, clan.Description ?? string.Empty)
                        .Set(x => x.NameLower, Normalize(clan.Name))
                        .Set(x => x.TagLower, Normalize(clan.Tag)));
            }
        }

        private void GetRolesV2(string id)
        {
            ClanMemberRole[] roles = BuildRoles();
            byte[] response = ContractWire.WrapRepeated(1, roles);
            ContractWire.SendRaw(_session, id, response);
        }

        private void GetRoles(string id)
        {
            Send(id, BuildRoles());
        }

        internal static ClanMemberRole[] BuildRoles()
        {
            return new[]
            {
                BuildRole(RoleIds.Leader, "Leader", 4, "Clan leader",
                    System.Enum.GetValues(typeof(ClanMemberRolePermission)).Cast<ClanMemberRolePermission>().ToArray()),
                BuildRole(RoleIds.CoLeader, "Co-Leader", 3, "Clan co-leader",
                    ClanMemberRolePermission.ChangeClanSettings,
                    ClanMemberRolePermission.AcceptMember,
                    ClanMemberRolePermission.InviteMember,
                    ClanMemberRolePermission.KickMemberLess,
                    ClanMemberRolePermission.AssignRoleLess,
                    ClanMemberRolePermission.CreateClanBattle,
                    ClanMemberRolePermission.JoinClanBattle,
                    ClanMemberRolePermission.UpgradeClanMembersCount),
                BuildRole(RoleIds.Elder, "Elder", 2, "Clan elder",
                    ClanMemberRolePermission.AcceptMember,
                    ClanMemberRolePermission.InviteMember,
                    ClanMemberRolePermission.KickMemberLess,
                    ClanMemberRolePermission.JoinClanBattle),
                BuildRole(RoleIds.Member, "Member", 1, "Clan member",
                    ClanMemberRolePermission.JoinClanBattle)
            };
        }

        private static ClanMemberRole BuildRole(int id, string name, int level, string description,
            params ClanMemberRolePermission[] permissions)
        {
            var role = new ClanMemberRole
            {
                Id = id,
                Name = name,
                Level = level,
                Descripption = description
            };
            role.Permissions.AddRange(permissions ?? Array.Empty<ClanMemberRolePermission>());
            return role;
        }

        private void GetClanSettingsV2(string id)
        {
            var settings = GetSettings();
            byte[] response = ContractWire.Build(w => w.Message(1, settings));
            ContractWire.SendRaw(_session, id, response);
        }

        private ClanSettings GetSettings()
        {
            return new ClanSettings
            {
                InitialMembersCount = InitialMembersCount,
                MembersCountLimit = MembersLimit,
                MembersCountUpgradeCost = Money(UpgradeMembersCost),
                ChangeClanNameOrTagCost = Money(RenameClanCost),
                ClanCreateCost = Money(CreateClanCost)
            };
        }

        private void GetClanSettings(string id)
        {
            var settings = GetSettings();

            Send(id, settings);
        }

        private static CurrencyAmount Money(float value)
        {
            return new CurrencyAmount { CurrencyId = CurrencyId, OldValue = 0, Value = value };
        }

        private void ValidateClanTag(BinaryValue[] args, string id)
        {
            string tag = ReadTag(Read<string>(args, 0));
            if (Clans.Find(x => x.TagLower == Normalize(tag)).Any())
                throw new ClanLogicException(ErrorCodes.ClanTagAlreadyExists, "clan tag already exists");
            SendOk(id);
        }

        private void ValidateClanName(BinaryValue[] args, string id)
        {
            string name = ReadName(Read<string>(args, 0));
            if (Clans.Find(x => x.NameLower == Normalize(name)).Any())
                throw new ClanLogicException(ErrorCodes.ClanNameAlreadyExists, "clan name already exists");
            SendOk(id);
        }

        private void ValidateClanTagV2(RpcRequest request)
        {
            string tag = ReadTag(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty));
            if (Clans.Find(x => x.TagLower == Normalize(tag)).Any())
                throw new ClanLogicException(ErrorCodes.ClanTagAlreadyExists, "clan tag already exists");
            ContractWire.SendEmpty(_session, request.Id);
        }

        private void ValidateClanNameV2(RpcRequest request)
        {
            string name = ReadName(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty));
            if (Clans.Find(x => x.NameLower == Normalize(name)).Any())
                throw new ClanLogicException(ErrorCodes.ClanNameAlreadyExists, "clan name already exists");
            ContractWire.SendEmpty(_session, request.Id);
        }

        private static string ReadTag(string value)
        {
            string tag = (value ?? string.Empty).Trim();
            if (tag.Length < 2 || tag.Length > 16)
                throw new ClanLogicException(ErrorCodes.InvalidClanTag, "bad clan tag length");
            if (!Regex.IsMatch(tag, @"^[\p{L}\p{N}_-]+$"))
                throw new ClanLogicException(ErrorCodes.InvalidClanTag, "bad clan tag characters");
            return tag;
        }

        private static string ReadName(string value)
        {
            string name = Regex.Replace((value ?? string.Empty).Trim(), @"\s+", " ");
            if (name.Length < 2 || name.Length > 64)
                throw new ClanLogicException(ErrorCodes.InvalidClanName, "bad clan name length");
            if (name.Any(char.IsControl))
                throw new ClanLogicException(ErrorCodes.InvalidClanName, "bad clan name characters");
            return name;
        }

        private void CreateClan(BinaryValue[] args, string id)
        {
            string tag = ReadTag(Read<string>(args, 0));
            string name = ReadName(Read<string>(args, 1));
            ClanType type = ReadEnum<ClanType>(args, 2, ClanType.Closed);
            CreateClanCore(tag, name, type, id, false);
        }

        private void CreateClanV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            string tag = ReadTag(ContractWire.ReadStringField(raw, 1, string.Empty));
            string name = ReadName(ContractWire.ReadStringField(raw, 2, string.Empty));
            int typeValue = ContractWire.ReadIntField(raw, 3, (int)ClanType.Closed);
            ClanType type = System.Enum.IsDefined(typeof(ClanType), typeValue) ? (ClanType)typeValue : ClanType.Closed;
            CreateClanCore(tag, name, type, request.Id, true);
        }

        private void CreateClanCore(string tag, string name, ClanType type, string id, bool responseV2)
        {
            string myId = GetPlayerId();

            lock (GetLock("clan-name-registry"))
            {
                if (FindMembership(myId) != null)
                    throw new ClanLogicException(ErrorCodes.PlayerAlreadyInClan, "player already in clan");
                if (Clans.Find(x => x.TagLower == Normalize(tag)).Any())
                    throw new ClanLogicException(ErrorCodes.ClanTagAlreadyExists, "clan tag already exists");
                if (Clans.Find(x => x.NameLower == Normalize(name)).Any())
                    throw new ClanLogicException(ErrorCodes.ClanNameAlreadyExists, "clan name already exists");

                long now = NowMs();
                ObjectId clanObjectId = ObjectId.GenerateNewId();
                var clan = new ClanDoc
                {
                    _id = clanObjectId,
                    Id = clanObjectId.ToString(),
                    Name = name,
                    Tag = tag,
                    NameLower = Normalize(name),
                    TagLower = Normalize(tag),
                    ClanType = (int)type,
                    AvatarId = string.Empty,
                    Description = string.Empty,
                    CreateDate = now,
                    CreatedAt = now,
                    MembersCount = 1,
                    MaxMemberCount = InitialMembersCount
                };

                var leader = new ClanMemberDoc
                {
                    _id = ObjectId.GenerateNewId(),
                    ClanId = clan.Id,
                    PlayerId = myId,
                    RoleId = RoleIds.Leader,
                    CreateDate = now
                };

                bool clanInserted = false;
                bool memberInserted = false;
                bool charged = false;
                try
                {
                    Clans.InsertOne(clan);
                    clanInserted = true;
                    Members.InsertOne(leader);
                    memberInserted = true;

                    ChargeCurrency(myId, CreateClanCost);
                    charged = true;
                }
                catch
                {
                    if (charged) RefundCurrency(myId, CreateClanCost);
                    if (memberInserted) Members.DeleteOne(x => x._id == leader._id);
                    if (clanInserted) Clans.DeleteOne(x => x.Id == clan.Id);
                    throw;
                }

                try { CloseRequestsAfterJoin(myId, null, null, myId); }
                catch { }

                Clan protoClan = ToProto(clan);
                if (responseV2)
                    ContractWire.SendRaw(_session, id, ContractWire.Build(w => w.Message(1, protoClan)));
                else
                    Send(id, protoClan);
            }
        }

        private void GetClanV2(string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc membership = FindMembership(myId);
            Clan clan = membership == null ? null : ToProto(FindClan(membership.ClanId));
            byte[] response = ContractWire.Build(w => w.Message(1, clan));
            ContractWire.SendRaw(_session, id, response);
        }

        private void GetRecommendedClansV2(RpcRequest request)
        {
            int count = Clamp(ContractWire.ReadIntField(ContractWire.Param(request), 1, 20), 1, MaxPageSize);
            Clan[] result = Clans.Find(Builders<ClanDoc>.Filter.Empty)
                .SortByDescending(x => x.MembersCount)
                .ThenByDescending(x => x.CreateDate)
                .ToList()
                .Where(x => x.MembersCount < (x.MaxMemberCount > 0 ? x.MaxMemberCount : InitialMembersCount))
                .Take(count)
                .Select(ToProto)
                .Where(x => x != null)
                .ToArray();
            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetClanByIdV2(RpcRequest request)
        {
            string clanId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            Clan clan = string.IsNullOrWhiteSpace(clanId) ? null : ToProto(FindClan(clanId));
            byte[] response = ContractWire.Build(w => w.Message(1, clan));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetClanInviteRequestsV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            byte[] raw = ContractWire.Param(request);
            int offset = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
            int length = Clamp(ContractWire.ReadIntField(raw, 2, 20), 1, MaxPageSize);
            ClanInviteRequest[] result = InviteRequests.Find(x => x.ClanId == clanId &&
        x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate).Skip(offset).Limit(length).ToList()
                .Select(x => ToProto(x, myId)).Where(x => x != null).ToArray();

            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetClanJoinRequestsV2(RpcRequest request)
        {
           string myId = GetPlayerId();
             string clanId = GetClanId(myId);
        
            byte[] raw = ContractWire.Param(request);
            int offset = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
            int length = Clamp(ContractWire.ReadIntField(raw, 2, 20), 1, MaxPageSize);

            List<JoinRequestDoc> docs = JoinRequests.Find(x => x.ClanId == clanId &&
                                                               x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate)
                .Skip(offset)
                .Limit(length)
                .ToList();

            var mapped = new List<ClanJoinRequest>(docs.Count);
            foreach (JoinRequestDoc doc in docs)
            {
                ClanJoinRequest proto = ToProtoJoinRequest(doc, myId, "clan-in");
                if (proto != null)
                    mapped.Add(proto);
            }

            ClanJoinRequest[] result = mapped.ToArray();
            foreach (ClanJoinRequest item in result)
                MarkRequestSeen(myId, "clan-join", item?.Id);
            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

       
        private ClanJoinRequest ToProtoJoinRequest(JoinRequestDoc doc, string viewerId, string direction)
        {




            if (doc == null || string.IsNullOrWhiteSpace(doc.RequestId) ||
                string.IsNullOrWhiteSpace(doc.ClanId) || string.IsNullOrWhiteSpace(doc.PlayerId))
                return null;

            ClanDoc clanDoc = FindClan(doc.ClanId);
            if (clanDoc == null)
            {
                return null;
            }
 Player sender = NormalizeRequestPlayer(BuildPlayer(doc.PlayerId), doc.PlayerId);
            if (sender == null || string.IsNullOrWhiteSpace(sender.Id))
            {
                return null;
            }

          Clan clan = ToProto(clanDoc);
            if (clan == null || string.IsNullOrWhiteSpace(clan.Id))
                return null;

            long createDate = doc.CreateDate;
            if (createDate <= 0 && doc._id != ObjectId.Empty)
                createDate = new DateTimeOffset(doc._id.CreationTime.ToUniversalTime()).ToUnixTimeMilliseconds();
            if (createDate <= 0) createDate = NowMs();

            RequestType requestType = doc.RequestType == (int)RequestType.ClosedRequest
                ? RequestType.ClosedRequest
                : RequestType.OpenRequest;
            long closeDate = requestType == RequestType.OpenRequest ? 0L : Math.Max(0L, doc.CloseDate);

            var proto = new ClanJoinRequest
            {
                Id = doc.RequestId.Trim(),
                Clan = clan,
                RequestSender = sender,
                CreateDate = createDate,
                CloseDate = closeDate,
                RequestType = requestType
            };

            try
            {
                byte[] wire = proto.ToByteArray();
                ClanJoinRequest parsed = ClanJoinRequest.Parser.ParseFrom(wire);
                return parsed;
            }
            catch (System.Exception)
            {
                return null;
            }
        }

        private void GetPlayerInviteRequestsV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            byte[] raw = ContractWire.Param(request);
            int offset = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
            int length = Clamp(ContractWire.ReadIntField(raw, 2, 20), 1, MaxPageSize);
            ClanInviteRequest[] result = InviteRequests.Find(x => x.InvitedPlayerId == myId &&
                                                                  x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate)
                .Skip(offset)
                .Limit(length)
                .ToList()
                .Select(x => ToProto(x, myId))
                .Where(x => x != null)
                .ToArray();
            foreach (ClanInviteRequest item in result)
                MarkRequestSeen(myId, "player-invite", item?.Id);
            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerJoinRequestsV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            byte[] raw = ContractWire.Param(request);
            int offset = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
            int length = Clamp(ContractWire.ReadIntField(raw, 2, 20), 1, MaxPageSize);
            List<JoinRequestDoc> docs = JoinRequests.Find(x => x.PlayerId == myId &&
                                                               x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate)
                .Skip(offset)
                .Limit(length)
                .ToList();
            ClanJoinRequest[] result = docs
                .Select(x => ToProtoJoinRequest(x, myId, "player-out"))
                .Where(x => x != null)
                .ToArray();
            foreach (ClanJoinRequest item in result)
                MarkRequestSeen(myId, "player-join", item?.Id);
            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerInviteRequestsCountV2(string id)
        {
            string myId = GetPlayerId();
            int count = (int)InviteRequests.CountDocuments(x => x.InvitedPlayerId == myId &&
                x.RequestType == (int)RequestType.OpenRequest);
            byte[] response = ContractWire.Build(w => w.Int32(1, count));
            ContractWire.SendRaw(_session, id, response);
        }

        private void GetPlayerClosedJoinRequestsCountV2(string id)
        {
            string myId = GetPlayerId();
            int count = (int)JoinRequests.CountDocuments(x => x.PlayerId == myId &&
                x.RequestType == (int)RequestType.ClosedRequest && !x.IsRead);
            byte[] response = ContractWire.Build(w => w.Int32(1, count));
            ContractWire.SendRaw(_session, id, response);
        }

        private void GetClan(string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc membership = FindMembership(myId);
            Send(id, membership == null ? null : ToProto(FindClan(membership.ClanId)));
        }

        private void GetClanById(BinaryValue[] args, string id)
        {
            string clanId = Read<string>(args, 0);
            Send(id, ToProto(FindClan(clanId)));
        }

        private void GetRecommendedClans(BinaryValue[] args, string id)
        {
            int count = Clamp(Read<int>(args, 0, 20), 1, MaxPageSize);
            Clan[] result = Clans.Find(Builders<ClanDoc>.Filter.Empty)
                .SortByDescending(x => x.MembersCount)
                .ThenByDescending(x => x.CreateDate)
                .ToList()
                .Where(x => x.MembersCount < (x.MaxMemberCount > 0 ? x.MaxMemberCount : InitialMembersCount))
                .Take(count)
                .Select(ToProto)
                .ToArray();
            Send(id, result);
        }

        private void GetClanByTag(RpcRequest request)
        {
            string tag = Normalize(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty));
            ClanDoc doc = string.IsNullOrWhiteSpace(tag) ? null : Clans.Find(x => x.TagLower == tag).FirstOrDefault();
            Clan clan = ToProto(doc);
            byte[] response = ContractWire.Build(w => w.Message(1, clan));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void FindClanV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            string filter = Normalize(ContractWire.ReadStringField(raw, 1, string.Empty));
            int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int size = Clamp(ContractWire.ReadIntField(raw, 3, 20), 1, MaxPageSize);
            FilterDefinition<ClanDoc> mongoFilter = Builders<ClanDoc>.Filter.Empty;
            if (!string.IsNullOrWhiteSpace(filter))
            {
                string escaped = Regex.Escape(filter);
                mongoFilter = Builders<ClanDoc>.Filter.Or(
                    Builders<ClanDoc>.Filter.Regex(x => x.NameLower, new BsonRegularExpression(escaped, "i")),
                    Builders<ClanDoc>.Filter.Regex(x => x.TagLower, new BsonRegularExpression(escaped, "i")));
            }
            Clan[] result = Clans.Find(mongoFilter)
                .SortByDescending(x => x.MembersCount)
                .Skip(page * size).Limit(size).ToList()
                .Select(ToProto).Where(x => x != null).ToArray();
            byte[] response = ContractWire.WrapRepeated(1, result);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void FindClan(BinaryValue[] args, string id)
        {
            string filter = Normalize(Read<string>(args, 0) ?? string.Empty);
            int page = Math.Max(0, Read<int>(args, 1, 0));
            int size = Clamp(Read<int>(args, 2, 20), 1, MaxPageSize);

            FilterDefinition<ClanDoc> mongoFilter = Builders<ClanDoc>.Filter.Empty;
            if (!string.IsNullOrWhiteSpace(filter))
            {
                string escaped = Regex.Escape(filter);
                mongoFilter = Builders<ClanDoc>.Filter.Or(
                    Builders<ClanDoc>.Filter.Regex(x => x.NameLower, new BsonRegularExpression(escaped, "i")),
                    Builders<ClanDoc>.Filter.Regex(x => x.TagLower, new BsonRegularExpression(escaped, "i")));
            }

            Clan[] result = Clans.Find(mongoFilter)
                .SortByDescending(x => x.MembersCount)
                .Skip(page * size)
                .Limit(size)
                .ToList()
                .Select(ToProto)
                .ToArray();
            Send(id, result);
        }

        private void GetClanMembers(string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            SendMembers(id, BuildMembers(clanId, myId));
        }

        private void GetClanMembersByClanId(BinaryValue[] args, string id)
        {
            string viewerId = GetPlayerId();
            string clanId = Read<string>(args, 0);
            if (FindClan(clanId) == null) throw new ClanLogicException(ErrorCodes.ClanNotFound, "clan not found");
            SendMembers(id, BuildMembers(clanId, viewerId));
        }

        private void GetClanMembersByClanIdV2(RpcRequest request)
        {
            string viewerId = GetPlayerId();
            string clanId = ContractWire.ReadStringField(
                ContractWire.Param(request),
                1,
                string.Empty);

            if (string.IsNullOrWhiteSpace(clanId))
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "clan id is required");

            if (FindClan(clanId) == null)
                throw new ClanLogicException(ErrorCodes.ClanNotFound, "clan not found");

            ClanMember[] members = BuildMembers(clanId, viewerId);
            SendMembers(request.Id, members);
        }

        private void SendMembers(string id, ClanMember[] members)
        {
            members = members ?? Array.Empty<ClanMember>();
            byte[] response = ContractWire.Build(w =>
            {
                foreach (ClanMember member in members)
                {
                    if (member != null) w.Message(1, member);
                }
            });
            ContractWire.SendRaw(_session, id, response);
        }

        private ClanMember[] BuildMembers(string clanId, string viewerId)
        {
            return Members.Find(x => x.ClanId == clanId)
                .SortBy(x => x.RoleId)
                .ThenBy(x => x.CreateDate)
                .ToList()
                .Select(x => ToProto(x, viewerId))
                .ToArray();
        }

        private void GetPlayerJoinRequests(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            var page = GetPage(args);
            var docs = JoinRequests.Find(x => x.PlayerId == myId && !x.IsRead)
                .SortByDescending(x => x.CreateDate)
                .Skip(page.offset)
                .Limit(page.length)
                .ToList();
            Send(id, docs.Select(x => ToProto(x, myId)).ToArray());
        }

        private void GetPlayerInviteRequests(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            var page = GetPage(args);
            var docs = InviteRequests.Find(x => x.InvitedPlayerId == myId &&
                                                x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate)
                .Skip(page.offset)
                .Limit(page.length)
                .ToList();
            Send(id, docs.Select(x => ToProto(x, myId)).ToArray());
        }

        private void GetClanJoinRequests(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            RequirePermission(myId, clanId, ClanMemberRolePermission.AcceptMember);
            var page = GetPage(args);
            var docs = JoinRequests.Find(x => x.ClanId == clanId &&
                                              x.RequestType == (int)RequestType.OpenRequest)
                .SortByDescending(x => x.CreateDate)
                .Skip(page.offset)
                .Limit(page.length)
                .ToList();
            Send(id, docs.Select(x => ToProto(x, myId)).ToArray());
        }

        private void GetClanInviteRequests(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            RequirePermission(myId, clanId, ClanMemberRolePermission.InviteMember);
            var page = GetPage(args);
            var docs = InviteRequests.Find(x => x.ClanId == clanId && !x.IsRead)
                .SortByDescending(x => x.CreateDate)
                .Skip(page.offset)
                .Limit(page.length)
                .ToList();
            Send(id, docs.Select(x => ToProto(x, myId)).ToArray());
        }

        private void GetPlayerInviteRequestsCount(string id)
        {
            string myId = GetPlayerId();
            Send(id, (int)InviteRequests.CountDocuments(x => x.InvitedPlayerId == myId &&
                x.RequestType == (int)RequestType.OpenRequest));
        }

        private void GetPlayerClosedJoinRequestsCount(string id)
        {
            string myId = GetPlayerId();
            int count = (int)JoinRequests.CountDocuments(x => x.PlayerId == myId &&
                x.RequestType == (int)RequestType.ClosedRequest && !x.IsRead);
            Send(id, count);
        }

        private void GetClanJoinRequestsCountV2(string id)
        {
            string clanId = GetClanId(GetPlayerId());
            int count = (int)JoinRequests.CountDocuments(x => x.ClanId == clanId &&
                x.RequestType == (int)RequestType.OpenRequest);
            ContractWire.SendRaw(_session, id, ContractWire.Build(w => w.Int32(1, count)));
        }

        private void GetClanClosedInviteRequestsCountV2(string id)
        {
            string clanId = GetClanId(GetPlayerId());
            int count = (int)InviteRequests.CountDocuments(x => x.ClanId == clanId &&
                x.RequestType == (int)RequestType.ClosedRequest && !x.IsRead);
            ContractWire.SendRaw(_session, id, ContractWire.Build(w => w.Int32(1, count)));
        }

        private void GetClanJoinRequestsCount(string id)
        {
            string clanId = GetClanId(GetPlayerId());
            Send(id, (int)JoinRequests.CountDocuments(x => x.ClanId == clanId &&
                x.RequestType == (int)RequestType.OpenRequest));
        }

        private void GetClanUnreadInviteRequestsCount(string id)
        {
            string clanId = GetClanId(GetPlayerId());
            Send(id, (int)InviteRequests.CountDocuments(x => x.ClanId == clanId &&
                x.RequestType == (int)RequestType.ClosedRequest && !x.IsRead));
        }

        private void GetClanClosedInviteRequestsCount(string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            int count = (int)InviteRequests.CountDocuments(x => x.ClanId == clanId &&
                x.RequestType == (int)RequestType.ClosedRequest && !x.IsRead);
            Send(id, count);
        }

        private void GetClanInviteRequestsCount(string id)
        {
            string clanId = GetClanId(GetPlayerId());
            Send(id, (int)InviteRequests.CountDocuments(x => x.ClanId == clanId && !x.IsRead));
        }

        private void RequestToJoinClanV2(RpcRequest request)
        {
            string clanId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);
            RequestToJoinClanCore(clanId, request.Id, true);
        }

        private void RequestToJoinClan(BinaryValue[] args, string id)
        {
            RequestToJoinClanCore(Read<string>(args, 0), id, false);
        }

        private void RequestToJoinClanCore(string clanId, string id, bool exactV2)
        {
            string myId = GetPlayerId();
            if (string.IsNullOrWhiteSpace(clanId)) throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad clan id");

            lock (GetLock(PairKey("join", clanId, myId)))
            {
                if (FindMembership(myId) != null)
                    throw new ClanLogicException(ErrorCodes.PlayerAlreadyInClan, "player already in clan");

                ClanDoc clan = RequireClan(clanId);
                CheckClanSpace(clan);

                InviteRequestDoc invite = InviteRequests.Find(x => x.ClanId == clanId &&
                    x.InvitedPlayerId == myId && x.RequestType == (int)RequestType.OpenRequest).FirstOrDefault();
                if (invite != null && TakeSeenRequest(myId, "player-invite", invite.RequestId))
                {
                    JoinPlayer(clan, myId, JoinClanType.ByAcceptInviteRequest, invite.InviterPlayerId,
                        acceptedInviteRequestId: invite.RequestId);
                    SendJoinResult(id, exactV2);
                    return;
                }

                if ((ClanType)clan.ClanType == ClanType.Opened)
                {
                    JoinPlayer(clan, myId, JoinClanType.JoinToOpenClan, string.Empty);
                    SendJoinResult(id, exactV2);
                    return;
                }

                if ((ClanType)clan.ClanType == ClanType.Closed)
                    throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "clan is closed");

                JoinRequestDoc existing = JoinRequests.Find(x => x.ClanId == clanId && x.PlayerId == myId).FirstOrDefault();
                if (existing != null && existing.RequestType == (int)RequestType.OpenRequest)
                    throw new ClanLogicException(ErrorCodes.RequestToJoinAlreadySent, "join request already sent");

                if (existing != null)
                {
                    JoinRequests.DeleteOne(x => x._id == existing._id);
                    existing = null;
                }
                long now = NowMs();
                string requestId = ObjectId.GenerateNewId().ToString();
                var replacement = new JoinRequestDoc
                {
                    _id = ObjectId.GenerateNewId(),
                    RequestId = requestId,
                    ClanId = clanId,
                    PlayerId = myId,
                    CreateDate = now,
                    CloseDate = 0,
                    RequestType = (int)RequestType.OpenRequest,
                    ExecutionState = ExecutionStates.None,
                    IsRead = false,
                    ClosedByPlayerId = string.Empty
                };
                JoinRequests.ReplaceOne(x => x.ClanId == clanId && x.PlayerId == myId,
                    replacement, new ReplaceOptions { IsUpsert = true });

                SendJoinResult(id, exactV2);
            }
        }

        private void SendJoinResult(string id, bool exactV2)
        {
            if (exactV2) SendEmptyProto(id, "RequestToJoinClanResponse");
            else SendOk(id);
        }

        private void InviteToClanV2(RpcRequest request)
        {
            string targetId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);
            InviteToClanCore(targetId, request.Id, true);
        }

        private void InviteToClan(BinaryValue[] args, string id)
        {
            InviteToClanCore(Read<string>(args, 0), id, false);
        }

        private void SendInviteResult(string id, bool exactV2)
        {
            if (exactV2) SendEmptyProto(id, "InviteToClanResponse");
            else SendOk(id);
        }

        private void InviteToClanCore(string targetId, string id, bool exactV2)
        {
            string myId = GetPlayerId();
            if (string.IsNullOrWhiteSpace(targetId))
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad player id");
            if (targetId == myId)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "can't invite yourself");

            string clanId = GetClanId(myId);

            lock (GetLock(PairKey("invite", clanId, targetId)))
            {
                ClanDoc clan = RequireClan(clanId);
                CheckClanSpace(clan);
                if (FindMembership(targetId) != null)
                    throw new ClanLogicException(
                        ErrorCodes.PlayerAlreadyInClan,
                        "player already in clan");
                CheckPlayerExists(targetId);

                JoinRequestDoc join = JoinRequests.Find(x =>
                    x.ClanId == clanId &&
                    x.PlayerId == targetId &&
                    x.RequestType == (int)RequestType.OpenRequest)
                    .FirstOrDefault();
                if (join != null && TakeSeenRequest(myId, "clan-join", join.RequestId))
                {

                    RequirePermission(
                        myId,
                        clanId,
                        ClanMemberRolePermission.AcceptMember);
                    BroadcastClan(clanId, "onJoinRequestTaken", new OnJoinRequestTakenEvent
                    {
                        RequestId = join.RequestId,
                        Player = BuildPlayer(myId)
                    });
                    JoinPlayer(
                        clan,
                        targetId,
                        JoinClanType.ByAcceptJoinRequest,
                        myId,
                        acceptedJoinRequestId: join.RequestId);
                    SendInviteResult(id, exactV2);
                    return;
                }

                RequirePermission(myId, clanId, ClanMemberRolePermission.InviteMember);

                InviteRequestDoc existing = InviteRequests.Find(x =>
                    x.ClanId == clanId &&
                    x.InvitedPlayerId == targetId)
                    .FirstOrDefault();
                if (existing != null &&
                    existing.RequestType == (int)RequestType.OpenRequest)
                    throw new ClanLogicException(
                        ErrorCodes.InviteRequestAlreadySent,
                        "invite request already sent");

                long now = NowMs();
                string requestId =
                    existing?.RequestId ?? ObjectId.GenerateNewId().ToString();
                var replacement = new InviteRequestDoc
                {
                    _id = existing?._id ?? ObjectId.GenerateNewId(),
                    RequestId = requestId,
                    ClanId = clanId,
                    InvitedPlayerId = targetId,
                    InviterPlayerId = myId,
                    CreateDate = now,
                    CloseDate = 0,
                    RequestType = (int)RequestType.OpenRequest,
                    ExecutionState = ExecutionStates.None,
                    IsRead = false,
                    ClosedByPlayerId = string.Empty
                };
                InviteRequests.ReplaceOne(
                    x => x.ClanId == clanId &&
                         x.InvitedPlayerId == targetId,
                    replacement,
                    new ReplaceOptions { IsUpsert = true });

                Push(targetId, "onInvitedToClanEvent", new OnInvitedToClanEvent
                {
                    RequestId = requestId,
                    Clan = ToProto(clan),
                    Player = BuildPlayer(myId)
                });
                SendInviteResult(id, exactV2);
            }
        }

        private static BinaryValue LegacyArg(string value) => new RpcValueWriter(typeof(string)).ToBytes(value ?? string.Empty);
        private static BinaryValue LegacyArg(int value) => new RpcValueWriter(typeof(int)).ToBytes(value);

        private void CancelJoinRequestV2(RpcRequest request) =>
            CancelJoinRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);
        private void CancelInviteRequestV2(RpcRequest request) =>
            CancelInviteRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);
        private void DeclineJoinRequestV2(RpcRequest request) =>
            DeclineJoinRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);
        private void DeclineInviteRequestV2(RpcRequest request) =>
            DeclineInviteRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);
        private void DeleteClosedJoinRequestV2(RpcRequest request) =>
            DeleteClosedJoinRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);
        private void DeleteClosedInviteRequestV2(RpcRequest request) =>
            DeleteClosedInviteRequest(new[] { LegacyArg(ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty)) }, request.Id);

        private void CancelJoinRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string requestId = Read<string>(args, 0);
            JoinRequestDoc doc = JoinRequests.Find(x => x.RequestId == requestId && x.PlayerId == myId).FirstOrDefault();
            if (doc == null) throw new ClanLogicException(ErrorCodes.RequestNotFound, "join request not found");
            if (doc.RequestType != (int)RequestType.OpenRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "join request is not open");

            CloseJoin(doc, ExecutionStates.Canceled, myId);
            BroadcastClan(doc.ClanId, "onJoinRequestCancelled");
            SendOk(id);
        }

        private void CancelInviteRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            RequirePermission(myId, clanId, ClanMemberRolePermission.InviteMember);
            string requestId = Read<string>(args, 0);
            InviteRequestDoc doc = InviteRequests.Find(x => x.RequestId == requestId && x.ClanId == clanId).FirstOrDefault();
            if (doc == null) throw new ClanLogicException(ErrorCodes.RequestNotFound, "invite request not found");
            if (doc.RequestType != (int)RequestType.OpenRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "invite request is not open");

            CloseInvite(doc, ExecutionStates.Canceled, myId);
            Push(doc.InvitedPlayerId, "onInviteRequestCancelled");
            BroadcastClan(clanId, "onInviteRequestCancelled", null, myId);
            SendOk(id);
        }

        private void DeclineJoinRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            RequirePermission(myId, clanId, ClanMemberRolePermission.AcceptMember);
            string requestId = Read<string>(args, 0);
            JoinRequestDoc doc = JoinRequests.Find(x => x.RequestId == requestId && x.ClanId == clanId).FirstOrDefault();
            if (doc == null) throw new ClanLogicException(ErrorCodes.RequestNotFound, "join request not found");
            if (doc.RequestType != (int)RequestType.OpenRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "join request is not open");

            BroadcastClan(clanId, "onJoinRequestTaken", new OnJoinRequestTakenEvent
            {
                RequestId = doc.RequestId,
                Player = BuildPlayer(myId)
            });
            CloseJoin(doc, ExecutionStates.Rejected, myId);
            Push(doc.PlayerId, "onJoinRequestDeclined");
            BroadcastClan(clanId, "onClanMemberDeclinedRequest", null, myId);
            SendOk(id);
        }

        private void DeclineInviteRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string requestId = Read<string>(args, 0);
            InviteRequestDoc doc = InviteRequests.Find(x => x.RequestId == requestId &&
                x.InvitedPlayerId == myId).FirstOrDefault();
            if (doc == null) throw new ClanLogicException(ErrorCodes.RequestNotFound, "invite request not found");
            if (doc.RequestType != (int)RequestType.OpenRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "invite request is not open");

            CloseInvite(doc, ExecutionStates.Rejected, myId);
            BroadcastClan(doc.ClanId, "onInviteRequestDeclined");
            SendOk(id);
        }

        private void DeleteClosedJoinRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string requestId = Read<string>(args, 0);
            JoinRequestDoc doc = JoinRequests.Find(x => x.RequestId == requestId && x.PlayerId == myId).FirstOrDefault();
            if (doc == null) { SendOk(id); return; }
            if (doc.RequestType != (int)RequestType.ClosedRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "join request is not closed");

            JoinRequests.DeleteOne(x => x._id == doc._id);
            SendOk(id);
        }

        private void DeleteClosedInviteRequest(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string clanId = GetClanId(myId);
            RequirePermission(myId, clanId, ClanMemberRolePermission.InviteMember);
            string requestId = Read<string>(args, 0);
            InviteRequestDoc doc = InviteRequests.Find(x => x.RequestId == requestId && x.ClanId == clanId).FirstOrDefault();
            if (doc == null) { SendOk(id); return; }
            if (doc.RequestType != (int)RequestType.ClosedRequest)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "invite request is not closed");

            InviteRequests.DeleteOne(x => x._id == doc._id);
            BroadcastClan(clanId, "onReadClosedInviteRequest", null, myId);
            SendOk(id);
        }

        private void CloseJoin(JoinRequestDoc doc, int executionState, string closedBy)
        {
            JoinRequests.UpdateOne(x => x._id == doc._id,
                Builders<JoinRequestDoc>.Update
                    .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                    .Set(x => x.ExecutionState, executionState)
                    .Set(x => x.CloseDate, NowMs())
                    .Set(x => x.IsRead, executionState != ExecutionStates.Rejected)
                    .Set(x => x.ClosedByPlayerId, closedBy ?? string.Empty));
        }

        private void CloseInvite(InviteRequestDoc doc, int executionState, string closedBy)
        {
            InviteRequests.UpdateOne(x => x._id == doc._id,
                Builders<InviteRequestDoc>.Update
                    .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                    .Set(x => x.ExecutionState, executionState)
                    .Set(x => x.CloseDate, NowMs())
                    .Set(x => x.IsRead, executionState != ExecutionStates.Rejected)
                    .Set(x => x.ClosedByPlayerId, closedBy ?? string.Empty));
        }

        private void JoinPlayer(ClanDoc clan, string playerId, JoinClanType joinType, string acceptorId,
            string acceptedJoinRequestId = null, string acceptedInviteRequestId = null)
        {
            lock (GetLock("clan:" + clan.Id))
            lock (GetLock("membership:" + playerId))
            {
                if (FindMembership(playerId) != null)
                    throw new ClanLogicException(ErrorCodes.PlayerAlreadyInClan, "player already in clan");

                clan = RequireClan(clan.Id);
                CheckClanSpace(clan);
                long now = NowMs();
                var member = new ClanMemberDoc
                {
                    _id = ObjectId.GenerateNewId(),
                    ClanId = clan.Id,
                    PlayerId = playerId,
                    RoleId = RoleIds.Member,
                    CreateDate = now
                };
                Members.InsertOne(member);
                int newCount = (int)Members.CountDocuments(x => x.ClanId == clan.Id);
                Clans.UpdateOne(x => x.Id == clan.Id,
                    Builders<ClanDoc>.Update.Set(x => x.MembersCount, newCount));
                clan.MembersCount = newCount;

                CloseRequestsAfterJoin(playerId, acceptedJoinRequestId, acceptedInviteRequestId, acceptorId);

                Push(playerId, "onJoinedToClan", new OnJoinedToClanEvent { Clan = ToProto(clan) });
                foreach (string recipientId in Members.Find(x => x.ClanId == clan.Id)
                             .Project(x => x.PlayerId).ToList().Distinct())
                {
                    if (recipientId == playerId) continue;
                    Push(recipientId, "onMemberJoinedToClan", new OnMemberJoinedToClanEvent
                    {
                        ClanMember = ToProto(member, recipientId),
                        JoinClanType = joinType,
                        JoinRequestAcceptor = acceptorId ?? string.Empty
                    });
                }

                AddLog(clan.Id, 9, primaryPlayerId: playerId);
            }
        }

        private void CloseRequestsAfterJoin(string playerId, string acceptedJoinRequestId,
            string acceptedInviteRequestId, string acceptedByPlayerId)
        {
            long now = NowMs();

            if (!string.IsNullOrWhiteSpace(acceptedJoinRequestId))
            {
                JoinRequests.UpdateOne(x => x.RequestId == acceptedJoinRequestId &&
                                             x.RequestType == (int)RequestType.OpenRequest,
                    Builders<JoinRequestDoc>.Update
                        .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                        .Set(x => x.ExecutionState, ExecutionStates.Accepted)
                        .Set(x => x.CloseDate, now)
                        .Set(x => x.IsRead, true)
                        .Set(x => x.ClosedByPlayerId, acceptedByPlayerId ?? playerId));
            }

            if (!string.IsNullOrWhiteSpace(acceptedInviteRequestId))
            {
                InviteRequests.UpdateOne(x => x.RequestId == acceptedInviteRequestId &&
                                               x.RequestType == (int)RequestType.OpenRequest,
                    Builders<InviteRequestDoc>.Update
                        .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                        .Set(x => x.ExecutionState, ExecutionStates.Accepted)
                        .Set(x => x.CloseDate, now)
                        .Set(x => x.IsRead, true)
                        .Set(x => x.ClosedByPlayerId, acceptedByPlayerId ?? playerId));
            }

            JoinRequests.UpdateMany(x => x.PlayerId == playerId &&
                                         x.RequestType == (int)RequestType.OpenRequest &&
                                         x.RequestId != acceptedJoinRequestId,
                Builders<JoinRequestDoc>.Update
                    .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                    .Set(x => x.ExecutionState, ExecutionStates.Canceled)
                    .Set(x => x.CloseDate, now)
                    .Set(x => x.IsRead, true)
                    .Set(x => x.ClosedByPlayerId, playerId));

            InviteRequests.UpdateMany(x => x.InvitedPlayerId == playerId &&
                                           x.RequestType == (int)RequestType.OpenRequest &&
                                           x.RequestId != acceptedInviteRequestId,
                Builders<InviteRequestDoc>.Update
                    .Set(x => x.RequestType, (int)RequestType.ClosedRequest)
                    .Set(x => x.ExecutionState, ExecutionStates.Canceled)
                    .Set(x => x.CloseDate, now)
                    .Set(x => x.IsRead, true)
                    .Set(x => x.ClosedByPlayerId, playerId));
        }

        private void LeaveClan(string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc self = RequireMembership(myId);
            string clanId = self.ClanId;

            lock (GetLock("clan:" + clanId))
            {
                if (self.RoleId == RoleIds.Leader)
                {
                    ClanMemberDoc successor = Members.Find(x => x.ClanId == clanId && x.PlayerId != myId)
                        .SortBy(x => x.RoleId)
                        .ThenBy(x => x.CreateDate)
                        .FirstOrDefault();

                    if (successor == null)
                    {
                        DeleteClanData(clanId);
                        SendOk(id);
                        return;
                    }

                    Members.UpdateOne(x => x._id == successor._id,
                        Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
                    BroadcastClan(clanId, "onAssignedLeaderRoleEvent", new OnAssignedLeaderRoleEvent
                    {
                        OldLeaderRole = RoleIds.Member,
                        NewLeaderId = successor.PlayerId
                    }, myId);
                }

                Members.DeleteOne(x => x._id == self._id);

                Push(myId, "onLeftFromClan", new OnLeftFromClan { MemberId = myId });

                JoinRequests.DeleteMany(x => x.ClanId == clanId && x.PlayerId == myId);
                InviteRequests.DeleteMany(x => x.ClanId == clanId && x.InvitedPlayerId == myId);
                int count = (int)Members.CountDocuments(x => x.ClanId == clanId);
                Clans.UpdateOne(x => x.Id == clanId,
                    Builders<ClanDoc>.Update.Set(x => x.MembersCount, count));
                BroadcastClan(clanId, "onLeftFromClan", new OnLeftFromClan { MemberId = myId }, myId);
                AddLog(clanId, 8, primaryPlayerId: myId);
                SendOk(id);
            }
        }

        private void KickMemberV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            KickMember(new[] { LegacyArg(ContractWire.ReadStringField(raw, 1, string.Empty)), LegacyArg(ContractWire.ReadStringField(raw, 2, string.Empty)) }, request.Id);
        }

        private void AssignRoleToMemberV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            AssignRoleToMember(new[] { LegacyArg(ContractWire.ReadStringField(raw, 1, string.Empty)), LegacyArg(ContractWire.ReadIntField(raw, 2, RoleIds.Member)) }, request.Id);
        }

        private void AssignLeaderRoleV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            AssignLeaderRole(new[] { LegacyArg(ContractWire.ReadStringField(raw, 1, string.Empty)), LegacyArg(ContractWire.ReadIntField(raw, 2, RoleIds.Member)) }, request.Id);
        }

        private void RenameClanV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            RenameClan(new[] { LegacyArg(ContractWire.ReadStringField(raw, 1, string.Empty)), LegacyArg(ContractWire.ReadStringField(raw, 2, string.Empty)) }, request.Id);
        }

        private void KickMember(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string targetId = Read<string>(args, 0);
            string reason = (Read<string>(args, 1) ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(targetId)) throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad player id");
            if (targetId == myId) throw new ClanLogicException(ErrorCodes.InvalidRequest, "use leave clan");

            ClanMemberDoc actor = RequireMembership(myId);
            ClanMemberDoc target = Members.Find(x => x.ClanId == actor.ClanId && x.PlayerId == targetId).FirstOrDefault();
            if (target == null) throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "member not found");
            if (target.RoleId == RoleIds.Leader) throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "can't kick clan leader");

            bool canKick = RoleIds.IsHigher(actor.RoleId, target.RoleId) ||
                           (actor.RoleId == target.RoleId && HasPermission(actor.RoleId, ClanMemberRolePermission.KickMemberEqual));
            if (!canKick || !HasPermission(actor.RoleId,
                    actor.RoleId == target.RoleId ? ClanMemberRolePermission.KickMemberEqual : ClanMemberRolePermission.KickMemberLess))
                throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "no permission to kick member");

            Members.DeleteOne(x => x._id == target._id);
            int count = (int)Members.CountDocuments(x => x.ClanId == actor.ClanId);
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.MembersCount, count));

            Push(targetId, "onKickedEvent", new OnKickedEvent { KickingReason = reason });
            BroadcastClan(actor.ClanId, "onKickedMember", new OnKickedMemberEvent
            {
                KickerMemberId = myId,
                KickedMemberId = targetId
            }, myId);
            AddLog(actor.ClanId, 10, primaryPlayerId: myId, secondaryPlayerId: targetId);
            SendOk(id);
        }

        private void AssignRoleToMember(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string targetId = Read<string>(args, 0);
            int? requestedRole = ReadNullableInt(args, 1);
            int newRole = requestedRole ?? RoleIds.Member;
            if (!RoleIds.IsValid(newRole) || newRole == RoleIds.Leader)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad role id");

            ClanMemberDoc actor = RequireMembership(myId);
            ClanMemberDoc target = Members.Find(x => x.ClanId == actor.ClanId && x.PlayerId == targetId).FirstOrDefault();
            if (target == null) throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "member not found");
            if (target.RoleId == RoleIds.Leader) throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "use leader transfer");
            if (targetId == myId) throw new ClanLogicException(ErrorCodes.InvalidRequest, "can't assign role to yourself");

            bool targetLower = RoleIds.IsHigher(actor.RoleId, target.RoleId);
            bool targetEqual = actor.RoleId == target.RoleId;
            if (!targetLower && !targetEqual) throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "target role is too high");
            ClanMemberRolePermission permission = targetEqual
                ? ClanMemberRolePermission.AssignRoleEqual
                : ClanMemberRolePermission.AssignRoleLess;
            if (!HasPermission(actor.RoleId, permission)) throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "no permission to assign role");
            if (!RoleIds.IsHigher(actor.RoleId, newRole)) throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "can't assign equal or higher role");

            UpdateResult roleUpdate = Members.UpdateOne(
                x => x._id == target._id && x.ClanId == actor.ClanId,
                Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, newRole));
            if (roleUpdate.MatchedCount != 1)
                throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "member changed during role assign");

            BroadcastClan(actor.ClanId, "onAssignedRoleEvent", new OnAssignedRoleEvent
            {
                NewRoleId = newRole,
                AssignatorMemberId = myId,
                AssigningMemberId = targetId
            });
            AddLog(actor.ClanId, 7, primaryPlayerId: myId, secondaryPlayerId: targetId, assignedRole: newRole);
            SendOk(id);
        }

        private void AssignLeaderRole(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            string targetId = Read<string>(args, 0);
            int? oldLeaderNewRoleArg = ReadNullableInt(args, 1);
            int oldLeaderNewRole = oldLeaderNewRoleArg ?? RoleIds.Member;
            if (!RoleIds.IsValid(oldLeaderNewRole) || oldLeaderNewRole == RoleIds.Leader)
                throw new ClanLogicException(ErrorCodes.ChangeClanLeaderNotAllowed, "bad old leader role");

            ClanMemberDoc actor = RequireMembership(myId);
            if (actor.RoleId != RoleIds.Leader) throw new ClanLogicException(ErrorCodes.ChangeClanLeaderNotAllowed, "clan leader is required");
            ClanMemberDoc target = Members.Find(x => x.ClanId == actor.ClanId && x.PlayerId == targetId).FirstOrDefault();
            if (target == null) throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "member not found");
            if (targetId == myId) { SendOk(id); return; }

            lock (GetLock("clan:" + actor.ClanId))
            {

                ClanMemberDoc currentActor = Members.Find(x => x._id == actor._id).FirstOrDefault();
                ClanMemberDoc currentTarget = Members.Find(x => x._id == target._id).FirstOrDefault();
                if (currentActor == null || currentActor.RoleId != RoleIds.Leader)
                    throw new ClanLogicException(ErrorCodes.ChangeClanLeaderNotAllowed, "leader changed during transfer");
                if (currentTarget == null || currentTarget.ClanId != actor.ClanId || currentTarget.PlayerId != targetId)
                    throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "member changed during leader transfer");

                UpdateResult demote = Members.UpdateOne(
                    x => x._id == currentActor._id && x.RoleId == RoleIds.Leader,
                    Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, oldLeaderNewRole));
                if (demote.MatchedCount != 1)
                    throw new ClanLogicException(ErrorCodes.ChangeClanLeaderNotAllowed, "leader demote conflict");

                try
                {
                    UpdateResult promote = Members.UpdateOne(
                        x => x._id == currentTarget._id && x.ClanId == actor.ClanId,
                        Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
                    if (promote.MatchedCount != 1)
                        throw new ClanLogicException(ErrorCodes.ClanMemberNotFound, "leader promote conflict");
                }
                catch
                {
                    try
                    {
                        Members.UpdateOne(
                            x => x._id == currentActor._id,
                            Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
                    }
                    catch { }
                    throw;
                }
            }

            BroadcastClan(actor.ClanId, "onAssignedLeaderRoleEvent", new OnAssignedLeaderRoleEvent
            {
                OldLeaderRole = oldLeaderNewRole,
                NewLeaderId = targetId
            });
            AddLog(actor.ClanId, 5, primaryPlayerId: myId, secondaryPlayerId: targetId);
            SendOk(id);
        }

        private void RenameClan(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            string tag = ReadTag(Read<string>(args, 0));
            string name = ReadName(Read<string>(args, 1));

            lock (GetLock("clan-name-registry"))
            {
                ClanDoc current = RequireClan(actor.ClanId);
                if (Normalize(current.Tag) == Normalize(tag) && Normalize(current.Name) == Normalize(name))
                {
                    SendOk(id);
                    return;
                }

                if (Clans.Find(x => x.Id != actor.ClanId && x.TagLower == Normalize(tag)).Any())
                    throw new ClanLogicException(ErrorCodes.ClanTagAlreadyExists, "clan tag already exists");
                if (Clans.Find(x => x.Id != actor.ClanId && x.NameLower == Normalize(name)).Any())
                    throw new ClanLogicException(ErrorCodes.ClanNameAlreadyExists, "clan name already exists");

                ChargeCurrency(myId, RenameClanCost);
                try
                {
                    UpdateResult result = Clans.UpdateOne(x => x.Id == actor.ClanId,
                        Builders<ClanDoc>.Update
                            .Set(x => x.Tag, tag)
                            .Set(x => x.Name, name)
                            .Set(x => x.TagLower, Normalize(tag))
                            .Set(x => x.NameLower, Normalize(name)));
                    if (result.MatchedCount == 0)
                        throw new ClanLogicException(ErrorCodes.ClanNotFound, "clan not found");
                }
                catch
                {
                    RefundCurrency(myId, RenameClanCost);
                    throw;
                }
            }

            BroadcastClan(actor.ClanId, "onClanTagAndNameChanged", new OnClanTagAndNameChanged
            {
                NewClanTag = tag,
                NewClanName = name
            }, myId);
            AddLog(actor.ClanId, 1, changedName: name, changedTag: tag);
            SendOk(id);
        }

        private void ChangeClanTypeV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            int rawType = ContractWire.ReadIntField(ContractWire.Param(request), 1, (int)ClanType.Closed);
            ClanType type = System.Enum.IsDefined(typeof(ClanType), rawType) ? (ClanType)rawType : ClanType.Closed;
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.ClanType, rawType));
            BroadcastClan(actor.ClanId, "onClanTypeChanged", new OnClanTypeChanged { NewClanType = type }, myId);
            AddLog(actor.ClanId, 3, changedType: rawType);
            SendEmptyProto(request.Id, "ChangeClanTypeResponse");
        }

        private void SetClanDescriptionV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            string description = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (description.Length > 500) throw new ClanLogicException(ErrorCodes.InvalidRequest, "description is too long");
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.Description, description));
            BroadcastClan(actor.ClanId, "onClanDescriptionChanged", description, myId);
            AddLog(actor.ClanId, 2);
            SendEmptyProto(request.Id, "SetClanDescriptionResponse");
        }

        private void IncreaseMaxMembersCountV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.UpgradeClanMembersCount);
            int increase = ContractWire.ReadIntField(ContractWire.Param(request), 1, 1);
            if (increase <= 0) throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad increase value");

            int newValue;
            int totalCost;
            lock (GetLock("clan:" + actor.ClanId))
            {
                ClanDoc clan = RequireClan(actor.ClanId);
                if (clan.MaxMemberCount <= 0) clan.MaxMemberCount = InitialMembersCount;
                if (increase > MembersLimit - clan.MaxMemberCount)
                    throw new ClanLogicException(ErrorCodes.ClanAlreadyFilled, "member limit reached");
                newValue = clan.MaxMemberCount + increase;
                checked { totalCost = UpgradeMembersCost * increase; }
                ChargeCurrency(myId, totalCost);
                try
                {
                    UpdateResult result = Clans.UpdateOne(x => x.Id == clan.Id && x.MaxMemberCount == clan.MaxMemberCount,
                        Builders<ClanDoc>.Update.Set(x => x.MaxMemberCount, newValue));
                    if (result.ModifiedCount != 1)
                        throw new ClanLogicException(ErrorCodes.InvalidRequest, "clan capacity changed");
                }
                catch
                {
                    RefundCurrency(myId, totalCost);
                    throw;
                }
                BroadcastClan(clan.Id, "onClanMembersCountIncreased", new OnClanMaxMembersCountIncreased
                {
                    NewMembersCountValue = newValue
                }, myId);
                AddLog(clan.Id, 6, changedMaxMembers: newValue);
            }
            SendEmptyProto(request.Id, "IncreaseMaxMembersCountResponse");
        }

        private void LeaveClanV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            ClanMemberDoc self = RequireMembership(myId);
            string clanId = self.ClanId;
            lock (GetLock("clan:" + clanId))
            {
                if (self.RoleId == RoleIds.Leader)
                {
                    ClanMemberDoc successor = Members.Find(x => x.ClanId == clanId && x.PlayerId != myId)
                        .SortBy(x => x.RoleId).ThenBy(x => x.CreateDate).FirstOrDefault();
                    if (successor == null)
                    {

                        Push(myId, "onLeftFromClan", new OnLeftFromClan { MemberId = myId });
                        DeleteClanData(clanId);
                        SendEmptyProto(request.Id, "LeaveClanResponse");
                        return;
                    }
                    Members.UpdateOne(x => x._id == successor._id,
                        Builders<ClanMemberDoc>.Update.Set(x => x.RoleId, RoleIds.Leader));
                    BroadcastClan(clanId, "onAssignedLeaderRoleEvent", new OnAssignedLeaderRoleEvent
                    {
                        OldLeaderRole = RoleIds.Member,
                        NewLeaderId = successor.PlayerId
                    }, myId);
                }
                Members.DeleteOne(x => x._id == self._id);

                Push(myId, "onLeftFromClan", new OnLeftFromClan { MemberId = myId });

                JoinRequests.DeleteMany(x => x.ClanId == clanId && x.PlayerId == myId);
                InviteRequests.DeleteMany(x => x.ClanId == clanId && x.InvitedPlayerId == myId);
                int count = (int)Members.CountDocuments(x => x.ClanId == clanId);
                Clans.UpdateOne(x => x.Id == clanId, Builders<ClanDoc>.Update.Set(x => x.MembersCount, count));
                BroadcastClan(clanId, "onLeftFromClan", new OnLeftFromClan { MemberId = myId }, myId);
                AddLog(clanId, 8, primaryPlayerId: myId);
            }
            SendEmptyProto(request.Id, "LeaveClanResponse");
        }

        private void ChangeClanType(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            ClanType type = ReadEnum<ClanType>(args, 0, ClanType.Closed);
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.ClanType, (int)type));
            BroadcastClan(actor.ClanId, "onClanTypeChanged", new OnClanTypeChanged { NewClanType = type }, myId);
            AddLog(actor.ClanId, 3, changedType: (int)type);
            SendOk(id);
        }

        private void SetClanAvatarV2(RpcRequest request)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            byte[] avatar = ContractWire.ReadBytesField(ContractWire.Param(request), 1);
            if (avatar.Length == 0 || avatar.Length > MaxAvatarBytes)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad avatar size");

            string avatarId = BoltGameDatabaseProvider.Instance.FindOrCreateAvatar(avatar.Select(x => (int)x).ToArray());
            UpdateResult result = Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.AvatarId, avatarId));
            if (result.MatchedCount == 0)
                throw new ClanLogicException(ErrorCodes.ClanNotFound, "clan not found");

            byte[] avatarChangedEvent = ContractWire.Build(w =>
            {
                w.String(1, avatarId);
                w.Bytes(2, avatar);
            });
            BroadcastClanRaw(actor.ClanId, "onClanAvatarChanged", avatarChangedEvent);
            AddLog(actor.ClanId, 4);
            byte[] response = ContractWire.Build(w => w.String(1, avatarId));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void SetClanAvatar(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            byte[] avatar = Read<byte[]>(args, 0) ?? Array.Empty<byte>();
            if (avatar.Length == 0 || avatar.Length > MaxAvatarBytes)
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad avatar size");

            string avatarId = BoltGameDatabaseProvider.Instance.FindOrCreateAvatar(avatar.Select(x => (int)x).ToArray());
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.AvatarId, avatarId));
            byte[] avatarChangedEvent = ContractWire.Build(w =>
            {
                w.String(1, avatarId);
                w.Bytes(2, avatar);
            });
            BroadcastClanRaw(actor.ClanId, "onClanAvatarChanged", avatarChangedEvent);
            AddLog(actor.ClanId, 4);
            Send(id, avatarId);
        }

        private void SetClanDescription(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.ChangeClanSettings);
            string description = (Read<string>(args, 0) ?? string.Empty).Trim();
            if (description.Length > 500) throw new ClanLogicException(ErrorCodes.InvalidRequest, "description is too long");
            Clans.UpdateOne(x => x.Id == actor.ClanId,
                Builders<ClanDoc>.Update.Set(x => x.Description, description));
            BroadcastClan(actor.ClanId, "onClanDescriptionChanged", description, myId);
            AddLog(actor.ClanId, 2);
            SendOk(id);
        }

        private void IncreaseMaxMembersCount(BinaryValue[] args, string id)
        {
            string myId = GetPlayerId();
            ClanMemberDoc actor = RequireMembership(myId);
            RequirePermission(myId, actor.ClanId, ClanMemberRolePermission.UpgradeClanMembersCount);
            int increase = Read<int>(args, 0, 1);
            if (increase <= 0) throw new ClanLogicException(ErrorCodes.InvalidRequest, "bad increase value");

            int newValue;
            int totalCost;
            lock (GetLock("clan:" + actor.ClanId))
            {
                ClanDoc clan = RequireClan(actor.ClanId);
                if (clan.MaxMemberCount <= 0) clan.MaxMemberCount = InitialMembersCount;
                if (increase > MembersLimit - clan.MaxMemberCount)
                    throw new ClanLogicException(ErrorCodes.ClanAlreadyFilled, "member limit reached");

                newValue = clan.MaxMemberCount + increase;
                checked { totalCost = UpgradeMembersCost * increase; }
                ChargeCurrency(myId, totalCost);
                try
                {
                    UpdateResult result = Clans.UpdateOne(x => x.Id == clan.Id && x.MaxMemberCount == clan.MaxMemberCount,
                        Builders<ClanDoc>.Update.Set(x => x.MaxMemberCount, newValue));
                    if (result.ModifiedCount != 1)
                        throw new ClanLogicException(ErrorCodes.InvalidRequest, "clan capacity changed");
                }
                catch
                {
                    RefundCurrency(myId, totalCost);
                    throw;
                }

                BroadcastClan(clan.Id, "onClanMembersCountIncreased", new OnClanMaxMembersCountIncreased
                {
                    NewMembersCountValue = newValue
                }, myId);
                AddLog(clan.Id, 6, changedMaxMembers: newValue);
            }
            SendOk(id);
        }

        internal Clan ToProto(ClanDoc doc)
        {
            if (doc == null) return null;
            int count = (int)Members.CountDocuments(x => x.ClanId == doc.Id);
            if (count != doc.MembersCount)
            {
                Clans.UpdateOne(x => x.Id == doc.Id,
                    Builders<ClanDoc>.Update.Set(x => x.MembersCount, count));
                doc.MembersCount = count;
            }

            return new Clan
            {
                Id = doc.Id ?? string.Empty,
                Name = doc.Name ?? string.Empty,
                Tag = doc.Tag ?? string.Empty,
                ClanType = System.Enum.IsDefined(typeof(ClanType), doc.ClanType) ? (ClanType)doc.ClanType : ClanType.Closed,
                AvatarId = doc.AvatarId ?? string.Empty,
                CreateDate = doc.CreateDate > 0 ? doc.CreateDate : doc.CreatedAt,
                MebersCount = count,
                MaxMemberCount = doc.MaxMemberCount > 0 ? doc.MaxMemberCount : InitialMembersCount,
                Description = doc.Description ?? string.Empty
            };
        }

        internal ClanMember ToProto(ClanMemberDoc doc, string viewerId)
        {
            if (doc == null) return null;

            PlayerFriend playerFriend = BuildPlayerFriend(doc.PlayerId, viewerId) ?? new PlayerFriend();
            if (playerFriend.Player == null) playerFriend.Player = BuildPlayer(doc.PlayerId);
            if (playerFriend.Player == null) playerFriend.Player = new Player();
            string canonicalPlayerId = (doc.PlayerId ?? string.Empty).Trim();
            playerFriend.Player.Id = canonicalPlayerId;
            playerFriend.Player.Uid = playerFriend.Player.Uid ?? string.Empty;
            playerFriend.Player.Name = playerFriend.Player.Name ?? string.Empty;
            playerFriend.Player.AvatarId = playerFriend.Player.AvatarId ?? string.Empty;
            if (playerFriend.Player.PlayerStatus == null)
                playerFriend.Player.PlayerStatus = ServerState.GetOrCreatePlayerStatus(canonicalPlayerId).GetPlayerStatusProto();


            return new ClanMember
            {
                PlayerFriend = playerFriend,
                ClanId = doc.ClanId ?? string.Empty,
                RoleId = RoleIds.IsValid(doc.RoleId) ? doc.RoleId : RoleIds.Member,
                CreateDate = doc.CreateDate
            };
        }

        private static string SurfacedRequestKey(string viewerId, string kind, string requestId)
        {
            return (viewerId ?? string.Empty).Trim() + "|" + (kind ?? string.Empty) + "|" + (requestId ?? string.Empty).Trim();
        }

        private static void MarkRequestSeen(string viewerId, string kind, string requestId)
        {
            if (string.IsNullOrWhiteSpace(viewerId) || string.IsNullOrWhiteSpace(requestId)) return;
            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            SeenRequestActions[SurfacedRequestKey(viewerId, kind, requestId)] = now;

            if (SeenRequestActions.Count > 2048)
            {
                long cutoff = now - SeenRequestTtlMs;
                foreach (var pair in SeenRequestActions)
                    if (pair.Value < cutoff)
                        SeenRequestActions.TryRemove(pair.Key, out _);
            }
        }

        private static bool TakeSeenRequest(string viewerId, string kind, string requestId)
        {
            if (string.IsNullOrWhiteSpace(viewerId) || string.IsNullOrWhiteSpace(requestId)) return false;
            string key = SurfacedRequestKey(viewerId, kind, requestId);
            if (!SeenRequestActions.TryRemove(key, out long surfacedAt)) return false;
            long age = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - surfacedAt;
            return age >= 0 && age <= SeenRequestTtlMs;
        }

        private static Player NormalizeRequestPlayer(Player player, string fallbackId)
        {
            player ??= new Player();
            player.Id = string.IsNullOrWhiteSpace(player.Id) ? (fallbackId ?? string.Empty).Trim() : player.Id.Trim();
            player.Uid ??= string.Empty;
            player.Name ??= string.Empty;
            player.AvatarId ??= string.Empty;
            if (player.PlayerStatus == null && !string.IsNullOrWhiteSpace(player.Id))
                player.PlayerStatus = ServerState.GetOrCreatePlayerStatus(player.Id).GetPlayerStatusProto();
            if (player.PlayerStatus != null)
                player.PlayerStatus.PlayerId = player.Id;
            return player;
        }

        internal ClanJoinRequest ToProto(JoinRequestDoc doc, string viewerId)
        {
            return ToProtoJoinRequest(doc, viewerId, "generic");
        }

        internal ClanInviteRequest ToProto(InviteRequestDoc doc, string viewerId)
        {
            if (doc == null) return null;
            Clan clan = ToProto(FindClan(doc.ClanId));
            if (clan == null) return null;
            Player sender = NormalizeRequestPlayer(BuildPlayer(doc.InviterPlayerId), doc.InviterPlayerId);
            Player invited = NormalizeRequestPlayer(BuildPlayer(doc.InvitedPlayerId), doc.InvitedPlayerId);
            return new ClanInviteRequest
            {
                Id = doc.RequestId ?? string.Empty,
                Clan = clan,
                RequestSender = sender,
                CreateDate = doc.CreateDate,
                CloseDate = doc.CloseDate,
                RequestType = (RequestType)doc.RequestType,
                InvitedPlayer = invited
            };
        }

        internal static Player BuildPlayer(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return new Player();
            try
            {
                if (ObjectId.TryParse(playerId, out ObjectId objectId))
                {
                    PlayerDocument doc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId);
                    if (doc != null) return FriendHelper.GetPlayer(doc);
                }
            }
            catch { }
            return new Player { Id = playerId, Name = "Unknown" };
        }

        internal static PlayerFriend BuildPlayerFriend(string playerId, string viewerId)
        {
            try
            {
                if (ObjectId.TryParse(playerId, out ObjectId objectId))
                {
                    PlayerDocument doc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId);
                    if (doc != null) return doc.GetPlayerFriend(viewerId);
                }
            }
            catch { }
            return new PlayerFriend
            {
                Player = BuildPlayer(playerId),
                RelationshipStatus = RelationshipStatus.None,
                LastRelationshipUpdate = 0
            };
        }

        private void AddLog(string clanId, int logType, string primaryPlayerId = null,
            string secondaryPlayerId = null, int changedType = 0, string changedName = null,
            string changedTag = null, int changedMaxMembers = 0, int assignedRole = 0)
        {
            try
            {
                ObjectId messageId = ObjectId.GenerateNewId();
                Logs.InsertOne(new ClanLogDoc
                {
                    _id = messageId,
                    Id = messageId.ToString(),
                    ClanId = clanId,
                    Timestamp = NowMs(),
                    MessageType = (int)MessageType.LogMessage,
                    ClanLogType = logType,
                    PrimaryPlayerId = primaryPlayerId ?? string.Empty,
                    SecondaryPlayerId = secondaryPlayerId ?? string.Empty,
                    ChangedClanType = changedType,
                    ChangedClanName = changedName ?? string.Empty,
                    ChangedClanTag = changedTag ?? string.Empty,
                    ChangedMaxMemberCount = changedMaxMembers,
                    AssignedRole = assignedRole
                });
            }
            catch { }
        }

        private static bool HasPermission(int roleId, ClanMemberRolePermission permission)
        {
            if (roleId == RoleIds.Leader) return true;
            if (roleId == RoleIds.CoLeader)
            {
                return permission != ClanMemberRolePermission.KickMemberEqual &&
                       permission != ClanMemberRolePermission.AssignRoleEqual;
            }
            if (roleId == RoleIds.Elder)
            {
                return permission == ClanMemberRolePermission.AcceptMember ||
                       permission == ClanMemberRolePermission.InviteMember ||
                       permission == ClanMemberRolePermission.KickMemberLess ||
                       permission == ClanMemberRolePermission.JoinClanBattle;
            }
            return permission == ClanMemberRolePermission.JoinClanBattle;
        }

        private void RequirePermission(string playerId, string clanId, ClanMemberRolePermission permission)
        {
            ClanMemberDoc member = Members.Find(x => x.PlayerId == playerId && x.ClanId == clanId).FirstOrDefault();
            if (member == null) throw new ClanLogicException(ErrorCodes.NotClanMember, "not a clan member");
            if (!HasPermission(member.RoleId, permission))
                throw new ClanLogicException(ErrorCodes.NotEnoughPermission, "clan permission denied");
        }

        private ClanMemberDoc FindMembership(string playerId) =>
            Members.Find(x => x.PlayerId == playerId).FirstOrDefault();

        private ClanMemberDoc RequireMembership(string playerId) =>
            FindMembership(playerId) ?? throw new ClanLogicException(ErrorCodes.NotClanMember, "player is not in clan");

        private string GetClanId(string playerId) => RequireMembership(playerId).ClanId;

        private ClanDoc FindClan(string clanId)
        {
            if (string.IsNullOrWhiteSpace(clanId)) return null;
            return Clans.Find(x => x.Id == clanId).FirstOrDefault();
        }

        private ClanDoc RequireClan(string clanId) =>
            FindClan(clanId) ?? throw new ClanLogicException(ErrorCodes.ClanNotFound, "clan not found");

        private void CheckClanSpace(ClanDoc clan)
        {
            int count = (int)Members.CountDocuments(x => x.ClanId == clan.Id);
            int max = clan.MaxMemberCount > 0 ? clan.MaxMemberCount : InitialMembersCount;
            if (count >= max) throw new ClanLogicException(ErrorCodes.ClanAlreadyFilled, "clan is full");
        }

        private static void CheckPlayerExists(string playerId)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId objectId))
                throw new ClanLogicException(ErrorCodes.InvalidRequest, "player not found");
            try
            {
                if (BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId) == null)
                    throw new ClanLogicException(ErrorCodes.InvalidRequest, "player not found");
            }
            catch (ClanLogicException) { throw; }
            catch { throw new ClanLogicException(ErrorCodes.InvalidRequest, "player not found"); }
        }

        private static void ChargeCurrency(string playerId, int amount)
        {
            if (amount <= 0) return;
            if (!ObjectId.TryParse(playerId, out ObjectId objectId))
                throw new ClanLogicException(ErrorCodes.NotEnoughFunds, "invalid koshel player id");

            lock (GetLock("wallet:" + playerId))
            {
                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                if (!provider.IsEnoughFunds(playerId, CurrencyId.ToString(), amount))
                    throw new ClanLogicException(ErrorCodes.NotEnoughFunds, "not enough funds");
                try
                {
                    provider.CurrencyMinusValue(objectId, CurrencyId, amount);
                }
                catch (SysException ex)
                {
                    if (ex.Message != null && ex.Message.IndexOf("not enough", StringComparison.OrdinalIgnoreCase) >= 0)
                        throw new ClanLogicException(ErrorCodes.NotEnoughFunds, "not enough funds");
                    throw;
                }
            }
        }

        private static void RefundCurrency(string playerId, int amount)
        {
            if (amount <= 0 || !ObjectId.TryParse(playerId, out ObjectId objectId)) return;
            try
            {
                lock (GetLock("wallet:" + playerId))
                    BoltGameDatabaseProvider.Instance.CurrencyPlusValue(objectId, CurrencyId, amount);
            }
            catch { }
        }

        private void DeleteClanData(string clanId)
        {
            Members.DeleteMany(x => x.ClanId == clanId);
            JoinRequests.DeleteMany(x => x.ClanId == clanId);
            InviteRequests.DeleteMany(x => x.ClanId == clanId);
            Logs.DeleteMany(x => x.ClanId == clanId);
            Clans.DeleteOne(x => x.Id == clanId);
        }

        private void EnsureClanEvents()
        {
            string playerId = TryGetMyId();
            if (string.IsNullOrWhiteSpace(playerId)) return;
            ServerState.EnsureConnectionEventSender(
                playerId,
                _session.TcpClient,
                () => new ClansRemoteEventSender(_session));
        }

        private static void Push(string playerId, string eventName, params object[] parameters)
        {
            SocialEventDelivery.Send<ClansRemoteEventSender>(
                playerId,
                "clan",
                eventName,
                parameters ?? Array.Empty<object>());
        }

        private void BroadcastClan(string clanId, string eventName, object payload = null, string excludePlayerId = null)
        {
            object[] args = payload == null ? Array.Empty<object>() : new[] { payload };
            BroadcastClan(clanId, eventName, args, excludePlayerId);
        }

        private void BroadcastClan(string clanId, string eventName, object first, object second)
        {
            BroadcastClan(clanId, eventName, new[] { first, second }, null);
        }

        private void BroadcastClan(string clanId, string eventName, object[] args, string excludePlayerId)
        {
            foreach (string memberId in Members.Find(x => x.ClanId == clanId)
                         .Project(x => x.PlayerId).ToList().Distinct())
            {
                if (!string.IsNullOrWhiteSpace(excludePlayerId) && memberId == excludePlayerId) continue;
                Push(memberId, eventName, args);
            }
        }

        private static void PushRaw(string playerId, string eventName, byte[] payload)
        {
            SocialEventDelivery.SendRaw<ClansRemoteEventSender>(
                playerId,
                "clan",
                eventName,
                payload ?? Array.Empty<byte>(),
                (sender, name, payload) => sender.SendRawEvent(name, payload));
        }

        internal static int BroadcastPlayerProfileEvent(
            string playerId,
            string eventName,
            byte[] payload)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return 0;

            try
            {
                IMongoDatabase db = BoltGameDatabaseProvider.Instance.GetDatabase();
                IMongoCollection<ClanMemberDoc> members =
                    db.GetCollection<ClanMemberDoc>("clan_members");
                ClanMemberDoc membership = members
                    .Find(value => value.PlayerId == playerId)
                    .FirstOrDefault();
                if (membership == null || string.IsNullOrWhiteSpace(membership.ClanId))
                    return 0;

                string[] targets = members
                    .Find(value => value.ClanId == membership.ClanId)
                    .Project(value => value.PlayerId)
                    .ToList()
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();

                int delivered = 0;
                foreach (string target in targets)
                {
                    delivered += SocialEventDelivery.SendRaw<ClansRemoteEventSender>(
                        target,
                        "clan-profile",
                        eventName,
                        payload ?? Array.Empty<byte>(),
                        (sender, name, payload) => sender.SendRawEvent(name, payload));
                }

                return delivered;
            }
            catch (System.Exception)
            {
                return 0;
            }
        }

        private void BroadcastClanRaw(string clanId, string eventName, byte[] payload, string excludePlayerId = null)
        {
            foreach (string memberId in Members.Find(x => x.ClanId == clanId)
                         .Project(x => x.PlayerId).ToList().Distinct())
            {
                if (!string.IsNullOrWhiteSpace(excludePlayerId) && memberId == excludePlayerId) continue;
                PushRaw(memberId, eventName, payload);
            }
        }

        private string TryGetMyId()
        {
            return ServerState.Users.TryGetValue(_session.TcpClient, out string id) ? id : null;
        }

        private string GetPlayerId() =>
            TryGetMyId() ?? throw new ClanLogicException(401, "not authenticated");

        private static T Read<T>(BinaryValue[] args, int index, T fallback = default(T))
        {
            if (args == null || index < 0 || index >= args.Length || args[index] == null || args[index].IsNull)
                return fallback;
            try
            {
                object value = new RpcValueReader(typeof(T)).FromBytes(args[index]);
                return value == null ? fallback : (T)value;
            }
            catch
            {
                return fallback;
            }
        }

        private static TEnum ReadEnum<TEnum>(BinaryValue[] args, int index, TEnum fallback)
            where TEnum : struct
        {
            int raw = Read<int>(args, index, Convert.ToInt32(fallback));
            return System.Enum.IsDefined(typeof(TEnum), raw) ? (TEnum)System.Enum.ToObject(typeof(TEnum), raw) : fallback;
        }

        private static int? ReadNullableInt(BinaryValue[] args, int index)
        {
            if (args == null || index < 0 || index >= args.Length || args[index] == null || args[index].IsNull)
                return null;
            try { return (int?)new RpcValueReader(typeof(int?)).FromBytes(args[index]); }
            catch { return Read<int>(args, index, RoleIds.Member); }
        }

        private static (int offset, int length) GetPage(BinaryValue[] args)
        {
            int offset = Math.Max(0, Read<int>(args, 0, 0));
            int length = Clamp(Read<int>(args, 1, 20), 1, MaxPageSize);
            return (offset, length);
        }

        private void SendProtoArray<T>(string id, IEnumerable<T> values) where T : class, IMessage
        {
            var binary = new BinaryValue { IsNull = false };
            int count = 0;
            int bytes = 0;
            foreach (T value in values ?? Enumerable.Empty<T>())
            {
                if (value == null) continue;
                ByteString payload = value.ToByteString();
                binary.Array.Add(payload);
                count++;
                bytes += payload.Length;
            }

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse { Id = id, Return = binary }
            });
        }

        private void Send<T>(string id, T value)
        {
            BinaryValue result;
            if (value == null)
                result = new BinaryValue { IsNull = true };
            else
                result = RpcTypeCodec.CreateToByteMethod(typeof(T)).ToBytes(value);

            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse { Id = id, Return = result }
            });
        }

        private void SendEmptyProto(string id, string contractName)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.Empty
                    }
                }
            });
        }

        private void SendOk(string id)
        {
            SendEmptyProto(id, "EmptyMutationResponse");
        }

        private void SendException(string id, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private static object GetLock(string key) => Locks.GetOrAdd(key, _ => new());
        private static string PairKey(string prefix, string a, string b) => prefix + ":" + a + ":" + b;
        private static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        private static int Clamp(int value, int min, int max) => Math.Max(min, Math.Min(max, value));
        private static string Normalize(string value) => Regex.Replace((value ?? string.Empty).Trim().ToLowerInvariant(), @"\s+", " ");

        private sealed class ClanLogicException : SysException
        {
            public int Code { get; }
            public ClanLogicException(int code, string message) : base(message) { Code = code; }
        }

        [BsonIgnoreExtraElements]
        public sealed class ClanDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("id")] public string Id { get; set; }
            [BsonElement("name")] public string Name { get; set; }
            [BsonElement("tag")] public string Tag { get; set; }
            [BsonElement("nameLower")] public string NameLower { get; set; }
            [BsonElement("tagLower")] public string TagLower { get; set; }
            [BsonElement("type")] public int ClanType { get; set; }
            [BsonElement("avatarId")] public string AvatarId { get; set; }
            [BsonElement("description")] public string Description { get; set; }
            [BsonElement("createDate")] public long CreateDate { get; set; }
            [BsonElement("createdAt")] public long CreatedAt { get; set; }
            [BsonElement("membersCount")] public int MembersCount { get; set; }
            [BsonElement("maxMembers")] public int MaxMemberCount { get; set; }
        }

        [BsonIgnoreExtraElements]
        public sealed class ClanMemberDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("playerId")] public string PlayerId { get; set; }
            [BsonElement("roleId")] public int RoleId { get; set; }
            [BsonElement("createDate")] public long CreateDate { get; set; }
        }

        [BsonIgnoreExtraElements]
        public sealed class JoinRequestDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("id")] public string RequestId { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("playerId")] public string PlayerId { get; set; }
            [BsonElement("createDate")] public long CreateDate { get; set; }
            [BsonElement("closeDate")] public long CloseDate { get; set; }
            [BsonElement("requestType")] public int RequestType { get; set; }
            [BsonElement("executionState")] public int ExecutionState { get; set; }
            [BsonElement("isRead")] public bool IsRead { get; set; }
            [BsonElement("closedByPlayerId")] public string ClosedByPlayerId { get; set; }
        }

        [BsonIgnoreExtraElements]
        public sealed class InviteRequestDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("id")] public string RequestId { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("invitedPlayerId")] public string InvitedPlayerId { get; set; }
            [BsonElement("inviterPlayerId")] public string InviterPlayerId { get; set; }
            [BsonElement("createDate")] public long CreateDate { get; set; }
            [BsonElement("closeDate")] public long CloseDate { get; set; }
            [BsonElement("requestType")] public int RequestType { get; set; }
            [BsonElement("executionState")] public int ExecutionState { get; set; }
            [BsonElement("isRead")] public bool IsRead { get; set; }
            [BsonElement("closedByPlayerId")] public string ClosedByPlayerId { get; set; }
        }

        [BsonIgnoreExtraElements]
        public sealed class ClanLogDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("id")] public string Id { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("timestamp")] public long Timestamp { get; set; }
            [BsonElement("messageType")] public int MessageType { get; set; }
            [BsonElement("clanLogType")] public int ClanLogType { get; set; }
            [BsonElement("primaryPlayerId")] public string PrimaryPlayerId { get; set; }
            [BsonElement("secondaryPlayerId")] public string SecondaryPlayerId { get; set; }
            [BsonElement("changedClanType")] public int ChangedClanType { get; set; }
            [BsonElement("changedClanName")] public string ChangedClanName { get; set; }
            [BsonElement("changedClanTag")] public string ChangedClanTag { get; set; }
            [BsonElement("changedMaxMemberCount")] public int ChangedMaxMemberCount { get; set; }
            [BsonElement("assignedRole")] public int AssignedRole { get; set; }
        }
    }
}
