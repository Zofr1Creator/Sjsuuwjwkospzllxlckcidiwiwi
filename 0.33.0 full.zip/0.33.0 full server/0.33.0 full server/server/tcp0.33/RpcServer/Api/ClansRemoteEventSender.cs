using System;
using Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer.Api
{

    public sealed class ClansRemoteEventSender : IEventSender
    {
        private readonly ClientSession _session;
        public string eventListenerName { get; set; } = "ClansRemoteEventListener";

         public ClansRemoteEventSender(ClientSession user) { _session = user; }

         public void SendEvent(string eventName, object[] parameters)
        {
            EventResponse envelope = BoltEventContract.Create(
                eventListenerName,
                eventName,
                parameters ?? Array.Empty<object>());
             _session.SendResponse(new ResponseMessage { EventResponse = envelope });
        }
        public void SendRawEvent(string eventName, byte[] payload)
        {
            EventResponse envelope = BoltEventContract.CreateRaw(
                eventListenerName,
                eventName,
                payload ?? Array.Empty<byte>());
            _session.SendResponse(new ResponseMessage { EventResponse = envelope });
        }
    }
}
