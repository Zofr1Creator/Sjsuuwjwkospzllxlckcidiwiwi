using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    public sealed class GameSeasonRemoteService : RpcHandler
    {
        public GameSeasonRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request)
        {
           if (!string.Equals(request.MethodName, "getGameSeasons2", StringComparison.Ordinal) &&
                !string.Equals(request.MethodName, "getGameSeasons", StringComparison.Ordinal))
           {
               ContractWire.SendException(_session, request.Id, 404);
                return;
            }

            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) ||
                string.IsNullOrWhiteSpace(playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }

            try

             {
                string current = PlayerStatsRemoteService.SeasonId;

               var ids = new List<string>();
                for (int season = 1; season <= 9; season++)
                    ids.Add($"season-{season}");

                foreach (string seasonId in BoltGameDatabaseProvider.Instance.GetKnownSeasonIds())
                {
                    string normalized = (seasonId ?? string.Empty).Trim();
                    if (normalized.Length != 0 && !ids.Contains(normalized, StringComparer.Ordinal))
                        ids.Add(normalized);
                }

                if (!ids.Contains(current, StringComparer.Ordinal))
                    ids.Add(current);

                byte[] response = ContractWire.Build(w =>
                {
                    foreach (string seasonId in ids)
                    {
                     string name = string.Equals(seasonId ,current,  StringComparison.Ordinal)
                            ? PlayerStatsRemoteService.SeasonName
                           : PlayerStatsRemoteService.SeasonTitle(seasonId);
                        byte[] gameSeason = ContractWire.Build(sw =>
                        {
                            sw.String(1, seasonId );
                            sw.String(2, name);
                        });
                           w.Message(1, gameSeason);
                    }
                });

                ContractWire.SendRaw(_session, request.Id, response);
            }
            catch (System.Exception)
            {
                ContractWire.SendException(_session, request.Id, 500);
            }
       }
    }
}
