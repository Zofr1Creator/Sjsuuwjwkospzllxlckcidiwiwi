using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{

    internal static class PlayerLevelRuntime
    {
        public const string EventId = "GLOBAL_LEVELS_REWORKED";

        public const string PassCode = "FreePass";
        public const string PassId = "GLOBAL_LEVELS_REWORKED:FreePass";

        private const string ConfigCollection = "player_levels_config";

        private const string StateCollection = "battle_pass_player_states";
private const int PrestigeLevel = 300;

        private const int MaterializedLevelCount = 301;

        private const int FragmentBoxItemDefinitionId = 900;

        private const int PrestigeTotalXp = 4813795;

        public const int RecurringCarrierLevel = 301;

        public const int RecurringXpStep = 35000;

        public readonly struct Snapshot
        {
            public Snapshot(
                int xp,
                int level,
                int gamePassLevel,
                int levelXp,
                int nextLevelXp,
                int maxLevel)

            {
                Xp = xp;
                Level = level;
                GamePassLevel = gamePassLevel;
                 LevelXp = levelXp;
                NextLevelXp = nextLevelXp;
                MaxLevel = maxLevel;


            }
            public int Xp { get; }

            public int Level { get; }

            public int GamePassLevel { get; }
            public int LevelXp { get; }
           public int NextLevelXp { get; }
            public int MaxLevel { get; }
        }

        private static IMongoDatabase Database => BoltGameDatabaseProvider.Instance.GetDatabase();

        public static Snapshot GetSnapshot(string playerId)
        {
            BattlePassDefinition definition=GetDefinition();
             int xp=ReadXp(playerId);
            List<GamePassLevel> levels=definition.Passes[PassCode];
            int carrier=levels.Where(x=>x.MinPoints<=xp).Select(x=>x.Level).DefaultIfEmpty(1).Max();
            carrier=Math.Max(1,Math.Min(carrier,RecurringCarrierLevel));

           GamePassLevel cur=levels.First(x=>x.Level==carrier);
            if(carrier < RecurringCarrierLevel)
            {
               GamePassLevel next=levels.FirstOrDefault(x=>x.Level==carrier+1);
                int span=next==null?0:Math.Max(0,next.MinPoints-cur.MinPoints);
                 return new Snapshot(xp,carrier,carrier,Math.Max(0,xp-cur.MinPoints),span,PrestigeLevel);
             }

            int extra=Math.Max(0,xp-cur.MinPoints);
           
            int repeats=extra/RecurringXpStep;
          
            int actualLevel=RecurringCarrierLevel+repeats;
           
            int within=extra%RecurringXpStep;
            return new Snapshot(xp,actualLevel,RecurringCarrierLevel,within,RecurringXpStep,PrestigeLevel);
        }

        public static BattlePassDefinition GetDefinition()
        {
            BsonDocument cfg=LoadConfig();
            string passCode=PassCode;
            var d=new BattlePassDefinition
            {
                Id=EventId, Code=EventId, DateSince=1577836800L,
             
                DateUntil=2082758400L, DurationDays=5844, CurrentDay=0,
             
                GoldPassItemDefinitionId=0
            };
            var levels=new List<GamePassLevel>();
            if(cfg.TryGetValue("levels",out BsonValue lv) && lv.IsBsonArray)
            {
                foreach(BsonValue v in lv.AsBsonArray)
                {
                    if(!v.IsBsonDocument) continue;
                    BsonDocument x=v.AsBsonDocument;
                    int logical=Math.Max(1,x.GetValue("level",levels.Count+1).ToInt32());
                    int min=Math.Max(0,x.GetValue("minPoints",0).ToInt32());
                    levels.Add(new GamePassLevel
                    {
                        Level=logical,
                        MinPoints=min,
                        Reward=MakeReward(x.GetValue("reward",BsonNull.Value))
                    });
                }
            }
            levels=levels.OrderBy(x=>x.Level).ThenBy(x=>x.MinPoints).ToList();
            if(levels.Count==0) levels=DefaultLevels();
             d.Passes[passCode]=levels;
            CheckLevelList(d);
            return d;
        }

       public static BattlePassPlayerStateDocument GetState(string playerId, BattlePassDefinition definition=null)
        {
            definition ??= GetDefinition();
            string passCode=definition.Passes.Keys.First();
            Snapshot s=GetSnapshot(playerId);
            IMongoCollection<BattlePassPlayerStateDocument> states=Database.GetCollection<BattlePassPlayerStateDocument>(StateCollection);
            BattlePassPlayerStateDocument state=states.Find(x=>x.PlayerId==playerId && x.EventId==EventId).FirstOrDefault();
            if(state==null)
            {
                state=new BattlePassPlayerStateDocument
                {
                    Id=ObjectId.GenerateNewId(), PlayerId=playerId, EventId=EventId,
                    ClaimedRewards=new List<string>(), ChallengePoints=new Dictionary<string,int>(),
                    CompletedChallenges=new List<string>(), Levels=new Dictionary<string,int>(),
                    UpdatedAtUtc=DateTime.UtcNow
                };
            }
            state.Points=s.Xp;
            state.Levels ??= new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
            state.ClaimedRewards ??= new List<string>();
            state.Levels.Clear();
            state.Levels[passCode]=s.GamePassLevel;
            state.UpdatedAtUtc=DateTime.UtcNow;
            states.ReplaceOne(x=>x.Id==state.Id,state,new ReplaceOptions{IsUpsert=true});
            return state;
        }
        public static void SaveState(BattlePassPlayerStateDocument state)
        {
            if(state==null) return;
           state.UpdatedAtUtc=DateTime.UtcNow;
            Database.GetCollection<BattlePassPlayerStateDocument>(StateCollection)
                .ReplaceOne(x=>x.Id==state.Id,state,new ReplaceOptions{IsUpsert=true});
        }

       public static IReadOnlyList<int> GetClaimableLevels(BattlePassDefinition definition, BattlePassPlayerStateDocument state, string passCode=null)
        {
            passCode=NormalizePassCode(definition,passCode);
            if(!definition.Passes.TryGetValue(passCode,out List<GamePassLevel> levels)) return Array.Empty<int>();
            int current=state.Levels.TryGetValue(passCode,out int c)?c:1;
            return levels.Where(x=>x.Level>1 && x.Level<=current && !state.ClaimedRewards.Contains(passCode+":"+x.Level))
                .Select(x=>x.Level).OrderBy(x=>x).ToArray();
        }

        public static string NormalizePassCode(BattlePassDefinition definition,string passIdOrCode)
        {
            string first=definition.Passes.Keys.First();
            if(string.IsNullOrWhiteSpace(passIdOrCode)) return first;
            if(definition.Passes.ContainsKey(passIdOrCode)) return passIdOrCode;
            foreach(string key in definition.Passes.Keys)
               if(string.Equals(definition.Id+":"+key,passIdOrCode,StringComparison.OrdinalIgnoreCase)) return key;
            return passIdOrCode;
        }

        public static void NormalizePersistedStats(string playerId)
        {
            Snapshot s=GetSnapshot(playerId);
             Database.GetCollection<BsonDocument>("stats").UpdateOne(
                Builders<BsonDocument>.Filter.Eq("playerId",playerId),
                Builders<BsonDocument>.Update
                    .Set("stats.level",s.Level).Set("stats.level_id",s.Level)
                    .Set("stats.level_xp",s.LevelXp).Set("stats.next_level_xp",s.NextLevelXp)
                    .Set("stats.total_xp_earned",s.Xp), new UpdateOptions{IsUpsert=true});

            GrantPendingUnlockedRewards(playerId, s.Level);
        }

        public static Reward GrantPendingUnlockedRewards(string playerId, int currentLevel)
        {
            var aggregate=new Reward();
            if (string.IsNullOrWhiteSpace(playerId) || currentLevel < 2) return aggregate;

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition=GetDefinition();
                 BattlePassPlayerStateDocument state=GetState(playerId, definition);
                string passCode=NormalizePassCode(definition, PassCode);
                if (!definition.Passes.TryGetValue(passCode, out List<GamePassLevel> levels)) return aggregate;

                int unlocked=state.Levels.TryGetValue(passCode, out int persistedLevel)
                    ? Math.Max(1, persistedLevel)
                    : Math.Max(1, currentLevel);
                unlocked=Math.Min(unlocked, RecurringCarrierLevel);

                int claimed=0;
                foreach (GamePassLevel level in levels
                    .Where(x=>x.Level>1 && x.Level<=unlocked)
                    .OrderBy(x=>x.Level))
                {
                    string claimKey=passCode+":"+level.Level;
                    if (state.ClaimedRewards.Contains(claimKey)) continue;

                    try
                    {
                        RewardInfo rewardInfo=level.Reward ?? new RewardInfo();
                        Reward granted=BattlePassRuntime.GrantRewardInfo(playerId, rewardInfo);
                        BattlePassRuntime.MergeReward(aggregate, granted);
                        state.ClaimedRewards.Add(claimKey);
                        claimed++;
                    }
                    catch
                    {
                        continue;
                    }
                }

                if (claimed==0) return aggregate;

                SaveState(state);
                if (aggregate.Items.Count>0 || aggregate.Currencies.Count>0)
                    InventoryEventBus.InventoryChanged(
                        playerId,
                        added: aggregate.Items,
                        currencies: aggregate.Currencies,
                        source: "xp-level-auto-claim");

                return aggregate;
            }
        }

        public static Reward SettleUnlockedRewardsForGameEventPath(string playerId, string source)
        {
            try
            {
                Snapshot snapshot=GetSnapshot(playerId);
                Reward granted=GrantPendingUnlockedRewards(playerId, snapshot.Level);
                return granted;
            }
            catch
            {
                return new Reward();
            }
        }

        private static int ReadXp(string playerId)
        {
           try
            {
                BsonDocument doc=Database.GetCollection<BsonDocument>("stats")
                    .Find(Builders<BsonDocument>.Filter.Eq("playerId",playerId)).FirstOrDefault();
                if(doc!=null && doc.TryGetValue("stats",out BsonValue sv) && sv.IsBsonDocument)
                    return Math.Max(0,sv.AsBsonDocument.GetValue("xp_reworked",0).ToInt32());
             }
            catch { }
            return 0;
        }

        private static RewardInfo MakeReward(BsonValue value)
        {
            var reward=new RewardInfo();
            if(value==null || !value.IsBsonDocument) return reward;
            BsonDocument d=value.AsBsonDocument;
            if(d.TryGetValue("currencies", out BsonValue currencies) && currencies.IsBsonArray)
            {
                foreach(BsonValue cv in currencies.AsBsonArray)
                {
                    if(!cv.IsBsonDocument) continue;
                    BsonDocument c=cv.AsBsonDocument;
                    int id=Math.Max(0,c.GetValue("id",0).ToInt32());
                    int amount=Math.Max(0,c.GetValue("amount",0).ToInt32());
                    if(id>0 && amount>0) reward.Currencies.Add(new CurrencyAmount{CurrencyId=id,Value=amount});
                }
            }
            if(d.TryGetValue("items", out BsonValue items) && items.IsBsonArray)
             {
                foreach(BsonValue iv in items.AsBsonArray)
                {
                    if(!iv.IsBsonDocument) continue;
                    BsonDocument i=iv.AsBsonDocument;
                    int id=Math.Max(0,i.GetValue("id",0).ToInt32());
                    int amount=Math.Max(0,i.GetValue("amount",0).ToInt32());
                    if(id>0 && amount>0) reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=id,Value=amount});
                 }
            }
            if(reward.Currencies.Count>0 || reward.Items.Count>0) return reward;

            string type=d.GetValue("type","").AsString.ToLowerInvariant();
            int legacyAmount=Math.Max(0,d.GetValue("amount",0).ToInt32());
            int legacyId=Math.Max(0,d.GetValue("id",0).ToInt32());
            if(type=="coins" || type=="currency") reward.Currencies.Add(new CurrencyAmount{CurrencyId=legacyId>0?legacyId:101,Value=legacyAmount});
            else if(type=="gold") reward.Currencies.Add(new CurrencyAmount{CurrencyId=102,Value=legacyAmount});
            else if(type=="item" && legacyId>0 && legacyAmount>0) reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=legacyId,Value=legacyAmount});
            return reward;
        }

        private static BsonDocument LoadConfig()
        {
            IMongoCollection<BsonDocument> c=Database.GetCollection<BsonDocument>(ConfigCollection);
            BsonDocument cfg=c.Find(Builders<BsonDocument>.Filter.Eq("_id","default")).FirstOrDefault();
bool badLevelShape=true;
            if(cfg!=null && cfg.TryGetValue("levels", out BsonValue existingLevels) && existingLevels.IsBsonArray)
            {
                BsonArray arr=existingLevels.AsBsonArray;
                BsonDocument level2=arr.Where(x=>x.IsBsonDocument).Select(x=>x.AsBsonDocument).FirstOrDefault(x=>x.GetValue("level",0).ToInt32()==2);
                BsonDocument recurring=arr.Where(x=>x.IsBsonDocument).Select(x=>x.AsBsonDocument).FirstOrDefault(x=>x.GetValue("level",0).ToInt32()==RecurringCarrierLevel);
                badLevelShape=arr.Count!=MaterializedLevelCount || level2==null || level2.GetValue("minPoints",0).ToInt32()!=300 || recurring==null;
            }
            bool needsMigration = cfg == null || badLevelShape;
            if(!needsMigration) return cfg;

            var levels=new BsonArray();


            foreach(GamePassLevel l in DefaultLevels())
            {
                BsonDocument reward=RewardDocument(l.Level, l.Reward);
                levels.Add(new BsonDocument{{"level",l.Level},{"minPoints",l.MinPoints},{"reward",reward}});
            }

            cfg=new BsonDocument
           {
                ["_id"]="default", ["eventId"]=EventId, ["passCode"]=PassCode,
                ["prestigeLevel"]=PrestigeLevel,
               ["prestigeFrameItemDefinitionId"]=7030,
                ["postPrestigeFragmentBoxesPerLevel"]=3,
                ["recurringCarrierLevel"]=RecurringCarrierLevel,
                ["recurringXpStep"]=RecurringXpStep,
                ["levels"]=levels
            };
            c.ReplaceOne(Builders<BsonDocument>.Filter.Eq("_id","default"), cfg, new ReplaceOptions{IsUpsert=true});
            return cfg;
        }

        private static BsonDocument RewardDocument(int level, RewardInfo reward)
        {
           var currencies=new BsonArray();
            var items=new BsonArray();
            if(reward!=null)
           {
                foreach(CurrencyAmount currency in reward.Currencies)
                    if(currency.CurrencyId>0 && currency.Value>0)
                        currencies.Add(new BsonDocument{{"id",currency.CurrencyId},{"amount",Math.Max(1,(int)currency.Value)}});
               foreach(InventoryItemAmount item in reward.Items)
                     if(item.InventoryItemDefinitionId>0 && item.Value>0)
                        items.Add(new BsonDocument{{"id",item.InventoryItemDefinitionId},{"amount",Math.Max(1,item.Value)}});
            }
            return new BsonDocument{{"currencies",currencies},{"items",items}};
        }

        private static int MinFallbackPoints(int level)
        {
            if(level<=1) return 0;
            if(level>=PrestigeLevel) return PrestigeTotalXp;

            double n=level-1;
            const double quadratic=53.0189558034612;

            const double linear=246.9810441965388 ;

            return (int)Math.Round(quadratic*n*n + linear*n, MidpointRounding.AwayFromZero);
        }

        private static List<GamePassLevel> DefaultLevels()
        {

            int[] boxes = {404,405,407,408,409,312,320,328,348,350};
            int[] cases = {304,305,307,308,309,311,319,329,347,351,359};
           int[] arcaneCases = {310,318,321,349,358};

            var result=new List<GamePassLevel>(MaterializedLevelCount);
            int previousMin=0;
            int boxCursor=0, caseCursor=0, arcaneCursor=0;

            for(int level=1; level<=PrestigeLevel; level++)
            {
                int min=MinFallbackPoints(level);
                if(level>1 && min<=previousMin) min=previousMin+1;
                previousMin=min;

                var reward=new RewardInfo();

                if(level%10==0)
                {
                    int frameDefinitionId=7000+(level/10);
                   reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=frameDefinitionId,Value=1});
               }

                else if (level%50==49)
               {
                    int id=arcaneCases[arcaneCursor++%arcaneCases.Length];
                    reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=id,Value=1});
                }

               else if (level%25==0)
                {
                     int id=cases[caseCursor++%cases.Length];
                    reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=id,Value=1});
                }

                else if (level%15==0)
                {
                    int id=boxes[boxCursor++%boxes.Length];
                   reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=id,Value=1});
                }

                else if (level%7==0)
                {
                    int amount = level>=200 ? 3 : (level>=100 ? 2 : 1);
                    reward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=FragmentBoxItemDefinitionId,Value=amount});
                }

                else if (level%20==5)
                {
                    int gold = 10 + (level/50)*5;
                    reward.Currencies.Add(new CurrencyAmount{CurrencyId=102,Value=gold});
                }
                else
               {
                    int coins = 75 + ((level-1)/25)*25;
                    reward.Currencies.Add(new CurrencyAmount{CurrencyId=101,Value=coins});
                }

                result.Add(new GamePassLevel{Level=level,MinPoints=min,Reward=reward});
            }

            var recurringReward=new RewardInfo();
            recurringReward.Items.Add(new InventoryItemAmount{InventoryItemDefinitionId=FragmentBoxItemDefinitionId,Value=3});
            result.Add(new GamePassLevel
            {
                Level=RecurringCarrierLevel,
                MinPoints=PrestigeTotalXp+RecurringXpStep,
                Reward=recurringReward
            });
            return result;
        }
        private static void CheckLevelList(BattlePassDefinition definition)
        {
            if (definition == null || !string.Equals(definition.Id, EventId, StringComparison.Ordinal))
                throw new InvalidOperationException("bad level event id");
            if (!definition.Passes.TryGetValue(PassCode, out List<GamePassLevel> levels) || levels == null || levels.Count != MaterializedLevelCount)
                throw new InvalidOperationException("level list");
            if (levels[0].Level != 1 || levels[1].Level != 2 || levels[1].MinPoints != 300)
                throw new InvalidOperationException("level xp start");
            if (levels.Select(x=>x.Level).Distinct().Count()!=levels.Count || levels.Zip(levels.Skip(1),(a,b)=>b.Level==a.Level+1 && b.MinPoints>a.MinPoints).Any(ok=>!ok))
                throw new InvalidOperationException("bad level");
            int FrameAt(int level) => levels.First(x => x.Level == level).Reward?.Items?.FirstOrDefault(i => i.InventoryItemDefinitionId >= 7001 && i.InventoryItemDefinitionId <= 7030)?.InventoryItemDefinitionId ?? 0;
            if (FrameAt(10) != 7001 || FrameAt(300) != 7030)
                throw new InvalidOperationException("bad frame");
            if(levels.Where(x=>x.Level<=PrestigeLevel).Any(x=>x.Reward==null || (x.Reward.Items.Count==0 && x.Reward.Currencies.Count==0)))
                throw new InvalidOperationException("empty level");
            if(levels.Where(x=>x.Level<=PrestigeLevel).Any(x=>
                (x.Reward.Items.Count + x.Reward.Currencies.Count) != 1))
               throw new InvalidOperationException("too many rewards");
           GamePassLevel recurring=levels.First(x=>x.Level==RecurringCarrierLevel);
            int recurringItem=recurring.Reward?.Items?.FirstOrDefault()?.InventoryItemDefinitionId ?? 0;
           if(recurringItem!=FragmentBoxItemDefinitionId || recurring.MinPoints!=PrestigeTotalXp+RecurringXpStep)
                throw new InvalidOperationException("recurring reward");
        }

    }
}
