using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using RpcException = Axlebolt.RpcSupport.Protobuf.Exception;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    public sealed class CoreRemoteService : RpcHandler
    {
        private readonly string _serviceName;

        private static readonly object _economyLock = new();

        public CoreRemoteService(ClientSession user, string serviceName) : base(user)
        {
            _serviceName = serviceName ?? string.Empty;
        }

        public override void Invoke(RpcRequest request)
        {
            string method = request?.MethodName ?? string.Empty;

            string id = request?.Id ?? string.Empty;
            try
            {
                switch (_serviceName)
                {
                    case "NewsFeedRemoteService": ProcessNews(request); return;
                    case "GameAnnouncementRemoteService": ProcessAnnouncements(request); return;
                    case "ContentCreatorRemoteService": ProcessCreator(request); return;
                    case "InAppRemoteService": ProcessInApp(request); return;
                    case "AchievementRemoteService": ProcessAchievements(request); return;
                    case "OffersRemoteService": ProcessOffers(request); return;
                    case "AccountLinkRemoteService": ProcessAccountLink(request); return;
                    case "ReferralRemoteService": ProcessReferral(request); return;
                    case "GdprRemoteService": ProcessGdpr(request); return;
                    case "DlcRemoteService": ProcessDlc(request); return;
                    case "RateGameRemoteService": ProcessRateGame(request); return;
                    default: SendError(id, 404, "unknown service", method); return;
                }
            }
            catch (FeatureRpcException ex)
            {
                SendError(id, ex.Code, ex.Message, method);
            }
            catch (System.Exception)
            {
                SendError(id, 500, "internal server error", method);
            }
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }

        private void ProcessNews(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getItems":
                case "getItems2":
                case "getNews":
                case "getNewsFeed":
                {
                    byte[] raw = ContractWire.Param(request);
                    int from = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
                    int count = Math.Clamp(ContractWire.ReadIntField(raw, 2, 30), 1, 100);
                    long now = NowMs();
                    List<BsonDocument> docs = GetCollection("news_feed")
                        .Find(Builders<BsonDocument>.Filter.Ne("enabled", false) &
                                (Builders<BsonDocument>.Filter.Eq("publishAt", BsonNull.Value) |
                                Builders<BsonDocument>.Filter.Lte("publishAt", now)))
                        .Sort(Builders<BsonDocument>.Sort.Descending("timestamp"))
                        .Skip(from).Limit(count).ToList();
                    byte[] response = ContractWire.Build(w =>
                    {
                        foreach (BsonDocument d in docs) w.Message(1, SerializeNewsItem(d));
                    });
                    Send(request.Id, response);
                    return;
                }
                case "sendNews":
                {
                    string playerId = RequirePlayer();
                    string definitionId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
                    if (definitionId.Length == 0) throw new FeatureRpcException(400, "empty news definition id");
                    BsonDocument definition = GetCollection("news_feed_definitions").Find(Builders<BsonDocument>.Filter.Eq("definitionId", definitionId)).FirstOrDefault();
                    string text = ReadString(definition, "itemText", definitionId);
                    GetCollection("news_feed").InsertOne(new BsonDocument
                    {
                        ["id"] = Guid.NewGuid().ToString("N"), ["definitionId"] = definitionId,
                        ["gpid"] = playerId, ["itemText"] = text, ["timestamp"] = NowMs(), ["enabled"] = true
                    });
                    ContractWire.SendEmpty(_session, request.Id);
                    return;
                }
                default: throw new FeatureRpcException(404, "news method is not supported");
            }
        }

        private static byte[] SerializeNewsItem(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "id", GetDocumentId(d)));
            w.String(2, ReadString(d, "definitionId"));
            w.String(3, ReadString(d, "gpid"));
            w.String(4, ReadString(d, "itemText"));
            w.Varint(5, ReadLong(d, "timestamp"));
        });

        private void ProcessAnnouncements(RpcRequest request)
        {
            if (request.MethodName != "getAllGameAnnouncements" && request.MethodName != "getAllAnnouncements" && request.MethodName != "getAnnouncements")
                throw new FeatureRpcException(404, "announcement method is not supported");
            long now = NowMs();
            List<BsonDocument> docs = GetCollection("game_announcements")
                .Find(Builders<BsonDocument>.Filter.Ne("enabled", false) &
                        (Builders<BsonDocument>.Filter.Eq("dateSince", BsonNull.Value) | Builders<BsonDocument>.Filter.Lte("dateSince", now)) &
                        (Builders<BsonDocument>.Filter.Eq("untilDate", BsonNull.Value) | Builders<BsonDocument>.Filter.Eq("untilDate", 0) | Builders<BsonDocument>.Filter.Gt("untilDate", now)))
                .Sort(Builders<BsonDocument>.Sort.Descending("pinned").Descending("date"))
                .ToList();
            Send(request.Id, ContractWire.Build(w =>
            {
                foreach (BsonDocument d in docs) w.Message(1, SerializeAnnouncement(d));
            }));
        }

        private static byte[] SerializeAnnouncement(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "id", GetDocumentId(d)));
            w.String(2, ReadString(d, "title"));
            w.String(3, ReadString(d, "body"));
            w.String(4, ReadString(d, "resourceUrl"));
            w.Varint(5, ReadLong(d, "date"));
            foreach (BsonValue link in ReadArray(d, "links"))
            {
                string url = link.IsBsonDocument ? ReadString(link.AsBsonDocument, "url") : link.ToString();
                w.Message(6, ContractWire.Build(x => x.String(2, url)));
            }
            foreach (BsonValue tag in ReadArray(d, "tags")) w.String(7, tag.ToString());
            w.Bool(8, ReadBool(d, "pinned"));
            foreach (BsonValue property in ReadArray(d, "properties"))
                if (property.IsBsonDocument) w.Message(9, SerializeProperty(property.AsBsonDocument));
            w.String(10, ReadString(d, "code"));
            w.Varint(11, ReadLong(d, "untilDate"));
        });

        private void ProcessCreator(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "findCreator":
                case "findCreatorByCode":
                {
                    string code = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim().ToUpperInvariant();
                    BsonDocument creator = FindActiveCreator(code);
                    if (creator == null) throw new FeatureRpcException(404, "creator not found");
                    byte[] response = ContractWire.Build(w => w.Message(1, SerializeCreator(creator, 0)));
                    Send(request.Id, response);
                    return;
                }
                case "subscribeCreator":
                case "subscribeToCreator":
                {
                    string playerId = RequirePlayer();
                    string code = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim().ToUpperInvariant();
                    BsonDocument creator = FindActiveCreator(code);
                    if (creator == null) throw new FeatureRpcException(404, "creator not found");
                    long until = NowMs() + Math.Max(1, ReadInt(creator, "subscriptionDays", 14)) * 86400000L;
                    GetCollection("creator_subscriptions").ReplaceOne(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        new BsonDocument { ["playerId"] = playerId, ["code"] = code, ["until"] = until, ["updatedAt"] = NowMs() },
                        new ReplaceOptions { IsUpsert = true });
                    Send(request.Id, ContractWire.Build(w => w.Message(1, SerializeCreator(creator, until))));
                    return;
                }
                case "getSubscribedCreator":
                case "findCreatorSubscription":
                {
                    string playerId = RequirePlayer();
                    BsonDocument sub = GetCollection("creator_subscriptions").Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
                    if (sub == null || ReadLong(sub, "until") <= NowMs()) { Send(request.Id, Array.Empty<byte>()); return; }
                    BsonDocument creator = FindActiveCreator(ReadString(sub, "code"));
                    if (creator == null) { Send(request.Id, Array.Empty<byte>()); return; }
                    Send(request.Id, ContractWire.Build(w => w.Message(1, SerializeCreator(creator, ReadLong(sub, "until")))));
                    return;
                }
                case "unsubscribeCreator":
                case "unsubscribeFromCreator":
                    GetCollection("creator_subscriptions").DeleteMany(Builders<BsonDocument>.Filter.Eq("playerId", RequirePlayer()));
                    ContractWire.SendEmpty(_session, request.Id); return;
                default: throw new FeatureRpcException(404, "creator method is not supported");
            }
        }

        private void ProcessInApp(RpcRequest request)
        {
            if (request.MethodName == "findCreatorSubscription" || request.MethodName.Contains("Creator", StringComparison.Ordinal))
            {
                ProcessCreator(request);
                return;
            }
            if (request.MethodName == "getProducts" || request.MethodName == "getInApps" || request.MethodName == "getSubscriptions")
            {
                ContractWire.SendEmpty(_session, request.Id);
                return;
            }
            throw new FeatureRpcException(404, "in-app method is not supported");
        }

        private BsonDocument FindActiveCreator(string code)
        {
            if (string.IsNullOrWhiteSpace(code)) return null;
            return GetCollection("content_creators").Find(
                Builders<BsonDocument>.Filter.Eq("code", code) & Builders<BsonDocument>.Filter.Ne("enabled", false)).FirstOrDefault();
        }

        public static bool IsKnownCreatorCode(string code)
        {
            if (string.IsNullOrWhiteSpace(code)) return false;
            try
            {
                string normalized = code.Trim().ToUpperInvariant();
                IMongoCollection<BsonDocument> creators = BoltMainDatabaseProvider.Instance
                    .GetDatabase().GetCollection<BsonDocument>("content_creators");
                return creators.CountDocuments(
                    Builders<BsonDocument>.Filter.Eq("code", normalized) &
                    Builders<BsonDocument>.Filter.Ne("enabled", false)) > 0;
            }
            catch { return false; }
        }

        private static byte[] SerializeCreator(BsonDocument d, long until) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "code"));
            w.String(2, ReadString(d, "nickName", ReadString(d, "nickname")));
            w.Varint(3, until);
        });

        private void ProcessAchievements(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getAchievementDefinitions":
                {
                    List<BsonDocument> definitions = GetCollection("achievement_definitions").Find(Builders<BsonDocument>.Filter.Ne("enabled", false)).Sort(Builders<BsonDocument>.Sort.Ascending("order")).ToList();
                    Send(request.Id, ContractWire.Build(w => { foreach (BsonDocument d in definitions) w.Message(1, SerializeAchievementDefinition(d)); }));
                    return;
                }
                case "getCurrentPlayerAchievements":
                case "getPlayerAchievements":
                {
                    string playerId = request.MethodName == "getPlayerAchievements"
                        ? ContractWire.ReadStringField(ContractWire.Param(request), 1, RequirePlayer())
                        : RequirePlayer();
                    bool showLocked = request.MethodName == "getCurrentPlayerAchievements"
                        ? ContractWire.ReadBoolField(ContractWire.Param(request), 1, true)
                        : ContractWire.ReadBoolField(ContractWire.Param(request), 2, true);
                    List<BsonDocument> definitions = GetCollection("achievement_definitions").Find(Builders<BsonDocument>.Filter.Ne("enabled", false)).Sort(Builders<BsonDocument>.Sort.Ascending("order")).ToList();
                    BsonDocument stats = GetStatsDocument(playerId);
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        foreach (BsonDocument d in definitions)
                        {
                            int current = AchievementProgress(d, stats);
                            int target = Math.Max(1, ReadInt(d, "target", 1));
                            if (!showLocked && current < target) continue;
                            w.Message(1, SerializePlayerAchievement(d, current, target, current >= target ? ReadUnlockDate(playerId, ReadString(d, "id")) : 0));
                            UpsertAchievementState(playerId, d, current, target);
                        }
                    }));
                    return;
                }
                default: throw new FeatureRpcException(404, "achievement method is not supported");
            }
        }

        private static byte[] SerializeLocalizedTitle(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "title", ReadString(d, "name")));
            w.String(2, ReadString(d, "description"));
            w.String(3, ReadString(d, "resourceUrl"));
        });

        private static byte[] SerializeAchievementDefinition(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "id", GetDocumentId(d)));
            w.String(2, ReadString(d, "key"));
            w.Message(3, SerializeLocalizedTitle(d));
            w.String(4, ReadString(d, "imageLocked"));
            w.String(5, ReadString(d, "imageUnlocked"));
        });

        private static byte[] SerializePlayerAchievement(BsonDocument d, int current, int target, long unlockDate) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "id", GetDocumentId(d)));
            w.String(2, ReadString(d, "key"));
          
            w.Message(3, SerializeLocalizedTitle(d));
            w.String(4, ReadString(d, "imageLocked"));
            w.String(5, ReadString(d, "imageUnlocked"));
            w.Int32(6, current);
            w.Int32(7, target);
            w.Varint(8, unlockDate);
        });

        private static int AchievementProgress(BsonDocument def, BsonDocument stats)
        {
            string statId = ReadString(def, "statId");
            if (string.IsNullOrWhiteSpace(statId)) return 0;
            return ReadNestedInt(stats, "stats", statId);
        }

        private void UpsertAchievementState(string playerId, BsonDocument def, int current, int target)
        {
            string id = ReadString(def, "id", GetDocumentId(def));
            var update = Builders<BsonDocument>.Update.Set("progressCurrent", current).Set("progressTarget", target).Set("updatedAt", NowMs());
            if (current >= target) update = update.SetOnInsert("unlockDate", NowMs());
          
            GetCollection("player_achievements").UpdateOne(
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("achievementId", id),
                update.SetOnInsert("playerId", playerId).SetOnInsert("achievementId", id), new UpdateOptions { IsUpsert = true });
        }

        private long ReadUnlockDate(string playerId, string achievementId)
        {
            BsonDocument d = GetCollection("player_achievements").Find(
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("achievementId", achievementId)).FirstOrDefault();
            return ReadLong(d, "unlockDate", NowMs());
        }

        private void ProcessOffers(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getSpecialOffers":
                {
                    string playerId = RequirePlayer();
                    long now = NowMs();
                    List<BsonDocument> docs = GetCollection("special_offers").Find(
                        Builders<BsonDocument>.Filter.Ne("enabled", false) &
                        (Builders<BsonDocument>.Filter.Eq("dateSince", 0) | Builders<BsonDocument>.Filter.Lte("dateSince", now)) &
                        (Builders<BsonDocument>.Filter.Eq("dateUntil", 0) | Builders<BsonDocument>.Filter.Gt("dateUntil", now))).ToList();
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        foreach (BsonDocument d in docs)
                        {
                            int limit = ReadInt(d, "offersCount", 1);
                            long accepted = GetCollection("offer_acceptances").CountDocuments(
                                Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("offerId", ReadString(d, "id", GetDocumentId(d))));
                            if (limit > 0 && accepted >= limit) continue;
                            w.Message(1, SerializeSpecialOffer(d));
                        }
                    }));
                    return;
                }
                case "acceptSpecialOffer":
                {
                    string playerId = RequirePlayer();
                    string offerId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
                    BsonDocument offer = GetCollection("special_offers").Find(Builders<BsonDocument>.Filter.Eq("id", offerId) & Builders<BsonDocument>.Filter.Ne("enabled", false)).FirstOrDefault();
                    if (offer == null) throw new FeatureRpcException(404, "offer not found");
                    lock (_economyLock)
                    {
                        int limit = ReadInt(offer, "offersCount", 1);
                        long accepted = GetCollection("offer_acceptances").CountDocuments(Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("offerId", offerId));
                        if (limit > 0 && accepted >= limit) throw new FeatureRpcException(409, "offer limit reached");
                        AwardConfiguredReward(playerId, offer.GetValue("reward", new BsonDocument()).AsBsonDocument);
                        GetCollection("offer_acceptances").InsertOne(new BsonDocument { ["playerId"] = playerId, ["offerId"] = offerId, ["createdAt"] = NowMs() });
                    }
                    ContractWire.SendEmpty(_session, request.Id);
                    return;
                }
                default: throw new FeatureRpcException(404, "offer method is not supported");
            }
        }

        private static byte[] SerializeSpecialOffer(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "id", GetDocumentId(d)));
            w.String(2, ReadString(d, "title"));
            w.String(3, ReadString(d, "body"));
            w.String(4, ReadString(d, "resourceUrl"));
            int type = ReadInt(d, "type", 1);
            w.Int32(5, type);
            BsonDocument reward = d.GetValue("reward", new BsonDocument()).AsBsonDocument;
            if (type == 0)
            {
                w.Message(6, ContractWire.Build(x => { x.String(1, ReadString(d, "productId")); x.Message(2, SerializeRewardInfo(reward)); }));
            }
            else
            {
                w.Message(7, ContractWire.Build(x =>
                {
                    x.String(1, ReadString(d, "itemPackId"));
                    foreach (BsonValue c in ReadArray(d, "price")) if (c.IsBsonDocument) x.Message(2, SerializeCurrencyAmount(c.AsBsonDocument));
                    x.Message(3, SerializeRewardInfo(reward));
                }));
            }
            w.Varint(8, ReadLong(d, "dateUntil"));
            w.Int32(9, ReadInt(d, "offersCount", 1));
            w.Varint(10, ReadLong(d, "dateSince"));
            foreach (BsonValue p in ReadArray(d, "settings")) if (p.IsBsonDocument) w.Message(11, SerializeProperty(p.AsBsonDocument));
            w.String(12, ReadString(d, "key"));
        });

        private void ProcessAccountLink(RpcRequest request)
        {
            string playerId = RequirePlayer();
            switch (request.MethodName)
            {
                case "getLinkedAuth":
                {
                    List<BsonDocument> links = GetCollection("linked_auth").Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).ToList();
                    if (links.Count == 0)
                    {
                        var guest = new BsonDocument { ["playerId"] = playerId, ["authType"] = 1, ["primary"] = true, ["createdAt"] = NowMs() };
                        GetCollection("linked_auth").InsertOne(guest); links.Add(guest);
                    }
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        foreach (BsonDocument d in links) w.Message(1, ContractWire.Build(x => { x.Int32(1, ReadInt(d, "authType", 1)); x.Bool(2, ReadBool(d, "primary")); }));
                    }));
                    return;
                }
                case "linkAuth":
                case "addLinkedAuth":
                {
                    int authType = ContractWire.ReadIntField(ContractWire.Param(request), 1, 1);
                    bool primary = ContractWire.ReadBoolField(ContractWire.Param(request), 2, false);
                    if (primary) GetCollection("linked_auth").UpdateMany(Builders<BsonDocument>.Filter.Eq("playerId", playerId), Builders<BsonDocument>.Update.Set("primary", false));
                    GetCollection("linked_auth").UpdateOne(
                        Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("authType", authType),
                        Builders<BsonDocument>.Update.Set("primary", primary).SetOnInsert("playerId", playerId).SetOnInsert("authType", authType).SetOnInsert("createdAt", NowMs()),
                        new UpdateOptions { IsUpsert = true });
                    ContractWire.SendEmpty(_session, request.Id); return;
                }
                case "unlinkAuth":
                case "removeLinkedAuth":
                {
                    int authType = ContractWire.ReadIntField(ContractWire.Param(request), 1, -1);
                    GetCollection("linked_auth").DeleteMany(Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("authType", authType) & Builders<BsonDocument>.Filter.Ne("primary", true));
                    ContractWire.SendEmpty(_session, request.Id); return;
                }
                default: throw new FeatureRpcException(404, "account link method is not supported");
            }
        }

        private void ProcessReferral(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getReferralSystemSettings":
                case "getSettings":
                {
                    BsonDocument settings = GetCollection("referral_settings").Find(Builders<BsonDocument>.Filter.Empty).FirstOrDefault() ?? new BsonDocument();
                    byte[] s = SerializeReferralSettings(settings);
                    Send(request.Id, ContractWire.Build(writer =>
                    {
                        writer.Message(1, s);
                        writer.Message(2, s);
                    }));
                    return;
                }
                case "subscribeToCommander":
                {
                    string recruitId = RequirePlayer();
                    string commanderUid = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
                    PlayerDocument commander = FindPlayerByUid(commanderUid);
                    if (commander == null) throw new FeatureRpcException(404, "commander not found");
                    if (commander._id.ToString() == recruitId) throw new FeatureRpcException(400, "cannot subscribe to self");
                    GetCollection("referral_states").UpdateOne(Builders<BsonDocument>.Filter.Eq("playerId", recruitId),
                        Builders<BsonDocument>.Update.Set("commanderId", commander._id.ToString()).Set("subscribedAt", NowMs()).Set("state", 0).SetOnInsert("playerId", recruitId),
                        new UpdateOptions { IsUpsert = true });
                    Send(request.Id, ContractWire.Build(w => w.Message(1, SerializePlayer(commander, false)))); return;
                }
                case "getReferralPlayerState":
                case "getPlayerState":
                {
                    string playerId = RequirePlayer();
                    BsonDocument state = GetCollection("referral_states").Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
                    if (state == null) { Send(request.Id, Array.Empty<byte>()); return; }
                    Send(request.Id, ContractWire.Build(w => w.Message(2, ContractWire.Build(x =>
                    {
                        x.Int32(1, ReadInt(state, "state", 0));
                        x.String(2, ReadString(state, "commanderId"));
                        x.Varint(3, ReadLong(state, "subscribedAt"));
                    })))); return;
                }
                case "findReferralState":
                {
                    string uid = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
                    PlayerDocument player = FindPlayerByUid(uid);
                    if (player == null) throw new FeatureRpcException(404, "referral player not found");
                    BsonDocument state = GetCollection("referral_states").Find(Builders<BsonDocument>.Filter.Eq("playerId", player._id.ToString())).FirstOrDefault();
                    Send(request.Id, ContractWire.Build(writer =>
                    {
                        writer.Message(1, SerializePlayer(player, false));
                        writer.Int32(2, ReadInt(state, "state", 0));
                    }));
                    return;
                }
                case "getRecruitById":
                {
                    string gpid = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
                    PlayerDocument player = ObjectId.TryParse(gpid, out ObjectId oid) ? BoltMainDatabaseProvider.Instance.GetPlayerDocument(oid) : null;
                    if (player == null) throw new FeatureRpcException(404, "recruit not found");
                    Send(request.Id, ContractWire.Build(w => w.Message(1, SerializeReferralRecruit(player)))); return;
                }
                case "getRecruitsByOffset":
                {
                    string commanderId = RequirePlayer();
                    byte[] raw = ContractWire.Param(request);
                    int offset = Math.Max(0, ContractWire.ReadIntField(raw, 1, 0));
                    int count = Math.Clamp(ContractWire.ReadIntField(raw, 2, 20), 1, 100);
                    List<BsonDocument> states = GetCollection("referral_states").Find(Builders<BsonDocument>.Filter.Eq("commanderId", commanderId)).Skip(offset).Limit(count).ToList();
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        foreach (BsonDocument s in states)
                        {
                            if (ObjectId.TryParse(ReadString(s, "playerId"), out ObjectId oid))
                            {
                                PlayerDocument p = BoltMainDatabaseProvider.Instance.GetPlayerDocument(oid);
                                if (p != null) w.Message(1, SerializeReferralRecruit(p, s));
                            }
                        }
                        if (states.Count == count) w.String(2, (offset + states.Count).ToString());
                    })); return;
                }
                default: throw new FeatureRpcException(404, "referral method is not supported");
            }
        }

        private static byte[] SerializeReferralSettings(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "recruitGameEventId", "referral_recruit"));
            w.String(2, ReadString(d, "commanderGameEventId", "referral_commander"));
            w.Int32(3, ReadInt(d, "durationDays", 30));
            w.Varint(4, ReadLong(d, "commanderSubscriptionTimeoutMs", 604800000));
            w.Bool(5, ReadBool(d, "enabled", true));
        });

        private static byte[] SerializeReferralRecruit(PlayerDocument p, BsonDocument state = null) => ContractWire.Build(w =>
        {
            w.Message(1, SerializePlayer(p, false));
            w.Bool(2, ReadBool(state, "achievedThreshold"));
            w.Varint(3, ReadLong(state, "subscribedAt"));
            w.Message(4, ContractWire.Build(x => { x.Int32(1, ReadInt(state, "progressPoints")); x.Bool(2, ReadBool(state, "completedOnTime")); }));
        });

        private void ProcessGdpr(RpcRequest request)
        {
            string playerId = RequirePlayer();
            BsonDocument d = GetCollection("gdpr_states").Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            switch (request.MethodName)
            {
                case "getState":
                    Send(request.Id, ContractWire.Build(writer =>
                    {
                        writer.Bool(1, ReadBool(d, "accepted"));
                        writer.String(2, ReadString(d, "version", "1"));
                        writer.Varint(3, ReadLong(d, "acceptedAt"));
                    }));
                    return;
                case "getGdpr":

                case "getAgreement":
                    Send(request.Id, ContractWire.Build(writer =>
                    {
                        writer.String(1, ReadString(d, "version", "1"));
                        writer.String(2, ReadString(d, "text", "Local server privacy agreement"));
                        writer.Bool(3, ReadBool(d, "accepted"));
                    }));

                    return;

                case "accept":
                case "acceptAgreement":
                    GetCollection("gdpr_states").UpdateOne(Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Update.Set("accepted", true).Set("acceptedAt", NowMs()).Set("version", ContractWire.ReadStringField(ContractWire.Param(request), 1, "1")).SetOnInsert("playerId", playerId),
                        new UpdateOptions { IsUpsert = true });
                    ContractWire.SendEmpty(_session, request.Id); return;
                default: throw new FeatureRpcException(404, "gdpr method is not supported");
            }
        }

        private void ProcessDlc(RpcRequest request)
        {
            if (request.MethodName != "getAllDlc" && request.MethodName != "getAllReleasedDlc")
                throw new FeatureRpcException(404, "dlc method is not supported");
            List<BsonDocument> docs = GetCollection("dlc").Find(Builders<BsonDocument>.Filter.Ne("enabled", false)).ToList();
            Send(request.Id, ContractWire.Build(w => { foreach (BsonDocument d in docs) w.Message(1, SerializeDlc(d)); }));
        }

        private static byte[] SerializeDlc(BsonDocument d) => ContractWire.Build(w =>
        {
            w.String(1, ReadString(d, "key"));
            w.String(2, ReadString(d, "name"));
            foreach (BsonValue p in ReadArray(d, "properties")) if (p.IsBsonDocument) w.Message(3, SerializeProperty(p.AsBsonDocument));
            foreach (BsonValue f in ReadArray(d, "files")) if (f.IsBsonDocument) w.Message(4, SerializeDlcFile(f.AsBsonDocument));
        });

        private static byte[] SerializeDlcFile(BsonDocument d) =>  ContractWire.Build(w =>
        {
            foreach (BsonValue u in ReadArray(d, "resourceUrls")) w.String(1, u.ToString());
            w.Varint(2, ReadLong(d, "fileSizeInBytes"));
            w.String(3, ReadString(d, "signature"));
            foreach (BsonValue p in ReadArray(d, "properties")) if (p.IsBsonDocument) w.Message(4, SerializeProperty(p.AsBsonDocument));
             w.String(5, ReadString(d, "fileName"));
        });

        private void ProcessRateGame(RpcRequest request)
        {
            string playerId = RequirePlayer();
            IMongoCollection<BsonDocument> states = GetCollection("rate_game_states");
            BsonDocument state = states.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
            byte[] raw = ContractWire.Param(request);
            long now = NowMs();

            switch (request.MethodName)
            {
                case "getLastRateGame":
                {
                    BsonDocument settings = GetCollection("rate_game_settings").Find(Builders<BsonDocument>.Filter.Empty).FirstOrDefault() ?? new BsonDocument();
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        w.Int32(1, ReadInt(state, "rate"));
                        w.String(2, ReadString(state, "message"));
                        w.String(3, ReadString(state, "internalData"));
                        w.String(4, ReadString(state, "context", ReadString(settings, "defaultContext", "menu")));
                        w.Varint(5, ReadLong(state, "timestampAskLater"));
                        w.Bool(6, ReadBool(state, "dontAskLater"));
                        w.Varint(7, ReadLong(state, "timestamp"));
                        foreach (BsonValue value in ReadArray(settings, "contexts"))
                        {
                            if (!value.IsBsonDocument) continue;
                            BsonDocument context = value.AsBsonDocument;
                            w.Message(8, ContractWire.Build(x =>
                            {
                                x.String(1, ReadString(context, "id"));
                                x.String(2, ReadString(context, "data"));
                            }));
                        }
                        BsonDocument reward = settings.GetValue("reward", new BsonDocument()).IsBsonDocument
                            ? settings.GetValue("reward").AsBsonDocument
                            : new BsonDocument();
                        w.Message(9, SerializeRewardInfo(reward));
                    }));
                    return;
                }
                case "rateGame":
                {
                    int rate = Math.Clamp(ContractWire.ReadIntField(raw, 1, 0), 0, 5);
                    string message = ContractWire.ReadStringField(raw, 2, string.Empty);
                    string internalData = ContractWire.ReadStringField(raw, 3, string.Empty);
                    string context = ContractWire.ReadStringField(raw, 4, string.Empty);
                    bool firstRate = state == null || ReadInt(state, "rate") <= 0;
                    BsonDocument settings = GetCollection("rate_game_settings").Find(Builders<BsonDocument>.Filter.Empty).FirstOrDefault() ?? new BsonDocument();
                    BsonDocument reward = firstRate && settings.GetValue("reward", new BsonDocument()).IsBsonDocument
                        ? settings.GetValue("reward").AsBsonDocument
                        : new BsonDocument();
                    AwardResult given = ObjectId.TryParse(playerId, out ObjectId oid)
                        ? AwardConfiguredRewardStatic(playerId, oid, reward)
                        : new AwardResult();
                    states.UpdateOne(Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Update
                            .Set("rate", rate).Set("message", message).Set("internalData", internalData)
                            .Set("context", context).Set("timestamp", now).Set("dontAskLater", true)
                            .SetOnInsert("playerId", playerId), new UpdateOptions { IsUpsert = true });
                    Send(request.Id, ContractWire.Build(w =>   
                    {
                        w.Int32(1, rate);
                        w.String(2, message);
                        w.String(3, internalData);
                        w.String(4, context);
                        w.Varint(5, now);
                        w.Message(6, SerializeGivenReward(given));
                    }));
                    return;
                }
                case "askLater":
                {
                    long timestampAskLater = ContractWire.ReadLongField(raw, 1, now + 86400000L);
                    string internalData = ContractWire.ReadStringField(raw, 2, string.Empty);
                    string context = ContractWire.ReadStringField(raw, 3, string.Empty);
                    states.UpdateOne(Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Update.Set("timestampAskLater", timestampAskLater).Set("internalData", internalData)
                            .Set("context", context).Set("timestamp", now).Set("dontAskLater", false).SetOnInsert("playerId", playerId),
                        new UpdateOptions { IsUpsert = true });
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        w.Varint(1, timestampAskLater);
                        w.String(2, internalData);
                        w.String(3, context);
                        w.Varint(4, now);
                    }));
                    return;
                }
                case "dontAskLater":
                {
                    string internalData = ContractWire.ReadStringField(raw, 1, string.Empty);
                    string context = ContractWire.ReadStringField(raw, 2, string.Empty);
                    states.UpdateOne(Builders<BsonDocument>.Filter.Eq("playerId", playerId),
                        Builders<BsonDocument>.Update.Set("dontAskLater", true).Set("internalData", internalData)
                            .Set("context", context).Set("timestamp", now).SetOnInsert("playerId", playerId),
                        new UpdateOptions { IsUpsert = true });
                    Send(request.Id, ContractWire.Build(w =>
                    {
                        w.Bool(1, true);
                        w.String(2, internalData);
                        w.String(3, context);
                        w.Varint(4, now);
                    }));
                    return;
                }
                default: throw new FeatureRpcException(404, "rate game method is not supported");
            }
        }

        private static byte[] SerializeGivenReward(AwardResult reward) => ContractWire.Build(w =>
        {
            if (reward == null) return;
            foreach (BsonDocument item in reward.Items) w.Message(1, SerializePlayerInventoryItem(item));
            foreach (BsonDocument currency in reward.Currencies) w.Message(2, SerializeCurrencyAmount(currency));
        });

        public static byte[] ActivateCoupon(ClientSession user, RpcRequest request)
        {
            return ActivateCoupon(user, ContractWire.Param(request));
        }

        public static byte[] ActivateCoupon(ClientSession user, byte[] exactRequestPayload)
        {
            string playerId = ServerState.Users.TryGetValue(user.TcpClient, out string p) ? p : string.Empty;
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out ObjectId oid))
                throw new FeatureRpcException(401, "not authenticated");
            string code = ContractWire.ReadStringField(exactRequestPayload ?? Array.Empty<byte>(), 1, string.Empty).Trim().ToUpperInvariant();
            if (code.Length == 0) throw new FeatureRpcException(400, "empty coupon code");
            IMongoCollection<BsonDocument> coupons = BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("coupons");
            IMongoCollection<BsonDocument> redemptions = BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>("coupon_redemptions");
            lock (_economyLock)
            {
                BsonDocument coupon = coupons.Find(Builders<BsonDocument>.Filter.Eq("couponId", code) & Builders<BsonDocument>.Filter.Ne("enabled", false)).FirstOrDefault();
                if (coupon == null) throw new FeatureRpcException(404, "coupon not found");
                long now = NowMs();
                long start = ReadLong(coupon, "startAt"); long end = ReadLong(coupon, "endAt");
                if (start > 0 && now < start) throw new FeatureRpcException(409, "coupon is not active yet");
                if (end > 0 && now > end) throw new FeatureRpcException(410, "coupon expired");

                string boundPlayerId = coupon.GetValue("boundPlayerId", string.Empty).ToString().Trim();
                if (boundPlayerId.Length > 0 && !string.Equals(boundPlayerId, playerId, StringComparison.Ordinal))
                    throw new FeatureRpcException(403, "coupon belongs to another player");

                if (redemptions.CountDocuments(Builders<BsonDocument>.Filter.Eq("playerId", playerId) & Builders<BsonDocument>.Filter.Eq("couponId", code)) > 0)
                    throw new FeatureRpcException(409, "coupon already used");
                int max = ReadInt(coupon, "maxActivations", 0); int used = ReadInt(coupon, "activations", 0);
                if (max > 0 && used >= max) throw new FeatureRpcException(429, "coupon activation limit reached");
                BsonDocument reward = coupon.GetValue("reward", new BsonDocument()).AsBsonDocument;
                AwardResult result = AwardConfiguredRewardStatic(playerId, oid, reward);
                redemptions.InsertOne(new BsonDocument { ["playerId"] = playerId, ["couponId"] = code, ["createdAt"] = now });
                coupons.UpdateOne(Builders<BsonDocument>.Filter.Eq("_id", coupon["_id"]), Builders<BsonDocument>.Update.Inc("activations", 1));
                byte[] response = ContractWire.Build(w =>
                {
                    foreach (BsonDocument c in result.Currencies) w.Message(1, SerializeCurrencyAmount(c));
                    foreach (BsonDocument i in result.Items) w.Message(2, SerializePlayerInventoryItem(i));
                });
                InventoryItem[] eventItems = result.Items
                    .Select(i => InventoryItem.Parser.ParseFrom(SerializePlayerInventoryItem(i)))
                    .ToArray();
                CurrencyAmount[] eventCurrencies = result.Currencies
                    .Select(c => CurrencyAmount.Parser.ParseFrom(SerializeCurrencyAmount(c)))
                    .ToArray();

                InventoryEventBus.CouponActivated(
                    playerId, eventItems, eventCurrencies, "coupon");
                return response;
            }
        }

        private void AwardConfiguredReward(string playerId, BsonDocument reward)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId oid)) throw new FeatureRpcException(400, "invalid player id");
            AwardConfiguredRewardStatic(playerId, oid, reward);
        }

        private static AwardResult AwardConfiguredRewardStatic(string playerId, ObjectId oid, BsonDocument reward)
        {
            var result = new AwardResult();
            BoltGameDatabaseProvider game = BoltGameDatabaseProvider.Instance;
            PlayerInventoryDocument inventory;
            try { inventory = game.GetPlayerInventoryDocument(oid); }
            catch { game.CreatePlayerInventory(oid); inventory = game.GetPlayerInventoryDocument(oid); }

            foreach (BsonValue value in ReadArray(reward, "currencies"))
            {
                if (!value.IsBsonDocument) continue;
                BsonDocument c = value.AsBsonDocument;
                int currencyId = ReadInt(c, "currencyId");
                int amount = ReadInt(c, "amount", ReadInt(c, "value"));
                if (currencyId <= 0 || amount <= 0) continue;
                int oldValue = ReadCurrency(inventory, currencyId);
                game.CurrencyPlusValue(oid, currencyId, amount);

                result.Currencies.Add(new BsonDocument
                {
                    ["currencyId"] = currencyId,
                    ["oldValue"] = oldValue,
                    ["value"] = amount
                });
            }

            int nextId = NextInventoryId(inventory);
            foreach (BsonValue value in ReadArray(reward, "items"))
            {
                if (!value.IsBsonDocument) continue;
                BsonDocument item = value.AsBsonDocument;

                int definitionId = ReadInt(item, "itemDefinitionId",
                    ReadInt(item, "inventoryItemDefinitionId", ReadInt(item, "itemId")));
                int quantity = Math.Max(1, ReadInt(item, "quantity",
                    ReadInt(item, "amount", ReadInt(item, "value", 1))));
                int flags = ReadInt(item, "flags");
                if (definitionId <= 0)
                    throw new FeatureRpcException(400, "invalid coupon item id");

                int inventoryId = nextId++;
                long awardedAt = NowMs();
                var model = new BoltInventoryItem
                {
                    id = inventoryId,
                    itemDefinitionId = definitionId,
                    quantity = quantity,
                    flags = flags,
                    date = new BsonDateTime(awardedAt)
                };
                game.AddItemToPlayerInventoryDocument(oid, model, inventoryId);
                result.Items.Add(new BsonDocument
                {
                    ["id"] = inventoryId,
                    ["itemDefinitionId"] = definitionId,
                    ["quantity"] = quantity,
                    ["flags"] = flags,
                    ["date"] = awardedAt
                });
            }
            return result;
        }

        private static int ReadCurrency(PlayerInventoryDocument inventory, int currencyId)
        {
            if (inventory?.Currencies == null || !inventory.Currencies.TryGetValue(currencyId.ToString(), out BsonValue value)) return 0;
            try { return Convert.ToInt32(value.IsDecimal128 ? (double)value.AsDecimal128 : value.ToDouble()); } catch { return 0; }
        }

        private static int NextInventoryId(PlayerInventoryDocument inventory)
        {
            int max = 0;
            if (inventory?.InventoryItems != null)
                foreach (BsonElement e in inventory.InventoryItems.Elements) if (int.TryParse(e.Name, out int id)) max = Math.Max(max, id);
            return max + 1;
        }

        private static byte[] SerializeRewardInfo(BsonDocument reward) => ContractWire.Build(w =>
        {
            foreach (BsonValue value in ReadArray(reward, "items")) if (value.IsBsonDocument)
            {
                BsonDocument i = value.AsBsonDocument;
                w.Message(1, ContractWire.Build(x =>
                {
                    x.Int32(1, ReadInt(i, "itemDefinitionId", ReadInt(i, "inventoryItemDefinitionId", ReadInt(i, "itemId"))));
                    x.Int32(2, ReadInt(i, "quantity", ReadInt(i, "amount", ReadInt(i, "value", 1))));
                }));
            }
            foreach (BsonValue value in ReadArray(reward, "currencies")) if (value.IsBsonDocument) w.Message(2, SerializeCurrencyAmount(value.AsBsonDocument));
        });

        private static byte[] SerializeCurrencyAmount(BsonDocument d) => ContractWire.Build(w =>
        {
            w.Int32(1, ReadInt(d, "currencyId"));
            w.Int32(2, ReadInt(d, "oldValue"));
            w.Float(3, ReadFloat(d, "value", ReadFloat(d, "amount")));
        });

        private static byte[] SerializePlayerInventoryItem(BsonDocument document) =>
            ContractWire.Build(writer =>
            {
                writer.Int32(1, ReadInt(document, "id"));
                writer.Int32(2, ReadInt(document, "itemDefinitionId"));
                writer.Int32(3, ReadInt(document, "quantity"));
                writer.Int32(4, ReadInt(document, "flags"));
                writer.Varint(5, ReadLong(document, "date"));
            });
        private static byte[] SerializeProperty(BsonDocument document) =>
            ContractWire.Build(writer =>
            {
                writer.String(1, ReadString(document, "name"));
                int type = ReadInt(document, "type", InferPropertyType(document));
                writer.Int32(2, type);

                switch (type)
                {
                    case 0:
                        writer.Int32(3, ReadInt(document, "value", ReadInt(document, "intValue")));
                        break;
                    case 1:
                        writer.Float(4, ReadFloat(document, "value", ReadFloat(document, "floatValue")));
                        break;
                    case 4:
                        writer.Varint(5, ReadLong(document, "value", ReadLong(document, "longValue")));
                        break;
                    case 3:
                        writer.Bool(7, ReadBool(document, "value", ReadBool(document, "booleanValue")));
                        break;
                    default:
                        writer.String(6, ReadString(document, "value", ReadString(document, "stringValue")));
                        break;
                }
            });

        private static int InferPropertyType(BsonDocument document)
        {
            BsonValue value = document.GetValue("value", BsonNull.Value);
            if (value.IsBoolean)
                return 3;
            if (value.IsInt32)
                return 0;
            if (value.IsInt64)
                return 4;
            if (value.IsDouble || value.IsDecimal128)
                return 1;
            return 2;
        }

        private static byte[] SerializePlayer(PlayerDocument player, bool guest) =>
            ContractWire.Build(writer =>
            {
                if (player == null)
                    return;

                writer.String(1, player._id.ToString());
                writer.String(2, player.uid ?? string.Empty);
                writer.String(3, player.name ?? string.Empty);
                writer.String(4, player.avatarId ?? string.Empty);
                writer.Int32(5, player.timeInGame);
                writer.Varint(8, player.createDate == null ? 0 : player.createDate.MillisecondsSinceEpoch);
                writer.Bool(14, guest);
            });
        private PlayerDocument FindPlayerByUid(string uid)
        {
            if (string.IsNullOrWhiteSpace(uid))
                return null;

            return BoltMainDatabaseProvider.Instance
                .GetDatabase()
                .GetCollection<PlayerDocument>("players")
                .Find(Builders<PlayerDocument>.Filter.Eq("uid", uid))
                .FirstOrDefault();
        }

        private BsonDocument GetStatsDocument(string playerId)
        {
            return BoltGameDatabaseProvider.Instance
                .GetDatabase()
                .GetCollection<BsonDocument>("stats")
                .Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId))
                .FirstOrDefault() ?? new BsonDocument();
        }

        private IMongoCollection<BsonDocument> GetCollection(string name)
        {
            return BoltMainDatabaseProvider.Instance.GetDatabase().GetCollection<BsonDocument>(name);
        }

        private string CurrentPlayerId()
        {
            return ServerState.Users.TryGetValue(_session.TcpClient, out string id)
                ? id ?? string.Empty
                : string.Empty;
        }

        private string RequirePlayer()
        {
            string playerId = CurrentPlayerId();
            if (string.IsNullOrWhiteSpace(playerId))
                throw new FeatureRpcException(401, "not authenticated");

            return playerId;
        }

        private void Send(string id, byte[] bytes)
        {
            ContractWire.SendRaw(_session, id, bytes ?? Array.Empty<byte>());
        }
        private void SendError(string id, int code, string reason, string method)
        {
            var rpcException = new RpcException
            {
                Id = BitConverter.ToInt64(
                    Guid.NewGuid().ToByteArray(),
                    8),
                Code = code
            };
            rpcException.Property["service"] = _serviceName ?? string.Empty;
            rpcException.Property["method"] = method ?? string.Empty;
            rpcException.Property["reason"] = reason ?? string.Empty;
            var response = new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id ?? string.Empty,
                    Exception = rpcException
                }
            };

            _session.SendResponse(response);
        }

        private static long NowMs()
        {
            return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }

        private static string GetDocumentId(BsonDocument document)
        {
            if (document == null)
               return string.Empty;

            return document.GetValue("_id", BsonNull.Value).ToString();
        }

        private static BsonArray ReadArray(BsonDocument document, string key)
        {
            if (document == null || !document.TryGetValue(key, out BsonValue value) || !value.IsBsonArray)
           return new BsonArray();

            return value.AsBsonArray;
        }

        private static string ReadString(BsonDocument document, string key, string fallback = "")
        {
            if (document == null || !document.TryGetValue(key, out BsonValue value) || value.IsBsonNull)
          return fallback;

            return value.IsString ? value.AsString : value.ToString();
        }

        private static int ReadInt(BsonDocument document, string key, int fallback = 0)
        {
            if (!TryGetValue(document, key, out BsonValue value))
           return fallback;

            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64 && value.AsInt64 is >= int.MinValue and <= int.MaxValue) return (int)value.AsInt64;
            if (value.IsDouble && value.AsDouble is >= int.MinValue and <= int.MaxValue) return (int)value.AsDouble;
            if (value.IsDecimal128)
            {
                double number = (double)value.AsDecimal128;
                if (number is >= int.MinValue and <= int.MaxValue) return (int)number;
            }
            if (value.IsString && int.TryParse(value.AsString, out int parsed)) return parsed;

            return fallback;
        }

        private static long ReadLong(BsonDocument document, string key, long fallback = 0)
        {
            if (!TryGetValue(document, key, out BsonValue value))
            return fallback;

            if (value.IsBsonDateTime) return value.AsBsonDateTime.MillisecondsSinceEpoch;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsInt32) return value.AsInt32;
            if (value.IsDouble) return (long)value.AsDouble;
            if (value.IsDecimal128) return (long)(double)value.AsDecimal128;
            if (value.IsString && long.TryParse(value.AsString, out long parsed)) return parsed;
            return fallback;
        }

        private static float ReadFloat(BsonDocument document, string key, float fallback = 0)
        {
            if (!TryGetValue(document, key, out BsonValue value))
            return fallback;
            if (value.IsDouble) return (float)value.AsDouble;
            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsDecimal128) return (float)(double)value.AsDecimal128;
            if (value.IsString && float.TryParse(value.AsString, System.Globalization.NumberStyles.Float,
         System.Globalization.CultureInfo.InvariantCulture, out float parsed))
            return parsed;

            return fallback;
        }

        private static bool ReadBool(BsonDocument document, string key, bool fallback = false)
        {
            if (!TryGetValue(document, key, out BsonValue value))
                return fallback;

            if (value.IsBoolean) return value.AsBoolean;
            if (value.IsInt32) return value.AsInt32 != 0;
            if (value.IsInt64) return value.AsInt64 != 0;
            if (value.IsString && bool.TryParse(value.AsString, out bool parsed)) return parsed;

            return fallback;
        }

        private static int ReadNestedInt(BsonDocument document, string container, string key)
        {
            if (document == null || !document.TryGetValue(container, out BsonValue value) || !value.IsBsonDocument)
                return 0;

            return ReadInt(value.AsBsonDocument, key);
        }

        private static bool TryGetValue(BsonDocument document, string key, out BsonValue value)
        {
            value = BsonNull.Value;
            return document != null && document.TryGetValue(key, out value) && value != null && !value.IsBsonNull;
        }

        private sealed class AwardResult
        {
            public readonly List<BsonDocument> Currencies =
                new List<BsonDocument>();

            public readonly List<BsonDocument> Items =
                new List<BsonDocument>();
        }

        public sealed class FeatureRpcException : System.Exception
        {
            public int Code { get; }

            public FeatureRpcException(int code, string message)
                : base(message)
            {
                Code = code;
            }
        }

    }
}
