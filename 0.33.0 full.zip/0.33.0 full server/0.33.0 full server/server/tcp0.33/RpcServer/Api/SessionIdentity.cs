using System;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;
namespace TspServer.RpcServer.Api
{
    public static class SessionIdentity
    {
       public static bool TryGetPlayerId(ClientSession session, out string playerId)
         {
            if (ServerState.Users.TryGetValue(session.TcpClient, out string? existingPlayerId) &&
                 !string.IsNullOrWhiteSpace(existingPlayerId))
            {
                playerId = existingPlayerId;
                return true;
            }

            playerId = string.Empty;
            string token = session.LastAuthToken ?? string.Empty;
            if (string.IsNullOrWhiteSpace(token))
                return false;
            if (!FindToken(session, token, out Token tokenInfo))
                return false;

           playerId = tokenInfo.playerId.ToString();
             InitPlayerState(playerId);
            Bind(session, playerId, tokenInfo);
            return true;
       }

        private static bool FindToken(ClientSession session, string token, out Token tokenInfo)
        {
            tokenInfo = null!;

            if (ServerState.Tokens.TryGetValue(token, out Token? cachedToken))
            {
                tokenInfo = cachedToken;
                return true;
            }

            try
            {
                LocalAccountDocument acc = BoltMainDatabaseProvider.Instance.GetLocalAccount(token);
                if (string.IsNullOrWhiteSpace(acc.playerId))
                    return false;

                tokenInfo = new Token
                {
                    playerId = ObjectId.Parse(acc.playerId),
                    gameCode = session.LastGameId ?? "1",
                    gameVersion = session.LastGameVersion ?? "1"
                };

               ServerState.Tokens[token] = tokenInfo;
                return true;
            }
            catch (AccountNotFoundException)
            {
                return false;
            }
           catch (System.Exception)
           {
                return false;
            }
       }

        private static void InitPlayerState(string playerId)
        {
            try
            {
                BoltGameDatabaseProvider gameDb = BoltGameDatabaseProvider.Instance;
                ObjectId objectId = ObjectId.Parse(playerId);

                CreateIfMissing(
                    () => gameDb.GetPlayerStatsDocument(playerId),
                    () => gameDb.CreatePlayerStats(playerId));

                CreateIfMissing(
                    () => gameDb.GetFiles(objectId),
                    () => gameDb.CreatePlayerFiles(playerId));

                CreateIfMissing(
                    () => gameDb.GetPlayerInventoryDocument(objectId),
                    () => gameDb.CreatePlayerInventory(objectId));
            }
           catch (System.Exception)
           {
            }
        }

        private static void CreateIfMissing(Action read, Action create)
        {
            try
            {
                read();
            }
             catch
            {
                create();
           }
        }

        private static void Bind(ClientSession session, string playerId, Token tokenInfo)
        {
            bool bound = false;

             lock (ServerState.UsersLock)
            {
                if (!ServerState.Users.ContainsKey(session.TcpClient))
                {
                    ServerState.Users[session.TcpClient] = playerId;
                    bound = true;
               }
            }

            if (!bound)
                return;

            PlayerStatus status = ServerState.GetOrCreatePlayerStatus(playerId);
            status.gpid = playerId;
            status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
             status.playInGame ??= new PlayInGame();

            if (string.IsNullOrWhiteSpace(status.playInGame.gameCode))
                status.playInGame.gameCode = tokenInfo.gameCode;

            if (string.IsNullOrWhiteSpace(status.playInGame.gameVersion))
                status.playInGame.gameVersion = tokenInfo.gameVersion;

            ServerState.SetPlayerStatusSnapshot(playerId, status);
            BoltMainDatabaseProvider.Instance.SetPlayerStatus(tokenInfo.playerId, status);

            session.InitializeEventSenders(playerId);
            session.FlushEventSenders(playerId, "session-auth-recovery");
            SocialProfileEventBridge.BroadcastStatus(playerId, status);
        }
    }
}
