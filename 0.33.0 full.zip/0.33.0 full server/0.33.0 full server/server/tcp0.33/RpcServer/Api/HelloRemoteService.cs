using System;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace TspServer.RpcServer.Api
{
    public sealed class HelloRemoteService : RpcHandler
    {
        public HelloRemoteService(ClientSession user) : base(user) { }

        public override void Invoke(RpcRequest request) => InvokeAsync(request).GetAwaiter().GetResult();

        public override Task InvokeAsync(RpcRequest request)
        {
            if (request == null || request.Params == null || request.Params.Count == 0)
            {
                SendError(request?.Id, 400, "HELLO_BAD_PAYLOAD");
                return Task.CompletedTask;
            }

            string method = request.MethodName ?? string.Empty;
            if (!method.Equals("hello", StringComparison.OrdinalIgnoreCase) &&
                !method.Equals("exchange", StringComparison.OrdinalIgnoreCase) &&
                !method.Equals("keyExchange", StringComparison.OrdinalIgnoreCase))
            {
                SendError(request.Id, 404, "HELLO_BAD_METHOD");
                return Task.CompletedTask;
            }

            byte[] payload = Protocol.GetBinaryValueBytes(request.Params[0]);
            if (!ReadHello(payload, out var fields, out string mode))
            {
                SendError(request.Id, 400, "HELLO_BAD_PROTO");
                return Task.CompletedTask;
            }

            fields.TryGetValue(1, out byte[] exponent);
            fields.TryGetValue(2, out byte[] modulus);
            fields.TryGetValue(3, out byte[] clientIv);

            if (clientIv == null || clientIv.Length != 16)
            {
                SendError(request.Id, 400, "HELLO_BAD_IV");
                return Task.CompletedTask;
            }

            byte[] sessionKey = RandomNumberGenerator.GetBytes(16);
            bool encrypted = Protocol.TryEncryptRsaPkcs1(
                modulus,
                exponent,
                sessionKey,
                out byte[] encryptedSessionKey,
                out _
            );

            
            if (!encrypted)
            {
                encrypted = Protocol.TryEncryptRsaPkcs1(
                    exponent,
                    modulus,
                    sessionKey,
                    out encryptedSessionKey,
                    out _
                );
            }

            if (!encrypted)
            {
                SendError(request.Id, 500, "HELLO_RSA_FAIL");
                return Task.CompletedTask;
            }

            string sessionId = "sr33-" + Guid.NewGuid().ToString("N");
            byte[] response = Protocol.BuildHelloResponse(encryptedSessionKey, sessionId);

            if (mode == "bootstrap")
                response = Protocol.EncryptAesCbc(response, Protocol.BootstrapKey, Protocol.BootstrapIv);

            _session.ConfigureSessionCrypto(sessionKey, clientIv, sessionId, request.Id);
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = request.Id,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.CopyFrom(response)
                    }
                }
            });

            return Task.CompletedTask;
        }

        private static bool ReadHello(
            byte[] raw,
            out System.Collections.Generic.Dictionary<int, byte[]> fields,
            out string mode)
        {
            if (TryReadHello(raw, out fields))
            {
                mode = "direct";
                return true;
            }

            if (Protocol.TryDecryptAesCbc(
                    raw,
                    Protocol.BootstrapKey,
                    Protocol.BootstrapIv,
                    out byte[] plain) &&
                TryReadHello(plain, out fields))
            {
                mode = "bootstrap";
                return true;
            }

            fields = null;
            mode = string.Empty;
            return false;
        }

        private static bool TryReadHello(
            byte[] payload,
            out System.Collections.Generic.Dictionary<int, byte[]> fields)
        {
            if (!Protocol.TryReadLengthDelimitedFields(payload, out fields, out _))
                return false;

            return fields.TryGetValue(1, out byte[] first) && first?.Length > 0 &&
                   fields.TryGetValue(2, out byte[] second) && second?.Length > 0 &&
                   fields.TryGetValue(3, out byte[] iv) && iv?.Length == 16;
        }

        private void SendError(string requestId, int code, string reason)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId ?? string.Empty,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code,
                        Property = { ["reason"] = reason }
                    }
                }
            });
        }
    }
}
