using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    public sealed class ClanStatsRemoteService : RpcHandler
    {
         private IMongoDatabase Db => BoltGameDatabaseProvider.Instance.GetDatabase();
        private IMongoCollection<ClanRemoteService.ClanMemberDoc> Members =>
            Db.GetCollection<ClanRemoteService.ClanMemberDoc>("clan_members");
        private IMongoCollection<ClanMemberStatsRemoteService.ClanMemberStatsDoc> MemberStats =>
           Db.GetCollection<ClanMemberStatsRemoteService.ClanMemberStatsDoc>("clan_member_stats");

         public ClanStatsRemoteService(ClientSession user) : base(user) { }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }

       public override void Invoke(RpcRequest request)
        {
            try
            {
                switch (request.MethodName)
                {
                     case "getCurrentClanStats":
                        GetCurrentClanStats(request);
                        return;
                    case "getClanStats":
                        GetClanStats(request);
                        return;
                    case "getCurrentClanStatsForSeason":
                    case "getCurrentClanStatsForSeason2":
                        GetCurrentForSeason(request);
                        return;
                    case "getClanStatsForSeason":
                    case "getClanStatsForSeason2":
                        GetForSeason(request);
                        return;
                    default:
                         SendException(request.Id, 404);
                        return;
                }
            }
            catch (System.Exception)
            {
                SendException(request.Id, 500);
            }
        }

        private static readonly string[] ClanIntStatIds =
        {
            "clan_ranked_xp",
            "clan_ranked_rank",
            "clan_ranked_current_mmr",
            "clan_ranked_best_rank",
            "clan_ranked_best_rank_history1",
            "clan_ranked_calibration_match_count",
            "clan_ranked_played_matches",
             "clan_ranked_won_match_count"
        };

        private static readonly string[] ClanMemberIntStatIds =
        {
            "clan_member_ranked_xp",
            "clan_member_ranked_played_matches",
            "clan_member_ranked_won_match_count",
            "clan_member_ranked_last_match_status"
        };

        private static readonly string[] ClanMemberLongStatIds =
        {
            "clan_member_ranked_last_match_start_time"
        };

         private sealed class MemberSnapshot
        {
            public ClanMemberStats Value { get; set; }
            public long Version { get; set; }
        }

        private void GetCurrentClanStats(RpcRequest request)
        {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc member = Members.Find(x => x.PlayerId == playerId).FirstOrDefault();
            string clanId = member?.ClanId ?? string.Empty;
           byte[] response = BuildResponse(clanId, string.Empty);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetClanStats(RpcRequest request)
       {
            byte[] payload = ContractWire.Param(request);
            string clanId = ContractWire.ReadStringField(payload, 1, string.Empty).Trim();
            byte[] response = BuildResponse(clanId, string.Empty);
            ContractWire.SendRaw(_session, request.Id, response);
        }
        private void GetCurrentForSeason(RpcRequest request)
        {
             byte[] payload = ContractWire.Param(request);
            string seasonId = ContractWire.ReadStringField(payload, 1, string.Empty).Trim();
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc member = Members.Find(x => x.PlayerId == playerId).FirstOrDefault();
            string clanId = member?.ClanId ?? string.Empty;
            byte[] response = SeasonResponse(clanId, seasonId);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetForSeason(RpcRequest request)
        {
            byte[] payload = ContractWire.Param(request);
            string seasonId = ContractWire.ReadStringField(payload, 1, string.Empty).Trim();
            string clanId = ContractWire.ReadStringField(payload, 2, string.Empty).Trim();
            byte[] response = SeasonResponse(clanId, seasonId);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private byte[] BuildResponse(string clanId, string seasonId)
        {
            List<MemberSnapshot> members = MemberSnapshots(clanId);
            ClanStats clanStats = ClanStatsPayload(clanId, seasonId, members);
            ClanStatsMap statsMap = StatsMap(clanStats);
            return ContractWire.Build(w =>
            {
                w.String(1, clanId ?? string.Empty);
                w.Message(2, statsMap);
                w.Message(3, clanStats);
                foreach (MemberSnapshot member in members)
                    w.Message(4, MemberStatsWire(member));
            });
        }

        private byte[] SeasonResponse(string clanId, string seasonId)
        {
            List<MemberSnapshot> members = MemberSnapshots(clanId);
            ClanStats clanStats = ClanStatsPayload(clanId, seasonId, members);
            return ContractWire.Build(w =>
            {
                w.Message(1, clanStats);
               foreach (MemberSnapshot member in members)
                    w.Message(2, MemberStatsWire(member));
            });
        }

        private static ClanStats ClanStatsPayload(string clanId, string seasonId, IReadOnlyList<MemberSnapshot> members)
        {
            var stats = new ClanStats
            {
                ClanId = clanId ?? string.Empty,
                SeasonId = seasonId ?? string.Empty
            };

            int totalXp = SumStat(members, "clan_member_ranked_xp");
            int totalMatches = SumStat(members, "clan_member_ranked_played_matches");
            int totalWins = SumStat(members, "clan_member_ranked_won_match_count");

            foreach (string statId in ClanIntStatIds)
            {
                int value = 0;
                if (statId == "clan_ranked_xp") value = totalXp;
                else if (statId == "clan_ranked_played_matches") value = totalMatches;
                else if (statId == "clan_ranked_won_match_count") value = totalWins;

                stats.Stats.Add(new ClanStat
                {
                    StatId = statId,
                    Type = StatDefType.Int,
                    IntValue = value
                });
            }
            return stats;
        }

        private static ClanStatsMap StatsMap(ClanStats source)
       {
             var map = new ClanStatsMap();
            foreach (ClanStat stat in source?.Stats ?? new Google.Protobuf.Collections.RepeatedField<ClanStat>())
            {
                if (stat == null || string.IsNullOrWhiteSpace(stat.StatId)) continue;
                map.Stats[stat.StatId] = stat.Clone();
            }
            return map;
        }

        private List<MemberSnapshot> MemberSnapshots(string clanId)
        {
            var result = new List<MemberSnapshot>();
            if (string.IsNullOrWhiteSpace(clanId)) return result;

            List<string> playerIds = Members.Find(x => x.ClanId == clanId)
                .Project(x => x.PlayerId)
                .ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.Ordinal)
               .ToList();

            Dictionary<string, ClanMemberStatsRemoteService.ClanMemberStatsDoc> docs = MemberStats
                .Find(x => x.ClanId == clanId)
                .ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x.PlayerId))
                .GroupBy(x => x.PlayerId, StringComparer.Ordinal)
                .ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.UpdatedAt).First(), StringComparer.Ordinal);

            foreach (string playerId in playerIds)
            {
                docs.TryGetValue(playerId, out ClanMemberStatsRemoteService.ClanMemberStatsDoc doc);
                CurrentClanMemberStats current = ReadMemberStats(doc?.Payload);
                var member = new ClanMemberStats { PlayerId = playerId };

                var byId = new Dictionary<string, ClanMemberStat>(StringComparer.Ordinal);
                foreach (ClanMemberStat stat in current.Stats)
                {
                    if (stat == null || string.IsNullOrWhiteSpace(stat.StatId)) continue;
                    byId[stat.StatId] = stat.Clone();
                 }
                foreach (string statId in ClanMemberIntStatIds)
                {
                    if (!byId.ContainsKey(statId))
                        byId[statId] = new ClanMemberStat { StatId = statId, Type = StatDefType.Int, IntValue = 0 };
               }
                foreach (string statId in ClanMemberLongStatIds)
                {
                    if (!byId.ContainsKey(statId))
                        byId[statId] = new ClanMemberStat { StatId = statId, Type = StatDefType.Int, LongValue = 0L };
                 }
                member.Stats.Add(byId.Values.OrderBy(x => x.StatId, StringComparer.Ordinal));

                long version = 0;
                if (doc != null && doc.UpdatedAt != default(DateTime))
                {
                    DateTime utc = doc.UpdatedAt.Kind == DateTimeKind.Utc
                        ? doc.UpdatedAt
                        : DateTime.SpecifyKind(doc.UpdatedAt, DateTimeKind.Utc);
                     version = new DateTimeOffset(utc).ToUnixTimeMilliseconds();
                }
                result.Add(new MemberSnapshot { Value = member, Version = Math.Max(0L, version) });
            }
           return result;
        }

        private static CurrentClanMemberStats ReadMemberStats(byte[] payload)
        {
            if (payload == null || payload.Length == 0) return new CurrentClanMemberStats();
            try { return CurrentClanMemberStats.Parser.ParseFrom(payload); }
            catch (System.Exception)
            {
               return new CurrentClanMemberStats();
            }
        }

        private static byte[] MemberStatsWire(MemberSnapshot snapshot)
        {
            ClanMemberStats value = snapshot?.Value ?? new ClanMemberStats();
            return ContractWire.Build(w =>
           {
                w.String(1, value.PlayerId ?? string.Empty);
                foreach (ClanMemberStat stat in value.Stats)
                    w.Message(2, stat);
                w.Varint(3, snapshot?.Version ?? 0L);
           });
        }

        private static int SumStat(IReadOnlyList<MemberSnapshot> members, string statId)
        {
             long total = 0;
            if (members != null)
           {
                foreach (MemberSnapshot member in members)
                {
                   ClanMemberStat stat = member?.Value?.Stats?.FirstOrDefault(x => x != null && x.StatId == statId);
                    if (stat != null) total += stat.IntValue;
                }
            }
           return (int)Math.Max(int.MinValue, Math.Min(int.MaxValue, total));
        }
        internal int BroadcastClanStatsUpdated(string clanId, string seasonId = "")
        {
            if (string.IsNullOrWhiteSpace(clanId)) return 0;
            List<MemberSnapshot> members = MemberSnapshots(clanId);
            ClanStats clanStats = ClanStatsPayload(clanId, seasonId, members);
            byte[] payload = ContractWire.Build(w =>
            {
                w.Message(1, clanStats);
                foreach (MemberSnapshot member in members)
                    w.Message(2, MemberStatsWire(member));
            });

            string[] recipients = Members.Find(x => x.ClanId == clanId)
                .Project(x => x.PlayerId)
                .ToList()
                 .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.Ordinal)
                .ToArray();

            int delivered = 0;
            foreach (string playerId in recipients)
            {
                foreach (ClanStatsRemoteEventSender sender in ServerState.GetLiveEventSenders<ClanStatsRemoteEventSender>(playerId))
                {
                     sender.SendRawEvent("onClanStatsUpdated", payload);
                    delivered++;
                }
            }
             return delivered;
        }

        private string GetPlayerId()
        {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string id)) return id;
            throw new InvalidOperationException("Not authenticated");
        }

        private void SendException(string id, int code)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
       }
    }
}
