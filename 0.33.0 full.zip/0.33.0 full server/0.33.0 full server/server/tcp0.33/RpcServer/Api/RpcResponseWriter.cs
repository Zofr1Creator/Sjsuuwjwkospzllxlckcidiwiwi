using System;
using Google.Protobuf;
using RpcProto = Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer.Api
{
    internal static class RpcResponseWriter
    {
        public static void SendPayload(
            ClientSession session,
            string requestId,
            byte[] payload)
        {
            session.SendResponse(
                new RpcProto.ResponseMessage
                {
                    RpcResponse = new RpcProto.RpcResponse
                    {
                        Id = requestId,
                        Return = new RpcProto.BinaryValue
                        {
                            IsNull = false,
                            One = ByteString.CopyFrom(payload ?? Array.Empty<byte>())
                       }
                    }
                });
        }

        public static void SendNotFound(ClientSession session, string requestId)
        {
            session.SendResponse(
                new RpcProto.ResponseMessage
                {
                    RpcResponse = new RpcProto.RpcResponse
                    {
                        Id = requestId,
                        Exception = new RpcProto.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 404
                        }
                    }
                });
        }
    }
}
