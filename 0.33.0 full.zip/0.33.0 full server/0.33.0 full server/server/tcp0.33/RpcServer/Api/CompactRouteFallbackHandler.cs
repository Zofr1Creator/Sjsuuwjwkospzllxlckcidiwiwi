using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace TspServer.RpcServer.Api
{
    public sealed class CompactRouteFallbackHandler : RpcHandler
   {
        private readonly string _serviceName;

        private readonly HashSet<string> _emptyMethods;

        public CompactRouteFallbackHandler(
             ClientSession session,
            string serviceName,
            params string[] emptyMethods) : base(session)
        {
            _serviceName = serviceName;
            _emptyMethods = new HashSet<string>(
                emptyMethods ?? Array.Empty<string>(),
                StringComparer.Ordinal);
        }

        public override void Invoke(RpcRequest request)
        {
             string method = request?.MethodName ?? string.Empty;
             string requestId = request?.Id ?? string.Empty;


            if (_emptyMethods.Contains(method))
            {
                SendEmpty(requestId);
                return;
            }

            SendNotImplemented(requestId, method);
       }

        public override Task InvokeAsync(RpcRequest request)
        {
           Invoke(request);
           return Task.CompletedTask;
         }

        private void SendEmpty(string requestId)
        {
            _session.SendResponse(new ResponseMessage
            {
               RpcResponse = new RpcResponse
                {
                    Id = requestId,
                    Return = new BinaryValue
                    {
                        IsNull = false,
                        One = ByteString.Empty
                    }
               }
            });
        }

        private void SendNotImplemented(string requestId, string method)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = requestId,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 404,
                        Property =
                        {
                            ["service"] = _serviceName,
                            ["method"] = method,
                            ["reason"] = "NOT_IMPLEMENTED"
                        }
                    }
                }
            });
        }
     }
}
