using System;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;
namespace TspServer.RpcServer.Api
{
    internal static class PlayerProfileContract
    {
        public const int VerifiedPlayerTag = 1;

        public const string VerifiedAttributeKey  = "mark_verified";

        public static bool IsVerified(PlayerDocument player)
        {
            if (player == null) return false;
              if (player.verified) return true;

            try
            {
                string id = player._id.ToString();
                var flags = BoltMainDatabaseProvider.Instance.GetDatabase()
                    .GetCollection<BsonDocument>("player_profile_flags")
                   .Find(Builders<BsonDocument>.Filter.Eq("playerId", id))
                    .FirstOrDefault();
                return flags != null && flags.TryGetValue("verified", out BsonValue v) &&
                       !v.IsBsonNull && v.ToBoolean();
            }
            catch { return false; }
        }

        public static Attributes BuildAttributes(PlayerDocument player)
        {
           var attrs = new Attributes();
            if (IsVerified(player))
         attrs.Map[VerifiedAttributeKey] = new Axlebolt.Bolt.Protobuf2.Attribute { Boolean = true };return attrs;
        }

        public static void Apply(Player proto, PlayerDocument player)
        {
            if (proto == null || player == null) return;
            proto.Attributes = BuildAttributes(player);
            if (IsVerified(player) && !proto.Tags.Contains(VerifiedPlayerTag))
            proto.Tags.Add(VerifiedPlayerTag);
        }
    }
}
