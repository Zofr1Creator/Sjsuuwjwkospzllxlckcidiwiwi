using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace TspServer.RpcServer.Api
{

    internal static class ContractWire
    {
        internal sealed class Reader
        {
            private readonly byte[] _data;
            private int _index;

            public Reader(byte[] data)
            {
                _data = data ?? Array.Empty<byte>();
            }

            public bool End => _index >= _data.Length;

            public bool TryReadField(out int field, out int wire)
            {
                field = 0;
                wire = 0;
                if (End) return false;
                ulong tag = ReadVarUInt64();
                if (tag == 0) return false;
                field = checked((int)(tag >> 3));
                wire = checked((int)(tag & 7));
                return true;
             }

             public ulong ReadVarUInt64()
            {
                ulong value = 0;
                int shift = 0;
                while (_index < _data.Length && shift < 70)
                {
                   byte b = _data[_index++];
                   value |= ((ulong)(b & 0x7f)) << shift;
                    if ((b & 0x80) == 0) return value;
                    shift += 7;
                }
                throw new InvalidDataException("Invalid protobuf varint.");
            }

           public int ReadInt32() => unchecked((int)ReadVarUInt64());
            public long ReadInt64() => unchecked((long)ReadVarUInt64());
            public bool ReadBool() => ReadVarUInt64() != 0;

            public float ReadFloat()
            {
                if (_index + 4 > _data.Length)
                    throw new InvalidDataException("Invalid protobuf fixed32 field.");
                float value = BitConverter.Int32BitsToSingle(
                    _data[_index] |
                    (_data[_index + 1] << 8) |
                    (_data[_index + 2] << 16) |
                     (_data[_index + 3] << 24));
                _index += 4;
                return value;
            }

            public byte[] ReadBytes()
            {
                int length = checked((int)ReadVarUInt64());
                if (length < 0 || _index + length > _data.Length)
                    throw new InvalidDataException("Invalid protobuf length-delimited field.");
               byte[] result = new byte[length];
                Buffer.BlockCopy(_data, _index, result, 0, length);
                _index += length;
                return result;
            }

            public string ReadString() => Encoding.UTF8.GetString(ReadBytes());

            public void Skip(int wire)
            {
                switch (wire)
                {
                    case 0: ReadVarUInt64(); return;
                    case 1: Advance(8); return;
                    case 2: Advance(checked((int)ReadVarUInt64())); return;
                    case 5: Advance(4); return;
                    default: throw new InvalidDataException("Unsupported protobuf wire type " + wire);
                }
            }

           private void Advance(int length)
            {
                if (length < 0 || _index + length > _data.Length)
                    throw new InvalidDataException("Invalid protobuf skip length.");
                _index += length;
            }
        }

        internal sealed class Writer : IDisposable
        {
            private readonly MemoryStream _stream = new MemoryStream();
            private readonly CodedOutputStream _output;

            public Writer()
            {
                _output = new CodedOutputStream(_stream, true);
            }

            public void Varint(int field, long value, bool emitDefault = false)
            {
                if (!emitDefault && value == 0) return;
               _output.WriteTag(field, WireFormat.WireType.Varint);
                _output.WriteInt64(value);
            }

            public void Int32(int field, int value, bool emitDefault = false)
            {
                if (!emitDefault && value == 0) return;
                _output.WriteTag(field, WireFormat.WireType.Varint);
                _output.WriteInt32(value);
            }

            public void Bool(int field, bool value, bool emitDefault = false)
           {
                if (!emitDefault && !value) return;
                _output.WriteTag(field, WireFormat.WireType.Varint);
                _output.WriteBool(value);
            }

            public void Float(int field, float value, bool emitDefault = false)
            {
                if (!emitDefault && value == 0f) return;
                _output.WriteTag(field, WireFormat.WireType.Fixed32);
                _output.WriteFloat(value);
            }

            public void String(int field, string value)
            {
               if (string.IsNullOrEmpty(value)) return;
                _output.WriteTag(field, WireFormat.WireType.LengthDelimited);
                _output.WriteString(value);
            }

            public void Bytes(int field, byte[] value, bool emitEmpty = false)
            {
                value ??= Array.Empty<byte>();
                if (!emitEmpty && value.Length == 0) return;
                _output.WriteTag(field, WireFormat.WireType.LengthDelimited);
                _output.WriteBytes(ByteString.CopyFrom(value));
            }

            public void Message(int field, IMessage value)
            {
                if (value == null) return;
                Bytes(field, value.ToByteArray(), true);
            }

            public void Message(int field, byte[] value)
            {
                if (value == null) return;
                Bytes(field, value, true);
             }

            public byte[] ToArray()
            {
                _output.Flush();
                return _stream.ToArray();
            }

            public void Dispose()
            {
                _output.Dispose();
                _stream.Dispose();
            }
        }

        public static byte[] Param(RpcRequest request, int index = 0)
        {
           if (request?.Params == null || index < 0 || index >= request.Params.Count)
                return Array.Empty<byte>();
            return request.Params[index].GetBytesSafe();
        }

        public static string ReadStringField(byte[] data, int wantedField, string fallback = "")
        {
            var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                 if (field == wantedField && wire == 2) return reader.ReadString();
                reader.Skip(wire);
            }
            return fallback ?? string.Empty;
       }

        public static int ReadIntField(byte[] data, int wantedField, int fallback = 0)
        {
            var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                if (field == wantedField && wire == 0) return reader.ReadInt32();
                reader.Skip(wire);
            }
            return fallback;
        }
        public static long ReadLongField(byte[] data, int wantedField, long fallback = 0L)
        {
           var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                 if (field == wantedField && wire == 0) return reader.ReadInt64();
                reader.Skip(wire);
            }
            return fallback;
        }

        public static bool ReadBoolField(byte[] data, int wantedField, bool fallback = false)
       {
            var reader = new Reader(data);
             while (reader.TryReadField(out int field, out int wire))
             {
                if (field == wantedField && wire == 0) return reader.ReadBool();
                reader.Skip(wire);
            }
             return fallback;
        }

        public static float ReadFloatField(byte[] data, int wantedField, float fallback = 0f)
        {
            var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                if (field == wantedField && wire == 5) return reader.ReadFloat();
                reader.Skip(wire);
            }
            return fallback;
        }

        public static List<int> ReadRepeatedIntField(byte[] data, int wantedField)
        {
            var result = new List<int>();
            var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                if (field != wantedField)
                {
                    reader.Skip(wire);
                    continue;
                }

                if (wire == 0)
                {
                   result.Add(reader.ReadInt32());
                }
                else if (wire == 2)
                {
                    var packed = new Reader(reader.ReadBytes());
                    while (!packed.End) result.Add(packed.ReadInt32());
                }
               else
                {
                    reader.Skip(wire);
                }
            }
            return result;
        }

       public static List<string> ReadRepeatedStringField(byte[] data, int wantedField)
        {
            var result = new List<string>();
           var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
                if (field == wantedField && wire == 2) result.Add(reader.ReadString());
                else reader.Skip(wire);
            }
            return result;
        }

        public static byte[] ReadBytesField(byte[] data, int wantedField)
        {
            var reader = new Reader(data);
            while (reader.TryReadField(out int field, out int wire))
            {
               if (field == wantedField && wire == 2) return reader.ReadBytes();
                reader.Skip(wire);
            }
            return Array.Empty<byte>();
        }

         public static byte[] DecryptParam(ClientSession user, RpcRequest request, int index, string traceName)
        {
            byte[] cipher = Param(request, index);
            byte[] key = user.GetSessionKey();
            byte[] iv = user.GetSessionIv();
            if (key?.Length != 16 || iv?.Length != 16)
                throw new InvalidOperationException("Session AES is not prepared for " + traceName);
            if (cipher.Length == 0 || cipher.Length % 16 != 0)
                throw new InvalidDataException($"Invalid AES payload for {traceName}: bytes={cipher.Length}");

            byte[] plain = Protocol.DecryptAesCbc(cipher, key, iv);
            return plain;
        }

         public static byte[] Build(Action<Writer> build)
        {
            using var writer = new Writer();
            build?.Invoke(writer);
            return writer.ToArray();
        }

        public static byte[] WrapMessage(int field, IMessage value) => Build(w => w.Message(field, value));

        public static byte[] WrapRepeated<T>(int field, IEnumerable<T> values) where T : class, IMessage
        {
            return Build(w =>
           {
                if (values == null) return;
                foreach (T value in values)
                    if (value != null) w.Message(field, value);
            });
        }

        public static void SendRaw(ClientSession user, string requestId, byte[] response)
        {
            RpcResponseWriter.SendPayload(user, requestId, response ?? Array.Empty<byte>());
        }
        public static void SendEmpty(ClientSession user, string requestId)
        {
            SendRaw(user, requestId, Array.Empty<byte>());
        }

         public static void SendEncrypted(ClientSession user, string requestId, byte[] plain, string traceName)
        {
            byte[] key = user.GetSessionKey();
            byte[] iv = user.GetSessionIv();
            if (key?.Length != 16 || iv?.Length != 16)
                throw new InvalidOperationException("Session AES is not prepared for " + traceName);

            byte[] cipher = Protocol.EncryptAesCbc(plain ?? Array.Empty<byte>(), key, iv);
            RpcResponseWriter.SendPayload(user, requestId, cipher);
        }

        public static void SendException(ClientSession user, string requestId, int code)
        {
            user.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                 {
                    Id = requestId,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
