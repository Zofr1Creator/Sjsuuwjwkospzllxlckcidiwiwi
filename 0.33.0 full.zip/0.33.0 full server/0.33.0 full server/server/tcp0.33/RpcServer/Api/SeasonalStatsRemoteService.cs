using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    public sealed class SeasonalStatsRemoteService : RpcHandler
    {
        private readonly ClanStatsRemoteService _clanStats;

        public SeasonalStatsRemoteService(ClientSession user, ClanStatsRemoteService clanStats) : base(user)
       {
            _clanStats = clanStats ?? throw new ArgumentNullException(nameof(clanStats));
        }

        public override void Invoke(RpcRequest request)
        {
            switch (request.MethodName)
             {
                case "getPlayerStatsForSeason":
                case "getPlayerStatsForSeason2":
                     GetPlayerStatsForSeason(request, explicitPlayer: true);
                    return;
                case "getStatsForSeason":
                case "getStatsForSeason2":
                    GetPlayerStatsForSeason(request, explicitPlayer: false);
                   return;
                case "getCurrentClanStatsForSeason":
                case "getCurrentClanStatsForSeason2":
                 case "getClanStatsForSeason":
                case "getClanStatsForSeason2":
                   _clanStats.Invoke(request);
                    return;
                default:
                    ContractWire.SendException(_session, request.Id, 404);
                   return;
            }
        }

         private void GetPlayerStatsForSeason(RpcRequest request, bool explicitPlayer)
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string currentPlayerId) ||
                string.IsNullOrWhiteSpace(currentPlayerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
            }

             byte[] raw = ContractWire.Param(request);
            string seasonId = ContractWire.ReadStringField(raw, 1, string.Empty).Trim();
            if (seasonId.Length == 0) seasonId = PlayerStatsRemoteService.SeasonId;
            string playerId = explicitPlayer
               ? ContractWire.ReadStringField(raw, 2, string.Empty).Trim()
               : currentPlayerId;
            if (playerId.Length == 0) playerId = currentPlayerId;

            if (!ObjectId.TryParse(playerId, out ObjectId objectId))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
             }

            try
            {
                if (BoltMainDatabaseProvider.Instance.GetPlayerDocument(objectId) == null)
                {
                    ContractWire.SendException(_session, request.Id, 404);
                    return;
                }
            }
            catch
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }

           try
            {
                BoltGameDatabaseProvider database = BoltGameDatabaseProvider.Instance;
                BsonDocument stored = database.GetSeasonStats(playerId, seasonId);
                List<BsonElement> stats;
                string source;

                if (stored != null)
                {
                     stats = stored.Elements.ToList();
                    source = "snapshot";
                }
                else if (string.Equals(seasonId, PlayerStatsRemoteService.SeasonId, StringComparison.Ordinal))
                {
                    stats = PlayerStatsRemoteService.LoadStats(playerId);
                   database.StoreSeasonStatsSnapshot(playerId, seasonId, stats);
                    source = "current-authority";
                }
               else
                {
                    stats = new List<BsonElement>();
                    source = "empty-historical";
                }

               byte[] response = ContractWire.Build(w =>
                {
                    foreach (BsonElement element in stats)
                    {
                        if (string.IsNullOrWhiteSpace(element.Name) || element.Value == null || element.Value.IsBsonNull)
                            continue;
                        w.Message(1, PlayerStatsRemoteService.BuildPlayerStat(element));
                     }
                 });

                ContractWire.SendRaw(_session, request.Id, response);
            }
            catch (System.Exception)
             {
                ContractWire.SendException(_session, request.Id, 500);
            }
        }
    }
}
