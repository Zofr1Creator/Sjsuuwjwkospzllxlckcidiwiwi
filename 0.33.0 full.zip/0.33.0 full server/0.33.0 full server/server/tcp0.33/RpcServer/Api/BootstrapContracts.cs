using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    internal static class BootstrapContracts
    {
        internal sealed class Result
        {
            public byte[] Bytes { get; set; } = Array.Empty<byte>();
             public string Contract { get; set; } = "canonical-empty";
            public string Detail { get; set; } = string.Empty;
        }

        public static Result Build(ClientSession user, string method, RpcRequest request)
        {
           switch (method ?? string.Empty)
            {
                case "getMarketplaceSettings2":
                    return Fixed(MarketplaceSettings(),
                        "GetMarketplaceSettingsResponse",
                        "MarketplaceSettings+Banned materialized; market defaults mirror server config");

                case "getRentMarketSettings":
                    return Fixed(RentMarketSettings(),
                        "GetRentMarketSettingsResponse",
                        "RentMarketSettings+Banned materialized; rent market disabled until full migration");

                case "getClanSettings2":
                    return Fixed(ClanSettings(),
                        "GetClanSettingsResponse",
                        "ClanSettings and all CurrencyAmount children materialized");

               case "getPlayerSettings2":
                    return Fixed(PlayerSettings(user),
                        "GetPlayerSettingsResponse",
                        "exact 0.33 PlayerSettings map restored from per-player Mongo persistence");

                case "readFiles":
                    return ReadFilesResponse(user, request);

                case "findCreatorSubscription":
                    return Fixed(SubscribedCreator(),
                        "GetSubscribedCreatorResponse",
                       "Creator materialized as an inactive empty subscription");

                case "getPlayerState":
                    return Fixed(ReferralState(),
                        "GetReferralPlayerStateResponse",
                        "ReferralPlayerStateLite selected with Recruit state and RecruitInfo");

                case "getSettings":
                    return Fixed(ReferralSettings(),
                        "GetReferralSystemSettingsResponse",
                        "complete disabled settings graph; cashback value oneofs select Percent");

                case "getPlayerOpenRequests2":
                    return Empty("GetPlayerOpenRequestsResponse", "repeated OpenRequests");
                case "getClan2":
                    return Empty("GetClanResponse", "optional Clan omitted to represent no clan membership");
               case "getPlayerInviteRequestsCount2":
                    return Empty("GetPlayerInviteRequestsCountResponse", "scalar Count defaults to 0");
                case "getPlayerGameEventsProgresses":
                    return Empty("GetPlayerGameEventsProgressesResponse", "repeated GameEventsProgresses");
                case "getPlayerProcessingRequests2":
                   return Empty("GetPlayerProcessingRequestResponse", "repeated ProcessingRequests");
                case "getRoles2":
                    return Fixed(ClanRolesResponse(),
                        "GetRolesResponse",
                        "exact clan role hierarchy + 0.33 permission sets materialized");
                case "getCachedPlayerGameEvents":
                     return Empty("GetCachedPlayerGameEventsResponse", "repeated GameEvents; LastUpdated and MsUntilRefresh default safely");
                case "getPlayerFriendsIds2":
                    return Empty("GetPlayerFriendsIdsResponse", "repeated FriendGpids");
                case "getInvitesToLobby2":
                    return Empty("GetInvitesToLobbyResponse", "repeated LobbyInvites");
                case "getChatUsersLite":
                    return Empty("GetChatUsersLiteResponse", "repeated ChatUsers");
                case "getUnreadChatMessagesCount2":
                    return Empty("GetUnreadChatMessagesCountResponse", "scalar Count defaults to 0");
                case "getPlayerFriends2":
                    return Empty("GetPlayerFriendsResponse", "repeated PlayerFriends");
                case "getUnreadLogMessagesCount2":
                    return Empty("GetUnreadLogMessagesCountResponse", "scalar Count defaults to 0");
                case "getLastRateGame":
                    return Empty("GetLastRateGameResponse", "scalars/strings/repeated; Reward is optional");
                case "getSpecialOffers":
                   return Empty("GetSpecialOffersResponse", "repeated offers");
                case "getCurrentClanStats":
                    return Empty("GetCurrentClanStatsResponse", "native loader null-checks optional Stats/ClanStats");
                case "getCurrentPlayerLastMatch":
                    return Empty("GetCurrentPlayerLastMatchResponse", "native loader null-checks both optional matches");
                case "getLinkedAuth":
                     return Empty("GetLinkedAuthResponse", "repeated AuthTypes");
                case "getItems2":
                    return Empty("GetItemsResponse", "repeated Items");
                case "getAllAnnouncements":
                    return Empty("GetAllGameAnnouncementsResponse", "repeated Announcements");
                case "getAllDlc":
                   return Empty("DlcResponse", "repeated Dlcs/CdnUrls");
                case "getCurrentPlayerAchievements":
                    return Empty("GetCurrentPlayerAchievementsResponse", "repeated Achievements");
                default:
                    return Empty("unknown-bootstrap-response", "no dedicated 0.33 contract builder");
            }
        }

        private static Result Fixed(byte[] bytes, string contract, string detail)
        {
            return new Result { Bytes = bytes ?? Array.Empty<byte>(), Contract = contract, Detail = detail };
         }

       private static Result Empty(string contract, string detail)
         {
            return new Result { Bytes = Array.Empty<byte>(), Contract = contract, Detail = detail };
        }

        private static byte[] ClanRolesResponse()
        {
            var roles = new[]
            {
                ClanRole(0, "Leader", 4, "Clan leader", 0,1,2,3,4,5,6,7,8,9),
                ClanRole(10, "Co-Leader", 3, "Clan co-leader", 0,1,2,3,5,7,8,9),
                ClanRole(100, "Elder", 2, "Clan elder", 1,2,3,8),
                ClanRole(1000, "Member", 1, "Clan member", 8)
            };

            return Message(w =>
           {
                foreach (byte[] role in roles)
                    w.Message(1, role);
            });
        }

        private static byte[] ClanRole(int id, string name, int level, string description, params int[] permissions)
        {
            return Message(w =>
            {
               w.Varint(1, unchecked((ulong)id));
                w.String(2, name);
                w.Varint(3, unchecked((ulong)level));
                w.String(4, description);
                if (permissions != null)
                    foreach (int permission in permissions)
                         w.Varint(5, unchecked((ulong)permission));
           });
        }

        private static byte[] MarketplaceSettings()
        {
            byte[] banned = Message(w =>
            {
                w.Varint(1, 0);
                w.Varint(2, 0);
            });

            byte[] settings = Message(w =>
             {
                w.Float(1, 0.20f);
                w.Float(2, 0.03f);
                w.Varint(3, 101);
                w.Varint(4, 1);
                w.Message(6, banned);
            });

            return Message(w => w.Message(1, settings));
        }

        private static byte[] RentMarketSettings()
        {
            byte[] banned = Message(w =>
            {
                w.Varint(1, 0);
                w.Varint(2, 0);
            });
            byte[] settings = Message(w =>
            {
                w.Float(1, 0.20f);
                w.Float(2, 0.03f);
                w.Varint(3, 101);
                w.Varint(4, 0);
                w.Message(6, banned);
                w.Varint(7, 0);
                w.Varint(8, 0);
           });

            return Message(w => w.Message(1, settings));
        }

        private static byte[] ClanSettings()
        {
            byte[] upgradeCost = CurrencyAmount(102, 200f);
            byte[] renameCost = CurrencyAmount(102, 100f);
           byte[] createCost = CurrencyAmount(102, 500f);

           byte[] settings = Message(w =>
            {
                w.Varint(1, 10);
                w.Varint(2, 50);
                w.Message(3, upgradeCost);
                w.Message(4, renameCost);
                w.Message(5, createCost);
             });

            return Message(w => w.Message(1, settings));
        }

        private static byte[] CurrencyAmount(int currencyId, float value)
        {
            return Message(w =>
            {
                w.Varint(1, (ulong)Math.Max(0, currencyId));
                w.Varint(2, 0);
               w.Float(3, value);
           });
        }

        private const string PlayerSettingsCollection = "player_settings_033";

        private static byte[] PlayerSettings(ClientSession user)
        {
            Dictionary<string, string> settings = LoadPlayerSettings(user);
            byte[] playerSettings = Message(sw =>
            {
                foreach (KeyValuePair<string, string> pair in settings.OrderBy(x => x.Key, StringComparer.Ordinal))
                {

                    byte[] entry = Message(ew =>
                    {
                        ew.String(1, pair.Key ?? string.Empty);
                        ew.String(2, pair.Value ?? string.Empty);
                    });
                    sw.Message(1, entry);
                }
            });

            string language = FindLanguageSetting(settings);
            return Message(w => w.Message(1, playerSettings));
         }

        internal static bool LooksLikeLanguagePlayerSettingsWrite(RpcRequest request, out Dictionary<string, string> settings)
        {
            settings = ParsePlayerSettingsRequest(request);
            return settings.Count > 0 && settings.Keys.Any(IsLanguageSettingKey);
        }

        internal static bool SavePlayerSettings(ClientSession user, RpcRequest request, out int keyCount, out string language)
        {
            Dictionary<string, string> settings = ParsePlayerSettingsRequest(request);
            keyCount = settings.Count;
            language = FindLanguageSetting(settings);
            string playerId = PlayerId(user);
            if (string.IsNullOrWhiteSpace(playerId) || settings.Count == 0)
                return false;

            IMongoCollection<BsonDocument> collection = BoltMainDatabaseProvider.Instance
                .GetDatabase().GetCollection<BsonDocument>(PlayerSettingsCollection);
            BsonDocument bsonSettings = new BsonDocument();
            foreach (KeyValuePair<string, string> pair in settings)
               bsonSettings[pair.Key] = pair.Value ?? string.Empty;

            var update = Builders<BsonDocument>.Update
                .Set("settings", bsonSettings)
                .Set("updatedUtc", DateTime.UtcNow);
           collection.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("_id", playerId),
                update,
                new UpdateOptions { IsUpsert = true });
            return true;
        }

        private static Dictionary<string, string> LoadPlayerSettings(ClientSession user)
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
            string playerId = PlayerId(user);
            if (string.IsNullOrWhiteSpace(playerId) || BoltMainDatabaseProvider.Instance == null)
                return result;
            try
            {
                IMongoCollection<BsonDocument> collection = BoltMainDatabaseProvider.Instance
                    .GetDatabase().GetCollection<BsonDocument>(PlayerSettingsCollection);
                BsonDocument doc = collection.Find(Builders<BsonDocument>.Filter.Eq("_id", playerId)).FirstOrDefault();
                if (doc != null && doc.TryGetValue("settings", out BsonValue value) && value.IsBsonDocument)
                {
                    foreach (BsonElement element in value.AsBsonDocument.Elements)
                        if (element.Value.IsString) result[element.Name] = element.Value.AsString;
                }
            }
            catch (System.Exception)
            {
            }
            return result;
        }

       private static Dictionary<string, string> ParsePlayerSettingsRequest(RpcRequest request)
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
             try
            {
                byte[] requestBytes = ContractWire.Param(request);
                byte[] playerSettings = ContractWire.ReadBytesField(requestBytes, 1);
                var reader = new ContractWire.Reader(playerSettings);
                while (reader.TryReadField(out int field, out int wire))
                {
                    if (field != 1 || wire != 2) { reader.Skip(wire); continue; }
                    byte[] entry = reader.ReadBytes();
                    string key = ContractWire.ReadStringField(entry, 1, string.Empty);
                     string value = ContractWire.ReadStringField(entry, 2, string.Empty);
                    if (!string.IsNullOrWhiteSpace(key)) result[key] = value ?? string.Empty;
                }
            }
            catch { result.Clear(); }
            return result;
        }

        private static bool IsLanguageSettingKey(string key)
        {
            return !string.IsNullOrWhiteSpace(key) &&
                   (key.IndexOf("language", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    key.IndexOf("locale", StringComparison.OrdinalIgnoreCase) >= 0);
         }

        private static string FindLanguageSetting(Dictionary<string, string> settings)
        {
            if (settings == null) return string.Empty;
            foreach (KeyValuePair<string, string> pair in settings)
                 if (IsLanguageSettingKey(pair.Key)) return pair.Key + "=" + pair.Value;
             return string.Empty;
        }

        private static string PlayerId(ClientSession user)
        {
            if (user?.TcpClient != null && ServerState.Users.TryGetValue(user.TcpClient, out string playerId))
                return playerId ?? string.Empty;
            return string.Empty;
        }

        private static Result ReadFilesResponse(ClientSession user, RpcRequest request)
        {
            byte[] requestBytes = ReadFirstParam(request);
            List<string> filenames = ReadStrings(requestBytes, 1);
            Dictionary<string, byte[]> stored = LoadStoredFiles(user, filenames);

            var responseNames = new List<string>(filenames);
            bool injectedRejoin = false;
            if (stored.TryGetValue("rejoin_options", out byte[] injectedBytes) &&
                injectedBytes != null && injectedBytes.Length > 0 &&
                !responseNames.Any(x => string.Equals(x, "rejoin_options", StringComparison.OrdinalIgnoreCase)))
            {
                responseNames.Add("rejoin_options");
                injectedRejoin = true;
            }
            if (injectedRejoin &&
                !responseNames.Any(x => string.Equals(x, "last_match_status", StringComparison.OrdinalIgnoreCase)))
            {
                responseNames.Add("last_match_status");
            }

            byte[] response = Message(w =>
            {
                foreach (string filename in responseNames)
                {
                    byte[] fileBytes = stored.TryGetValue(filename, out byte[] found)
                         ? found ?? Array.Empty<byte>()
                        : Array.Empty<byte>();

                    byte[] storage = Message(sw =>
                     {
                        sw.String(1, filename ?? string.Empty);
                       sw.Bytes(2, fileBytes);
                        sw.String(3, string.Empty);
                        sw.String(4, string.Empty);
                    });
                    w.Message(1, storage);
                }
            });

            return new Result
            {
               Bytes = response,
                Contract = "ReadFilesResponse",
                 Detail = $"requested={filenames.Count} emitted={responseNames.Count} dbHits={stored.Count}; reconnectInjected={injectedRejoin}"
            };
        }

        private static Dictionary<string, byte[]> LoadStoredFiles(ClientSession user, IEnumerable<string> filenames)
        {
            var result = new Dictionary<string, byte[]>(StringComparer.Ordinal);
            try
            {
                if (user?.TcpClient == null ||
                    !ServerState.Users.TryGetValue(user.TcpClient, out string playerId) ||
                    !ObjectId.TryParse(playerId, out ObjectId objectId))
                {
                     return result;
                }

                byte[] authoritativeRejoin = StorageRemoteService.BuildActiveRejoinOptions(playerId);
                if (authoritativeRejoin.Length > 0)
                {
                    result["rejoin_options"] = authoritativeRejoin;
                    result["last_match_status"] = Encoding.UTF8.GetBytes("0");
                }
                var doc = BoltGameDatabaseProvider.Instance.GetFiles(objectId);
                if (doc?.files == null)
                    return result;

                foreach (string filename in filenames ?? Enumerable.Empty<string>())
                {
                    if (string.IsNullOrEmpty(filename))
                        continue;

                    if (string.Equals(filename, "rejoin_options", StringComparison.OrdinalIgnoreCase))
                    {
                        result[filename] = authoritativeRejoin;
                        continue;
                    }
                    if (string.Equals(filename, "last_match_status", StringComparison.OrdinalIgnoreCase))
                    {
                        if (authoritativeRejoin.Length > 0)
                        {
                            result[filename] = Encoding.UTF8.GetBytes("0");
                            continue;
                        }
                    }

                    if (!doc.files.TryGetValue(filename, out BsonValue value) || value == null || !value.IsBsonArray)
                        continue;

                    byte[] bytes = value.AsBsonArray
                        .Where(x => x != null && (x.IsInt32 || x.IsInt64))
                        .Select(x => unchecked((byte)(x.IsInt32 ? x.AsInt32 : x.AsInt64)))
                        .ToArray();
                    result[filename] = bytes;
                }
            }
            catch
           {
                result.Clear();
            }
            return result;
        }

        private static byte[] SubscribedCreator()
        {
            byte[] creator = Message(w =>
            {
                w.String(1, string.Empty);
                w.String(2, string.Empty);
                w.Varint(3, 0);
            });
            return Message(w => w.Message(1, creator));
        }

        private static byte[] ReferralState()
        {
            byte[] recruitInfo = Message(w =>
            {
               w.String(1, string.Empty);
                w.Varint(2, 0);
            });

            byte[] stateLite = Message(w =>
            {
               w.Varint(1, 0);
                w.Message(2, recruitInfo);
            });

            return Message(w => w.Message(2, stateLite));
        }

         private static byte[] ReferralSettings()
        {
            byte[] systemSettings = Message(w =>
            {
               w.String(1, string.Empty);
                w.String(2, string.Empty);
                w.Varint(3, 0);
               w.Varint(4, 0);
                w.Varint(5, 0);
            });

            byte[] payment = Message(w =>
           {
                w.Float(2, 0f);
            });

            byte[] cashback = Message(w =>
            {
                w.Message(1, payment);
                w.Message(2, payment);
                w.Varint(3, 0);
                w.Varint(5, 0);
            });

            return Message(w =>
            {
               w.Message(1, systemSettings);
                w.Message(2, cashback);
            });
        }

        private static byte[] ReadFirstParam(RpcRequest request)
        {
            try
             {
                if (request?.Params == null || request.Params.Count == 0 || request.Params[0] == null)
                    return Array.Empty<byte>();
                return request.Params[0].One?.ToByteArray() ?? Array.Empty<byte>();
            }
            catch
            {
                return Array.Empty<byte>();
            }
        }

        private static List<string> ReadStrings(byte[] bytes, int targetField)
        {
            var result = new List<string>();
            if (bytes == null || bytes.Length == 0)
                return result;

            int offset = 0;
            try
            {
                while (offset < bytes.Length)
                {
                    ulong tag = ReadVarint(bytes, ref offset);
                    if (tag == 0)
                        break;
                    int field = (int)(tag >> 3);
                    int wire = (int)(tag & 7);

                    if (wire == 2)
                    {
                        int length = checked((int)ReadVarint(bytes, ref offset));
                        if (length < 0 || offset + length > bytes.Length)
                            break;
                        if (field == targetField)
                            result.Add(Encoding.UTF8.GetString(bytes, offset, length));
                        offset += length;
                   }
                    else
                    {
                        SkipField(bytes, ref offset, wire);
                    }
                }
           }
            catch
            {
            }

            return result;
        }

        private static ulong ReadVarint(byte[] bytes, ref int offset)
        {
            ulong value = 0;
            int shift = 0;
            while (offset < bytes.Length && shift < 64)
            {
                byte b = bytes[offset++];
                value |= (ulong)(b & 0x7F) << shift;
                if ((b & 0x80) == 0)
                    return value;
                shift += 7;
            }
            throw new InvalidDataException("Invalid protobuf varint");
        }

        private static void SkipField(byte[] bytes, ref int offset, int wire)
        {
            switch (wire)
            {
                case 0:
                    ReadVarint(bytes, ref offset);
                    break;
                case 1:
                    offset = checked(offset + 8);
                    break;
                case 2:
                   offset = checked(offset + checked((int)ReadVarint(bytes, ref offset)));
                    break;
                case 5:
                    offset = checked(offset + 4);
                    break;
                default:
                    throw new InvalidDataException("Unsupported protobuf wire type " + wire);
            }
            if (offset < 0 || offset > bytes.Length)
                throw new InvalidDataException("Protobuf field exceeds input");
        }

        private static byte[] Message(Action<WireWriter> write)
        {
             using (var stream = new MemoryStream())
            {
                var writer = new WireWriter(stream);
                write?.Invoke(writer);
                return stream.ToArray();
            }
        }

        private sealed class WireWriter
        {
            private readonly Stream _stream;

            public WireWriter(Stream stream)
             {
                _stream = stream ?? throw new ArgumentNullException(nameof(stream));
            }

            public void Varint(int fieldNumber, ulong value)
            {
                Tag(fieldNumber, 0);
                RawVarint(value);
            }

            public void Float(int fieldNumber, float value)
            {
                Tag(fieldNumber, 5);
                byte[] bytes = BitConverter.GetBytes(value);
                if (!BitConverter.IsLittleEndian)
                   Array.Reverse(bytes);
                _stream.Write(bytes, 0, bytes.Length);
            }

            public void String(int fieldNumber, string value)
           {
                Bytes(fieldNumber, Encoding.UTF8.GetBytes(value ?? string.Empty));
            }

            public void Bytes(int fieldNumber, byte[] value)
            {
                byte[] bytes = value ?? Array.Empty<byte>();
                Tag(fieldNumber, 2);
                RawVarint((ulong)bytes.Length);
                _stream.Write(bytes, 0, bytes.Length);
            }

            public void Message(int fieldNumber, byte[] value)
            {
                Bytes(fieldNumber, value ?? Array.Empty<byte>());
            }

            private void Tag(int fieldNumber, int wireType)
            {
                if (fieldNumber <= 0)
                    throw new ArgumentOutOfRangeException(nameof(fieldNumber));
                RawVarint((ulong)((fieldNumber << 3) | wireType));
            }

           private void RawVarint(ulong value)
            {
               while (value >= 0x80)
                {
                    _stream.WriteByte((byte)((value & 0x7F) | 0x80));
                    value >>= 7;
                }
                _stream.WriteByte((byte)value);
            }
        }
    }
}
