using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TspServer.RpcServer.Api
{
    internal static class SwissSanctionBridgeClient
    {
        private static string Host =>
            Environment.GetEnvironmentVariable("BOLT_TO_SWISS_SANCTION_HOST") ?? "127.0.0.1";

        private static int Port =>
            int.TryParse(Environment.GetEnvironmentVariable("BOLT_TO_SWISS_SANCTION_PORT"), out int port) && port > 0
                ? port
                : 2235;

        private static string Secret =>
            Environment.GetEnvironmentVariable("BOLT_TO_SWISS_SANCTION_SECRET") ??
            Environment.GetEnvironmentVariable("BOLT_PRESENCE_BRIDGE_SECRET") ??
            string.Empty;

        public static async Task NotifyAsync(string playerId, string reason, string source)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return;

            try
            {
                await Task.Delay(250).ConfigureAwait(false);

                using var client = new TcpClient { NoDelay = true };
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));

                await client.ConnectAsync(Host, Port, timeout.Token).ConfigureAwait(false);

                NetworkStream stream = client.GetStream();
                string[] fields = string.IsNullOrEmpty(Secret)
                    ? new[] { "BAN", Encode(playerId), Encode(reason), Encode(source) }
                    : new[] { Secret, "BAN", Encode(playerId), Encode(reason), Encode(source) };

                byte[] frame = Encoding.UTF8.GetBytes(string.Join("|", fields) + "\n");
                await stream.WriteAsync(frame, timeout.Token).ConfigureAwait(false);
                await stream.FlushAsync(timeout.Token).ConfigureAwait(false);

                using var reader = new StreamReader(stream, Encoding.UTF8, false, 512, leaveOpen: true);
                await reader.ReadLineAsync().ConfigureAwait(false);
            }
            catch
            {
            }
        }

        private static string Encode(string value)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? string.Empty));
        }
    }
}
