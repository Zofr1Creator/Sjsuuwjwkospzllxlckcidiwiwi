using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
    using Proto = Axlebolt.Bolt.Protobuf2;

    public sealed class MarketplaceRemoteService : RpcHandler
    {
        public MarketplaceRemoteService(ClientSession user) : base(user)
       {
        }
        public override void Invoke(RpcRequest request)
        {
            if (request == null) return;
            EnsureMarketEvents();

            string method = (request.MethodName ?? string.Empty).Trim();
            string key = method.ToLowerInvariant();
            if (key == "getplayerprocessingrequest") key = "getplayerprocessingrequests";

            // same
            if (key == "createpurchasebysale") key = "createpurchaserequestbysale";


            try
            {
                BinaryValue[] args = request.Params?.ToArray() ?? Array.Empty<BinaryValue>();
                switch (key)
                {
                    case "getplayerprocessingrequests2": GetPlayerProcessingRequestsV2(request.Id); return;
                    case "getplayeropenrequests2": GetPlayerOpenRequestsV2(request.Id); return;
                    case "getplayerclosedrequests2": GetPlayerClosedRequestsV2(request); return;
                    case "gettrade2": GetTradeV2(request); return;
                    case "gettradeopensalerequests2": GetTradeOpenSaleRequestsV2(request); return;
                    case "gettradeopenpurchaserequests2": GetTradeOpenPurchaseRequestsV2(request); return;
           
                    case "createpurchaserequest2": CreatePurchaseRequestV2(request); return;
                    case "createpurchaserequestbysale2": CreatePurchaseRequestBySaleV2(request); return;
                     case "createsale2": CreateSaleV2(request); return;
                    case "cancelrequest2": CancelRequestV2(request); return;
              
                    case "getplayerclosedrequestscount2": GetPlayerClosedRequestsCountV2(request); return;
                    case "getmarketplacesettings2": GetMarketplaceSettingsV2(request); return;
                    case "getmarketplacesettings": GetMarketplaceSettings(request.Id); return;
                    case "getplayerprocessingrequests": GetPlayerProcessingRequests(request.Id); return;
                    case "getplayeropenrequests": GetPlayerOpenRequests(request.Id); return;
                    case "createsale": CreateSale(args, request.Id); return;
                    case "createsalerequest": CreateSaleRequest(args, request.Id); return;
                    case "createpurchaserequest": CreatePurchaseRequest(args, request.Id); return;
                    case "createpurchaserequestbysale": CreatePurchaseRequestBySale(args, request.Id); return;
                    case "cancelrequest": CancelRequest(args, request.Id); return;
                    case "gettrades2": GetTradesV2(request); return;
                    case "gettrades": GetTrades(args, request.Id); return;
                    case "gettrade": GetTrade(args, request.Id); return;
                   case "gettradeopensalerequests": GetTradeOpenSaleRequests(args, request.Id); return;
                    case "gettradeopenpurchaserequests": GetTradeOpenPurchaseRequests(args, request.Id); return;
                    case "getplayerclosedrequestscount": GetPlayerClosedRequestsCount(args, request.Id); return;
                    case "getplayerclosedrequests": GetPlayerClosedRequests(args, request.Id); return;
                    default:
                        SendException(request.Id, 404);
                         return;
                 }
            }
            catch (MarketplaceEngine.MarketError ex)
            {
                SendException(request.Id, ex.Code);
            }
            catch
            {
                SendException(request.Id, 500);
            }
         }

        private void GetTradeV2(RpcRequest request)
        {
            int id = ContractWire.ReadIntField(ContractWire.Param(request), 1, 0);
            if (id <= 0) throw new MarketplaceEngine.MarketError(400, "invalid trade id");
            var trade = MarketplaceEngine.GetTrade(id);
            var response = ContractWire.Build(w => w.Message(1, trade));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetTradeOpenSaleRequestsV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            int id = ContractWire.ReadIntField(raw, 1, 0);
            int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int size = Math.Max(1, Math.Min(ContractWire.ReadIntField(raw, 3, 20), 200));
            if (id <= 0) throw new MarketplaceEngine.MarketError(400, "invalid trade id");
           Proto.OpenRequest[] values = MarketplaceEngine.GetTradeOpenRequests(id, Proto.MarketRequestType.SaleRequest, page, size).ToArray();
            string viewerPlayerId = GetPlayerId();
            byte[] response = MarketplaceWire.RepeatedOpenRequests(values, viewerPlayerId);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetTradeOpenPurchaseRequestsV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            int id = ContractWire.ReadIntField(raw, 1, 0);
           int page = Math.Max(0, ContractWire.ReadIntField(raw, 2, 0));
            int size = Math.Max(1, Math.Min(ContractWire.ReadIntField(raw, 3, 20), 200));
            if (id <= 0) throw new MarketplaceEngine.MarketError(400, "invalid trade id");
            Proto.OpenRequest[] values = MarketplaceEngine.GetTradeOpenRequests(id, Proto.MarketRequestType.PurchaseRequest, page, size).ToArray();
            string viewerPlayerId = GetPlayerId();
            byte[] response = MarketplaceWire.RepeatedOpenRequests(values, viewerPlayerId);
            ContractWire.SendRaw(_session, request.Id, response);
         }

        private void CreatePurchaseRequestV2(RpcRequest request)
        {
            string playerId = GetPlayerId();
            var cfg = GetConfig();
            byte[] raw = ContractWire.Param(request);
            int itemDefinitionId = ContractWire.ReadIntField(raw, 1, 0);
            float price = ContractWire.ReadFloatField(raw, 2, 0f);
            int quantity = ContractWire.ReadIntField(raw, 3, 0);
            if (itemDefinitionId <= 0 || quantity <= 0 || price < cfg.MinPrice)
                throw new MarketplaceEngine.MarketError(400, "invalid purchase request");
            MarketplaceEngine.CreateResult result = MarketplaceEngine.CreatePurchaseRequestWithInfo(
                playerId, itemDefinitionId, price, quantity,
                cfg.CurrencyId, cfg.CommissionPercent, cfg.MinCommission);
            byte[] response = ContractWire.Build(w => w.String(1, result.RequestId));
            ContractWire.SendRaw(_session, request.Id, response);
            PublishRequest(result);
        }

        private void CreatePurchaseRequestBySaleV2(RpcRequest request)
        {
            string playerId = GetPlayerId();
             var cfg = GetConfig();
            string saleId = ContractWire.ReadStringField(
                ContractWire.Param(request), 1, string.Empty);
            if (string.IsNullOrWhiteSpace(saleId))
                throw new MarketplaceEngine.MarketError(400, "invalid sale id");

            MarketplaceEngine.CreateResult result =
                MarketplaceEngine.CreatePurchaseBySaleWithInfo(
                    playerId, saleId, MarketplaceEngine.MarketCurrencyId,
                    cfg.CommissionPercent, cfg.MinCommission);

            byte[] response = ContractWire.Build(w => w.String(1, result.RequestId));
            ContractWire.SendRaw(_session, request.Id, response);
            PublishRequest(result);
        }

        private void CreateSaleV2(RpcRequest request)
        {
            byte[] raw = ContractWire.Param(request);
            int itemId = ContractWire.ReadIntField(raw, 1, 0);
            float price = ContractWire.ReadFloatField(raw, 2, 0f);
            if (itemId <= 0) throw new MarketplaceEngine.MarketError(400, "invalid item id");
            MarketplaceEngine.CreateResult result = CreateSaleCore(itemId, price);
             byte[] response = ContractWire.Build(w => w.String(1, result.RequestId));
            ContractWire.SendRaw(_session, request.Id, response);
            PublishRequest(result);
        }

        private void CancelRequestV2(RpcRequest request)
         {
            string playerId = GetPlayerId();
            string targetRequestId = ContractWire.ReadStringField(
               ContractWire.Param(request), 1, string.Empty);

            if (string.IsNullOrWhiteSpace(targetRequestId))
                throw new MarketplaceEngine.MarketError(400, "invalid request id");

            try
            {
                MarketplaceEngine.CancelResult result =
                    MarketplaceEngine.CancelRequestWithInfo(playerId, targetRequestId);

                ContractWire.SendRaw(_session, request.Id, Array.Empty<byte>());

                if (result.Item != null)
                {
                    InventoryEventBus.InventoryChanged(
                        playerId,
                        added: new[] { result.Item },
                        source: "market-cancel-return");
                }

                MarketplaceEventBus.PlayerRequestClosed(
                    playerId, result.Request, result.Item);
                MarketplaceEventBus.TradeRequestClosed(
                     result.ItemDefinitionId, result.Request, playerId);
                MarketplaceEventBus.TradeUpdated(
                    result.ItemDefinitionId,
                    MarketplaceEngine.GetTrade(result.ItemDefinitionId),
                    playerId);

            }
            catch (MarketplaceEngine.MarketError ex) when (
                ex.Code == 401 && ex.Message == "request owner mismatch")
            {
                var cfg = GetConfig();
                MarketplaceEngine.CreateResult purchase =
                    MarketplaceEngine.CreatePurchaseBySaleWithInfo(
                        playerId, targetRequestId, cfg.CurrencyId,
                        cfg.CommissionPercent, cfg.MinCommission);

                byte[] response = ContractWire.Build(w => w.String(1, purchase.RequestId));
                ContractWire.SendRaw(_session, request.Id, response);

                PublishRequest(purchase);

            }
        }

        private void GetPlayerClosedRequestsCountV2(RpcRequest request)
        {
             string playerId = GetPlayerId();
            byte[] raw = ContractWire.Param(request);
            var type = (Proto.MarketRequestType)ContractWire.ReadIntField(raw, 1, 0);
            var reason = (Proto.ClosingReason)ContractWire.ReadIntField(raw, 2, 0);
            int count = MarketplaceEngine.GetPlayerClosedRequestsCount(playerId, type, reason);
             byte[] response = ContractWire.Build(w => w.Int32(1, count, true));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetPlayerProcessingRequestsV2(string id)
        {
            string playerId = GetPlayerId();
            Proto.ProcessingRequest[] values = MarketplaceEngine.GetPlayerProcessingRequests(playerId).ToArray();
            byte[] response = ContractWire.WrapRepeated(1, values);
            ContractWire.SendRaw(_session, id, response);
         }

        private void GetPlayerOpenRequestsV2(string id)
        {
            string playerId = GetPlayerId();
            Proto.OpenRequest[] values = MarketplaceEngine.GetPlayerOpenRequests(playerId, null).ToArray();
            byte[] response = MarketplaceWire.RepeatedOpenRequests(values, playerId);
             ContractWire.SendRaw(_session, id, response);
        }

        private void GetPlayerClosedRequestsV2(RpcRequest request)
        {
            string playerId = GetPlayerId();
            Proto.GetClosedRequestsArgs input;
            try
            {
                input = Proto.GetClosedRequestsArgs.Parser.ParseFrom(ContractWire.Param(request));
            }
            catch (System.Exception ex)
            {
                 throw new MarketplaceEngine.MarketError(400, "bad closed requests payload: " + ex.Message);
            }

            int page = Math.Max(0, input.Page);
            int size = input.Size <= 0 ? 50 : Math.Min(input.Size, 200);
            Proto.ClosedRequest[] values = MarketplaceEngine.GetPlayerClosedRequests(
               playerId, input.Type, input.Reason, page, size).ToArray();
            byte[] response = MarketplaceWire.RepeatedClosedRequests(values);
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetMarketplaceSettingsV2(RpcRequest request)
        {
             MarketConfigDoc cfg = MarketplaceEngine.Config.Get();
           var settings = new Proto.MarketplaceSettings
            {
                CommissionPercent = cfg.CommissionPercent / 100f,
                MinCommission = cfg.MinCommission,
                CurrencyId = MarketplaceEngine.MarketCurrencyId,
                Enabled = cfg.Enabled,
                BannedUntilDate = cfg.BannedUntilDate
           };
            byte[] response = ContractWire.Build(w => w.Message(1, settings));
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void GetMarketplaceSettings(string id)
        {
            MarketConfigDoc cfg = MarketplaceEngine.Config.Get();
            Send(id, new Proto.MarketplaceSettings
            {
                CommissionPercent = cfg.CommissionPercent / 100f,
                MinCommission = cfg.MinCommission,
                CurrencyId = MarketplaceEngine.MarketCurrencyId,
               Enabled = cfg.Enabled,
                BannedUntilDate = cfg.BannedUntilDate
            });
        }

        private void GetPlayerProcessingRequests(string id)
        {
            string playerId = GetPlayerId();
            Send(id, MarketplaceEngine.GetPlayerProcessingRequests(playerId).ToArray());
        }

        private void GetPlayerOpenRequests(string id)
         {
            string playerId = GetPlayerId();
            Send(id, MarketplaceEngine.GetPlayerOpenRequests(playerId, null).ToArray());
        }

        private void CreateSale(BinaryValue[] args, string id)
        {
            Proto.CreateSaleRequest input = ReadRequired<Proto.CreateSaleRequest>(args, 0);
           MarketplaceEngine.CreateResult result = CreateSaleCore(input.ItemId, input.Price);
            Send(id, new Proto.CreateSaleResponse { RequestId = result.RequestId });
            PublishRequest(result);
        }

        private void CreateSaleRequest(BinaryValue[] args, string id)
        {
            Proto.CreateSaleRequestArgs input = ReadRequired<Proto.CreateSaleRequestArgs>(args, 0);
            MarketplaceEngine.CreateResult result = CreateSaleCore(input.ItemId, input.Price);
            Send(id, result.RequestId);
            PublishRequest(result);
        }

        private MarketplaceEngine.CreateResult CreateSaleCore(int inventoryItemId, float price)
        {
            string playerId = GetPlayerId();
            MarketConfigDoc cfg = GetConfig();
             if (inventoryItemId <= 0 || price < cfg.MinPrice)
                throw new MarketplaceEngine.MarketError(400, "invalid sale request");

            return MarketplaceEngine.CreateSaleRequestWithInfo(
                playerId, inventoryItemId, price, cfg.CurrencyId,
                cfg.CommissionPercent, cfg.MinCommission);
        }

        private void CreatePurchaseRequest(BinaryValue[] args, string id)
        {
            string playerId = GetPlayerId();
            MarketConfigDoc cfg = GetConfig();
           Proto.CreatePurchaseRequestArgs input = ReadRequired<Proto.CreatePurchaseRequestArgs>(args, 0);
           if (input.ItemDefinitionId <= 0 || input.Quantity <= 0 || input.Price < cfg.MinPrice)
                throw new MarketplaceEngine.MarketError(400, "invalid purchase request");

            MarketplaceEngine.CreateResult result = MarketplaceEngine.CreatePurchaseRequestWithInfo(
                playerId, input.ItemDefinitionId, input.Price, input.Quantity,
                cfg.CurrencyId, cfg.CommissionPercent, cfg.MinCommission);
            Send(id, result.RequestId);
            PublishRequest(result);
        }

        private void CreatePurchaseRequestBySale(BinaryValue[] args, string id)
        {
            string playerId = GetPlayerId();
            MarketConfigDoc cfg = GetConfig();
            Proto.CreatePurchaseBySaleArgs input = ReadRequired<Proto.CreatePurchaseBySaleArgs>(args, 0);
            if (string.IsNullOrWhiteSpace(input.SaleId))
                throw new MarketplaceEngine.MarketError(400, "invalid sale id");

            MarketplaceEngine.CreateResult result = MarketplaceEngine.CreatePurchaseBySaleWithInfo(
                playerId, input.SaleId, cfg.CurrencyId,
                cfg.CommissionPercent, cfg.MinCommission);
            Send(id, result.RequestId);
            PublishRequest(result);
        }

        private void PublishRequest(MarketplaceEngine.CreateResult result)
        {
             MarketplaceEngine.MatchAndPublish(
                result.ItemDefinitionId, result.CurrencyId,
                result.CommissionPercent, result.MinCommission);

            if (!MarketplaceEngine.IsRequestOpen(result.RequestId))
            {
                return;
            }

            MarketplaceEventBus.PlayerRequestOpened(result.PlayerId, result.Request);
            MarketplaceEventBus.TradeRequestOpened(result.ItemDefinitionId, result.Request, result.PlayerId);
            MarketplaceEventBus.TradeUpdated(
                result.ItemDefinitionId, MarketplaceEngine.GetTrade(result.ItemDefinitionId), result.PlayerId);
        }

        private void CancelRequest(BinaryValue[] args, string id)
        {
            string playerId = GetPlayerId();
           Proto.CancelRequestArgs input = ReadRequired<Proto.CancelRequestArgs>(args, 0);
            if (string.IsNullOrWhiteSpace(input.Id))
                throw new MarketplaceEngine.MarketError(400, "invalid request id");

            MarketplaceEngine.CancelResult result = MarketplaceEngine.CancelRequestWithInfo(playerId, input.Id);
            SendVoid(id);
            if (result.Item != null)
            {
                InventoryEventBus.InventoryChanged(
                    playerId,
                    added: new[] { result.Item },
                    source: "market-cancel-return");
            }
            MarketplaceEventBus.PlayerRequestClosed(playerId, result.Request, result.Item);
            MarketplaceEventBus.TradeRequestClosed(result.ItemDefinitionId, result.Request, playerId);
            MarketplaceEventBus.TradeUpdated(result.ItemDefinitionId, MarketplaceEngine.GetTrade(result.ItemDefinitionId), playerId);
        }

        private void GetTradesV2(RpcRequest request)
       {
            List<int> ids = ContractWire.ReadRepeatedIntField(ContractWire.Param(request), 1)
                .Where(x => x > 0)
                .Distinct()
                .ToList();
            Proto.Trade[] trades = MarketplaceEngine.GetTrades(ids.ToArray()).ToArray();
            byte[] response = ContractWire.WrapRepeated(1, trades);
            ContractWire.SendRaw(_session, request.Id, response);
        }

       private void GetTrades(BinaryValue[] args, string id)
        {
            Proto.GetTradesArgs input = ReadRequired<Proto.GetTradesArgs>(args, 0);
            Send(id, MarketplaceEngine.GetTrades(input.ItemDefinitionIds.ToArray()).ToArray());
        }

       private void GetTrade(BinaryValue[] args, string id)
        {
            Proto.GetTradeArgs input = ReadRequired<Proto.GetTradeArgs>(args, 0);
            Send(id, MarketplaceEngine.GetTrade(input.Id));
         }

        private void GetTradeOpenSaleRequests(BinaryValue[] args, string id)
        {
            Proto.GetTradeOpenSaleRequestsArgs input = ReadRequired<Proto.GetTradeOpenSaleRequestsArgs>(args, 0);
            Send(id, MarketplaceEngine.GetTradeOpenRequests(
                input.Id, Proto.MarketRequestType.SaleRequest, input.Page, input.Size).ToArray());
        }

        private void GetTradeOpenPurchaseRequests(BinaryValue[] args, string id)
        {
           Proto.GetTradeOpenPurchaseRequestsArgs input = ReadRequired<Proto.GetTradeOpenPurchaseRequestsArgs>(args, 0);
            Send(id, MarketplaceEngine.GetTradeOpenRequests(
                input.Id, Proto.MarketRequestType.PurchaseRequest, input.Page, input.Size).ToArray());
        }

        private void GetPlayerClosedRequestsCount(BinaryValue[] args, string id)
         {
            string playerId = GetPlayerId();
            Proto.GetClosedRequestsCountArgs input = ReadRequired<Proto.GetClosedRequestsCountArgs>(args, 0);
           Send(id, MarketplaceEngine.GetPlayerClosedRequestsCount(playerId, input.Type, input.Reason));
        }

        private void GetPlayerClosedRequests(BinaryValue[] args, string id)
        {
            string playerId = GetPlayerId();
             Proto.GetClosedRequestsArgs input = ReadRequired<Proto.GetClosedRequestsArgs>(args, 0);
            Send(id, MarketplaceEngine.GetPlayerClosedRequests(
                playerId, input.Type, input.Reason, input.Page, input.Size).ToArray());
        }

        private MarketConfigDoc GetConfig()
        {
            MarketConfigDoc cfg = MarketplaceEngine.Config.Get();
            if (!cfg.Enabled) throw new MarketplaceEngine.MarketError(503, "market is disabled");
            if (cfg.BannedUntilDate > MarketplaceEngine.NowMs())
                throw new MarketplaceEngine.MarketError(403, "market access is blocked");
            return cfg;
        }
        private string GetPlayerId()
       {
            if (ServerState.Users.TryGetValue(_session.TcpClient, out string id) && !string.IsNullOrWhiteSpace(id))
                return id;
             throw new MarketplaceEngine.MarketError(401, "not authenticated");
        }

        private void EnsureMarketEvents()
        {
            if (!ServerState.Users.TryGetValue(_session.TcpClient, out string playerId) || string.IsNullOrWhiteSpace(playerId))
                return;
            MarketplaceEventBus.Register(playerId, _session);
        }

        private static T ReadRequired<T>(BinaryValue[] args, int index)
        {
            if (args == null || index < 0 || index >= args.Length || args[index] == null || args[index].IsNull)
                throw new MarketplaceEngine.MarketError(400, "missing argument");
            try
            {
                return (T)new RpcValueReader(typeof(T)).FromBytes(args[index]);
            }
            catch (System.Exception ex)
            {
               throw new MarketplaceEngine.MarketError(400, "bad argument " + typeof(T).Name + ": " + ex.Message);
            }
        }

        private void Send<T>(string id, T value)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = value == null
                         ? new BinaryValue { IsNull = true }
                        : RpcTypeCodec.CreateToByteMethod(typeof(T)).ToBytes(value)
                 }
            });
        }

        private void SendVoid(string id)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse { Id = id, Return = new BinaryValue { IsNull = true } }
            });
        }
        private void SendException(string id, int code)
       {
            _session.SendResponse(new ResponseMessage
           {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }

    internal static class MarketplaceWire
    {
        private static byte[] Build(Action<Google.Protobuf.CodedOutputStream> write)
        {
            using (var ms = new System.IO.MemoryStream())
            {
                var output = new Google.Protobuf.CodedOutputStream(ms, true);
                write(output);
                output.Flush();
                return ms.ToArray();
            }
        }

        private static void String(Google.Protobuf.CodedOutputStream w, int field, string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.LengthDelimited);
            w.WriteString(value);
        }

        private static void Message(Google.Protobuf.CodedOutputStream w, int field, Google.Protobuf.IMessage value)
        {
            if (value == null) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.LengthDelimited);
            w.WriteMessage(value);
        }

       private static void MsgBytes(Google.Protobuf.CodedOutputStream w, int field, byte[] value)
        {
            if (value == null || value.Length == 0) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.LengthDelimited);
            w.WriteBytes(Google.Protobuf.ByteString.CopyFrom(value));
       }
        private static void Int32(Google.Protobuf.CodedOutputStream w, int field, int value)
        {
            if (value == 0) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.Varint);
            w.WriteInt32(value);
        }

        private static void Int64(Google.Protobuf.CodedOutputStream w, int field, long value)
        {
            if (value == 0) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.Varint);
            w.WriteInt64(value);
        }

        private static void Bool(Google.Protobuf.CodedOutputStream w, int field, bool value)
        {
            if (!value) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.Varint);
            w.WriteBool(true);
        }

        private static void Float(Google.Protobuf.CodedOutputStream w, int field, float value)
        {
            if (value == 0f) return;
            w.WriteTag(field, Google.Protobuf.WireFormat.WireType.Fixed32);
            w.WriteFloat(value);
         }

        private static byte[] BuildModValue(Proto.InventoryItemProperty property)
        {
             if (property == null) return Array.Empty<byte>();
            return Build(w =>
            {
                Int32(w, 1, (int)property.Type);
                Int32(w, 2, property.IntValue);
                 Float(w, 3, property.FloatValue);
                String(w, 4, property.StringValue);
                Bool(w, 5, property.BooleanValue);
            });
        }

        private static byte[] BuildModEntry(string key, Proto.InventoryItemProperty value)
        {
            if (string.IsNullOrEmpty(key) || value == null) return Array.Empty<byte>();
            return Build(w =>
           {
                String(w, 1, key);
                MsgBytes(w, 2, BuildModValue(value));
            });
        }

        private static void WriteMods(Google.Protobuf.CodedOutputStream w, int field,
           IEnumerable<KeyValuePair<string, Proto.InventoryItemProperty>> properties)
        {
           if (properties == null) return;
            foreach (KeyValuePair<string, Proto.InventoryItemProperty> pair in properties)
                MsgBytes(w, field, BuildModEntry(pair.Key, pair.Value));
        }

       public static byte[] OpenRequest(Proto.OpenRequest request, bool isCreator)
        {
            if (request == null) return Array.Empty<byte>();
            return Build(w =>
            {
                String(w, 1, request.Id);
                Message(w, 2, request.Creator);
                Int32(w, 3, request.ItemDefinitionId);
                Float(w, 4, request.Price);
                Int64(w, 5, request.CreateDate);
                Int32(w, 6, (int)request.Type);
               Int32(w, 7, request.Quantity);
                WriteMods(w, 8, request.Properties);
               Bool(w, 9, isCreator);
            });
        }
        public static byte[] ClosedRequest(Proto.ClosedRequest request)
        {
            if (request == null) return Array.Empty<byte>();
            return Build(w =>
            {
                String(w, 1, request.Id);
                String(w, 2, request.OriginId);
                Message(w, 3, request.Creator);
                Int32(w, 4, request.ItemDefinitionId);
                 Float(w, 5, request.Price);
                Int64(w, 6, request.CreateDate);
                Int64(w, 7, request.CloseDate);
                Int32(w, 8, (int)request.Type);
                Message(w, 9, request.Partner);
                String(w, 10, request.PartnerRequestId);
                Int32(w, 11, (int)request.Reason);
                Int32(w, 12, request.Quantity);
                WriteMods(w, 13, request.Properties);
            });
        }

        public static byte[] Trade(Proto.Trade trade)
        {
            if (trade == null) return Array.Empty<byte>();
            return Build(w =>
            {
               Int32(w, 1, trade.Id);
                Int32(w, 2, trade.SalesCount);
               Int32(w, 3, trade.PurchasesCount);
                Float(w, 4, trade.SalesPrice);
                Float(w, 5, trade.PurchasesPrice);
            });
        }

        public static byte[] RepeatedOpenRequests(IEnumerable<Proto.OpenRequest> requests, string viewerPlayerId) =>
           Build(w =>
            {
                foreach (Proto.OpenRequest request in requests ?? Array.Empty<Proto.OpenRequest>())
                {
                    bool isCreator = string.Equals(request?.Creator?.Id, viewerPlayerId, StringComparison.Ordinal);
                     MsgBytes(w, 1, OpenRequest(request, isCreator));
                }
            });

        public static byte[] RepeatedClosedRequests(IEnumerable<Proto.ClosedRequest> requests) =>
            Build(w =>
            {
                foreach (Proto.ClosedRequest request in requests ?? Array.Empty<Proto.ClosedRequest>())
                     MsgBytes(w, 1, ClosedRequest(request));
            });
        public static byte[] OnTradeUpdated(Proto.Trade trade) =>
            new Proto.OnTradeUpdatedEvent
            {
                Trade = trade
            }.ToByteArray();

        public static byte[] OnPlayerRequestOpened(Proto.OpenRequest request, bool isCreator)
        {
             Proto.OpenRequest exact = request == null
                ? null
                : Proto.OpenRequest.Parser.ParseFrom(OpenRequest(request, isCreator));
            return new Proto.OnPlayerRequestOpenedEvent
            {
                Request = exact
            }.ToByteArray();
        }

        public static byte[] OnTradeRequestOpened(Proto.OpenRequest request, bool isCreator)
        {
            Proto.OpenRequest exact = request == null
                ? null
                : Proto.OpenRequest.Parser.ParseFrom(OpenRequest(request, isCreator));
            return new Proto.OnTradeRequestOpenedEvent
            {
                 Request = exact
            }.ToByteArray();
         }

         public static byte[] OnTradeRequestClosed(Proto.ClosedRequest request)
        {
            Proto.ClosedRequest exact = request == null
                 ? null
                : Proto.ClosedRequest.Parser.ParseFrom(ClosedRequest(request));
            return new Proto.OnTradeRequestClosedEvent
            {
                Request = exact
            }.ToByteArray();
        }

        private static byte[] PlayerInventoryItem(Proto.InventoryItem item)
        {
            if (item == null) return Array.Empty<byte>();
            return Build(w =>
            {
                Int32(w, 1, item.Id);
                Int32(w, 2, item.ItemDefinitionId);
                Int32(w, 3, item.Quantity);
                Int32(w, 4, item.Flags);
               Int64(w, 5, item.Date);
                WriteMods(w, 6, item.Properties);
            });
        }

        public static byte[] OnPlayerRequestClosed(Proto.ClosedRequest request, Proto.InventoryItem item)
        {
            Proto.ClosedRequest exactRequest = request == null
                ? null
                : Proto.ClosedRequest.Parser.ParseFrom(ClosedRequest(request));
            Proto.InventoryItem exactItem = item == null
                ? null
                : Proto.InventoryItem.Parser.ParseFrom(PlayerInventoryItem(item));

             var evt = new Proto.OnPlayerRequestClosedEvent
            {
                Request = exactRequest
             };
            if (exactItem != null)
                evt.Item = exactItem;
            return evt.ToByteArray();
        }
    }

    internal static class MarketplaceEventBus
    {

        public const string ListenerName = "MarketplaceRemoteEventListener";
        public const string TradesTopic = "marketplace_trades";
        public const string TradeTopicPrefix = "marketplace_trade_";

        public static void Register(string playerId, ClientSession user)
        {
            if (string.IsNullOrWhiteSpace(playerId) || user == null) return;
            ServerState.EnsureConnectionEventSender(
                playerId,
                user.TcpClient,
                 () => new MarketplaceRemoteEventSender(user));
        }

        public static void Unregister(ClientSession user)
        {
            if (user == null) return;
            lock (ServerState.EventSendersLock)
            {
                foreach (List<IEventSender> list in ServerState.EventSenders.Values)
                     list?.RemoveAll(x => x is MarketplaceRemoteEventSender sender && ReferenceEquals(sender.User, user));
            }
        }

        public static int PlayerRequestOpened(string playerId, Proto.OpenRequest request) =>
            SendPlayer(playerId, "onPlayerRequestOpened",
                 MarketplaceWire.OnPlayerRequestOpened(request, true), "player-direct");

         public static int PlayerRequestClosed(string playerId, Proto.ClosedRequest request, Proto.InventoryItem item) =>
            SendPlayer(playerId, "onPlayerRequestClosed",
                MarketplaceWire.OnPlayerRequestClosed(request, item), "player-direct");

       public static int TradeUpdated(int itemDefinitionId, Proto.Trade trade, string actorPlayerId = null)
        {
            var recipients = GetRecipients(new[] { TradesTopic, TradeTopicPrefix + itemDefinitionId });
            if (!string.IsNullOrWhiteSpace(actorPlayerId)) recipients.Add(actorPlayerId);
            return SendMany(recipients, "onTradeUpdated", _ => MarketplaceWire.OnTradeUpdated(trade),
                $"topics={TradesTopic},{TradeTopicPrefix + itemDefinitionId}");
        }

        public static int TradeRequestOpened(int itemDefinitionId, Proto.OpenRequest request, string actorPlayerId = null)
        {
           var recipients = GetRecipients(new[] { TradeTopicPrefix + itemDefinitionId });
             if (!string.IsNullOrWhiteSpace(actorPlayerId)) recipients.Add(actorPlayerId);
            string creatorId = request?.Creator?.Id ?? actorPlayerId ?? string.Empty;
            return SendMany(recipients, "onTradeRequestOpened",
                id => MarketplaceWire.OnTradeRequestOpened(request,
                    string.Equals(id, creatorId, StringComparison.Ordinal)),
                $"topic={TradeTopicPrefix + itemDefinitionId}");
        }

        public static int TradeRequestClosed(int itemDefinitionId, Proto.ClosedRequest request, string actorPlayerId = null)
        {
            var recipients = GetRecipients(new[] { TradeTopicPrefix + itemDefinitionId });
            if (!string.IsNullOrWhiteSpace(actorPlayerId)) recipients.Add(actorPlayerId);
            return SendMany(recipients, "onTradeRequestClosed",
               _ => MarketplaceWire.OnTradeRequestClosed(request),
                $"topic={TradeTopicPrefix + itemDefinitionId}");
        }

        private static HashSet<string> GetRecipients(IEnumerable<string> topics)
        {
            var result = new HashSet<string>(StringComparer.Ordinal);
            foreach (string topic in topics ?? Array.Empty<string>())
            {
               foreach (ClientSession user in BoltEvents.Subscribers(topic))
                {
                    string id = FindPlayerId(user);
                    if (!string.IsNullOrWhiteSpace(id)) result.Add(id);
               }
            }
            return result;
        }

        private static string FindPlayerId(ClientSession user)
        {
            if (user == null) return string.Empty;
            lock (ServerState.EventSendersLock)
            {
                foreach (var pair in ServerState.EventSenders)
               {
                    if (pair.Value != null && pair.Value.OfType<MarketplaceRemoteEventSender>()
                        .Any(x => ReferenceEquals(x.User, user))) return pair.Key;
                }
            }
            return string.Empty;
        }

       private static int SendMany(IEnumerable<string> playerIds, string eventName,
            Func<string, byte[]> payloadFactory, string source)
        {
            int delivered = 0;
            foreach (string playerId in (playerIds ?? Array.Empty<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal))
            {
                delivered += SendPlayer(playerId, eventName, payloadFactory(playerId), source);
            }
            return delivered;
       }

        private static int SendPlayer(string playerId, string eventName, byte[] payload, string source)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return 0;
            List<MarketplaceRemoteEventSender> senders =
                ServerState.GetLiveEventSenders<MarketplaceRemoteEventSender>(playerId);
            int delivered = 0;
             foreach (MarketplaceRemoteEventSender sender in senders)
            {
                try
                {
                    sender.SendRawEvent(eventName, payload, playerId, source);
                    delivered++;
                }
                catch
                {
                }
            }
            return delivered;
        }
    }

    public static class MarketplaceEngine
    {

        public const int MarketCurrencyId = 102;
        private static readonly object _lock = new();

        private static IMongoCollection<MarketOpenDoc> OpenCol => MarketplaceDb.OpenRequests;
        private static IMongoCollection<MarketClosedDoc> ClosedCol => MarketplaceDb.ClosedRequests;
        private static IMongoCollection<MarketPurchaseEscrowDoc> PurchaseEscrowCol => MarketplaceDb.PurchaseEscrows;
        private static IMongoCollection<MarketConfigDoc> ConfigCol => MarketplaceDb.Config;

        static MarketplaceEngine()
        {
            EnsureIndexes();
            Config.EnsureExists();
            // startup repair for old db state
            RepairLegacyCurrency();
            RepairOpenSales();
            BackfillEscrows();
            ReleaseLegacyReserves();
        }

        public sealed class MarketError : System.Exception
        {
            public int Code { get; }
            public MarketError(int code, string message) : base(message) => Code = code;
        }

        private static bool IsTradable(int itemDefinitionId)
        {
            IMongoDatabase db = BoltGameDatabaseProvider.Instance.GetDatabase();
            IMongoCollection<BsonDocument> defs =
                db.GetCollection<BsonDocument>(InventoryCatalog.ItemCollection);
            BsonDocument doc = defs.Find(
                Builders<BsonDocument>.Filter.Eq("key", itemDefinitionId) &
                Builders<BsonDocument>.Filter.Eq("gid", 1) &
                Builders<BsonDocument>.Filter.Eq("enabled", true)).FirstOrDefault();
            return doc != null &&
                   doc.TryGetValue("canBeTraded", out BsonValue traded) &&
                   traded.IsBoolean &&
                  traded.AsBoolean;
       }
        public static class Config
        {
            private const string ConfigId = "config";

            public static MarketConfigDoc Get()
            {
                 var doc = ConfigCol.Find(x => x.Id == ConfigId).FirstOrDefault();
                if (doc == null)
                {
                   EnsureExists();
                    doc = ConfigCol.Find(x => x.Id == ConfigId).FirstOrDefault();
                }
                if (doc != null && doc.CurrencyId != MarketCurrencyId)
                {
                    ConfigCol.UpdateOne(x => x.Id == ConfigId,
                        Builders<MarketConfigDoc>.Update.Set(x => x.CurrencyId, MarketCurrencyId));
                    doc.CurrencyId = MarketCurrencyId;
                }
                return doc;
            }

            public static void EnsureExists()
            {
                MarketConfigDoc existing = ConfigCol.Find(x => x.Id == ConfigId).FirstOrDefault();
                if (existing != null)
                {
                    if (existing.CurrencyId != MarketCurrencyId)
                   {
                        ConfigCol.UpdateOne(x => x.Id == ConfigId,
                            Builders<MarketConfigDoc>.Update.Set(x => x.CurrencyId, MarketCurrencyId));
                    }
                    return;
                }

                ConfigCol.InsertOne(new MarketConfigDoc
                {
                    Id = ConfigId,
                    Enabled = true,
                    BannedUntilDate = 0,
                     CurrencyId = MarketCurrencyId,
                    MinPrice = 0.03f,
                    CommissionPercent = 20f,
                    MinCommission = 0.03f
                 });
            }
       }

        public sealed class CreateResult
        {
            public string RequestId { get; set; }
            public string PlayerId { get; set; }
            public int ItemDefinitionId { get; set; }
            public int CurrencyId { get; set; }
            public float CommissionPercent { get; set; }
           public float MinCommission { get; set; }
            public Proto.OpenRequest Request { get; set; }
        }

        public sealed class CancelResult
        {
            public int ItemDefinitionId { get; set; }
            public Proto.ClosedRequest Request { get; set; }
            public Proto.InventoryItem Item { get; set; }
        }

        public static List<Proto.ProcessingRequest> GetPlayerProcessingRequests(string playerId)
        {
            return new List<Proto.ProcessingRequest>();
        }

        public static CreateResult CreateSaleRequestWithInfo(
            string sellerId, int inventoryItemId, float price,
            int currencyId, float commissionPercent, float minCommission)
        {
            currencyId = MarketCurrencyId;
            lock (_lock)
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                ObjectId sellerObjectId = ParsePlayerId(sellerId);
                 PlayerInventoryDocument inventory = boltGame.GetPlayerInventoryDocument(sellerObjectId);
                if (inventory?.InventoryItems == null)
                    throw new MarketError(404, "inventory not found");
                if (!TryReadInventoryItem(inventory, inventoryItemId, out StoredItem storedItem))
                    throw new MarketError(404, "item not found");

                 if (!IsTradable(storedItem.ItemDefinitionId))
                    throw new MarketError(403, "item is not tradable");

                RepairStaleSale_NoLock(
                    sellerId, inventoryItemId, storedItem.ItemDefinitionId);

                bool alreadyListed = OpenCol.Find(x =>
                    x.CreatorId == sellerId &&
                    x.Type == Proto.MarketRequestType.SaleRequest &&
                    x.InventoryItemId == inventoryItemId).Any();
                if (alreadyListed)
                {
                    throw new MarketError(409, "item already listed");
                }

                 string requestId = Guid.NewGuid().ToString("N");
                long now = NowMs();
                var document = new MarketOpenDoc
                {
                    Id = requestId,
                    CreatorId = sellerId,
                    Type = Proto.MarketRequestType.SaleRequest,
                    ItemDefinitionId = storedItem.ItemDefinitionId,
                    InventoryItemId = inventoryItemId,
                    CreateDate = now,
                    Price = price,
                    Quantity = 1,
                    Properties = CloneProperties(storedItem.Properties),
                    ItemSnapshot = storedItem,
                    ReservedCurrencyId = 0,
                    ReservedAmount = 0
                };

                boltGame.RemoveItemToPlayerInventoryDocument(sellerObjectId, inventoryItemId);
                try
                {
                    OpenCol.InsertOne(document);
                }
                catch
                {
                   boltGame.AddItemToPlayerInventoryDocument(
                        sellerObjectId, MakeBoltInventoryItem(storedItem), inventoryItemId);
                    throw;
                }

               Proto.OpenRequest openRequest = ToProtoOpenRequest(document);
                return new CreateResult
                {
                    RequestId = requestId,
                    PlayerId = sellerId,
                    ItemDefinitionId = storedItem.ItemDefinitionId,
                    CurrencyId = currencyId,
                    CommissionPercent = commissionPercent,
                    MinCommission = minCommission,
                    Request = openRequest
                };
            }
        }

        public static CreateResult CreatePurchaseRequestWithInfo(
            string buyerId, int itemDefinitionId, float price, int quantity,
            int currencyId, float commissionPercent, float minCommission)
        {
            currencyId = MarketCurrencyId;
            lock (_lock)
           {
                if (quantity <= 0) throw new MarketError(400, "invalid quantity");
                if (!IsTradable(itemDefinitionId))
                    throw new MarketError(403, "item is not tradable");

                ObjectId buyerObjectId = ParsePlayerId(buyerId);
                double reserve = 0d;

                string requestId = Guid.NewGuid().ToString("N");
                var document = new MarketOpenDoc
                {
                    Id = requestId,
                    CreatorId = buyerId,
                    Type = Proto.MarketRequestType.PurchaseRequest,
                    ItemDefinitionId = itemDefinitionId,
                    InventoryItemId = 0,
                    CreateDate = NowMs(),
                   Price = price,
                    Quantity = quantity,
                    Properties = new Dictionary<string, Proto.InventoryItemProperty>(),
                    ItemSnapshot = null,
                    ReservedCurrencyId = currencyId,
                    ReservedAmount = reserve
                };
                try
                {
                    OpenCol.InsertOne(document);
                }
                catch
                {
                    try { OpenCol.DeleteOne(x => x.Id == requestId); } catch { }
                    throw;
                }

                return new CreateResult
                {
                    RequestId = requestId,
                    PlayerId = buyerId,
                    ItemDefinitionId = itemDefinitionId,
                    CurrencyId = currencyId,
                    CommissionPercent = commissionPercent,
                    MinCommission = minCommission,
                    Request = ToProtoOpenRequest(document)
                };
            }
        }

       public static CreateResult CreatePurchaseBySaleWithInfo(
           string buyerId, string saleId,
            int currencyId, float commissionPercent, float minCommission)
        {
            currencyId = MarketCurrencyId;
             lock (_lock)
            {
                MarketOpenDoc sale = OpenCol.Find(x => x.Id == saleId).FirstOrDefault();
                if (sale == null) throw new MarketError(404, "sale request not found");
                if (sale.Type != Proto.MarketRequestType.SaleRequest)
                    throw new MarketError(400, "request is not a sale");
                if (sale.CreatorId == buyerId)
                    throw new MarketError(400, "can't buy own item");

                ObjectId buyerObjectId = ParsePlayerId(buyerId);
                PlayerInventoryDocument directInventory =
                    BoltGameDatabaseProvider.Instance.GetPlayerInventoryDocument(buyerObjectId);
                 if (directInventory == null || ReadCurrencyValue(directInventory, currencyId) + 0.0001d < sale.Price)
                    throw new MarketError(402, "not enough funds");

                string requestId = Guid.NewGuid().ToString("N");
                var document = new MarketOpenDoc
                {
                    Id = requestId,
                    CreatorId = buyerId,
                    Type = Proto.MarketRequestType.PurchaseRequest,
                    ItemDefinitionId = sale.ItemDefinitionId,
                   InventoryItemId = 0,
                    CreateDate = NowMs(),
                    Price = sale.Price,
                    Quantity = 1,
                    Properties = CloneProperties(sale.Properties),
                    ItemSnapshot = null,
                    BySaleRequestId = sale.Id,
                   ReservedCurrencyId = currencyId,
                    ReservedAmount = 0d
               };

                try
               {
                    OpenCol.InsertOne(document);
                }
                catch
                 {
                    try { OpenCol.DeleteOne(x => x.Id == requestId); } catch { }
                    throw;
                }

                return new CreateResult
                {
                    RequestId = requestId,
                    PlayerId = buyerId,
                    ItemDefinitionId = sale.ItemDefinitionId,
                    CurrencyId = currencyId,
                    CommissionPercent = commissionPercent,
                    MinCommission = minCommission,
                    Request = ToProtoOpenRequest(document)
                };
            }
        }

        public static CancelResult CancelRequestWithInfo(string playerId, string requestId)
        {
             lock (_lock)
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                MarketOpenDoc request = OpenCol.Find(x => x.Id == requestId).FirstOrDefault();
                if (request == null) throw new MarketError(404, "request not found");
                if (!string.Equals(request.CreatorId, playerId, StringComparison.Ordinal))
                    throw new MarketError(401, "request owner mismatch");

                Proto.InventoryItem returnedItem = null;
                 ObjectId playerObjectId = ParsePlayerId(playerId);
                int restoredItemId = 0;

                if (request.Type == Proto.MarketRequestType.SaleRequest)
                {
                    StoredItem snapshot = GetSaleSnapshot(request);
                    PlayerInventoryDocument inventory = boltGame.GetPlayerInventoryDocument(playerObjectId);
                    restoredItemId = ChooseRestoreInventoryId(inventory, request.InventoryItemId);
                    boltGame.AddItemToPlayerInventoryDocument(
                        playerObjectId, MakeBoltInventoryItem(snapshot), restoredItemId);
                    returnedItem = MakeProtoInventoryItem(snapshot, restoredItemId);
                }
                else if (request.Type == Proto.MarketRequestType.PurchaseRequest && request.ReservedAmount > 0)
                {
                    SafeCurrencyPlus(playerObjectId,
                        request.ReservedCurrencyId > 0 ? request.ReservedCurrencyId : Config.Get().CurrencyId,
                        request.ReservedAmount);
                }

                DeleteResult deleteResult = OpenCol.DeleteOne(x => x.Id == requestId);
                if (deleteResult.DeletedCount == 1 && request.Type == Proto.MarketRequestType.PurchaseRequest)
                    CloseEscrow_NoLock(request.Id, "cancelled");
                if (deleteResult.DeletedCount != 1)
                {
                    if (returnedItem != null)
                        boltGame.RemoveItemToPlayerInventoryDocument(playerObjectId, restoredItemId);
                    else if (request.ReservedAmount > 0)
                        SafeCurrencyMinus(playerObjectId,
                           request.ReservedCurrencyId > 0 ? request.ReservedCurrencyId : Config.Get().CurrencyId,
                            request.ReservedAmount);
                    throw new MarketError(409, "request changed during cancel");
                }

                Proto.ClosedRequest closed = MakeClosedProto(
                    request, null, string.Empty, Proto.ClosingReason.Cancelled,
                    NowMs(), request.Price, request.Quantity);
                AddClosed(playerId, closed);
                return new CancelResult
               {
                    ItemDefinitionId = request.ItemDefinitionId,
                    Request = closed,
                    Item = returnedItem
                };
           }
        }

        public static List<Proto.OpenRequest> GetPlayerOpenRequests(string playerId, Proto.MarketRequestType? typeOrNull)
        {

            RecoverEscrows(playerId);

            var filter = Builders<MarketOpenDoc>.Filter.Eq(x => x.CreatorId, playerId);

            if (typeOrNull.HasValue && (int)typeOrNull.Value != 0)
                filter &= Builders<MarketOpenDoc>.Filter.Eq(x => x.Type, typeOrNull.Value);

            return OpenCol.Find(filter)
                .SortByDescending(x => x.CreateDate)
                .ToList()
                .Select(ToProtoOpenRequest)
                 .ToList();
        }

        public static List<Proto.OpenRequest> GetTradeOpenRequests(int itemDefinitionId, Proto.MarketRequestType type, int page, int size)
        {
            if (size <= 0) size = 20;
            if (page < 0) page = 0;

            var filter = Builders<MarketOpenDoc>.Filter.Eq(x => x.ItemDefinitionId, itemDefinitionId) &
                         Builders<MarketOpenDoc>.Filter.Eq(x => x.Type, type);

            var q = OpenCol.Find(filter);

            if (type == Proto.MarketRequestType.SaleRequest)
                q = q.SortBy(x => x.Price).ThenBy(x => x.CreateDate);
            else
                q = q.SortByDescending(x => x.Price).ThenBy(x => x.CreateDate);

            return q.Skip(page * size).Limit(size).ToList()
                .Select(ToProtoOpenRequest)
               .ToList();
        }

       public static List<Proto.Trade> GetTrades(int[] itemDefinitionIds)
        {
            return itemDefinitionIds.Select(GetTrade).ToList();
        }

        public static Proto.Trade GetTrade(int itemDefinitionId)
        {
            var salesFilter = Builders<MarketOpenDoc>.Filter.Eq(x => x.ItemDefinitionId, itemDefinitionId) &
                              Builders<MarketOpenDoc>.Filter.Eq(x => x.Type, Proto.MarketRequestType.SaleRequest);

            var buysFilter = Builders<MarketOpenDoc>.Filter.Eq(x => x.ItemDefinitionId, itemDefinitionId) &
                             Builders<MarketOpenDoc>.Filter.Eq(x => x.Type, Proto.MarketRequestType.PurchaseRequest);

            var sales = OpenCol.Find(salesFilter).ToList();
            var buys = OpenCol.Find(buysFilter).ToList();

            int salesCount = sales.Sum(a => Math.Max(1, a.Quantity));
            int buyCount = buys.Sum(a => Math.Max(1, a.Quantity));

            float bestSale = sales.Count > 0 ? sales.Min(a => a.Price) : 0f;
             float bestBuy = buys.Count > 0 ? buys.Max(a => a.Price) : 0f;

            return new Proto.Trade
            {
                Id = itemDefinitionId,
                SalesCount = salesCount,
                PurchasesCount = buyCount,
                SalesPrice = bestSale,
                PurchasesPrice = bestBuy
            };
        }

        public static int GetPlayerClosedRequestsCount(string playerId, Proto.MarketRequestType type, Proto.ClosingReason reason)
        {
            var filter = Builders<MarketClosedDoc>.Filter.Eq(x => x.CreatorId, playerId);
            if ((int)type != 0)
                filter &= Builders<MarketClosedDoc>.Filter.Eq(x => x.Type, type);
            if ((int)reason != 0)
                filter &= Builders<MarketClosedDoc>.Filter.Eq(x => x.Reason, reason);

            return (int)ClosedCol.CountDocuments(filter);
        }

        public static bool IsRequestOpen(string requestId)
        {
            if (string.IsNullOrWhiteSpace(requestId)) return false;
            lock (_lock)
                 return OpenCol.Find(x => x.Id == requestId).Limit(1).Any();
         }

        public static List<Proto.ClosedRequest> GetPlayerClosedRequests(string playerId, Proto.MarketRequestType type, Proto.ClosingReason reason, int page, int size)
        {
            if (size <= 0) size = 20;
           if (page < 0) page = 0;

            var filter = Builders<MarketClosedDoc>.Filter.Eq(x => x.CreatorId, playerId);

            if ((int)type != 0)
                filter &= Builders<MarketClosedDoc>.Filter.Eq(x => x.Type, type);
            if ((int)reason != 0)
                filter &= Builders<MarketClosedDoc>.Filter.Eq(x => x.Reason, reason);

            return ClosedCol.Find(filter)
                .SortByDescending(x => x.CloseDate)
                .Skip(page * size)
                .Limit(size)
                .ToList()
                .Select(x => x.ClosedProto)
                .ToList();
        }

        public static void MatchAndPublish(int itemDefinitionId, int currencyId, float commissionPercent, float minCommission)
        {
            currencyId = MarketCurrencyId;
            lock (_lock)
            {
                while (true)
                {
                   MarketOpenDoc buy = OpenCol.Find(x =>
                            x.ItemDefinitionId == itemDefinitionId &&
                           x.Type == Proto.MarketRequestType.PurchaseRequest)
                        .SortByDescending(x => x.Price).ThenBy(x => x.CreateDate)
                        .FirstOrDefault();
                    if (buy == null) return;

                    MarketOpenDoc sale;
                    if (!string.IsNullOrWhiteSpace(buy.BySaleRequestId))
                    {
                        sale = OpenCol.Find(x => x.Id == buy.BySaleRequestId).FirstOrDefault();
                        if (sale == null || sale.Type != Proto.MarketRequestType.SaleRequest)
                        {
                            ClosePurchase_NoLock(buy, Proto.ClosingReason.SaleRequestNotFound, currencyId);
                            MarketplaceEventBus.TradeUpdated(itemDefinitionId, GetTrade(itemDefinitionId));
                            continue;
                        }
                     }
                    else
                    {

                        List<MarketOpenDoc> candidates = OpenCol.Find(x =>
                                x.ItemDefinitionId == itemDefinitionId &&
                                x.Type == Proto.MarketRequestType.SaleRequest)
                             .SortBy(x => x.Price).ThenBy(x => x.CreateDate)
                             .Limit(100)
                            .ToList();
                        sale = candidates.FirstOrDefault(x =>
                            !string.Equals(buy.CreatorId, x.CreatorId, StringComparison.Ordinal));
                    }

                    if (sale == null || buy.Price < sale.Price) return;
                    if (!ExecuteMatch_NoLock(buy, sale, currencyId, commissionPercent, minCommission)) return;
                }
            }
        }

        private static void ClosePurchase_NoLock(
            MarketOpenDoc buy, Proto.ClosingReason reason, int fallbackCurrencyId)
        {
            ObjectId buyerObjectId = ParsePlayerId(buy.CreatorId);
            if (buy.ReservedAmount > 0)
            {
                SafeCurrencyPlus(
                   buyerObjectId,
                    buy.ReservedCurrencyId > 0 ? buy.ReservedCurrencyId : fallbackCurrencyId,
                    buy.ReservedAmount);
           }

            OpenCol.DeleteOne(x => x.Id == buy.Id);
            CloseEscrow_NoLock(buy.Id, "closed-" + reason);
            Proto.ClosedRequest closed = MakeClosedProto(
                buy, null, string.Empty, reason, NowMs(), buy.Price, buy.Quantity);
            AddClosed(buy.CreatorId, closed);
            MarketplaceEventBus.PlayerRequestClosed(buy.CreatorId, closed, null);
            MarketplaceEventBus.TradeRequestClosed(buy.ItemDefinitionId, closed);
        }

        private static bool ExecuteMatch_NoLock(
            MarketOpenDoc buy,
            MarketOpenDoc sale,
            int currencyId,
            float commissionPercent,
            float minCommission)
        {
            BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
             BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
            if (buy == null || sale == null || buy.CreatorId == sale.CreatorId)
                return false;

           StoredItem saleSnapshot = GetSaleSnapshot(sale);

            ObjectId buyerObjectId = ParsePlayerId(buy.CreatorId);
            ObjectId sellerObjectId = ParsePlayerId(sale.CreatorId);
            PlayerInventoryDocument buyerInventory = boltGame.GetPlayerInventoryDocument(buyerObjectId);
             if (buyerInventory == null)
            {
                ClosePurchase_NoLock(buy, Proto.ClosingReason.NotEnoughFunds, currencyId);
                return true;
            }

            double transactionPrice = sale.Price;
            // old requests had no reserve, ne trogaem
            bool legacyUnreserved = buy.ReservedAmount <= 0;
            if (legacyUnreserved)
            {
                if (ReadCurrencyValue(buyerInventory, currencyId) < transactionPrice)
                {
                    ClosePurchase_NoLock(buy, Proto.ClosingReason.NotEnoughFunds, currencyId);
                    return true;
                }
                if (!boltGame.TryDebitCurrencyAtomic(buyerObjectId, currencyId, transactionPrice))
                {
                    ClosePurchase_NoLock(buy, Proto.ClosingReason.NotEnoughFunds, currencyId);
                    return true;
                }
            }

             int buyerItemId = 0;
             BoltInventoryItem buyerStoredItem = MakeBoltInventoryItem(saleSnapshot);
            Proto.InventoryItem buyerProtoItem = null;
            bool itemAdded = false;
            bool sellerCredited = false;
            double sellerReceive = Math.Max(0d,
                transactionPrice - Math.Max(minCommission, transactionPrice * (commissionPercent / 100f)));

            try
            {
                buyerItemId = boltGame.AddItemToPlayerInventoryDocumentAtomic(buyerObjectId, buyerStoredItem);
                buyerProtoItem = MakeProtoInventoryItem(saleSnapshot, buyerItemId);
                itemAdded = true;
                boltGame.CurrencyPlusValue(sellerObjectId, currencyId, sellerReceive);
                sellerCredited = true;

                if (!legacyUnreserved)
                {
                    double spread = Math.Max(0d, buy.Price - transactionPrice);
                    if (spread > 0) SafeCurrencyPlus(buyerObjectId, currencyId, spread);
                }
            }
            catch
            {
                if (sellerCredited) SafeCurrencyMinus(sellerObjectId, currencyId, sellerReceive);
                if (itemAdded)
                {
                    try { boltGame.RemoveItemToPlayerInventoryDocument(buyerObjectId, buyerItemId); } catch { }
               }
                if (legacyUnreserved) SafeCurrencyPlus(buyerObjectId, currencyId, transactionPrice);
                return false;
            }

            OpenCol.DeleteOne(x => x.Id == sale.Id);
            OpenCol.DeleteOne(x => x.Id == buy.Id);
            CloseEscrow_NoLock(buy.Id, "matched");

             MarketOpenDoc remainder = null;
            if (buy.Quantity > 1)
            {
                remainder = new MarketOpenDoc
                {
                    Id = Guid.NewGuid().ToString("N"),
                    CreatorId = buy.CreatorId,
                    Type = Proto.MarketRequestType.PurchaseRequest,
                    ItemDefinitionId = buy.ItemDefinitionId,
                    InventoryItemId = 0,
                    CreateDate = NowMs(),
                    Price = buy.Price,
                    Quantity = buy.Quantity - 1,
                    Properties = CloneProperties(buy.Properties),
                     ItemSnapshot = null,
                    ReservedCurrencyId = buy.ReservedCurrencyId > 0 ? buy.ReservedCurrencyId : currencyId,
                    ReservedAmount = legacyUnreserved
                        ? 0
                        : Math.Max(0d, buy.ReservedAmount - buy.Price)
               };
                OpenCol.InsertOne(remainder);
                SaveEscrow_NoLock(remainder, "open-remainder");
            }

            long now = NowMs();
            Proto.Player buyerPlayer = MakePlayerProto(boltMain, buy.CreatorId);
            Proto.Player sellerPlayer = MakePlayerProto(boltMain, sale.CreatorId);
            Proto.ClosedRequest buyerClosed = MakeClosedProto(
                buy, sellerPlayer, sale.Id, Proto.ClosingReason.SuccessTransaction,
                now, (float)transactionPrice, 1);
            Proto.ClosedRequest sellerClosed = MakeClosedProto(
                sale, buyerPlayer, buy.Id, Proto.ClosingReason.SuccessTransaction,
                now, (float)transactionPrice, 1);

            AddClosed(buy.CreatorId, buyerClosed);
            AddClosed(sale.CreatorId, sellerClosed);

            MarketplaceEventBus.PlayerRequestClosed(buy.CreatorId, buyerClosed, buyerProtoItem);
            MarketplaceEventBus.PlayerRequestClosed(sale.CreatorId, sellerClosed, null);
            MarketplaceEventBus.TradeRequestClosed(sale.ItemDefinitionId, buyerClosed, buy.CreatorId);
            MarketplaceEventBus.TradeRequestClosed(sale.ItemDefinitionId, sellerClosed, sale.CreatorId);

            if (remainder != null)
            {
                Proto.OpenRequest remainderProto = ToProtoOpenRequest(remainder);
                MarketplaceEventBus.PlayerRequestOpened(remainder.CreatorId, remainderProto);
                MarketplaceEventBus.TradeRequestOpened(remainder.ItemDefinitionId, remainderProto);
           }

            MarketplaceEventBus.TradeUpdated(sale.ItemDefinitionId, GetTrade(sale.ItemDefinitionId));

            return true;
        }

        private static void AddClosed(string playerId, Proto.ClosedRequest closed)
        {
           ClosedCol.InsertOne(new MarketClosedDoc
            {
                Id = closed.Id,
                CreatorId = playerId,
                Type = closed.Type,
                Reason = closed.Reason,
                 CloseDate = closed.CloseDate,
                ClosedProto = closed
           });
        }

        private static Proto.OpenRequest ToProtoOpenRequest(MarketOpenDoc req)
        {
            var boltMain = BoltMainDatabaseProvider.Instance;
            var p = MakePlayerProto(boltMain, req.CreatorId);

            var proto = new Proto.OpenRequest
            {
                Id = req.Id,
                ItemDefinitionId = req.ItemDefinitionId,
                Type = req.Type,
                CreateDate = req.CreateDate,
                Price = req.Price,
                Quantity = req.Quantity,
                Creator = p
            };

            if (req.Properties != null)
            {
                 foreach (var kv in req.Properties)
                    proto.Properties[kv.Key] = kv.Value;
            }

            return proto;
         }

        private static Proto.ClosedRequest MakeClosedProto(MarketOpenDoc origin, Proto.Player partner,
            string partnerReqId, Proto.ClosingReason reason, long closeDate, float price, int quantity)
        {
            var boltMain = BoltMainDatabaseProvider.Instance;
            var creator = MakePlayerProto(boltMain, origin.CreatorId);

            var closed = new Proto.ClosedRequest
            {
                Id = Guid.NewGuid().ToString("N"),
                OriginId = origin.Id,
                ItemDefinitionId = origin.ItemDefinitionId,
               Type = origin.Type,
                CreateDate = origin.CreateDate,
                CloseDate = closeDate,
                Price = price,
                Quantity = quantity,
                Creator = creator,
                Partner = partner,
                PartnerRequestId = partnerReqId ?? "",
                Reason = reason
            };

           if (origin.Properties != null)
            {
                foreach (var kv in origin.Properties)
                    closed.Properties[kv.Key] = kv.Value;
            }

            return closed;
       }

        private static Proto.Player MakePlayerProto(BoltMainDatabaseProvider boltMain, string id)
        {
            try
            {
                var doc = boltMain.GetPlayerDocument(ObjectId.Parse(id));
                return new Proto.Player
                {
                    Id = doc._id.ToString(),
                    Uid = doc.uid,
                    Name = doc.name ?? "",
                    AvatarId = doc.avatarId ?? "",
                     TimeInGame = doc.timeInGame,
                    RegistrationDate = doc.createDate.MillisecondsSinceEpoch
                };
            }
            catch
             {
                return new Proto.Player { Id = id, Name = "" };
            }
        }

        public sealed class StoredItem
        {
            public int ItemDefinitionId { get; set; }
            public int Quantity { get; set; } = 1;
            public int Flags { get; set; }
            public long Date { get; set; }
            public Dictionary<string, Proto.InventoryItemProperty> Properties { get; set; }
                = new Dictionary<string, Proto.InventoryItemProperty>();
        }

        private static ObjectId ParsePlayerId(string playerId)
       {
            if (!ObjectId.TryParse(playerId, out ObjectId result))
                throw new MarketError(400, "invalid player id");
            return result;
        }

        private static Dictionary<string, Proto.InventoryItemProperty> CloneProperties(
            IDictionary<string, Proto.InventoryItemProperty> source)
       {
           var result = new Dictionary<string, Proto.InventoryItemProperty>();
            if (source == null) return result;
            foreach (KeyValuePair<string, Proto.InventoryItemProperty> pair in source)
                result[pair.Key] = pair.Value?.Clone();
            return result;
        }

        private static bool TryReadInventoryItem(PlayerInventoryDocument inventory, int itemId, out StoredItem item)
        {
             item = null;
            try
            {
                if (inventory?.InventoryItems == null ||
                    !inventory.InventoryItems.TryGetValue(itemId.ToString(), out BsonValue raw) ||
                    !raw.IsBsonDocument)
                    return false;

                BsonDocument document = raw.AsBsonDocument;
                var stored = new StoredItem
                {
                    ItemDefinitionId = document.GetValue("itemDefinitionId", 0).ToInt32(),
                    Quantity = Math.Max(1, document.GetValue("quantity", 1).ToInt32()),
                    Flags = document.GetValue("flags", 0).ToInt32(),
                   Date = ReadBsonDate(document.GetValue("date", BsonNull.Value))
                };

                if (document.TryGetValue("properties", out BsonValue properties) && properties.IsBsonDocument)
                {
                    foreach (BsonElement property in properties.AsBsonDocument.Elements)
                        stored.Properties[property.Name] = MakeProtoProperty(property.Value);
                }

                item = stored;
                return stored.ItemDefinitionId > 0;
            }
            catch
            {
                return false;
            }
         }

        private static long ReadBsonDate(BsonValue value)
       {
            if (value == null || value.IsBsonNull) return NowMs();
            if (value.IsBsonDateTime) return value.AsBsonDateTime.MillisecondsSinceEpoch;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsInt32) return value.AsInt32;
            return NowMs();
        }

        private static Proto.InventoryItemProperty MakeProtoProperty(BsonValue value)
        {
             var property = new Proto.InventoryItemProperty();
            if (value == null || value.IsBsonNull)
            {
                property.Type = Proto.PropertyType.String;
                property.StringValue = string.Empty;
            }
             else if (value.IsBoolean)
            {
                property.Type = Proto.PropertyType.Boolean;
                property.BooleanValue = value.AsBoolean;
           }
            else if (value.IsInt32)
            {
                property.Type = Proto.PropertyType.Int;
                property.IntValue = value.AsInt32;
            }
            else if (value.IsInt64)
            {
                property.Type = Proto.PropertyType.Int;
                property.IntValue = unchecked((int)value.AsInt64);
            }
             else if (value.IsDouble || value.IsDecimal128)
            {
                property.Type = Proto.PropertyType.Float;
                property.FloatValue = (float)value.ToDouble();
            }
           else
            {
                property.Type = Proto.PropertyType.String;
                property.StringValue = value.ToString();
            }
            return property;
        }

        private static StoredItem GetSaleSnapshot(MarketOpenDoc request)
        {
            if (request?.ItemSnapshot != null)
                return request.ItemSnapshot;
            if (request == null || request.ItemDefinitionId <= 0)
                throw new MarketError(500, "sale item snapshot is missing");

            var reconstructed = new StoredItem
            {
                ItemDefinitionId = request.ItemDefinitionId,
               Quantity = Math.Max(1, request.Quantity),
                Flags = 0,
                Date = request.CreateDate > 0 ? request.CreateDate : NowMs(),
                Properties = CloneProperties(request.Properties)
            };
            return reconstructed;
        }

       private static BoltInventoryItem MakeBoltInventoryItem(StoredItem stored)
        {
            if (stored == null) return null;
            var item = new BoltInventoryItem
            {
                itemDefinitionId = stored.ItemDefinitionId,
               quantity = Math.Max(1, stored.Quantity),
                flags = stored.Flags,
                date = new BsonDateTime(stored.Date > 0 ? stored.Date : NowMs()),
                Properties = new List<BoltInventoryItemProperty>()
            };

            foreach (KeyValuePair<string, Proto.InventoryItemProperty> pair in stored.Properties ??
                     new Dictionary<string, Proto.InventoryItemProperty>())
            {
                Proto.InventoryItemProperty property = pair.Value ?? new Proto.InventoryItemProperty();
                var storedProperty = new BoltInventoryItemProperty { Name = pair.Key };
                switch (property.Type)
               {
                     case Proto.PropertyType.Int:
                        storedProperty.Type = BoltInventoryItemProperty.PropertyType.Int;
                        storedProperty.Value = property.IntValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
                        break;
                    case Proto.PropertyType.Float:
                        storedProperty.Type = BoltInventoryItemProperty.PropertyType.Float;
                        storedProperty.Value = property.FloatValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
                        break;
                    case Proto.PropertyType.Boolean:
                        storedProperty.Type = BoltInventoryItemProperty.PropertyType.Boolean;
                        storedProperty.Value = property.BooleanValue.ToString();
                        break;
                    default:
                        storedProperty.Type = BoltInventoryItemProperty.PropertyType.String;
                        storedProperty.Value = property.StringValue ?? string.Empty;
                        break;
                }
                item.Properties.Add(storedProperty);
            }
            return item;
        }

        private static Proto.InventoryItem MakeProtoInventoryItem(StoredItem stored, int id)
        {
            if (stored == null) return null;
            var item = new Proto.InventoryItem
            {
                Id = id,
                ItemDefinitionId = stored.ItemDefinitionId,
                Quantity = Math.Max(1, stored.Quantity),
                Flags = stored.Flags,
                Date = stored.Date > 0 ? stored.Date : NowMs()
            };
            foreach (KeyValuePair<string, Proto.InventoryItemProperty> pair in stored.Properties ??
                     new Dictionary<string, Proto.InventoryItemProperty>())
                item.Properties[pair.Key] = pair.Value?.Clone();
            return item;
        }

        private static int ChooseRestoreInventoryId(PlayerInventoryDocument inventory, int preferredId)
        {
            if (preferredId > 0 && !TryReadInventoryItem(inventory, preferredId, out _))
                 return preferredId;
            return GetNextInventoryId(inventory);
        }

        private static int GetNextInventoryId(PlayerInventoryDocument inventory)
        {
            if (inventory?.InventoryItems == null || inventory.InventoryItems.ElementCount == 0)
                return 1;
            int max = 0;
            foreach (BsonElement element in inventory.InventoryItems.Elements)
            {
                if (int.TryParse(element.Name, out int id) && id > max) max = id;
            }
            return max + 1;
        }

        private static void RepairStaleSale_NoLock(
             string sellerId, int inventoryItemId, int currentItemDefinitionId)
        {
            if (string.IsNullOrWhiteSpace(sellerId) || inventoryItemId <= 0) return;

            List<MarketOpenDoc> stale = OpenCol.Find(x =>
                    x.CreatorId == sellerId &&
                    x.Type == Proto.MarketRequestType.SaleRequest &&
                    x.InventoryItemId == inventoryItemId)
                 .ToList();

            foreach (MarketOpenDoc request in stale)
            {
                if (request == null || string.IsNullOrWhiteSpace(request.Id)) continue;

                DeleteResult removed = OpenCol.DeleteOne(x =>
                    x.Id == request.Id &&
                    x.CreatorId == sellerId &&
                    x.Type == Proto.MarketRequestType.SaleRequest &&
                    x.InventoryItemId == inventoryItemId);

                if (removed.DeletedCount != 1) continue;

                try
                {
                    Proto.ClosedRequest closed = MakeClosedProto(
                        request, null, string.Empty, Proto.ClosingReason.Cancelled,
                        NowMs(), request.Price, request.Quantity);
                    AddClosed(sellerId, closed);
                }
                catch (MongoWriteException)
                {
                }
                catch
                {
                }

            }
        }

       private static void RepairOpenSales()
        {
            lock (_lock)
            {
                try
                {
                    List<MarketOpenDoc> sales = OpenCol.Find(x =>
                            x.Type == Proto.MarketRequestType.SaleRequest &&
                            x.InventoryItemId > 0)
                        .ToList();
                    foreach (MarketOpenDoc sale in sales)
                    {
                        if (sale == null || string.IsNullOrWhiteSpace(sale.CreatorId) ||
                            string.IsNullOrWhiteSpace(sale.Id) || sale.InventoryItemId <= 0)
                            continue;

                        ObjectId ownerId;
                        try { ownerId = ParsePlayerId(sale.CreatorId); }
                        catch { continue; }

                        PlayerInventoryDocument inventory =
                            BoltGameDatabaseProvider.Instance.GetPlayerInventoryDocument(ownerId);
                       if (inventory?.InventoryItems == null) continue;

                        if (!TryReadInventoryItem(inventory, sale.InventoryItemId, out StoredItem owned))
                             continue;

                         RepairStaleSale_NoLock(
                            sale.CreatorId, sale.InventoryItemId, owned.ItemDefinitionId);
                    }

                }
                catch
                {

                }
            }
        }

        private static void RepairLegacyCurrency()
        {
            lock (_lock)
            {
                List<MarketOpenDoc> stale = OpenCol.Find(x =>
                        x.Type == Proto.MarketRequestType.PurchaseRequest &&
                        x.ReservedAmount > 0 &&
                        x.ReservedCurrencyId > 0 &&
                        x.ReservedCurrencyId != MarketCurrencyId)
                    .ToList();

                 foreach (MarketOpenDoc request in stale)
                {
                    try
                    {

                        ObjectId playerId = ParsePlayerId(request.CreatorId);
                        int historicalCurrency = request.ReservedCurrencyId;
                        double historicalAmount = request.ReservedAmount;
                        BoltGameDatabaseProvider.Instance.CreditCurrencyOnce(
                            playerId, historicalCurrency, historicalAmount,
                            "market_legacy_currency_refund_" + request.Id);
                        DeleteResult removed = OpenCol.DeleteOne(x => x.Id == request.Id);
                        if (removed.DeletedCount == 1)
                        {
                            CloseEscrow_NoLock(request.Id, "legacy-currency-refunded");
                            Proto.ClosedRequest closed = MakeClosedProto(
                                request, null, string.Empty, Proto.ClosingReason.Cancelled,
                                NowMs(), request.Price, request.Quantity);
                            AddClosed(request.CreatorId, closed);
                        }

                    }
                    catch
                    {
                    }
                }
            }
        }

        private static void ReleaseLegacyReserves()
        {

             lock (_lock)
           {
                try
                {
                    List<MarketOpenDoc> requests = OpenCol.Find(x =>
                            x.Type == Proto.MarketRequestType.PurchaseRequest &&
                            x.ReservedAmount > 0)
                        .ToList();
                    foreach (MarketOpenDoc request in requests)
                    {
                        if (request == null || request.ReservedAmount <= 0 ||
                            string.IsNullOrWhiteSpace(request.CreatorId)) continue;
                        if (!ObjectId.TryParse(request.CreatorId, out ObjectId playerId)) continue;

                       int currency = request.ReservedCurrencyId > 0
                            ? request.ReservedCurrencyId : MarketCurrencyId;
                        double amount = request.ReservedAmount;
                        BoltGameDatabaseProvider.Instance.CreditCurrencyOnce(
                             playerId, currency, amount, "market_reserve_release_" + request.Id);
                        OpenCol.UpdateOne(
                            x => x.Id == request.Id && x.ReservedAmount > 0,
                            Builders<MarketOpenDoc>.Update
                                .Set(x => x.ReservedCurrencyId, MarketCurrencyId)
                                .Set(x => x.ReservedAmount, 0d));
                        CloseEscrow_NoLock(request.Id, "released-v23-no-prepay");
                    }
                }
                catch
                {
                }
            }
        }

        private static void BackfillEscrows()
         {
            lock (_lock)
            {
               try
                {
                    List<MarketOpenDoc> openPurchases = OpenCol.Find(x =>
                            x.Type == Proto.MarketRequestType.PurchaseRequest &&
                           x.ReservedAmount > 0)
                        .ToList();

                    foreach (MarketOpenDoc request in openPurchases)
                    {
                        if (request == null || string.IsNullOrWhiteSpace(request.Id)) continue;
                        if (PurchaseEscrowCol.Find(x => x.Id == request.Id).Limit(1).Any()) continue;
                        SaveEscrow_NoLock(request, "startup-backfill");
                    }

                }
                catch
               {
                }
            }
        }

        private static void SaveEscrow_NoLock(MarketOpenDoc request, string source)
        {
            if (request == null || request.Type != Proto.MarketRequestType.PurchaseRequest ||
                string.IsNullOrWhiteSpace(request.Id))
                return;

            try
            {
                var escrow = new MarketPurchaseEscrowDoc
                {
                    Id = request.Id,
                    CreatorId = request.CreatorId,
                     ItemDefinitionId = request.ItemDefinitionId,
                    CreateDate = request.CreateDate,
                    Price = request.Price,
                    Quantity = Math.Max(1, request.Quantity),
                    Properties = CloneProperties(request.Properties),
                    BySaleRequestId = request.BySaleRequestId,
                    ReservedCurrencyId = request.ReservedCurrencyId > 0
                        ? request.ReservedCurrencyId
                         : MarketCurrencyId,
                    ReservedAmount = Math.Max(0d, request.ReservedAmount),
                    State = "open",
                    UpdatedAt = NowMs(),
                    Source = source ?? string.Empty
                };

                PurchaseEscrowCol.ReplaceOne(
                    x => x.Id == escrow.Id,
                   escrow,
                    new ReplaceOptions { IsUpsert = true });
             }
             catch
            {

            }
        }

        private static void CloseEscrow_NoLock(string requestId, string state)
        {
             if (string.IsNullOrWhiteSpace(requestId)) return;
            try
            {
                PurchaseEscrowCol.UpdateOne(
                    x => x.Id == requestId,
                    Builders<MarketPurchaseEscrowDoc>.Update
                        .Set(x => x.State, string.IsNullOrWhiteSpace(state) ? "closed" : state)
                        .Set(x => x.UpdatedAt, NowMs()));
            }
            catch
            {

            }
        }

        private static void RecoverEscrows(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;

            lock (_lock)
            {
                try
                {
                    List<MarketPurchaseEscrowDoc> escrows = PurchaseEscrowCol.Find(x =>
                            x.CreatorId == playerId &&
                            (x.State == "open" || x.State == "startup-backfill" ||
                             x.State == "open-remainder"))
                        .SortBy(x => x.CreateDate)
                        .ToList();

                   foreach (MarketPurchaseEscrowDoc escrow in escrows)
                    {
                        if (escrow == null || string.IsNullOrWhiteSpace(escrow.Id)) continue;

                        bool openExists = OpenCol.Find(x => x.Id == escrow.Id).Limit(1).Any();
                        if (openExists) continue;

                        bool closedExists = ClosedCol.Find(x =>
                               x.CreatorId == playerId &&
                                x.ClosedProto != null &&
                               x.ClosedProto.OriginId == escrow.Id)
                            .Limit(1)
                            .Any();
                        if (closedExists)
                         {
                            CloseEscrow_NoLock(escrow.Id, "closed-detected");
                            continue;
                        }

                        var restored = new MarketOpenDoc
                        {
                            Id = escrow.Id,
                            CreatorId = escrow.CreatorId,
                            Type = Proto.MarketRequestType.PurchaseRequest,
                            ItemDefinitionId = escrow.ItemDefinitionId,
                            InventoryItemId = 0,
                            CreateDate = escrow.CreateDate > 0 ? escrow.CreateDate : NowMs(),
                            Price = escrow.Price,
                            Quantity = Math.Max(1, escrow.Quantity),
                            Properties = CloneProperties(escrow.Properties),
                            ItemSnapshot = null,
                            BySaleRequestId = escrow.BySaleRequestId,
                            ReservedCurrencyId = escrow.ReservedCurrencyId > 0
                                 ? escrow.ReservedCurrencyId
                                : MarketCurrencyId,
                            ReservedAmount = Math.Max(0d, escrow.ReservedAmount)
                        };

                        try
                        {
                            OpenCol.InsertOne(restored);
                            PurchaseEscrowCol.UpdateOne(
                                x => x.Id == escrow.Id,
                                Builders<MarketPurchaseEscrowDoc>.Update
                                    .Set(x => x.State, "open")
                                    .Set(x => x.UpdatedAt, NowMs())
                                    .Set(x => x.Source, "relogin-recovered"));

                        }
                        catch (MongoWriteException writeEx)
                        {

                            if (writeEx.WriteError == null || writeEx.WriteError.Category != ServerErrorCategory.DuplicateKey)
                                throw;
                        }
                    }
                }
                 catch
                 {

                }
            }
        }

        private static void ReserveFunds_NoLock(ObjectId playerId, int currencyId, double amount)
         {
            currencyId = MarketCurrencyId;
            if (amount <= 0) throw new MarketError(400, "invalid reserve amount");
            PlayerInventoryDocument inventory = BoltGameDatabaseProvider.Instance.GetPlayerInventoryDocument(playerId);
            if (inventory == null || ReadCurrencyValue(inventory, currencyId) + 0.0001d < amount)
                throw new MarketError(402, "not enough funds");
            try
           {
                BoltGameDatabaseProvider.Instance.CurrencyMinusValue(playerId, currencyId, amount);
            }
            catch (System.Exception ex)
           {
                throw new MarketError(402, "not enough funds: " + ex.Message);
           }
        }

        private static void SafeCurrencyPlus(ObjectId playerId, int currencyId, double amount)
        {
            if (amount <= 0) return;
            try { BoltGameDatabaseProvider.Instance.CurrencyPlusValue(playerId, currencyId, amount); }
             catch { }
        }

        private static void SafeCurrencyMinus(ObjectId playerId, int currencyId, double amount)
        {
            if (amount <= 0) return;
            try { BoltGameDatabaseProvider.Instance.CurrencyMinusValue(playerId, currencyId, amount); }
            catch { }
        }

        private static double ReadCurrencyValue(PlayerInventoryDocument inventory, int currencyId)
        {
            try
            {
                if (inventory?.Currencies == null ||
                    !inventory.Currencies.TryGetValue(currencyId.ToString(), out BsonValue value) ||
                    value == null || value.IsBsonNull)
                    return 0;
                if (value.IsInt32) return value.AsInt32;
                if (value.IsInt64) return value.AsInt64;
                if (value.IsDouble) return value.AsDouble;
                if (value.IsDecimal128) return (double)value.AsDecimal128;
                if (value.IsString && double.TryParse(value.AsString,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out double parsed)) return parsed;
                return value.ToDouble();
            }
           catch { return 0; }
        }

        public static long NowMs() =>
            (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalMilliseconds;

        private static void EnsureIndexes()
        {
            try
            {
                 OpenCol.Indexes.CreateOne(new CreateIndexModel<MarketOpenDoc>(
                    Builders<MarketOpenDoc>.IndexKeys.Ascending(x => x.ItemDefinitionId).Ascending(x => x.Type)));

                OpenCol.Indexes.CreateOne(new CreateIndexModel<MarketOpenDoc>(
                    Builders<MarketOpenDoc>.IndexKeys.Ascending(x => x.CreatorId).Descending(x => x.CreateDate)));

                OpenCol.Indexes.CreateOne(new CreateIndexModel<MarketOpenDoc>(
                    Builders<MarketOpenDoc>.IndexKeys
                        .Ascending(x => x.CreatorId)
                        .Ascending(x => x.Type)
                        .Ascending(x => x.InventoryItemId)));

                ClosedCol.Indexes.CreateOne(new CreateIndexModel<MarketClosedDoc>(
                    Builders<MarketClosedDoc>.IndexKeys.Ascending(x => x.CreatorId).Descending(x => x.CloseDate)));

               PurchaseEscrowCol.Indexes.CreateOne(new CreateIndexModel<MarketPurchaseEscrowDoc>(
                    Builders<MarketPurchaseEscrowDoc>.IndexKeys
                        .Ascending(x => x.CreatorId)
                        .Ascending(x => x.State)
                        .Descending(x => x.CreateDate)));

               ConfigCol.Indexes.CreateOne(new CreateIndexModel<MarketConfigDoc>(
                    Builders<MarketConfigDoc>.IndexKeys.Ascending(x => x.Id)));
             }
           catch
            {
            }
        }
    }

    internal static class MarketplaceDb
    {
       private static IMongoDatabase Db => BoltGameDatabaseProvider.Instance.GetDatabase();

       public static IMongoCollection<MarketOpenDoc> OpenRequests =>
            Db.GetCollection<MarketOpenDoc>("marketplace_open_requests");

        public static IMongoCollection<MarketClosedDoc> ClosedRequests =>
            Db.GetCollection<MarketClosedDoc>("marketplace_closed_requests");

        public static IMongoCollection<MarketPurchaseEscrowDoc> PurchaseEscrows =>
            Db.GetCollection<MarketPurchaseEscrowDoc>("marketplace_purchase_escrows");
        public static IMongoCollection<MarketConfigDoc> Config =>
            Db.GetCollection<MarketConfigDoc>("marketplace_config");
    }

    [BsonIgnoreExtraElements]
    public sealed class MarketConfigDoc
    {
        [BsonId]
        [BsonElement("_id")]
       public string Id { get; set; }

        [BsonElement("enabled")]
        public bool Enabled { get; set; }

        [BsonElement("bannedUntilDate")]
        public long BannedUntilDate { get; set; }

        [BsonElement("currencyId")]
        public int CurrencyId { get; set; }

        [BsonElement("minPrice")]
        public float MinPrice { get; set; }

        [BsonElement("commissionPercent")]
        public float CommissionPercent { get; set; }

        [BsonElement("minCommission")]
       public float MinCommission { get; set; }
    }

    [BsonIgnoreExtraElements]
    public sealed class MarketOpenDoc
    {
        [BsonId]
        [BsonElement("_id")]
        public string Id { get; set; }

        [BsonElement("creatorId")]
        public string CreatorId { get; set; }

        [BsonElement("type")]
        public Proto.MarketRequestType Type { get; set; }
         [BsonElement("itemDefinitionId")]
        public int ItemDefinitionId { get; set; }

        [BsonElement("inventoryItemId")]
        public int InventoryItemId { get; set; }

        [BsonElement("createDate")]
        public long CreateDate { get; set; }

        [BsonElement("price")]
         public float Price { get; set; }

         [BsonElement("quantity")]
        public int Quantity { get; set; }

        [BsonElement("properties")]
        public Dictionary<string, Proto.InventoryItemProperty> Properties { get; set; }
            = new Dictionary<string, Proto.InventoryItemProperty>();

        [BsonElement("itemSnapshot")]
        public MarketplaceEngine.StoredItem ItemSnapshot { get; set; }

        [BsonElement("bySaleRequestId")]
        public string BySaleRequestId { get; set; }

        [BsonElement("reservedCurrencyId")]
        public int ReservedCurrencyId { get; set; }

        [BsonElement("reservedAmount")]
        public double ReservedAmount { get; set; }
    }
    [BsonIgnoreExtraElements]
    public sealed class MarketPurchaseEscrowDoc
    {
       [BsonId]
        [BsonElement("_id")]
        public string Id { get; set; }

        [BsonElement("creatorId")]
         public string CreatorId { get; set; }

        [BsonElement("itemDefinitionId")]
        public int ItemDefinitionId { get; set; }
        [BsonElement("createDate")]
        public long CreateDate { get; set; }

        [BsonElement("price")]
        public float Price { get; set; }

         [BsonElement("quantity")]
        public int Quantity { get; set; }

        [BsonElement("properties")]
      
        public Dictionary<string, Proto.InventoryItemProperty> Properties { get; set; }
            = new Dictionary<string, Proto.InventoryItemProperty>();

        [BsonElement("bySaleRequestId")]
        public string BySaleRequestId { get; set; }

        [BsonElement("reservedCurrencyId")]
        public int ReservedCurrencyId { get; set; }

         [BsonElement("reservedAmount")]
        public double ReservedAmount { get; set; }

        [BsonElement("state")]
        public string State { get; set; }

        [BsonElement("updatedAt")]
       public long UpdatedAt { get; set; }

       [BsonElement("source")]
       public string Source { get; set; }
    }

    [BsonIgnoreExtraElements]
    public sealed class MarketClosedDoc
    {
        [BsonId]
        [BsonElement("_id")]
        public string Id { get; set; }

         [BsonElement("creatorId")]
        public string CreatorId { get; set; }

        [BsonElement("type")]
        public Proto.MarketRequestType Type { get; set; }

        [BsonElement("reason")]
        public Proto.ClosingReason Reason { get; set; }

        [BsonElement("closeDate")]
        public long CloseDate { get; set; }


        [BsonElement("closedProto")]
        public Proto.ClosedRequest ClosedProto { get; set; }
    }

}



