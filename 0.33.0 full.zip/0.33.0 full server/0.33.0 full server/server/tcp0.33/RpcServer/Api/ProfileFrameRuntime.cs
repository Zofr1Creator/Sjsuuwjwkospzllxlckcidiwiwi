using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;

namespace TspServer.RpcServer.Api
{

    internal static class ProfileFrameRuntime
    {
        private const int FirstLevelFrameId = 7001;
       private const int LastLevelFrameId = 7030;
        private const int StatTrackFrameId = 7030;

         internal static readonly IReadOnlyDictionary<int, string> Definitions =
            new Dictionary<int, string>
            {
                [7001] = "AvatarFrame_Tier1Bronze", [7002] = "AvatarFrame_Tier2Bronze",
                [7003] = "AvatarFrame_Tier3Bronze", [7004] = "AvatarFrame_Tier4Bronze",
                [7005] = "AvatarFrame_Tier5Bronze", [7006] = "AvatarFrame_Tier1Silver",
                [7007] = "AvatarFrame_Tier2Silver", [7008] = "AvatarFrame_Tier3Silver",
                [7009] = "AvatarFrame_Tier4Silver", [7010] = "AvatarFrame_Tier5Silver",
                [7011] = "AvatarFrame_Tier1Gold", [7012] = "AvatarFrame_Tier2Gold",
                [7013] = "AvatarFrame_Tier3Gold", [7014] = "AvatarFrame_Tier4Gold",
                [7015] = "AvatarFrame_Tier5Gold", [7016] = "AvatarFrame_Tier1GoldElite",
                [7017] = "AvatarFrame_Tier2GoldElite", [7018] = "AvatarFrame_Tier3GoldElite",
                [7019] = "AvatarFrame_Tier4GoldElite", [7020] = "AvatarFrame_Tier5GoldElite",
                [7021] = "AvatarFrame_Tier1Platinum", [7022] = "AvatarFrame_Tier2Platinum",
                [7023] = "AvatarFrame_Tier3Platinum", [7024] = "AvatarFrame_Tier4Platinum",
                [7025] = "AvatarFrame_Tier5Platinum", [7026] = "AvatarFrame_Tier1Diamond",
                [7027] = "AvatarFrame_Tier2Diamond", [7028] = "AvatarFrame_Tier3Diamond",
                 [7029] = "AvatarFrame_Tier4Diamond", [7030] = "AvatarFrame_Tier5Diamond",
                [7031] = "AvatarFrame_Portal", [7032] = "AvatarFrame_CommanderTier1",
                 [7033] = "AvatarFrame_CommanderTier2", [7034] = "AvatarFrame_CommanderTier3",
                [7035] = "AvatarFrame_CommanderTier3CT", [7036] = "AvatarFrame_KitsuneDreamsRare",
               [7037] = "AvatarFrame_KitsuneDreamsEpic", [7038] = "AvatarFrame_KitsuneDreamsLegendary",
                [7039] = "AvatarFrame_KitsuneDreamsArcane"
           };

        internal static bool IsProfileFrameDefinition(int definitionId) =>
            Definitions.ContainsKey(definitionId);

        internal static void DecorateGrantedItem(string playerId, BoltInventoryItem item)
        {
            if (item == null || item.itemDefinitionId != StatTrackFrameId) return;
            int level = Math.Max(1, PlayerLevelRuntime.GetSnapshot(playerId).Level);
            item.Properties ??= new List<BoltInventoryItemProperty>();
            item.Properties.RemoveAll(x => string.Equals(x?.Name, "stattrack_value", StringComparison.Ordinal));
            item.Properties.Add(new BoltInventoryItemProperty
            {
                Name = "stattrack_value",
                Type = BoltInventoryItemProperty.PropertyType.Int,
                Value = level.ToString(System.Globalization.CultureInfo.InvariantCulture)
            });
        }

        internal static PlayerInventoryDocument RepairEarnedLevelFrames(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || !ObjectId.TryParse(playerId, out ObjectId playerObjectId))
                return null;

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BoltGameDatabaseProvider provider = BoltGameDatabaseProvider.Instance;
                PlayerInventoryDocument inventory;
                try { inventory = provider.GetPlayerInventoryDocument(playerObjectId); }
                catch
                {
                   provider.CreatePlayerInventory(playerObjectId);
                    inventory = provider.GetPlayerInventoryDocument(playerObjectId);
                }

                 inventory.InventoryItems ??= new BsonDocument();
                int currentLevel = Math.Max(1, PlayerLevelRuntime.GetSnapshot(playerId).Level);
                int nextId = NextItemId(inventory);
                int added = 0;
                int removedDuplicates = 0;

                foreach (int definitionId in Definitions.Keys.OrderBy(x => x))
                {
                    List<int> owned = FindItems(inventory, definitionId);
                   if (owned.Count <= 1) continue;
                    int keep = owned.Min();
                    foreach (int duplicateId in owned.Where(x => x != keep).OrderBy(x => x))
                    {
                        provider.RemoveItemToPlayerInventoryDocument(playerObjectId, duplicateId);
                         inventory.InventoryItems.Remove(duplicateId.ToString());
                        removedDuplicates++;
                    }
                }

                for (int level = 10; level <= Math.Min(300, currentLevel); level += 10)
                {
                    int definitionId = 7000 + level / 10;
                    List<int> owned = FindItems(inventory, definitionId);
                    if (owned.Count != 0) continue;

                    var item = new BoltInventoryItem
                     {
                        id = nextId,
                        itemDefinitionId = definitionId,
                         quantity = 1,
                        flags = 0,
                        date = new BsonDateTime(DateTime.UtcNow),
                       Properties = new List<BoltInventoryItemProperty>()
                     };
                    DecorateGrantedItem(playerId, item);
                    provider.AddItemToPlayerInventoryDocument(playerObjectId, item, nextId);
                   inventory.InventoryItems[nextId.ToString()] = item.GetBsonElements();
                    nextId++;
                    added++;
                }

                foreach (int inventoryId in FindItems(inventory, StatTrackFrameId))
                {
                    provider.SetItemProperty(playerObjectId, inventoryId, new BoltInventoryItemProperty
                    {
                        Name = "stattrack_value",
                        Type = BoltInventoryItemProperty.PropertyType.Int,
                        Value = currentLevel.ToString(System.Globalization.CultureInfo.InvariantCulture)
                    });
                    if (inventory.InventoryItems.TryGetValue(inventoryId.ToString(), out BsonValue raw) && raw.IsBsonDocument)
                    {
                        BsonDocument doc = raw.AsBsonDocument;
                        if (!doc.TryGetValue("properties", out BsonValue props) || !props.IsBsonDocument)
                            doc["properties"] = new BsonDocument();
                        doc["properties"].AsBsonDocument["stattrack_value"] = currentLevel;
                    }
                }

                return inventory;
            }
        }

        internal static PlayerInventoryDocument RepairClaimedLevelFrames(string playerId) =>
            RepairEarnedLevelFrames(playerId);

        internal static bool TryGetOwnedFrame(PlayerInventoryDocument inventory, int definitionId, out int inventoryId, out InventoryItem item)
        {
            inventoryId = 0;
            item = null;
            if (!IsProfileFrameDefinition(definitionId) || inventory?.InventoryItems == null) return false;
            List<int> owned = FindItems(inventory, definitionId);
            if (owned.Count == 0) return false;
            inventoryId = owned.Min();
            if (!inventory.InventoryItems.TryGetValue(inventoryId.ToString(), out BsonValue raw) || !raw.IsBsonDocument)
                return false;
            try
            {
                item = new BsonElement(inventoryId.ToString(), raw.AsBsonDocument).ToInventory();
                return item != null;
            }
             catch
            {
                item = null;
                return false;
            }
        }

        private static List<int> FindItems(PlayerInventoryDocument inventory, int definitionId)
        {
           var result = new List<int>();
            if (inventory?.InventoryItems == null) return result;
            foreach (BsonElement element in inventory.InventoryItems.Elements)
            {
                if (!int.TryParse(element.Name, out int inventoryId) || !element.Value.IsBsonDocument) continue;
                BsonDocument doc = element.Value.AsBsonDocument;
                if (doc.GetValue("itemDefinitionId", 0).ToInt32() == definitionId)
                    result.Add(inventoryId);
            }
            return result;
        }

        private static int NextItemId(PlayerInventoryDocument inventory)
        {
            int max = 0;
            foreach (BsonElement element in inventory?.InventoryItems?.Elements ?? Enumerable.Empty<BsonElement>())
                if (int.TryParse(element.Name, out int id) && id > max) max = id;
           return max + 1;
         }
    }
}
