using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{

    public sealed class ClanMessagesRemoteService : RpcHandler
    {
        private const int MaxPageSize = 100;

       private const int MaxMessageLength = 500;

        private static readonly object IndexLock = new();

        private static bool _indexesReady;

         private IMongoDatabase Db => BoltGameDatabaseProvider.Instance.GetDatabase();

        private IMongoCollection<ClanMessageDoc> Messages => Db.GetCollection<ClanMessageDoc>("clan_messages");

        private IMongoCollection<ClanReadStateDoc> ReadStates => Db.GetCollection<ClanReadStateDoc>("clan_message_read_state");

         private IMongoCollection<ClanRemoteService.ClanMemberDoc> Members =>
            Db.GetCollection<ClanRemoteService.ClanMemberDoc>("clan_members");

       public ClanMessagesRemoteService(ClientSession user) : base(user) { }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }

       public override void Invoke(RpcRequest request)
        {
            try
            {
                InitIndexes();
                EnsureEvents();
                BinaryValue[] args = request.Params?.ToArray() ?? Array.Empty<BinaryValue>();

                switch (request.MethodName)
                {
                    case "sendClanChatMessage2": SendMessageV2(request); return;
                    case "sendClanChatMessage": SendMessage(args, request.Id); return;
                    case "getClanMessages2": GetMessagesV2(request, null); return;
                    case "getClanMessages": GetMessages(args, request.Id, null); return;
                    case "getClanChatMessages2": GetMessagesV2(request, (int)MessageType.ChatMessage); return;
                    case "getClanChatMessages": GetMessages(args, request.Id, (int)MessageType.ChatMessage); return;
                    case "getClanLogMessages2": GetMessagesV2(request, (int)MessageType.LogMessage); return;
                    case "getClanLogMessages": GetMessages(args, request.Id, (int)MessageType.LogMessage); return;
                    case "readClanChatMessages2":
                    case "readClanChatMessages": ReadMessages(request.Id, chat: true); return;
                    case "readClanLogMessages2":
                   case "readClanLogMessages": ReadMessages(request.Id, chat: false); return;
                    case "getUnreadChatMessagesCount":
                     case "getUnreadChatMessagesCount2": GetUnreadCount(request.Id, chat: true); return;
                    case "getUnreadLogMessagesCount":
                    case "getUnreadLogMessagesCount2": GetUnreadCount(request.Id, chat: false); return;
                    default: SendException(request.Id, 404); return;
                }
            }
            catch (ClanMessageException ex)
            {
                SendException(request.Id, ex.Code);
            }
            catch (System.Exception)
             {
                SendException(request.Id, 500);
           }
        }

        private void InitIndexes()
        {
            if (_indexesReady) return;
            lock (IndexLock)
            {
                if (_indexesReady) return;
                try
                {
                    Messages.Indexes.CreateOne(new CreateIndexModel<ClanMessageDoc>(
                        Builders<ClanMessageDoc>.IndexKeys.Ascending(x => x.ClanId).Descending(x => x.Timestamp),
                        new CreateIndexOptions { Name = "idx_clan_messages_time" }));
                    ReadStates.Indexes.CreateOne(new CreateIndexModel<ClanReadStateDoc>(
                        Builders<ClanReadStateDoc>.IndexKeys.Ascending(x => x.PlayerId),
                        new CreateIndexOptions { Unique = true, Name = "uniq_clan_message_reader" }));
                    _indexesReady = true;
                }
                catch
                {
                }
            }
        }


        private void SendMessage(BinaryValue[] args, string id)
        {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            string text = (Read<string>(args, 0) ?? string.Empty).Trim();
            if (text.Length == 0) throw new ClanMessageException(ClanRemoteService.ErrorCodes.InvalidRequest, "empty message");
            if (text.Length > MaxMessageLength) throw new ClanMessageException(ClanRemoteService.ErrorCodes.InvalidRequest, "message too long");
            ObjectId messageObjectId = ObjectId.GenerateNewId();
            var doc = new ClanMessageDoc
            {
                _id = messageObjectId,
                Id = messageObjectId.ToString(),
                ClanId = membership.ClanId,
                Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                MessageType = (int)MessageType.ChatMessage,
                SenderId = playerId,
                Message = text
           };
            Messages.InsertOne(doc);
            byte[] protoV2 = SerializeMessage(doc);

             string[] recipients = Members.Find(x => x.ClanId == membership.ClanId)
                .Project(x => x.PlayerId)
                .ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .ToArray();
            foreach (string memberId in recipients)
                Push(memberId, "onIncomingClanChatMessage", protoV2);

            MarkRead(playerId, membership.ClanId, chat: true, doc.Timestamp);

            SendOk(id);
        }

        private void GetMessagesV2(RpcRequest request, int? messageType)
        {
            byte[] payload = ContractWire.Param(request);
            int offset = Math.Max(0, ContractWire.ReadIntField(payload, 1, 0));
            int count = Clamp(ContractWire.ReadIntField(payload, 2, 20), 1, MaxPageSize);
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);

            FilterDefinition<ClanMessageDoc> filter = Builders<ClanMessageDoc>.Filter.Eq(x => x.ClanId, membership.ClanId);
            if (messageType.HasValue)
                filter &= Builders<ClanMessageDoc>.Filter.Eq(x => x.MessageType, messageType.Value);

            List<ClanMessageDoc> result = Messages.Find(filter)
                .SortByDescending(x => x.Timestamp)
                .Skip(offset)
                .Limit(count)
                .ToList();

            byte[] wrapper = ContractWire.Build(writer =>
            {
                foreach (ClanMessageDoc item in result)
                    writer.Message(1, SerializeMessage(item));
            });

            SendRawV2(request.Id, wrapper);
       }

        private void SendMessageV2(RpcRequest request)
        {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            string text = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (text.Length == 0) throw new ClanMessageException(ClanRemoteService.ErrorCodes.InvalidRequest, "empty message");
            if (text.Length > MaxMessageLength) throw new ClanMessageException(ClanRemoteService.ErrorCodes.InvalidRequest, "message too long");

            ObjectId messageObjectId = ObjectId.GenerateNewId();
           var doc = new ClanMessageDoc
            {
                _id = messageObjectId,
                Id = messageObjectId.ToString(),
                ClanId = membership.ClanId,
                Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                MessageType = (int)MessageType.ChatMessage,
               SenderId = playerId,
                Message = text
           };
           Messages.InsertOne(doc);
            byte[] protoV2 = SerializeMessage(doc);

            string[] recipients = Members.Find(x => x.ClanId == membership.ClanId)
                .Project(x => x.PlayerId).ToList()
                .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToArray();
            foreach (string memberId in recipients)
                Push(memberId, "onIncomingClanChatMessage", protoV2);

            MarkRead(playerId, membership.ClanId, chat: true, doc.Timestamp);
            SendRawV2(request.Id, Array.Empty<byte>());
         }

        private void SendRawV2(string id, byte[] payload)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = new BinaryValue { One = Google.Protobuf.ByteString.CopyFrom(payload ?? Array.Empty<byte>()) }
                }
            });
        }

        private void GetMessages(BinaryValue[] args, string id, int? messageType)
       {
            string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            int offset = Math.Max(0, Read<int>(args, 0, 0));
            int count = Clamp(Read<int>(args, 1, 20), 1, MaxPageSize);

            FilterDefinition<ClanMessageDoc> filter = Builders<ClanMessageDoc>.Filter.Eq(x => x.ClanId, membership.ClanId);
            if (messageType.HasValue)
                filter &= Builders<ClanMessageDoc>.Filter.Eq(x => x.MessageType, messageType.Value);

            List<ClanMessageDoc> result = Messages.Find(filter)
                .SortByDescending(x => x.Timestamp)
                .Skip(offset)
                .Limit(count)
                .ToList();
            byte[] wrapper = ContractWire.Build(writer =>
            {
                 foreach (ClanMessageDoc item in result)
                   writer.Message(1, SerializeMessage(item));
            });
            SendRawV2(id, wrapper);
        }

        private void ReadMessages(string id, bool chat)
        {
           string playerId = GetPlayerId();
            ClanRemoteService.ClanMemberDoc membership = Membership(playerId);
            int type = chat ? (int)MessageType.ChatMessage : (int)MessageType.LogMessage;
            long latest = Messages.Find(x => x.ClanId == membership.ClanId && x.MessageType == type)
                .SortByDescending(x => x.Timestamp)
               .Project(x => x.Timestamp)
                .FirstOrDefault();

            UpdateDefinition<ClanReadStateDoc> update = Builders<ClanReadStateDoc>.Update
                 .SetOnInsert(x => x._id, ObjectId.GenerateNewId())
                .Set(x => x.PlayerId, playerId)
                .Set(x => x.ClanId, membership.ClanId);
           update = chat
                ? update.Set(x => x.LastReadChatTimestamp, latest)
                : update.Set(x => x.LastReadLogTimestamp, latest);

            ReadStates.UpdateOne(x => x.PlayerId == playerId, update, new UpdateOptions { IsUpsert = true });
            SendRawV2(id, Array.Empty<byte>());
        }

        private void GetUnreadCount(string id, bool chat)
        {
            string playerId = TryGetPlayerId();
            if (string.IsNullOrWhiteSpace(playerId))
            {
                SendUnread(id, 0);
                return;
             }

            ClanRemoteService.ClanMemberDoc membership =
                Members.Find(x => x.PlayerId == playerId).FirstOrDefault();

            if (membership == null)
            {
                SendUnread(id, 0);
                return;
            }

            ClanReadStateDoc state = ReadStates.Find(x => x.PlayerId == playerId).FirstOrDefault();
            long after = 0;
           if (state != null && state.ClanId == membership.ClanId)
                after = chat ? state.LastReadChatTimestamp : state.LastReadLogTimestamp;

            int type = chat ? (int)MessageType.ChatMessage : (int)MessageType.LogMessage;
            FilterDefinition<ClanMessageDoc> filter = Builders<ClanMessageDoc>.Filter.Eq(x => x.ClanId, membership.ClanId) &
                                                      Builders<ClanMessageDoc>.Filter.Eq(x => x.MessageType, type) &
                                                       Builders<ClanMessageDoc>.Filter.Gt(x => x.Timestamp, after);
            if (chat)
                filter &= Builders<ClanMessageDoc>.Filter.Ne(x => x.SenderId, playerId);
            int count = (int)Messages.CountDocuments(filter);
            SendUnread(id, count);
        }

       private void SendUnread(string id, int count)
        {
           SendRawV2(id, ContractWire.Build(w => w.Int32(1, Math.Max(0, count))));
        }

        private void MarkRead(string playerId, string clanId, bool chat, long timestamp)
        {
            UpdateDefinition<ClanReadStateDoc> update = Builders<ClanReadStateDoc>.Update
                .SetOnInsert(x => x._id, ObjectId.GenerateNewId())
                .Set(x => x.PlayerId, playerId)
                .Set(x => x.ClanId, clanId);
            update = chat
                ? update.Max(x => x.LastReadChatTimestamp, timestamp)
                : update.Max(x => x.LastReadLogTimestamp, timestamp);
            ReadStates.UpdateOne(x => x.PlayerId == playerId, update, new UpdateOptions { IsUpsert = true });
        }

        private static byte[] SerializeMessage(ClanMessageDoc doc)
       {
            return ContractWire.Build(w =>
            {
               w.String(1, doc?.Id ?? string.Empty);
                w.Varint(2, doc?.Timestamp ?? 0L);
                int type = doc?.MessageType == (int)MessageType.LogMessage
                    ? (int)MessageType.LogMessage
                    : (int)MessageType.ChatMessage;
                w.Int32(3, type, true);
                if (type == (int)MessageType.ChatMessage)
                {
                    w.Message(4, ContractWire.Build(chat =>
                    {
                         chat.String(1, doc?.SenderId ?? string.Empty);
                        chat.String(2, doc?.Message ?? string.Empty);
                    }));
                }
                else
                {
                    w.Message(6, ContractWire.Build(log =>
                    {
                        log.Int32(1, doc?.ClanLogType ?? 0, true);
                        log.Int32(2, doc?.ChangedClanType ?? 0, true);
                        log.String(3, doc?.ChangedClanName ?? string.Empty);
                        log.String(4, doc?.ChangedClanTag ?? string.Empty);
                        log.String(5, doc?.PrimaryPlayerId ?? string.Empty);
                        log.String(6, doc?.SecondaryPlayerId ?? string.Empty);
                        log.Int32(7, doc?.ChangedMaxMemberCount ?? 0, true);
                        log.Int32(8, doc?.AssignedRole ?? 0, true);
                    }));
                }
            });
        }

        private void EnsureEvents()
        {
            string playerId = TryGetPlayerId();
             if (string.IsNullOrWhiteSpace(playerId)) return;
            ServerState.EnsureConnectionEventSender(
                playerId,
                 _session.TcpClient,
                () => new ClanMessagesRemoteEventSender(_session));
        }

        private static bool Push(string playerId, string eventName, params object[] args)
       {
            return SocialEventDelivery.Send<ClanMessagesRemoteEventSender>(
                playerId,
                "clan-chat",
                eventName,
                 args ?? Array.Empty<object>()) > 0;
        }

        private ClanRemoteService.ClanMemberDoc Membership(string playerId)
        {
            return Members.Find(x => x.PlayerId == playerId).FirstOrDefault()
                  ?? throw new ClanMessageException(ClanRemoteService.ErrorCodes.NotClanMember, "player not in clan");
        }

        private string TryGetPlayerId() =>
            ServerState.Users.TryGetValue(_session.TcpClient, out string id) ? id : null;

        private string GetPlayerId() =>
            TryGetPlayerId() ?? throw new ClanMessageException(401, "not authenticated");

        private static T Read<T>(BinaryValue[] args, int index, T fallback = default(T))
        {
            if (args == null || index < 0 || index >= args.Length || args[index] == null || args[index].IsNull)
                return fallback;
            try
           {
                object value = new RpcValueReader(typeof(T)).FromBytes(args[index]);
                return value == null ? fallback : (T)value;
             }
            catch { return fallback; }
        }

        private void Send<T>(string id, T value)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Return = value == null
                        ? new BinaryValue { IsNull = true }
                        : RpcTypeCodec.CreateToByteMethod(typeof(T)).ToBytes(value)
                }
            });
        }

        private void SendOk(string id)
        {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse { Id = id, Return = new BinaryValue { IsNull = true } }
            });
        }

        private void SendException(string id, int code)
       {
            _session.SendResponse(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = id,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private static int Clamp(int value, int min, int max) => Math.Max(min, Math.Min(max, value));

        private sealed class ClanMessageException : System.Exception
        {
            public int Code { get; }
            public ClanMessageException(int code, string message) : base(message) { Code = code; }
        }

       [BsonIgnoreExtraElements]
        private sealed class ClanMessageDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("id")] public string Id { get; set; }
           [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("timestamp")] public long Timestamp { get; set; }
            [BsonElement("messageType")] public int MessageType { get; set; }
            [BsonElement("senderId")] public string SenderId { get; set; }
            [BsonElement("message")] public string Message { get; set; }
            [BsonElement("clanLogType")] public int ClanLogType { get; set; }
            [BsonElement("primaryPlayerId")] public string PrimaryPlayerId { get; set; }
            [BsonElement("secondaryPlayerId")] public string SecondaryPlayerId { get; set; }
            [BsonElement("changedClanType")] public int ChangedClanType { get; set; }
            [BsonElement("changedClanName")] public string ChangedClanName { get; set; }
            [BsonElement("changedClanTag")] public string ChangedClanTag { get; set; }
            [BsonElement("changedMaxMemberCount")] public int ChangedMaxMemberCount { get; set; }
            [BsonElement("assignedRole")] public int AssignedRole { get; set; }
       }

        [BsonIgnoreExtraElements]
        private sealed class ClanReadStateDoc
        {
            [BsonId] public ObjectId _id { get; set; }
            [BsonElement("playerId")] public string PlayerId { get; set; }
            [BsonElement("clanId")] public string ClanId { get; set; }
            [BsonElement("lastReadChatTimestamp")] public long LastReadChatTimestamp { get; set; }
            [BsonElement("lastReadLogTimestamp")] public long LastReadLogTimestamp { get; set; }
        }
    }

    public sealed class ClanMessagesRemoteEventSender : IEventSender
    {
        private readonly ClientSession _session;
        public string eventListenerName { get; set; } = "ClanMessagesRemoteEventListener";

        public ClanMessagesRemoteEventSender(ClientSession user) { _session = user; }

        public void SendEvent(string eventName, object[] parameters)
        {
             EventResponse evt = BoltEventContract.Create(
                eventListenerName, eventName, parameters ?? Array.Empty<object>());
           _session.SendResponse(new ResponseMessage { EventResponse = evt });
       }
    }
}
