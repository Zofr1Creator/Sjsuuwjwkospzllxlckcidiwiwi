using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB;

namespace TspServer.RpcServer.Api
{
    internal static class ConnectionGate
    {
        private const int AdmissionWindowSeconds = 10;
        private const int IdleEntryLifetimeSeconds = 300;
        private const int CleanupThreshold = 8_192;

        private sealed class ClientWindow
         {
            public long WindowStartedAt;
            public long LastSeenAt;
            public int NewConnections;
            public int ActiveConnections;
        }

        private static readonly ConcurrentDictionary<string, ClientWindow> Clients =
            new(StringComparer.Ordinal);

        private static readonly object GlobalWindowLock = new();
        private static long _globalWindowStartedAt;
        private static int _globalNewConnections;

        public static int MaxBoltActive => ReadInt("BOLT_MAX_ACTIVE_CONNECTIONS", 512, 32, 10_000);
        public static int MaxManifestActive => ReadInt("BOLT_MANIFEST_MAX_ACTIVE", 128, 8, 4_096);
        public static int MaxPerIpActive => ReadInt("BOLT_MAX_ACTIVE_PER_IP", 24, 2, 512);
        public static int MaxNewPerIpPer10s => ReadInt("BOLT_MAX_NEW_PER_IP_10S", 80, 10, 5_000);
       public static int MaxNewGlobalPer10s => ReadInt("BOLT_MAX_NEW_GLOBAL_10S", 2_000, 100, 100_000);

        public static bool TryEnter(string ip, int globalActive, int globalMax, out string reason)
        {
            reason = string.Empty;

            if (globalActive >= globalMax)
            {
                reason = "global-cap";
                return false;
            }

            ip = ClientKey(ip);
             long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            ClientWindow client = Clients.GetOrAdd(
                 ip,
               _ => new ClientWindow
                {
                   WindowStartedAt = now,
                   LastSeenAt = now
                });

            lock (client)
            {
               ResetWindow(client, now);
                client.LastSeenAt = now;

                if (client.ActiveConnections >= MaxPerIpActive)
                {
                    reason = "per-ip-active";
                    return false;
                 }

                if (client.NewConnections >= MaxNewPerIpPer10s)
                {
                    reason = "per-ip-rate";
                    return false;
                }
                if (!TakeGlobalSlot(now))
                {
                   reason = "global-rate";
                    return false;
                }

                client.ActiveConnections++;
                client.NewConnections++;
            }

            if (Clients.Count > CleanupThreshold)
                Cleanup(now);

            return true;
       }

        public static void Leave(string ip)
        {
            ip = ClientKey(ip);
            if (!Clients.TryGetValue(ip, out ClientWindow? client))
                return;

            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            lock (client)
            {
                if (client.ActiveConnections > 0)
                    client.ActiveConnections--;

               client.LastSeenAt = now;
            }

            if (Clients.Count > CleanupThreshold)
                Cleanup(now);
         }

        private static bool TakeGlobalSlot(long now)
        {
            lock (GlobalWindowLock)
            {
                if (now - _globalWindowStartedAt >= AdmissionWindowSeconds)
                {
                    _globalWindowStartedAt = now;
                     _globalNewConnections = 0;
                }

                if (_globalNewConnections >= MaxNewGlobalPer10s)
                    return false;

                _globalNewConnections++;
                 return true;
            }
        }

        private static void ResetWindow(ClientWindow client, long now)
        {
            if (now - client.WindowStartedAt < AdmissionWindowSeconds)
                return;

            client.WindowStartedAt = now;
            client.NewConnections = 0;
        }

        private static void Cleanup(long now)
        {
            long cutoff = now - IdleEntryLifetimeSeconds;

            foreach (KeyValuePair<string, ClientWindow> entry in Clients)
            {
                ClientWindow client = entry.Value;
                lock (client)
                {
                    if (client.ActiveConnections == 0 && client.LastSeenAt < cutoff)
                        Clients.TryRemove(entry.Key, out _);
                }
            }
        }

        private static string ClientKey(string ip) =>
            string.IsNullOrWhiteSpace(ip) ? "unknown" : ip;

        private static int ReadInt(string key, int fallback, int min, int max)
        {
            return int.TryParse(Environment.GetEnvironmentVariable(key), out int value)
                ? Math.Clamp(value, min, max)
                : fallback;
        }
    }

    internal static class LiveBanReconciler
    {
        private static readonly ConcurrentDictionary<string, string> LastDeliveredBan =
            new(StringComparer.Ordinal);

        private static int _started;

        public static void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
               return;

            _ = Task.Run(Loop);
        }

         private static async Task Loop()
       {
            while (true)
            {
                try
                {
                    Sync();
               }
                catch (System.Exception)
                {
                }

                await Task.Delay(TimeSpan.FromSeconds(2)).ConfigureAwait(false);
            }
        }

       private static void Sync()
        {
            List<string> playerIds = ConnectedPlayers();
            if (playerIds.Count == 0)
                return;

            ObjectId[] objectIds = playerIds
                .Where(id => ObjectId.TryParse(id, out _))
                .Select(ObjectId.Parse)
                .ToArray();

            if (objectIds.Length == 0)
                return;

            IMongoCollection<BsonDocument> players =
                BoltMainDatabaseProvider.Instance.GetDatabase()
                    .GetCollection<BsonDocument>("players");

            List<BsonDocument> documents = players
                .Find(Builders<BsonDocument>.Filter.In("_id", objectIds))
                .ToList();
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            foreach (BsonDocument document in documents)
                SyncPlayer(document, now);

           foreach (string stalePlayerId in LastDeliveredBan.Keys.Except(playerIds).ToArray())
                LastDeliveredBan.TryRemove(stalePlayerId, out _);
        }

        private static List<string> ConnectedPlayers()
        {
            lock (ServerState.UsersLock)
            {
                return ServerState.Users.Values
                    .Where(id => !string.IsNullOrWhiteSpace(id))
                    .Distinct(StringComparer.Ordinal)
                    .ToList();
             }
        }

        private static void SyncPlayer(BsonDocument document, long now)
        {
             string playerId = document.GetValue("_id", BsonNull.Value).ToString();
            if (!ObjectId.TryParse(playerId, out ObjectId objectId))
                return;

            bool isBanned = document.GetValue("isBanned", false).ToBoolean();
            long bannedUntil = ReadLong(document, "bannedUntil");

            if (isBanned && bannedUntil > 0 && bannedUntil <= now)
            {
                BoltMainDatabaseProvider.Instance.ClearPlayerBan(objectId, "live-expired");
                LastDeliveredBan.TryRemove(playerId, out _);
                return;
           }

            if (!isBanned)
            {
                LastDeliveredBan.TryRemove(playerId, out _);
                return;
            }

            int code = Math.Max(1, ReadInt(document, "banCode", 1));
            string reason = document.GetValue("banReason", "Account banned").ToString();
            string source = document.GetValue("banSource", "mongo-live").ToString();
            string fingerprint =
                $"{code}|{bannedUntil}|{reason}|{source}|{document.GetValue("banUpdatedAt", BsonNull.Value)}";

            if (LastDeliveredBan.TryGetValue(playerId, out string? last) && last == fingerprint)
                return;

            LastDeliveredBan[playerId] = fingerprint;
            PlayerSanctionService.NotifyPersistedBan(
                playerId,
                code,
                reason,
                bannedUntil,
                "mongo-reconcile:" + source);
        }

        private static int ReadInt(BsonDocument document, string key, int fallback)
        {
            try
            {
                return document.TryGetValue(key, out BsonValue? value) && value.IsNumeric
                    ? value.ToInt32()
                    : fallback;
            }
            catch
             {
                return fallback;
            }
        }

        private static long ReadLong(BsonDocument document, string key)
        {
            try
            {
                return document.TryGetValue(key, out BsonValue? value) && value.IsNumeric
                    ? value.ToInt64()
                     : 0;
            }
            catch
            {
                return 0;
            }
        }
    }

    internal static class CommerceAdminServer
   {
        private const int MaxRequestBytes = 64 * 1024;
        private const int MaxConcurrentRequests = 32;

        private static readonly SemaphoreSlim RequestSlots =
            new(MaxConcurrentRequests, MaxConcurrentRequests);

        private static HttpListener? _listener;
         private static int _started;

        private static int Port
        {
            get
            {
               return int.TryParse(
                    Environment.GetEnvironmentVariable("BOLT_COMMERCE_PORT"),
                    out int value)
                   ? Math.Clamp(value, 1_024, 65_535)
                    : 2_236;
            }
        }

       public static void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;

            string adminKey =
               Environment.GetEnvironmentVariable("BOLT_COMMERCE_ADMIN_KEY") ?? string.Empty;

            if (adminKey.Length < 24)
            {
                return;
            }

            var listener = new HttpListener();
           listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
            listener.Start();

             _listener = listener;
            _ = Task.Run(() => Listen(listener, adminKey));

        }

        private static async Task Listen(HttpListener listener, string adminKey)
        {
            while (listener.IsListening)
            {
                HttpListenerContext? context = null;

                try
                {
                    context = await listener.GetContextAsync().ConfigureAwait(false);

                    if (!await RequestSlots.WaitAsync(0).ConfigureAwait(false))
                    {
                        await WriteJson(context, 503, new { ok = false, error = "busy" })
                            .ConfigureAwait(false);
                        continue;
                    }

                    HttpListenerContext accepted = context;
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            await Handle(accepted, adminKey).ConfigureAwait(false);
                        }
                        finally
                        {
                            RequestSlots.Release();
                        }
                    });
                }
                catch (System.Exception)
                {
                    if (listener.IsListening)

                    try
                    {
                        context?.Response.Close();
                    }
                    catch
                    {
                    }
                }
            }
        }

        private static async Task Handle(
            HttpListenerContext context,
            string adminKey)
        {
            try
            {
                string suppliedKey = context.Request.Headers["X-Admin-Key"] ?? string.Empty;
                if (!SameKey(suppliedKey, adminKey))
                {
                   await WriteJson(context, 401, new { ok = false, error = "unauthorized" });
                    return;
                 }

                string path = context.Request.Url?.AbsolutePath?.TrimEnd('/') ?? string.Empty;

                if (context.Request.HttpMethod == "GET" && path == "/health")
                {
                    await WriteJson(context, 200, new { ok = true, service = "commerce" });
                    return;
                }

                if (context.Request.HttpMethod != "POST")
                {
                    await WriteJson(context, 405, new { ok = false, error = "method" });
                    return;
                }

                string idempotencyKey =
                    (context.Request.Headers["X-Idempotency-Key"] ?? string.Empty).Trim();

                if (idempotencyKey.Length is < 8 or > 128)
                {
                    await WriteJson(
                       context,
                        400,
                        new { ok = false, error = "idempotency_required" });
                    return;
                }
                 if (context.Request.ContentLength64 > MaxRequestBytes)
                {
                    await WriteJson(
                        context,
                        413,
                        new { ok = false, error = "payload_too_large" });
                    return;
                }

                string body = await ReadBody(context.Request).ConfigureAwait(false);
                if (body.Length > MaxRequestBytes)
                {
                    await WriteJson(
                        context,
                        413,
                        new { ok = false, error = "payload_too_large" });
                    return;
                }

                using JsonDocument document = JsonDocument.Parse(
                    string.IsNullOrWhiteSpace(body) ? "{}" : body);

                JsonElement payload = document.RootElement;
               string playerId = ReadString(payload, "playerId");

                if (!ObjectId.TryParse(playerId, out _))
                {
                    await WriteJson(context, 400, new { ok = false, error = "playerId" });
                    return;
                }

                string requestHash = Sha256(path + "\n" + body);
                ClaimResult claim = Claim(
                    idempotencyKey,
                    path,
                    playerId,
                    body,
                    requestHash);

                 if (claim.State == "applied")
                {
                    await WriteJson(
                        context,
                        200,
                        new
                        {
                            ok = true,
                             idempotencyKey,
                            replayed = true,
                            resultJson = claim.ResultJson
                       });
                    return;
                }

                if (claim.State != "new")
                {
                    await WriteJson(
                        context,
                        409,
                         new { ok = false, error = claim.State, idempotencyKey });
                    return;
                }

                await Execute(
                    context,
                    path,
                   payload,
                     playerId,
                    idempotencyKey).ConfigureAwait(false);
            }
            catch
           {
                await WriteJson(context, 500, new { ok = false, error = "internal" });
            }
        }

        private static async Task Execute(
            HttpListenerContext context,
            string path,
            JsonElement payload,
            string playerId,
            string idempotencyKey)
         {
           try
            {
                object result = path switch
                {
                    "/v1/grant/currency" => GrantCurrency(
                        playerId,
                        ReadInt(payload, "currencyId"),
                        ReadInt(payload, "amount"),
                        "commerce-api"),

                    "/v1/grant/item" => GrantItem(
                        playerId,
                         ReadInt(payload, "itemDefinitionId"),
                        Math.Max(1, ReadInt(payload, "quantity", 1)),
                        "commerce-api"),

                    "/v1/purchase/product" => GrantProduct(
                        playerId,
                        ReadString(payload, "sku"),
                         "commerce-product"),

                    "/v1/battlepass/goldpass" => GrantPass(playerId, "commerce-api"),

                   "/v1/battlepass/levels" => AddLevels(
                        playerId,
                        ReadInt(payload, "levels", 1),
                        "commerce-api"),

                    "/v1/ban" => Ban(
                        playerId,
                        ReadInt(payload, "code", 1),
                        ReadString(payload, "reason", "Account banned"),
                         ReadLong(payload, "until", 0)),

                    "/v1/unban" => Unban(playerId),
                    _ => throw new InvalidOperationException("unknown endpoint")
                };

                string resultJson = JsonSerializer.Serialize(result);
                CompleteClaim(idempotencyKey, resultJson);

                await WriteJson(
                    context,
                    200,
                    new { ok = true, idempotencyKey, replayed = false, result });
            }
            catch (System.Exception ex)
            {
                FailClaim(idempotencyKey, ex.Message);
               await WriteJson(
                    context,
                     400,
                    new { ok = false, error = ex.Message, idempotencyKey });
            }
        }

        private static object GrantCurrency(
            string playerId,
            int currencyId,
            int amount,
            string source)
        {
            if (currencyId <= 0 || amount <= 0 || amount > 100_000_000)
                throw new ArgumentOutOfRangeException(nameof(amount));

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                var rewardInfo = new RewardInfo();
                rewardInfo.Currencies.Add(
                   new CurrencyAmount
                    {
                        CurrencyId = currencyId,
                        Value = amount
                    });

                Reward reward = BattlePassRuntime.GrantRewardInfo(playerId, rewardInfo);
                InventoryEventBus.InventoryChanged(
                    playerId,
                    currencies: reward.Currencies,
                    source: source);

               return new { playerId, currencyId, amount };
            }
        }

        private static object GrantItem(
            string playerId,
            int itemDefinitionId,
            int quantity,
           string source)
       {
            if (itemDefinitionId <= 0 || quantity <= 0 || quantity > 1_000)
                throw new ArgumentOutOfRangeException(nameof(itemDefinitionId));

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                var rewardInfo = new RewardInfo();
                rewardInfo.Items.Add(
                    new InventoryItemAmount
                    {
                        InventoryItemDefinitionId = itemDefinitionId,
                        Value = quantity
                    });

                Reward reward = BattlePassRuntime.GrantRewardInfo(playerId, rewardInfo);
                 InventoryEventBus.InventoryChanged(
                    playerId,
                    added: reward.Items,
                    source: source);

                return new { playerId, itemDefinitionId, quantity };
            }
        }
        private static object GrantProduct(
            string playerId,
            string sku,
            string source)
        {
            sku = (sku ?? string.Empty).Trim();
            if (sku.Length is < 2 or > 80)
                throw new ArgumentException("Invalid product SKU.", nameof(sku));

           IMongoCollection<BsonDocument> products =
                BoltMainDatabaseProvider.Instance.GetDatabase()
                    .GetCollection<BsonDocument>("commerce_products");

            BsonDocument? product = products
                .Find(Builders<BsonDocument>.Filter.Eq("_id", sku))
                .FirstOrDefault();

            if (product == null || !product.GetValue("enabled", false).ToBoolean())
                throw new InvalidOperationException("product_not_found_or_disabled");

            string kind = product.GetValue("kind", string.Empty).ToString();
            object grant = kind switch
           {
                "currency" => GrantCurrency(
                    playerId,
                    BsonInt(product, "currencyId"),
                    BsonInt(product, "amount"),
                    source + ":" + sku),

               "item" => GrantItem(
                    playerId,
                    BsonInt(product, "itemDefinitionId"),
                    Math.Max(1, BsonInt(product, "quantity", 1)),
                    source + ":" + sku),

                "goldpass" => GrantPass(playerId, source + ":" + sku),

                "bp_levels" => AddLevels(
                    playerId,
                    Math.Max(1, BsonInt(product, "levels", 1)),
                    source + ":" + sku),

                _ => throw new InvalidOperationException("unsupported_product_kind")
            };

            return new { playerId, sku, kind, grant };
        }

        private static object GrantPass(string playerId, string source)
        {
            int itemDefinitionId = BattlePassRuntime.FallbackGoldPassItemDefinitionId;

           if (BattlePassRuntime.OwnsInventoryDefinition(playerId, itemDefinitionId))
            {
                GameEventRemoteService.BroadcastStateChanged(playerId, new Reward());
                return new
                {
                    playerId,
                    itemDefinitionId,
                    quantity = 0,
                    alreadyOwned = true
                };
            }

            object result = GrantItem(playerId, itemDefinitionId, 1, source);
            GameEventRemoteService.BroadcastStateChanged(playerId, new Reward());
            return result;
        }

        private static object AddLevels(string playerId, int levels, string source)
        {
            levels = Math.Clamp(levels, 1, 100);

            lock (BattlePassRuntime.LockForPlayer(playerId))
            {
                BattlePassDefinition definition = BattlePassRuntime.GetDefinition();
                BattlePassPlayerStateDocument state =
                    BattlePassRuntime.GetState(playerId, definition);

                int before = state.Points;
               BattlePassRuntime.AddEventPoints(state, checked(levels * 1_000));
                BattlePassRuntime.UpdateLevelsOnly(state, definition);
                BattlePassRuntime.SaveState(state);
                GameEventRemoteService.BroadcastStateChanged(playerId, new Reward());

                return new
                {
                    playerId,
                    levels,
                    before,
                    after = state.Points,
                    source
                };
             }
       }

        private static object Ban(string playerId, int code, string reason, long until)
        {
            if (!ObjectId.TryParse(playerId, out _))
                throw new ArgumentException("Invalid player id.", nameof(playerId));

            int delivered = PlayerSanctionService.Ban(
                playerId,
                code,
                reason,
                until,
                "commerce-api");

            return new { playerId, code, until, delivered };
        }

        private static object Unban(string playerId)
        {
            if (!ObjectId.TryParse(playerId, out ObjectId objectId))
                throw new ArgumentException("Invalid player id.", nameof(playerId));

            BoltMainDatabaseProvider.Instance.ClearPlayerBan(
                 objectId,
                "commerce-api-unban");

            return new { playerId, unbanned = true };
        }

        private sealed class ClaimResult
        {
           public string State { get; init; } = "new";
            public string ResultJson { get; init; } = string.Empty;
        }

        private static ClaimResult Claim(
           string id,
            string operation,
            string playerId,
            string body,
            string requestHash)
        {
            IMongoCollection<BsonDocument> ledger = Ledger();

            try
             {
                ledger.InsertOne(
                     new BsonDocument
                    {
                        ["_id"] = id,
                        ["state"] = "pending",
                        ["operation"] = operation,
                        ["playerId"] = playerId,
                        ["requestHash"] = requestHash,
                        ["request"] = body.Length > 4_096 ? body[..4_096] : body,
                        ["createdAt"] = DateTime.UtcNow
                    });

                return new ClaimResult();
            }
            catch (MongoWriteException ex)
                when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
                BsonDocument? existing = ledger
                    .Find(Builders<BsonDocument>.Filter.Eq("_id", id))
                    .FirstOrDefault();

                if (existing == null)
                    return new ClaimResult { State = "duplicate_unknown" };

                string existingHash =
                    existing.GetValue("requestHash", string.Empty).ToString();

                if (!string.Equals(
                       existingHash,
                        requestHash,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return new ClaimResult { State = "idempotency_key_reused" };
                }

                string state = existing.GetValue("state", "pending").ToString();
                if (state == "applied")
                {
                     return new ClaimResult
                    {
                        State = "applied",
                        ResultJson = existing.GetValue("resultJson", string.Empty).ToString()
                    };
                }

                return new ClaimResult
                {
                   State = state == "failed" ? "previous_attempt_failed" : "pending"
                };
            }
         }

         private static void CompleteClaim(string id, string resultJson)
        {
            Ledger().UpdateOne(
                Builders<BsonDocument>.Filter.Eq("_id", id),
                Builders<BsonDocument>.Update
                    .Set("state", "applied")
                    .Set("completedAt", DateTime.UtcNow)
                    .Set("resultJson", resultJson ?? string.Empty));
        }

        private static void FailClaim(string id, string error)
        {
            Ledger().UpdateOne(
                Builders<BsonDocument>.Filter.Eq("_id", id),
                 Builders<BsonDocument>.Update
                    .Set("state", "failed")
                    .Set("error", error ?? string.Empty)
                     .Set("completedAt", DateTime.UtcNow));
       }

        private static IMongoCollection<BsonDocument> Ledger() =>
            BoltMainDatabaseProvider.Instance.GetDatabase()
                .GetCollection<BsonDocument>("commerce_ledger");

        private static async Task<string> ReadBody(HttpListenerRequest request)
        {
            using var reader = new StreamReader(
                request.InputStream,
                request.ContentEncoding ?? Encoding.UTF8);

             return await reader.ReadToEndAsync().ConfigureAwait(false);
        }

        private static async Task WriteJson(
            HttpListenerContext context,
            int statusCode,
           object payload)
        {
            byte[] body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload));
            context.Response.StatusCode = statusCode;
             context.Response.ContentType = "application/json";
            context.Response.ContentEncoding = Encoding.UTF8;
           context.Response.ContentLength64 = body.Length;

            await context.Response.OutputStream.WriteAsync(body).ConfigureAwait(false);
            context.Response.Close();
        }

        private static bool SameKey(string supplied, string expected)
        {
            byte[] suppliedHash = SHA256.HashData(
                Encoding.UTF8.GetBytes(supplied ?? string.Empty));
            byte[] expectedHash = SHA256.HashData(
                Encoding.UTF8.GetBytes(expected ?? string.Empty));

            return CryptographicOperations.FixedTimeEquals(suppliedHash, expectedHash);
        }

        private static string Sha256(string value)
         {
            byte[] hash = SHA256.HashData(
                Encoding.UTF8.GetBytes(value ?? string.Empty));
            return Convert.ToHexString(hash).ToLowerInvariant();
        }

        private static int BsonInt(
            BsonDocument document,
            string key,
            int fallback = 0)
        {
            try
            {
                 return document.TryGetValue(key, out BsonValue? value) && value.IsNumeric
                    ? value.ToInt32()
                    : fallback;
            }
            catch
            {
                return fallback;
            }
       }

        private static string ReadString(
            JsonElement document,
            string key,
            string fallback = "")
        {
            return document.TryGetProperty(key, out JsonElement value) &&
                  value.ValueKind == JsonValueKind.String
                ? value.GetString() ?? fallback
                : fallback;
       }

        private static int ReadInt(
            JsonElement document,
            string key,
            int fallback = 0)
        {
            return document.TryGetProperty(key, out JsonElement value) &&
                   value.TryGetInt32(out int number)
                ? number
                : fallback;
        }

        private static long ReadLong(
            JsonElement document,
            string key,
             long fallback = 0)
       {
            return document.TryGetProperty(key, out JsonElement value) &&
                   value.TryGetInt64(out long number)
                ? number
                : fallback;
        }
    }
}
