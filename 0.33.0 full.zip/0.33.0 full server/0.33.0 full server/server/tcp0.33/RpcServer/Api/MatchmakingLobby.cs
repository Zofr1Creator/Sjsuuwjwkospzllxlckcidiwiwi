using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{

    public partial class MatchmakingRemoteService
     {
        private static bool TryFindLobby(string playerId, byte[] raw, out BoltLobby lobby)
        {
            lobby = null;
            string lobbyId = ContractWire.ReadStringField(raw, 1, string.Empty);
             if (string.IsNullOrWhiteSpace(lobbyId))
               lobbyId = ServerState.GetOrCreatePlayerStatus(playerId).playInGame?.lobbyId ?? string.Empty;
            return !string.IsNullOrWhiteSpace(lobbyId) && TryResolveLiveLobby(lobbyId, out lobby);
        }

        private static GameServerDetails BuildServerDetails(BoltLobby lobby)
        {
            var details = new GameServerDetails
            {
                Id = lobby?.GameServer?.Id ?? string.Empty,
                Map = lobby != null && lobby.Data.TryGetValue("map", out string map) ? map ?? string.Empty : string.Empty,
                CurrentPlayers = (lobby?.LobbyMembers?.Length ?? 0) + (lobby?.LobbySpectators?.Length ?? 0),
                 MaxPlayers = (lobby?.MaxMembers ?? 0) + (lobby?.MaxSpectators ?? 0),
                BotPlayers = 0,
                RequirePassword = false,
                Version = "0.33.0",
                SuccessfulResponse = lobby?.GameServer != null,
                DoNotRefresh = lobby?.GameServer == null
            };
            if (lobby?.GameServer != null) details.GameServer = lobby.GameServer.Clone();
             return details;
        }
        private void GetLobbyGameServer(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                 return;
            }
            if (!TryFindLobby(playerId, ContractWire.Param(request), out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            var response = new GetLobbyGameServerResponse { GameServerDetails = BuildServerDetails(lobby) };
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

        private void GetGameServerDetails(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string serverId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            BoltLobby lobby = ServerState.Lobbies.Values.FirstOrDefault(x =>
                x?.GameServer != null && string.Equals(x.GameServer.Id, serverId, StringComparison.Ordinal));
            var response = new GetGameServerDetailsResponse
            {
                GameServerDetails = BuildServerDetails(lobby)
            };
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

        private void SetLobbyName(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            string name = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (name.Length == 0 || name.Length > 48)
            {
                ContractWire.SendException(_session, request.Id, 400);
                return;
            }
            lobby.Name = name;
            PersistLobby(lobby);
           ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyNameChanged", name);
        }

        private void SetLobbyGameServer(RpcRequest request)
       {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            string serverId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Trim();
            if (serverId.Length == 0)
            {
                lobby.GameServer = null;
             }
            else
            {
                lobby.GameServer = new GameServer
                {
                    Id = serverId,
                    Ip = ResolvePhotonHost(),
                    Port = 5055
                };
             }
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyGameServerChanged", lobby.GameServer ?? new GameServer());
        }

        private void DeleteLobbyData(RpcRequest request)
         {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                 ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryGetOwnedLobby(playerId, request.Id, out BoltLobby lobby)) return;
            List<string> keys = ContractWire.ReadRepeatedStringField(ContractWire.Param(request), 1);
            var updated = new Dictionary<string, string>(lobby.Data, StringComparer.Ordinal);
            foreach (string key in keys)
                if (!BoltLobby.IsRequiredLobbyKey(key)) updated.Remove(key);
            lobby.Data = BoltLobby.NormalizeLobbyData(updated);
             PersistLobby(lobby);
            var exact = new Axlebolt.Bolt.Protobuf2.Dictionary();
            exact.Content.Add(lobby.Data);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyDataChanged", exact);
        }

        private void InvitePlayerToLobbyV2(RpcRequest request)
        {
            InvitePlayerToLobbyAs(request);
        }

        private void GetGameServerPlayers(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            string serverId = ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty);
            BoltLobby lobby = ServerState.Lobbies.Values.FirstOrDefault(x =>
               x?.GameServer != null && string.Equals(x.GameServer.Id, serverId, StringComparison.Ordinal));
            var response = new GetGameServerPlayersResponse();
            if (lobby != null)
           {
                foreach (BoltFriend participant in LobbyAudience(lobby))
                 {
                    PlayerDocument document = participant.GetPlayerDocument();
                    if (document != null) response.Players.Add(FriendHelper.GetPlayer(document));
                }
            }
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

        private void RequestInternetServerList(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            byte[] response = ContractWire.Build(w =>
            {
                foreach (BoltLobby lobby in ServerState.Lobbies.Values.Where(x => x?.GameServer != null))
                    w.Message(1, lobby.GameServer);
            });
            ContractWire.SendRaw(_session, request.Id, response);
        }

        private void ChangeLobbyPlayerType(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                 ContractWire.SendException(_session, request.Id, 401);
                return;
           }
            if (!TryGetCurrentLobby(playerId, request.Id, out BoltLobby lobby)) return;
            LobbyPlayerType type = ContractWire.ReadIntField(ContractWire.Param(request), 1, 0) == (int)LobbyPlayerType.Spectator
                ? LobbyPlayerType.Spectator : LobbyPlayerType.Member;
            if (string.Equals(lobby.LobbyOwnerId, playerId, StringComparison.Ordinal) && type == LobbyPlayerType.Spectator)
            {
                ContractWire.SendException(_session, request.Id, 403);
                 return;
           }
             if (type == LobbyPlayerType.Member && !lobby.IsLobbyMember(playerId) && lobby.LobbyMembers.Length >= lobby.MaxMembers)
            {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }
            if (type == LobbyPlayerType.Spectator && !lobby.IsLobbySpectator(playerId) && lobby.LobbySpectators.Length >= lobby.MaxSpectators)
            {
                ContractWire.SendException(_session, request.Id, 5006);
                return;
            }
            lobby.ChangeMemberType(playerId, type);
            PersistLobby(lobby);
            ContractWire.SendEmpty(_session, request.Id);
            BroadcastLobbyEvent(lobby, "onLobbyPlayerTypeChanged", playerId, (int)type);
        }

        private void JoinLobbyV2(RpcRequest request)
        {
            JoinLobbyAsV2(request);
        }

        private void RequestLobbyList(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
               return;
             }
            BoltLobby[] lobbies = ServerState.Lobbies.Values
                .Where(x => x != null && x.Joinable && x.Type == BoltLobby.LobbyType.Public && x.LobbyMembers.Length < x.MaxMembers)
                .Take(100)
                .ToArray();
            var response = new RequestLobbyListResponse();
            foreach (BoltLobby lobby in lobbies) response.Lobbies.Add(BuildGeneratedLobby(lobby, playerId));
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

       private void GetLobbyMembers(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
               ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryFindLobby(playerId, ContractWire.Param(request), out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            var response = new GetLobbyMembersResponse();
            foreach (BoltFriend participant in LobbyAudience(lobby))
            {
                PlayerDocument document = participant.GetPlayerDocument();
                if (document != null) response.Players.Add(FriendHelper.GetPlayer(document));
            }
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

        private void GetLobbyPhotonGame(RpcRequest request)
        {
           if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryFindLobby(playerId, ContractWire.Param(request), out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                 return;
             }
            var response = new GetLobbyPhotonGameResponse();
            if (lobby.PhotonGame != null) response.PhotonGame = RpcServer.PhotonGame.GetByDocument(lobby.PhotonGame);
            ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }

        private void GetLobbyOwnerV2(RpcRequest request)
        {
            if (!SessionIdentity.TryGetPlayerId(_session, out string playerId))
            {
                ContractWire.SendException(_session, request.Id, 401);
                return;
            }
            if (!TryFindLobby(playerId, ContractWire.Param(request), out BoltLobby lobby))
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            PlayerDocument owner = GetPlayerDocumentOrNull(lobby.LobbyOwnerId);
            if (owner == null)
            {
                ContractWire.SendException(_session, request.Id, 404);
                return;
            }
            var response = new GetLobbyOwnerResponse { Owner = FriendHelper.GetPlayer(owner) };
           ContractWire.SendRaw(_session, request.Id, response.ToByteArray());
        }
   }
}
