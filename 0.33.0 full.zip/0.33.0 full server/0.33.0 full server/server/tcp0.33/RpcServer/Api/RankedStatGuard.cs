using System;
using System.Collections.Generic;

namespace TspServer.RpcServer.Api
{
    internal sealed class RankedQueueStatus
    {
        public RankedModeId Mode;
        public int Mmr = 500;
        public int Rank;
        public long BannedUntil;
        public int BanCode = -1;
        public int LastMatchRunning;
        public int LastMatchStatus;
        public long LastMatchStartTime;
        public string ActiveMatchId = string.Empty;
       public string ActiveRoomId = string.Empty;
        public string ActiveMode = string.Empty;
        public string ActiveMatchStatus = string.Empty;

        public bool IsBanned(long nowUnixSeconds) => BannedUntil > nowUnixSeconds;
     }

    internal static class RankedStatGuard
    {
        private static readonly HashSet<string> ProtectedSuffixes = new HashSet<string>(StringComparer.Ordinal)
        {
            "rank", "current_mmr", "best_rank", "best_rank_history1",
            "played_matches", "won_match_count", "calibration_match_count",
            "calibration_won_match_count", "calibration_status", "client_key_contract",
            "ban_code", "ban_duration", "banned_match_no", "ban_reason", "banned_until",
            "last_match_status", "last_activity_time1", "last_activity_time2",
            "last_match_start_time", "last_match_running"
        };

       public static int ConfirmationSeconds => RankedSettings.For(RankedModeContracts.Ranked5v5).ConfirmationSeconds;
        public static int MmrLowerThreshold => RankedSettings.For(RankedModeContracts.Ranked5v5).MmrLowerThreshold;

        public static bool IsServerOwned(string statName)
        {
            if (string.IsNullOrWhiteSpace(statName)) return false;
            if (statName.StartsWith("ranked_2v2_", StringComparison.Ordinal))
                return ProtectedSuffixes.Contains(statName.Substring("ranked_2v2_".Length));
            if (statName.StartsWith("ranked_duel_", StringComparison.Ordinal))
                 return ProtectedSuffixes.Contains(statName.Substring("ranked_duel_".Length));
            if (statName.StartsWith("ranked_", StringComparison.Ordinal))
                return ProtectedSuffixes.Contains(statName.Substring("ranked_".Length));
            return false;
        }

       public static RankedQueueStatus LoadQueueStatus(string playerId, RankedModeContract mode)
        {
            return RankedAuthorityRepository.Instance.LoadQueueStatus(playerId, mode);
        }

        public static int GetSearchRange(RankedModeContract mode, DateTime queuedUtc, DateTime nowUtc)
        {
            RankedMatchmakingSettings settings = RankedSettings.For(mode);
            int[] ranges = settings.SearchRange ?? Array.Empty<int>();
            if (ranges.Length == 0) return 0;
            int elapsedMs = Math.Max(0, (int)(nowUtc - queuedUtc).TotalMilliseconds);
            int index = Math.Min(ranges.Length - 1, elapsedMs / Math.Max(1, settings.SearchStepDelayMs));
            return ranges[index];
       }

        public static int GetSearchRange(DateTime queuedUtc, DateTime nowUtc) =>
            GetSearchRange(RankedModeContracts.Ranked5v5, queuedUtc, nowUtc);
    }
}
