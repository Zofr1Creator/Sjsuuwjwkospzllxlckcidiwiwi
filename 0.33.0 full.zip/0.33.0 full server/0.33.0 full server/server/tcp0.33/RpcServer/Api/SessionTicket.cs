using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MongoDB.Bson;

namespace TspServer.RpcServer.Api
{

    internal static class SessionTicket
    {
        private const string Prefix = "s2";
        private const int DefaultTtlSeconds = 30 * 24 * 60 * 60;
        private const int MinTtlSeconds = 60 * 60;
       private const int MaxTtlSeconds = 90 * 24 * 60 * 60;
        private static readonly byte[] SigningKey = LoadSigningKey();

        public static int TtlSeconds
        {
            get
            {
                string raw = Environment.GetEnvironmentVariable("BOLT_SESSION_TTL_SECONDS");
               if (!int.TryParse(raw, out int ttl))
                   ttl = DefaultTtlSeconds;
                return Math.Clamp(ttl, MinTtlSeconds, MaxTtlSeconds);
            }
        }

        public static string Issue(ObjectId playerId)
        {
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            long expires = now + TtlSeconds;
            byte[] nonce = RandomNumberGenerator.GetBytes(8);
            string core = $"{Prefix}:{playerId}:{expires:X8}:{Convert.ToHexString(nonce)}";
            byte[] signature = Sign(core);

            string ticket = core + ":" + Convert.ToHexString(signature.AsSpan(0, 16));
           CryptographicOperations.ZeroMemory(nonce);
            CryptographicOperations.ZeroMemory(signature);
            return ticket;
        }

        public static bool TryValidate(string ticket, out ObjectId playerId, out long expiresAt)
        {
            playerId = ObjectId.Empty;
            expiresAt = 0;
            if (string.IsNullOrWhiteSpace(ticket) || ticket.Length > 116)
                return false;

            string[] parts = ticket.Split(':');
            if (parts.Length != 5 || !string.Equals(parts[0], Prefix, StringComparison.Ordinal))
                return false;
            if (!ObjectId.TryParse(parts[1], out playerId))
                return false;
            if (!long.TryParse(parts[2], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out expiresAt))
                return false;
            if (parts[3].Length != 16 || parts[4].Length != 32)
                return false;
            byte[] supplied;
            try { supplied = Convert.FromHexString(parts[4]); }
            catch { return false; }
            string core = $"{parts[0]}:{parts[1]}:{parts[2]}:{parts[3]}";
            byte[] expected = Sign(core);
            bool signatureOk = supplied.Length == 16 &&
                CryptographicOperations.FixedTimeEquals(supplied, expected.AsSpan(0, 16));
            CryptographicOperations.ZeroMemory(supplied);
            CryptographicOperations.ZeroMemory(expected);
            if (!signatureOk)
                return false;

            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            if (expiresAt <= now || expiresAt > now + MaxTtlSeconds + 24 * 60 * 60)
                return false;
            return true;
        }

        private static byte[] Sign(string text)
        {
            using HMACSHA256 hmac = new HMACSHA256(SigningKey);
            return hmac.ComputeHash(Encoding.UTF8.GetBytes(text ?? string.Empty));
        }

        private static byte[] LoadSigningKey()
        {
            string envHex = Environment.GetEnvironmentVariable("BOLT_SESSION_SIGNING_KEY_HEX");
            if (!string.IsNullOrWhiteSpace(envHex))
                 return ParseKey(envHex, "BOLT_SESSION_SIGNING_KEY_HEX");

            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(localAppData))
                localAppData = Environment.CurrentDirectory;
            string dir = Path.Combine(localAppData, "TspServer");
            string path = Path.Combine(dir, "session_signing_key.hex");

            if (File.Exists(path))
                return ParseKey(File.ReadAllText(path), path);

            Directory.CreateDirectory(dir);
            byte[] key = RandomNumberGenerator.GetBytes(32);
            string hex = Convert.ToHexString(key);
            File.WriteAllText(path, hex + Environment.NewLine);
            return key;
        }

        private static byte[] ParseKey(string hex, string source)
        {
            hex = (hex ?? string.Empty).Trim();
            if (hex.Length != 64)
                throw new InvalidOperationException($"{source} must contain exactly 64 hex characters.");
            try { return Convert.FromHexString(hex); }
            catch (FormatException ex)
            {
                throw new InvalidOperationException($"{source} contains non-hex characters.", ex);
           }
        }

    }
}
