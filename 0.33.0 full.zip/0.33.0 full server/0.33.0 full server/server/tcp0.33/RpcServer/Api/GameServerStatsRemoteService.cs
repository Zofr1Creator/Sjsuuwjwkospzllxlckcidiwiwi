using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using TspServer.MongoDB;
using TspServer.MongoDB.Main;

namespace TspServer.RpcServer.Api
{
     public class GameServerStatsRemoteService : RpcHandler
    {
        public GameServerStatsRemoteService(ClientSession user) : base(user)
        {

        }

        protected void StoreStats(BinaryValue[] values, string guid)
        {
            if (ServerState.GameServerUsers.Contains(_session.TcpClient))
            {
                RpcValueReader from = new RpcValueReader(typeof(PlayerStats[]));
               PlayerStats[] storePlayerStats = (PlayerStats[])from.FromBytes(values[0]);
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                if (storePlayerStats.Length > 0) foreach (PlayerStats storePlayerStat in storePlayerStats) boltMain.StoreStat(storePlayerStat);
                _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } }); return;
            }

            _session.SendResponse(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });

         }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "storeStats") StoreStats(request.Params.ToArray(), request.Id);
            else _session.SendResponse(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }
    }
}
