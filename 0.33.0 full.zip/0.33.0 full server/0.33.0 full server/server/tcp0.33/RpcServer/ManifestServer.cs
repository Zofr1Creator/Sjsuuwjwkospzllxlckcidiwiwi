using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using TspServer.RpcServer.Api;

namespace TspServer.RpcServer
{
    internal static class ManifestServer
    {
        private const uint ManifestMagic = 0x334D5652U;

        private const ushort AndroidProtocol = 3;
        private const ushort IosProtocol = 4;

        private const ulong BuildId = 0x03300003UL;

        private const int RequestSize = 64;
        private const int AndroidResponseSize = 192;
        private const int AndroidMacOffset = 160;
        private const int IosResponseSize = 256;

        private const int IosMacOffset = 224;
        private const int TargetSlots = 16;

          private const ulong FeatureMask = 0x0FUL;
         private const ushort AndroidRevision = 0xB314;
        private const ushort IosRevision = 0x4934;

        [Flags]
        private enum IosFlags : ulong
        {
            Bootstrap = 1UL << 0,
            Hooks = 1UL << 1,
            Diagnostics = 1UL << 2,
            DiagnosticFsync = 1UL << 3,
            TlsHook = 1UL << 4,
            BoltHook = 1UL << 5,
            PhotonHook = 1UL << 6,
            Routing = 1UL << 7,
            TlsPinOverride = 1UL << 8,
            StrictPreflight = 1UL << 9,
            DiagnosticStderr = 1UL << 10
        }

        private sealed class IosConfig
        {
            public uint Revision { get; set; } = 1;
            public bool BootstrapEnabled { get; set; } = true;
            public bool HooksEnabled { get; set; } = true;
             public bool DiagnosticsEnabled { get; set; } = true;
            public bool DiagnosticFsync { get; set; } = true;
            public bool DiagnosticStderr { get; set; } = false;
            public bool TlsHookEnabled { get; set; } = true;
            public bool BoltHookEnabled { get; set; } = true;
            public bool PhotonHookEnabled { get; set; } = true;
            public bool RoutingEnabled { get; set; } = true;
            public bool TlsPinOverrideEnabled { get; set; } = true;
            public bool StrictPreflight { get; set; } = true;
            public uint StartupDelayMs { get; set; } = 5000;
            public uint UnityWaitMs { get; set; } = 45000;
            public uint DomainWaitMs { get; set; } = 45000;
            public uint DependencyWaitMs { get; set; } = 45000;
            public uint HookWaitMs { get; set; } = 30000;
            public uint PollMinUs { get; set; } = 1000;
            public uint PollMaxUs { get; set; } = 20000;
            public ushort TlsLogLimit { get; set; } = 24;
            public ushort BoltLogLimit { get; set; } = 32;
            public ushort PhotonLogLimit { get; set; } = 32;
           public uint MaxAssemblyCount { get; set; } = 4096;
            public uint ExpectedRpcClassCount { get; set; } = 179;
        }

        private static int _started;
        private static TcpListener? _listener;
        private static int _activeClients;
        private static ulong _generationId;
        private static byte[] _certificateHash = Array.Empty<byte>();

                private static readonly IReadOnlyDictionary<ushort, uint> _androidTargets =
            new Dictionary<ushort, uint>
            {
                [1] = 0x04CC593CU,
                [2] = 0x03E9A2DCU,
                [3] = 0x05798BACU,
                [4] = 0x05798DE8U,
                [5] = 0x05798F78U,
                [6] = 0x03C49568U,
                [7] = 0x03B827C8U,
                [8] = 0x03B82888U,
                [9] = 0x04FE9080U,
                [10] = 0x0588501CU,
                [11] = 0x04B3FDACU,
                [12] = 0x03DC817CU,
                [13] = 0x048B4E2CU,
                [14] = 0x03B5B584U,
                [15] = 0x05060ED4U,
                [16] = 0x042B0210U
            };

        private static readonly IReadOnlyDictionary<ushort, uint> _iosTargets = new Dictionary<ushort, uint>
         {
            [1]=0x059D1268U,
            [2]=0x059D1200U,
            [3]=0x059D0DB4U,
            [4]=0x059D0DC0U,
            [5]=0x059D0854U,
            [6]=0x059D1514U,
            [7]=0x059D152CU,
            [8]=0x059D08B4U,
            [9]=0x059D08B8U,
            [10]=0x059D08ACU,
            [11]=0x059D08B0U,
            [12]=0x059D1164U,
            [13]=0x059D1174U,
            [14]=0x059D124CU,
            [15]=0x059D10FCU,
            [16]=0x059D1508U
        };

        public static void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0)
                return;
            try
            {
                ValidateTargets(_androidTargets, "android");
                ValidateTargets(_iosTargets, "ios");
               ServerOptions options = ServerOptions.Current;
                byte[] key = LoadKey();
                _certificateHash = LoadCertificateHash(options);
                _generationId = NewRandomId();

                TcpListener listener = new TcpListener(IPAddress.Any, options.ManifestPort);
                listener.Start(512);
                _listener = listener;

                _ = Task.Run(() => AcceptLoop(listener, key));
            }
            catch
            {
                Interlocked.Exchange(ref _started, 0);
                _listener?.Stop();
                _listener = null;
                throw;
            }
        }
        private static async Task AcceptLoop(TcpListener listener, byte[] key)
        {
            while (true)
             {
                TcpClient? client = null;
                try
                {
                    client = await listener.AcceptTcpClientAsync().ConfigureAwait(false);
                    string remoteIp;
                    try
                    {
                        remoteIp = (client.Client.RemoteEndPoint as IPEndPoint)?.Address.ToString() ?? "unknown";
                    }
                    catch
                    {
                       remoteIp = "unknown";
                    }

                    int activeSnapshot = Volatile.Read(ref _activeClients);
                    if (!ConnectionGate.TryEnter(remoteIp, activeSnapshot, ConnectionGate.MaxManifestActive, out _))
                    {
                        try { client.Close(); } catch { }
                        continue;
                    }

                    Interlocked.Increment(ref _activeClients);

                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            await HandleClient(client, key, remoteIp).ConfigureAwait(false);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[manifest] {remoteIp}: {ErrorText(ex)}");
                            try { client.Close(); } catch { }
                        }
                        finally
                        {
                            ConnectionGate.Leave(remoteIp);
                            Interlocked.Decrement(ref _activeClients);
                        }
                     });
                }
                catch (ObjectDisposedException)
                {
                     return;
                }
                catch (SocketException)
                {
                    try { client?.Close(); } catch { }
                    await Task.Delay(100).ConfigureAwait(false);
               }
                catch
                {
                   try { client?.Close(); } catch { }
                     await Task.Delay(100).ConfigureAwait(false);
                }
            }
        }

        private static void ValidateTargets(IReadOnlyDictionary<ushort, uint> targets, string platform)
        {
            if (targets.Count != TargetSlots)
                throw new InvalidOperationException($"bad {platform} target count");

            HashSet<uint> unique = new HashSet<uint>();
            for (ushort slot = 1; slot <= TargetSlots; slot++)
            {
                if (!targets.TryGetValue(slot, out uint rva))
                    throw new InvalidOperationException($"missing {platform} target {slot}");
                if (rva < 0x1000U || rva > 0x0FFFFFFFU)
                    throw new InvalidOperationException($"bad {platform} target {slot}");
                if (!unique.Add(rva))
                     throw new InvalidOperationException($"duplicate {platform} target");
            }
        }

        private static byte[] LoadCertificateHash(ServerOptions options)
        {
            string pfxPath = options.TlsPfxPath;
            if (string.IsNullOrWhiteSpace(pfxPath))
                throw new InvalidOperationException("tls pfx path missing");
            if (!Path.IsPathRooted(pfxPath))
                pfxPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, pfxPath));
            if (!File.Exists(pfxPath))
                throw new FileNotFoundException("tls certificate not found", pfxPath);

            X509KeyStorageFlags flags = OperatingSystem.IsWindows()
                ? X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable
                : X509KeyStorageFlags.DefaultKeySet | X509KeyStorageFlags.Exportable;

            X509Certificate2 cert;
            try
            {
                cert = new X509Certificate2(
                    pfxPath,
                    options.TlsPfxPassword ?? string.Empty,
                    flags);
            }
            catch (CryptographicException) when (OperatingSystem.IsWindows())
            {
                try
                {
                    cert = new X509Certificate2(
                        pfxPath,
                        options.TlsPfxPassword ?? string.Empty,
                        X509KeyStorageFlags.UserKeySet |
                        X509KeyStorageFlags.PersistKeySet |
                        X509KeyStorageFlags.Exportable);
                }
                catch (Exception userKeyError)
                {
                    throw new InvalidOperationException("certificate load failed", userKeyError);
                }
            }

            using (cert)
            {
                if (!cert.HasPrivateKey)
                    throw new InvalidOperationException("private key missing");

                byte[] hash = SHA256.HashData(cert.RawData);
                return hash;
            }
        }

        private static async Task<bool> HandleClient(TcpClient client, byte[] key, string remoteIp)
        {
            using (client)
            {
client.NoDelay = true;
                try { client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true); } catch { }
                NetworkStream stream = client.GetStream();
                byte[] request = new byte[RequestSize];

                if (!await ReadRequest(stream, request).ConfigureAwait(false))
                {
                    Console.WriteLine($"[manifest] {remoteIp} short request");
                    return false;
                }

                uint magic = BinaryPrimitives.ReadUInt32LittleEndian(request.AsSpan(0, 4));
                ushort version = BinaryPrimitives.ReadUInt16LittleEndian(request.AsSpan(4, 2));
                ushort clientRevision = BinaryPrimitives.ReadUInt16LittleEndian(request.AsSpan(6, 2));
                ulong build = BinaryPrimitives.ReadUInt64LittleEndian(request.AsSpan(8, 8));
                ulong clientNonce = BinaryPrimitives.ReadUInt64LittleEndian(request.AsSpan(16, 8));
                ulong clientStamp = BinaryPrimitives.ReadUInt64LittleEndian(request.AsSpan(24, 8));

                bool isIos = version == IosProtocol && clientRevision == IosRevision;
                bool isAndroid = version == AndroidProtocol && clientRevision == AndroidRevision;
               if (magic != ManifestMagic || build != BuildId || clientNonce == 0 || (!isIos && !isAndroid))
                {
                    Console.WriteLine($"[manifest] {remoteIp} unsupported client");
                    return false;
                }
                IReadOnlyDictionary<ushort, uint> targets = isIos ? _iosTargets : _androidTargets;

                byte[] expectedRequestMac = Hmac(key, request.AsSpan(0, 32));
                if (!CryptographicOperations.FixedTimeEquals(expectedRequestMac, request.AsSpan(32, 32)))
                {
                    Console.WriteLine($"[manifest] {remoteIp} bad hmac");
                    return false;
                }

                long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                long skew;
                try { skew = checked((long)clientStamp - now); }
                catch { skew = long.MaxValue; }
                if (skew > 300 || skew < -300)
                {
                    Console.WriteLine($"[manifest] {remoteIp} bad clock");
                    return false;
                }

                ulong serverNonce = NewRandomId();
                int responseSize = isIos ? IosResponseSize : AndroidResponseSize;
                 int authenticatedBytes = isIos ? IosMacOffset : AndroidMacOffset;
                byte[] response = new byte[responseSize];

                BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(0, 4), ManifestMagic);
                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(4, 2), version);
                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(6, 2), 0);
                BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(8, 8), clientNonce);
               BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(16, 8), serverNonce);
                BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(24, 8), _generationId);
                BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(32, 8), (ulong)(now + 1800));
                BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(40, 8), FeatureMask);

                ServerOptions options = ServerOptions.Current;
                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(48, 2), checked((ushort)options.BoltPort));
                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(50, 2), checked((ushort)options.PhotonPort));
                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(52, 2), checked((ushort)TargetSlots));

                BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(54, 2), isIos ? (ushort)0x0003 : (ushort)0x0001);
                BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(56, 8), BuildId);

                for (ushort slot = 1; slot <= TargetSlots; slot++)
                {
                    uint masked = targets[slot] ^ TargetMask(key, clientNonce, serverNonce, _generationId, slot, version);
                    BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(64 + (slot - 1) * 4, 4), masked);
                }

                _certificateHash.AsSpan(0, 32).CopyTo(response.AsSpan(128, 32));
                if (isIos)
                {
                    IosConfig iosConfig = LoadIosConfig();
                    WriteIosConfig(response, iosConfig);
                }
                byte[] responseMac = Hmac(key, response.AsSpan(0, authenticatedBytes));
                responseMac.CopyTo(response, authenticatedBytes);

                await stream.WriteAsync(response.AsMemory(0, response.Length)).ConfigureAwait(false);
                await stream.FlushAsync().ConfigureAwait(false);
                return true;
            }
        }

        private static string ErrorText(Exception ex)
        {
            Exception root = ex;
            while (root.InnerException != null) root = root.InnerException;
            string message = root.Message ?? root.GetType().Name;
            int nl = message.IndexOfAny(new[] { '\r', '\n' });
            if (nl >= 0) message = message[..nl];
            if (message.Length > 140) message = message[..140] + "...";
            return $"{root.GetType().Name}: {message}";
        }
        private static IosConfig LoadIosConfig()
        {
            string configured = Environment.GetEnvironmentVariable("BOLT_IOS_CONTROL_PATH") ?? string.Empty;
            string path = string.IsNullOrWhiteSpace(configured)
                ? Path.Combine(AppContext.BaseDirectory, "config", "ios_manifest_control.json")
                : (Path.IsPathRooted(configured) ? configured : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, configured)));
            try
            {
                if (!File.Exists(path))
                 {
                    return DisabledIosConfig();
                }
                string json;
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (StreamReader reader = new StreamReader(fs))
                    json = reader.ReadToEnd();
                IosConfig? config = JsonSerializer.Deserialize<IosConfig>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                   AllowTrailingCommas = true
                });
                if (config == null) throw new InvalidDataException("empty configuration");
                 FixIosConfig(config);
                return config;
            }
             catch
            {
                return DisabledIosConfig();
            }
        }

        private static IosConfig DisabledIosConfig() => new IosConfig
        {
            Revision = 1,
            BootstrapEnabled = false,
            HooksEnabled = false,
            DiagnosticsEnabled = true,
           DiagnosticFsync = true,
            DiagnosticStderr = false,
            TlsHookEnabled = false,
            BoltHookEnabled = false,
           PhotonHookEnabled = false,
           RoutingEnabled = false,
            TlsPinOverrideEnabled = false,
            StrictPreflight = true
        };

       private static void FixIosConfig(IosConfig config)
        {
           if (config.Revision == 0) config.Revision = 1;
            config.StartupDelayMs = Math.Clamp(config.StartupDelayMs, 0U, 60000U);
            config.UnityWaitMs = Math.Clamp(config.UnityWaitMs, 0U, 120000U);
            config.DomainWaitMs = Math.Clamp(config.DomainWaitMs, 0U, 120000U);
            config.DependencyWaitMs = Math.Clamp(config.DependencyWaitMs, 0U, 120000U);
            config.HookWaitMs = Math.Clamp(config.HookWaitMs, 0U, 120000U);
            config.PollMinUs = Math.Clamp(config.PollMinUs, 250U, 50000U);
            config.PollMaxUs = Math.Clamp(config.PollMaxUs, config.PollMinUs, 100000U);
            config.TlsLogLimit = (ushort)Math.Clamp((int)config.TlsLogLimit, 0, 512);
            config.BoltLogLimit = (ushort)Math.Clamp((int)config.BoltLogLimit, 0, 512);
            config.PhotonLogLimit = (ushort)Math.Clamp((int)config.PhotonLogLimit, 0, 512);
            config.MaxAssemblyCount = Math.Clamp(config.MaxAssemblyCount, 4U, 8192U);
            config.ExpectedRpcClassCount = Math.Clamp(config.ExpectedRpcClassCount, 0U, 100000U);
            if (!config.BootstrapEnabled) config.HooksEnabled = false;
            if (!config.HooksEnabled)
           {
                config.TlsHookEnabled = false;
                config.BoltHookEnabled = false;
                config.PhotonHookEnabled = false;
                config.RoutingEnabled = false;
                config.TlsPinOverrideEnabled = false;
            }
            if (!config.TlsHookEnabled) config.TlsPinOverrideEnabled = false;
        }

       private static void WriteIosConfig(byte[] response, IosConfig config)
        {
            IosFlags features = 0;
            if (config.BootstrapEnabled) features |= IosFlags.Bootstrap;
            if (config.HooksEnabled) features |= IosFlags.Hooks;
            if (config.DiagnosticsEnabled) features |= IosFlags.Diagnostics;
            if (config.DiagnosticFsync) features |= IosFlags.DiagnosticFsync;
            if (config.DiagnosticStderr) features |= IosFlags.DiagnosticStderr;
            if (config.TlsHookEnabled) features |= IosFlags.TlsHook;
            if (config.BoltHookEnabled) features |= IosFlags.BoltHook;
            if (config.PhotonHookEnabled) features |= IosFlags.PhotonHook;
            if (config.RoutingEnabled) features |= IosFlags.Routing;
            if (config.TlsPinOverrideEnabled) features |= IosFlags.TlsPinOverride;
            if (config.StrictPreflight) features |= IosFlags.StrictPreflight;

            BinaryPrimitives.WriteUInt64LittleEndian(response.AsSpan(160, 8), (ulong)features);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(168, 4), config.Revision);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(172, 4), config.StartupDelayMs);
           BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(176, 4), config.UnityWaitMs);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(180, 4), config.DomainWaitMs);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(184, 4), config.DependencyWaitMs);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(188, 4), config.HookWaitMs);
            BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(192, 4), config.PollMinUs);
             BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(196, 4), config.PollMaxUs);
            BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(208, 2), config.TlsLogLimit);
            BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(210, 2), config.BoltLogLimit);
            BinaryPrimitives.WriteUInt16LittleEndian(response.AsSpan(212, 2), config.PhotonLogLimit);
             BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(216, 4), config.MaxAssemblyCount);
           BinaryPrimitives.WriteUInt32LittleEndian(response.AsSpan(220, 4), config.ExpectedRpcClassCount);
        }

        private static uint TargetMask(byte[] key, ulong clientNonce, ulong serverNonce, ulong generation, ushort slot, ushort version)
        {
            Span<byte> material = stackalloc byte[32];
            BinaryPrimitives.WriteUInt64LittleEndian(material.Slice(0, 8), clientNonce);
            BinaryPrimitives.WriteUInt64LittleEndian(material.Slice(8, 8), serverNonce);
            BinaryPrimitives.WriteUInt64LittleEndian(material.Slice(16, 8), generation);
            BinaryPrimitives.WriteUInt16LittleEndian(material.Slice(24, 2), slot);
           BinaryPrimitives.WriteUInt16LittleEndian(material.Slice(26, 2), version);
           BinaryPrimitives.WriteUInt32LittleEndian(material.Slice(28, 4), unchecked((uint)BuildId));
            return BinaryPrimitives.ReadUInt32LittleEndian(Hmac(key, material).AsSpan(0, 4));
        }

        private static byte[] Hmac(byte[] key, ReadOnlySpan<byte> data)
        {
            using HMACSHA256 hmac = new(key);
            return hmac.ComputeHash(data.ToArray());
        }

        private static ulong NewRandomId()
        {
            Span<byte> bytes = stackalloc byte[8];
             ulong value;
            do
            {
                RandomNumberGenerator.Fill(bytes);
                value = BinaryPrimitives.ReadUInt64LittleEndian(bytes);
            } while (value == 0);
            return value;
         }

        private static async Task<bool> ReadRequest(NetworkStream stream, byte[] buffer)
        {
            using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
           int offset = 0;
            try
           {
                while (offset < buffer.Length)
                {
                     int read = await stream.ReadAsync(buffer.AsMemory(offset, buffer.Length - offset), timeout.Token).ConfigureAwait(false);
                    if (read <= 0) return false;
                    offset += read;
                }
                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
        }

        private static byte[] LoadKey()
        {
            string? hex = Environment.GetEnvironmentVariable("BOLT_MANIFEST_PSK_HEX");
            if (string.IsNullOrWhiteSpace(hex) ||
                hex.Contains("REPLACE_WITH", StringComparison.OrdinalIgnoreCase) ||
                hex.Contains("CLIENT_MANIFEST_KEY", StringComparison.OrdinalIgnoreCase))
            {

                hex = "a5dc5d6aeaf97e19c08559b7a1af87dd2479b1b94d84d28f944add74a9490b43";
            }

            hex = hex.Trim();

            if (hex.Length != 64)
              throw new InvalidOperationException("key must be 64 hex");
            try { return Convert.FromHexString(hex); }
            catch (FormatException e)
            {
                throw new InvalidOperationException("invalid manifest key", e);
             }
        }
    }
}
