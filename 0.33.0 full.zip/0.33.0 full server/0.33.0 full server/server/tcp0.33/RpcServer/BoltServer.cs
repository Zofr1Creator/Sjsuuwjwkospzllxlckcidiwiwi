using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using MongoDB.Bson.Serialization.Conventions;
using TspServer.MongoDB;
using TspServer.MongoDB.Data;
using TspServer.MongoDB.Game;
using TspServer.RpcServer.Api;

namespace TspServer.RpcServer
{
    public sealed class BoltServer
    {
        private const int ListenBacklog = 512;

        private static readonly object DatabaseInitLock = new();

        private static bool _databaseInitialized;

        private static bool _conventionsRegistered;

        private readonly TcpListener _listener;

        private int _activeConnections;

        public BoltServer(int port)
        {
            InitializeDatabase();

            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start(ListenBacklog);
        }

        public async Task RunAsync()
        {
            while (true)
            {
                TcpClient? client = null;

                try
                {
                    client = await _listener.AcceptTcpClientAsync().ConfigureAwait(false);
                    ConfigureClient(client);

                    string remoteIp = GetRemoteIp(client);
                    int active = Volatile.Read(ref _activeConnections);

                    if (!ConnectionGate.TryEnter(remoteIp, active, ConnectionGate.MaxBoltActive, out string gateReason))
                    {
                        Console.WriteLine($"[bolt] {remoteIp} rejected ({gateReason})");
                        client.Close();
                        continue;
                    }

                    Console.WriteLine($"[bolt] {remoteIp} connected");
                    Interlocked.Increment(ref _activeConnections);
                    _ = HandleClientAsync(client, remoteIp);
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (SocketException)
                {
                    try { client?.Close(); } catch { }
                    await Task.Delay(100).ConfigureAwait(false);
                }
                catch
                {
                    try { client?.Close(); } catch { }
                    await Task.Delay(100).ConfigureAwait(false);
                }
            }
        }

        public static string GetLocalIpAddress()
        {
            try
            {
                using var probe = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                probe.Connect("1.1.1.1", 53);

                if (probe.LocalEndPoint is IPEndPoint endpoint && !IPAddress.IsLoopback(endpoint.Address))
                    return endpoint.Address.ToString();
            }
            catch
            {
            }

            foreach (IPAddress address in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (address.AddressFamily != AddressFamily.InterNetwork || IPAddress.IsLoopback(address))
                    continue;

                byte[] octets = address.GetAddressBytes();
                bool isPrivate =
                    octets[0] == 10 ||
                    (octets[0] == 172 && octets[1] is >= 16 and <= 31) ||
                    (octets[0] == 192 && octets[1] == 168);

                if (isPrivate)
                    return address.ToString();
            }

            throw new InvalidOperationException("No private IPv4 address was found.");
        }

        internal static void InitializeDatabase()
        {
            lock (DatabaseInitLock)
            {
                if (_databaseInitialized &&
                    BoltMainDatabaseProvider.Instance != null &&
                    BoltGameDatabaseProvider.Instance != null)
                {
                    return;
                }

                BoltDatabaseManager.Initialize();

                if (!_conventionsRegistered)
                {
                    var conventions = new ConventionPack
                    {
                        new IgnoreExtraElementsConvention(true)
                    };
                    ConventionRegistry.Register("IgnoreExtraElements", conventions, _ => true);
                    _conventionsRegistered = true;
                }

                ServerOptions options = ServerOptions.Current;
                string databaseName = Environment.GetEnvironmentVariable("MONGO_DATABASE") ?? "Main";

                BoltMainDatabaseProvider.Instance =
                    (BoltMainDatabaseProvider)BoltDatabaseManager.Connect(new BoltDatabaseInfo
                    {
                        DatabaseName = databaseName,
                        DatabaseType = BoltDatabaseType.Main,
                        Address = "127.0.0.1",
                        Port = "2077",
                        Uri = options.MongoMainUri
                    });

                BoltGameDatabaseProvider.Instance =
                    (BoltGameDatabaseProvider)BoltDatabaseManager.Connect(new BoltDatabaseInfo
                    {
                        DatabaseName = databaseName,
                        DatabaseType = BoltDatabaseType.Game,
                        Address = "127.0.0.1",
                        Port = "2077",
                        Uri = options.MongoGameUri
                    });

                _databaseInitialized = true;
            }
        }

        private async Task HandleClientAsync(TcpClient client, string remoteIp)
        {
            try
            {
                var session = new ClientSession(client);
                await session.RunAsync().ConfigureAwait(false);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[bolt] {remoteIp} error: {ShortError(ex)}");
            }
            finally
            {
                Console.WriteLine($"[bolt] {remoteIp} disconnected");
                ConnectionGate.Leave(remoteIp);
                try { client.Close(); } catch { }
                Interlocked.Decrement(ref _activeConnections);
            }
        }

        private static void ConfigureClient(TcpClient client)
        {
            try { client.NoDelay = true; } catch { }
            try
            {
                client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
            }
            catch
            {
            }
        }

        private static string ShortError(System.Exception ex)
        {
            System.Exception root = ex;
            while (root.InnerException != null) root = root.InnerException;
            string message = root.Message ?? root.GetType().Name;
            int nl = message.IndexOfAny(new[] { '\r', '\n' });
            if (nl >= 0) message = message[..nl];
            if (message.Length > 140) message = message[..140] + "...";
            return $"{root.GetType().Name}: {message}";
        }

        private static string GetRemoteIp(TcpClient client)
        {
            try
            {
                return (client.Client.RemoteEndPoint as IPEndPoint)?.Address.ToString() ?? "unknown";
            }
            catch
            {
                return "unknown";
            }
        }
    }
}
