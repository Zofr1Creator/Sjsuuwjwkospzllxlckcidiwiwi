using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading.Tasks;

namespace TspServer.RpcServer
{
    public sealed class ServerOptions
    {
        public static ServerOptions Current { get; } = Load();

        public int BoltPort { get; init; } = 2222;
        public int ManifestPort { get; init; } = 2221;
        public int PhotonPort { get; init; } = 5055;
        public string MongoMainUri { get; init; } = "mongodb://127.0.0.1:2077/";
        public string MongoGameUri { get; init; } = "mongodb://127.0.0.1:2077/";
        public bool AllowLocalGuest { get; init; } = true;
        public bool GoogleAuthEnabled { get; init; } = true;
        public string GoogleWebClientId { get; init; } = string.Empty;
        public string GoogleWebClientSecret { get; init; } = string.Empty;
        public string GoogleTokenEndpoint { get; init; } = "https://oauth2.googleapis.com/token";
        public string GoogleOAuthRedirectUri { get; init; } = string.Empty;
        public bool GoogleAllowIdToken { get; init; } = true;
        public bool GoogleAllowServerAuthCode { get; init; } = true;
        public bool GoogleRequireVerifiedEmail { get; init; }
        public int GoogleAuthTimeoutMs { get; init; } = 10_000;
        public bool EnableWireCrypto { get; init; } = true;
        public bool EnablePresenceBridge { get; init; } = true;
        public string TlsMode { get; init; } = "auto";
        public string TlsPfxPath { get; init; } = string.Empty;
        public string TlsPfxPassword { get; init; } = string.Empty;
        public int TlsHandshakeTimeoutMs { get; init; } = 15_000;
        public string Country { get; init; } = "ZZ";
        public string PublicHost { get; private set; } = string.Empty;
        public bool AntiCheatEnabled { get; init; } = true;
        public bool AntiCheatRequireVerification { get; init; } = true;
        public bool AntiCheatRequireHashes { get; init; } = true;
        public bool AntiCheatRejectRooted { get; init; } = true;
        public bool AntiCheatRejectForbiddenApps { get; init; } = true;
        public bool AntiCheatBanOnAuthViolation { get; init; } = true;
        public int AntiCheatBanCode { get; init; } = 1;
        public long AntiCheatBanSeconds { get; init; }
        public int MaxBridgeClients { get; init; } = 128;
        public int MaxIncomingFrameBytes { get; init; } = 8 * 1024 * 1024;
        public int MaxQueuedRequests { get; init; } = 256;
        public int MaxQueuedResponses { get; init; } = 1024;
        public int FrameBodyReadTimeoutMs { get; init; } = 15_000;

        public bool GoogleWebClientSecretLooksConfigured =>
            !string.IsNullOrWhiteSpace(GoogleWebClientSecret) &&
            GoogleWebClientSecret.Length >= 8;

        private sealed class LocalConfig
        {
            public string? PublicHost { get; set; }
            public int? ManifestPort { get; set; }
            public int? BoltPort { get; set; }
            public int? PhotonPort { get; set; }
            public string? MongoUri { get; set; }
            public string? MongoDatabase { get; set; }
            public string? RankedMongoDatabase { get; set; }
            public bool? AllowLocalGuest { get; set; }
            public bool? WireCrypto { get; set; }
            public string? Country { get; set; }
            public TlsConfig? Tls { get; set; }
            public GoogleConfig? Google { get; set; }
            public PresenceConfig? Presence { get; set; }
            public ContentConfig? Content { get; set; }
            public RankedConfig? Ranked { get; set; }
            public AntiCheatConfig? AntiCheat { get; set; }
            public AdvancedConfig? Advanced { get; set; }
        }

        private sealed class TlsConfig
        {
            public string? Mode { get; set; }
            public string? Certificate { get; set; }
            public string? Password { get; set; }
            public int? HandshakeTimeoutMs { get; set; }
        }

        private sealed class GoogleConfig
        {
            public bool? Enabled { get; set; }
            public string? WebClientId { get; set; }
            public string? WebClientSecret { get; set; }
            public string? TokenEndpoint { get; set; }
            public string? RedirectUri { get; set; }
            public bool? AllowIdToken { get; set; }
            public bool? AllowServerAuthCode { get; set; }
            public bool? RequireVerifiedEmail { get; set; }
            public int? TimeoutMs { get; set; }
        }

        private sealed class PresenceConfig
        {
            public bool? Enabled { get; set; }
            public int? Port { get; set; }
            public string? Bind { get; set; }
            public string? Secret { get; set; }
        }

        private sealed class ContentConfig
        {
            public bool? Enabled { get; set; }
            public int? Port { get; set; }
        }

        private sealed class RankedConfig
        {
            public int? RequiredPlayers5v5 { get; set; }
            public int? RequiredPlayers2v2 { get; set; }
            public int? RequiredPlayersDuel { get; set; }
            public int? ConfirmationSeconds { get; set; }
            public int? ReadyRetentionSeconds { get; set; }
            public bool? TestMode { get; set; }
        }

        private sealed class AntiCheatConfig
        {
            public bool? Enabled { get; set; }
            public bool? RequireVerification { get; set; }
            public bool? RequireHashes { get; set; }
            public bool? RejectRooted { get; set; }
            public bool? RejectForbiddenApps { get; set; }
            public bool? BanOnAuthViolation { get; set; }
            public int? BanCode { get; set; }
            public long? BanSeconds { get; set; }
        }

        private sealed class AdvancedConfig
        {
            public string? ReadyFile { get; set; }
            public string? IosControlPath { get; set; }
            public int? SanctionPort { get; set; }
            public string? SanctionHost { get; set; }
            public string? SanctionSecret { get; set; }
            public string? DonationHost { get; set; }
            public string? DonationSecret { get; set; }
            public string? CommerceAdminKey { get; set; }
            public int? CommercePort { get; set; }
            public string? SessionSigningKeyHex { get; set; }
            public int? SessionTtlSeconds { get; set; }
            public string? ManifestPskHex { get; set; }
        }

        private static ServerOptions Load()
        {
            LocalConfig config = LoadConfig();
            ApplyLegacyConfig(config);

            string defaultPfx = DefaultTlsPath();
            string pfxPath = config.Tls?.Certificate ?? defaultPfx;
            if (!Path.IsPathRooted(pfxPath))
                pfxPath = Path.GetFullPath(Path.Combine(FindProjectRoot(), pfxPath));

            return new ServerOptions
            {
                BoltPort = ReadPort("BOLT_PORT", config.BoltPort ?? 2222),
                ManifestPort = ReadPort("BOLT_MANIFEST_PORT", config.ManifestPort ?? 2221),
                PhotonPort = ReadPort("BOLT_PHOTON_PORT", config.PhotonPort ?? 5055),
                MongoMainUri = ReadString("MONGO_MAIN_URI", config.MongoUri ?? "mongodb://127.0.0.1:2077/"),
                MongoGameUri = ReadString("MONGO_GAME_URI", config.MongoUri ?? "mongodb://127.0.0.1:2077/"),
                AllowLocalGuest = ReadBool("BOLT_ALLOW_LOCAL_GUEST", config.AllowLocalGuest ?? true),
                GoogleAuthEnabled = ReadBool("BOLT_GOOGLE_AUTH_ENABLED", config.Google?.Enabled ?? true),
                GoogleWebClientId = ReadString("BOLT_GOOGLE_WEB_CLIENT_ID", config.Google?.WebClientId ?? string.Empty),
                GoogleWebClientSecret = ReadString("BOLT_GOOGLE_WEB_CLIENT_SECRET", config.Google?.WebClientSecret ?? string.Empty),
                GoogleTokenEndpoint = ReadString("BOLT_GOOGLE_TOKEN_ENDPOINT", config.Google?.TokenEndpoint ?? "https://oauth2.googleapis.com/token"),
                GoogleOAuthRedirectUri = ReadString("BOLT_GOOGLE_REDIRECT_URI", config.Google?.RedirectUri ?? string.Empty),
                GoogleAllowIdToken = ReadBool("BOLT_GOOGLE_ALLOW_ID_TOKEN", config.Google?.AllowIdToken ?? true),
                GoogleAllowServerAuthCode = ReadBool("BOLT_GOOGLE_ALLOW_SERVER_AUTH_CODE", config.Google?.AllowServerAuthCode ?? true),
                GoogleRequireVerifiedEmail = ReadBool("BOLT_GOOGLE_REQUIRE_VERIFIED_EMAIL", config.Google?.RequireVerifiedEmail ?? false),
                GoogleAuthTimeoutMs = ReadInt("BOLT_GOOGLE_AUTH_TIMEOUT_MS", config.Google?.TimeoutMs ?? 10_000),
                EnableWireCrypto = ReadBool("BOLT_WIRE_CRYPTO", config.WireCrypto ?? true),
                EnablePresenceBridge = ReadBool("BOLT_ENABLE_PRESENCE_BRIDGE", config.Presence?.Enabled ?? true),
                TlsMode = ReadTlsMode("BOLT_TLS_MODE", config.Tls?.Mode ?? "auto"),
                TlsPfxPath = ReadString("BOLT_TLS_PFX_PATH", pfxPath),
                TlsPfxPassword = ReadString("BOLT_TLS_PFX_PASSWORD", config.Tls?.Password ?? "server033"),
                TlsHandshakeTimeoutMs = ReadInt("BOLT_TLS_HANDSHAKE_TIMEOUT_MS", config.Tls?.HandshakeTimeoutMs ?? 15_000),
                Country = ReadString("BOLT_COUNTRY", config.Country ?? "ZZ"),
                PublicHost = CleanPublicHost(ReadString("BOLT_PUBLIC_HOST", config.PublicHost ?? string.Empty)),
                AntiCheatEnabled = ReadBool("BOLT_AC_ENABLED", config.AntiCheat?.Enabled ?? true),
                AntiCheatRequireVerification = ReadBool("BOLT_AC_REQUIRE_VERIFICATION", config.AntiCheat?.RequireVerification ?? true),
                AntiCheatRequireHashes = ReadBool("BOLT_AC_REQUIRE_HASHES", config.AntiCheat?.RequireHashes ?? true),
                AntiCheatRejectRooted = ReadBool("BOLT_AC_REJECT_ROOT", config.AntiCheat?.RejectRooted ?? true),
                AntiCheatRejectForbiddenApps = ReadBool("BOLT_AC_REJECT_FORBIDDEN_APPS", config.AntiCheat?.RejectForbiddenApps ?? true),
                AntiCheatBanOnAuthViolation = ReadBool("BOLT_AC_BAN_AUTH_VIOLATION", config.AntiCheat?.BanOnAuthViolation ?? true),
                AntiCheatBanCode = ReadInt("BOLT_AC_BAN_CODE", config.AntiCheat?.BanCode ?? 1),
                AntiCheatBanSeconds = ReadLong("BOLT_AC_BAN_SECONDS", config.AntiCheat?.BanSeconds ?? 0),
                MaxBridgeClients = ReadInt("BOLT_PRESENCE_MAX_CLIENTS", 128),
                MaxIncomingFrameBytes = Math.Clamp(ReadInt("BOLT_MAX_FRAME_BYTES", 8 * 1024 * 1024), 64 * 1024, 64 * 1024 * 1024),
                MaxQueuedRequests = Math.Clamp(ReadInt("BOLT_MAX_QUEUED_REQUESTS", 256), 32, 4096),
                MaxQueuedResponses = Math.Clamp(ReadInt("BOLT_MAX_QUEUED_RESPONSES", 1024), 64, 16_384),
                FrameBodyReadTimeoutMs = Math.Clamp(ReadInt("BOLT_FRAME_BODY_TIMEOUT_MS", 15_000), 1000, 120_000)
            };
        }

        private static LocalConfig LoadConfig()
        {
            string path = Path.Combine(FindProjectRoot(), "serverconfig.json");
            if (!File.Exists(path))
                return new LocalConfig();

            try
            {
                string json = File.ReadAllText(path);
                return JsonSerializer.Deserialize<LocalConfig>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    AllowTrailingCommas = true
                }) ?? new LocalConfig();
            }
            catch (JsonException ex)
            {
                throw new InvalidDataException("invalid serverconfig.json", ex);
            }
        }

        private static void ApplyLegacyConfig(LocalConfig config)
        {
            SetIfMissing("MONGO_DATABASE", config.MongoDatabase);
            SetIfMissing("RANKED_MONGO_DATABASE", config.RankedMongoDatabase);
            SetIfMissing("BOLT_PRESENCE_BRIDGE_PORT", config.Presence?.Port?.ToString());
            SetIfMissing("BOLT_PRESENCE_BRIDGE_BIND", config.Presence?.Bind);
            SetIfMissing("BOLT_PRESENCE_BRIDGE_SECRET", config.Presence?.Secret);
            SetIfMissing("BOLT_CONTENT_HTTP_ENABLED", BoolString(config.Content?.Enabled));
            SetIfMissing("BOLT_CONTENT_HTTP_PORT", config.Content?.Port?.ToString());
            SetIfMissing("BOLT_RANKED_5V5_REQUIRED_PLAYERS", config.Ranked?.RequiredPlayers5v5?.ToString());
            SetIfMissing("BOLT_RANKED_2V2_REQUIRED_PLAYERS", config.Ranked?.RequiredPlayers2v2?.ToString());
            SetIfMissing("BOLT_RANKED_DUEL_REQUIRED_PLAYERS", config.Ranked?.RequiredPlayersDuel?.ToString());
            SetIfMissing("RANKED_CONFIRMATION_SECONDS", config.Ranked?.ConfirmationSeconds?.ToString());
            SetIfMissing("BOLT_RANKED_READY_RETENTION_SECONDS", config.Ranked?.ReadyRetentionSeconds?.ToString());
            SetIfMissing("RANKED_TEST_MODE", BoolString(config.Ranked?.TestMode));
            SetIfMissing("BOLT_READY_FILE", ResolvePath(config.Advanced?.ReadyFile));
            SetIfMissing("BOLT_IOS_CONTROL_PATH", ResolvePath(config.Advanced?.IosControlPath));
            SetIfMissing("BOLT_TO_SWISS_SANCTION_PORT", config.Advanced?.SanctionPort?.ToString());
            SetIfMissing("BOLT_TO_SWISS_SANCTION_HOST", config.Advanced?.SanctionHost);
            SetIfMissing("BOLT_TO_SWISS_SANCTION_SECRET", config.Advanced?.SanctionSecret);
            SetIfMissing("BOLT_DONATION_BRIDGE_HOST", config.Advanced?.DonationHost);
            SetIfMissing("BOLT_DONATION_BRIDGE_SECRET", config.Advanced?.DonationSecret);
            SetIfMissing("BOLT_COMMERCE_ADMIN_KEY", config.Advanced?.CommerceAdminKey);
            SetIfMissing("BOLT_COMMERCE_PORT", config.Advanced?.CommercePort?.ToString());
            SetIfMissing("BOLT_SESSION_SIGNING_KEY_HEX", config.Advanced?.SessionSigningKeyHex);
            SetIfMissing("BOLT_SESSION_TTL_SECONDS", config.Advanced?.SessionTtlSeconds?.ToString());
            SetIfMissing("BOLT_MANIFEST_PSK_HEX", config.Advanced?.ManifestPskHex);
        }

        private static string? BoolString(bool? value)
        {
            return value is null ? null : (value.Value ? "true" : "false");
        }

        private static string? ResolvePath(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;
            return Path.IsPathRooted(value) ? value : Path.GetFullPath(Path.Combine(FindProjectRoot(), value));
        }

        private static void SetIfMissing(string key, string? value)
        {
            if (string.IsNullOrWhiteSpace(value) || !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(key)))
                return;
            Environment.SetEnvironmentVariable(key, value);
        }

        private static string FindProjectRoot()
        {
            string? current = Environment.CurrentDirectory;
            for (int i = 0; i < 8 && !string.IsNullOrWhiteSpace(current); i++)
            {
                if (File.Exists(Path.Combine(current, "serverconfig.json")))
                    return current;
                current = Directory.GetParent(current)?.FullName;
            }

            current = AppContext.BaseDirectory;
            for (int i = 0; i < 8 && !string.IsNullOrWhiteSpace(current); i++)
            {
                if (File.Exists(Path.Combine(current, "serverconfig.json")))
                    return current;
                current = Directory.GetParent(current)?.FullName;
            }

            return Environment.CurrentDirectory;
        }

        private static string CleanPublicHost(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;
            string trimmed = value.Trim();
            return trimmed.Equals("auto", StringComparison.OrdinalIgnoreCase) ? string.Empty : trimmed;
        }

        public async Task<string> EnsurePublicHostAsync()
        {
            if (!string.IsNullOrWhiteSpace(PublicHost))
                return PublicHost;

            PublicHost = FindPublicIpv4();
            if (!string.IsNullOrWhiteSpace(PublicHost))
                return PublicHost;

            PublicHost = await QueryPublicIpv4().ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(PublicHost))
                return PublicHost;

            throw new InvalidOperationException("public ipv4 not found");
        }

        private static string FindPublicIpv4()
        {
            try
            {
                foreach (IPAddress address in Dns.GetHostAddresses(Dns.GetHostName()))
                {
                    if (IsPublicIpv4(address))
                        return address.ToString();
                }
            }
            catch (SocketException)
            {
            }

            return string.Empty;
        }

        private static async Task<string> QueryPublicIpv4()
        {
            string[] services =
            {
                "https://api.ipify.org"
            };

            using var http = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(3)
            };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("TspServer/0.33");

            foreach (string url in services)
            {
                try
                {
                    string text = (await http.GetStringAsync(url).ConfigureAwait(false)).Trim();
                    if (IPAddress.TryParse(text, out IPAddress? address) && IsPublicIpv4(address))
                        return address.ToString();
                }
                catch (HttpRequestException)
                {
                }
                catch (TaskCanceledException)
                {
                }
            }

            return string.Empty;
        }

        private static bool IsPublicIpv4(IPAddress address)
        {
            if (address.AddressFamily != AddressFamily.InterNetwork)
                return false;

            byte[] bytes = address.GetAddressBytes();
            if (bytes[0] == 0 || bytes[0] == 10 || bytes[0] == 127 || bytes[0] >= 224)
                return false;
            if (bytes[0] == 100 && bytes[1] >= 64 && bytes[1] <= 127)
                return false;
            if (bytes[0] == 169 && bytes[1] == 254)
                return false;
            if (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31)
                return false;
            if (bytes[0] == 192 && bytes[1] == 168)
                return false;
            return true;
        }

        private static string DefaultTlsPath()
        {
            return Path.Combine(FindProjectRoot(), "certs", "server.pfx");
        }

        private static string ReadTlsMode(string key, string fallback)
        {
            string value = ReadString(key, fallback).ToLowerInvariant();
            return value is "on" or "off" or "auto" ? value : fallback;
        }

        private static string ReadString(string key, string fallback)
        {
            string? value = Environment.GetEnvironmentVariable(key);
            return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
        }

        private static int ReadInt(string key, int fallback)
        {
            string? raw = Environment.GetEnvironmentVariable(key);
            return int.TryParse(raw, out int value) ? value : fallback;
        }

        private static long ReadLong(string key, long fallback)
        {
            string? raw = Environment.GetEnvironmentVariable(key);
            return long.TryParse(raw, out long value) ? value : fallback;
        }

        private static int ReadPort(string key, int fallback)
        {
            int value = ReadInt(key, fallback);
            return value is > 0 and <= 65_535 ? value : fallback;
        }

        private static bool ReadBool(string key, bool fallback)
        {
            string? value = Environment.GetEnvironmentVariable(key);
            if (string.IsNullOrWhiteSpace(value))
                return fallback;
            return value.Equals("1", StringComparison.OrdinalIgnoreCase)
                || value.Equals("true", StringComparison.OrdinalIgnoreCase)
                || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
                || value.Equals("on", StringComparison.OrdinalIgnoreCase);
        }
    }
}
