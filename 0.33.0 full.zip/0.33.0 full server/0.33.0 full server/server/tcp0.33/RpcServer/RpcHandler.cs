using System;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;

namespace TspServer.RpcServer
{
   public abstract class RpcHandler
    {
        protected RpcHandler(ClientSession session)
        {
             _session = session ?? throw new ArgumentNullException(nameof(session));
        }

        protected readonly ClientSession _session;

        public virtual Task InvokeAsync(RpcRequest request)
        {
            return Task.Run(() => Invoke(request));
        }

        public abstract void Invoke(RpcRequest request);
    }
}
