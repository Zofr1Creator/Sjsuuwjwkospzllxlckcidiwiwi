using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.RpcServer.Api;

namespace TspServer.RpcServer
{
    public static class PresenceBridgeServer
    {
        private static TcpListener _listener;
        private static bool _started;
        private static readonly int _maxClients = Math.Clamp(ServerOptions.Current.MaxBridgeClients, 8, 1024);
        private static readonly System.Threading.SemaphoreSlim _clients = new System.Threading.SemaphoreSlim(_maxClients, _maxClients);

        public static void Start()
        {
            if (_started) return;
            _started = true;
            int port = 2233;
            int.TryParse(Environment.GetEnvironmentVariable("BOLT_PRESENCE_BRIDGE_PORT"), out port);
            if (port <= 0) port = 2233;
            string bindText = Environment.GetEnvironmentVariable("BOLT_PRESENCE_BRIDGE_BIND") ?? "127.0.0.1";
            IPAddress bind = IPAddress.TryParse(bindText, out IPAddress parsedBind) ? parsedBind : IPAddress.Loopback;
            _listener = new TcpListener(bind, port);
            _listener.Start(Math.Max(32, _maxClients));
             _ = Task.Run(AcceptLoop);
        }

        private static async Task AcceptLoop()
        {
            while (true)
            {
                 TcpClient client = null;
                try
                {
                    client = await _listener.AcceptTcpClientAsync();
                    client.NoDelay = true;
                    await _clients.WaitAsync();
                    TcpClient accepted = client;
                    _ = Task.Run(async () =>
                    {
                        try { await Handle(accepted); }
                        finally { _clients.Release(); }
                    });
                }
                catch (System.Exception)
                {
                    try { client?.Close(); } catch { }
                    await Task.Delay(1000);
                }
            }
        }

        private static async Task Handle(TcpClient client)
        {
             string remote = client.Client.RemoteEndPoint?.ToString() ?? "unknown";
            try
            {
                client.ReceiveTimeout = 5000;
                client.SendTimeout = 5000;
               using (client)
                using (var stream = client.GetStream())
                {

                    using var reader = new StreamReader(stream, Encoding.UTF8, false, 8192, leaveOpen: true);
                    using var writer = new StreamWriter(stream, new UTF8Encoding(false), 1024, leaveOpen: true) { AutoFlush = true };
                    string line = await reader.ReadLineAsync();
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        await writer.WriteLineAsync("ERR|empty-frame");
                        return;
                    }
                    string[] parts = line.Trim().Split('|');
                    string secret = Environment.GetEnvironmentVariable("BOLT_PRESENCE_BRIDGE_SECRET") ?? string.Empty;
                    int offset = string.IsNullOrEmpty(secret) ? 0 : 1;
                    if (parts.Length < offset + 2 || (!string.IsNullOrEmpty(secret) && parts[0] != secret))
                    {
                        await writer.WriteLineAsync("ERR|bad-frame");
                        return;
                    }
                   string command = parts[offset];
                    string playerId = Decode(parts[offset + 1]);
                    string ackResponse = "OK";
                    if (command == "SET" && parts.Length >= offset + 6)
                    {
                        string roomId = Decode(parts[offset + 2]);
                        string region = Decode(parts[offset + 3]);
                        string version = Decode(parts[offset + 4]);
                        string mode = Decode(parts[offset + 5]);
                        string gameVersion = parts.Length > offset + 6 ? Decode(parts[offset + 6]) : null;
                        ServerState.SetPlayerPhotonPresence(playerId, roomId, region, version,
                            new System.Collections.Generic.Dictionary<string,string> { ["mode"] = mode },
                            gameVersion);
                        try
                        {
                            if (mode.StartsWith("Ranked", StringComparison.OrdinalIgnoreCase))
                                RankedAuthorityRepository.Instance.PromoteActiveMatchFromPhotonPresence(playerId, roomId, mode, region, version);
                        }
                        catch (System.Exception) { ; }
                        try
                        {
                            TspServer.MongoDB.BoltMainDatabaseProvider.Instance
                                .SetPlayerStatus(
                                    global::MongoDB.Bson.ObjectId.Parse(playerId),
                                    ServerState.GetOrCreatePlayerStatus(playerId));
                        }
                        catch (System.Exception) { ; }
                        try { BattlePassRuntime.BindActiveMatch(playerId, roomId); }
                        catch (System.Exception) { ; }
                    }
                    else if (command == "XP_SYNC")
                    {
                        int delivered = GameEventRemoteService.SendPlayerLevelChanged(playerId);
                    }
                    else if (command == "CURRENCY" && parts.Length >= offset + 5)
                    {
                        int currencyId = ParseInt(Decode(parts[offset + 2]));
                        float oldValue = ParseFloat(Decode(parts[offset + 3]));
                        float newValue = ParseFloat(Decode(parts[offset + 4]));
                        int delivered = InventoryEventBus.InventoryChanged(playerId, currencies: new[]
                        {
                            new CurrencyAmount { CurrencyId = currencyId, OldValue = (int)Math.Round(oldValue), Value = newValue - oldValue }
                        }, source: "swiss-postmatch-reward");
                    }
                    else if (command == "POSTMATCH_ITEM" && parts.Length >= offset + 4)
                    {
                        string matchId = Decode(parts[offset + 2]);
                       int itemDefinitionId = ParseInt(Decode(parts[offset + 3]));
                        if (itemDefinitionId <= 0 || string.IsNullOrWhiteSpace(matchId))
                         {
                            await writer.WriteLineAsync("ERR|bad-postmatch-item");
                             return;
                         }
                        string markerId = $"postmatch-item:{matchId}:{playerId}";
                        IMongoCollection<BsonDocument> markers = TspServer.MongoDB.BoltMainDatabaseProvider.Instance
                            .GetDatabase().GetCollection<BsonDocument>("postmatch_reward_markers");
                        bool newlyClaimed = false;
                        try
                        {
                            markers.InsertOne(new BsonDocument
                            {
                                ["_id"] = markerId, ["playerId"] = playerId, ["matchId"] = matchId,
                                ["itemDefinitionId"] = itemDefinitionId, ["createdAt"] = DateTime.UtcNow
                            });
                            newlyClaimed = true;
                            var info = new RewardInfo();
                           info.Items.Add(new InventoryItemAmount { InventoryItemDefinitionId = itemDefinitionId, Value = 1 });
                            Reward granted = BattlePassRuntime.GrantRewardInfo(playerId, info);
                            if (granted.Items.Count > 0)
                                InventoryEventBus.InventoryChanged(playerId, added: granted.Items, source: "swiss-postmatch-item");
                            markers.UpdateOne(Builders<BsonDocument>.Filter.Eq("_id", markerId),
                                Builders<BsonDocument>.Update.Set("committed", true).Set("grantedAt", DateTime.UtcNow));
                         }
                        catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
                        {
                        }
                        catch
                        {
                            if (newlyClaimed)
                                markers.DeleteOne(Builders<BsonDocument>.Filter.Eq("_id", markerId));
                            throw;
                        }
                    }
                    else if (command == "BP_MATCH" && parts.Length >= offset + 8)
                    {
                        string matchId = Decode(parts[offset + 2]);
                        int kills = ParseInt(Decode(parts[offset + 3]));
                        int headshots = ParseInt(Decode(parts[offset + 4]));
                       bool completed = ParseBool(Decode(parts[offset + 5]));
                       bool won = ParseBool(Decode(parts[offset + 6]));
                        string source = Decode(parts[offset + 7]);
                        BattlePassMissionSettlementResult settled = BattlePassRuntime.ApplyMatchSnapshot(
                            playerId, matchId, kills, headshots, completed, won);
                        if (settled.Reward != null && (settled.Reward.Items.Count > 0 || settled.Reward.Currencies.Count > 0))
                            InventoryEventBus.InventoryChanged(playerId, added: settled.Reward.Items, currencies: settled.Reward.Currencies, source: "prey-bp-mission");
                         string[] realtimeChallenges = settled.ChangedChallenges
                            .Concat(settled.CompletedChallenges)
                            .Where(x => !string.IsNullOrWhiteSpace(x))
                            .Distinct(StringComparer.Ordinal)
                            .ToArray();
                       if (realtimeChallenges.Length > 0)
                            GameEventRemoteService.SendChallengeChanged(playerId, realtimeChallenges, settled.Reward);
                        if (realtimeChallenges.Length > 0 || settled.EventPointsAwarded > 0)
                            GameEventRemoteService.SendPassChanged(playerId, settled.Reward);
                    }
                    else if (command == "STATTRACK" && parts.Length >= offset + 5)
                    {
                        int itemDefinitionId = ParseInt(Decode(parts[offset + 2]));
                        int inventoryItemId = ParseInt(Decode(parts[offset + 3]));
                        int absoluteValue = ParseInt(Decode(parts[offset + 4]));
                        StatTrackBridge.Result result = StatTrackBridge.ApplyAbsolute(
                            playerId, itemDefinitionId, inventoryItemId, absoluteValue);
                        ackResponse = "OK|" + Math.Max(0, result.Delivered).ToString(System.Globalization.CultureInfo.InvariantCulture);
                    }
                    else if (command == "STATTRACK_GET" && parts.Length >= offset + 4)
                    {
                        int itemDefinitionId = ParseInt(Decode(parts[offset + 2]));
                        int inventoryItemId = ParseInt(Decode(parts[offset + 3]));
                        StatTrackBridge.Result result = StatTrackBridge.GetCurrent(playerId, itemDefinitionId, inventoryItemId);
                        ackResponse = result.Accepted
                            ? "OK|" + result.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)
                            : "MISS|" + result.Reason;
                    }
                    else if (command == "STATTRACK_SET" && parts.Length >= offset + 5)
                    {
                        int itemDefinitionId = ParseInt(Decode(parts[offset + 2]));
                        int inventoryItemId = ParseInt(Decode(parts[offset + 3]));
                        int absoluteValue = ParseInt(Decode(parts[offset + 4]));
                        StatTrackBridge.Result result = StatTrackBridge.ApplyAbsolute(playerId, itemDefinitionId, inventoryItemId, absoluteValue);
                       ackResponse = result.Accepted
                            ? "OK|" + result.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)
                            : "MISS|" + result.Reason;
                    }
                    else if (command == "STATTRACK_RESOLVE" && parts.Length >= offset + 3)
                   {
                        string selectedCsv = Decode(parts[offset + 2]);
                        int[] selectedDefinitions = selectedCsv.Split(',', StringSplitOptions.RemoveEmptyEntries)
                            .Select(x => int.TryParse(x, out int parsed) ? parsed : 0)
                            .Where(x => x > 0)
                            .Distinct()
                            .ToArray();
                        StatTrackBridge.ResolveResult resolved = StatTrackBridge.ResolveOwned(playerId, selectedDefinitions);
                        ackResponse = resolved.Candidates.Length == 0
                            ? "MISS|" + resolved.Reason
                            : "OK|" + string.Join(";", resolved.Candidates.Select(c =>
                                $"{c.ItemDefinitionId},{c.InventoryItemId},{c.Value}"));
                    }
                     else if (command == "SANCTION" && parts.Length >= offset + 6)
                    {
                        int banCode = Math.Max(1, ParseInt(Decode(parts[offset + 2])));
                        long until = ParseLong(Decode(parts[offset + 3]));
                        string reason = Decode(parts[offset + 4]);
                       string source = Decode(parts[offset + 5]);
                        int delivered = PlayerSanctionService.Ban(playerId, banCode, reason, until, source);
                        ackResponse = "OK|" + delivered.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    }
                   else if (command == "CLEAR")
                    {
                        string roomId = parts.Length > offset + 2 ? Decode(parts[offset + 2]) : string.Empty;
                        var status = ServerState.GetOrCreatePlayerStatus(playerId);
                        string current = status.playInGame?.photonGame?.roomId ?? string.Empty;
                       if (string.IsNullOrEmpty(roomId) || string.Equals(current, roomId, StringComparison.Ordinal))
                        {
                            ServerState.SetPlayerPhotonPresence(playerId, null, null, null);
                            try
                            {
                                TspServer.MongoDB.BoltMainDatabaseProvider.Instance
                                    .SetPlayerStatus(global::MongoDB.Bson.ObjectId.Parse(playerId), status);
                            }
                            catch (System.Exception) { ; }
                            BattlePassRuntime.ClearActiveMatch(playerId, string.IsNullOrEmpty(roomId) ? current : roomId);
                        }
                       else
                        {
                        }
                    }
                    else
                    {
                         await writer.WriteLineAsync("ERR|unsupported-or-short");
                        return;
                    }

                    await writer.WriteLineAsync(ackResponse);
                 }
            }
            catch (System.Exception)
            {
                try { client.Close(); } catch { }
            }
        }

        private static int ParseInt(string value) => int.TryParse(value, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out int v) ? v : 0;
        private static long ParseLong(string value) => long.TryParse(value, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out long v) ? v : 0;
        private static bool ParseBool(string value) => bool.TryParse(value, out bool v) && v;
        private static float ParseFloat(string value) => float.TryParse(value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float v) ? v : 0f;

        private static string Decode(string value)
        {
            try { return Encoding.UTF8.GetString(Convert.FromBase64String(value ?? string.Empty)); }
            catch { return string.Empty; }
        }
    }
}
