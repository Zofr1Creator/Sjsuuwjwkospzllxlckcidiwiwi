using System;
using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using TspServer.MongoDB;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;
using TspServer.RpcServer.Api;

namespace TspServer.RpcServer
{
    public class ClientSession
    {
       private readonly SemaphoreSlim _sendLock = new(1, 1);

        private Stream _transportStream;

        private int _queuedRequestCount;

        private int _queuedResponseCount;

        private readonly ConcurrentDictionary<string, WireEncoding> _requestWireEncodings = new(StringComparer.Ordinal);

        private readonly object _cryptoLock = new();

        private byte[] _sessionKey;

        private byte[] _sessionIv;

        private string _activateSessionAfterResponseId;

        private bool _sessionCryptoActive;

        private WireEncoding? _confirmedSessionWireEncoding;

        private readonly object _stateLock = new();

         private readonly Stopwatch _eventSenderInitWatch = new();

         public string LastAuthToken { get; set; }
         public string LastGameId { get; set; }
         public string LastGameVersion { get; set; }

        private bool _clientConnected;

        private readonly Dictionary<string, RpcHandler> _rpcHandlers = new();

        internal bool TryGetRpcHandler<T>(string serviceName, out T handler) where T : RpcHandler
       {
            handler = null!;
            if (string.IsNullOrWhiteSpace(serviceName))
                return false;

             if (!_rpcHandlers.TryGetValue(serviceName, out RpcHandler? raw) || raw is not T typed)
                return false;

            handler = typed;
            return true;
        }

        public ClientSession(TcpClient client)
        {
            TcpClient = client ?? throw new ArgumentNullException(nameof(client));
            _requests = new ConcurrentQueue<RpcRequest>();
            _responses = new ConcurrentQueue<ResponseMessage>();
            _clientConnected = true;

            InitServices();
        }
        public bool HasSessionCrypto
       {
            get
             {
                lock (_cryptoLock)
                    return _sessionKey?.Length == 16 && _sessionIv?.Length == 16;
            }
        }

        public void ConfigureSessionCrypto(
           byte[] sessionKey,
           byte[] sessionIv,
            string sessionId,
            string activateAfterResponseId)
        {
            if (sessionKey == null || sessionKey.Length != 16)
                throw new ArgumentException("session key must be 16 bytes", nameof(sessionKey));
            if (sessionIv == null || sessionIv.Length != 16)
                throw new ArgumentException("session iv must be 16 bytes", nameof(sessionIv));

            lock (_cryptoLock)
            {
                _sessionKey = (byte[])sessionKey.Clone();
                _sessionIv = (byte[])sessionIv.Clone();
                _activateSessionAfterResponseId = activateAfterResponseId;
                _sessionCryptoActive = false;
                _confirmedSessionWireEncoding = null;
            }
        }

        public WireEncoding GetRequestWireEncoding(string requestId)
        {
            if (!string.IsNullOrWhiteSpace(requestId) &&
                _requestWireEncodings.TryGetValue(requestId, out WireEncoding encoding))
                return encoding;

            lock (_cryptoLock)
                return _sessionCryptoActive ? WireEncoding.SessionAes : WireEncoding.Plain;
        }

        public byte[] GetSessionKey()
        {
            lock (_cryptoLock)
                return _sessionKey == null ? null : (byte[])_sessionKey.Clone();
        }

        public byte[] GetSessionIv()
        {
            lock (_cryptoLock)
                return _sessionIv == null ? null : (byte[])_sessionIv.Clone();
        }
        private void InitServices()
         {
            void Register(string name, RpcHandler handler)
            {
                _rpcHandlers[name] = handler;
                _rpcHandlers["Axlebolt.Bolt.Api." + name] = handler;
           }
           var hello = new HelloRemoteService(this);
            Register("HelloRemoteService", hello);
            var handshake = new HandshakeRemoteService(this);
            Register("HandshakeRemoteService", handshake);
            var localGuestAuth = new GoogleAuthRemoteService(this);
            Register("GoogleAuthRemoteService", localGuestAuth);
            Register("GuestAuthRemoteService", localGuestAuth);
            Register("IdTokenRemoteService", localGuestAuth);
            Register("PlayerRemoteService", new PlayerRemoteService(this));
            Register("GameSettingsRemoteService", new GameSettingsRemoteService(this));
            Register("PlayerStatsRemoteService", new PlayerStatsRemoteService(this));
            Register("StorageRemoteService", new StorageRemoteService(this));
            var boltRemote = new BoltRemoteService(this);
            Register("BoltRemoteService", boltRemote);
            var clanStats = new ClanStatsRemoteService(this);
            Register("ClanStatsRemoteService", clanStats);
            Register("GameSeasonRemoteService", new GameSeasonRemoteService(this));
            Register("SeasonalStatsRemoteService", new SeasonalStatsRemoteService(this, clanStats));
            var clanMemberStats = new ClanMemberStatsRemoteService(this);
            Register("ClanMemberStatsRemoteService", clanMemberStats);
            Register("RateGameRemoteService", new CoreRemoteService(this, "RateGameRemoteService"));
            Register("OffersRemoteService", new CoreRemoteService(this, "OffersRemoteService"));
            Register("MarketplaceRemoteService", new MarketplaceRemoteService(this));
            Register("RentMarketRemoteService", new StartupRemoteService(this, "MenuBootstrap033RemoteService"));
            Register("InventoryRemoteService", new InventoryRemoteService(this));
            var rankedMatchmaking = new MatchmakingRemoteService(this);
            Register("MatchmakingRemoteService", rankedMatchmaking);
            Register("BoltMatchmakingApi", rankedMatchmaking);
           Register("RankedMatchmakingService", rankedMatchmaking);
            Register("IRankedMatchmakingService", rankedMatchmaking);
            Register("Axlebolt.Standoff.Matchmaking.RankedMatchmakingService", rankedMatchmaking);
            Register("MatchesRemoteService", new MatchesRemoteService(this));
            Register("FriendsRemoteService", new FriendsRemoteService(this));
            Register("AvatarRemoteService", new StartupRemoteService(this, "AvatarRemoteService"));
            Register("MenuBootstrap033RemoteService", new StartupRemoteService(this, "MenuBootstrap033RemoteService"));
            Register("TestAuthRemoteService", new ClientAuthRemoteService(this));
            Register("GameServerStatsRemoteService", new GameServerStatsRemoteService(this));
            Register("GameServerRemoteService", new GameServerRemoteService(this));
            Register("GameServerPlayerRemoteService", new GameServerPlayerRemoteService(this));
            var gameEvents = new GameEventRemoteService(this);
            Register("GameEventRemoteService", gameEvents);



            Register("GameServerGameEventRemoteService", gameEvents);
            Register("ChatRemoteService", new ChatRemoteService(this));
            var clans = new ClanRemoteService(this);
            Register("ClanRemoteService", clans);

            var clanMessages = new ClanMessagesRemoteService(this);
            Register("ClanMessagesRemoteService", clanMessages);
            Register("DlcRemoteService", new CoreRemoteService(this, "DlcRemoteService"));
            Register("GdprRemoteService", new CoreRemoteService(this, "GdprRemoteService"));
            Register("NewsFeedRemoteService", new CoreRemoteService(this, "NewsFeedRemoteService"));
            Register("SystemMessagesRemoteService", new StartupRemoteService(this, "SystemMessagesRemoteService"));
             Register("UnknownCompactRoute", new CompactRouteFallbackHandler(
                this, "UnknownCompactRoute"));
            Register("GameAnnouncementRemoteService", new CoreRemoteService(this, "GameAnnouncementRemoteService"));
            Register("ContentCreatorRemoteService", new CoreRemoteService(this, "ContentCreatorRemoteService"));
            Register("InAppRemoteService", new CoreRemoteService(this, "InAppRemoteService"));
            Register("AchievementRemoteService", new CoreRemoteService(this, "AchievementRemoteService"));
            Register("AccountLinkRemoteService", new CoreRemoteService(this, "AccountLinkRemoteService"));
            Register("ReferralRemoteService", new CoreRemoteService(this, "ReferralRemoteService"));

            BoltEventContract.SelfTestOnce();
        }

        public void InitializeEventSenders(string playerId)
        {
            _eventSenderInitWatch.Start();

            var list = new List<IEventSender>
            {
                 new PlayerInternalRemoteEventSender(this),
                new FriendsRemoteEventSender(this),
                new MatchmakingEventSender(this),
                new ClansRemoteEventSender(this),
                new ClanMessagesRemoteEventSender(this),
                new ClanStatsRemoteEventSender(this),
                new MessagesRemoteEventSender(this),
                new MarketplaceRemoteEventSender(this),
                new InventoryRemoteEventSender(this),
                new GameEventRemoteEventSender(this)
            };
            ServerState.SetConnectionEventSenders(playerId, TcpClient, list);

       }

        private readonly object _postHandshakeEventsLock = new();
        private string _postHandshakeEventsResponseId;
        private string _postHandshakeEventsPlayerId;

        public void SchedulePostHandshakeEvents(string responseId, string playerId)
        {
            if (string.IsNullOrWhiteSpace(responseId) || string.IsNullOrWhiteSpace(playerId))
                return;
            lock (_postHandshakeEventsLock)
            {
                _postHandshakeEventsResponseId = responseId;
                _postHandshakeEventsPlayerId = playerId;
            }
        }

        public void FlushEventSenders(string playerId, string source = "post-auth")
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;
            TspServer.RpcServer.Api.SocialEventDelivery.ReplayPending(playerId);
            TspServer.RpcServer.Api.SocialProfileEventBridge.ResyncFriendStatusesTo(playerId);
        }

        private void FlushScheduledEvents(string responseId)
        {
            string playerId = null;
            lock (_postHandshakeEventsLock)
            {
                if (string.IsNullOrWhiteSpace(responseId) ||
                   !string.Equals(responseId, _postHandshakeEventsResponseId, StringComparison.Ordinal))
                    return;
                playerId = _postHandshakeEventsPlayerId;
                _postHandshakeEventsResponseId = null;
                _postHandshakeEventsPlayerId = null;
            }
            FlushEventSenders(playerId, "handshake-response-sent");
        }

        private bool IsAlive()
        {
            lock (_stateLock)
            {
                try
                {
                    return TcpClient?.Client?.Connected == true && _clientConnected;
                }
                catch
                {
                    return false;
                }
            }
        }

        private Stream TransportStream
        {
           get
            {
                if (_transportStream == null)
                    throw new InvalidOperationException("transport unavailable");
                return _transportStream;
            }
         }

        private bool IsTlsHello()
        {
            try
            {
                Socket socket = TcpClient?.Client;
                if (socket == null)
                    return false;

                byte[] probe = new byte[3];
                int previousTimeout = socket.ReceiveTimeout;
                socket.ReceiveTimeout = Math.Max(1000, ServerOptions.Current.TlsHandshakeTimeoutMs);
               int received;
                try
               {
                    received = socket.Receive(probe, 0, probe.Length, SocketFlags.Peek);
                 }
                finally
                {
                     socket.ReceiveTimeout = previousTimeout;
               }
               bool tls = received >= 3 && probe[0] == 0x16 && probe[1] == 0x03;

                 return tls;
             }
            catch (SocketException)
            {
                return false;
            }
        }

       private async Task InitTransportAsync()
        {
            NetworkStream networkStream = TcpClient.GetStream();
            ServerOptions options = ServerOptions.Current;
            string mode = options.TlsMode ?? "auto";

            bool useTls = mode.Equals("on", StringComparison.OrdinalIgnoreCase);
           if (mode.Equals("auto", StringComparison.OrdinalIgnoreCase))
                useTls = IsTlsHello();

            if (!useTls)
            {
                _transportStream = networkStream;
                return;
            }
            string pfxPath = options.TlsPfxPath;
            if (string.IsNullOrWhiteSpace(pfxPath))
                throw new InvalidOperationException("tls pfx path missing");
            if (!Path.IsPathRooted(pfxPath))
                 pfxPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, pfxPath));
            if (!File.Exists(pfxPath))
                throw new FileNotFoundException("tls certificate not found", pfxPath);

            string pfxPassword = options.TlsPfxPassword ?? string.Empty;

            X509Certificate2 certificate;
            try
            {
                X509KeyStorageFlags flags = OperatingSystem.IsWindows()
                    ? X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable
                    : X509KeyStorageFlags.DefaultKeySet | X509KeyStorageFlags.Exportable;

                certificate = new X509Certificate2(pfxPath, pfxPassword, flags);
            }
            catch (CryptographicException) when (OperatingSystem.IsWindows())
            {

                try
                {
                    certificate = new X509Certificate2(
                        pfxPath,
                        pfxPassword,
                        X509KeyStorageFlags.UserKeySet |
                        X509KeyStorageFlags.PersistKeySet |
                        X509KeyStorageFlags.Exportable);
                }
                catch (CryptographicException userKeyError)
                {
                    throw new InvalidOperationException("tls certificate load failed", userKeyError);
                }
            }

            if (!certificate.HasPrivateKey)
            {
                certificate.Dispose();
                throw new InvalidOperationException("tls private key missing");
            }

            try
            {
                using RSA? rsa = certificate.GetRSAPrivateKey();
                if (rsa == null)
                    throw new InvalidOperationException(
                        "tls private key unavailable");
}
            catch
            {
                certificate.Dispose();
                throw;
            }

            var sslStream = new SslStream(networkStream, leaveInnerStreamOpen: false);

            using var timeoutCts = new CancellationTokenSource(options.TlsHandshakeTimeoutMs);
            var authOptions = new SslServerAuthenticationOptions
            {
                ServerCertificate = certificate,
                ClientCertificateRequired = false,

                EnabledSslProtocols = SslProtocols.Tls12,
                CertificateRevocationCheckMode = X509RevocationMode.NoCheck
            };

               try
            {
                await sslStream.AuthenticateAsServerAsync(authOptions, timeoutCts.Token)
                    .ConfigureAwait(false);
}
            catch (OperationCanceledException ex)
            {
                sslStream.Dispose();
                certificate.Dispose();
                throw new TimeoutException(
                    "tls handshake timeout",
                    ex
                );
            }
            catch (AuthenticationException ex)
            {
                sslStream.Dispose();
                certificate.Dispose();
                throw new InvalidOperationException(
                    "tls handshake failed",
                    ex);
            }
            catch (IOException ex)
            {
                sslStream.Dispose();
                certificate.Dispose();
                throw new InvalidOperationException(
                    "tls handshake failed",
                    ex);
            }

            _transportStream = sslStream;

        }

        public async Task RunAsync()
        {
            try
            {
               _clientConnected = true;

                await InitTransportAsync().ConfigureAwait(false);
                _ = ReceiveLoopAsync();

                while (_clientConnected)
                {
                    _clientConnected = IsAlive();

                    if (!_clientConnected)
                        return;

                    if (_responses.TryDequeue(out ResponseMessage response))
                    {
                        Interlocked.Decrement(ref _queuedResponseCount);
                        await SendResponse(response).ConfigureAwait(false);
                         continue;
                    }

                    if (_requests.TryDequeue(out RpcRequest request))
                    {
                        Interlocked.Decrement(ref _queuedRequestCount);
                        await DispatchAsync(request).ConfigureAwait(false);
                        continue;
                    }

                    await Task.Delay(50).ConfigureAwait(false);
               }
             }
            finally
            {
                CloseClient();
                RemoveUser();
            }
        }

        public async Task ReceiveLoopAsync()
        {
            await ProcessIncomingFramesAsync().ConfigureAwait(false);
        }

        public async Task ProcessIncomingFramesAsync()
        {

            while (_clientConnected)
            {
                 try
                {
                    int bodySize = await ReadFrameSizeAsync().ConfigureAwait(false);

                   if (bodySize < 0)
                    {
                        throw new InvalidDataException(
                            "invalid frame size"
                        );
                    }

                    int maxFrameBytes = ServerOptions.Current.MaxIncomingFrameBytes;
                    if (bodySize > maxFrameBytes)
                    {
                        throw new InvalidDataException(
                            "frame too large"
                       );
                    }

                    if (bodySize == 0)
                    {
                        await SendPong().ConfigureAwait(false);
                        continue;
                    }

                    byte[] body = new byte[bodySize];
                    using (var frameCts = new CancellationTokenSource(ServerOptions.Current.FrameBodyReadTimeoutMs))
                    {
                        int offset = 0;
                        while (offset < body.Length)
                        {
                            int read = await TransportStream.ReadAsync(
                                body.AsMemory(offset, body.Length - offset),
                                 frameCts.Token).ConfigureAwait(false);
                            if (read <= 0) throw new ReceiveException();
                            offset += read;
                       }
                    }

                    if (body.Length == 1)
                    {

                        MarkPongReceived();
                        await SendPong().ConfigureAwait(false);
                    }
                    else
                    {
                        ProcessIncomingFrame(body);
                    }
                }
                catch (ReceiveException)
                {
                    _clientConnected = false;
                }
                catch (ObjectDisposedException)
                {
                    _clientConnected = false;
                }
                catch (IOException)
                {

                    _clientConnected = false;
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine($"[bolt] {ex.GetType().Name}: {ex.Message}");
                    _clientConnected = false;
                }
            }

        }

        private void CloseClient()
        {

             try
            {
               _transportStream?.Close();
                _transportStream = null;
            }
            catch
            {
            }

            try
            {
                 TcpClient?.Close();
            }
            catch
            {
            }
        }

        private void RemoveUser()
        {
            TspServer.RpcServer.Api.MarketplaceEventBus.Unregister(this);
            TspServer.RpcServer.Api.BoltEvents.RemoveUser(this);

            string playerId = null;
            bool hadBinding = false;
            bool hasOtherConnection = false;

            lock (ServerState.UsersLock)
            {
                if (ServerState.Users.TryGetValue(TcpClient, out playerId) && !string.IsNullOrWhiteSpace(playerId))
                {
                   hadBinding = true;
                   ServerState.Users.Remove(TcpClient);
                    hasOtherConnection = ServerState.Users.Any(pair =>
                        string.Equals(pair.Value, playerId, StringComparison.Ordinal) && pair.Key != null);
                 }
            }

            if (!hadBinding)
            {
                return;
            }

            ServerState.RemoveConnectionEventSenders(TcpClient, playerId);

            MatchmakingRemoteService.OnUserDisconnected(this);

            if (hasOtherConnection)
            {
                return;
            }

            try
            {
                _eventSenderInitWatch.Stop();
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                if (ObjectId.TryParse(playerId, out ObjectId objectId))
                {

                    int elapsedSeconds = (int)Math.Floor(_eventSenderInitWatch.Elapsed.TotalSeconds);
                    boltMain.AddPlayerTime(objectId, elapsedSeconds);
                    PlayerDocument playerDocument = boltMain.GetPlayerDocument(objectId);
                    RpcServer.PlayerStatus stat = ServerState.GetOrCreatePlayerStatus(playerId);
                    if (stat.playInGame != null && stat.playInGame.lobbyId != "" &&
                        ServerState.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                    {
                        lobby.RemoveLobbyAny(playerDocument.GetBoltFriend());
                        ServerState.Lobbies[stat.playInGame.lobbyId] = lobby;
                        if (lobby.LobbyMembers.Length == 0)
                        {
                            ServerState.Lobbies.Remove(lobby.Id);
                        }
                       else
                        {
                             if (lobby.LobbyOwnerId == playerId)
                            {
                                ServerState.Lobbies[lobby.Id].LobbyOwnerId = lobby.LobbyMembers.First().Id;
                                foreach (BoltFriend player in lobby.LobbyMembers)
                                    if (ServerState.EventSenders.TryGetValue(player.Id, out List<IEventSender> eventSenders))
                                        eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)?.SendEvent("onLobbyOwnerChanged", new object[] { ServerState.Lobbies[lobby.Id].LobbyOwnerId });
                                foreach (BoltFriend player in lobby.LobbySpectators)
                                    if (ServerState.EventSenders.TryGetValue(player.Id, out List<IEventSender> eventSenders))
                                        eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)?.SendEvent("onLobbyOwnerChanged", new object[] { ServerState.Lobbies[lobby.Id].LobbyOwnerId });
                            }
                            foreach (BoltFriend player in lobby.LobbyMembers)
                                 if (ServerState.EventSenders.TryGetValue(player.Id, out List<IEventSender> eventSenders))
                                   eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)?.SendEvent("onPlayerLeftLobby", new object[] { playerId });
                            foreach (BoltFriend player in lobby.LobbySpectators)
                                if (ServerState.EventSenders.TryGetValue(player.Id, out List<IEventSender> eventSenders))
                                    eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)?.SendEvent("onPlayerLeftLobby", new object[] { playerId });
                        }
                    }
                }
            }
            catch
            {
           }

            var offlineStatus = new PlayerStatus
           {
                onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOffline,
                playInGame = null
            };
            ServerState.SetPlayerStatusSnapshot(playerId, offlineStatus);
           if (ObjectId.TryParse(playerId, out ObjectId offlineObjectId))
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(offlineObjectId, offlineStatus);
            TspServer.RpcServer.Api.SocialProfileEventBridge.BroadcastStatus(playerId, offlineStatus);
            lock (ServerState.EventSendersLock)
            {
               ServerState.EventSenders.Remove(playerId);
            }

        }
        private async Task<byte> ReadByteAsync()
        {
             byte[] array = new byte[1];
            if (await TransportStream.ReadAsync(array, 0, 1).ConfigureAwait(false) > 0)
            {
               return array[0];
            }
            throw new ClientSession.ReceiveException();
        }

        private async Task<int> ReadFrameSizeAsync()
        {
            byte[] networkHeader = new byte[4];
            for (int i = 0; i < networkHeader.Length; i++)
                networkHeader[i] = await ReadByteAsync().ConfigureAwait(false);

            if (networkHeader[0] == 0x16 && networkHeader[1] == 0x03)
            {

                throw new InvalidDataException(
                    "unexpected tls frame"
                );
            }

            int size = BinaryPrimitives.ReadInt32BigEndian(networkHeader);

            return size;
        }

        public void ProcessIncomingFrame(byte[] data)
        {
            if (!TryParseRpcRequest(data, out RpcRequest request, out WireEncoding encoding))
                throw new InvalidDataException("rpc decode failed");

            if (!string.IsNullOrWhiteSpace(request.Id))
                _requestWireEncodings[request.Id] = encoding;

            int queued = Interlocked.Increment(ref _queuedRequestCount);
            if (queued > ServerOptions.Current.MaxQueuedRequests)
            {
                Interlocked.Decrement(ref _queuedRequestCount);
                throw new InvalidDataException("request queue full");
            }

            _requests.Enqueue(request);
        }

        private bool TryParseRpcRequest(
            byte[] wireBody,
            out RpcRequest request,
            out WireEncoding encoding)
        {
            request = null;
            encoding = WireEncoding.Plain;

            if (TryParsePlainRequest(wireBody, out request))
            {
                RememberWireEncoding(WireEncoding.Plain);
                return true;
            }

            if (!ServerOptions.Current.EnableWireCrypto)
                return false;

            byte[] sessionKey;
            byte[] sessionIv;
            lock (_cryptoLock)
            {
                 sessionKey = _sessionKey == null ? null : (byte[])_sessionKey.Clone();
                 sessionIv = _sessionIv == null ? null : (byte[])_sessionIv.Clone();
            }

            if (sessionKey?.Length == 16 && sessionIv?.Length == 16 &&
                Protocol.TryDecryptAesCbc(wireBody, sessionKey, sessionIv, out byte[] sessionPlain) &&
                TryParsePlainRequest(sessionPlain, out request))
            {
                encoding = WireEncoding.SessionAes;
                RememberWireEncoding(encoding);
                return true;
            }

            if (Protocol.TryDecryptAesCbc(
                    wireBody,
                    Protocol.BootstrapKey,
                     Protocol.BootstrapIv,
                    out byte[] bootstrapPlain) &&
               TryParsePlainRequest(bootstrapPlain, out request))
            {
                encoding = WireEncoding.BootstrapAes;
                return true;
             }

            return false;
        }

        private void RememberWireEncoding(WireEncoding encoding)
        {
            lock (_cryptoLock)
            {
                if (!_sessionCryptoActive)
                    return;

                if (encoding != WireEncoding.Plain && encoding != WireEncoding.SessionAes)
                    return;

                if (_confirmedSessionWireEncoding == null)
                {
                   _confirmedSessionWireEncoding = encoding;
                }
            }
        }

        private bool TryParsePlainRequest(byte[] data, out RpcRequest request)
        {
            request = null;
            try
            {
                RpcRequest parsed = RpcRequest.Parser.ParseFrom(data ?? Array.Empty<byte>());
                if (parsed == null || string.IsNullOrWhiteSpace(parsed.Id))
                    return false;

                if (string.IsNullOrWhiteSpace(parsed.ServiceName) &&
                    string.IsNullOrWhiteSpace(parsed.MethodName))
                {
                   if (!TryRouteCompactRequest(parsed))
                    {
                        return false;
                    }
                }
                else if (string.IsNullOrWhiteSpace(parsed.ServiceName) ||
                         string.IsNullOrWhiteSpace(parsed.MethodName))
                {
                    return false;
                 }

                request = parsed;
                 return true;
            }
            catch
            {
                return false;
           }
        }

        private bool TryRouteCompactRequest(RpcRequest request)
        {
            if (request == null)
                return false;

            int paramCount = request.Params?.Count ?? 0;
             bool sessionPrepared;
            lock (_cryptoLock)
                sessionPrepared = _sessionKey?.Length == 16;

            bool connectionAuthenticated = false;
            try
            {
                connectionAuthenticated =
                     TcpClient != null &&
                    ServerState.Users.TryGetValue(TcpClient, out string authenticatedPlayerId) &&
                    !string.IsNullOrWhiteSpace(authenticatedPlayerId);
            }
            catch
            {
                connectionAuthenticated = false;
             }

            if (sessionPrepared && paramCount == 1)
            {
                 try
                {
                    BinaryValue dedicatedParam = request.Params[0];
                    if (MatchmakingRemoteService.LooksLikeDedicatedRankedStart(
                            dedicatedParam, out _))
                    {
                        request.ServiceName = "MatchmakingRemoteService";
                        request.MethodName = "start";
                         return true;
                    }
                }
                catch
                {
                }
             }
            if (sessionPrepared && paramCount == 1)
            {
                try
                {
                    string historyMatchId = ContractWire.ReadStringField(
                        ContractWire.Param(request), 1, string.Empty);
                    if (!string.IsNullOrWhiteSpace(historyMatchId) &&
                         historyMatchId.Length >= 32 &&
                        (historyMatchId.StartsWith("RankedDefuse_", StringComparison.OrdinalIgnoreCase) ||
                         historyMatchId.StartsWith("Ranked2v2_", StringComparison.OrdinalIgnoreCase) ||
                         historyMatchId.StartsWith("RankedDuel_", StringComparison.OrdinalIgnoreCase)))
                    {
                         request.ServiceName = "MatchesRemoteService";
                        request.MethodName = "getMatch";
                        return true;
                    }
                }
                catch
                {
                }
            }

           switch (request.Options)
            {

                 case 1 when !sessionPrepared && paramCount == 1:
                    request.ServiceName = "HelloRemoteService";
                    request.MethodName = "hello";
                    return true;

                case 315 when sessionPrepared && paramCount == 1:
                    request.ServiceName = "GoogleAuthRemoteService";
                    request.MethodName = "encryptedAuth2";
                    return true;

                case 3 when sessionPrepared && paramCount == 1:
                    request.ServiceName = "HandshakeRemoteService";
                    request.MethodName = "encryptedHandshake";
                    return true;

                case 23 when sessionPrepared && paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                    request.MethodName = "getPlayer2";
                    return true;

                case 5 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getPlayerProcessingRequests2";
                     return true;
                case 6 when sessionPrepared && connectionAuthenticated && paramCount == 0:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "confirm";
                    return true;
                case 6 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getMarketplaceSettings2";
                    return true;
                case 22 when paramCount == 1:
                    return RouteMenuBootstrap(request, "PlayerRemoteService", "getPlayerSettings2");

                case 51 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "setInventoryItemsPropertiesEncrypted";
                    return true;
                case 52 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "setInventoryItemFlagsEncrypted";
                    return true;
                case 53 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "getPlayerInventoryEncrypted";
                    return true;
                case 54 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "getInventoryItemDefinitionsEncrypted";
                    return true;
                case 55 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "getInventoryItemPropertyDefinitionsEncrypted";
                    return true;

                case 56 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "executeRecipeEncrypted2";
                    return true;
                case 57 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "buyInventoryItemEncrypted";
                    return true;
                case 58 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "mountInventoryItemEncrypted";
                    return true;
                case 59 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "unmountInventoryItemEncrypted";
                   return true;

                case 60 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "activateCouponEncrypted";
                    return true;
                 case 61 when paramCount == 1:
                   request.ServiceName = "InventoryRemoteService";
                    request.MethodName = "getOtherPlayerPublicItemsEncrypted";
                    return true;
               case 62 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getLobbyGameServer2";
                    return true;
                case 63 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getGameServerDetails2";
                    return true;
                case 64 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyName2";
                    return true;
                case 65 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyGameServer2";
                    return true;
                case 66 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "deleteLobbyData2";
                    return true;
                case 67 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "invitePlayerToLobby2";
                    return true;
                case 68 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getGameServerPlayers2";
                    return true;
               case 69 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "requestInternetServerList2";
                    return true;
                case 70 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyData2";
                    return true;
                case 542252353 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                     request.MethodName = "increaseMaxMembersCount2";
                     return true;
                case 125 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "leaveClan2";
                    return true;
                case 71 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                   request.MethodName = "setLobbyJoinable2";
                    return true;
                case 72 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                     request.MethodName = "getInvitesToLobby2";
                    return true;
                case 75 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "leaveLobby2";
                    return true;
                case 7 when sessionPrepared && connectionAuthenticated && paramCount == 0:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "cancel";
                    return true;
                case 7 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getPlayerOpenRequests2";
                    return true;

                case 8 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getTrade2";
                    return true;
                case 9 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                     request.MethodName = "createSale2";
                    return true;
                case 11 when paramCount == 1:
                     request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "createPurchaseRequest2";
                    return true;
                case 12 when paramCount == 1 &&
                    ContractWire.ReadStringField(ContractWire.Param(request), 1, string.Empty).Length == 32:
                   request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "createPurchaseRequestBySale2";
                    return true;
                case 12 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getPlayerClosedRequestsCount2";
                    return true;
                case 13 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "cancelRequest2";
                    return true;
               case 14 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getTradeOpenPurchaseRequests2";
                    return true;
                case 15 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getTradeOpenSaleRequests2";
                    return true;
                case 10 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getPlayerClosedRequests2";
                    return true;
                case 16 when paramCount == 1:
                    request.ServiceName = "MarketplaceRemoteService";
                    request.MethodName = "getTrades2";
                   return true;
                case 20 when paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                    request.MethodName = "setAwayStatus2";
                    return true;
                case 21 when paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                    request.MethodName = "setOnlineStatus2";
                    return true;
                case 25 when paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                    request.MethodName = "setPlayerAvatar2";
                    return true;
                case 26 when paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                   request.MethodName = "setPlayerName2";
                     return true;
               case 28 when paramCount == 1:
                    request.ServiceName = "PlayerRemoteService";
                    request.MethodName = "setDefaultAvatar";
                    return true;
                case 41 when paramCount == 1:
                    request.ServiceName = "BoltRemoteService";
                    request.MethodName = "subscribe2";
                    return true;
               case 42 when paramCount == 1:
                    request.ServiceName = "BoltRemoteService";
                    request.MethodName = "unsubscribe2";
                    return true;
                case 73 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "invitePlayerToLobbyAs2";
                    return true;
                case 74 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "sendLobbyChatMsg2";
                    return true;
                case 76 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "joinLobbyAs2";
                    return true;
                case 77 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "createLobbyWithSpectators2";
                     return true;
                case 78 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyMaxMembers2";
                    return true;
                case 79 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "searchLobby";
                    return true;
                case 80 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyPhotonGame2";
                    return true;
                case 81 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyType2";
                    return true;
                case 82 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getLobby2";
                    return true;
                case 83 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyMaxSpectators2";
                    return true;
                case 84 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                     request.MethodName = "kickPlayerFromLobby2";
                    return true;
                 case 85 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "refuseInvitationToLobby2";
                    return true;
                case 86 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "revokePlayerInvitationToLobby2";
                    return true;
                case 87 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                     request.MethodName = "changeLobbyOtherPlayerType2";
                    return true;
                 case 88 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "setLobbyOwner2";
                    return true;
                case 89 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "changeLobbyPlayerType2";
                    return true;
                case 90 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "joinLobby2";
                    return true;
                case 91 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "requestLobbyList2";
                    return true;
                case 92 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getLobbyMembers2";
                     return true;
                case 93 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getLobbyPhotonGame2";
                    return true;
                case 94 when paramCount == 1:
                    request.ServiceName = "MatchmakingRemoteService";
                    request.MethodName = "getLobbyOwner2";
                    return true;
                case 101 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClan2";
                    return true;
                case 102 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ClanRemoteService", "getRoles2");
                case 103 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ClanRemoteService", "getClanSettings2");
                case 104 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getPlayerInviteRequestsCount2";
                    return true;
                case 105 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getPlayerClosedJoinRequestsCount2";
                    return true;
                 case 109 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getRecommendedClans2";
                    return true;
               case 111 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "requestToJoinClan2";
                    return true;
                case 112 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getPlayerInviteRequests2";
                    return true;
                case 113 when paramCount == 1:
                     request.ServiceName = "ClanRemoteService";
                   request.MethodName = "getClanById2";
                    return true;
                case 114 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getPlayerJoinRequests2";
                    return true;
                case 115 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "findClan2";
                    return true;
                case 117 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "deleteClosedJoinRequest2";
                   return true;
                case 118 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "validateClanTag2";
                     return true;

                case 119 when paramCount == 1 &&
                   !string.IsNullOrWhiteSpace(ContractWire.ReadStringField(ContractWire.Param(request), 2, string.Empty)):
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "createClan2";
                    return true;
                case 120 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "declineJoinRequest2";
                    return true;
                case 121 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "cancelJoinRequest2";
                    return true;
                case 123 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "deleteClosedInviteRequest2";
                    return true;
                case 126 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "kickMember2";
                    return true;
                case 129 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanByTag";
                    return true;
                case 133 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "cancelInviteRequest2";
                   return true;
                case 134 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "assignRoleToMember2";
                    return true;
                case 135 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "assignLeaderRole2";
                    return true;
               case 127 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "setClanDescription2";
                   return true;
                case 128 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "setClanAvatar2";
                    return true;
                case 130 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                     request.MethodName = "increaseMaxMembersCount2";
                   return true;
                case 132 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "changeClanType2";
                    return true;
                case 131 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "createClan2";
                    return true;
                case 122 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "inviteToClan2";
                    return true;
                case 124 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "validateClanName2";
                    return true;

                case 150 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "getPlayerFriends2";
                    return true;
                case 151 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "getPlayerFriendById2";
                    return true;
                case 152 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "getPlayerFriendsIds2";
                     return true;
                case 153 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "sendFriendRequest2";
                    return true;
                case 154 when paramCount == 1:
                     request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "searchPlayers2";
                    return true;
                case 155 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "revokeFriendRequest2";
                    return true;
                case 156 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "acceptFriendRequest2";
                    return true;
                case 157 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                   request.MethodName = "removeFriend2";
                    return true;
                case 158 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "ignoreFriendRequest2";
                    return true;
                case 159 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "blockFriend2";
                    return true;
                case 160 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "unblockFriend2";
                    return true;
                case 161 when paramCount == 1:
                    request.ServiceName = "FriendsRemoteService";
                    request.MethodName = "getPlayerFriendByUid2";
                    return true;
                case 172 when paramCount == 1:
                    return RouteMenuBootstrap(request, "StorageRemoteService", "readFiles");
                case 180 when paramCount == 1:
                    request.ServiceName = "PlayerStatsRemoteService";
                    request.MethodName = "storeStats2";
                    return true;
                case 181 when paramCount == 1:
                    request.ServiceName = "PlayerStatsRemoteService";
                    request.MethodName = "getCurrentStats";
                    return true;
                case 182 when paramCount == 1:
                    request.ServiceName = "PlayerStatsRemoteService";
                    request.MethodName = "getPlayerStats2";
                     return true;
                case 190 when paramCount == 1:
                     request.ServiceName = "ChatRemoteService";
                    request.MethodName = "getChatUsersLite";
                    return true;
                case 191 when paramCount == 1:
                    request.ServiceName = "ChatRemoteService";
                    request.MethodName = "getFriendMsgsByOffset2";
                    return true;
                case 192 when paramCount == 1:
                    request.ServiceName = "ChatRemoteService";
                    request.MethodName = "sendFriendMsg2";
                    return true;
                case 193 when paramCount == 1:
                    request.ServiceName = "ChatRemoteService";
                    request.MethodName = "readFriendMsgs2";
                    return true;
                case 194 when paramCount == 1:
                    request.ServiceName = "ChatRemoteService";
                    request.MethodName = "getChatUser";
                    return true;
                case 195 when paramCount == 1:
                    request.ServiceName = "ChatRemoteService";
                    request.MethodName = "deleteFriendMsgs2";
                    return true;
                case 110 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanMembersById2";
                    return true;
                case 116 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanJoinRequests2";
                    return true;
                case 119 when paramCount == 1 &&
                    string.IsNullOrWhiteSpace(ContractWire.ReadStringField(ContractWire.Param(request), 2, string.Empty)):
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanInviteRequests2";
                    return true;
                case 241 when paramCount == 1:
                    request.ServiceName = "ClanStatsRemoteService";
                    request.MethodName = "getClanStats";
                    return true;

               case 0 when connectionAuthenticated && paramCount == 1 && ContractWire.Param(request).Length == 0:
                    request.ServiceName = "GameSeasonRemoteService";
                    request.MethodName = "getGameSeasons2";
                    return true;
                case 325 when paramCount == 1:
                    request.ServiceName = "SeasonalStatsRemoteService";
                    request.MethodName = "getPlayerStatsForSeason";
                    return true;
                case 326 when paramCount == 1:
                    request.ServiceName = "SeasonalStatsRemoteService";
                    request.MethodName = "getStatsForSeason";
                    return true;
                case 327 when paramCount == 1:
                    request.ServiceName = "SeasonalStatsRemoteService";
                    request.MethodName = "getCurrentClanStatsForSeason";
                    return true;
                case 328 when paramCount == 1:
                    request.ServiceName = "SeasonalStatsRemoteService";
                    request.MethodName = "getClanStatsForSeason";
                    return true;
                case 106 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanJoinRequestsCount2";
                    return true;
                case 107 when paramCount == 1:
                    request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanClosedInviteRequestsCount2";
                    return true;
                case 108 when paramCount == 1:
                     request.ServiceName = "ClanRemoteService";
                    request.MethodName = "getClanMembers2";
                   return true;
                case 202 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ClanMessagesRemoteService", "getUnreadChatMessagesCount2");
               case 203 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                    request.MethodName = "getClanChatMessages2";
                    return true;
                case 204 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                   request.MethodName = "readClanChatMessages2";
                    return true;
                case 205 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                    request.MethodName = "sendClanChatMessage2";
                    return true;
                case 206 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                    request.MethodName = "readClanLogMessages2";
                    return true;
                case 207 when paramCount == 1:
                     request.ServiceName = "ClanMessagesRemoteService";
                    request.MethodName = "getClanLogMessages2";
                    return true;
                case 208 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                     request.MethodName = "getClanMessages2";
                    return true;

                case 214 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "claimAllRewardsOfSpecificPasses");
                case 215 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getPlayerGameEventsProgresses");
                case 216 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getCachedPlayerGameEvents");
                case 217 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getCurrentChallenges");
                case 218 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getPlayerCurrentGameEvents");
                case 219 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "setChallengeProgress");
                case 220 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "claimSpecificLevelReward");
               case 221 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "saveChallenge2");
               case 222 when paramCount == 1:
                     return RouteMenuBootstrap(request, "GameEventRemoteService", "progressGameEvent");
                case 223 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getAllChallenges");
                case 224 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameEventRemoteService", "getPlayerGameEventProgress");
                case 225 when paramCount == 1:
                    return RouteMenuBootstrap(request, "DlcRemoteService", "getAllDlc");
                case 226 when paramCount == 1:
                    return RouteMenuBootstrap(request, "DlcRemoteService", "getAllReleasedDlc");
                case 240 when paramCount == 1:
                   request.ServiceName = "ClanStatsRemoteService";
                    request.MethodName = "getCurrentClanStats";
                    return true;
                case 247 when paramCount == 1:
                    return RouteMenuBootstrap(request, "RateGameRemoteService", "dontAskLater");
                case 248 when paramCount == 1:
                     return RouteMenuBootstrap(request, "RateGameRemoteService", "rateGame");
                case 249 when paramCount == 1:
                    return RouteMenuBootstrap(request, "RateGameRemoteService", "askLater");
                case 250 when paramCount == 1:
                    return RouteMenuBootstrap(request, "RateGameRemoteService", "getLastRateGame");
                case 260 when paramCount == 1:
                    return RouteMenuBootstrap(request, "AccountLinkRemoteService", "getLinkedAuth");
                case 265 when paramCount == 1:
                    return RouteMenuBootstrap(request, "AchievementRemoteService", "getCurrentPlayerAchievements");
                case 280 when paramCount == 1:
                    return RouteMenuBootstrap(request, "GameAnnouncementRemoteService", "getAllAnnouncements");
                case 295 when paramCount == 1:
                    return RouteMenuBootstrap(request, "NewsFeedRemoteService", "getItems2");
                case 300 when paramCount == 1:
                    return RouteMenuBootstrap(request, "OffersRemoteService", "getSpecialOffers");

               case 264 when paramCount == 1:
                    return RouteMenuBootstrap(request, "AchievementRemoteService", "getAchievementDefinitions");
                case 266 when paramCount == 1:
                    return RouteMenuBootstrap(request, "AchievementRemoteService", "getPlayerAchievements");
                case 296 when paramCount == 1:
                    return RouteMenuBootstrap(request, "NewsFeedRemoteService", "sendNews");
                case 307 when paramCount == 1:
                    request.ServiceName = "SystemMessagesRemoteService";
                    request.MethodName = "getSystemMessageDetails";
                    return true;
                case 308 when paramCount == 1:
                    request.ServiceName = "SystemMessagesRemoteService";
                    request.MethodName = "readSystemMessages";
                    return true;
                case 309 when paramCount == 1:
                    request.ServiceName = "SystemMessagesRemoteService";
                   request.MethodName = "deleteSystemMessages";
                    return true;

                case 1071717263 when paramCount == 1:
                    request.ServiceName = "ContentCreatorRemoteService";
                    request.MethodName = "findCreator";
                    return true;
                case 310 when paramCount == 1:
                    request.ServiceName = "ContentCreatorRemoteService";
                    request.MethodName = "subscribeCreator";
                    return true;
                case 311 when paramCount == 1:
                    request.ServiceName = "ContentCreatorRemoteService";
                    request.MethodName = "getSubscribedCreator";
                    return true;
                case 312 when paramCount == 1:
                    request.ServiceName = "ContentCreatorRemoteService";
                    request.MethodName = "unsubscribeCreator";
                    return true;
                case 313 when paramCount == 1:
                    request.ServiceName = "ContentCreatorRemoteService";
                    request.MethodName = "findCreator";
                    return true;
                case 443 when paramCount == 1:
                    return RouteMenuBootstrap(request, "RentMarketRemoteService", "getRentMarketSettings");
                case 460 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ReferralRemoteService", "getPlayerState");
                case 461 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ReferralRemoteService", "subscribeToCommander");
                case 462 when paramCount == 1:
                   return RouteMenuBootstrap(request, "ReferralRemoteService", "getRecruitById");
                case 463 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ReferralRemoteService", "getRecruitsByOffset");
                case 464 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ReferralRemoteService", "findReferralState");
               case 465 when paramCount == 1:
                    return RouteMenuBootstrap(request, "ReferralRemoteService", "getSettings");
                case 389771019 when paramCount == 1:

                    request.ServiceName = "ClanMemberStatsRemoteService";
                    request.MethodName = "getClanMembersStats2";
                    return true;
                case 23620487 when paramCount == 2:
                    request.ServiceName = "StorageRemoteService";
                     request.MethodName = "writeFile";
                    return true;
                case 713847037 when paramCount == 1:
                    return RouteMenuBootstrap(request, "InAppRemoteService", "findCreatorSubscription");
                 case 1084093307 when paramCount == 1:
                    request.ServiceName = "InventoryRemoteService";
                   request.MethodName = "getRecipeStatusEncrypted";
                    return true;
                case 1100040608 when paramCount == 1:
                    request.ServiceName = "MatchesRemoteService";
                    request.MethodName = "getPlayerMatches";
                    return true;
                case 1444664024 when paramCount == 1:
                    request.ServiceName = "AvatarRemoteService";
                    request.MethodName = "getAvatars2";
                    return true;
                case 1678720367 when paramCount == 1:
                    request.ServiceName = "MatchesRemoteService";
                    request.MethodName = "getCurrentPlayerLastMatch";
                    return true;

                case 275 when paramCount == 1:
                   request.ServiceName = "AvatarRemoteService";
                   request.MethodName = "getDefaultAvatars";
                    return true;

                case 201 when paramCount == 1:
                    request.ServiceName = "ClanMessagesRemoteService";
                    request.MethodName = "getUnreadLogMessagesCount2";
                    return true;

                case 305 when paramCount == 1:
                    request.ServiceName = "SystemMessagesRemoteService";
                   request.MethodName = "getSystemMessages";
                    return true;
                case 306 when paramCount == 1:
                    request.ServiceName = "SystemMessagesRemoteService";
                    request.MethodName = "countUnreadSystemMessages";
                     return true;

                case 285 when paramCount == 1:
                     request.ServiceName = "GameSettingsRemoteService";
                     request.MethodName = "getGameSettingsEncrypted2";
                    return true;

                case 1:
                    return false;

                case 315:
                    return false;

                case 3:
                    return false;

                case 23:
                    return false;

                default:
                    if (paramCount == 1)
                    {
                        try
                        {
                            BinaryValue dedicatedParam = request.Params[0];
                            if (MatchmakingRemoteService.LooksLikeDedicatedRankedStart(
                                    dedicatedParam, out _))
                            {
                                request.ServiceName = "MatchmakingRemoteService";
                                request.MethodName = "start";
                               return true;
                            }
                        }
                        catch
                        {
                       }
                    }

                    if (paramCount == 0 &&
                        _rpcHandlers.TryGetValue("MatchmakingRemoteService", out RpcHandler rankedHandler) &&
                        rankedHandler is MatchmakingRemoteService rankedService &&
                        rankedService.TryResolveDedicatedZeroParam(out string rankedMethod))
                    {
                        request.ServiceName = "MatchmakingRemoteService";
                         request.MethodName = rankedMethod;
                        return true;
                     }

                    if (paramCount == 1)
                    {
                        try
                         {
                            string creatorCode = ContractWire.ReadStringField(
                                ContractWire.Param(request), 1, string.Empty).Trim().ToUpperInvariant();
                            if (!string.IsNullOrWhiteSpace(creatorCode) &&
                                CoreRemoteService.IsKnownCreatorCode(creatorCode))
                            {
                                request.ServiceName = "ContentCreatorRemoteService";
                                request.MethodName = "subscribeCreator";
                                return true;
                            }
                        }
                       catch
                        {

                       }
                    }

                     if (paramCount == 1 &&
                         BootstrapContracts.LooksLikeLanguagePlayerSettingsWrite(request, out _))
                    {
                        request.ServiceName = "PlayerRemoteService";
                        request.MethodName = "setPlayerSettings2";
                        return true;
                    }

                    request.ServiceName = "UnknownCompactRoute";
                    request.MethodName = "route_" + request.Options;
                    return true;
            }
        }

        private bool RouteMenuBootstrap(
            RpcRequest request,
            string observedService,
            string observedMethod)
        {

            bool useRuntimeService = observedService switch
            {
                "DlcRemoteService" => true,
                 "GameEventRemoteService" => true,
                "RateGameRemoteService" => true,
                "AccountLinkRemoteService" => true,
                "AchievementRemoteService" => true,
                "GameAnnouncementRemoteService" => true,
                "NewsFeedRemoteService" => true,
                "OffersRemoteService" => true,
                "ReferralRemoteService" => true,
                "InAppRemoteService" => true,
                _ => false
            };

            request.ServiceName = useRuntimeService
                ? observedService
                : "MenuBootstrap033RemoteService";
            request.MethodName = observedMethod;
            return true;
        }

        public static byte[] WrapHeader(byte[] body)
        {
            byte[] bytes = BitConverter.GetBytes(body.Length);
            Array.Reverse(bytes);
            byte[] result;
            using (MemoryStream memoryStream = new MemoryStream(4 + body.Length))
            {
                memoryStream.Write(bytes, 0, bytes.Length);
                memoryStream.Write(body, 0, body.Length);
                result = memoryStream.ToArray();
            }
            return result;
        }
        private async Task SendResponse(ResponseMessage response)
        {
            byte[] protobuf = response?.ToByteArray() ?? Array.Empty<byte>();
            string responseId = response?.RpcResponse?.Id;
            WireEncoding encoding = GetResponseEncoding(responseId);
            byte[] wireBody = EncodeResponse(protobuf, encoding);
            byte[] framed = ClientSession.WrapHeader(wireBody);

            await _sendLock.WaitAsync().ConfigureAwait(false);

            try
            {
               Stream stream = TransportStream;
                await stream.WriteAsync(framed, 0, framed.Length).ConfigureAwait(false);
                await stream.FlushAsync().ConfigureAwait(false);

                ActivateSessionCrypto(responseId);

                FlushScheduledEvents(responseId);
                if (!string.IsNullOrWhiteSpace(responseId))
                    _requestWireEncodings.TryRemove(responseId, out _);
            }
            catch
            {

                _clientConnected = false;
                throw;
            }
            finally
             {
                _sendLock.Release();
            }
        }

        private WireEncoding GetResponseEncoding(string responseId)
        {

            if (!string.IsNullOrWhiteSpace(responseId) &&
                _requestWireEncodings.TryGetValue(responseId, out WireEncoding requestEncoding))
           {
                 return requestEncoding;
             }

           lock (_cryptoLock)
            {
                if (_sessionCryptoActive && _confirmedSessionWireEncoding.HasValue)
                    return _confirmedSessionWireEncoding.Value;
            }

             return WireEncoding.Plain;
         }

        private byte[] EncodeResponse(byte[] protobuf, WireEncoding encoding)
        {
            if (!ServerOptions.Current.EnableWireCrypto || encoding == WireEncoding.Plain)
                return protobuf;

            if (encoding == WireEncoding.BootstrapAes)
                return Protocol.EncryptAesCbc(protobuf, Protocol.BootstrapKey, Protocol.BootstrapIv);

            byte[] key;
            byte[] iv;
            lock (_cryptoLock)
           {
                key = _sessionKey == null ? null : (byte[])_sessionKey.Clone();
                iv = _sessionIv == null ? null : (byte[])_sessionIv.Clone();
            }

            if (key?.Length != 16 || iv?.Length != 16)
                throw new InvalidOperationException("session key unavailable");

            return Protocol.EncryptAesCbc(protobuf, key, iv);
        }

        private void ActivateSessionCrypto(string responseId)
       {
            if (string.IsNullOrWhiteSpace(responseId))
                return;

            lock (_cryptoLock)
            {
                if (responseId != _activateSessionAfterResponseId)
                    return;

                _sessionCryptoActive = true;
                _activateSessionAfterResponseId = null;
            }

        }

        public long RequestTimeout { get; set; } = 10000L;

        public void SendResponse(
            ResponseMessage request,
            CancellationToken ct = default(CancellationToken))
        {
             if (request == null)
            {
                return;
            }

            int queued = Interlocked.Increment(ref _queuedResponseCount);
            if (queued > ServerOptions.Current.MaxQueuedResponses)
            {
                Interlocked.Decrement(ref _queuedResponseCount);
                _clientConnected = false;
                return;
            }
            _responses.Enqueue(request);

        }

        private async Task DispatchAsync(RpcRequest request)
        {
            try
            {
                if (request == null)
                {
                    return;
                }

                if (!_rpcHandlers.TryGetValue(request.ServiceName, out RpcHandler handler))
                {

                    if (request.Params != null && request.Params.Count == 1 &&
                         MatchmakingRemoteService.LooksLikeDedicatedRankedStart(
                            request.Params[0], out _) &&
                        _rpcHandlers.TryGetValue("MatchmakingRemoteService", out RpcHandler recoveredRanked))
                    {
                        request.ServiceName = "MatchmakingRemoteService";
                        request.MethodName = "start";
                        handler = recoveredRanked;
                    }
                   else
                    {

                        SendResponse(
                        new ResponseMessage
                        {
                            RpcResponse = new RpcResponse
                            {
                                Id = request.Id,
                                Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                {
                                    Id = BitConverter.ToInt64(
                                        Guid.NewGuid().ToByteArray(),
                                        8
                                     ),
                                    Code = 404
                                 }
                            }
                        }
                        );

                        return;
                    }
                }

                await handler.InvokeAsync(request).ConfigureAwait(false);

            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[rpc] {request?.ServiceName}.{request?.MethodName}: {ex.Message}");

                if (request != null)
                {
                    SendResponse(
                        new ResponseMessage
                        {
                            RpcResponse = new RpcResponse
                            {
                                Id = request.Id,
                                Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                {
                                   Id = BitConverter.ToInt64(
                                        Guid.NewGuid().ToByteArray(),
                                        8
                                    ),
                                    Code = 5555
                                }
                            }
                        }
                    );
                }
            }
        }

        public void MarkPongReceived()
        {
        }

        private async Task SendPong()
        {
            byte[] body = new byte[] { 1 };
           byte[] framed = ClientSession.WrapHeader(body);

            await _sendLock.WaitAsync().ConfigureAwait(false);

           try
            {
                 Stream stream = TransportStream;
                await stream.WriteAsync(framed, 0, framed.Length).ConfigureAwait(false);
                await stream.FlushAsync().ConfigureAwait(false);

            }
            catch
            {
                _clientConnected = false;
                throw;
           }
            finally
             {
                _sendLock.Release();
            }
        }

        private readonly ConcurrentQueue<RpcRequest> _requests;
       private readonly ConcurrentQueue<ResponseMessage> _responses;
        private class ReceiveException : SocketException
         {
        }
        public TcpClient TcpClient { get; private set; }
    }
}
