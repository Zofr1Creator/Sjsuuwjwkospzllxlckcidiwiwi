using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TspServer.RpcServer
{

    internal static class ContentHttpServer
   {
        private static int _started;
        private static TcpListener _listener;
        private static string _root;
        private static readonly SemaphoreSlim ClientSlots = new SemaphoreSlim(64, 64);

        public static void Start()
        {
            if (Interlocked.Exchange(ref _started, 1) != 0) return;
            bool enabled = ReadBool("BOLT_CONTENT_HTTP_ENABLED", true);
            if (!enabled)
            {
                return;
            }

            int port = ReadInt("BOLT_CONTENT_HTTP_PORT", 2234);
            string workingRoot = Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, "Content"));
            string outputRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "Content"));
            _root = Directory.Exists(workingRoot) ? workingRoot : outputRoot;
            Directory.CreateDirectory(_root);
            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start();
            _ = Task.Run(AcceptLoopAsync);
        }

        private static async Task AcceptLoopAsync()
        {
            while (_listener != null)
            {
                TcpClient client = null;
                 try
                {
                    client = await _listener.AcceptTcpClientAsync().ConfigureAwait(false);
                    if (!await ClientSlots.WaitAsync(0).ConfigureAwait(false))
                    {
                        try { client.Dispose(); } catch { }
                        continue;
                    }
                    TcpClient accepted = client;
                    _ = Task.Run(() =>
                    {
                        try { HandleClient(accepted); }
                        finally { ClientSlots.Release(); }
                    });
                }
                catch (ObjectDisposedException) { return; }
                 catch (System.Exception)
                {
                    client?.Dispose();
                    await Task.Delay(100).ConfigureAwait(false);
               }
            }
        }

        private static void HandleClient(TcpClient client)
        {
            using (client)
            using (NetworkStream stream = client.GetStream())
            {
                stream.ReadTimeout = 5000;
                stream.WriteTimeout = 5000;
                string requestLine = ReadRequestLine(stream);
                if (string.IsNullOrWhiteSpace(requestLine)) return;
                string[] parts = requestLine.Split(' ');
                if (parts.Length < 2 || (!string.Equals(parts[0], "GET", StringComparison.OrdinalIgnoreCase) &&
                                         !string.Equals(parts[0], "HEAD", StringComparison.OrdinalIgnoreCase)))
                {
                    WriteStatus(stream, 405, "Method Not Allowed", "text/plain", Array.Empty<byte>(), false);
                    return;
                }

                string rawPath = parts[1].Split('?')[0];
                string decoded = Uri.UnescapeDataString(rawPath).Replace('\\', '/').TrimStart('/');
                if (decoded.Length == 0) decoded = "health.txt";
                string fullPath = Path.GetFullPath(Path.Combine(_root, decoded));
                if (!fullPath.StartsWith(_root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(fullPath, _root, StringComparison.OrdinalIgnoreCase))
                {
                    WriteStatus(stream, 403, "Forbidden", "text/plain", Array.Empty<byte>(), false);
                     return;
                }
                if (!File.Exists(fullPath))
                {
                   WriteStatus(stream, 404, "Not Found", "text/plain", Encoding.UTF8.GetBytes("not found"), parts[0] == "HEAD");
                    return;
                }

                byte[] body = File.ReadAllBytes(fullPath);
                WriteStatus(stream, 200, "OK", ContentType(fullPath), body, parts[0] == "HEAD");
            }
         }

        private static string ReadRequestLine(NetworkStream stream)
        {
            using var buffer = new MemoryStream();
            int previous = -1;
             for (int i = 0; i < 8192; i++)
            {
                int current = stream.ReadByte();
                if (current < 0) break;
                if (previous == '\r' && current == '\n') break;
                if (previous >= 0) buffer.WriteByte((byte)previous);
                previous = current;
            }
            return Encoding.ASCII.GetString(buffer.ToArray()).Trim();
        }

        private static void WriteStatus(NetworkStream stream, int code, string reason, string contentType, byte[] body, bool headOnly)
        {
            body ??= Array.Empty<byte>();
            string headers = $"HTTP/1.1 {code} {reason}\r\n" +
                             $"Content-Type: {contentType}\r\n" +
                             $"Content-Length: {body.Length}\r\n" +
                             "Access-Control-Allow-Origin: *\r\n" +
                             "Cache-Control: public, max-age=60\r\n" +
                             "Connection: close\r\n\r\n";
            byte[] headerBytes = Encoding.ASCII.GetBytes(headers);
            stream.Write(headerBytes, 0, headerBytes.Length);
            if (!headOnly && body.Length > 0) stream.Write(body, 0, body.Length);
        }

        private static string ContentType(string path)
         {
            switch (Path.GetExtension(path).ToLowerInvariant())
            {
                case ".png": return "image/png";
                case ".jpg":
                case ".jpeg": return "image/jpeg";
                case ".webp": return "image/webp";
                case ".json": return "application/json; charset=utf-8";
                default: return "application/octet-stream";
            }
        }

        private static int ReadInt(string key, int fallback) =>
            int.TryParse(Environment.GetEnvironmentVariable(key), out int value) ? value : fallback;

        private static bool ReadBool(string key, bool fallback)
        {
            string raw = Environment.GetEnvironmentVariable(key);
           if (string.IsNullOrWhiteSpace(raw)) return fallback;
            return raw.Equals("1", StringComparison.OrdinalIgnoreCase) ||
                   raw.Equals("true", StringComparison.OrdinalIgnoreCase) ||
                   raw.Equals("yes", StringComparison.OrdinalIgnoreCase) ||
                   raw.Equals("on", StringComparison.OrdinalIgnoreCase);
        }
    }
}
