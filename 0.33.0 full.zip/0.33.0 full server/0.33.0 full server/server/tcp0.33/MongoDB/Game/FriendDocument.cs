using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using TspServer.MongoDB.Main;
using TspServer.RpcServer.Api;

namespace TspServer.MongoDB.Game
{
    public class FriendDocument : DocumentModelBase
    {
        public string playerInitiatorId { get; set; }
        public string playerId { get; set; }
       public RelationshipStatusCustom relationshipStatus { get; set; }
        public BsonDateTime lastTimeUpdate { get; set; }
        public string msg { get; set; } = string.Empty;

    }
    public enum RelationshipStatusCustom
    {
        None = 0,
        Blocked = 1,
        Request = 2,
        Friend = 3,
        Ignored = 4
    }
    public static class FriendHelper
   {
        public static RelationshipStatus GetRelationshipStatus(this RelationshipStatusCustom ex, bool isInitiator)
       {
            switch (ex)
            {
                case RelationshipStatusCustom.Request:
                    return isInitiator
                         ? RelationshipStatus.RequestInitiator
                         : RelationshipStatus.RequestRecipient;
                case RelationshipStatusCustom.None: return RelationshipStatus.None;
                case RelationshipStatusCustom.Blocked:
                   return isInitiator ? RelationshipStatus.Blocked : RelationshipStatus.None;
                case RelationshipStatusCustom.Friend:
                     return RelationshipStatus.Friend;
                case RelationshipStatusCustom.Ignored:

                    return isInitiator ? RelationshipStatus.None : RelationshipStatus.Ignored;
                default: throw new ArgumentOutOfRangeException("RelationshipStatusCustom");
            }
        }
        public static RelationshipStatusCustom GetRelationshipStatusCustom(this RelationshipStatus ex)
        {
            switch (ex)
            {
                case RelationshipStatus.RequestInitiator: return RelationshipStatusCustom.Request;
               case RelationshipStatus.RequestRecipient: return RelationshipStatusCustom.Request;
                case RelationshipStatus.None: return RelationshipStatusCustom.None;
                case RelationshipStatus.Blocked: return RelationshipStatusCustom.Blocked;
                case RelationshipStatus.Friend: return RelationshipStatusCustom.Friend;
                case RelationshipStatus.Ignored: return RelationshipStatusCustom.Ignored;
                default: throw new ArgumentOutOfRangeException("RelationshipStatusCustom");
             }
        }
        public static Player GetPlayer(string playerId)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
            return GetPlayer(playerDocument);
       }
        public static Player GetPlayer(PlayerDocument playerDocument)
        {
            if (playerDocument == null) return null;
           var player = new Player
           {
                Id = playerDocument._id.ToString(),
                Uid = playerDocument.uid ?? string.Empty,
                Name = playerDocument.name ?? string.Empty,
                AvatarId = playerDocument.avatarId ?? string.Empty,
                TimeInGame = playerDocument.timeInGame,
                RegistrationDate = playerDocument.createDate == null ? 0L : playerDocument.createDate.MillisecondsSinceEpoch,
                PlayerStatus = (TspServer.RpcServer.ServerState.GetPlayerStatusSnapshot(playerDocument._id.ToString()) ?? new RpcServer.PlayerStatus()).GetPlayerStatusProto()
            };
            PlayerProfileContract.Apply(player, playerDocument);
            return player;
        }
        public static PlayerFriend GetPlayerFriend(this FriendDocument a, string playerId)
        {
            bool viewerIsInitiator = string.Equals(a.playerInitiatorId, playerId, StringComparison.Ordinal);
            return new PlayerFriend
             {
                Player = viewerIsInitiator ? GetPlayer(a.playerId) : GetPlayer(a.playerInitiatorId),
                RelationshipStatus = a.relationshipStatus.GetRelationshipStatus(viewerIsInitiator),
                LastRelationshipUpdate = a.lastTimeUpdate?.MillisecondsSinceEpoch ?? 0L
            };
        }
        public static PlayerFriend GetPlayerFriend(this BoltFriend a)
        {
            return new PlayerFriend { Player = GetPlayer(a.GetPlayerDocument()), RelationshipStatus = RelationshipStatus.None, LastRelationshipUpdate = 0L };
        }
        public static PlayerFriend GetPlayerFriend(this PlayerDocument a)
        {
           return new PlayerFriend { Player = GetPlayer(a), RelationshipStatus = RelationshipStatus.None, LastRelationshipUpdate = 0 };
        }
        public static PlayerFriend GetPlayerFriend(this PlayerDocument a, string playerId)
        {
            List<PlayerFriend> playerFriends = GetPlayerFriends(playerId);
            PlayerFriend playerFriend = playerFriends.FirstOrDefault(e => e.Player.Id == a._id.ToString());
            return playerFriend != null ? playerFriend : a.GetPlayerFriend();
        }
        public static bool IsContainsFriend(this PlayerDocument a, string playerId)
        {
            List<PlayerFriend> playerFriends = GetPlayerFriends(playerId);
            PlayerFriend playerFriend = playerFriends.FirstOrDefault(e => e.Player.Id == a._id.ToString());
            return playerFriend != null && playerFriend.RelationshipStatus == RelationshipStatus.Friend;
        }
        public static List<PlayerFriend> GetPlayerFriends(string playerId)
        {
            List<FriendDocument> playerFriends = BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
            return playerFriends
                .Select(a => a.GetPlayerFriend(playerId))
                .Where(a => a != null)
                 .ToList();
        }
    }
}
