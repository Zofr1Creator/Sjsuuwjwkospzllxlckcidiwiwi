using System;
using System.Collections.Generic;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    [Serializable]
    public class BoltInventoryStarterPackDocument : BoltInventoryItemDocumentBase
    {
        public BsonArray items
        {
            get;
            set;
        }

        public BsonDocument currencies { get; set; }
    }

    [Serializable]
    public class BoltInventoryStarterPackElement
    {
        public int itemDefinitionId
        {
             get;
            set;
         }
        public BsonDocument GetBsonElement()
        {
            return new BsonDocument(new BsonElement[]
           {
                new BsonElement("itemDefinitionId", itemDefinitionId)
            } as IEnumerable<BsonElement>);
        }
    }

}
