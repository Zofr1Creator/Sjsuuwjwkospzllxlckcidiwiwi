using System.Collections.Generic;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    public struct BoltInventoryItemDefinitionCreationData
    {
        public string DisplayName;
        public int Key;
        public bool CanBeTraded;
        public bool Enabled;
        public int ItemType;
        public int GameId;
        public string MinGameVersion;

        public List<BsonElement> Properties;

        public BsonDocument GetDocument()
        {

            if (Properties == null)
            Properties = new List<BsonElement>(1);
            Properties.Add(new BsonElement("itemType", ItemType));

            return new BsonDocument(new BsonElement[]
            {
                new BsonElement("displayName", DisplayName),
                new BsonElement("key", Key),
                new BsonElement("canBeTraded", CanBeTraded),
                new BsonElement("enabled", Enabled),
               new BsonElement("gid", GameId),
                new BsonElement("properties", new BsonDocument(Properties)),
                 new BsonElement("penalty", new BsonDocument()),
                new BsonElement("buyPrice", new BsonArray()),
                new BsonElement("minGameVersion", MinGameVersion ?? string.Empty)
           } as IEnumerable<BsonElement>);
        }
    }

}
