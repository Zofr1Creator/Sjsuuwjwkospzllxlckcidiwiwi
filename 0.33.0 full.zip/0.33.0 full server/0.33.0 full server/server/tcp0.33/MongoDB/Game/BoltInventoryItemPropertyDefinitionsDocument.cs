using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    [Serializable]
    public class BoltInventoryItemPropertyDefinitionsDocument : BoltInventoryItemDocumentBase
    {
        public int key { get; set; }
        public BsonDocument definitions { get; set; }
        public InventoryItemPropertyDefinitions GetInventoryItemPropertyDefinitions()
        {
            var inv = new InventoryItemPropertyDefinitions { ItemDefinitionId = key };
            inv.Definitions.Add(definitions.ToDictionary(x => x.Name, x => x.Value.AsBsonDocument.ToPropertyDefinition(x.Name)));
            return inv;
        }
    }
    [Serializable]
    public class BoltInventoryItemPropertyDefinition
    {
        public PropertyType propertyType { get; set; }
        public bool saveInTrade { get; set; }
        public PropertySetByType setByType { get; set; }
        public static BsonDocument GetBsonElements(BoltInventoryItemPropertyDefinition source)
        {
            return new BsonDocument(new BsonElement[]
            {
                new BsonElement("propertyType", source.propertyType),
                new BsonElement("saveInTrade", source.saveInTrade),
                new BsonElement("setByType", source.setByType)
             } as IEnumerable<BsonElement>);
        }
        public enum PropertyType
        {
            Int = 0,
            Float = 1,
            String = 2,
            Boolean = 3
        }
        public enum PropertySetByType
        {
            GAME_SERVER = 0,
            OFFICAL_GAME_SERVER = 1,
           CLIENT = 2
        }
    }
}
