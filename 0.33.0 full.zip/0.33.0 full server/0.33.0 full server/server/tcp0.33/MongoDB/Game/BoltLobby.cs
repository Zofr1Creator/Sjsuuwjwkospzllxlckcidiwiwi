using System.Collections.Concurrent;
using Axlebolt.Bolt.Protobuf2;
using TspServer.Bolt;
using TspServer.MongoDB.Main;
using TspServer.RpcServer;

namespace TspServer.MongoDB.Game
{
    public class BoltLobby
{
     public enum LobbyType
    {
        Private = 0,
       FriendsOnly = 1,
        Public = 2,
        Invisible = 3
    }

    public string Id { get; internal set; }

    public string LobbyOwnerId
    {
        get => LobbyOwner.Id;
        internal set { LobbyOwner = LobbyMembers.First(bf => bf.Id == value); }
    }

    public BoltFriend LobbyOwner { get; private set; }
    public string Name { get; internal set; }

     public LobbyType Type { get; internal set; }

    public bool Joinable { get; internal set; }

    public int MaxMembers { get; internal set; }

    public int MaxSpectators { get; internal set; }

    private IDictionary<string, string> _data;

    public IDictionary<string, string> Data
     {
        get
       {
            _data ??= new ConcurrentDictionary<string, string>(StringComparer.Ordinal);
            return _data;
        }
        internal set => _data = value == null
            ? new ConcurrentDictionary<string, string>(StringComparer.Ordinal)
            : new ConcurrentDictionary<string, string>(value, StringComparer.Ordinal);
    }

    public static IDictionary<string, string> NormalizeLobbyData(IDictionary<string, string> source)
    {
        return source == null
            ? new ConcurrentDictionary<string, string>(StringComparer.Ordinal)
            : new ConcurrentDictionary<string, string>(source, StringComparer.Ordinal);
    }

    public ISet<string> DataVisibleInSearch { get; internal set; } =
         new HashSet<string>(StringComparer.Ordinal);

   public static bool IsRequiredLobbyKey(string key) => false;

    public string Messages { get; internal set; }
    public IDictionary<string, string> Mesagess { get; internal set; }

    public BoltFriend[] LobbyMembers { get; private set; }

   public BoltFriend[] LobbySpectators { get; private set; }

    public BoltFriend[] LobbyMemberInvites { get; private set; }

    public BoltFriend[] LobbySpectatorInvites { get; private set; }

    public GameServer GameServer { get; internal set; }

    public TspServer.RpcServer.PhotonGame PhotonGame { get; internal set; }

   public void TryRemoveMember(string id)
   {
        try
        {
            List<BoltFriend> playerDocuments = LobbyMembers.ToList();
            playerDocuments.RemoveAll(a => a.Id == id);
            LobbyMembers = playerDocuments.ToArray();
        }
        catch (System.Exception)
        {
       }
    }

    public void TryRemoveSpectator(string id)
   {
        try
        {
            List<BoltFriend> playerDocuments = LobbySpectators.ToList();
           playerDocuments.RemoveAll(a => a.Id == id);
            LobbySpectators = playerDocuments.ToArray();
         }
        catch (System.Exception)
        {
        }
    }

    public BoltLobby(string id, string lobbyOwnerId, string name, LobbyType type, bool joinable, int maxMembers,
        int maxSpectators, ConcurrentDictionary<string, string> data, List<BoltFriend> lobbyMembers,
        List<BoltFriend> lobbySpectators, List<BoltFriend> lobbyMemberInvites, List<BoltFriend> lobbySpectatorInvites,
        GameServer gameServer, TspServer.RpcServer.PhotonGame photonGame)
    {
        if (data == null)
        {
            throw new ArgumentNullException("data");
        }

        if (lobbyMembers == null)
         {
             throw new ArgumentNullException("lobbyMembers");
        }

        if (lobbySpectators == null)
        {
            throw new ArgumentNullException("lobbySpectators");
        }

        if (lobbyMemberInvites == null)
        {
            throw new ArgumentNullException("lobbyMemberInvites");
        }

        if (lobbySpectatorInvites == null)
        {
            throw new ArgumentNullException("lobbySpectatorInvites");
        }

        Id = id;
        Name = name;
        Type = type;
        Joinable = joinable;
        MaxMembers = maxMembers;
        MaxSpectators = maxSpectators;
        Data = data;
        Mesagess = new ConcurrentDictionary<string, string>();
        LobbyMembers = lobbyMembers.ToArray();
        LobbySpectators = lobbySpectators.ToArray();
       LobbyMemberInvites = lobbyMemberInvites.ToArray();
        LobbySpectatorInvites = lobbySpectatorInvites.ToArray();
        LobbyOwnerId = lobbyOwnerId;
        GameServer = gameServer;
        PhotonGame = photonGame;
    }

     public Lobby ToOriginal(string playerId)
    {
        Lobby lobby = new Lobby
         {
            Id = Id,
            OwnerGpid = LobbyOwnerId,
            Name = Name,
            LobbyType = EnumMapper<LobbyType, Axlebolt.Bolt.Protobuf2.LobbyType>.ToOriginal(Type),
            Joinable = Joinable,
            MaxMembers = MaxMembers,
            MaxSpectators = MaxSpectators,
            NumberOfMembers = LobbyMembers?.Length ?? 0,
            NumberOfSpectators = LobbySpectators?.Length ?? 0,
            Token = string.Empty,
            GameServer = GameServer,
            PhotonGame = PhotonGame != null ? RpcServer.PhotonGame.GetByDocument(PhotonGame) : null
        };
        lobby.Data.Add(Data);
        lobby.Members.Add(LobbyMembers.Select(a => a.GetPlayerDocument().GetPlayerFriend(playerId)));
        lobby.Spectators.Add(LobbySpectators.Select(a => a.GetPlayerDocument().GetPlayerFriend(playerId)));
        lobby.Invites.Add(LobbyMemberInvites.Select(a => a.GetPlayerDocument().GetPlayerFriend(playerId)));
        lobby.SpectatorInvites.Add(LobbySpectatorInvites.Select(a => a.GetPlayerDocument().GetPlayerFriend(playerId)));
        return lobby;
    }

    public bool IsLobbyMember(BoltFriend friend)
    {
        return LobbyMembers.Any(member => member.Id == friend.Id);
    }

   public bool IsLobbyMember(string memberId)
    {
        return LobbyMembers.Any(member => member.Id == memberId);
    }

    public bool IsLobbySpectator(BoltFriend friend)
    {
        return LobbySpectators.Any(member => member.Id == friend.Id);
    }

    public bool IsLobbySpectator(string spectatorId)
   {
        return LobbySpectators.Any(spectator => spectator.Id == spectatorId);
    }

    public bool IsMemberInvited(BoltFriend friend)
    {
        return LobbyMemberInvites.Any(invite => invite.Id == friend.Id);
    }

    public bool IsMemberInvited(string id)
    {
        return LobbyMemberInvites.Any(invite => invite.Id == id);
     }
     public bool IsSpectatorInvited(BoltFriend friend)
    {
        return LobbySpectatorInvites.Any(invite => invite.Id == friend.Id);
    }

    public bool IsSpectatorInvited(string id)
    {
        return LobbySpectatorInvites.Any(invite => invite.Id == id);
    }

    public BoltFriend GetLobbyAny(string id)
    {
        if (IsLobbyMember(id))
        {
            return LobbyMembers.First(member => member.Id == id);
        }

        if (IsLobbySpectator(id))
        {
            return LobbySpectators.First(member => member.Id == id);
        }

        return null;
    }

    public BoltFriend GetLobbyMember(string id)
    {
        return LobbyMembers.First(member => member.Id == id);
    }
    public BoltFriend GetLobbySpectator(string id)
     {
        return LobbySpectators.First(spectator => spectator.Id == id);
    }
     public BoltFriend GetLobbyAnyInvite(string id)
    {
        if (IsMemberInvited(id))
        {
            return LobbyMemberInvites.First(invite => invite.Id == id);
        }

        if (IsSpectatorInvited(id))
        {
            return LobbySpectatorInvites.First(invite => invite.Id == id);
        }

        return null;
    }

    public BoltFriend GetLobbyMemberInvite(string id)
    {
        return LobbyMemberInvites.First(invite => invite.Id == id);
    }

    public BoltFriend GetLobbySpectatorInvite(string id)
    {
        return LobbySpectatorInvites.First(invite => invite.Id == id);
    }

     internal void AddLobbyMember(BoltFriend member)
    {
        if (!IsLobbyMember(member))
        {
            LobbyMembers = new List<BoltFriend>(LobbyMembers) { member }.ToArray();
        }
    }

    internal void AddLobbySpectator(BoltFriend spectator)
    {
        if (!IsLobbySpectator(spectator))
        {
             LobbySpectators = new List<BoltFriend>(LobbySpectators) { spectator }.ToArray();
        }
    }

    public void ChangeMemberType(string id, LobbyPlayerType type)
    {
        if (type == LobbyPlayerType.Member)
       {
            var member = GetLobbySpectator(id);
           if (member != null)
            {
                RemoveLobbySpectator(member);
                AddLobbyMember(member);
                return;
            }
        }
        else if (type == LobbyPlayerType.Spectator)
       {
             var member = GetLobbyMember(id);
            if (member != null)
            {
                RemoveLobbyMember(member);
                AddLobbySpectator(member);
                return;
            }
        }
    }

   internal void RemoveLobbyAny(BoltFriend member)
    {
        RemoveLobbyMember(member);
        RemoveLobbySpectator(member);
     }

    internal void RemoveLobbyMember(BoltFriend member)
    {
        if (IsLobbyMember(member))
        {
            List<BoltFriend> list = new List<BoltFriend>(LobbyMembers);
            list.Remove(member);
            LobbyMembers = list.ToArray();
        }
     }

    internal void RemoveLobbySpectator(BoltFriend spectator)
    {
         if (IsLobbySpectator(spectator))
        {
            List<BoltFriend> list = new List<BoltFriend>(LobbySpectators);
            list.Remove(spectator);
            LobbySpectators = list.ToArray();
        }
    }

    internal void AddLobbyMemberInvite(BoltFriend member)
    {
         if (!IsMemberInvited(member))
        {
            LobbyMemberInvites = new List<BoltFriend>(LobbyMemberInvites) { member }.ToArray();
       }
    }

     internal void AddLobbySpectatorInvite(BoltFriend member)
    {
        if (!IsSpectatorInvited(member))
        {
            LobbySpectatorInvites = new List<BoltFriend>(LobbySpectatorInvites) { member }.ToArray();
        }
    }

     internal void RemoveLobbyAnyInvite(BoltFriend member)
    {
        RemoveLobbyMemberInvite(member);
        RemoveLobbySpectatorInvite(member);
    }

    internal void RemoveLobbyMemberInvite(BoltFriend member)
     {
        if (IsMemberInvited(member))
         {
            List<BoltFriend> list = new List<BoltFriend>(LobbyMemberInvites);
           list.Remove(member);
            LobbyMemberInvites = list.ToArray();
        }
    }

    internal void RemoveLobbySpectatorInvite(BoltFriend member)
    {
        if (IsSpectatorInvited(member))
        {
            List<BoltFriend> list = new List<BoltFriend>(LobbySpectatorInvites);
            list.Remove(member);
            LobbySpectatorInvites = list.ToArray();
        }
    }
    }
}
