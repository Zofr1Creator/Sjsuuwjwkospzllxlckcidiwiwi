using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TspServer.MongoDB.Game
{
    [Serializable]
    [BsonIgnoreExtraElements]
    public class BoltInventoryItemDefinitionDocument : BoltInventoryItemDocumentBase
    {
        public string displayName { get; set; }
         public int itemType { get; set; }
        public bool canBeTraded { get; set; }
        public int key { get; set; }
         public BsonDocument penalty { get; set; }
        public BsonArray buyPrice { get; set; }
        public BsonDocument properties { get; set; }
       public BsonArray sellPrice { get; set; }
        public BsonDocument definitions { get; set; }
        public int maxStackSize { get; set; }
        public bool canBeRented { get; set; }

        public InventoryItemDefinition ToInventoryItemDefinition()
        {
            var item = new InventoryItemDefinition
            {
                Id = key,
                DisplayName = displayName ?? "Unknown Item",
                CanBeTraded = canBeTraded
            };

            AddPrices(item.BuyPrice, buyPrice, "buyPrice");
             AddPrices(item.SellPrice, sellPrice, "sellPrice");

            if (properties != null)
           {
                try
                {
                    item.Properties.Add(properties.ToStringDictionary());
                }
                catch (System.Exception)
                {
                }
             }

             return item;
        }

        private void AddPrices(ICollection<CurrencyAmount> target, BsonArray? prices, string fieldName)
        {
            if (prices == null)
                return;

            foreach (BsonValue price in prices)
            {
                 if (price == null || !price.IsBsonDocument)
                    continue;

               try
                {
                   target.Add(price.AsBsonDocument.ToCurrency());
                }
                 catch (System.Exception)
                {
                }
            }
        }
    }

    public static class InventoryBsonExtensions
     {
        public static CurrencyAmount ToCurrency(this BsonDocument document)
        {
            int currencyId = 0;
            float value = 0f;

            if (document.TryGetValue("currencyId", out BsonValue currencyValue))
                currencyId = ReadInt(currencyValue, currencyId);

            if (document.TryGetValue("value", out BsonValue amountValue))
               value = ReadFloat(amountValue, value);

            return new CurrencyAmount
            {
                CurrencyId = currencyId,
                Value = value
            };
       }

        public static CurrencyAmount ToCurrency(this BsonElement element)
         {
            return new CurrencyAmount
            {
                CurrencyId = Convert.ToInt32(element.Name),
                Value = ReadFloat(element.Value, throwOnInvalid: true)
            };
        }

        public static InventoryItem ToInventory(this BsonElement element)
        {
           InventoryItem item = CreateInventoryItem(element);
            AddInventoryProperties(item, element.Value.AsBsonDocument);
            EnsureNativeStatTrackValue(item);
            return item;
        }

        public static InventoryItem? ToInventory(this BsonElement element, int[] itemDefinitionIds)
        {
            InventoryItem item = element.ToInventory();
            return itemDefinitionIds.Contains(item.ItemDefinitionId) ? item : null;
        }

        public static BoltInventoryItem ToBoltInventory(this BsonElement element)
        {
            BsonDocument document = element.Value.AsBsonDocument;
            var item = new BoltInventoryItem
            {
                id = Convert.ToInt32(element.Name),
                itemDefinitionId = document.GetValue("itemDefinitionId").AsInt32,
                quantity = document.GetValue("quantity").AsInt32,
                flags = document.GetValue("flags").AsInt32,
                date = document.GetValue("date").AsBsonDateTime
            };

            if (document.TryGetValue("properties", out BsonValue propertiesValue) &&
                propertiesValue.IsBsonDocument &&
                propertiesValue.AsBsonDocument.ElementCount > 0)
            {
                item.Properties.AddRange(
                    propertiesValue.AsBsonDocument
                        .Select(property => property.ToBoltInventoryItemProperty())
                        .ToList());
             }

            return item;
        }

        public static InventoryItem ToInventory(this BoltInventoryItem source, int id)
        {
            var item = new InventoryItem
            {
                Id = id,
                ItemDefinitionId = source.itemDefinitionId,
                Quantity = source.quantity,
                Flags = source.flags,
                Date = source.date.ToUniversalTime().Ticks
            };

            if (source.Properties?.Count > 0)
            {
                item.Properties.Add(
                    source.Properties.ToDictionary(
                        property => property.Name,
                        property => property.GetInventoryItemProperty()));
            }

            EnsureNativeStatTrackValue(item);
           return item;
        }

        public static InventoryItemProperty GetInventoryItemProperty(this BsonElement element)
        {
            var property = new InventoryItemProperty();

            switch (element.Value.BsonType)
            {
                case BsonType.Int32:
                    property.IntValue = element.Value.AsInt32;
                    property.Type = PropertyType.Int;
                    break;
                case BsonType.Double:
                    property.FloatValue = (float)element.Value.AsDouble;
                    property.Type = PropertyType.Float;
                    break;
                case BsonType.String:
                    property.StringValue = element.Value.AsString;
                    property.Type = PropertyType.String;
                    break;
                case BsonType.Boolean:
                    property.BooleanValue = element.Value.AsBoolean;
                    property.Type = PropertyType.Boolean;
                   break;
            }
            return property;
        }

        public static BoltInventoryItemProperty ToBoltInventoryItemProperty(this BsonElement element)
        {
            var property = new BoltInventoryItemProperty
            {
                Name = element.Name
           };

            switch (element.Value.BsonType)
            {
                case BsonType.Int32:
                     property.Value = element.Value.AsInt32.ToString();
                    property.Type = BoltInventoryItemProperty.PropertyType.Int;
                    break;
                case BsonType.Double:
                    property.Value = ((float)element.Value.AsDouble).ToString();
                    property.Type = BoltInventoryItemProperty.PropertyType.Float;
                    break;
                case BsonType.String:
                    property.Value = element.Value.AsString;
                    property.Type = BoltInventoryItemProperty.PropertyType.String;
                    break;
                case BsonType.Boolean:
                    property.Value = element.Value.AsBoolean.ToString();
                    property.Type = BoltInventoryItemProperty.PropertyType.Boolean;
                    break;
            }

            return property;
        }

        public static InventoryItemProperty GetInventoryItemProperty(this BoltInventoryItemProperty source)
        {
            var property = new InventoryItemProperty();

            switch (source.Type)
            {
                case BoltInventoryItemProperty.PropertyType.Int:
                     property.IntValue = Convert.ToInt32(source.Value);
                    property.Type = PropertyType.Int;
                    break;
                case BoltInventoryItemProperty.PropertyType.Float:
                   property.FloatValue = Convert.ToSingle(source.Value);
                    property.Type = PropertyType.Float;
                    break;
                case BoltInventoryItemProperty.PropertyType.String:
                    property.StringValue = source.Value;
                    property.Type = PropertyType.String;
                    break;
                case BoltInventoryItemProperty.PropertyType.Boolean:
                    property.BooleanValue = Convert.ToBoolean(source.Value);
                    property.Type = PropertyType.Boolean;
                    break;
            }

            return property;
         }

        public static InventoryItemPropertyDefinition ToPropertyDefinition(this BsonDocument document, string name)
        {
           return new InventoryItemPropertyDefinition
            {
                Name = name,
                PropertyType = (PropertyType)document.GetValue("propertyType").AsInt32,
                SaveInTrade = document.GetValue("saveInTrade").AsBoolean,
               SetByType = (PropertySetByType)document.GetValue("setByType").AsInt32
            };
        }

        public static Dictionary<string, string> ToStringDictionary(this BsonDocument? document)
        {
            var result = new Dictionary<string, string>();
            if (document == null)
                return result;

            foreach (BsonElement element in document)
            {
                try
                {
                    result[element.Name] = FormatValue(element.Value);
                }
                catch
                {
                    result[element.Name] = element.Value.ToString();
                }
             }

             return result;
        }

        private static InventoryItem CreateInventoryItem(BsonElement element)
        {
            BsonDocument document = element.Value.AsBsonDocument;
            return new InventoryItem
             {
                Id = Convert.ToInt32(element.Name),
                ItemDefinitionId = document.GetValue("itemDefinitionId").AsInt32,
                Quantity = document.GetValue("quantity").AsInt32,
                Flags = document.GetValue("flags").AsInt32,
                Date = document.GetValue("date").AsBsonDateTime.ToUniversalTime().Ticks
            };
        }
        private static void AddInventoryProperties(InventoryItem item, BsonDocument document)
        {
            if (!document.TryGetValue("properties", out BsonValue value) ||
                !value.IsBsonDocument ||
                value.AsBsonDocument.ElementCount == 0)
            {
                return;
            }

            item.Properties.Add(
                value.AsBsonDocument.ToDictionary(
                    property => property.Name,
                    property => property.GetInventoryItemProperty()));
        }

        private static void EnsureNativeStatTrackValue(InventoryItem item)
        {
            if (item.ItemDefinitionId < 1_000_000 || item.ItemDefinitionId > 1_999_999)
                return;

            if (!item.Properties.ContainsKey("stattrack_value"))
           {
                item.Properties.Add("stattrack_value", new InventoryItemProperty
                {
                    IntValue = 0,
                    Type = PropertyType.Int
                });
            }

            item.Properties.Remove("stattrack_property");
        }

        private static int ReadInt(BsonValue value, int fallback)
        {
            if (value.IsInt32)
                return value.AsInt32;
            if (value.IsInt64)
                return (int)value.AsInt64;
            if (value.IsDouble)
                return (int)value.AsDouble;

            return int.TryParse(value.ToString(), out int parsed) ? parsed : fallback;
        }

        private static float ReadFloat(BsonValue value, float fallback = 0f, bool throwOnInvalid = false)
        {
            if (value.IsInt32)
                return value.AsInt32;
            if (value.IsInt64)
                return value.AsInt64;
            if (value.IsDouble)
                return (float)value.AsDouble;
            if (value.IsDecimal128)
                return (float)value.AsDecimal128;
            if (float.TryParse(value.ToString(), out float parsed))
                return parsed;

            if (throwOnInvalid)
                 throw new InvalidCastException("Currency value is not numeric.");

            return fallback;
        }

        private static string FormatValue(BsonValue value)
        {
            if (value.IsDouble)
                return value.AsDouble.ToString();
            if (value.IsInt32)
               return value.AsInt32.ToString();

            return value.ToString();
        }
    }
}
