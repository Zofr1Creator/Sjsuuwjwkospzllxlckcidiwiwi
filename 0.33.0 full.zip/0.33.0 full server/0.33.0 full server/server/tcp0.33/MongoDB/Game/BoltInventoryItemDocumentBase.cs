using System;

namespace TspServer.MongoDB.Game
{
    public abstract class BoltInventoryItemDocumentBase : DocumentModelBase
    {
        public bool enabled
        {
            get;
           set;
        }

        public int gid
        {
            get;
            set;
       }

        public string minGameVersion
        {
            get;
            set;
        }

    }
}
