using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    public class BoltGameEventDocument : BoltInventoryItemDocumentBase
    {
        public string code { get; set; }

        public int dateSince { get; set; }

        public int dateUntil { get; set; }

        public int durationDays { get; set; }

        public int goldPassItem { get; set; }

        public Dictionary<string, BsonDocument> levels { get; set; }

        public static Dictionary<string, BoltGamePassLevels> GetByDocument(Dictionary<string, BsonDocument> bsonElements)
        {
            if (bsonElements.Count() > 0)
            {
                Dictionary<string, BoltGamePassLevels> levels = new Dictionary<string, BoltGamePassLevels>();
                foreach (KeyValuePair<string, BsonDocument> bsonElement in bsonElements)
               {
                    BsonDocument elements = bsonElement.Value;
                    levels.Add(bsonElement.Key, BoltGamePassLevels.GetByDocument(elements));
                }
                return levels;
            }
            return new Dictionary<string, BoltGamePassLevels>();
        }
    }
    public class BoltGamePassLevels
    {
        public Dictionary<int, BoltGamePassLevel> PassLevels { get; set; } = new();
        public List<GamePassLevel> GetGamePassLevelsProto()
        {
            if (PassLevels.Count > 0)
            {
                List<GamePassLevel> gamePassLevels = new();
                foreach (KeyValuePair<int, BoltGamePassLevel> keyValuePair in PassLevels)
                {
                    GamePassLevel gamePassLevel = new() { Level = keyValuePair.Key, MinPoints = keyValuePair.Value.minPoints, Reward = keyValuePair.Value.reward.GetProto() };
                    gamePassLevels.Add(gamePassLevel);
                }
                return gamePassLevels;
             }
            return new();
        }
        public static BoltGamePassLevels GetByDocument(BsonDocument bsonElements)
        {
            if (bsonElements.Count() > 0)
            {
                BoltGamePassLevels levels = new BoltGamePassLevels();
                foreach (BsonElement bsonElement in bsonElements)
                {
                    levels.PassLevels.Add(Int32.Parse(bsonElement.Name), BoltGamePassLevel.GetByDocument(bsonElement.Value.AsBsonDocument));
                }
                return levels;
            }
           return new BoltGamePassLevels();
        }
   }
    public class BoltGamePassLevel
    {
        public int minPoints { get; set; }

        public BoltGameReward reward { get; set; }
        public static BoltGamePassLevel GetByDocument(BsonDocument bsonElements)
        {
            if (bsonElements.Count() > 0)
             {
                BoltGamePassLevel level = new BoltGamePassLevel();
                foreach (BsonElement bsonElement in bsonElements)
                {
                    switch (bsonElement.Name)
                    {
                         case "minPoints":
                            level.minPoints = bsonElement.Value.AsInt32;
                             break;
                        case "reward":
                            BsonDocument elements2 = bsonElement.Value.AsBsonDocument;
                            level.reward = BoltGameReward.GetByDocument(elements2);
                             break;
                    }
                }
                 return level;
            }
            return new BoltGamePassLevel();
        }
    }
    public class BoltGameReward
    {
         public Dictionary<int, int> items { get; set; } = new();

        public Dictionary<int, int> currencies { get; set; } = new();

        public Dictionary<string, BsonDocument> recipes { get; set; } = new();

        public RewardInfo GetProto()
        {
            RewardInfo rewardInfo = new();
            if (items.Count > 0)
            {
                foreach (KeyValuePair<int, int> keyValuePair in items)
                {
                    InventoryItemAmount inventoryItemAmount = new() { InventoryItemDefinitionId = keyValuePair.Key, Value = keyValuePair.Value };
                    rewardInfo.Items.Add(inventoryItemAmount);
                }
            }
            if (currencies.Count > 0)
            {
                foreach (KeyValuePair<int, int> keyValuePair in currencies)
                {
                    CurrencyAmount currencyAmount = new() { CurrencyId = keyValuePair.Key, Value = keyValuePair.Value };
                    rewardInfo.Currencies.Add(currencyAmount);
                }
            }

            return rewardInfo;
        }

        public static BoltGameReward GetByDocument(BsonDocument bsonElements)
        {
            if (bsonElements.Count() > 0)
            {
                BoltGameReward reward = new BoltGameReward();
                foreach (BsonElement bsonElement in bsonElements)
               {
                    switch (bsonElement.Name)
                    {
                        case "items":
                            BsonDocument elements = bsonElement.Value.AsBsonDocument;
                            foreach (BsonElement element in elements)
                                reward.items.Add(Int32.Parse(element.Name), element.Value.AsInt32);
                            break;
                        case "currencies":
                            BsonDocument elements2 = bsonElement.Value.AsBsonDocument;
                            foreach (BsonElement element in elements2)
                                reward.currencies.Add(Int32.Parse(element.Name), element.Value.AsInt32);
                             break;
                        case "recipes":

                             BsonDocument elements3 = bsonElement.Value.AsBsonDocument;
                            foreach (BsonElement element in elements3)
                                reward.recipes.Add(element.Name, element.Value.AsBsonDocument);
                            break;
                    }
                }
                return reward;
             }
            return new BoltGameReward();
        }
     }
}
