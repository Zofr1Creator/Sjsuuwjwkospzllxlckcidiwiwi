using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    public class PlayerInventoryDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public BsonDocument Currencies { get; set; }
        public BsonDocument InventoryItems { get; set; }

        public PlayerInventory GetPlayerInventoryProto()
        {
            var playerInventory = new PlayerInventory();

            if (Currencies != null)
            {
                foreach (var el in Currencies.Elements)
                {
                    try
                    {
                        if (!int.TryParse(el.Name, out int currencyId))
                           continue;

                        var amount = ReadCurrencyValue(el.Value);
                        playerInventory.Currencies.Add(new CurrencyAmount
                        {
                            CurrencyId = currencyId,
                             OldValue = (int)amount,
                            Value = (float)amount
                        });
                    }
                    catch (System.Exception)
                    {
                    }
                }
            }

            if (InventoryItems != null)
            {
                foreach (var el in InventoryItems.Elements)
                {
                    try
                    {
                        InventoryItem item = el.ToInventory();
                        if (item == null || item.Id <= 0 || item.ItemDefinitionId <= 0)
                         {
                            continue;
                        }

                        playerInventory.InventoryItems.Add(item);
                    }
                     catch (System.Exception)
                    {

                    }
               }
            }

            return playerInventory;
         }

        private static double ReadCurrencyValue(BsonValue value)
        {
            if (value == null || value.IsBsonNull)
                return 0;

            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
           if (value.IsDouble) return value.AsDouble;
            if (value.IsDecimal128) return (double)value.AsDecimal128;

            if (value.IsString && double.TryParse(value.AsString, out var d))
                return d;

            return 0;
        }

        public InventoryItem[] GetInventoryItemsProto(int[] itemDefinitionIds)
        {
            List<InventoryItem> items = new();
             if (InventoryItems == null || itemDefinitionIds == null || itemDefinitionIds.Length == 0)
                return items.ToArray();

            foreach (var el in InventoryItems.Elements)
            {
                try
                {
                    InventoryItem? item = el.ToInventory(itemDefinitionIds);
                    if (item != null && item.Id > 0 && item.ItemDefinitionId > 0)
                        items.Add(item);
                }
                catch (System.Exception)
                {
                }
            }

             return items.ToArray();
        }
    }
    public class Currency
    {
        public float value { get; set; }

        public BsonDocument GetBsonElements()
        {
            return new BsonDocument(new BsonElement[]
                {
                    new BsonElement("value", value)
                }
                as IEnumerable<BsonElement>);
        }
    }
    public class BoltInventoryItem
    {
        public int id { get; set; }
        public int itemDefinitionId { get; set; }
        public int quantity { get; set; }
        public int flags { get; set; }
        public BsonDateTime date { get; set; }
        public List<BoltInventoryItemProperty> Properties { get; set; }
        public BoltInventoryItem()
        {
            Properties = new List<BoltInventoryItemProperty>();
        }
        public List<BsonElement> GetProperties()
        {
            if (Properties == null || Properties.Count == 0)
                return null;

            var props = new List<BsonElement>(Properties.Count);
            props.AddRange(Properties.Select(property => property.GetBsonElement()));

            return props;
        }

        public BsonDocument GetBsonElements()
        {
             BsonDocument properties = (GetProperties() != null) ? new BsonDocument(GetProperties()) : new BsonDocument();
            if (itemDefinitionId >= 1000000 && itemDefinitionId <= 1999999 && !properties.Contains("stattrack_value"))
                properties["stattrack_value"] = 0;
            properties.Remove("stattrack_property");
            return new BsonDocument(new BsonElement[]
                {
                    new BsonElement("itemDefinitionId", itemDefinitionId),
                     new BsonElement("quantity", quantity),
                    new BsonElement("flags", flags),
                    new BsonElement("date", date),
                    new BsonElement("properties", properties)
                }
                 as IEnumerable<BsonElement>);
        }
    }
    public class BoltInventoryItemProperty
    {
        public string Name { get; set; }
        public PropertyType Type { get; set; }
        public string Value { get; set; }
        public BsonElement GetBsonElement()
        {
            return new BsonElement(Name, GetValue(Type));
        }
        public BsonValue GetValue(PropertyType type)
        {
            var value = BsonValue.Create(Value);
            switch (type)
            {
                case PropertyType.Int:
                    return value.ToInt32();
                case PropertyType.Boolean:
                    return value.ToBoolean();
                case PropertyType.Float:
                    return value.ToDouble();
                case PropertyType.String:
                    return value;
            };
            throw new ArgumentOutOfRangeException();
         }
        public enum PropertyType
       {
            Int,
            Float,
           String,
            Boolean
        }

    }
}
