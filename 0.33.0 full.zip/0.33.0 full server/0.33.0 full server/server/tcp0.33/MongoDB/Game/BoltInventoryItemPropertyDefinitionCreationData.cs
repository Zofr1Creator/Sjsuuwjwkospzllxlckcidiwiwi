using System.Collections.Generic;
using MongoDB.Bson;

namespace TspServer.MongoDB.Game
{
    public struct BoltInventoryItemPropertyDefinitionCreationData
    {
        public bool CanBeTraded;
        public bool Enabled;
        public int Key;
        public int GameId;
        public List<BsonElement> Properties;

        public BsonDocument GetDocument()
        {
            return new BsonDocument(new BsonElement[]
            {
                new BsonElement("key", Key),
                new BsonElement("enabled", Enabled),
                new BsonElement("gid", GameId),
                new BsonElement("definitions", new BsonDocument(Properties)),
             } as IEnumerable<BsonElement>);
        }
    }

}
