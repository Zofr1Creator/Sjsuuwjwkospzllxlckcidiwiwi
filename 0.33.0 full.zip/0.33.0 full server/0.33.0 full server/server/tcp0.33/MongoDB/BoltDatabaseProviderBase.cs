using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB.Data;

namespace TspServer.MongoDB
{
    public abstract class BoltDatabaseProviderBase
    {
        public abstract BoltDatabaseType DatabaseType { get; }

        public Action ConnectedCallback;

        protected BoltDatabaseInfo _databaseInfo;
         protected MongoClient _client;
        protected List<string> _databaseNames = new List<string>();
         protected readonly Dictionary<string, List<string>> _databaseNameToCollectionNames = new Dictionary<string, List<string>>();
        public void Connect(BoltDatabaseInfo databaseInfo)
        {
            _databaseInfo = databaseInfo;
            string uri = databaseInfo.GetUri();

             MongoClientSettings settings = MongoClientSettings.FromConnectionString(uri);
            settings.ServerSelectionTimeout = TimeSpan.FromSeconds(5);
            settings.ConnectTimeout = TimeSpan.FromSeconds(5);
            settings.SocketTimeout = TimeSpan.FromSeconds(10);
            _client = new MongoClient(settings);

            _client.GetDatabase("admin").RunCommand<BsonDocument>(new BsonDocument("ping", 1));

            _databaseNames = GetDatabaseNames() ?? new List<string>();
            FilterDatabaseNames(_databaseNames).GetAwaiter().GetResult();

            _databaseNameToCollectionNames.Clear();
            foreach (string databaseName in _databaseNames)
             {
               List<string> collectionNames = GetCollectionNames(databaseName) ?? new List<string>();
                FilterCollectionNames(databaseName, collectionNames).GetAwaiter().GetResult();
                _databaseNameToCollectionNames[databaseName] = collectionNames;
            }

            ConnectedCallback?.Invoke();
        }

        public void Disconnect()
        {
         }

        public List<string> GetFilteredDatabaseNames() => _databaseNames;
         public List<string> GetFilteredCollectionNames(string databaseName) =>
            _databaseNameToCollectionNames.TryGetValue(databaseName, out List<string> names) ? names : new List<string>();

        protected virtual Task FilterDatabaseNames(List<string> databaseNames) => Task.CompletedTask;
        protected virtual Task FilterCollectionNames(string databaseName, List<string> collectionNames) => Task.CompletedTask;

        public List<string> GetDatabaseNames() => _client.ListDatabaseNames().ToList();
        public Task<List<string>> GetDatabaseNamesAsync() => Async(GetDatabaseNames);

        public List<string> GetCollectionNames(string databaseName) =>
            _client.GetDatabase(databaseName).ListCollectionNames().ToList();
        public Task<List<string>> GetCollectionNamesAsync(string databaseName) => Async(() => GetCollectionNames(databaseName));

        public static Task Async(Action action) => Task.Run(action);
        public static Task Async(Action action, string processName, string processDescription = null, int parentProcessId = -1) => Task.Run(action);
        public static Task<T> Async<T>(Func<T> func) => Task.Run(func);
        public static Task<T> Async<T>(Func<T> func, string processName, string processDescription = null, int parentProcessId = -1) => Task.Run(func);
    }
}
