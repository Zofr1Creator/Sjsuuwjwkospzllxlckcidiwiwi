using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace TspServer.MongoDB
{
    [Serializable]
   public abstract class DocumentModelBase
    {
        [BsonId]
        public ObjectId _id { get; set; }
    }
}
