using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB.Data;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;

namespace TspServer.MongoDB
{
    public class BoltGameDatabaseProvider : BoltDatabaseProviderBase
    {
        public override BoltDatabaseType DatabaseType => BoltDatabaseType.Game;

        private static string BoltDatabaseName =>
            Environment.GetEnvironmentVariable("MONGO_DATABASE") ?? "Main";
         public IMongoDatabase GetDatabase() => _client.GetDatabase(BoltDatabaseName);

        public static BoltGameDatabaseProvider Instance { get; set; }
        protected override Task FilterDatabaseNames(List<string> databaseNames)
        {
            if (databaseNames == null)
                return base.FilterDatabaseNames(null);

            databaseNames.RemoveAll(s => !string.Equals(s, BoltDatabaseName, StringComparison.Ordinal));
            return base.FilterDatabaseNames(databaseNames);
        }

       protected override Task FilterCollectionNames(string databaseName, List<string> collectionNames)
        {
            if (collectionNames == null)
                return base.FilterCollectionNames(databaseName, null);

            collectionNames.RemoveAll(s => s.StartsWith("system."));

            return base.FilterCollectionNames(databaseName, collectionNames);
        }

        private const string LobbyCollectionName = "lobbies";

        public void UpsertLobbyRuntime(BoltLobby lobby)
        {
            if (lobby == null || string.IsNullOrWhiteSpace(lobby.Id))
                return;

            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(LobbyCollectionName);
             var data = new BsonDocument();
            foreach (KeyValuePair<string, string> pair in BoltLobby.NormalizeLobbyData(lobby.Data))
                 data[pair.Key ?? string.Empty] = pair.Value ?? string.Empty;

            var customProperties = new BsonDocument();
            if (lobby.PhotonGame?.customProperties != null)
            {
                foreach (KeyValuePair<string, string> pair in lobby.PhotonGame.customProperties)
                    customProperties[pair.Key ?? string.Empty] = pair.Value ?? string.Empty;
             }

            BsonDocument document = new BsonDocument
            {
                { "_id", lobby.Id },
                { "ownerId", lobby.LobbyOwnerId ?? string.Empty },
               { "name", lobby.Name ?? string.Empty },
               { "type", (int)lobby.Type },
                { "joinable", lobby.Joinable },
                { "maxMembers", lobby.MaxMembers },
                { "maxSpectators", lobby.MaxSpectators },
                { "data", data },
                { "visibleDataKeys", new BsonArray((lobby.DataVisibleInSearch ?? new HashSet<string>())
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(x => (BsonValue)x)) },
                { "members", new BsonArray((lobby.LobbyMembers ?? Array.Empty<BoltFriend>()).Where(x => x != null).Select(x => (BsonValue)(x.Id ?? string.Empty))) },
                 { "spectators", new BsonArray((lobby.LobbySpectators ?? Array.Empty<BoltFriend>()).Where(x => x != null).Select(x => (BsonValue)(x.Id ?? string.Empty))) },
                { "memberInvites", new BsonArray((lobby.LobbyMemberInvites ?? Array.Empty<BoltFriend>()).Where(x => x != null).Select(x => (BsonValue)(x.Id ?? string.Empty))) },
               { "spectatorInvites", new BsonArray((lobby.LobbySpectatorInvites ?? Array.Empty<BoltFriend>()).Where(x => x != null).Select(x => (BsonValue)(x.Id ?? string.Empty))) },
                { "gameServer", new BsonDocument
                    {
                        { "id", lobby.GameServer?.Id ?? string.Empty },
                        { "ip", lobby.GameServer?.Ip ?? string.Empty },
                        { "port", lobby.GameServer?.Port ?? 0 }
                    }
                },
               { "photonGame", new BsonDocument
                    {
                        { "region", lobby.PhotonGame?.region ?? string.Empty },
                       { "roomId", lobby.PhotonGame?.roomId ?? string.Empty },
                        { "appVersion", lobby.PhotonGame?.appVersion ?? string.Empty },
                        { "customProperties", customProperties }
                    }
               },
                { "updatedAt", DateTime.UtcNow }
            };

            collection.ReplaceOne(
                Builders<BsonDocument>.Filter.Eq("_id", lobby.Id),
                document,
                 new ReplaceOptions { IsUpsert = true });
        }

        public void DeleteLobbyRuntime(string lobbyId)
        {
            if (string.IsNullOrWhiteSpace(lobbyId))
                return;
           var database = _client.GetDatabase(BoltDatabaseName);
            database.GetCollection<BsonDocument>(LobbyCollectionName)
                .DeleteOne(Builders<BsonDocument>.Filter.Eq("_id", lobbyId));
        }
        public BsonDocument GetLobbyRuntime(string lobbyId)
        {
            if (string.IsNullOrWhiteSpace(lobbyId))
                return null;
            var database = _client.GetDatabase(BoltDatabaseName);
            return database.GetCollection<BsonDocument>(LobbyCollectionName)
                .Find(Builders<BsonDocument>.Filter.Eq("_id", lobbyId))
                .FirstOrDefault();
        }

        private const string InventoryItemDefinitionCollectionName = InventoryCatalog.ItemCollection;

        public List<BoltInventoryItemDefinitionDocument> GetInventoryItemDefinitions()
        {
            return GetDatabase()
                .GetCollection<BoltInventoryItemDefinitionDocument>(InventoryCatalog.ItemCollection)
                .Find(Builders<BoltInventoryItemDefinitionDocument>.Filter.Eq(x => x.enabled, true))
                .ToList();
        }

        public BoltInventoryItemDefinitionDocument GetInventoryItemDefinition(int key, int gameId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemDefinitionDocument>(InventoryItemDefinitionCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<BoltInventoryItemDefinitionDocument>();
            var filter = filterBuilder.Eq("key", key) & filterBuilder.Eq("gid", gameId);
            BoltInventoryItemDefinitionDocument exact = collection.Find(filter).FirstOrDefault();
            if (exact != null) return exact;

            return collection.Find(filterBuilder.Eq("key", key))
                .SortByDescending(x => x.enabled)
                .ThenBy(x => x.gid)
                .FirstOrDefault();
        }

        public Task<BoltInventoryItemDefinitionDocument> GetInventoryItemDefinitionAsync(int key, int gameId, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => GetInventoryItemDefinition(key, gameId), processName, processDescription, parentProcessId);
        }

       public ObjectId CreateInventoryItemDefinition(BoltInventoryItemDefinitionCreationData definitionCreationData)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
             var collection = database.GetCollection<BsonDocument>(InventoryItemDefinitionCollectionName);
            collection.InsertOne(definitionCreationData.GetDocument());

            var definitionsCollection = database.GetCollection<BoltInventoryItemDefinitionDocument>(InventoryItemDefinitionCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<BoltInventoryItemDefinitionDocument>();
            var filter = filterBuilder.Eq("key", definitionCreationData.Key) &
                         filterBuilder.Eq("gid", definitionCreationData.GameId);
            var createdItemDefinition = definitionsCollection.Find(filter).First();
            return createdItemDefinition._id;
        }

        public Task<ObjectId> CreateInventoryItemDefinitionAsync(BoltInventoryItemDefinitionCreationData definitionCreationData, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => CreateInventoryItemDefinition(definitionCreationData), processName, processDescription, parentProcessId);
        }

        public void ReplaceInventoryItemDefinition(BoltInventoryItemDefinitionDocument definitionDocument)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemDefinitionDocument>(InventoryItemDefinitionCollectionName);
            var filter = new FilterDefinitionBuilder<BoltInventoryItemDefinitionDocument>().Eq("_id", definitionDocument._id);
           var result = collection.ReplaceOne(filter, definitionDocument);
        }

        public Task ReplaceInventoryItemDefinitionAsync(BoltInventoryItemDefinitionDocument definitionDocument, string processName, string processDescription = null, int parentProcessId = -1)
       {
            return Async(() => ReplaceInventoryItemDefinition(definitionDocument), processName, processDescription, parentProcessId);
        }

         public List<BoltInventoryItemDefinitionDocument> GetAllItemDefinitionsByType(uint inventoryItemTypeId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemDefinitionDocument>(InventoryItemDefinitionCollectionName);
            var inventoryDocument = collection.Find(new BsonDocument()).ToList();
            return inventoryDocument.OrderBy(o => o.key).ToList();
        }

        public Task<List<BoltInventoryItemDefinitionDocument>> GetAllItemDefinitionsByTypeAsync(uint inventoryItemTypeId, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => GetAllItemDefinitionsByType(inventoryItemTypeId), processName, processDescription, parentProcessId);
        }

        public string FindOrCreateAvatar(int[] avatar)
        {
            const string collectionName = "avatars";
            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<AvatarDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<AvatarDocument>().Eq("bytes", avatar);
            var documents = playersCollection.Find(filter);
             if (documents.CountDocuments() == 0)
            {
               string avatarId = Guid.NewGuid().ToString();
                var collection = database.GetCollection<BsonDocument>(collectionName);
                collection.InsertOne(new BsonDocument(new BsonElement[]
                {
                new BsonElement("avatarId", avatarId),
                new BsonElement("bytes", new BsonArray(avatar)),
                } as IEnumerable<BsonElement>));
                return avatarId;
            }
            return documents.First().avatarId;
        }
        private static readonly byte[] DefaultAvatarPng = Convert.FromBase64String(
             "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=");
        private static string NormalizeAvatarStorageId(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "1";
            string normalized = value.Trim().Replace('\\', '/');
            int query = normalized.IndexOfAny(new[] { '?', '#' });
            if (query >= 0) normalized = normalized.Substring(0, query);
            string[] parts = normalized.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length == 0 ? normalized : parts[parts.Length - 1];
        }

        private static string[] BuildAvatarAliases(string requested)
        {
            var result = new List<string>();
            void Add(string value)
            {
                if (string.IsNullOrWhiteSpace(value)) return;
                value = value.Trim();
                 if (!result.Contains(value, StringComparer.Ordinal)) result.Add(value);
            }

            Add(requested);
            string storage = NormalizeAvatarStorageId(requested);
             Add(storage);
            if (storage.StartsWith("_default_", StringComparison.OrdinalIgnoreCase))
           {
                string[] parts = storage.Split('_', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length > 0)
                {
                    string leaf = parts[parts.Length - 1];
                    Add(leaf);
                    Add("default_" + leaf);
                   if (parts.Length >= 2)
                        Add(parts[parts.Length - 2] + "_" + leaf);
                }
            }
            return result.ToArray();
        }

        private static byte[] DecodeAvatarDocument(BsonDocument document)
        {
            foreach (string field in new[] { "bytes", "avatar", "data", "image", "payload" })
            {
                if (!document.TryGetValue(field, out BsonValue value) || value == null || value.IsBsonNull)
                     continue;
                try
                {
                   byte[] bytes = Array.Empty<byte>();
                    if (value.IsBsonBinaryData)
                        bytes = value.AsBsonBinaryData.Bytes;
                    else if (value.IsBsonArray)
                        bytes = value.AsBsonArray.Where(x => x.IsNumeric).Select(x => checked((byte)x.ToInt32())).ToArray();
                    else if (value.IsString && !string.IsNullOrWhiteSpace(value.AsString))
                        bytes = Convert.FromBase64String(value.AsString.Trim());

                    if (bytes.Length > 0 && bytes.Length <= 4 * 1024 * 1024)
                        return bytes;
                 }
                catch { }
            }
            return Array.Empty<byte>();
        }

        private static BsonDocument FindAvatarDocument(IMongoDatabase database, string collectionName, string[] aliases)
        {
            var collection = database.GetCollection<BsonDocument>(collectionName);
             var filters = new List<FilterDefinition<BsonDocument>>();
            foreach (string alias in aliases)
            {
                filters.Add(Builders<BsonDocument>.Filter.Eq("avatarId", alias));
                filters.Add(Builders<BsonDocument>.Filter.Eq("id", alias));
                filters.Add(Builders<BsonDocument>.Filter.Eq("key", alias));
                if (ObjectId.TryParse(alias, out ObjectId objectId))
                    filters.Add(Builders<BsonDocument>.Filter.Eq("_id", objectId));
           }
            return filters.Count == 0
                ? null
                : collection.Find(Builders<BsonDocument>.Filter.Or(filters)).FirstOrDefault();
        }

       public Axlebolt.Bolt.Protobuf2.AvatarBinary GetAvatar(string Id)
        {
            string requestedAvatarId = string.IsNullOrWhiteSpace(Id) ? "1" : Id.Trim();
            string[] aliases = BuildAvatarAliases(requestedAvatarId);
            var database = _client.GetDatabase(BoltDatabaseName);

            BsonDocument document = FindAvatarDocument(database, "avatars", aliases);
            byte[] bytes = document == null ? Array.Empty<byte>() : DecodeAvatarDocument(document);
            string source = "avatars";

            if (bytes.Length == 0)
            {
                 BsonDocument defaultDocument = FindAvatarDocument(database, "default_avatars", aliases);
                bytes = defaultDocument == null ? Array.Empty<byte>() : DecodeAvatarDocument(defaultDocument);
                source = "default_avatars";
            }

            if (bytes.Length == 0)
            {

                bytes = DefaultAvatarPng;
            }
            else
            {
            }

            return new Axlebolt.Bolt.Protobuf2.AvatarBinary
            {
                Id = requestedAvatarId,
                Avatar = Google.Protobuf.ByteString.CopyFrom(bytes)
            };
        }

        public Axlebolt.Bolt.Protobuf2.AvatarBinary[] GetAvatars(string[] ids)
        {
            if (ids == null || ids.Length == 0)
                return Array.Empty<Axlebolt.Bolt.Protobuf2.AvatarBinary>();

           return ids
                .Where(i => !string.IsNullOrWhiteSpace(i))
               .Distinct(StringComparer.Ordinal)
               .Select(GetAvatar)
                .ToArray();
        }

        public PlayerStatsDocument GetPlayerStatsDocument(string Id)
        {
            const string collectionName = "stats";

           var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerStatsDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerStatsDocument>().Eq("playerId", Id);
            return playersCollection.Find(filter).First();
        }

        public ObjectId CreatePlayerStats(string playerId)
        {
            const string collectionName = "stats";

            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(collectionName);
           collection.InsertOne(new BsonDocument(new BsonElement[]
             {
                new BsonElement("playerId", playerId),
                new BsonElement("stats", new BsonDocument(PlayerStatsExtension.GetAllNullStats()))
            } as IEnumerable<BsonElement>));

            var playersCollection = database.GetCollection<PlayerStatsDocument>(collectionName);
             var filter = new FilterDefinitionBuilder<PlayerStatsDocument>().Eq("playerId", playerId);
            var createdPlayer = playersCollection.Find(filter).First();
            return createdPlayer._id;
        }

       public void StoreStat(ObjectId id, string Name, int value)
        {
            const string collectionName = "stats";

            var database = _client.GetDatabase(BoltDatabaseName);
           var playersCollection = database.GetCollection<PlayerStatsDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerStatsDocument>().Eq("playerId", id.ToString());
            var update = new UpdateDefinitionBuilder<PlayerStatsDocument>().Set("stats." + Name, value);
            playersCollection.UpdateOne(filter, update);
        }

        public void StoreStatValue(string playerId, string name, BsonValue value)
        {
            const string collectionName = "stats";
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(name)) return;

             var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<BsonDocument>(collectionName);
            var filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId);
            var update = Builders<BsonDocument>.Update
                .SetOnInsert("playerId", playerId)
                .Set("stats." + name, value ?? BsonNull.Value);
            playersCollection.UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
        }

        private const string SeasonalPlayerStatsCollection = "seasonal_player_stats_033";

        public void StoreSeasonStatValue(string playerId, string seasonId, string name, BsonValue value)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(seasonId) || string.IsNullOrWhiteSpace(name)) return;
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(SeasonalPlayerStatsCollection);
            var filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                         Builders<BsonDocument>.Filter.Eq("seasonId", seasonId);
            var update = Builders<BsonDocument>.Update
                .SetOnInsert("playerId", playerId)
                .SetOnInsert("seasonId", seasonId)
                .Set("stats." + name, value ?? BsonNull.Value)
                .Set("updatedAt", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
            collection.UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
        }

        public void StoreSeasonStatsSnapshot(string playerId, string seasonId, IEnumerable<BsonElement> stats)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(seasonId)) return;
            var normalized = new BsonDocument();
            foreach (BsonElement element in stats ?? Enumerable.Empty<BsonElement>())
            {
                if (string.IsNullOrWhiteSpace(element.Name) || element.Value == null || element.Value.IsBsonNull) continue;
                normalized[element.Name] = element.Value;
            }
            var database = _client.GetDatabase(BoltDatabaseName);
           var collection = database.GetCollection<BsonDocument>(SeasonalPlayerStatsCollection);
            var filter = Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                         Builders<BsonDocument>.Filter.Eq("seasonId", seasonId);
            var update = Builders<BsonDocument>.Update
                .SetOnInsert("playerId", playerId)
                .SetOnInsert("seasonId", seasonId)
                .Set("stats", normalized)
                .Set("updatedAt", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
             collection.UpdateOne(filter, update, new UpdateOptions { IsUpsert = true });
        }

        public BsonDocument GetSeasonStats(string playerId, string seasonId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(seasonId)) return null;
            var database = _client.GetDatabase(BoltDatabaseName);
           var collection = database.GetCollection<BsonDocument>(SeasonalPlayerStatsCollection);
            BsonDocument doc = collection.Find(Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                                               Builders<BsonDocument>.Filter.Eq("seasonId", seasonId)).FirstOrDefault();
            if (doc == null || !doc.TryGetValue("stats", out BsonValue stats) || !stats.IsBsonDocument) return null;
            return stats.AsBsonDocument;
        }

        public IReadOnlyList<string> GetKnownSeasonIds()
       {
            try
            {
                var database = _client.GetDatabase(BoltDatabaseName);
                var collection = database.GetCollection<BsonDocument>(SeasonalPlayerStatsCollection);
                return collection.Distinct<string>("seasonId", Builders<BsonDocument>.Filter.Empty)
                    .ToList()
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                     .Distinct(StringComparer.Ordinal)
                   .ToList();
            }
            catch
            {
                return Array.Empty<string>();
            }
        }

        public void StoreStat(ObjectId id, Axlebolt.Bolt.Protobuf2.StorePlayerStat storePlayerStat)
        {
            const string collectionName = "stats";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerStatsDocument>(collectionName);
           var filter = new FilterDefinitionBuilder<PlayerStatsDocument>().Eq("playerId", id.ToString());
            var update = new UpdateDefinitionBuilder<PlayerStatsDocument>().Set("stats." + storePlayerStat.Name, storePlayerStat.StoreInt);
            playersCollection.UpdateOne(filter, update);
        }

        public void StoreStat(Axlebolt.Bolt.Protobuf2.PlayerStats storePlayerStat)
        {
            const string collectionName = "stats";
            foreach (Axlebolt.Bolt.Protobuf2.StorePlayerStat abob in storePlayerStat.Stats)
            {
                StoreStat(ObjectId.Parse(storePlayerStat.PlayerId), abob);
            }

        }

        public BoltGameEventDocument GetGameEvent(string code)
        {
            const string collectionName = "game_events";

           var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<BoltGameEventDocument>(collectionName);
             var filter = new FilterDefinitionBuilder<BoltGameEventDocument>().Eq("code", code);
           return playersCollection.Find(filter).First();
        }
         public ObjectId CreatePlayerFiles(string playerId)
        {
            const string collectionName = "file_storage";

            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(collectionName);
            collection.InsertOne(new BsonDocument(new BsonElement[]
           {
                 new BsonElement("playerId", playerId),
                new BsonElement("files", new BsonDocument())
            } as IEnumerable<BsonElement>));

            var playersCollection = database.GetCollection<FileStoragesDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<FileStoragesDocument>().Eq("playerId", playerId);
            var createdPlayer = playersCollection.Find(filter).First();
            return createdPlayer._id;
        }
        public FileStoragesDocument GetFiles(ObjectId id)
        {
            const string collectionName = "file_storage";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<FileStoragesDocument>(collectionName);
           var filter = new FilterDefinitionBuilder<FileStoragesDocument>().Eq("playerId", id.ToString());
            return playersCollection.Find(filter).First();
        }
        public void WriteOrCreateFile(ObjectId id, string fileName, byte[] file)
        {
            int[] rt = new int[file.Length];
            rt = file.Select(i => (int)i).ToArray();
            const string collectionName = "file_storage";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<FileStoragesDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<FileStoragesDocument>().Eq("playerId", id.ToString());
            var fie = playersCollection.Find(filter).First();
            var update = new UpdateDefinitionBuilder<FileStoragesDocument>().Set("files." + fileName, new BsonArray(rt));
            playersCollection.UpdateOne(filter, update);
        }

        private const string FriendCollectionName = "friends";

        private static FilterDefinition<FriendDocument> FriendPairFilter(
            FilterDefinitionBuilder<FriendDocument> filterBuilder,
            string playerId,
            string friendId)
        {
            return
                (filterBuilder.Eq("playerInitiatorId", playerId) &
                 filterBuilder.Eq("playerId", friendId)) |
                (filterBuilder.Eq("playerInitiatorId", friendId) &
                 filterBuilder.Eq("playerId", playerId));
        }

        private static long FriendUpdatedAt(FriendDocument document) =>
           document?.lastTimeUpdate?.MillisecondsSinceEpoch ?? 0L;

        public List<FriendDocument> GetPlayerFriends(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
                return new List<FriendDocument>();

            IMongoCollection<FriendDocument> collection =
                _client.GetDatabase(BoltDatabaseName)
                    .GetCollection<FriendDocument>(FriendCollectionName);
            var filterBuilder = Builders<FriendDocument>.Filter;
            FilterDefinition<FriendDocument> filter =
                 filterBuilder.Eq(x => x.playerId, playerId) |
                filterBuilder.Eq(x => x.playerInitiatorId, playerId);

            return collection.Find(filter)
                .ToList()
                .Where(x => x != null)
                .GroupBy(x => string.Equals(x.playerInitiatorId, playerId, StringComparison.Ordinal)
                    ? x.playerId
                    : x.playerInitiatorId,
                    StringComparer.Ordinal)
               .Select(group => group
                    .OrderByDescending(FriendUpdatedAt)
                   .ThenByDescending(x => x._id.CreationTime)
                    .First())
                .Where(x => x != null)
                 .ToList();
        }

        public FriendDocument GetPlayerFriendRelationship(string playerId, string friendId)
        {
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(friendId))
                return null;

            IMongoCollection<FriendDocument> collection =
                _client.GetDatabase(BoltDatabaseName)
                    .GetCollection<FriendDocument>(FriendCollectionName);
            var filterBuilder = Builders<FriendDocument>.Filter;
            List<FriendDocument> documents = collection
                .Find(FriendPairFilter(filterBuilder, playerId, friendId))
                .ToList()
                .Where(x => x != null)
                .OrderByDescending(FriendUpdatedAt)
                .ThenByDescending(x => x._id.CreationTime)
                .ToList();

            if (documents.Count == 0) return null;

            FriendDocument canonical = documents[0];
            if (documents.Count > 1)
            {
                 ObjectId[] duplicateIds = documents.Skip(1)
                    .Where(x => x._id != ObjectId.Empty)
                    .Select(x => x._id)
                    .ToArray();
                if (duplicateIds.Length > 0)
                {
                    collection.DeleteMany(
                        Builders<FriendDocument>.Filter.In(x => x._id, duplicateIds));
                }
            }
             return canonical;
        }

       public FriendDocument CreatePlayerFriendDocument(FriendDocument friendDocument)
        {
            if (friendDocument == null) throw new ArgumentNullException(nameof(friendDocument));
            if (string.IsNullOrWhiteSpace(friendDocument.playerInitiatorId) ||
                string.IsNullOrWhiteSpace(friendDocument.playerId))
                throw new ArgumentException("Friend relationship requires both player ids.");

            FriendDocument existing = GetPlayerFriendRelationship(
                friendDocument.playerInitiatorId,
                 friendDocument.playerId);
            if (existing != null)
            {
                friendDocument._id = existing._id;
                UpdatePlayerFriendDocument(
                    friendDocument.playerInitiatorId,
                    friendDocument.playerId,
                    friendDocument);
                 return friendDocument;
            }

            friendDocument.lastTimeUpdate = (BsonDateTime)DateTime.UtcNow;
            friendDocument.msg ??= string.Empty;
            IMongoCollection<FriendDocument> collection =
                _client.GetDatabase(BoltDatabaseName)
                    .GetCollection<FriendDocument>(FriendCollectionName);
            collection.InsertOne(friendDocument);
            return friendDocument;
        }

       public void UpdatePlayerFriendDocument(
            string playerId,
            string friendId,
           FriendDocument friendDocument)
        {
            if (friendDocument == null) throw new ArgumentNullException(nameof(friendDocument));

            IMongoCollection<FriendDocument> collection =
                _client.GetDatabase(BoltDatabaseName)
                    .GetCollection<FriendDocument>(FriendCollectionName);
            var filterBuilder = Builders<FriendDocument>.Filter;

            friendDocument.lastTimeUpdate = (BsonDateTime)DateTime.UtcNow;
            friendDocument.msg ??= string.Empty;

            if (friendDocument._id == ObjectId.Empty)
             {
                FriendDocument existing = GetPlayerFriendRelationship(playerId, friendId);
               if (existing != null) friendDocument._id = existing._id;
            }

             if (friendDocument._id == ObjectId.Empty)
            {
                 collection.InsertOne(friendDocument);
            }
            else
            {
                collection.ReplaceOne(
                    filterBuilder.Eq(x => x._id, friendDocument._id),
                    friendDocument,
                    new ReplaceOptions { IsUpsert = true });
            }

            FilterDefinition<FriendDocument> duplicateFilter =
               FriendPairFilter(filterBuilder, playerId, friendId) &
                filterBuilder.Ne(x => x._id, friendDocument._id);
            DeleteResult removed = collection.DeleteMany(duplicateFilter);
             if (removed.DeletedCount > 0)
            {
            }
        }

        public void DeletePlayerFriendDocument(string playerId, string friendId)
        {
            IMongoCollection<FriendDocument> collection =
                _client.GetDatabase(BoltDatabaseName)
                    .GetCollection<FriendDocument>(FriendCollectionName);
            collection.DeleteMany(
                FriendPairFilter(Builders<FriendDocument>.Filter, playerId, friendId));
       }

        private const string PlayerInventoryCollectionName = InventoryCatalog.PlayerInventoryCollection;
        private const string LegacyPlayerInventoryCollectionName = InventoryCatalog.LegacyPlayerInventoryCollection;

        private PlayerInventoryDocument EnsurePlayerInventory(ObjectId objectId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var target = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filter = Builders<PlayerInventoryDocument>.Filter.Eq("playerId", objectId.ToString());
             PlayerInventoryDocument existing = target.Find(filter).FirstOrDefault();
            if (existing != null)
                return existing;

            var legacy = database.GetCollection<PlayerInventoryDocument>(LegacyPlayerInventoryCollectionName);
            PlayerInventoryDocument legacyDoc = legacy.Find(filter).FirstOrDefault();
            PlayerInventoryDocument clone;
            if (legacyDoc != null)
            {
                clone = new PlayerInventoryDocument
                {
                    _id = ObjectId.GenerateNewId(),
                    playerId = legacyDoc.playerId,
                    Currencies = legacyDoc.Currencies?.DeepClone().AsBsonDocument ?? new BsonDocument(),
                    InventoryItems = legacyDoc.InventoryItems?.DeepClone().AsBsonDocument ?? new BsonDocument()
                };
            }
            else
            {
                clone = new PlayerInventoryDocument
                {
                    _id = ObjectId.GenerateNewId(),
                    playerId = objectId.ToString(),
                   Currencies = new BsonDocument(),
                    InventoryItems = new BsonDocument()
                };
            }

            try
            {
                target.InsertOne(clone);
                return clone;
            }
             catch (MongoWriteException)
           {
                return target.Find(filter).First();
            }
         }

       public PlayerInventoryDocument GetPlayerInventoryDocument(ObjectId objectId)
        {
            return EnsurePlayerInventory(objectId);
        }

        public void AddItemToPlayerInventoryDocument(ObjectId objectId, BoltInventoryItem boltInventoryItem, int itemId)
        {
            EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());
            var update = new UpdateDefinitionBuilder<PlayerInventoryDocument>().Set("InventoryItems." + itemId, boltInventoryItem.GetBsonElements());
            definitionsCollection.UpdateOne(filter, update);
       }
        public int AddItemToPlayerInventoryDocumentAtomic(ObjectId objectId, BoltInventoryItem boltInventoryItem)
        {
           if (boltInventoryItem == null) throw new ArgumentNullException(nameof(boltInventoryItem));
            EnsurePlayerInventory(objectId);
            IMongoCollection<BsonDocument> collection =
               GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
            string playerId = objectId.ToString();

            for (int attempt = 0; attempt < 32; attempt++)
            {
                BsonDocument doc = collection.Find(
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId)).FirstOrDefault();
                if (doc == null) throw new InvalidOperationException("Inventory was not found.");

                int next = 1;
                if (doc.TryGetValue("InventoryItems", out BsonValue rawItems) && rawItems.IsBsonDocument)
                {
                    foreach (BsonElement e in rawItems.AsBsonDocument.Elements)
                        if (int.TryParse(e.Name, out int id) && id >= next) next = id + 1;
                }

                string path = "InventoryItems." + next;
                FilterDefinition<BsonDocument> filter =
                    Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                    Builders<BsonDocument>.Filter.Exists(path, false);
               UpdateResult result = collection.UpdateOne(
                    filter,
                    Builders<BsonDocument>.Update.Set(path, boltInventoryItem.GetBsonElements()));
                if (result.ModifiedCount == 1) return next;
            }
            throw new InvalidOperationException("Could not allocate a unique inventory item id.");
        }
        public bool SetItemFlag(ObjectId objectId, int itemId, int flag)
        {
            EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());
            var update = new UpdateDefinitionBuilder<PlayerInventoryDocument>().Set("InventoryItems." + itemId + ".flags", flag);
            definitionsCollection.UpdateOne(filter, update);
            return true;
        }
        public bool SetItemProperty(ObjectId objectId, int itemId, BoltInventoryItemProperty itemProperty)
        {
             EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());
            var update = new UpdateDefinitionBuilder<PlayerInventoryDocument>().Set("InventoryItems." + itemId + ".properties." + itemProperty.Name, itemProperty.GetValue(itemProperty.Type));
            definitionsCollection.UpdateOne(filter, update);
            return true;
        }
        public bool SetItemProperties(ObjectId objectId, int itemId, BoltInventoryItemProperty[] itemProperties)
        {
            foreach (BoltInventoryItemProperty a in itemProperties) SetItemProperty(objectId, itemId, a);
            return true;
        }
        public bool RemoveItemProperty(ObjectId objectId, int itemId, string propertyName)
        {
            EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filter = Builders<PlayerInventoryDocument>.Filter.Eq("playerId", objectId.ToString());
            var update = Builders<PlayerInventoryDocument>.Update
                .Unset("InventoryItems." + itemId + ".properties." + propertyName);
            collection.UpdateOne(filter, update);
            return true;
       }
         public void RemoveItemToPlayerInventoryDocument(ObjectId objectId, int itemId)
        {
           EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());
            var update = new UpdateDefinitionBuilder<PlayerInventoryDocument>().Unset("InventoryItems." + itemId);
            definitionsCollection.UpdateOne(filter, update);
        }

        public void SetPlayerInventoryItemQuantity(ObjectId objectId, int itemId, int quantity)
         {
            EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filter = Builders<PlayerInventoryDocument>.Filter.Eq("playerId", objectId.ToString());
            var update = Builders<PlayerInventoryDocument>.Update
                .Set("InventoryItems." + itemId + ".quantity", Math.Max(0, quantity));
            collection.UpdateOne(filter, update);
        }

        public void CurrencyUpdate(ObjectId objectId, int num, double value)
        {
            EnsurePlayerInventory(objectId);
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());
            var update = new UpdateDefinitionBuilder<PlayerInventoryDocument>().Set("Currencies." + num, value);
            definitionsCollection.UpdateOne(filter, update);
        }

       private static double ReadCurrencyValue(BsonValue value)
        {
            if (value == null || value.IsBsonNull)
               return 0;

            if (value.IsInt32) return value.AsInt32;
            if (value.IsInt64) return value.AsInt64;
            if (value.IsDouble) return value.AsDouble;
            if (value.IsDecimal128) return (double)value.AsDecimal128;
            if (value.IsString && double.TryParse(
                    value.AsString,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out double parsed))
                return parsed;
            if (value.IsBsonDocument)
            {
                BsonDocument doc = value.AsBsonDocument;
                foreach (string key in new[] { "value", "Value", "amount", "Amount" })
                    if (doc.TryGetValue(key, out BsonValue nested))
                       return ReadCurrencyValue(nested);
            }

            throw new InvalidOperationException($"Unsupported currency type: {value.BsonType}.");
        }

        public bool IsEnoughFunds(string playerId, string currencyId, double amount)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);

            var filter = Builders<PlayerInventoryDocument>.Filter.Eq("playerId", playerId);
            var inventory = collection.Find(filter).FirstOrDefault();
            if (inventory == null)
                return false;

            if (!inventory.Currencies.TryGetValue(currencyId, out var currencyValue))
                return false;

            var currentAmount = ReadCurrencyValue(currencyValue);
            return currentAmount >= amount;
        }

        private const string InventoryMutationLedgerCollection = "inventory_mutation_ledger";

        public bool TryBeginInventoryMutation(string playerId, string method, string requestId, out string mutationKey)
        {
            mutationKey = $"{playerId}:{method}:{requestId}";
            if (string.IsNullOrWhiteSpace(playerId) || string.IsNullOrWhiteSpace(method) || string.IsNullOrWhiteSpace(requestId))
                return false;
            try
           {
                var col = GetDatabase().GetCollection<BsonDocument>(InventoryMutationLedgerCollection);
                col.InsertOne(new BsonDocument
                {
                    ["_id"] = mutationKey,
                    ["playerId"] = playerId,
                   ["method"] = method,
                    ["requestId"] = requestId,
                    ["state"] = "pending",
                   ["createdAt"] = DateTime.UtcNow
                });
                return true;
            }
            catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {
                return false;
            }
        }

        public void CompleteInventoryMutation(string mutationKey)
        {
            if (string.IsNullOrWhiteSpace(mutationKey)) return;
            var col = GetDatabase().GetCollection<BsonDocument>(InventoryMutationLedgerCollection);
            col.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("_id", mutationKey),
                 Builders<BsonDocument>.Update
                    .Set("state", "committed")
                    .Set("completedAt", DateTime.UtcNow));
        }

        public void AbortInventoryMutation(string mutationKey)
        {
            if (string.IsNullOrWhiteSpace(mutationKey)) return;
             GetDatabase().GetCollection<BsonDocument>(InventoryMutationLedgerCollection)
                .DeleteOne(Builders<BsonDocument>.Filter.Eq("_id", mutationKey));
        }

        public bool TrySpendCurrencyAtomic(ObjectId objectId, int currencyId, double amount,
            out double before, out double after)
        {
             before = 0;
            after = 0;
           if (amount < 0 || currencyId <= 0 || double.IsNaN(amount) || double.IsInfinity(amount)) return false;
            if (amount == 0) return true;

            var col = GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
           string playerId = objectId.ToString();
            string path = $"Currencies.{currencyId}";
            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Gte(path, amount);
            UpdateDefinition<BsonDocument> update =
                 Builders<BsonDocument>.Update.Inc(path, -amount);

            BsonDocument old = col.FindOneAndUpdate(
                filter,
                update,
                new FindOneAndUpdateOptions<BsonDocument>
                {
                    ReturnDocument = ReturnDocument.Before
                });

            if (old == null) return false;
            if (old.TryGetValue("Currencies", out BsonValue currencies) &&
                currencies.IsBsonDocument &&
                currencies.AsBsonDocument.TryGetValue(currencyId.ToString(), out BsonValue raw))
                before = ReadCurrencyValue(raw);
            after = before - amount;
            return true;
        }

        public bool TryExchangeCurrencyAtomic(
            ObjectId objectId,
            int spendCurrencyId,
            double spendAmount,
            int rewardCurrencyId,
            double rewardAmount,
            out double spendBefore,
            out double spendAfter,
            out double rewardBefore,
            out double rewardAfter)
        {
            spendBefore = spendAfter = rewardBefore = rewardAfter = 0;
           if (spendCurrencyId <= 0 || rewardCurrencyId <= 0 ||
                spendCurrencyId == rewardCurrencyId || spendAmount <= 0 || rewardAmount <= 0 ||
                double.IsNaN(spendAmount) || double.IsInfinity(spendAmount) ||
                double.IsNaN(rewardAmount) || double.IsInfinity(rewardAmount))
                return false;

            EnsurePlayerInventory(objectId);
            var col = GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
            string playerId = objectId.ToString();
            string spendPath = $"Currencies.{spendCurrencyId}";
            string rewardPath = $"Currencies.{rewardCurrencyId}";

            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Gte(spendPath, spendAmount);
            UpdateDefinition<BsonDocument> update = Builders<BsonDocument>.Update.Combine(
                Builders<BsonDocument>.Update.Inc(spendPath, -spendAmount),
                Builders<BsonDocument>.Update.Inc(rewardPath, rewardAmount));

            BsonDocument old = col.FindOneAndUpdate(
                filter,
                update,
                new FindOneAndUpdateOptions<BsonDocument>
                {
                    ReturnDocument = ReturnDocument.Before
                });
            if (old == null) return false;
            if (old.TryGetValue("Currencies", out BsonValue currencies) && currencies.IsBsonDocument)
            {
                BsonDocument values = currencies.AsBsonDocument;
                if (values.TryGetValue(spendCurrencyId.ToString(), out BsonValue spendRaw))
                    spendBefore = ReadCurrencyValue(spendRaw);
                if (values.TryGetValue(rewardCurrencyId.ToString(), out BsonValue rewardRaw))
                    rewardBefore = ReadCurrencyValue(rewardRaw);
            }

            spendAfter = spendBefore - spendAmount;
            rewardAfter = rewardBefore + rewardAmount;
            return true;
        }

        public void RefundCurrencyAtomic(ObjectId objectId, int currencyId, double amount)
        {
            if (amount <= 0 || currencyId <= 0 || double.IsNaN(amount) || double.IsInfinity(amount)) return;
            var col = GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
            string path = $"Currencies.{currencyId}";
            col.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("playerId", objectId.ToString()),
                Builders<BsonDocument>.Update.Inc(path, amount));
        }

        public bool TryDebitCurrencyAtomic(ObjectId objectId, int currencyId, double amount)
        {
            if (currencyId <= 0 || amount <= 0 || double.IsNaN(amount) || double.IsInfinity(amount))
                return false;

            EnsurePlayerInventory(objectId);
            IMongoCollection<BsonDocument> collection =
                GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
            string playerId = objectId.ToString();
             string path = $"Currencies.{currencyId}";

            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", playerId) &
                Builders<BsonDocument>.Filter.Gte(path, amount);
            UpdateResult result = collection.UpdateOne(
                filter,
                Builders<BsonDocument>.Update.Inc(path, -amount));
           return result.ModifiedCount == 1;
        }

        public void CurrencyMinusValue(ObjectId objectId, int currencyId, double amount)
        {
            if (currencyId <= 0 || amount <= 0 || double.IsNaN(amount) || double.IsInfinity(amount))
                throw new ArgumentOutOfRangeException(nameof(amount), "Currency debit must be finite and positive.");
            if (!TryDebitCurrencyAtomic(objectId, currencyId, amount))
                 throw new InvalidOperationException("Not enough funds.");
        }

        public void CurrencyPlusValue(ObjectId objectId, int currencyId, double amount)
        {
            if (currencyId <= 0 || amount <= 0 || double.IsNaN(amount) || double.IsInfinity(amount))
                throw new ArgumentOutOfRangeException(nameof(amount), "Currency credit must be finite and positive.");

            EnsurePlayerInventory(objectId);
            IMongoCollection<BsonDocument> collection =
                GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
            string path = $"Currencies.{currencyId}";
            UpdateResult result = collection.UpdateOne(
                Builders<BsonDocument>.Filter.Eq("playerId", objectId.ToString()),
                Builders<BsonDocument>.Update.Inc(path, amount));
            if (result.MatchedCount != 1)
                throw new InvalidOperationException("Inventory was not found.");
        }

        public bool CreditCurrencyOnce(ObjectId objectId, int currencyId, double amount, string markerId)
        {
           if (currencyId <= 0 || amount <= 0 || string.IsNullOrWhiteSpace(markerId)) return false;
            EnsurePlayerInventory(objectId);
            IMongoCollection<BsonDocument> collection =
               GetDatabase().GetCollection<BsonDocument>(PlayerInventoryCollectionName);
           string safeMarker = new string(markerId.Select(ch => char.IsLetterOrDigit(ch) ? ch : '_').ToArray());
            if (safeMarker.Length > 120) safeMarker = safeMarker.Substring(0, 120);
             string markerPath = "EconomyCreditMarkers033." + safeMarker;
            string currencyPath = $"Currencies.{currencyId}";
            FilterDefinition<BsonDocument> filter =
                Builders<BsonDocument>.Filter.Eq("playerId", objectId.ToString()) &
                Builders<BsonDocument>.Filter.Exists(markerPath, false);
            UpdateDefinition<BsonDocument> update = Builders<BsonDocument>.Update.Combine(
                Builders<BsonDocument>.Update.Inc(currencyPath, amount),
                Builders<BsonDocument>.Update.Set(markerPath, DateTime.UtcNow));
            return collection.UpdateOne(filter, update).ModifiedCount == 1;
        }

        public BoltInventoryItem? GetItemInPlayerInventoryByInvId(ObjectId objectId, int definitionId)
        {
            PlayerInventoryDocument inventory = GetPlayerInventoryDocument(objectId);
            if (inventory?.InventoryItems == null)
                return null;

            foreach (BsonElement element in inventory.InventoryItems.Elements)
            {
                if (!element.Value.IsBsonDocument)
                    continue;

                BsonDocument item = element.Value.AsBsonDocument;
                if (item.GetValue("itemDefinitionId", 0).ToInt32() != definitionId)
                    continue;

                var result = new BoltInventoryItem
                {
                    itemDefinitionId = definitionId,
                    quantity = item.GetValue("quantity", 1).ToInt32(),
                    flags = item.GetValue("flags", 0).ToInt32(),
                    date = item.TryGetValue("date", out BsonValue date) && date.IsValidDateTime
                        ? (BsonDateTime)date.AsBsonDateTime.ToUniversalTime().Ticks
                        : (BsonDateTime)DateTime.UtcNow
                };

                if (item.TryGetValue("properties", out BsonValue properties) &&
                    properties.IsBsonDocument)
                {
                    result.Properties = properties.AsBsonDocument
                        .Elements
                        .Select(property => property.ToBoltInventoryItemProperty())
                        .ToList();
                }

                return result;
            }

            return null;
        }
        public BoltInventoryItem? GetItemInPlayerInventory(ObjectId objectId, int id)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", objectId.ToString());

            var playerInventoryDocument = definitionsCollection.Find(filter).FirstOrDefault();

            if (playerInventoryDocument != null)
            {
                var inventoryItems = playerInventoryDocument.InventoryItems;
               var bsonInventoryItem = inventoryItems.FirstOrDefault(item => item.Name == id.ToString());

                var inventoryItem = new BoltInventoryItem
                {
                    itemDefinitionId = bsonInventoryItem.Value.AsBsonDocument.GetValue("itemDefinitionId").AsInt32,
                    quantity = bsonInventoryItem.Value.AsBsonDocument.GetValue("quantity").AsInt32,
                    flags = bsonInventoryItem.Value.AsBsonDocument.GetValue("flags").AsInt32,
                    date = (BsonDateTime)bsonInventoryItem.Value.AsBsonDocument.GetValue("date").AsBsonDateTime.ToUniversalTime().Ticks
                };

                var propertiesValue = bsonInventoryItem.Value.AsBsonDocument.GetValue("properties");
                if (propertiesValue != null && propertiesValue.IsBsonDocument)
                {
                    var properties = propertiesValue.AsBsonDocument;
                    if (properties != null && properties.Values.Any())
                    {
                        inventoryItem.Properties = properties
                            .ToList()
                            .Select(property => property.ToBoltInventoryItemProperty())
                            .ToList();
                    }
                }

                return inventoryItem;
           }

            return null;
        }
        public ObjectId CreatePlayerInventory(ObjectId playerId, int starterGold = 500)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(PlayerInventoryCollectionName);
           BoltInventoryStarterPackDocument starterPack = null;
            try
            {
                starterPack = GetBoltInventoryStarterPack();
            }
            catch (System.Exception)
            {
            }

             BsonArray starterItems = starterPack?.items ?? new BsonArray();
            BsonDocument starterCurrencies = starterPack?.currencies ?? new BsonDocument();
            Dictionary<string, BsonDocument> boltInventoryItems = new Dictionary<string, BsonDocument>();
           for (int x = 0; x < starterItems.Count; x++)
            {
               if (!starterItems[x].IsInt32)
                    continue;

                boltInventoryItems.Add(
                    (x + 1).ToString(),
                    new BoltInventoryItem
                    {
                        itemDefinitionId = starterItems[x].AsInt32,
                        quantity = 1,
                        flags = 0,
                        date = (BsonDateTime)DateTime.Now
                    }.GetBsonElements());
            }

            BsonValue currency101 = starterCurrencies.GetValue("101", new BsonInt32(0));
            BsonValue currency102 = new BsonInt32(Math.Max(0, starterGold));

            collection.InsertOne(new BsonDocument(new BsonElement[]
                {
                new BsonElement("playerId", playerId.ToString()),
                new BsonElement("Currencies", new BsonDocument(new BsonElement[]
                {
                    new BsonElement("101", currency101),
                    new BsonElement("102", currency102)
                } as IEnumerable<BsonElement>)),
                new BsonElement("InventoryItems", new BsonDocument(boltInventoryItems)),
                } as IEnumerable<BsonElement>));

            var definitionsCollection = database.GetCollection<PlayerInventoryDocument>(PlayerInventoryCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<PlayerInventoryDocument>();
            var filter = filterBuilder.Eq("playerId", playerId.ToString());
            var createdItemDefinition = definitionsCollection.Find(filter).First();
            return createdItemDefinition._id;
        }

        public Task<ObjectId> CreatePlayerInventoryAsync(ObjectId objectId, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => CreatePlayerInventory(objectId), processName, processDescription, parentProcessId);
        }

        private const string InventoryItemPropertyDefinitionCollectionName = InventoryCatalog.PropertyCollection;

        public BoltInventoryItemPropertyDefinitionsDocument GetInventoryItemPropertyDefinition(int key, int gameId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemPropertyDefinitionsDocument>(InventoryItemPropertyDefinitionCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<BoltInventoryItemPropertyDefinitionsDocument>();
            var filter = filterBuilder.Eq("key", key) & filterBuilder.Eq("gid", gameId);
            BoltInventoryItemPropertyDefinitionsDocument exact = collection.Find(filter).FirstOrDefault();
            if (exact != null) return exact;
            return collection.Find(filterBuilder.Eq("key", key))
                 .SortByDescending(x => x.enabled)
                .ThenBy(x => x.gid)
                .FirstOrDefault();
        }

       public Task<BoltInventoryItemPropertyDefinitionsDocument> GetInventoryItemPropertyDefinitionAsync(int key, int gameId, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => GetInventoryItemPropertyDefinition(key, gameId), processName, processDescription, parentProcessId);
        }

        public ObjectId CreateInventoryItemPropertyDefinition(BoltInventoryItemPropertyDefinitionCreationData definitionCreationData)
         {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(InventoryItemPropertyDefinitionCollectionName);
            collection.InsertOne(definitionCreationData.GetDocument());

            var definitionsCollection = database.GetCollection<BoltInventoryItemPropertyDefinitionsDocument>(InventoryItemPropertyDefinitionCollectionName);
            var filterBuilder = new FilterDefinitionBuilder<BoltInventoryItemPropertyDefinitionsDocument>();
            var filter = filterBuilder.Eq("key", definitionCreationData.Key) &
                         filterBuilder.Eq("gid", definitionCreationData.GameId);
             var createdItemDefinition = definitionsCollection.Find(filter).First();
            return createdItemDefinition._id;
        }

        public Task<ObjectId> CreateInventoryItemPropertyDefinitionAsync(BoltInventoryItemPropertyDefinitionCreationData definitionCreationData, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => CreateInventoryItemPropertyDefinition(definitionCreationData), processName, processDescription, parentProcessId);
        }

        public void ReplaceInventoryItemPropertyDefinition(BoltInventoryItemPropertyDefinitionsDocument definitionDocument)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemPropertyDefinitionsDocument>(InventoryItemPropertyDefinitionCollectionName);
            var filter = new FilterDefinitionBuilder<BoltInventoryItemPropertyDefinitionsDocument>().Eq("_id", definitionDocument._id);
            var result = collection.ReplaceOne(filter, definitionDocument);
        }

        public Task ReplaceInventoryItemPropertyDefinitionAsync(BoltInventoryItemPropertyDefinitionsDocument definitionDocument, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => ReplaceInventoryItemPropertyDefinition(definitionDocument), processName, processDescription, parentProcessId);
        }

        public List<BoltInventoryItemPropertyDefinitionsDocument> GetAllItemPropertyDefinitions()
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryItemPropertyDefinitionsDocument>(InventoryItemPropertyDefinitionCollectionName);
            FilterDefinition<BoltInventoryItemPropertyDefinitionsDocument> filter = new FilterDefinitionBuilder<BoltInventoryItemPropertyDefinitionsDocument>().Empty;
            return collection.Find(filter).ToList();
        }

        public Task<List<BoltInventoryItemPropertyDefinitionsDocument>> GetAllItemPropertyDefinitionsAsync(string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => GetAllItemPropertyDefinitions(), processName, processDescription, parentProcessId);
        }

        private const string InventoryStarterPackCollectionName = "inventory_starter_pack";

        public BoltInventoryStarterPackDocument GetBoltInventoryStarterPack()
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryStarterPackDocument>(InventoryStarterPackCollectionName);
            return collection.Find(new FilterDefinitionBuilder<BoltInventoryStarterPackDocument>().Empty).First();
        }

       public Task<BoltInventoryStarterPackDocument> GetBoltInventoryStarterPackAsync()
       {
            return Async(GetBoltInventoryStarterPack);
        }

        public Task<BoltInventoryStarterPackDocument> GetBoltInventoryStarterPackAsync(string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(GetBoltInventoryStarterPack, processName, processDescription, parentProcessId);
        }

        public void SetBoltInventoryStarterPack(BoltInventoryStarterPackDocument starterPackDocument)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BoltInventoryStarterPackDocument>(InventoryStarterPackCollectionName);
            var filter = new FilterDefinitionBuilder<BoltInventoryStarterPackDocument>().Eq("_id", starterPackDocument._id);
            var result = collection.ReplaceOne(filter, starterPackDocument);
        }
         public void CreateBoltInventoryStarterPack()
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(InventoryStarterPackCollectionName);
            collection.InsertOne(new BsonDocument(new BsonElement[]
                {
                new BsonElement("enabled", true),
                new BsonElement("gid", 1),
               new BsonElement("items", new BsonArray(new List<int> { 101 })),
                new BsonElement("currencies", new BsonDocument()),
                } as IEnumerable<BsonElement>));
        }
        public Task SetBoltInventoryStarterPackAsync(BoltInventoryStarterPackDocument starterPackDocument)
        {
            return Async(() => SetBoltInventoryStarterPack(starterPackDocument));
        }

        public Task SetBoltInventoryStarterPackAsync(BoltInventoryStarterPackDocument starterPackDocument, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => SetBoltInventoryStarterPack(starterPackDocument), processName, processDescription, parentProcessId);
        }

    }
}
