namespace TspServer.MongoDB
{
    public static class GameSettingsContract
    {
        public const string TargetGameUid = "e0eb8b95-72b3-4821-9dce-31bbb632da7c";
        public const string TargetVersion = "0.33.0";
        public const int TargetVersionCode = 203491;
    }
}
