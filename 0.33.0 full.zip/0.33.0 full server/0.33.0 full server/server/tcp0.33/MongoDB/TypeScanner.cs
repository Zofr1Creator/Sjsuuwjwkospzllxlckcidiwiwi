using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace TspServer.MongoDB
{
    internal static class TypeScanner
    {
        public static IEnumerable<Type> FindDerivedTypes<T>(
            bool includeBaseType = false,
            bool includeAbstractTypes = false)
        {
            Type baseType = typeof(T);

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (Type type in GetLoadableTypes(assembly))
                {
                    if (!baseType.IsAssignableFrom(type))
                        continue;

                    if (!includeBaseType && type == baseType)
                       continue;

                    if (!includeAbstractTypes && type.IsAbstract)
                        continue;

                    yield return type;
               }
            }
        }

        private static IEnumerable<Type> GetLoadableTypes(Assembly assembly)
        {
            try
            {
               return assembly.GetTypes();
            }
           catch (ReflectionTypeLoadException ex)
            {
                return ex.Types.Where(type => type != null).Cast<Type>();
            }
        }
    }
}
