namespace TspServer.Bolt;

public abstract class MessageMapper<TP, TO>
{
    public abstract TO ToOriginal(TP proto);

    public abstract TP ToProto(TO original);

    public List<TO> ToOriginalList(IEnumerable<TP> array)
    {
        if (array == null)
         {
            throw new ArgumentNullException(nameof(array));
        }
        return array.Select(ToOriginal).ToList();
    }

    public List<TP> ToProtoList(IEnumerable<TO> array)
    {
        if (array == null)
        {
            throw new ArgumentNullException(nameof(array));
        }
        return array.Select(ToProto).ToList();
    }

   public TO[] ToOriginalArray(IEnumerable<TP> array)
    {
        if (array == null)
       {
            throw new ArgumentNullException(nameof(array));
        }
        return array.Select(ToOriginal).ToArray();
    }

   public TP[] ToProtoArray(IEnumerable<TO> array)
    {
        if (array == null)
        {
            throw new ArgumentNullException(nameof(array));
        }
        return array.Select(ToProto).ToArray();
    }
}
