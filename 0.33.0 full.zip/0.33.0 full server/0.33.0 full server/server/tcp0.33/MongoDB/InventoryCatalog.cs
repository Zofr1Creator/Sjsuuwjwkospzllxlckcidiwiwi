using MongoDB.Bson;
using MongoDB.Driver;

namespace TspServer.MongoDB
{
     public static class InventoryCatalog
    {
        public const string ItemCollection = "inventory_items";

        public const string PropertyCollection = "inventory_item_properties";

        public const string CollectionsCollection = "inventory_collections";

        public const string DropGroupsCollection = "inventory_drop_groups";

        public const string ManifestCollection = "inventory_catalog_manifest";

        public const string PlayerInventoryCollection = "player_inventory";

        public const string ContainerRawCollection = "inventory_container_raw";

        public const string LegacyItemCollection = "inventory_item_definition";

        public const string LegacyPropertyCollection = "inventory_item_property_definition";

       public const string LegacyCollectionsCollection = "inventory_collections";

        public const string LegacyDropGroupsCollection = "inventory_drop_groups";

        public const string LegacyPlayerInventoryCollection = "inventory";

        public static FilterDefinition<BsonDocument> DefinitionKey(int key, int gid = 1)
        {
             return Builders<BsonDocument>.Filter.Eq("key", key) &
                   Builders<BsonDocument>.Filter.Eq("gid", gid);
        }
    }
}
