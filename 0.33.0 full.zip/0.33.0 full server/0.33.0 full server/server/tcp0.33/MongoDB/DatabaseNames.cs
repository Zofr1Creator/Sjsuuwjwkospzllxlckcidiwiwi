namespace TspServer.MongoDB
{

     public static class DatabaseNames
    {
        public const string Database = "Main";

        public static class Collections
        {
            public const string GameSettings = "game_settings";
            public const string Players = "players";
            public const string Devices = "devices";
            public const string GoogleAccounts = "accounts_google";
            public const string LocalAccounts = "accounts_test";
           public const string IntegrityHashes = "hashes";
            public const string PlayerEvents = "player_events";
            public const string FileStorage = "file_storage";
           public const string Lobbies = "lobbies";
             public const string RankedProfiles = "ranked_profiles";
            public const string RankedMatches = "ranked_matches";
            public const string RankedLedger = "ranked_ledger";
         }
    }
}
