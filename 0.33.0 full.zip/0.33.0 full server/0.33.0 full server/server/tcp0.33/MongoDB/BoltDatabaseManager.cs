using System;
using System.Collections.Generic;
using TspServer.MongoDB.Data;

namespace TspServer.MongoDB
{
    public static class BoltDatabaseManager
    {
        private static readonly Dictionary<BoltDatabaseType, Type> ProviderTypes =
            new(new BoltDatabaseTypeEqualityComparer());

        private static readonly Dictionary<BoltDatabaseInfo, BoltDatabaseProviderBase> Connections =
            new(new BoltDatabaseInfoEqualityComparer());

        public static void Initialize()
        {
            ProviderTypes.Clear();

            foreach (Type providerType in TypeScanner.FindDerivedTypes<BoltDatabaseProviderBase>())
            {
                if (Activator.CreateInstance(providerType) is not BoltDatabaseProviderBase provider)
                    continue;

                ProviderTypes[provider.DatabaseType] = providerType;
            }
        }

        public static BoltDatabaseProviderBase Connect(BoltDatabaseInfo databaseInfo)
        {
            if (!Connections.TryGetValue(databaseInfo, out BoltDatabaseProviderBase? provider))
            {
                if (!ProviderTypes.TryGetValue(databaseInfo.DatabaseType, out Type? providerType))
                {
                    throw new InvalidOperationException(
                        $"No database provider is registered for {databaseInfo.DatabaseType}.");
                }

                provider = Activator.CreateInstance(providerType) as BoltDatabaseProviderBase
                     ?? throw new InvalidOperationException(
                        $"Could not create database provider {providerType.FullName}.");

                Connections.Add(databaseInfo, provider);
            }
            provider.Connect(databaseInfo);
            return provider;
       }

        public static void Disconnect(BoltDatabaseInfo databaseInfo)
       {
            if (!Connections.Remove(databaseInfo, out BoltDatabaseProviderBase? provider))
                return;

            provider.Disconnect();
        }
    }
}
