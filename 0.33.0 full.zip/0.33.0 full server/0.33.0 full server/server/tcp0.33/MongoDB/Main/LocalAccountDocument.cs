using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TspServer.MongoDB.Main
{
    public class LocalAccountDocument
    {
       [BsonId]
         public ObjectId _id { get; set; }

        [BsonElement("token")]
        public string token { get; set; }
        [BsonElement("gid")]
        public int gid { get; set; }

        [BsonElement("playerId")]
        public string playerId { get; set; }

        [BsonElement("username")]
        public string username { get; set; }

        [BsonElement("passSalt")]
        public string passSalt { get; set; }

        [BsonElement("passHash")]
        public string passHash { get; set; }
    }
}
