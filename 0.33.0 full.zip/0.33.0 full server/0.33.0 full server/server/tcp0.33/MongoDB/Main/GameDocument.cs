using System;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class GameDocument
    {
       private int _id1;
        private string _gameUid;
        private string _code;
       private BsonDocument _androidSettings;
        private BsonDocument _iosSettings;
        private string _minVersion;
        private string _defaultLocale;

       public int _id
        {
            get => _id1;
            set => _id1 = value;
        }
        public string gameUid
        {
            get => _gameUid;
            set => _gameUid = value;
        }

        public string code
        {
            get => _code;
            set => _code = value;
         }

        public BsonDocument androidSettings
         {
            get => _androidSettings;
           set => _androidSettings = value;
         }

        public BsonDocument iosSettings
        {
            get => _iosSettings;
            set => _iosSettings = value;
        }
        public string minVersion
        {
            get => _minVersion;
            set => _minVersion = value;
        }

        public string defaultLocale
        {
            get => _defaultLocale;
            set => _defaultLocale = value;
        }

    }
}
