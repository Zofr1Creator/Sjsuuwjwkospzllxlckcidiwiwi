using System;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class FileStoragesDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public BsonDocument files { get; set; }
    }
}
