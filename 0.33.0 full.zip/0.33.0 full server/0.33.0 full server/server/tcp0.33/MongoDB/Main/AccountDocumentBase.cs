using System;

namespace TspServer.MongoDB.Main
{
    [Serializable]
     public abstract class AccountDocumentBase : DocumentModelBase
    {
        private string _playerId;
        private int _gid;

        public string playerId
        {
            get => _playerId;
            set => _playerId = value;
       }

        public int gid
        {
            get => _gid;
            set => _gid = value;
       }

    }
}
