using System;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class HashDocument : DocumentModelBase
    {
        public string version { get; set; }
        public string gameId { get; set; }
        public string hash { get; set; }
        public string signature { get; set; }
   }
}
