using System;
using System.Collections.Generic;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class PlayerStatsDocument : DocumentModelBase
    {
        public string playerId { get; set; } = string.Empty;
        public BsonDocument stats { get; set; } = new();
    }

    public static class PlayerStatsExtension
    {
        private static readonly string[] GameModes =
        {
            "ArmsRace",
            "CaptureTheFlag",
            "DeathMatch",
            "Defuse",
            "RankedDefuse",
            "Ranked2v2",
            "KingOfTheHill",
            "MadSanta",
            "Rampage",
            "SniperDuel",
            "SnowMadness"
        };

        private static readonly string[] WeaponNames =
        {
            "g22",
            "usp",
            "p350",
            "deagle",
            "tec9",
            "fiveseven",
            "ump45",
            "mp7",
            "p90",
            "mp5",
            "m4a1",
            "akr",
            "akr12",
            "m4",
            "m16",
            "famas",
            "fnfal",
            "awm",
            "m40",
            "m110",
            "sm1014",
            "fabm",
            "m60",
            "knife",
            "knifebayonet",
            "knifekarambit",
            "jkommando",
            "knifebutterfly",
            "flipknife",
            "kunaiknife",
            "scorpionknife",
            "knifetanto",
            "yokaihands"
        };

        private static readonly string[] ModeStats =
        {
            "damage",
            "assists",
            "deaths",
            "games_played",
            "headshots",
            "hits",
            "kills",
            "shots"
        };

        private static readonly string[] WeaponStats =
        {
            "shots",
            "kills",
            "hits",
            "headshots",
            "damage"
        };

        public static string WrapMode(string apiName, string gameMode)
        {
            return gameMode.ToLowerInvariant() + "_" + apiName;
        }

        public static string WrapModeGun(string apiName, string gameMode, string weaponName)
        {
            return "gun_"
                + gameMode.ToLowerInvariant()
                + "_"
                + weaponName
                + "_"
                + apiName;
        }

        public static List<BsonElement> GetAllNullStats()
        {
            var result = new List<BsonElement>();

            foreach (string gameMode in GameModes)
            {
                foreach (string stat in ModeStats)
                    result.Add(new BsonElement(WrapMode(stat, gameMode), 0));

                foreach (string weaponName in WeaponNames)
                {
                    foreach (string stat in WeaponStats)
                        result.Add(new BsonElement(WrapModeGun(stat, gameMode, weaponName), 0));
                }
            }

            AddCommonStats(result);
            AddRankedStats(result, "ranked");
            AddRankedStats(result, "ranked_2v2");

            return result;
        }

        private static void AddCommonStats(ICollection<BsonElement> stats)
        {
            stats.Add(new BsonElement("level_id", 0));
            stats.Add(new BsonElement("level_xp", 0));
        }

        private static void AddRankedStats(ICollection<BsonElement> stats, string prefix)
        {
            Add(stats, prefix + "_rank", 0);
            Add(stats, prefix + "_current_mmr", 500);
            Add(stats, prefix + "_best_rank", 0);
            Add(stats, prefix + "_best_rank_history1", 0);
            Add(stats, prefix + "_played_matches", 0);
            Add(stats, prefix + "_won_match_count", 0);
            Add(stats, prefix + "_calibration_status", 0);
            Add(stats, prefix + "_calibration_match_count", 0);
            Add(stats, prefix + "_calibration_won_match_count", 0);
            Add(stats, prefix + "_ban_code", -1);
            Add(stats, prefix + "_ban_duration", 0);
            Add(stats, prefix + "_banned_match_no", 0);
            Add(stats, prefix + "_ban_reason", 0);
            Add(stats, prefix + "_banned_until", 0);
            Add(stats, prefix + "_last_match_status", 0);
            Add(stats, prefix + "_last_activity_time1", 0);
            Add(stats, prefix + "_last_activity_time2", 0);
            Add(stats, prefix + "_last_match_start_time", 0);
            Add(stats, prefix + "_last_match_running", 0);
        }

        private static void Add(ICollection<BsonElement> stats, string name, int value)
        {
            stats.Add(new BsonElement(name, value));
        }
    }
}
