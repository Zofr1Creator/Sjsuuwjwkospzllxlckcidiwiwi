using System;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class BoltPlayerGameEventDocument : DocumentModelBase
    {
        public string playerId { get; set; }
        public int currentLevel { get; set; }
        public int points { get; set; }
    }
}
