using System;
using System.Globalization;
using Axlebolt.Bolt.Protobuf2;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main.PlayerStats
{
    public static class PlayerStatsExtension
    {
        public static PlayerStat GetPlayerStat(this BsonElement bsonElement)
        {
            string statName = bsonElement.Name;
            BsonValue value = bsonElement.Value;

            if (value == null || value.IsBsonNull)
            {

                throw new InvalidOperationException(
                    $"Player stat '{statName}' contains a null BSON value.");
             }


            try
            {
                StatDefType statDefType = value.BsonType.GetStatDefType();

                var playerStat = new PlayerStat
                {
                    Name = statName,
                    Type = statDefType
                };

                switch (statDefType)
                {
                     case StatDefType.Int:
                        {
                            int convertedValue = ConvertToInt32(statName, value);
                            playerStat.IntValue = convertedValue;


                            break;
                        }

                    case StatDefType.Float:
                        {
                            float convertedValue = ConvertToFloat(statName, value);
                            playerStat.FloatValue = convertedValue;


                            break;
                        }

                    default:
                        {

                            throw new InvalidOperationException(
                                $"Unsupported StatDefType '{statDefType}' " +
                                $"for player stat '{statName}'.");
                         }
                }

                return playerStat;
            }
            catch (System.Exception)
            {

                throw;
            }
        }

        public static StatDefType GetStatDefType(this BsonType type)
        {
           switch (type)
            {
                case BsonType.Int32:
                case BsonType.Int64:
                case BsonType.Boolean:
                     return StatDefType.Int;

                case BsonType.Double:
                case BsonType.Decimal128:
                    return StatDefType.Float;

               default:
                    throw new InvalidOperationException(
                        $"Unsupported BSON type: {type}");
            }
        }

        private static int ConvertToInt32(
             string statName,
            BsonValue value)
       {
            try
            {
                switch (value.BsonType)
                {
                    case BsonType.Int32:
                        return value.AsInt32;

                    case BsonType.Int64:
                        {
                            long longValue = value.AsInt64;

                            if (longValue < int.MinValue ||
                                longValue > int.MaxValue)
                             {
                                throw new OverflowException(
                                    $"Int64 value {longValue} does not fit");
                            }
                            return (int)longValue;
                        }

                    case BsonType.Double:
                        {
                            double doubleValue = value.AsDouble;

                            if (double.IsNaN(doubleValue) ||
                                double.IsInfinity(doubleValue))
                            {
                                 throw new OverflowException(
                                    $"Double value {doubleValue}");
                            }

                            if (doubleValue < int.MinValue ||
                                doubleValue > int.MaxValue)
                            {
                                throw new OverflowException(
                                   $"Double value {doubleValue}");
                            }

                            return checked((int)doubleValue);
                        }

                    case BsonType.Decimal128:
                        {
                             decimal decimalValue =
                                Decimal128.ToDecimal(value.AsDecimal128);

                            if (decimalValue < int.MinValue ||
                                decimalValue > int.MaxValue)
                            {
                                throw new OverflowException(
                                    $"Decimal128 value {decimalValue} ");
                            }

                            return checked((int)decimalValue);
                       }

                    case BsonType.Boolean:
                        return value.AsBoolean ? 1 : 0;

                    default:
                       throw new InvalidOperationException(
                           $"Stat '{statName}' cannot be converted " +
                            $"from BSON type {value.BsonType}");
                }
            }
            catch (System.Exception ex)
           {
                throw new InvalidOperationException(
                    $"Failed to convert player stat '{statName}' " +
                    $"from {value.BsonType} " +
                    $"Raw value: {FormatBsonValue(value)}.",
                    ex);
            }
        }

        private static float ConvertToFloat(
            string statName,
            BsonValue value)
        {
            try
            {
                double numericValue;

                switch (value.BsonType)
                {
                    case BsonType.Int32:
                        numericValue = value.AsInt32;
                        break;

                    case BsonType.Int64:
                        numericValue = value.AsInt64;
                        break;

                   case BsonType.Double:
                        numericValue = value.AsDouble;
                        break;

                    case BsonType.Decimal128:
                        {
                            decimal decimalValue =
                                Decimal128.ToDecimal(value.AsDecimal128);

                            numericValue = (double)decimalValue;
                            break;
                        }

                    case BsonType.Boolean:
                        numericValue = value.AsBoolean ? 1d : 0d;
                        break;

                    default:
                        throw new InvalidOperationException(
                            $"Stat '{statName}' cannot be converted " +
                            $"from BSON type {value.BsonType} to Float.");
                }

               if (double.IsNaN(numericValue) ||
                    double.IsInfinity(numericValue))
                {
                   throw new OverflowException(
                       $"Numeric value {numericValue} is not finite.");
                }

                if (numericValue < -float.MaxValue ||
                    numericValue > float.MaxValue)
                {
                    throw new OverflowException(
                        $"Numeric value {numericValue} does not fit into Float.");
                }

                return (float)numericValue;
            }
            catch (System.Exception ex)
            {
                throw new InvalidOperationException(
                    $"Failed to convert player stat '{statName}' " +
                    $"from {value.BsonType} to Float. " +
                    $"Raw value: {FormatBsonValue(value)}.",
                    ex);
             }
        }

       private static string FormatBsonValue(BsonValue value)
        {
            if (value == null)
                return "<null>";

            try
            {
                return value.ToString();
           }
            catch
            {
                return $"<{value.BsonType}>";
            }
        }

        public static bool CanConvertToPlayerStat(
           this BsonElement bsonElement)
        {
            if (bsonElement.Value == null ||
                bsonElement.Value.IsBsonNull)
            {

                 return false;
            }

            switch (bsonElement.Value.BsonType)
            {
                case BsonType.Int32:
                case BsonType.Int64:
                case BsonType.Double:
                case BsonType.Decimal128:
                case BsonType.Boolean:
                    return true;

                default:

                    return false;
            }
        }
    }
}
