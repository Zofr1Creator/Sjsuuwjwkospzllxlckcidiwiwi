using System;
using System.Collections.Generic;
using System.Linq;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class PlayerDocument : DocumentModelBase
    {
        private string _uid;
        private string _name;
        private string _avatarId;
         private int _timeInGame;
        private string _class1;
        private BsonDateTime _updateDate;
        private BsonDateTime _createDate;
        public string uid
        {
            get => _uid;
            set => _uid = value;
        }

        public string name
        {
            get => _name;
            set => _name = value;
        }

        public string avatarId
        {
            get => _avatarId;
            set => _avatarId = value;
        }

        public int timeInGame
        {
            get => _timeInGame;
            set => _timeInGame = value;
        }

        public string timeInGameUnit { get; set; }

        public string _class
        {
            get => _class1;
            set => _class1 = value;
        }
        public bool noDetectRoot { get; set; }
        public bool verified { get; set; }
        public bool isBanned { get; set; }

        public int banCode { get; set; }

       public string banReason { get; set; }
        public long bannedUntil { get; set; }
        public string banSource { get; set; }

        public BsonDocument playerStatus { get; set; }

        public BsonDateTime updateDate
        {
            get => _updateDate;
           set => _updateDate = value;
        }

        public BsonDateTime createDate
        {
            get => _createDate;
            set => _createDate = value;
        }
    }
}
