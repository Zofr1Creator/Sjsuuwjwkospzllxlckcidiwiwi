using System;
using MongoDB.Bson;
namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class GoogleAccountDocument : AccountDocumentBase
    {
        public string googleId { get; set; }
       public BsonDocument deviceInfo { get; set; }
       public BsonDocument verification { get; set; }
     }
}
