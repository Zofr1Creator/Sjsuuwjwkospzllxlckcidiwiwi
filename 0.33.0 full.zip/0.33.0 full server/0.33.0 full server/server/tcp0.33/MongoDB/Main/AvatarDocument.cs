using System;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
    [Serializable]
    public class AvatarDocument : DocumentModelBase
    {
        public string avatarId { get; set; }
        public BsonArray bytes { get; set; }
   }
}
