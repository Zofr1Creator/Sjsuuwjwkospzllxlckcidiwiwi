using System;
using System.Collections.Generic;
using MongoDB.Bson;

namespace TspServer.MongoDB.Main
{
     [Serializable]
    public class DevicesInfoDocument : DocumentModelBase
    {
        public string DeviceId { get; set; }
        public string DeviceModel { get; set; }
        public bool isBanned { get; set; }
        public BsonDocument GetBsonElements()
        {
            return new BsonDocument(
                new BsonElement[]
                {
                    new BsonElement("DeviceId", DeviceId),
                    new BsonElement("DeviceModel", DeviceModel)
                }
                as IEnumerable<BsonElement>);
        }
    }
}
