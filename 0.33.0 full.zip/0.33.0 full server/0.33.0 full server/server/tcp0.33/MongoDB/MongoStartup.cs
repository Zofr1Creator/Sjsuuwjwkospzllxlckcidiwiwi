using System;
using System.Threading;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.RpcServer;

namespace TspServer.MongoDB
{
    internal static class MongoStartup
    {
        public static void WaitUntilReady(ServerOptions options, int timeoutSeconds = 45)
        {
            string uri = options.MongoMainUri;
            DateTime deadline = DateTime.UtcNow.AddSeconds(Math.Max(5, timeoutSeconds));
            System.Exception? last = null;

            while (DateTime.UtcNow < deadline)
            {
                try
                {
                    MongoClientSettings settings = MongoClientSettings.FromConnectionString(uri);
                    settings.ServerSelectionTimeout = TimeSpan.FromSeconds(2);
                    settings.ConnectTimeout = TimeSpan.FromSeconds(2);
                    settings.SocketTimeout = TimeSpan.FromSeconds(5);

                    MongoClient client = new MongoClient(settings);
                    IMongoDatabase admin = client.GetDatabase("admin");
                    BsonDocument ping = admin.RunCommand<BsonDocument>(new BsonDocument("ping", 1));
                    if (ping.TryGetValue("ok", out BsonValue ok) && ok.ToDouble() >= 1.0)
                        return;

                    throw new InvalidOperationException("Mongo ping returned no ok=1.");
                }
                catch (System.Exception ex)
                {
                    last = ex;
                    if (DateTime.UtcNow < deadline)
                        Thread.Sleep(1000);
                }
            }

            throw new InvalidOperationException(
                $"MongoDB did not become ready at {uri} within {timeoutSeconds}s. " +
                $"Last error: {last?.GetType().Name}: {last?.Message}",
                last);
        }
    }
}
