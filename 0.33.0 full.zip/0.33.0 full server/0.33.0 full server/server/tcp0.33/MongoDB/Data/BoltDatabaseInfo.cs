using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TspServer.MongoDB.Data
{
    [Serializable]
    public struct BoltDatabaseInfo : IEquatable<BoltDatabaseInfo>
    {
        public string DatabaseName;
        public BoltDatabaseType DatabaseType;

        public string Address;
        public string Port;

        public string DatabaseAuth;
        public string UserName;
        public string Password;

        public string Uri;

       public string GetUri()
        {
            return !string.IsNullOrWhiteSpace(Uri) ? Uri : $"mongodb://{UserName}:{Password}@{Address}:{Port}/{DatabaseName}?authMechanism={DatabaseAuth}";
        }

        public bool Equals(BoltDatabaseInfo other)
        {
            return DatabaseType == other.DatabaseType &&
                   string.Equals(DatabaseName, other.DatabaseName, StringComparison.Ordinal) &&
                   string.Equals(Address, other.Address, StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(Port, other.Port, StringComparison.Ordinal) &&
                   string.Equals(Uri, other.Uri, StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            return obj is BoltDatabaseInfo other && Equals(other);
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(
               DatabaseType,
                DatabaseName ?? string.Empty,
                Address?.ToLowerInvariant() ?? string.Empty,
                Port ?? string.Empty,
                Uri ?? string.Empty);
       }

    }
    public enum BoltDatabaseType : byte
    {
        Main = 0,
        Game = 1
    }

   public class BoltDatabaseInfoEqualityComparer : IEqualityComparer<BoltDatabaseInfo>
    {
        public bool Equals(BoltDatabaseInfo x, BoltDatabaseInfo y)
        {
            return x.Equals(y);
        }

       public int GetHashCode(BoltDatabaseInfo obj)
         {
            return obj.GetHashCode();
        }
    }

    public class BoltDatabaseTypeEqualityComparer : IEqualityComparer<BoltDatabaseType>
    {
        public bool Equals(BoltDatabaseType x, BoltDatabaseType y)
        {
             return x == y;
        }

         public int GetHashCode(BoltDatabaseType obj)
        {
            return (int)obj;
        }
    }

}
