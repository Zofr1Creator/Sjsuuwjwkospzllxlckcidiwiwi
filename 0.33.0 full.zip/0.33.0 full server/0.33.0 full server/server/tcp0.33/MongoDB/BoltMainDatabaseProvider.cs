using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using TspServer.MongoDB.Data;
using TspServer.MongoDB.Game;
using TspServer.MongoDB.Main;
using TspServer.RpcServer;
using TspServer.RpcServer.Api;

namespace TspServer.MongoDB
{
    public class BoltMainDatabaseProvider : BoltDatabaseProviderBase
    {
        public override BoltDatabaseType DatabaseType => BoltDatabaseType.Main;

       private static string BoltDatabaseName =>
            Environment.GetEnvironmentVariable("MONGO_DATABASE") ?? "Main";

         public static BoltMainDatabaseProvider Instance { get; set; }

        public IMongoDatabase GetDatabase() => _client.GetDatabase(BoltDatabaseName);
        protected override Task FilterDatabaseNames(List<string> databaseNames)
        {
            if (databaseNames == null)
                return base.FilterDatabaseNames(null);

           databaseNames.RemoveAll(s => !string.Equals(s, BoltDatabaseName, StringComparison.Ordinal));
            return base.FilterDatabaseNames(databaseNames);
        }

        protected override Task FilterCollectionNames(string databaseName, List<string> collectionNames)
        {
            if (collectionNames == null)
                 return base.FilterCollectionNames(databaseName, null);

            collectionNames.RemoveAll(s => s.StartsWith("system."));

            return base.FilterCollectionNames(databaseName, collectionNames);
        }

        public GameDocument GetGameInfo()
        {
            return GetGameInfo(null);
        }

        public GameDocument GetGameInfo(string gameVersion)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<GameDocument>("game_settings");

            if (!string.IsNullOrWhiteSpace(gameVersion))
            {
                string normalizedVersion = gameVersion.Trim();
                bool isTarget = normalizedVersion.StartsWith(
                    GameSettingsContract.TargetVersion,
                    StringComparison.OrdinalIgnoreCase);
                string lookupVersion = isTarget
                    ? GameSettingsContract.TargetVersion
                    : normalizedVersion;

                var targetFilter =
                    Builders<GameDocument>.Filter.Eq(x => x.minVersion, lookupVersion) &
                    Builders<GameDocument>.Filter.Eq(x => x.gameUid, GameSettingsContract.TargetGameUid);

                var exactTarget = collection.Find(targetFilter).FirstOrDefault();
                if (exactTarget != null)
                    return exactTarget;

                if (isTarget)
                {
                    throw new InvalidOperationException(
                        $"Game document is missing for client version '{gameVersion}'.");
                }

                var exactVersion = collection
                    .Find(Builders<GameDocument>.Filter.Eq(x => x.minVersion, lookupVersion))
                    .FirstOrDefault();

                if (exactVersion != null)
                    return exactVersion;
             }

            var documents = collection
                .Find(Builders<GameDocument>.Filter.Empty)
                .ToList();

            if (documents.Count == 0)
                throw new InvalidOperationException("The TspServer.game collection is empty.");

            return documents
                 .OrderByDescending(x => x.androidSettings == null ? 0 : x.androidSettings.ElementCount)
                .First();
        }

        public Task<GameDocument> GetGameInfoAsync()
        {
            return Async(GetGameInfo);
        }

        public Task<GameDocument> GetGameInfoAsync(string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(GetGameInfo, processName, processDescription, parentProcessId);
        }

        public void SetGameInfo(GameDocument gameDocument, int originalId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<GameDocument>("game_settings");
            var filter = new FilterDefinitionBuilder<GameDocument>().Eq("_id", originalId);
            var result = collection.ReplaceOne(filter, gameDocument);
        }

        public Task SetGameInfoAsync(GameDocument gameDocument, int originalId)
        {
            return Async(() => SetGameInfo(gameDocument, originalId));
       }

        public Task SetGameInfoAsync(GameDocument gameDocument, int originalId, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => SetGameInfo(gameDocument, originalId), processName, processDescription, parentProcessId);
        }

        public HashDocument GetHashDocument(string version, string gameId)
       {
            const string collectionName = "hashes";


            var database = _client.GetDatabase(BoltDatabaseName);
            var hashesCollection =
                database.GetCollection<HashDocument>(collectionName);

            var allDocuments = hashesCollection
                .Find(Builders<HashDocument>.Filter.Empty)
                .ToList();


            foreach (HashDocument document in allDocuments)
            {
                bool versionEqual =
                    string.Equals(
                       document.version,
                        version,
                        StringComparison.Ordinal
                    );

                 bool gameIdEqual =
                    string.Equals(
                        document.gameId,
                        gameId,
                        StringComparison.Ordinal
                    );


            }

            var filter =
                Builders<HashDocument>.Filter.Eq(
                    x => x.version,
                    version
                 ) &
                Builders<HashDocument>.Filter.Eq(
                   x => x.gameId,
                    gameId
                );
            HashDocument result =
                hashesCollection
                    .Find(filter)
                    .FirstOrDefault();

            if (result == null)
            {

                throw new HashDocumentNotFoundException();
            }


            return result;
        }

        public DevicesInfoDocument GetDeviceInfoDocument(string DeviceId)
        {
            const string collectionName = "devices";

            var database = _client.GetDatabase(BoltDatabaseName);
            var hashesCollection = database.GetCollection<DevicesInfoDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<DevicesInfoDocument>().Eq("DeviceId", DeviceId);
            var tet = hashesCollection.Find(filter);
           if (tet.CountDocuments() == 0)
                throw new DeviceInfoNotFoundException();
             return tet.First();
        }
        public void SetPlayerAvatar(ObjectId objectId, string avatarId)
        {
            const string collectionName = "players";

            var database = _client.GetDatabase(BoltDatabaseName);
           var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("_id", objectId);
            var update = new UpdateDefinitionBuilder<PlayerDocument>().Set("avatarId", avatarId);

            playersCollection.UpdateOne(filter, update);
            Async(() => SocialProfileEventBridge.BroadcastAvatar(objectId.ToString(), avatarId));
        }
       public int GetNextUid100k()
        {
            const string collectionName = "counters";

            var database = _client.GetDatabase(BoltDatabaseName);
            var counters = database.GetCollection<BsonDocument>(collectionName);
            var idFilter = Builders<BsonDocument>.Filter.Eq("_id", "player_uid");

            try
             {
                counters.UpdateOne(
                    idFilter,
                    Builders<BsonDocument>.Update.SetOnInsert("seq", 99999),
                    new UpdateOptions { IsUpsert = true });
           }
            catch (MongoWriteException ex) when (ex.WriteError?.Category == ServerErrorCategory.DuplicateKey)
            {

            }

            var nextOptions = new FindOneAndUpdateOptions<BsonDocument>
            {
                 IsUpsert = false,
                ReturnDocument = ReturnDocument.After
            };

            while (true)
            {
                BsonDocument doc = counters.FindOneAndUpdate(
                    idFilter,
                   Builders<BsonDocument>.Update.Inc("seq", 1),
                    nextOptions);

                if (doc == null)
                    throw new InvalidOperationException("player_uid counter was not created");

                int uid = doc.GetValue("seq", 0).ToInt32();
                if (uid >= 100000)
                    return uid;
                 var repairFilter = Builders<BsonDocument>.Filter.And(
                    idFilter,
                     Builders<BsonDocument>.Filter.Eq("seq", uid));
                counters.UpdateOne(
                    repairFilter,
                    Builders<BsonDocument>.Update.Set("seq", 99999));
            }
        }
        public void AddPlayerTime(ObjectId objectId, int seconds)
        {
            const string collectionName = "players";

            EnsurePlayerTimeSeconds(objectId);

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("_id", objectId);
            var update = new UpdateDefinitionBuilder<PlayerDocument>()
                .Inc("timeInGame", Math.Max(0, seconds))
                .Set("timeInGameUnit", "seconds");
            playersCollection.UpdateOne(filter, update);
        }

        public void EnsurePlayerTimeSeconds(ObjectId objectId)
         {
            const string collectionName = "players";
            var database = _client.GetDatabase(BoltDatabaseName);
            var rawPlayers = database.GetCollection<BsonDocument>(collectionName);

            for (int attempt = 0; attempt < 4; attempt++)
            {
                 BsonDocument doc = rawPlayers.Find(
                        Builders<BsonDocument>.Filter.Eq("_id", objectId))
                    .Project(Builders<BsonDocument>.Projection
                        .Include("timeInGame")
                        .Include("timeInGameUnit"))
                    .FirstOrDefault();

                if (doc == null)
                    return;

                BsonValue unitValue = doc.GetValue("timeInGameUnit", "");
                string unit = unitValue.IsString ? unitValue.AsString : string.Empty;
                if (string.Equals(unit, "seconds", StringComparison.OrdinalIgnoreCase))
                    return;

                int legacyMinutes = 0;
                 BsonValue rawTime = doc.GetValue("timeInGame", 0);
               if (rawTime.IsInt32) legacyMinutes = rawTime.AsInt32;
                else if (rawTime.IsInt64) legacyMinutes = checked((int)rawTime.AsInt64);
                 else if (rawTime.IsDouble) legacyMinutes = checked((int)rawTime.AsDouble);

                int seconds = checked(Math.Max(0, legacyMinutes) * 60);
                var filter = Builders<BsonDocument>.Filter.Eq("_id", objectId) &
                             Builders<BsonDocument>.Filter.Eq("timeInGame", rawTime) &
                             Builders<BsonDocument>.Filter.Ne("timeInGameUnit", "seconds");
                var update = Builders<BsonDocument>.Update
                    .Set("timeInGame", seconds)
                    .Set("timeInGameUnit", "seconds");

                UpdateResult result = rawPlayers.UpdateOne(filter, update);
                if (result.ModifiedCount == 1 || result.MatchedCount == 1)
                {
                    return;
                }
            }
        }
        public void SetPlayerName(ObjectId objectId, string name)
        {
            const string collectionName = "players";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("_id", objectId);
            var update = new UpdateDefinitionBuilder<PlayerDocument>().Set("name", name);

            playersCollection.UpdateOne(filter, update);
            Async(() => SocialProfileEventBridge.BroadcastName(objectId.ToString(), name));
        }

        public void BanPlayer(ObjectId playerId, string banReason, int banCode, long until = 0, string source = "server")
       {
            const string collectionName = "players";
            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            var filter = Builders<PlayerDocument>.Filter.Eq("_id", playerId);
            var update = Builders<PlayerDocument>.Update
                .Set("isBanned", true)
                .Set("banReason", banReason ?? "Anti-cheat violation")
                .Set("banCode", Math.Max(1, banCode))
                .Set("bannedUntil", Math.Max(0, until))
                 .Set("banSource", source ?? "server")
                .Set("banUpdatedAt", DateTime.UtcNow);
            playersCollection.UpdateOne(filter, update);

            try
            {
                 var accountGoogle = GetGoogleAccountByPlayerId(playerId.ToString());
                if (accountGoogle?.deviceInfo != null && accountGoogle.deviceInfo.TryGetValue("deviceId", out BsonValue deviceValue) && deviceValue.IsString)
               {
                    string deviceId = deviceValue.AsString;
                    var devices = database.GetCollection<DevicesInfoDocument>("devices");
                    devices.UpdateOne(
                        Builders<DevicesInfoDocument>.Filter.Eq("DeviceId", deviceId),
                         Builders<DevicesInfoDocument>.Update.Set("isBanned", true));
                }
            }
            catch (System.Exception)
            {
            }
        }

        public void ClearPlayerBan(ObjectId playerId, string source = "admin")
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var players = database.GetCollection<PlayerDocument>("players");
            players.UpdateOne(
                Builders<PlayerDocument>.Filter.Eq(x => x._id, playerId),
               Builders<PlayerDocument>.Update
                    .Set("isBanned", false)
                    .Set("banCode", 0)
                    .Set("banReason", string.Empty)
                    .Set("bannedUntil", 0L)
                    .Set("banSource", source ?? "admin")
                    .Set("banUpdatedAt", DateTime.UtcNow));
        }

        public void ClearExpiredPlayerBan(ObjectId playerId)
        {
            var database = _client.GetDatabase(BoltDatabaseName);
            var players = database.GetCollection<PlayerDocument>("players");
            players.UpdateOne(
                Builders<PlayerDocument>.Filter.Eq(x => x._id, playerId),
               Builders<PlayerDocument>.Update
                    .Set("isBanned", false)
                    .Set("banCode", 0)
                    .Set("banReason", string.Empty)
                    .Set("bannedUntil", 0L)
                    .Set("banSource", "expired")
                    .Set("banUpdatedAt", DateTime.UtcNow));
       }

        public void SetPlayerStatus(ObjectId playerId, PlayerStatus playerStatus)
        {
            PlayerStatus effectiveStatus = playerStatus ?? new PlayerStatus
            {
                onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOnline,
                playInGame = new RpcServer.PlayInGame
               {
                    gameCode = string.Empty,
                    gameVersion = string.Empty,
                    lobbyId = string.Empty,
                    photonGame = null
                }
            };
            lock (ServerState.UsersLock)
            {
                ServerState.PlayersStatus[playerId.ToString()] = effectiveStatus;
            }
           Async(() => SocialProfileEventBridge.BroadcastStatus(playerId.ToString(), effectiveStatus));
        }

        public static void BroadcastClanPlayerAttributesChanged(string playerId, Axlebolt.Bolt.Protobuf2.Attributes attributes)
        {
            if (string.IsNullOrWhiteSpace(playerId)) return;
            var payload = new Axlebolt.Bolt.Protobuf2.OnPlayerAttributesChanged
            {
                PlayerId = playerId,
                Attributes = attributes ?? new Axlebolt.Bolt.Protobuf2.Attributes()
            }.ToByteArray();
            ClanRemoteService.BroadcastPlayerProfileEvent(
                playerId,
                "onPlayerAttributesChanged",
                payload);
        }

        public int GetLastId()
        {
            const string collectionName = "players";
            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            return Convert.ToInt32(playersCollection.Find(new BsonDocument()).Sort(new BsonDocument("_id", -1)).First().uid);
        }
        public PlayerDocument GetPlayerDocument(ObjectId Id)
        {
            const string collectionName = "players";

            EnsurePlayerTimeSeconds(Id);

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("_id", Id);
            return playersCollection.Find(filter).First();
        }
        public static string StripHTML(string input)
        {
            return Regex.Replace(input, "<.*?>", String.Empty);
        }
        public PlayerDocument[] GetPlayersDocumentsByUid(string uid)
        {
            const string collectionName = "players";
            string value = StripHTML(uid);
            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);

           var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("uid", uid);
            return playersCollection.Find(filter).ToList().ToArray();
        }
       public ObjectId CreatePlayer(string playerName, string playerUid)
        {
            const string collectionName = "players";

            var database = _client.GetDatabase(BoltDatabaseName);
           var collection = database.GetCollection<BsonDocument>(collectionName);
             collection.InsertOne(new BsonDocument(new BsonElement[]
            {
                new BsonElement("name", playerName),
                new BsonElement("uid", playerUid),
                new BsonElement("avatarId", ""),
                new BsonElement("timeInGame", 0),
                new BsonElement("timeInGameUnit", "seconds"),
                new BsonElement("noDetectRoot", false),
                new BsonElement("verified", false),
                new BsonElement("isBanned", false),
                new BsonElement("banCode", 0),
                new BsonElement("banReason", ""),
                new BsonElement("updateDate", (BsonDateTime)DateTime.Now),
                new BsonElement("createDate", (BsonDateTime)DateTime.Now)
            } as IEnumerable<BsonElement>));

            var playersCollection = database.GetCollection<PlayerDocument>(collectionName);
           var filter = new FilterDefinitionBuilder<PlayerDocument>().Eq("uid", playerUid);
            var createdPlayer = playersCollection.Find(filter).First();

            var flagsCollection = database.GetCollection<BsonDocument>("player_profile_flags");
            var flagsFilter = Builders<BsonDocument>.Filter.Eq("playerId", createdPlayer._id.ToString());
             var flagsUpdate = Builders<BsonDocument>.Update
                 .SetOnInsert("playerId", createdPlayer._id.ToString())
                .SetOnInsert("verified", false)
                .SetOnInsert("testerRole", string.Empty)
                .SetOnInsert("tags", new BsonArray())
               .SetOnInsert("createDate", DateTime.UtcNow)
                .Set("updateDate", DateTime.UtcNow);
            flagsCollection.UpdateOne(flagsFilter, flagsUpdate, new UpdateOptions { IsUpsert = true });

            return createdPlayer._id;
        }
         public void UpdateAccountDeviceInfo(string googleId, DeviceInfo deviceInfo)
        {
            const string collectionName = "accounts_google";

            var database = _client.GetDatabase(BoltDatabaseName);
            var accountsCollection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("googleId", googleId);
             var update = new UpdateDefinitionBuilder<GoogleAccountDocument>().Set("deviceInfo", deviceInfo.GetBsonElements());

            accountsCollection.UpdateOne(filter, update);
        }
        public void UpdateAccountVerificationInfo(string googleId, Verification verification)
        {
            const string collectionName = "accounts_google";

            var database = _client.GetDatabase(BoltDatabaseName);
            var accountsCollection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("googleId", googleId);
             var update = new UpdateDefinitionBuilder<GoogleAccountDocument>().Set("verification", verification.GetBsonElements());

            accountsCollection.UpdateOne(filter, update);
        }
        public DevicesInfoDocument CreateDeviceInfo(DeviceInfo deviceInfo)
        {
            const string collectionName = "devices";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<DevicesInfoDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<DevicesInfoDocument>().Eq("DeviceId", deviceInfo.DeviceId);
            var hwid = playersCollection.Find(filter);
            if (hwid.CountDocuments() == 0)
            {
                var collection = database.GetCollection<BsonDocument>(collectionName);
               collection.InsertOne(new BsonDocument(new BsonElement[]
                {
                new BsonElement("DeviceId", deviceInfo.DeviceId),
                new BsonElement("DeviceModel", deviceInfo.DeviceModel),
                new BsonElement("isBanned", false)
                } as IEnumerable<BsonElement>));
            }
            var createdHwid = playersCollection.Find(filter).First();
            return createdHwid;
        }

        public Task<ObjectId> CreatePlayerAsync(string playerName, string playerUid)
        {
            return Async(() => CreatePlayer(playerName, playerUid));
        }

        public void SetPlayerForGoogleAccount(ObjectId accountId, string playerId)
        {
            const string collectionName = "accounts_google";

           var database = _client.GetDatabase(BoltDatabaseName);
           var collection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("_id", accountId);
           var update = new UpdateDefinitionBuilder<GoogleAccountDocument>().Set("playerId", playerId);

            collection.UpdateOne(filter, update);
        }
        public GoogleAccountDocument GetGoogleAccountByPlayerId(string playerId)
        {
            const string collectionName = "accounts_google";

            var database = _client.GetDatabase(BoltDatabaseName);
            var accountsCollection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("playerId", playerId);
            var createdAccount = accountsCollection.Find(filter);
            if (createdAccount.CountDocuments() == 0)
                throw new AccountNotFoundException();
            return createdAccount.First();
        }
        public void EnsureGoogleAccountIndexes()
        {
            const string collectionName = "accounts_google";
            var database = _client.GetDatabase(BoltDatabaseName);
            var col = database.GetCollection<GoogleAccountDocument>(collectionName);
            var keys = Builders<GoogleAccountDocument>.IndexKeys.Ascending(x => x.googleId);
            var options = new CreateIndexOptions { Unique = true };
            col.Indexes.CreateOne(new CreateIndexModel<GoogleAccountDocument>(keys, options));
        }

        public GoogleAccountDocument GetGoogleAccount(string googleId)
        {
            const string collectionName = "accounts_google";

            var database = _client.GetDatabase(BoltDatabaseName);
            var accountsCollection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("googleId", googleId);
            var createdAccount = accountsCollection.Find(filter);
            if (createdAccount.CountDocuments() == 0)
                throw new AccountNotFoundException();
            return createdAccount.First();
       }
        public LocalAccountDocument GetLocalAccount(string token)
        {
            const string collectionName = "accounts_test";

           var database = _client.GetDatabase(BoltDatabaseName);
            var accountsCollection = database.GetCollection<LocalAccountDocument>(collectionName);

           var filter = Builders<LocalAccountDocument>.Filter.Eq("token", token);
            var createdAccount = accountsCollection.Find(filter);

            if (createdAccount.CountDocuments() == 0)
                throw new AccountNotFoundException();

            return createdAccount.First();
        }

        public ObjectId CreateGoogleAccount(string googleId, int gameId, Verification verification, DeviceInfo deviceInfo)
        {
            const string collectionName = "accounts_google";

            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(collectionName);
            collection.InsertOne(new BsonDocument(new BsonElement[]
            {
                 new BsonElement("googleId", googleId),
                new BsonElement("gid", gameId),
                new BsonElement("verification", verification.GetBsonElements()),
                new BsonElement("deviceInfo", deviceInfo.GetBsonElements())
            } as IEnumerable<BsonElement>));

            var accountsCollection = database.GetCollection<GoogleAccountDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<GoogleAccountDocument>().Eq("googleId", googleId);
            var createdAccount = accountsCollection.Find(filter).First();
            return createdAccount._id;
        }
        public ObjectId CreateGoogleAccountWithPlayer(string playerName, string playerUid, string token, int gameId, Verification verification, DeviceInfo deviceInfo)
        {
            var playerObjectId = CreatePlayer(playerName, playerUid);
            BoltGameDatabaseProvider.Instance.CreatePlayerStats(playerObjectId.ToString());
            BoltGameDatabaseProvider.Instance.CreatePlayerFiles(playerObjectId.ToString());
            int starterGold = DeviceEconomyGuard.PrepareNewAccountStarterGold(playerObjectId, deviceInfo, "google");
            if (deviceInfo != null && !string.IsNullOrWhiteSpace(deviceInfo.DeviceId)) CreateDeviceInfo(deviceInfo);
            BoltGameDatabaseProvider.Instance.CreatePlayerInventory(playerObjectId, starterGold);
            var accountObjectId = CreateGoogleAccount(token, gameId, verification, deviceInfo ?? new DeviceInfo { DeviceId = string.Empty, DeviceModel = string.Empty });
            SetPlayerForGoogleAccount(accountObjectId, playerObjectId.ToString());
            return playerObjectId;
        }

        public Task<ObjectId> CreateGoogleAccountWithPlayerAsync(string playerName, string playerUid, string token, int gameId, Verification verification, DeviceInfo deviceInfo, string processName, string processDescription = null, int parentProcessId = -1)
        {
            return Async(() => CreateGoogleAccountWithPlayer(playerName, playerUid, token, gameId, verification, deviceInfo), processName, processDescription, parentProcessId);
        }

        public Task<ObjectId> CreateLocalAccountAsync(string token, int gameId)
        {
            return Async(() => CreateLocalAccount(token, gameId));
        }
       public LocalAccountDocument GetLocalAccountByUsername(string usernameLower)
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            var col = database.GetCollection<LocalAccountDocument>(collectionName);

            var u = (usernameLower ?? "").Trim().ToLowerInvariant();
            if (u.Length == 0) return null;

            return col.Find(Builders<LocalAccountDocument>.Filter.Eq(x => x.username, u))
                      .FirstOrDefault();
        }

        public void EnsureLocalAccountIndexes()
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            var col = database.GetCollection<LocalAccountDocument>(collectionName);

            var keys = Builders<LocalAccountDocument>.IndexKeys.Ascending(x => x.username);
            var opt = new CreateIndexOptions { Unique = true, Sparse = true };
            col.Indexes.CreateOne(new CreateIndexModel<LocalAccountDocument>(keys, opt));
        }

         public void UpdateAccountTokenByUsername(string usernameLower, string newToken)
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            var col = database.GetCollection<LocalAccountDocument>(collectionName);

            var filter = Builders<LocalAccountDocument>.Filter.Eq(x => x.username, usernameLower);
             var update = Builders<LocalAccountDocument>.Update.Set(x => x.token, newToken);

             col.UpdateOne(filter, update);
        }

        public void SetUsernamePasswordForToken(string token, string usernameLower, string saltB64, string hashB64)
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            var col = database.GetCollection<LocalAccountDocument>(collectionName);

            var filter = Builders<LocalAccountDocument>.Filter.Eq(x => x.token, token);
            var update = Builders<LocalAccountDocument>.Update
                .Set(x => x.username, usernameLower)
                .Set(x => x.passSalt, saltB64)
                .Set(x => x.passHash, hashB64);

            col.UpdateOne(filter, update);
         }

        public void SetPlayerForLocalAccount(ObjectId accountId, string playerId)
        {
            const string collectionName = "accounts_test";

            var database = _client.GetDatabase(BoltDatabaseName);
           var collection = database.GetCollection<BsonDocument>(collectionName);

            var filter = Builders<BsonDocument>.Filter.Eq("_id", accountId);
            var update = Builders<BsonDocument>.Update.Set("playerId", playerId);

            collection.UpdateOne(filter, update);
         }

        public Task SetPlayerForLocalAccountAsync(ObjectId accountId, string playerId)
        {
            return Async(() => SetPlayerForLocalAccount(accountId, playerId));
        }

        public ObjectId CreateLocalAccountWithPlayer(string playerName, string playerUid, string token, int gameId, DeviceInfo deviceInfo = null, string authProvider = "local")
        {

            var playerObjectId = CreatePlayer(playerName, playerUid);

           BoltGameDatabaseProvider.Instance.CreatePlayerStats(playerObjectId.ToString());
            BoltGameDatabaseProvider.Instance.CreatePlayerFiles(playerObjectId.ToString());
            int starterGold = deviceInfo == null
                 ? 500
                : DeviceEconomyGuard.PrepareNewAccountStarterGold(playerObjectId, deviceInfo, authProvider);
             BoltGameDatabaseProvider.Instance.CreatePlayerInventory(playerObjectId, starterGold);
            CreatePlayerGameEvent(playerObjectId.ToString());

             var accountObjectId = CreateLocalAccount(token, gameId);
            UpdateLocalAccountTokenAndPlayerId(accountObjectId, token, playerObjectId.ToString());

           return accountObjectId;
        }

        public IMongoCollection<LocalAccountDocument> GetLocalAccountCollection()
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            return database.GetCollection<LocalAccountDocument>(collectionName);
        }

         private void UpdateLocalAccountTokenAndPlayerId(ObjectId accountObjectId, string token, string playerId)
         {
            var collection = BoltMainDatabaseProvider.Instance.GetLocalAccountCollection();

            var filter = Builders<LocalAccountDocument>.Filter.Eq(x => x._id, accountObjectId);

            var update = Builders<LocalAccountDocument>.Update
                 .Set(x => x.token, token)
                .Set(x => x.playerId, playerId);

            collection.UpdateOne(filter, update);
        }

        public ObjectId CreateLocalAccount(string token, int gameId)
        {
            const string collectionName = "accounts_test";
            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(collectionName);

            var id = ObjectId.GenerateNewId();

            var doc = new BsonDocument
    {
        { "_id", id },
        { "token", token },
        { "gid", gameId },
        { "playerId", "" }
    };

            collection.InsertOne(doc);
            return id;
        }

        public Task<ObjectId> CreateLocalAccountWithPlayerAsync(string playerName, string playerUid, string token, int gameId, string processName, string processDescription = null, int parentProcessId = -1)
        {
             return Async(() => CreateLocalAccountWithPlayer(playerName, playerUid, token, gameId), processName, processDescription, parentProcessId);
        }

        public ObjectId CreatePlayerGameEvent(string playerId)
        {
            const string collectionName = "player_events";

            var database = _client.GetDatabase(BoltDatabaseName);
            var collection = database.GetCollection<BsonDocument>(collectionName);
            collection.InsertOne(new BsonDocument(new BsonElement[]
            {
                new BsonElement("playerId", playerId),
                new BsonElement("currentLevel", 1),
                new BsonElement("points", 0)
            } as IEnumerable<BsonElement>));

            var playersCollection = database.GetCollection<BoltPlayerGameEventDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<BoltPlayerGameEventDocument>().Eq("playerId", playerId);
            var createdPlayer = playersCollection.Find(filter).First();
            return createdPlayer._id;
        }

        public BoltPlayerGameEventDocument GetGameEvent(ObjectId id)
        {
            const string collectionName = "player_events";

            var database = _client.GetDatabase(BoltDatabaseName);
            var playersCollection = database.GetCollection<BoltPlayerGameEventDocument>(collectionName);
            var filter = new FilterDefinitionBuilder<BoltPlayerGameEventDocument>().Eq("playerId", id.ToString());
            return playersCollection.Find(filter).First();
        }

    }
    public class DeviceInfoNotFoundException : Exception
   {
    }
   public class AccountNotFoundException : Exception
    {
    }
    public class HashDocumentNotFoundException : Exception
    {
    }
}
