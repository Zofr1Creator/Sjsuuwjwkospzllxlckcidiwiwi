#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class PlayerMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static PlayerMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChNQbGF5ZXJNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3RvYnVm",
            "MhoTQ29tbW9uTWVzc2FnZS5wcm90byJ9CgpQbGF5SW5HYW1lEhAKCGdhbWVD",
            "b2RlGAEgASgJEhMKC2dhbWVWZXJzaW9uGAIgASgJEg8KB2xvYmJ5SWQYAyAB",
            "KAkSNwoKcGhvdG9uR2FtZRgEIAEoCzIjLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLlBob3RvbkdhbWUilgEKDFBsYXllclN0YXR1cxIQCghwbGF5ZXJJZBgB",
            "IAEoCRI3CgpwbGF5SW5HYW1lGAIgASgLMiMuQXhsZWJvbHQuQm9sdC5Qcm90",
            "b2J1ZjIuUGxheUluR2FtZRI7CgxvbmxpbmVTdGF0dXMYAyABKA4yJS5BeGxl",
            "Ym9sdC5Cb2x0LlByb3RvYnVmMi5PbmxpbmVTdGF0dXMiwAEKBlBsYXllchIK",
            "CgJpZBgBIAEoCRILCgN1aWQYAiABKAkSDAoEbmFtZRgDIAEoCRIQCghhdmF0",
            "YXJJZBgEIAEoCRISCgp0aW1lSW5HYW1lGAUgASgFEjsKDHBsYXllclN0YXR1",
            "cxgGIAEoCzIlLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBsYXllclN0YXR1",
            "cxISCgpsb2dvdXREYXRlGAcgASgDEhgKEHJlZ2lzdHJhdGlvbkRhdGUYCCAB",
            "KAMqGgoIQXV0aFR5cGUSDgoKR29vZ2xlUGxheRAAKpEBCgxPbmxpbmVTdGF0",
            "dXMSEAoMU3RhdGVPZmZsaW5lEAASDwoLU3RhdGVPbmxpbmUQARINCglTdGF0",
            "ZUJ1c3kQAhINCglTdGF0ZUF3YXkQAxIPCgtTdGF0ZVNub296ZRAEEhcKE1N0",
            "YXRlTG9va2luZ1RvVHJhZGUQBRIWChJTdGF0ZUxvb2tpbmdUb1BsYXkQBmIG",
            "cHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CommonMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.AuthType), typeof(global::Axlebolt.Bolt.Protobuf2.OnlineStatus), }, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayInGame), global::Axlebolt.Bolt.Protobuf2.PlayInGame.Parser, new[]{ "GameCode", "GameVersion", "LobbyId", "PhotonGame" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayerStatus), global::Axlebolt.Bolt.Protobuf2.PlayerStatus.Parser, new[]{ "PlayerId", "PlayInGame", "OnlineStatus" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Player), global::Axlebolt.Bolt.Protobuf2.Player.Parser, new[]{ "Id", "Uid", "Name", "AvatarId", "TimeInGame", "PlayerStatus", "LogoutDate", "RegistrationDate" }, null, null, null)
          }));
    }

  }
  public enum AuthType {
    [pbr::OriginalName("GooglePlay")] GooglePlay = 0,
  }

  public enum OnlineStatus {
    [pbr::OriginalName("StateOffline")] StateOffline = 0,
    [pbr::OriginalName("StateOnline")] StateOnline = 1,
    [pbr::OriginalName("StateBusy")] StateBusy = 2,
    [pbr::OriginalName("StateAway")] StateAway = 3,
    [pbr::OriginalName("StateSnooze")] StateSnooze = 4,
    [pbr::OriginalName("StateLookingToTrade")] StateLookingToTrade = 5,
    [pbr::OriginalName("StateLookingToPlay")] StateLookingToPlay = 6,
  }


  public sealed partial class PlayInGame : pb::IMessage<PlayInGame> {
    private static readonly pb::MessageParser<PlayInGame> _parser = new pb::MessageParser<PlayInGame>(() => new PlayInGame());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayInGame> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayInGame() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayInGame(PlayInGame other) : this() {
      gameCode_ = other.gameCode_;
      gameVersion_ = other.gameVersion_;
      lobbyId_ = other.lobbyId_;
      PhotonGame = other.photonGame_ != null ? other.PhotonGame.Clone() : null;
      lobbyName_ = other.lobbyName_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayInGame Clone() {
      return new PlayInGame(this);
    }

    public const int GameCodeFieldNumber = 1;
    private string gameCode_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameCode {
      get { return gameCode_; }
      set {
        gameCode_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int GameVersionFieldNumber = 2;
    private string gameVersion_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameVersion {
      get { return gameVersion_; }
      set {
        gameVersion_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LobbyIdFieldNumber = 3;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PhotonGameFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    public const int LobbyNameFieldNumber = 5;
    private string lobbyName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyName {
      get { return lobbyName_; }
      set { lobbyName_ = pb::ProtoPreconditions.CheckNotNull(value, "value"); }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayInGame);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayInGame other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameCode != other.GameCode) return false;
      if (GameVersion != other.GameVersion) return false;
      if (LobbyId != other.LobbyId) return false;
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      if (LobbyName != other.LobbyName) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameCode.Length != 0) hash ^= GameCode.GetHashCode();
      if (GameVersion.Length != 0) hash ^= GameVersion.GetHashCode();
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (LobbyName.Length != 0) hash ^= LobbyName.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (GameCode.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameCode);
      }
      if (GameVersion.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(GameVersion);
      }
      if (LobbyId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(LobbyId);
      }
      if (photonGame_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(PhotonGame);
      }
      if (LobbyName.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(LobbyName);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameCode.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameCode);
      }
      if (GameVersion.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameVersion);
      }
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (LobbyName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyName);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayInGame other) {
      if (other == null) {
        return;
      }
      if (other.GameCode.Length != 0) {
        GameCode = other.GameCode;
      }
      if (other.GameVersion.Length != 0) {
        GameVersion = other.GameVersion;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          photonGame_ = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      if (other.LobbyName.Length != 0) {
        LobbyName = other.LobbyName;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            GameCode = input.ReadString();
            break;
          }
          case 18: {
            GameVersion = input.ReadString();
            break;
          }
          case 26: {
            LobbyId = input.ReadString();
            break;
          }
          case 34: {
            if (photonGame_ == null) {
              photonGame_ = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(photonGame_);
            break;
          }
          case 42: {
            LobbyName = input.ReadString();
            break;
          }
        }
      }
    }

  }

  public sealed partial class PlayerStatus : pb::IMessage<PlayerStatus> {
    private static readonly pb::MessageParser<PlayerStatus> _parser = new pb::MessageParser<PlayerStatus>(() => new PlayerStatus());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayerStatus> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStatus() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStatus(PlayerStatus other) : this() {
      playerId_ = other.playerId_;
      PlayInGame = other.playInGame_ != null ? other.PlayInGame.Clone() : null;
      onlineStatus_ = other.onlineStatus_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStatus Clone() {
      return new PlayerStatus(this);
    }

    public const int PlayerIdFieldNumber = 1;
    private string playerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string PlayerId {
      get { return playerId_; }
      set {
        playerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayInGameFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PlayInGame playInGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayInGame PlayInGame {
      get { return playInGame_; }
      set {
        playInGame_ = value;
      }
    }

    public const int OnlineStatusFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.OnlineStatus onlineStatus_ = 0;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.OnlineStatus OnlineStatus {
      get { return onlineStatus_; }
      set {
        onlineStatus_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayerStatus);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayerStatus other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (PlayerId != other.PlayerId) return false;
      if (!object.Equals(PlayInGame, other.PlayInGame)) return false;
      if (OnlineStatus != other.OnlineStatus) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (PlayerId.Length != 0) hash ^= PlayerId.GetHashCode();
      if (playInGame_ != null) hash ^= PlayInGame.GetHashCode();
      if (OnlineStatus != 0) hash ^= OnlineStatus.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (PlayerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      if (playInGame_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(PlayInGame);
      }
      if (OnlineStatus != 0) {
        output.WriteRawTag(24);
        output.WriteEnum((int) OnlineStatus);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (PlayerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PlayerId);
      }
      if (playInGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PlayInGame);
      }
      if (OnlineStatus != 0) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) OnlineStatus);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayerStatus other) {
      if (other == null) {
        return;
      }
      if (other.PlayerId.Length != 0) {
        PlayerId = other.PlayerId;
      }
      if (other.playInGame_ != null) {
        if (playInGame_ == null) {
          playInGame_ = new global::Axlebolt.Bolt.Protobuf2.PlayInGame();
        }
        PlayInGame.MergeFrom(other.PlayInGame);
      }
      if (other.OnlineStatus != 0) {
        OnlineStatus = other.OnlineStatus;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            PlayerId = input.ReadString();
            break;
          }
          case 18: {
            if (playInGame_ == null) {
              playInGame_ = new global::Axlebolt.Bolt.Protobuf2.PlayInGame();
            }
            input.ReadMessage(playInGame_);
            break;
          }
          case 24: {
            onlineStatus_ = (global::Axlebolt.Bolt.Protobuf2.OnlineStatus) input.ReadEnum();
            break;
          }
        }
      }
    }

  }

  public sealed partial class Player : pb::IMessage<Player> {
    private static readonly pb::MessageParser<Player> _parser = new pb::MessageParser<Player>(() => new Player());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Player> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Player() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Player(Player other) : this() {
      id_ = other.id_;
      uid_ = other.uid_;
      name_ = other.name_;
      avatarId_ = other.avatarId_;
      timeInGame_ = other.timeInGame_;
      PlayerStatus = other.playerStatus_ != null ? other.PlayerStatus.Clone() : null;
      logoutDate_ = other.logoutDate_;
      registrationDate_ = other.registrationDate_;
      Attributes = other.attributes_ != null ? other.Attributes.Clone() : null;
      tags_ = other.tags_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Player Clone() {
      return new Player(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int UidFieldNumber = 2;
    private string uid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Uid {
      get { return uid_; }
      set {
        uid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NameFieldNumber = 3;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AvatarIdFieldNumber = 4;
    private string avatarId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string AvatarId {
      get { return avatarId_; }
      set {
        avatarId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TimeInGameFieldNumber = 5;
    private int timeInGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int TimeInGame {
      get { return timeInGame_; }
      set {
        timeInGame_ = value;
      }
    }

    public const int PlayerStatusFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.PlayerStatus playerStatus_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerStatus PlayerStatus {
      get { return playerStatus_; }
      set {
        playerStatus_ = value;
      }
    }

    public const int LogoutDateFieldNumber = 7;
    private long logoutDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long LogoutDate {
      get { return logoutDate_; }
      set {
        logoutDate_ = value;
      }
    }

    public const int RegistrationDateFieldNumber = 8;
    private long registrationDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long RegistrationDate {
      get { return registrationDate_; }
      set {
        registrationDate_ = value;
      }
    }

    public const int AttributesFieldNumber = 9;
    private global::Axlebolt.Bolt.Protobuf2.Attributes attributes_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Attributes Attributes {
      get { return attributes_; }
      set { attributes_ = value; }
    }

    public const int TagsFieldNumber = 13;
    private static readonly pb::FieldCodec<int> _repeated_tags_codec = pb::FieldCodec.ForInt32(106);
    private readonly pbc::RepeatedField<int> tags_ = new pbc::RepeatedField<int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<int> Tags { get { return tags_; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Player);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Player other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Uid != other.Uid) return false;
      if (Name != other.Name) return false;
      if (AvatarId != other.AvatarId) return false;
      if (TimeInGame != other.TimeInGame) return false;
      if (!object.Equals(PlayerStatus, other.PlayerStatus)) return false;
      if (LogoutDate != other.LogoutDate) return false;
      if (RegistrationDate != other.RegistrationDate) return false;
      if (!object.Equals(Attributes, other.Attributes)) return false;
      if (!tags_.Equals(other.tags_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Uid.Length != 0) hash ^= Uid.GetHashCode();
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (AvatarId.Length != 0) hash ^= AvatarId.GetHashCode();
      if (TimeInGame != 0) hash ^= TimeInGame.GetHashCode();
      if (playerStatus_ != null) hash ^= PlayerStatus.GetHashCode();
      if (LogoutDate != 0L) hash ^= LogoutDate.GetHashCode();
      if (RegistrationDate != 0L) hash ^= RegistrationDate.GetHashCode();
      if (attributes_ != null) hash ^= Attributes.GetHashCode();
      hash ^= tags_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Uid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Uid);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Name);
      }
      if (AvatarId.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(AvatarId);
      }
      if (TimeInGame != 0) {
        output.WriteRawTag(40);
        output.WriteInt32(TimeInGame);
      }
      if (playerStatus_ != null) {
        output.WriteRawTag(50);
        output.WriteMessage(PlayerStatus);
      }
      if (LogoutDate != 0L) {
        output.WriteRawTag(56);
        output.WriteInt64(LogoutDate);
      }
      if (RegistrationDate != 0L) {
        output.WriteRawTag(64);
        output.WriteInt64(RegistrationDate);
      }
      if (attributes_ != null) {
        output.WriteRawTag(74);
        output.WriteMessage(Attributes);
      }
      tags_.WriteTo(output, _repeated_tags_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Uid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Uid);
      }
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (AvatarId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AvatarId);
      }
      if (TimeInGame != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(TimeInGame);
      }
      if (playerStatus_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PlayerStatus);
      }
      if (LogoutDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(LogoutDate);
      }
      if (RegistrationDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(RegistrationDate);
      }
      if (attributes_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Attributes);
      }
      size += tags_.CalculateSize(_repeated_tags_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Player other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Uid.Length != 0) {
        Uid = other.Uid;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.AvatarId.Length != 0) {
        AvatarId = other.AvatarId;
      }
      if (other.TimeInGame != 0) {
        TimeInGame = other.TimeInGame;
      }
      if (other.playerStatus_ != null) {
        if (playerStatus_ == null) {
          playerStatus_ = new global::Axlebolt.Bolt.Protobuf2.PlayerStatus();
        }
        PlayerStatus.MergeFrom(other.PlayerStatus);
      }
      if (other.LogoutDate != 0L) {
        LogoutDate = other.LogoutDate;
      }
      if (other.RegistrationDate != 0L) {
        RegistrationDate = other.RegistrationDate;
      }
      if (other.attributes_ != null) {
        if (attributes_ == null) attributes_ = new global::Axlebolt.Bolt.Protobuf2.Attributes();
        Attributes.MergeFrom(other.Attributes);
      }
      tags_.Add(other.tags_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Uid = input.ReadString();
            break;
          }
          case 26: {
            Name = input.ReadString();
            break;
          }
          case 34: {
            AvatarId = input.ReadString();
            break;
          }
          case 40: {
            TimeInGame = input.ReadInt32();
            break;
          }
          case 50: {
            if (playerStatus_ == null) {
              playerStatus_ = new global::Axlebolt.Bolt.Protobuf2.PlayerStatus();
            }
            input.ReadMessage(playerStatus_);
            break;
          }
          case 56: {
            LogoutDate = input.ReadInt64();
            break;
          }
          case 64: {
            RegistrationDate = input.ReadInt64();
            break;
          }
          case 74: {
            if (attributes_ == null) attributes_ = new global::Axlebolt.Bolt.Protobuf2.Attributes();
            input.ReadMessage(attributes_);
            break;
          }
          case 104: {
            tags_.Add(input.ReadInt32());
            break;
          }
          case 106: {
            tags_.AddEntriesFrom(input, _repeated_tags_codec);
            break;
          }
        }
      }
    }

  }


}

