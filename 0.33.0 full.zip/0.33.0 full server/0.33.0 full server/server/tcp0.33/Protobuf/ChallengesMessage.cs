#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class ChallengesMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static ChallengesMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChdDaGFsbGVuZ2VzTWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90",
            "b2J1ZjIaE0NvbW1vbk1lc3NhZ2UucHJvdG8aFUN1cnJlbmN5TWVzc2FnZS5w",
            "cm90bxoWSW52ZW50b3J5TWVzc2FnZS5wcm90byLmAgoQQ3VycmVudENoYWxs",
            "ZW5nZRIcChRnYW1lRXZlbnRDaGFsbGVuZ2VJZBgBIAEoCRIMCgRjb2RlGAIg",
            "ASgJEhsKE2tleUl0ZW1EZWZpbml0aW9uSWQYAyABKAUSPwoObG9jYWxpemVk",
            "VGl0bGUYBCABKAsyJy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Mb2NhbGl6",
            "ZWRUaXRsZRIOCgZhY3Rpb24YBSABKAkSMwoIZGF5UmFuZ2UYBiABKAsyIS5B",
            "eGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5EYXlSYW5nZRIMCgR0eXBlGAcgASgJ",
            "EhMKC2V2ZW50UG9pbnRzGAggASgFEhQKDHRhcmdldFBvaW50cxgJIAEoBRIV",
            "Cg1jdXJyZW50UG9pbnRzGAogASgFEjMKBnJld2FyZBgLIAEoCzIjLkF4bGVi",
            "b2x0LkJvbHQuUHJvdG9idWYyLlJld2FyZEluZm8iRQobR2V0Q3VycmVudENo",
            "YWxsZW5nZXNSZXF1ZXN0EhMKC2dhbWVFdmVudElkGAEgASgJEhEKCWNvbXBs",
            "ZXRlZBgCIAEoCCJdChxHZXRDdXJyZW50Q2hhbGxlbmdlc1Jlc3BvbnNlEj0K",
            "CmNoYWxsZW5nZXMYASADKAsyKS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5D",
            "dXJyZW50Q2hhbGxlbmdlIkgKGFByb2dyZXNzQ2hhbGxlbmdlUmVxdWVzdBIc",
            "ChRnYW1lRXZlbnRDaGFsbGVuZ2VJZBgBIAEoCRIOCgZwb2ludHMYAiABKAUi",
            "8gIKGVByb2dyZXNzQ2hhbGxlbmdlUmVzcG9uc2USEQoJY29tcGxldGVkGAEg",
            "ASgIEhcKD2NoYWxsZW5nZVBvaW50cxgCIAEoBRI4Cg9jaGFsbGVuZ2VSZXdh",
            "cmQYAyABKAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5SZXdhcmQSEwoL",
            "RXZlbnRQb2ludHMYBCABKAUSaAoTZXZlbnRHYW1lUGFzc0xldmVscxgFIAMo",
            "CzJLLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlByb2dyZXNzQ2hhbGxlbmdl",
            "UmVzcG9uc2UuRXZlbnRHYW1lUGFzc0xldmVsc0VudHJ5EjQKC0V2ZW50UmV3",
            "YXJkGAYgASgLMh8uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUmV3YXJkGjoK",
            "GEV2ZW50R2FtZVBhc3NMZXZlbHNFbnRyeRILCgNrZXkYASABKAkSDQoFdmFs",
            "dWUYAiABKAU6AjgBYgZwcm90bzM="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CommonMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CurrentChallenge), global::Axlebolt.Bolt.Protobuf2.CurrentChallenge.Parser, new[]{ "GameEventChallengeId", "Code", "KeyItemDefinitionId", "LocalizedTitle", "Action", "DayRange", "Type", "EventPoints", "TargetPoints", "CurrentPoints", "Reward" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetCurrentChallengesRequest), global::Axlebolt.Bolt.Protobuf2.GetCurrentChallengesRequest.Parser, new[]{ "GameEventId", "Completed" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetCurrentChallengesResponse), global::Axlebolt.Bolt.Protobuf2.GetCurrentChallengesResponse.Parser, new[]{ "Challenges" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ProgressChallengeRequest), global::Axlebolt.Bolt.Protobuf2.ProgressChallengeRequest.Parser, new[]{ "GameEventChallengeId", "Points" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ProgressChallengeResponse), global::Axlebolt.Bolt.Protobuf2.ProgressChallengeResponse.Parser, new[]{ "Completed", "ChallengePoints", "ChallengeReward", "EventPoints", "EventGamePassLevels", "EventReward" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, })
          }));
    }

  }
  public sealed partial class CurrentChallenge : pb::IMessage<CurrentChallenge> {
    private static readonly pb::MessageParser<CurrentChallenge> _parser = new pb::MessageParser<CurrentChallenge>(() => new CurrentChallenge());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<CurrentChallenge> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChallengesMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentChallenge() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentChallenge(CurrentChallenge other) : this() {
      gameEventChallengeId_ = other.gameEventChallengeId_;
      code_ = other.code_;
      keyItemDefinitionId_ = other.keyItemDefinitionId_;
      LocalizedTitle = other.localizedTitle_ != null ? other.LocalizedTitle.Clone() : null;
      action_ = other.action_;
      DayRange = other.dayRange_ != null ? other.DayRange.Clone() : null;
      type_ = other.type_;
      eventPoints_ = other.eventPoints_;
      targetPoints_ = other.targetPoints_;
      currentPoints_ = other.currentPoints_;
      Reward = other.reward_ != null ? other.Reward.Clone() : null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentChallenge Clone() {
      return new CurrentChallenge(this);
    }

    public const int GameEventChallengeIdFieldNumber = 1;
    private string gameEventChallengeId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameEventChallengeId {
      get { return gameEventChallengeId_; }
      set {
        gameEventChallengeId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CodeFieldNumber = 2;
    private string code_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Code {
      get { return code_; }
      set {
        code_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int KeyItemDefinitionIdFieldNumber = 3;
    private int keyItemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int KeyItemDefinitionId {
      get { return keyItemDefinitionId_; }
      set {
        keyItemDefinitionId_ = value;
      }
    }

    public const int LocalizedTitleFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.LocalizedTitle localizedTitle_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LocalizedTitle LocalizedTitle {
      get { return localizedTitle_; }
      set {
        localizedTitle_ = value;
      }
    }

    public const int ActionFieldNumber = 5;
    private string action_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Action {
      get { return action_; }
      set {
        action_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int DayRangeFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.DayRange dayRange_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.DayRange DayRange {
      get { return dayRange_; }
      set {
        dayRange_ = value;
      }
    }

    public const int TypeFieldNumber = 7;
    private string type_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Type {
      get { return type_; }
      set {
        type_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int EventPointsFieldNumber = 8;
    private int eventPoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int EventPoints {
      get { return eventPoints_; }
      set {
        eventPoints_ = value;
      }
    }

    public const int TargetPointsFieldNumber = 9;
    private int targetPoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int TargetPoints {
      get { return targetPoints_; }
      set {
        targetPoints_ = value;
      }
    }

    public const int CurrentPointsFieldNumber = 10;
    private int currentPoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CurrentPoints {
      get { return currentPoints_; }
      set {
        currentPoints_ = value;
      }
    }

    public const int RewardFieldNumber = 11;
    private global::Axlebolt.Bolt.Protobuf2.RewardInfo reward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.RewardInfo Reward {
      get { return reward_; }
      set {
        reward_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as CurrentChallenge);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(CurrentChallenge other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameEventChallengeId != other.GameEventChallengeId) return false;
      if (Code != other.Code) return false;
      if (KeyItemDefinitionId != other.KeyItemDefinitionId) return false;
      if (!object.Equals(LocalizedTitle, other.LocalizedTitle)) return false;
      if (Action != other.Action) return false;
      if (!object.Equals(DayRange, other.DayRange)) return false;
      if (Type != other.Type) return false;
      if (EventPoints != other.EventPoints) return false;
      if (TargetPoints != other.TargetPoints) return false;
      if (CurrentPoints != other.CurrentPoints) return false;
      if (!object.Equals(Reward, other.Reward)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameEventChallengeId.Length != 0) hash ^= GameEventChallengeId.GetHashCode();
      if (Code.Length != 0) hash ^= Code.GetHashCode();
      if (KeyItemDefinitionId != 0) hash ^= KeyItemDefinitionId.GetHashCode();
      if (localizedTitle_ != null) hash ^= LocalizedTitle.GetHashCode();
      if (Action.Length != 0) hash ^= Action.GetHashCode();
      if (dayRange_ != null) hash ^= DayRange.GetHashCode();
      if (Type.Length != 0) hash ^= Type.GetHashCode();
      if (EventPoints != 0) hash ^= EventPoints.GetHashCode();
      if (TargetPoints != 0) hash ^= TargetPoints.GetHashCode();
      if (CurrentPoints != 0) hash ^= CurrentPoints.GetHashCode();
      if (reward_ != null) hash ^= Reward.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (GameEventChallengeId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameEventChallengeId);
      }
      if (Code.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Code);
      }
      if (KeyItemDefinitionId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(KeyItemDefinitionId);
      }
      if (localizedTitle_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(LocalizedTitle);
      }
      if (Action.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(Action);
      }
      if (dayRange_ != null) {
        output.WriteRawTag(50);
        output.WriteMessage(DayRange);
      }
      if (Type.Length != 0) {
        output.WriteRawTag(58);
        output.WriteString(Type);
      }
      if (EventPoints != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(EventPoints);
      }
      if (TargetPoints != 0) {
        output.WriteRawTag(72);
        output.WriteInt32(TargetPoints);
      }
      if (CurrentPoints != 0) {
        output.WriteRawTag(80);
        output.WriteInt32(CurrentPoints);
      }
      if (reward_ != null) {
        output.WriteRawTag(90);
        output.WriteMessage(Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameEventChallengeId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameEventChallengeId);
      }
      if (Code.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Code);
      }
      if (KeyItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(KeyItemDefinitionId);
      }
      if (localizedTitle_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(LocalizedTitle);
      }
      if (Action.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Action);
      }
      if (dayRange_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(DayRange);
      }
      if (Type.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Type);
      }
      if (EventPoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(EventPoints);
      }
      if (TargetPoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(TargetPoints);
      }
      if (CurrentPoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrentPoints);
      }
      if (reward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Reward);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(CurrentChallenge other) {
      if (other == null) {
        return;
      }
      if (other.GameEventChallengeId.Length != 0) {
        GameEventChallengeId = other.GameEventChallengeId;
      }
      if (other.Code.Length != 0) {
        Code = other.Code;
      }
      if (other.KeyItemDefinitionId != 0) {
        KeyItemDefinitionId = other.KeyItemDefinitionId;
      }
      if (other.localizedTitle_ != null) {
        if (localizedTitle_ == null) {
          localizedTitle_ = new global::Axlebolt.Bolt.Protobuf2.LocalizedTitle();
        }
        LocalizedTitle.MergeFrom(other.LocalizedTitle);
      }
      if (other.Action.Length != 0) {
        Action = other.Action;
      }
      if (other.dayRange_ != null) {
        if (dayRange_ == null) {
          dayRange_ = new global::Axlebolt.Bolt.Protobuf2.DayRange();
        }
        DayRange.MergeFrom(other.DayRange);
      }
      if (other.Type.Length != 0) {
        Type = other.Type;
      }
      if (other.EventPoints != 0) {
        EventPoints = other.EventPoints;
      }
      if (other.TargetPoints != 0) {
        TargetPoints = other.TargetPoints;
      }
      if (other.CurrentPoints != 0) {
        CurrentPoints = other.CurrentPoints;
      }
      if (other.reward_ != null) {
        if (reward_ == null) {
          reward_ = new global::Axlebolt.Bolt.Protobuf2.RewardInfo();
        }
        Reward.MergeFrom(other.Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            GameEventChallengeId = input.ReadString();
            break;
          }
          case 18: {
            Code = input.ReadString();
            break;
          }
          case 24: {
            KeyItemDefinitionId = input.ReadInt32();
            break;
          }
          case 34: {
            if (localizedTitle_ == null) {
              localizedTitle_ = new global::Axlebolt.Bolt.Protobuf2.LocalizedTitle();
            }
            input.ReadMessage(localizedTitle_);
            break;
          }
          case 42: {
            Action = input.ReadString();
            break;
          }
          case 50: {
            if (dayRange_ == null) {
              dayRange_ = new global::Axlebolt.Bolt.Protobuf2.DayRange();
            }
            input.ReadMessage(dayRange_);
            break;
          }
          case 58: {
            Type = input.ReadString();
            break;
          }
          case 64: {
            EventPoints = input.ReadInt32();
            break;
          }
          case 72: {
            TargetPoints = input.ReadInt32();
            break;
          }
          case 80: {
            CurrentPoints = input.ReadInt32();
            break;
          }
          case 90: {
            if (reward_ == null) {
              reward_ = new global::Axlebolt.Bolt.Protobuf2.RewardInfo();
            }
            input.ReadMessage(reward_);
            break;
          }
        }
      }
    }

  }

  public sealed partial class GetCurrentChallengesRequest : pb::IMessage<GetCurrentChallengesRequest> {
    private static readonly pb::MessageParser<GetCurrentChallengesRequest> _parser = new pb::MessageParser<GetCurrentChallengesRequest>(() => new GetCurrentChallengesRequest());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetCurrentChallengesRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChallengesMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesRequest(GetCurrentChallengesRequest other) : this() {
      gameEventId_ = other.gameEventId_;
      completed_ = other.completed_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesRequest Clone() {
      return new GetCurrentChallengesRequest(this);
    }

    public const int GameEventIdFieldNumber = 1;
    private string gameEventId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameEventId {
      get { return gameEventId_; }
      set {
        gameEventId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CompletedFieldNumber = 2;
    private bool completed_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Completed {
      get { return completed_; }
      set {
        completed_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetCurrentChallengesRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetCurrentChallengesRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameEventId != other.GameEventId) return false;
      if (Completed != other.Completed) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameEventId.Length != 0) hash ^= GameEventId.GetHashCode();
      if (Completed != false) hash ^= Completed.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (GameEventId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameEventId);
      }
      if (Completed != false) {
        output.WriteRawTag(16);
        output.WriteBool(Completed);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameEventId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameEventId);
      }
      if (Completed != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetCurrentChallengesRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameEventId.Length != 0) {
        GameEventId = other.GameEventId;
      }
      if (other.Completed != false) {
        Completed = other.Completed;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            GameEventId = input.ReadString();
            break;
          }
          case 16: {
            Completed = input.ReadBool();
            break;
          }
        }
      }
    }

  }

  public sealed partial class GetCurrentChallengesResponse : pb::IMessage<GetCurrentChallengesResponse> {
    private static readonly pb::MessageParser<GetCurrentChallengesResponse> _parser = new pb::MessageParser<GetCurrentChallengesResponse>(() => new GetCurrentChallengesResponse());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetCurrentChallengesResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChallengesMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesResponse(GetCurrentChallengesResponse other) : this() {
      challenges_ = other.challenges_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentChallengesResponse Clone() {
      return new GetCurrentChallengesResponse(this);
    }

    public const int ChallengesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrentChallenge> _repeated_challenges_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.CurrentChallenge.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentChallenge> challenges_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentChallenge>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentChallenge> Challenges {
      get { return challenges_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetCurrentChallengesResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetCurrentChallengesResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!challenges_.Equals(other.challenges_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= challenges_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      challenges_.WriteTo(output, _repeated_challenges_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += challenges_.CalculateSize(_repeated_challenges_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetCurrentChallengesResponse other) {
      if (other == null) {
        return;
      }
      challenges_.Add(other.challenges_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            challenges_.AddEntriesFrom(input, _repeated_challenges_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class ProgressChallengeRequest : pb::IMessage<ProgressChallengeRequest> {
    private static readonly pb::MessageParser<ProgressChallengeRequest> _parser = new pb::MessageParser<ProgressChallengeRequest>(() => new ProgressChallengeRequest());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ProgressChallengeRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChallengesMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeRequest(ProgressChallengeRequest other) : this() {
      gameEventChallengeId_ = other.gameEventChallengeId_;
      points_ = other.points_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeRequest Clone() {
      return new ProgressChallengeRequest(this);
    }

    public const int GameEventChallengeIdFieldNumber = 1;
    private string gameEventChallengeId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameEventChallengeId {
      get { return gameEventChallengeId_; }
      set {
        gameEventChallengeId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PointsFieldNumber = 2;
    private int points_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Points {
      get { return points_; }
      set {
        points_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ProgressChallengeRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ProgressChallengeRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameEventChallengeId != other.GameEventChallengeId) return false;
      if (Points != other.Points) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameEventChallengeId.Length != 0) hash ^= GameEventChallengeId.GetHashCode();
      if (Points != 0) hash ^= Points.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (GameEventChallengeId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameEventChallengeId);
      }
      if (Points != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Points);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameEventChallengeId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameEventChallengeId);
      }
      if (Points != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Points);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ProgressChallengeRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameEventChallengeId.Length != 0) {
        GameEventChallengeId = other.GameEventChallengeId;
      }
      if (other.Points != 0) {
        Points = other.Points;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            GameEventChallengeId = input.ReadString();
            break;
          }
          case 16: {
            Points = input.ReadInt32();
            break;
          }
        }
      }
    }

  }

  public sealed partial class ProgressChallengeResponse : pb::IMessage<ProgressChallengeResponse> {
    private static readonly pb::MessageParser<ProgressChallengeResponse> _parser = new pb::MessageParser<ProgressChallengeResponse>(() => new ProgressChallengeResponse());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ProgressChallengeResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChallengesMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeResponse(ProgressChallengeResponse other) : this() {
      completed_ = other.completed_;
      challengePoints_ = other.challengePoints_;
      ChallengeReward = other.challengeReward_ != null ? other.ChallengeReward.Clone() : null;
      eventPoints_ = other.eventPoints_;
      eventGamePassLevels_ = other.eventGamePassLevels_.Clone();
      EventReward = other.eventReward_ != null ? other.EventReward.Clone() : null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressChallengeResponse Clone() {
      return new ProgressChallengeResponse(this);
    }

    public const int CompletedFieldNumber = 1;
    private bool completed_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Completed {
      get { return completed_; }
      set {
        completed_ = value;
      }
    }

    public const int ChallengePointsFieldNumber = 2;
    private int challengePoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int ChallengePoints {
      get { return challengePoints_; }
      set {
        challengePoints_ = value;
      }
    }

    public const int ChallengeRewardFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Reward challengeReward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Reward ChallengeReward {
      get { return challengeReward_; }
      set {
        challengeReward_ = value;
      }
    }

    public const int EventPointsFieldNumber = 4;
    private int eventPoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int EventPoints {
      get { return eventPoints_; }
      set {
        eventPoints_ = value;
      }
    }

    public const int EventGamePassLevelsFieldNumber = 5;
    private static readonly pbc::MapField<string, int>.Codec _map_eventGamePassLevels_codec
        = new pbc::MapField<string, int>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForInt32(16), 42);
    private readonly pbc::MapField<string, int> eventGamePassLevels_ = new pbc::MapField<string, int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, int> EventGamePassLevels {
      get { return eventGamePassLevels_; }
    }

    public const int EventRewardFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.Reward eventReward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Reward EventReward {
      get { return eventReward_; }
      set {
        eventReward_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ProgressChallengeResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ProgressChallengeResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Completed != other.Completed) return false;
      if (ChallengePoints != other.ChallengePoints) return false;
      if (!object.Equals(ChallengeReward, other.ChallengeReward)) return false;
      if (EventPoints != other.EventPoints) return false;
      if (!EventGamePassLevels.Equals(other.EventGamePassLevels)) return false;
      if (!object.Equals(EventReward, other.EventReward)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Completed != false) hash ^= Completed.GetHashCode();
      if (ChallengePoints != 0) hash ^= ChallengePoints.GetHashCode();
      if (challengeReward_ != null) hash ^= ChallengeReward.GetHashCode();
      if (EventPoints != 0) hash ^= EventPoints.GetHashCode();
      hash ^= EventGamePassLevels.GetHashCode();
      if (eventReward_ != null) hash ^= EventReward.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Completed != false) {
        output.WriteRawTag(8);
        output.WriteBool(Completed);
      }
      if (ChallengePoints != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ChallengePoints);
      }
      if (challengeReward_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(ChallengeReward);
      }
      if (EventPoints != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(EventPoints);
      }
      eventGamePassLevels_.WriteTo(output, _map_eventGamePassLevels_codec);
      if (eventReward_ != null) {
        output.WriteRawTag(50);
        output.WriteMessage(EventReward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Completed != false) {
        size += 1 + 1;
      }
      if (ChallengePoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ChallengePoints);
      }
      if (challengeReward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ChallengeReward);
      }
      if (EventPoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(EventPoints);
      }
      size += eventGamePassLevels_.CalculateSize(_map_eventGamePassLevels_codec);
      if (eventReward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(EventReward);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ProgressChallengeResponse other) {
      if (other == null) {
        return;
      }
      if (other.Completed != false) {
        Completed = other.Completed;
      }
      if (other.ChallengePoints != 0) {
        ChallengePoints = other.ChallengePoints;
      }
      if (other.challengeReward_ != null) {
        if (challengeReward_ == null) {
          challengeReward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
        }
        ChallengeReward.MergeFrom(other.ChallengeReward);
      }
      if (other.EventPoints != 0) {
        EventPoints = other.EventPoints;
      }
      eventGamePassLevels_.Add(other.eventGamePassLevels_);
      if (other.eventReward_ != null) {
        if (eventReward_ == null) {
          eventReward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
        }
        EventReward.MergeFrom(other.EventReward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Completed = input.ReadBool();
            break;
          }
          case 16: {
            ChallengePoints = input.ReadInt32();
            break;
          }
          case 26: {
            if (challengeReward_ == null) {
              challengeReward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
            }
            input.ReadMessage(challengeReward_);
            break;
          }
          case 32: {
            EventPoints = input.ReadInt32();
            break;
          }
          case 42: {
            eventGamePassLevels_.AddEntriesFrom(input, _map_eventGamePassLevels_codec);
            break;
          }
          case 50: {
            if (eventReward_ == null) {
              eventReward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
            }
            input.ReadMessage(eventReward_);
            break;
          }
        }
      }
    }

  }


}

