#pragma warning disable 1591, 0612, 3021
using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
namespace Axlebolt.Bolt.Protobuf2
{
  public static partial class ClanMemberStatsMessageReflection
  {
    public static pbr::FileDescriptor Descriptor { get { return descriptor; } }
    private static pbr::FileDescriptor descriptor;
    static ClanMemberStatsMessageReflection()
    {
      byte[] descriptorData = global::System.Convert.FromBase64String(string.Concat(
            "ChxDbGFuTWVtYmVyU3RhdHNNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlBy",
            "b3RvYnVmMhoWQ2xhblN0YXRzTWVzc2FnZS5wcm90byJQChZDdXJyZW50Q2xhbk1l",
            "bWJlclN0YXRzEjYKBXN0YXRzGAEgAygLMicuQXhsZWJvbHQuQm9sdC5Qcm90b2J1",
            "ZjIuQ2xhbk1lbWJlclN0YXQiIgogR2V0Q3VycmVudENsYW5NZW1iZXJTdGF0c1Jl",
            "cXVlc3QifQohR2V0Q3VycmVudENsYW5NZW1iZXJTdGF0c1Jlc3BvbnNlEg4KBmNs",
            "YW5JZBgBIAEoCRJICg9jbGFuTWVtYmVyU3RhdHMYAiABKAsyLy5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5DdXJyZW50Q2xhbk1lbWJlclN0YXRzIiwKGkdldENsYW5N",
            "ZW1iZXJzU3RhdHNSZXF1ZXN0Eg4KBmNsYW5JZBgBIAEoCSJxChtHZXRDbGFuTWVt",
            "YmVyc1N0YXRzUmVzcG9uc2USDgoGY2xhbklkGAEgASgJEkIKEGNsYW5NZW1iZXJz",
            "U3RhdHMYAiADKAsyKC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuTWVtYmVy",
            "U3RhdHMibQohU2F2ZUN1cnJlbnRDbGFuTWVtYmVyU3RhdHNSZXF1ZXN0EkgKD2Ns",
            "YW5NZW1iZXJTdGF0cxgBIAEoCzIvLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkN1",
            "cnJlbnRDbGFuTWVtYmVyU3RhdHMiJAoiU2F2ZUN1cnJlbnRDbGFuTWVtYmVyU3Rh",
            "dHNSZXNwb25zZUIaqgIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjJiBnByb3RvMw=="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
        new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor },
        new pbr::GeneratedClrTypeInfo(null, null, new pbr::GeneratedClrTypeInfo[] {
          new pbr::GeneratedClrTypeInfo(typeof(CurrentClanMemberStats), CurrentClanMemberStats.Parser, new[] { "Stats" }, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(GetCurrentClanMemberStatsRequest), GetCurrentClanMemberStatsRequest.Parser, null, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(GetCurrentClanMemberStatsResponse), GetCurrentClanMemberStatsResponse.Parser, new[] { "ClanId", "ClanMemberStats" }, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(GetClanMembersStatsRequest), GetClanMembersStatsRequest.Parser, new[] { "ClanId" }, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(GetClanMembersStatsResponse), GetClanMembersStatsResponse.Parser, new[] { "ClanId", "ClanMembersStats" }, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(SaveCurrentClanMemberStatsRequest), SaveCurrentClanMemberStatsRequest.Parser, new[] { "ClanMemberStats" }, null, null, null, null),
          new pbr::GeneratedClrTypeInfo(typeof(SaveCurrentClanMemberStatsResponse), SaveCurrentClanMemberStatsResponse.Parser, null, null, null, null, null)
        }));
    }
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CurrentClanMemberStats : pb::IMessage<CurrentClanMemberStats>
  {
    private static readonly pb::MessageParser<CurrentClanMemberStats> _parser = new pb::MessageParser<CurrentClanMemberStats>(() => new CurrentClanMemberStats());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<CurrentClanMemberStats> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[0]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public CurrentClanMemberStats() { }
    public const int StatsFieldNumber = 1;
    private static readonly pb::FieldCodec<ClanMemberStat> _repeated_stats_codec = pb::FieldCodec.ForMessage(10, ClanMemberStat.Parser);
    private readonly pbc::RepeatedField<ClanMemberStat> stats_ = new pbc::RepeatedField<ClanMemberStat>();
    public pbc::RepeatedField<ClanMemberStat> Stats { get { return stats_; } }
    public CurrentClanMemberStats(CurrentClanMemberStats other) { stats_ = other.stats_.Clone(); _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields); }
    public CurrentClanMemberStats Clone() { return new CurrentClanMemberStats(this); }
    public override bool Equals(object other) { return Equals(other as CurrentClanMemberStats); }
    public bool Equals(CurrentClanMemberStats other) { if (ReferenceEquals(other,null)) return false; if (ReferenceEquals(other,this)) return true; return stats_.Equals(other.stats_) && Equals(_unknownFields,other._unknownFields); }
    public override int GetHashCode() { int hash=1; hash ^= stats_.GetHashCode(); if (_unknownFields!=null) hash^=_unknownFields.GetHashCode(); return hash; }
    public override string ToString() { return pb::JsonFormatter.ToDiagnosticString(this); }
    public void WriteTo(pb::CodedOutputStream output) { stats_.WriteTo(output,_repeated_stats_codec); if (_unknownFields!=null) _unknownFields.WriteTo(output); }
    public int CalculateSize() { int size=stats_.CalculateSize(_repeated_stats_codec); if (_unknownFields!=null) size+=_unknownFields.CalculateSize(); return size; }
    public void MergeFrom(CurrentClanMemberStats other) { if (other==null) return; stats_.Add(other.stats_); _unknownFields=pb::UnknownFieldSet.MergeFrom(_unknownFields,other._unknownFields); }
    public void MergeFrom(pb::CodedInputStream input) { uint tag; while((tag=input.ReadTag())!=0) { if((tag&7)==4)return; switch(tag){ case 10: stats_.AddEntriesFrom(input,_repeated_stats_codec); break; default:_unknownFields=pb::UnknownFieldSet.MergeFieldFrom(_unknownFields,input);break;} } }
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetCurrentClanMemberStatsRequest : pb::IMessage<GetCurrentClanMemberStatsRequest>
  {
    private static readonly pb::MessageParser<GetCurrentClanMemberStatsRequest> _parser = new pb::MessageParser<GetCurrentClanMemberStatsRequest>(() => new GetCurrentClanMemberStatsRequest());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<GetCurrentClanMemberStatsRequest> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[1]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public GetCurrentClanMemberStatsRequest() { }
    public GetCurrentClanMemberStatsRequest(GetCurrentClanMemberStatsRequest other) { _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields); }
    public GetCurrentClanMemberStatsRequest Clone() { return new GetCurrentClanMemberStatsRequest(this); }
    public override bool Equals(object other) { return Equals(other as GetCurrentClanMemberStatsRequest); }
    public bool Equals(GetCurrentClanMemberStatsRequest other) { return !global::System.Object.ReferenceEquals(other, null) && (global::System.Object.ReferenceEquals(other, this) || Equals(_unknownFields, other._unknownFields)); }
    public override int GetHashCode() { return _unknownFields == null ? 1 : 1 ^ _unknownFields.GetHashCode(); }
    public override string ToString() { return pb::JsonFormatter.ToDiagnosticString(this); }
    public void WriteTo(pb::CodedOutputStream output) { if (_unknownFields != null) _unknownFields.WriteTo(output); }
    public int CalculateSize() { return _unknownFields == null ? 0 : _unknownFields.CalculateSize(); }
    public void MergeFrom(GetCurrentClanMemberStatsRequest other) { if (other != null) _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields); }
    public void MergeFrom(pb::CodedInputStream input) { uint tag; while ((tag = input.ReadTag()) != 0) { if ((tag & 7) == 4) return; _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input); } }
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetCurrentClanMemberStatsResponse : pb::IMessage<GetCurrentClanMemberStatsResponse>
  {
    private static readonly pb::MessageParser<GetCurrentClanMemberStatsResponse> _parser = new pb::MessageParser<GetCurrentClanMemberStatsResponse>(() => new GetCurrentClanMemberStatsResponse());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<GetCurrentClanMemberStatsResponse> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[2]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public GetCurrentClanMemberStatsResponse() { }
    public const int ClanIdFieldNumber=1; private string clanId_=""; public string ClanId { get{return clanId_;} set{clanId_=pb::ProtoPreconditions.CheckNotNull(value,"value");} }
    public const int ClanMemberStatsFieldNumber=2; private CurrentClanMemberStats clanMemberStats_; public CurrentClanMemberStats ClanMemberStats { get{return clanMemberStats_;} set{clanMemberStats_=value;} }
    public GetCurrentClanMemberStatsResponse(GetCurrentClanMemberStatsResponse other){clanId_=other.clanId_; clanMemberStats_=other.clanMemberStats_!=null?other.clanMemberStats_.Clone():null; _unknownFields=pb::UnknownFieldSet.Clone(other._unknownFields);} public GetCurrentClanMemberStatsResponse Clone(){return new GetCurrentClanMemberStatsResponse(this);}
    public override bool Equals(object o){return Equals(o as GetCurrentClanMemberStatsResponse);} public bool Equals(GetCurrentClanMemberStatsResponse o){if(ReferenceEquals(o,null))return false;if(ReferenceEquals(o,this))return true;return ClanId==o.ClanId && Equals(ClanMemberStats,o.ClanMemberStats)&&Equals(_unknownFields,o._unknownFields);} public override int GetHashCode(){int h=1;if(ClanId.Length!=0)h^=ClanId.GetHashCode();if(clanMemberStats_!=null)h^=ClanMemberStats.GetHashCode();if(_unknownFields!=null)h^=_unknownFields.GetHashCode();return h;} public override string ToString(){return pb::JsonFormatter.ToDiagnosticString(this);}
    public void WriteTo(pb::CodedOutputStream output){if(ClanId.Length!=0){output.WriteRawTag(10);output.WriteString(ClanId);}if(clanMemberStats_!=null){output.WriteRawTag(18);output.WriteMessage(ClanMemberStats);}if(_unknownFields!=null)_unknownFields.WriteTo(output);} public int CalculateSize(){int s=0;if(ClanId.Length!=0)s+=1+pb::CodedOutputStream.ComputeStringSize(ClanId);if(clanMemberStats_!=null)s+=1+pb::CodedOutputStream.ComputeMessageSize(ClanMemberStats);if(_unknownFields!=null)s+=_unknownFields.CalculateSize();return s;}
    public void MergeFrom(GetCurrentClanMemberStatsResponse o){if(o==null)return;if(o.ClanId.Length!=0)ClanId=o.ClanId;if(o.clanMemberStats_!=null){if(clanMemberStats_==null)ClanMemberStats=new CurrentClanMemberStats();ClanMemberStats.MergeFrom(o.ClanMemberStats);}_unknownFields=pb::UnknownFieldSet.MergeFrom(_unknownFields,o._unknownFields);} public void MergeFrom(pb::CodedInputStream input){uint tag;while((tag=input.ReadTag())!=0){if((tag&7)==4)return;switch(tag){case 10:ClanId=input.ReadString();break;case 18:if(clanMemberStats_==null)ClanMemberStats=new CurrentClanMemberStats();input.ReadMessage(ClanMemberStats);break;default:_unknownFields=pb::UnknownFieldSet.MergeFieldFrom(_unknownFields,input);break;}}}
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClanMembersStatsRequest : pb::IMessage<GetClanMembersStatsRequest>
  {
    private static readonly pb::MessageParser<GetClanMembersStatsRequest> _parser = new pb::MessageParser<GetClanMembersStatsRequest>(() => new GetClanMembersStatsRequest());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<GetClanMembersStatsRequest> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[3]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public GetClanMembersStatsRequest() { }
    public const int ClanIdFieldNumber=1; private string clanId_=""; public string ClanId { get{return clanId_;} set{clanId_=pb::ProtoPreconditions.CheckNotNull(value,"value");} }
    public GetClanMembersStatsRequest(GetClanMembersStatsRequest other){clanId_=other.clanId_;_unknownFields=pb::UnknownFieldSet.Clone(other._unknownFields);} public GetClanMembersStatsRequest Clone(){return new GetClanMembersStatsRequest(this);} public override bool Equals(object o){return Equals(o as GetClanMembersStatsRequest);}public bool Equals(GetClanMembersStatsRequest o){return !ReferenceEquals(o,null)&&(ReferenceEquals(o,this)||(ClanId==o.ClanId&&Equals(_unknownFields,o._unknownFields)));}public override int GetHashCode(){int h=1;if(ClanId.Length!=0)h^=ClanId.GetHashCode();if(_unknownFields!=null)h^=_unknownFields.GetHashCode();return h;}public override string ToString(){return pb::JsonFormatter.ToDiagnosticString(this);}public void WriteTo(pb::CodedOutputStream output){if(ClanId.Length!=0){output.WriteRawTag(10);output.WriteString(ClanId);}if(_unknownFields!=null)_unknownFields.WriteTo(output);}public int CalculateSize(){int s=ClanId.Length==0?0:1+pb::CodedOutputStream.ComputeStringSize(ClanId);if(_unknownFields!=null)s+=_unknownFields.CalculateSize();return s;}public void MergeFrom(GetClanMembersStatsRequest o){if(o==null)return;if(o.ClanId.Length!=0)ClanId=o.ClanId;_unknownFields=pb::UnknownFieldSet.MergeFrom(_unknownFields,o._unknownFields);}public void MergeFrom(pb::CodedInputStream input){uint tag;while((tag=input.ReadTag())!=0){if((tag&7)==4)return;if(tag==10)ClanId=input.ReadString();else _unknownFields=pb::UnknownFieldSet.MergeFieldFrom(_unknownFields,input);}}
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClanMembersStatsResponse : pb::IMessage<GetClanMembersStatsResponse>
  {
    private static readonly pb::MessageParser<GetClanMembersStatsResponse> _parser = new pb::MessageParser<GetClanMembersStatsResponse>(() => new GetClanMembersStatsResponse());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<GetClanMembersStatsResponse> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[4]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public GetClanMembersStatsResponse() { }
    public const int ClanIdFieldNumber=1; private string clanId_=""; public string ClanId {get{return clanId_;}set{clanId_=pb::ProtoPreconditions.CheckNotNull(value,"value");}}
    public const int ClanMembersStatsFieldNumber=2; private static readonly pb::FieldCodec<ClanMemberStats> _repeated_clanMembersStats_codec=pb::FieldCodec.ForMessage(18,ClanMemberStats.Parser); private readonly pbc::RepeatedField<ClanMemberStats> clanMembersStats_=new pbc::RepeatedField<ClanMemberStats>(); public pbc::RepeatedField<ClanMemberStats> ClanMembersStats{get{return clanMembersStats_;}}
    public GetClanMembersStatsResponse(GetClanMembersStatsResponse other){clanId_=other.clanId_;clanMembersStats_=other.clanMembersStats_.Clone();_unknownFields=pb::UnknownFieldSet.Clone(other._unknownFields);}public GetClanMembersStatsResponse Clone(){return new GetClanMembersStatsResponse(this);}public override bool Equals(object o){return Equals(o as GetClanMembersStatsResponse);}public bool Equals(GetClanMembersStatsResponse o){if(ReferenceEquals(o,null))return false;if(ReferenceEquals(o,this))return true;return ClanId==o.ClanId&&clanMembersStats_.Equals(o.clanMembersStats_)&&Equals(_unknownFields,o._unknownFields);}public override int GetHashCode(){int h=1;if(ClanId.Length!=0)h^=ClanId.GetHashCode();h^=clanMembersStats_.GetHashCode();if(_unknownFields!=null)h^=_unknownFields.GetHashCode();return h;}public override string ToString(){return pb::JsonFormatter.ToDiagnosticString(this);}public void WriteTo(pb::CodedOutputStream output){if(ClanId.Length!=0){output.WriteRawTag(10);output.WriteString(ClanId);}clanMembersStats_.WriteTo(output,_repeated_clanMembersStats_codec);if(_unknownFields!=null)_unknownFields.WriteTo(output);}public int CalculateSize(){int s=ClanId.Length==0?0:1+pb::CodedOutputStream.ComputeStringSize(ClanId);s+=clanMembersStats_.CalculateSize(_repeated_clanMembersStats_codec);if(_unknownFields!=null)s+=_unknownFields.CalculateSize();return s;}public void MergeFrom(GetClanMembersStatsResponse o){if(o==null)return;if(o.ClanId.Length!=0)ClanId=o.ClanId;clanMembersStats_.Add(o.clanMembersStats_);_unknownFields=pb::UnknownFieldSet.MergeFrom(_unknownFields,o._unknownFields);}public void MergeFrom(pb::CodedInputStream input){uint tag;while((tag=input.ReadTag())!=0){if((tag&7)==4)return;switch(tag){case 10:ClanId=input.ReadString();break;case 18:clanMembersStats_.AddEntriesFrom(input,_repeated_clanMembersStats_codec);break;default:_unknownFields=pb::UnknownFieldSet.MergeFieldFrom(_unknownFields,input);break;}}}
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class SaveCurrentClanMemberStatsRequest : pb::IMessage<SaveCurrentClanMemberStatsRequest>
  {
    private static readonly pb::MessageParser<SaveCurrentClanMemberStatsRequest> _parser = new pb::MessageParser<SaveCurrentClanMemberStatsRequest>(() => new SaveCurrentClanMemberStatsRequest());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<SaveCurrentClanMemberStatsRequest> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[5]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public SaveCurrentClanMemberStatsRequest() { }
    public const int ClanMemberStatsFieldNumber=1;private CurrentClanMemberStats clanMemberStats_;public CurrentClanMemberStats ClanMemberStats{get{return clanMemberStats_;}set{clanMemberStats_=value;}}
    public SaveCurrentClanMemberStatsRequest(SaveCurrentClanMemberStatsRequest other){clanMemberStats_=other.clanMemberStats_!=null?other.clanMemberStats_.Clone():null;_unknownFields=pb::UnknownFieldSet.Clone(other._unknownFields);}public SaveCurrentClanMemberStatsRequest Clone(){return new SaveCurrentClanMemberStatsRequest(this);}public override bool Equals(object o){return Equals(o as SaveCurrentClanMemberStatsRequest);}public bool Equals(SaveCurrentClanMemberStatsRequest o){return !ReferenceEquals(o,null)&&(ReferenceEquals(o,this)||(Equals(ClanMemberStats,o.ClanMemberStats)&&Equals(_unknownFields,o._unknownFields)));}public override int GetHashCode(){int h=1;if(clanMemberStats_!=null)h^=ClanMemberStats.GetHashCode();if(_unknownFields!=null)h^=_unknownFields.GetHashCode();return h;}public override string ToString(){return pb::JsonFormatter.ToDiagnosticString(this);}public void WriteTo(pb::CodedOutputStream output){if(clanMemberStats_!=null){output.WriteRawTag(10);output.WriteMessage(ClanMemberStats);}if(_unknownFields!=null)_unknownFields.WriteTo(output);}public int CalculateSize(){int s=clanMemberStats_==null?0:1+pb::CodedOutputStream.ComputeMessageSize(ClanMemberStats);if(_unknownFields!=null)s+=_unknownFields.CalculateSize();return s;}public void MergeFrom(SaveCurrentClanMemberStatsRequest o){if(o==null)return;if(o.clanMemberStats_!=null){if(clanMemberStats_==null)ClanMemberStats=new CurrentClanMemberStats();ClanMemberStats.MergeFrom(o.ClanMemberStats);}_unknownFields=pb::UnknownFieldSet.MergeFrom(_unknownFields,o._unknownFields);}public void MergeFrom(pb::CodedInputStream input){uint tag;while((tag=input.ReadTag())!=0){if((tag&7)==4)return;if(tag==10){if(clanMemberStats_==null)ClanMemberStats=new CurrentClanMemberStats();input.ReadMessage(ClanMemberStats);}else _unknownFields=pb::UnknownFieldSet.MergeFieldFrom(_unknownFields,input);}}
  }
  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class SaveCurrentClanMemberStatsResponse : pb::IMessage<SaveCurrentClanMemberStatsResponse>
  {
    private static readonly pb::MessageParser<SaveCurrentClanMemberStatsResponse> _parser = new pb::MessageParser<SaveCurrentClanMemberStatsResponse>(() => new SaveCurrentClanMemberStatsResponse());
    private pb::UnknownFieldSet _unknownFields;
    public static pb::MessageParser<SaveCurrentClanMemberStatsResponse> Parser { get { return _parser; } }
    public static pbr::MessageDescriptor Descriptor { get { return ClanMemberStatsMessageReflection.Descriptor.MessageTypes[6]; } }
    pbr::MessageDescriptor pb::IMessage.Descriptor { get { return Descriptor; } }
    public SaveCurrentClanMemberStatsResponse() { }
    public SaveCurrentClanMemberStatsResponse(SaveCurrentClanMemberStatsResponse other) { _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields); }
    public SaveCurrentClanMemberStatsResponse Clone() { return new SaveCurrentClanMemberStatsResponse(this); }
    public override bool Equals(object other) { return Equals(other as SaveCurrentClanMemberStatsResponse); }
    public bool Equals(SaveCurrentClanMemberStatsResponse other) { return !global::System.Object.ReferenceEquals(other, null) && (global::System.Object.ReferenceEquals(other, this) || Equals(_unknownFields, other._unknownFields)); }
    public override int GetHashCode() { return _unknownFields == null ? 1 : 1 ^ _unknownFields.GetHashCode(); }
    public override string ToString() { return pb::JsonFormatter.ToDiagnosticString(this); }
    public void WriteTo(pb::CodedOutputStream output) { if (_unknownFields != null) _unknownFields.WriteTo(output); }
    public int CalculateSize() { return _unknownFields == null ? 0 : _unknownFields.CalculateSize(); }
    public void MergeFrom(SaveCurrentClanMemberStatsResponse other) { if (other != null) _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields); }
    public void MergeFrom(pb::CodedInputStream input) { uint tag; while ((tag = input.ReadTag()) != 0) { if ((tag & 7) == 4) return; _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input); } }
  }
}
