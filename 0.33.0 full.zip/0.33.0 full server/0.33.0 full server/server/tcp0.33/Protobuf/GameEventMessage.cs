#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class GameEventMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static GameEventMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChZHYW1lRXZlbnRNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMhoTQ29tbW9uTWVzc2FnZS5wcm90bxoVQ3VycmVuY3lNZXNzYWdlLnBy",
            "b3RvGhZJbnZlbnRvcnlNZXNzYWdlLnByb3RvIo8BCghHYW1lUGFzcxIKCgJp",
            "ZBgBIAEoCRIMCgRjb2RlGAIgASgJEhsKE2tleUl0ZW1EZWZpbml0aW9uSWQY",
            "AyABKAUSNgoGbGV2ZWxzGAQgAygLMiYuQXhsZWJvbHQuQm9sdC5Qcm90b2J1",
            "ZjIuR2FtZVBhc3NMZXZlbBIUCgxjdXJyZW50TGV2ZWwYBSABKAUiZgoNR2Ft",
            "ZVBhc3NMZXZlbBINCgVsZXZlbBgBIAEoBRIRCgltaW5Qb2ludHMYAiABKAUS",
            "MwoGcmV3YXJkGAMgASgLMiMuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUmV3",
            "YXJkSW5mbyJdChxHZXRDdXJyZW50R2FtZUV2ZW50c1Jlc3BvbnNlEj0KCmdh",
            "bWVFdmVudHMYASADKAsyKS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DdXJy",
            "ZW50R2FtZUV2ZW50IsMBChBDdXJyZW50R2FtZUV2ZW50EgoKAmlkGAEgASgJ",
            "EgwKBGNvZGUYAiABKAkSEQoJZGF0ZVNpbmNlGAMgASgDEhEKCWRhdGVVbnRp",
            "bBgEIAEoAxIUCgxkdXJhdGlvbkRheXMYBSABKAUSNQoKZ2FtZVBhc3NlcxgG",
            "IAMoCzIhLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkdhbWVQYXNzEg4KBnBv",
            "aW50cxgHIAEoBRISCgpjdXJyZW50RGF5GAggASgFIj8KGFByb2dyZXNzR2Ft",
            "ZUV2ZW50UmVxdWVzdBITCgtnYW1lRXZlbnRJZBgBIAEoCRIOCgZwb2ludHMY",
            "AiABKAUi2wEKGVByb2dyZXNzR2FtZUV2ZW50UmVzcG9uc2USDgoGcG9pbnRz",
            "GAEgASgFEk4KBmxldmVscxgCIAMoCzI+LkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLlByb2dyZXNzR2FtZUV2ZW50UmVzcG9uc2UuTGV2ZWxzRW50cnkSLwoG",
            "cmV3YXJkGAMgASgLMh8uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUmV3YXJk",
            "Gi0KC0xldmVsc0VudHJ5EgsKA2tleRgBIAEoCRINCgV2YWx1ZRgCIAEoBToC",
            "OAEi5gEKFk9uR2FtZVBhc3NDaGFuZ2VkRXZlbnQSDwoHZXZlbnRJZBgBIAEo",
            "CRIOCgZwb2ludHMYAiABKAUSSwoGbGV2ZWxzGAMgAygLMjsuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuT25HYW1lUGFzc0NoYW5nZWRFdmVudC5MZXZlbHNF",
            "bnRyeRIvCgZyZXdhcmQYBCABKAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVm",
            "Mi5SZXdhcmQaLQoLTGV2ZWxzRW50cnkSCwoDa2V5GAEgASgJEg0KBXZhbHVl",
            "GAIgASgFOgI4AWIGcHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CommonMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GamePass), global::Axlebolt.Bolt.Protobuf2.GamePass.Parser, new[]{ "Id", "Code", "KeyItemDefinitionId", "Levels", "CurrentLevel" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GamePassLevel), global::Axlebolt.Bolt.Protobuf2.GamePassLevel.Parser, new[]{ "Level", "MinPoints", "Reward" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetCurrentGameEventsResponse), global::Axlebolt.Bolt.Protobuf2.GetCurrentGameEventsResponse.Parser, new[]{ "GameEvents" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent), global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent.Parser, new[]{ "Id", "Code", "DateSince", "DateUntil", "DurationDays", "GamePasses", "Points", "CurrentDay" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ProgressGameEventRequest), global::Axlebolt.Bolt.Protobuf2.ProgressGameEventRequest.Parser, new[]{ "GameEventId", "Points" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ProgressGameEventResponse), global::Axlebolt.Bolt.Protobuf2.ProgressGameEventResponse.Parser, new[]{ "Points", "Levels", "Reward" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnGamePassChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnGamePassChangedEvent.Parser, new[]{ "EventId", "Points", "Levels", "Reward" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, })
          }));
    }

  }
  public sealed partial class GamePass : pb::IMessage<GamePass> {
    private static readonly pb::MessageParser<GamePass> _parser = new pb::MessageParser<GamePass>(() => new GamePass());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GamePass> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePass() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePass(GamePass other) : this() {
      id_ = other.id_;
      code_ = other.code_;
      keyItemDefinitionId_ = other.keyItemDefinitionId_;
      levels_ = other.levels_.Clone();
      currentLevel_ = other.currentLevel_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePass Clone() {
      return new GamePass(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CodeFieldNumber = 2;
    private string code_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Code {
      get { return code_; }
      set {
        code_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int KeyItemDefinitionIdFieldNumber = 3;
    private int keyItemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int KeyItemDefinitionId {
      get { return keyItemDefinitionId_; }
      set {
        keyItemDefinitionId_ = value;
      }
    }

    public const int LevelsFieldNumber = 4;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.GamePassLevel> _repeated_levels_codec
        = pb::FieldCodec.ForMessage(34, global::Axlebolt.Bolt.Protobuf2.GamePassLevel.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePassLevel> levels_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePassLevel>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePassLevel> Levels {
      get { return levels_; }
    }

    public const int CurrentLevelFieldNumber = 5;
    private int currentLevel_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CurrentLevel {
      get { return currentLevel_; }
      set {
        currentLevel_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GamePass);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GamePass other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Code != other.Code) return false;
      if (KeyItemDefinitionId != other.KeyItemDefinitionId) return false;
      if(!levels_.Equals(other.levels_)) return false;
      if (CurrentLevel != other.CurrentLevel) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Code.Length != 0) hash ^= Code.GetHashCode();
      if (KeyItemDefinitionId != 0) hash ^= KeyItemDefinitionId.GetHashCode();
      hash ^= levels_.GetHashCode();
      if (CurrentLevel != 0) hash ^= CurrentLevel.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Code.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Code);
      }
      if (KeyItemDefinitionId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(KeyItemDefinitionId);
      }
      levels_.WriteTo(output, _repeated_levels_codec);
      if (CurrentLevel != 0) {
        output.WriteRawTag(40);
        output.WriteInt32(CurrentLevel);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Code.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Code);
      }
      if (KeyItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(KeyItemDefinitionId);
      }
      size += levels_.CalculateSize(_repeated_levels_codec);
      if (CurrentLevel != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrentLevel);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GamePass other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Code.Length != 0) {
        Code = other.Code;
      }
      if (other.KeyItemDefinitionId != 0) {
        KeyItemDefinitionId = other.KeyItemDefinitionId;
      }
      levels_.Add(other.levels_);
      if (other.CurrentLevel != 0) {
        CurrentLevel = other.CurrentLevel;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Code = input.ReadString();
            break;
          }
          case 24: {
            KeyItemDefinitionId = input.ReadInt32();
            break;
          }
          case 34: {
            levels_.AddEntriesFrom(input, _repeated_levels_codec);
            break;
          }
          case 40: {
            CurrentLevel = input.ReadInt32();
            break;
          }
        }
      }
    }

  }

  public sealed partial class GamePassLevel : pb::IMessage<GamePassLevel> {
    private static readonly pb::MessageParser<GamePassLevel> _parser = new pb::MessageParser<GamePassLevel>(() => new GamePassLevel());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GamePassLevel> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePassLevel() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePassLevel(GamePassLevel other) : this() {
      level_ = other.level_;
      minPoints_ = other.minPoints_;
      Reward = other.reward_ != null ? other.Reward.Clone() : null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GamePassLevel Clone() {
      return new GamePassLevel(this);
    }

    public const int LevelFieldNumber = 1;
    private int level_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Level {
      get { return level_; }
      set {
        level_ = value;
      }
    }

    public const int MinPointsFieldNumber = 2;
    private int minPoints_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MinPoints {
      get { return minPoints_; }
      set {
        minPoints_ = value;
      }
    }

    public const int RewardFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.RewardInfo reward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.RewardInfo Reward {
      get { return reward_; }
      set {
        reward_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GamePassLevel);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GamePassLevel other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Level != other.Level) return false;
      if (MinPoints != other.MinPoints) return false;
      if (!object.Equals(Reward, other.Reward)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Level != 0) hash ^= Level.GetHashCode();
      if (MinPoints != 0) hash ^= MinPoints.GetHashCode();
      if (reward_ != null) hash ^= Reward.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Level != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Level);
      }
      if (MinPoints != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(MinPoints);
      }
      if (reward_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Level != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Level);
      }
      if (MinPoints != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MinPoints);
      }
      if (reward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Reward);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GamePassLevel other) {
      if (other == null) {
        return;
      }
      if (other.Level != 0) {
        Level = other.Level;
      }
      if (other.MinPoints != 0) {
        MinPoints = other.MinPoints;
      }
      if (other.reward_ != null) {
        if (reward_ == null) {
          reward_ = new global::Axlebolt.Bolt.Protobuf2.RewardInfo();
        }
        Reward.MergeFrom(other.Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Level = input.ReadInt32();
            break;
          }
          case 16: {
            MinPoints = input.ReadInt32();
            break;
          }
          case 26: {
            if (reward_ == null) {
              reward_ = new global::Axlebolt.Bolt.Protobuf2.RewardInfo();
            }
            input.ReadMessage(reward_);
            break;
          }
        }
      }
    }

  }

  public sealed partial class GetCurrentGameEventsResponse : pb::IMessage<GetCurrentGameEventsResponse> {
    private static readonly pb::MessageParser<GetCurrentGameEventsResponse> _parser = new pb::MessageParser<GetCurrentGameEventsResponse>(() => new GetCurrentGameEventsResponse());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetCurrentGameEventsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentGameEventsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentGameEventsResponse(GetCurrentGameEventsResponse other) : this() {
      gameEvents_ = other.gameEvents_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetCurrentGameEventsResponse Clone() {
      return new GetCurrentGameEventsResponse(this);
    }

    public const int GameEventsFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent> _repeated_gameEvents_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent> gameEvents_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrentGameEvent> GameEvents {
      get { return gameEvents_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetCurrentGameEventsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetCurrentGameEventsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!gameEvents_.Equals(other.gameEvents_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= gameEvents_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      gameEvents_.WriteTo(output, _repeated_gameEvents_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += gameEvents_.CalculateSize(_repeated_gameEvents_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetCurrentGameEventsResponse other) {
      if (other == null) {
        return;
      }
      gameEvents_.Add(other.gameEvents_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            gameEvents_.AddEntriesFrom(input, _repeated_gameEvents_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class CurrentGameEvent : pb::IMessage<CurrentGameEvent> {
    private static readonly pb::MessageParser<CurrentGameEvent> _parser = new pb::MessageParser<CurrentGameEvent>(() => new CurrentGameEvent());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<CurrentGameEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentGameEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentGameEvent(CurrentGameEvent other) : this() {
      id_ = other.id_;
      code_ = other.code_;
      dateSince_ = other.dateSince_;
      dateUntil_ = other.dateUntil_;
      durationDays_ = other.durationDays_;
      gamePasses_ = other.gamePasses_.Clone();
      points_ = other.points_;
      currentDay_ = other.currentDay_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrentGameEvent Clone() {
      return new CurrentGameEvent(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CodeFieldNumber = 2;
    private string code_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Code {
      get { return code_; }
      set {
        code_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int DateSinceFieldNumber = 3;
    private long dateSince_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long DateSince {
      get { return dateSince_; }
      set {
        dateSince_ = value;
      }
    }

    public const int DateUntilFieldNumber = 4;
    private long dateUntil_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long DateUntil {
      get { return dateUntil_; }
      set {
        dateUntil_ = value;
      }
    }

    public const int DurationDaysFieldNumber = 5;
    private int durationDays_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int DurationDays {
      get { return durationDays_; }
      set {
        durationDays_ = value;
      }
    }

    public const int GamePassesFieldNumber = 6;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.GamePass> _repeated_gamePasses_codec
        = pb::FieldCodec.ForMessage(50, global::Axlebolt.Bolt.Protobuf2.GamePass.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePass> gamePasses_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePass>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.GamePass> GamePasses {
      get { return gamePasses_; }
    }

    public const int PointsFieldNumber = 7;
    private int points_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Points {
      get { return points_; }
      set {
        points_ = value;
      }
    }

    public const int CurrentDayFieldNumber = 8;
    private int currentDay_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CurrentDay {
      get { return currentDay_; }
      set {
        currentDay_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as CurrentGameEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(CurrentGameEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Code != other.Code) return false;
      if (DateSince != other.DateSince) return false;
      if (DateUntil != other.DateUntil) return false;
      if (DurationDays != other.DurationDays) return false;
      if(!gamePasses_.Equals(other.gamePasses_)) return false;
      if (Points != other.Points) return false;
      if (CurrentDay != other.CurrentDay) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Code.Length != 0) hash ^= Code.GetHashCode();
      if (DateSince != 0L) hash ^= DateSince.GetHashCode();
      if (DateUntil != 0L) hash ^= DateUntil.GetHashCode();
      if (DurationDays != 0) hash ^= DurationDays.GetHashCode();
      hash ^= gamePasses_.GetHashCode();
      if (Points != 0) hash ^= Points.GetHashCode();
      if (CurrentDay != 0) hash ^= CurrentDay.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Code.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Code);
      }
      if (DateSince != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(DateSince);
      }
      if (DateUntil != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(DateUntil);
      }
      if (DurationDays != 0) {
        output.WriteRawTag(40);
        output.WriteInt32(DurationDays);
      }
      gamePasses_.WriteTo(output, _repeated_gamePasses_codec);
      if (Points != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(Points);
      }
      if (CurrentDay != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(CurrentDay);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Code.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Code);
      }
      if (DateSince != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(DateSince);
      }
      if (DateUntil != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(DateUntil);
      }
      if (DurationDays != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(DurationDays);
      }
      size += gamePasses_.CalculateSize(_repeated_gamePasses_codec);
      if (Points != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Points);
      }
      if (CurrentDay != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrentDay);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(CurrentGameEvent other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Code.Length != 0) {
        Code = other.Code;
      }
      if (other.DateSince != 0L) {
        DateSince = other.DateSince;
      }
      if (other.DateUntil != 0L) {
        DateUntil = other.DateUntil;
      }
      if (other.DurationDays != 0) {
        DurationDays = other.DurationDays;
      }
      gamePasses_.Add(other.gamePasses_);
      if (other.Points != 0) {
        Points = other.Points;
      }
      if (other.CurrentDay != 0) {
        CurrentDay = other.CurrentDay;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Code = input.ReadString();
            break;
          }
          case 24: {
            DateSince = input.ReadInt64();
            break;
          }
          case 32: {
            DateUntil = input.ReadInt64();
            break;
          }
          case 40: {
            DurationDays = input.ReadInt32();
            break;
          }
          case 50: {
            gamePasses_.AddEntriesFrom(input, _repeated_gamePasses_codec);
            break;
          }
          case 56: {
            Points = input.ReadInt32();
            break;
          }
          case 64: {
            CurrentDay = input.ReadInt32();
            break;
          }
        }
      }
    }

  }

  public sealed partial class ProgressGameEventRequest : pb::IMessage<ProgressGameEventRequest> {
    private static readonly pb::MessageParser<ProgressGameEventRequest> _parser = new pb::MessageParser<ProgressGameEventRequest>(() => new ProgressGameEventRequest());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ProgressGameEventRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventRequest(ProgressGameEventRequest other) : this() {
      gameEventId_ = other.gameEventId_;
      points_ = other.points_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventRequest Clone() {
      return new ProgressGameEventRequest(this);
    }

    public const int GameEventIdFieldNumber = 1;
    private string gameEventId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameEventId {
      get { return gameEventId_; }
      set {
        gameEventId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PointsFieldNumber = 2;
    private int points_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Points {
      get { return points_; }
      set {
        points_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ProgressGameEventRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ProgressGameEventRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameEventId != other.GameEventId) return false;
      if (Points != other.Points) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameEventId.Length != 0) hash ^= GameEventId.GetHashCode();
      if (Points != 0) hash ^= Points.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (GameEventId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameEventId);
      }
      if (Points != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Points);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameEventId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameEventId);
      }
      if (Points != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Points);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ProgressGameEventRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameEventId.Length != 0) {
        GameEventId = other.GameEventId;
      }
      if (other.Points != 0) {
        Points = other.Points;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            GameEventId = input.ReadString();
            break;
          }
          case 16: {
            Points = input.ReadInt32();
            break;
          }
        }
      }
    }

  }

  public sealed partial class ProgressGameEventResponse : pb::IMessage<ProgressGameEventResponse> {
    private static readonly pb::MessageParser<ProgressGameEventResponse> _parser = new pb::MessageParser<ProgressGameEventResponse>(() => new ProgressGameEventResponse());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ProgressGameEventResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventResponse(ProgressGameEventResponse other) : this() {
      points_ = other.points_;
      levels_ = other.levels_.Clone();
      Reward = other.reward_ != null ? other.Reward.Clone() : null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ProgressGameEventResponse Clone() {
      return new ProgressGameEventResponse(this);
    }

    public const int PointsFieldNumber = 1;
    private int points_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Points {
      get { return points_; }
      set {
        points_ = value;
      }
    }

    public const int LevelsFieldNumber = 2;
    private static readonly pbc::MapField<string, int>.Codec _map_levels_codec
        = new pbc::MapField<string, int>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForInt32(16), 18);
    private readonly pbc::MapField<string, int> levels_ = new pbc::MapField<string, int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, int> Levels {
      get { return levels_; }
    }

    public const int RewardFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Reward reward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Reward Reward {
      get { return reward_; }
      set {
        reward_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ProgressGameEventResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ProgressGameEventResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Points != other.Points) return false;
      if (!Levels.Equals(other.Levels)) return false;
      if (!object.Equals(Reward, other.Reward)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Points != 0) hash ^= Points.GetHashCode();
      hash ^= Levels.GetHashCode();
      if (reward_ != null) hash ^= Reward.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Points != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Points);
      }
      levels_.WriteTo(output, _map_levels_codec);
      if (reward_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Points != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Points);
      }
      size += levels_.CalculateSize(_map_levels_codec);
      if (reward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Reward);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ProgressGameEventResponse other) {
      if (other == null) {
        return;
      }
      if (other.Points != 0) {
        Points = other.Points;
      }
      levels_.Add(other.levels_);
      if (other.reward_ != null) {
        if (reward_ == null) {
          reward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
        }
        Reward.MergeFrom(other.Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Points = input.ReadInt32();
            break;
          }
          case 18: {
            levels_.AddEntriesFrom(input, _map_levels_codec);
            break;
          }
          case 26: {
            if (reward_ == null) {
              reward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
            }
            input.ReadMessage(reward_);
            break;
          }
        }
      }
    }

  }

  public sealed partial class OnGamePassChangedEvent : pb::IMessage<OnGamePassChangedEvent> {
    private static readonly pb::MessageParser<OnGamePassChangedEvent> _parser = new pb::MessageParser<OnGamePassChangedEvent>(() => new OnGamePassChangedEvent());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnGamePassChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GameEventMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnGamePassChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnGamePassChangedEvent(OnGamePassChangedEvent other) : this() {
      eventId_ = other.eventId_;
      points_ = other.points_;
      levels_ = other.levels_.Clone();
      Reward = other.reward_ != null ? other.Reward.Clone() : null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnGamePassChangedEvent Clone() {
      return new OnGamePassChangedEvent(this);
    }

    public const int EventIdFieldNumber = 1;
    private string eventId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string EventId {
      get { return eventId_; }
      set {
        eventId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PointsFieldNumber = 2;
    private int points_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Points {
      get { return points_; }
      set {
        points_ = value;
      }
    }

    public const int LevelsFieldNumber = 3;
    private static readonly pbc::MapField<string, int>.Codec _map_levels_codec
        = new pbc::MapField<string, int>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForInt32(16), 26);
    private readonly pbc::MapField<string, int> levels_ = new pbc::MapField<string, int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, int> Levels {
      get { return levels_; }
    }

    public const int RewardFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.Reward reward_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Reward Reward {
      get { return reward_; }
      set {
        reward_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnGamePassChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnGamePassChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (EventId != other.EventId) return false;
      if (Points != other.Points) return false;
      if (!Levels.Equals(other.Levels)) return false;
      if (!object.Equals(Reward, other.Reward)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (EventId.Length != 0) hash ^= EventId.GetHashCode();
      if (Points != 0) hash ^= Points.GetHashCode();
      hash ^= Levels.GetHashCode();
      if (reward_ != null) hash ^= Reward.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (EventId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(EventId);
      }
      if (Points != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Points);
      }
      levels_.WriteTo(output, _map_levels_codec);
      if (reward_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (EventId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(EventId);
      }
      if (Points != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Points);
      }
      size += levels_.CalculateSize(_map_levels_codec);
      if (reward_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Reward);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnGamePassChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.EventId.Length != 0) {
        EventId = other.EventId;
      }
      if (other.Points != 0) {
        Points = other.Points;
      }
      levels_.Add(other.levels_);
      if (other.reward_ != null) {
        if (reward_ == null) {
          reward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
        }
        Reward.MergeFrom(other.Reward);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            EventId = input.ReadString();
            break;
          }
          case 16: {
            Points = input.ReadInt32();
            break;
          }
          case 26: {
            levels_.AddEntriesFrom(input, _map_levels_codec);
            break;
          }
          case 34: {
            if (reward_ == null) {
              reward_ = new global::Axlebolt.Bolt.Protobuf2.Reward();
            }
            input.ReadMessage(reward_);
            break;
          }
        }
      }
    }

  }


}

