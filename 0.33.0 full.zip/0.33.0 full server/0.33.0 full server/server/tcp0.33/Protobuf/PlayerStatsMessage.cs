#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class PlayerStatsMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static PlayerStatsMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChhQbGF5ZXJTdGF0c01lc3NhZ2UucHJvdG8SF0F4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyInUKBVN0YXRzEjEKBHN0YXQYASADKAsyIy5BeGxlYm9sdC5Cb2x0",
            "LlByb3RvYnVmMi5QbGF5ZXJTdGF0EjkKC2FjaGlldmVtZW50GAIgAygLMiQu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQWNoaWV2ZW1lbnQihAEKClBsYXll",
            "clN0YXQSDAoEbmFtZRgBIAEoCRIQCghpbnRWYWx1ZRgCIAEoBRISCgpmbG9h",
            "dFZhbHVlGAMgASgCEg4KBndpbmRvdxgEIAEoAhIyCgR0eXBlGAUgASgOMiQu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuU3RhdERlZlR5cGUilAEKC1BsYXll",
            "clN0YXRzEhAKCHBsYXllcklkGAEgASgJEjcKBXN0YXRzGAIgAygLMiguQXhs",
            "ZWJvbHQuQm9sdC5Qcm90b2J1ZjIuU3RvcmVQbGF5ZXJTdGF0EjoKDGFjaGll",
            "dmVtZW50cxgDIAMoCzIkLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkFjaGll",
            "dmVtZW50IpABCgtBY2hpZXZlbWVudBIMCgRuYW1lGAEgASgJEhMKC2Rpc3Bs",
            "YXlOYW1lGAIgASgJEhoKEmRpc3BsYXlEZXNjcmlwdGlvbhgDIAEoCRISCgp1",
            "bmxvY2tUaW1lGAQgASgDEhAKCGFjaGlldmVkGAUgASgIEgwKBGljb24YBiAB",
            "KAwSDgoGaGlkZGVuGAcgASgIIkUKD1N0b3JlUGxheWVyU3RhdBIMCgRuYW1l",
            "GAEgASgJEhAKCFN0b3JlSW50GAIgASgFEhIKClN0b3JlRmxvYXQYAyABKAIi",
            "MgoQU3RvcmVBY2hpZXZlbWVudBIMCgRuYW1lGAEgASgJEhAKCGFjaGlldmVk",
            "GAIgASgIKi4KC1N0YXREZWZUeXBlEgcKA0lOVBAAEgkKBUZMT0FUEAESCwoH",
            "QVZHUkFURRACYgZwcm90bzM="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.StatDefType), }, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Stats), global::Axlebolt.Bolt.Protobuf2.Stats.Parser, new[]{ "Stat", "Achievement" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayerStat), global::Axlebolt.Bolt.Protobuf2.PlayerStat.Parser, new[]{ "Name", "IntValue", "FloatValue", "Window", "Type" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayerStats), global::Axlebolt.Bolt.Protobuf2.PlayerStats.Parser, new[]{ "PlayerId", "Stats", "Achievements" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Achievement), global::Axlebolt.Bolt.Protobuf2.Achievement.Parser, new[]{ "Name", "DisplayName", "DisplayDescription", "UnlockTime", "Achieved", "Icon", "Hidden" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.StorePlayerStat), global::Axlebolt.Bolt.Protobuf2.StorePlayerStat.Parser, new[]{ "Name", "StoreInt", "StoreFloat" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.StoreAchievement), global::Axlebolt.Bolt.Protobuf2.StoreAchievement.Parser, new[]{ "Name", "Achieved" }, null, null, null)
          }));
    }

  }
  public enum StatDefType {
    [pbr::OriginalName("INT")] Int = 0,
    [pbr::OriginalName("FLOAT")] Float = 1,
    [pbr::OriginalName("AVGRATE")] Avgrate = 2,
  }


  public sealed partial class Stats : pb::IMessage<Stats> {
    private static readonly pb::MessageParser<Stats> _parser = new pb::MessageParser<Stats>(() => new Stats());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Stats> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Stats() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Stats(Stats other) : this() {
      stat_ = other.stat_.Clone();
      achievement_ = other.achievement_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Stats Clone() {
      return new Stats(this);
    }

    public const int StatFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.PlayerStat> _repeated_stat_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.PlayerStat.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerStat> stat_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerStat>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerStat> Stat {
      get { return stat_; }
    }

    public const int AchievementFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Achievement> _repeated_achievement_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.Achievement.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement> achievement_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement> Achievement {
      get { return achievement_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Stats);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Stats other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!stat_.Equals(other.stat_)) return false;
      if(!achievement_.Equals(other.achievement_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= stat_.GetHashCode();
      hash ^= achievement_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      stat_.WriteTo(output, _repeated_stat_codec);
      achievement_.WriteTo(output, _repeated_achievement_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += stat_.CalculateSize(_repeated_stat_codec);
      size += achievement_.CalculateSize(_repeated_achievement_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Stats other) {
      if (other == null) {
        return;
      }
      stat_.Add(other.stat_);
      achievement_.Add(other.achievement_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            stat_.AddEntriesFrom(input, _repeated_stat_codec);
            break;
          }
          case 18: {
            achievement_.AddEntriesFrom(input, _repeated_achievement_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class PlayerStat : pb::IMessage<PlayerStat> {
    private static readonly pb::MessageParser<PlayerStat> _parser = new pb::MessageParser<PlayerStat>(() => new PlayerStat());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayerStat> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStat() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStat(PlayerStat other) : this() {
      name_ = other.name_;
      intValue_ = other.intValue_;
      floatValue_ = other.floatValue_;
      window_ = other.window_;
      type_ = other.type_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStat Clone() {
      return new PlayerStat(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int IntValueFieldNumber = 2;
    private int intValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int IntValue {
      get { return intValue_; }
      set {
        intValue_ = value;
      }
    }

    public const int FloatValueFieldNumber = 3;
    private float floatValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float FloatValue {
      get { return floatValue_; }
      set {
        floatValue_ = value;
      }
    }

    public const int WindowFieldNumber = 4;
    private float window_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float Window {
      get { return window_; }
      set {
        window_ = value;
      }
    }

    public const int TypeFieldNumber = 5;
    private global::Axlebolt.Bolt.Protobuf2.StatDefType type_ = 0;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.StatDefType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayerStat);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayerStat other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (IntValue != other.IntValue) return false;
      if (FloatValue != other.FloatValue) return false;
      if (Window != other.Window) return false;
      if (Type != other.Type) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (IntValue != 0) hash ^= IntValue.GetHashCode();
      if (FloatValue != 0F) hash ^= FloatValue.GetHashCode();
      if (Window != 0F) hash ^= Window.GetHashCode();
      if (Type != 0) hash ^= Type.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (IntValue != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(FloatValue);
      }
      if (Window != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(Window);
      }
      if (Type != 0) {
        output.WriteRawTag(40);
        output.WriteEnum((int) Type);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (IntValue != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(IntValue);
      }
      if (FloatValue != 0F) {
        size += 1 + 4;
      }
      if (Window != 0F) {
        size += 1 + 4;
      }
      if (Type != 0) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayerStat other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.IntValue != 0) {
        IntValue = other.IntValue;
      }
      if (other.FloatValue != 0F) {
        FloatValue = other.FloatValue;
      }
      if (other.Window != 0F) {
        Window = other.Window;
      }
      if (other.Type != 0) {
        Type = other.Type;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            IntValue = input.ReadInt32();
            break;
          }
          case 29: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 37: {
            Window = input.ReadFloat();
            break;
          }
          case 40: {
            type_ = (global::Axlebolt.Bolt.Protobuf2.StatDefType) input.ReadEnum();
            break;
          }
        }
      }
    }

  }

  public sealed partial class PlayerStats : pb::IMessage<PlayerStats> {
    private static readonly pb::MessageParser<PlayerStats> _parser = new pb::MessageParser<PlayerStats>(() => new PlayerStats());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayerStats> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStats() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStats(PlayerStats other) : this() {
      playerId_ = other.playerId_;
      stats_ = other.stats_.Clone();
      achievements_ = other.achievements_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerStats Clone() {
      return new PlayerStats(this);
    }

    public const int PlayerIdFieldNumber = 1;
    private string playerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string PlayerId {
      get { return playerId_; }
      set {
        playerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StatsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.StorePlayerStat> _repeated_stats_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.StorePlayerStat.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.StorePlayerStat> stats_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.StorePlayerStat>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.StorePlayerStat> Stats {
      get { return stats_; }
    }

    public const int AchievementsFieldNumber = 3;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Achievement> _repeated_achievements_codec
        = pb::FieldCodec.ForMessage(26, global::Axlebolt.Bolt.Protobuf2.Achievement.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement> achievements_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Achievement> Achievements {
      get { return achievements_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayerStats);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayerStats other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (PlayerId != other.PlayerId) return false;
      if(!stats_.Equals(other.stats_)) return false;
      if(!achievements_.Equals(other.achievements_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (PlayerId.Length != 0) hash ^= PlayerId.GetHashCode();
      hash ^= stats_.GetHashCode();
      hash ^= achievements_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (PlayerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      stats_.WriteTo(output, _repeated_stats_codec);
      achievements_.WriteTo(output, _repeated_achievements_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (PlayerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PlayerId);
      }
      size += stats_.CalculateSize(_repeated_stats_codec);
      size += achievements_.CalculateSize(_repeated_achievements_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayerStats other) {
      if (other == null) {
        return;
      }
      if (other.PlayerId.Length != 0) {
        PlayerId = other.PlayerId;
      }
      stats_.Add(other.stats_);
      achievements_.Add(other.achievements_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            PlayerId = input.ReadString();
            break;
          }
          case 18: {
            stats_.AddEntriesFrom(input, _repeated_stats_codec);
            break;
          }
          case 26: {
            achievements_.AddEntriesFrom(input, _repeated_achievements_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class Achievement : pb::IMessage<Achievement> {
    private static readonly pb::MessageParser<Achievement> _parser = new pb::MessageParser<Achievement>(() => new Achievement());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Achievement> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Achievement() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Achievement(Achievement other) : this() {
      name_ = other.name_;
      displayName_ = other.displayName_;
      displayDescription_ = other.displayDescription_;
      unlockTime_ = other.unlockTime_;
      achieved_ = other.achieved_;
      icon_ = other.icon_;
      hidden_ = other.hidden_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Achievement Clone() {
      return new Achievement(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int DisplayNameFieldNumber = 2;
    private string displayName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string DisplayName {
      get { return displayName_; }
      set {
        displayName_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int DisplayDescriptionFieldNumber = 3;
    private string displayDescription_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string DisplayDescription {
      get { return displayDescription_; }
      set {
        displayDescription_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int UnlockTimeFieldNumber = 4;
    private long unlockTime_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long UnlockTime {
      get { return unlockTime_; }
      set {
        unlockTime_ = value;
      }
    }

    public const int AchievedFieldNumber = 5;
    private bool achieved_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Achieved {
      get { return achieved_; }
      set {
        achieved_ = value;
      }
    }

    public const int IconFieldNumber = 6;
    private pb::ByteString icon_ = pb::ByteString.Empty;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString Icon {
      get { return icon_; }
      set {
        icon_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int HiddenFieldNumber = 7;
    private bool hidden_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Hidden {
      get { return hidden_; }
      set {
        hidden_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Achievement);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Achievement other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (DisplayName != other.DisplayName) return false;
      if (DisplayDescription != other.DisplayDescription) return false;
      if (UnlockTime != other.UnlockTime) return false;
      if (Achieved != other.Achieved) return false;
      if (Icon != other.Icon) return false;
      if (Hidden != other.Hidden) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (DisplayName.Length != 0) hash ^= DisplayName.GetHashCode();
      if (DisplayDescription.Length != 0) hash ^= DisplayDescription.GetHashCode();
      if (UnlockTime != 0L) hash ^= UnlockTime.GetHashCode();
      if (Achieved != false) hash ^= Achieved.GetHashCode();
      if (Icon.Length != 0) hash ^= Icon.GetHashCode();
      if (Hidden != false) hash ^= Hidden.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (DisplayName.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(DisplayName);
      }
      if (DisplayDescription.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(DisplayDescription);
      }
      if (UnlockTime != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(UnlockTime);
      }
      if (Achieved != false) {
        output.WriteRawTag(40);
        output.WriteBool(Achieved);
      }
      if (Icon.Length != 0) {
        output.WriteRawTag(50);
        output.WriteBytes(Icon);
      }
      if (Hidden != false) {
        output.WriteRawTag(56);
        output.WriteBool(Hidden);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (DisplayName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(DisplayName);
      }
      if (DisplayDescription.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(DisplayDescription);
      }
      if (UnlockTime != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(UnlockTime);
      }
      if (Achieved != false) {
        size += 1 + 1;
      }
      if (Icon.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(Icon);
      }
      if (Hidden != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Achievement other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.DisplayName.Length != 0) {
        DisplayName = other.DisplayName;
      }
      if (other.DisplayDescription.Length != 0) {
        DisplayDescription = other.DisplayDescription;
      }
      if (other.UnlockTime != 0L) {
        UnlockTime = other.UnlockTime;
      }
      if (other.Achieved != false) {
        Achieved = other.Achieved;
      }
      if (other.Icon.Length != 0) {
        Icon = other.Icon;
      }
      if (other.Hidden != false) {
        Hidden = other.Hidden;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 18: {
            DisplayName = input.ReadString();
            break;
          }
          case 26: {
            DisplayDescription = input.ReadString();
            break;
          }
          case 32: {
            UnlockTime = input.ReadInt64();
            break;
          }
          case 40: {
            Achieved = input.ReadBool();
            break;
          }
          case 50: {
            Icon = input.ReadBytes();
            break;
          }
          case 56: {
            Hidden = input.ReadBool();
            break;
          }
        }
      }
    }

  }

  public sealed partial class StorePlayerStat : pb::IMessage<StorePlayerStat> {
    private static readonly pb::MessageParser<StorePlayerStat> _parser = new pb::MessageParser<StorePlayerStat>(() => new StorePlayerStat());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<StorePlayerStat> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StorePlayerStat() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StorePlayerStat(StorePlayerStat other) : this() {
      name_ = other.name_;
      storeInt_ = other.storeInt_;
      storeFloat_ = other.storeFloat_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StorePlayerStat Clone() {
      return new StorePlayerStat(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StoreIntFieldNumber = 2;
    private int storeInt_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int StoreInt {
      get { return storeInt_; }
      set {
        storeInt_ = value;
      }
    }

    public const int StoreFloatFieldNumber = 3;
    private float storeFloat_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float StoreFloat {
      get { return storeFloat_; }
      set {
        storeFloat_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as StorePlayerStat);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(StorePlayerStat other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (StoreInt != other.StoreInt) return false;
      if (StoreFloat != other.StoreFloat) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (StoreInt != 0) hash ^= StoreInt.GetHashCode();
      if (StoreFloat != 0F) hash ^= StoreFloat.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (StoreInt != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(StoreInt);
      }
      if (StoreFloat != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(StoreFloat);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (StoreInt != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(StoreInt);
      }
      if (StoreFloat != 0F) {
        size += 1 + 4;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(StorePlayerStat other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.StoreInt != 0) {
        StoreInt = other.StoreInt;
      }
      if (other.StoreFloat != 0F) {
        StoreFloat = other.StoreFloat;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            StoreInt = input.ReadInt32();
            break;
          }
          case 29: {
            StoreFloat = input.ReadFloat();
            break;
          }
        }
      }
    }

  }

  public sealed partial class StoreAchievement : pb::IMessage<StoreAchievement> {
    private static readonly pb::MessageParser<StoreAchievement> _parser = new pb::MessageParser<StoreAchievement>(() => new StoreAchievement());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<StoreAchievement> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.PlayerStatsMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StoreAchievement() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StoreAchievement(StoreAchievement other) : this() {
      name_ = other.name_;
      achieved_ = other.achieved_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public StoreAchievement Clone() {
      return new StoreAchievement(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AchievedFieldNumber = 2;
    private bool achieved_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Achieved {
      get { return achieved_; }
      set {
        achieved_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as StoreAchievement);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(StoreAchievement other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (Achieved != other.Achieved) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (Achieved != false) hash ^= Achieved.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (Achieved != false) {
        output.WriteRawTag(16);
        output.WriteBool(Achieved);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (Achieved != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(StoreAchievement other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.Achieved != false) {
        Achieved = other.Achieved;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            Achieved = input.ReadBool();
            break;
          }
        }
      }
    }

  }


}

