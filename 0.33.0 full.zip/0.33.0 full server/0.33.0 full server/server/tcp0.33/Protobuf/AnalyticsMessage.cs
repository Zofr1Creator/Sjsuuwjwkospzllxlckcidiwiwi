#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class AnalyticsMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static AnalyticsMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChZBbmFseXRpY3NNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMiJkCglVc2VyRXZlbnQSEAoIY2F0ZWdvcnkYASABKAkSDQoFZXZlbnQY",
            "AiABKAkSDQoFdmFsdWUYAyABKAUSEQoJaW5jcmVtZW50GAQgASgIEhQKDHN0",
            "b3JlQ291bnRyeRgFIAEoCGIGcHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.UserEvent), global::Axlebolt.Bolt.Protobuf2.UserEvent.Parser, new[]{ "Category", "Event", "Value", "Increment", "StoreCountry" }, null, null, null)
          }));
    }

  }
  public sealed partial class UserEvent : pb::IMessage<UserEvent> {
    private static readonly pb::MessageParser<UserEvent> _parser = new pb::MessageParser<UserEvent>(() => new UserEvent());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<UserEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AnalyticsMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserEvent(UserEvent other) : this() {
      category_ = other.category_;
      event_ = other.event_;
      value_ = other.value_;
      increment_ = other.increment_;
      storeCountry_ = other.storeCountry_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserEvent Clone() {
      return new UserEvent(this);
    }

    public const int CategoryFieldNumber = 1;
    private string category_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Category {
      get { return category_; }
      set {
        category_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int EventFieldNumber = 2;
    private string event_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Event {
      get { return event_; }
      set {
        event_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ValueFieldNumber = 3;
    private int value_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Value {
      get { return value_; }
      set {
        value_ = value;
      }
    }

    public const int IncrementFieldNumber = 4;
    private bool increment_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Increment {
      get { return increment_; }
      set {
        increment_ = value;
      }
    }

    public const int StoreCountryFieldNumber = 5;
    private bool storeCountry_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool StoreCountry {
      get { return storeCountry_; }
      set {
        storeCountry_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as UserEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(UserEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Category != other.Category) return false;
      if (Event != other.Event) return false;
      if (Value != other.Value) return false;
      if (Increment != other.Increment) return false;
      if (StoreCountry != other.StoreCountry) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Category.Length != 0) hash ^= Category.GetHashCode();
      if (Event.Length != 0) hash ^= Event.GetHashCode();
      if (Value != 0) hash ^= Value.GetHashCode();
      if (Increment != false) hash ^= Increment.GetHashCode();
      if (StoreCountry != false) hash ^= StoreCountry.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Category.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Category);
      }
      if (Event.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Event);
      }
      if (Value != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Value);
      }
      if (Increment != false) {
        output.WriteRawTag(32);
        output.WriteBool(Increment);
      }
      if (StoreCountry != false) {
        output.WriteRawTag(40);
        output.WriteBool(StoreCountry);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Category.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Category);
      }
      if (Event.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Event);
      }
      if (Value != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Value);
      }
      if (Increment != false) {
        size += 1 + 1;
      }
      if (StoreCountry != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(UserEvent other) {
      if (other == null) {
        return;
      }
      if (other.Category.Length != 0) {
        Category = other.Category;
      }
      if (other.Event.Length != 0) {
        Event = other.Event;
      }
      if (other.Value != 0) {
        Value = other.Value;
      }
      if (other.Increment != false) {
        Increment = other.Increment;
      }
      if (other.StoreCountry != false) {
        StoreCountry = other.StoreCountry;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Category = input.ReadString();
            break;
          }
          case 18: {
            Event = input.ReadString();
            break;
          }
          case 24: {
            Value = input.ReadInt32();
            break;
          }
          case 32: {
            Increment = input.ReadBool();
            break;
          }
          case 40: {
            StoreCountry = input.ReadBool();
            break;
          }
        }
      }
    }

  }


}

