#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class InventoryMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static InventoryMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChZJbnZlbnRvcnlNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMhoVQ3VycmVuY3lNZXNzYWdlLnByb3RvIo4BCg9QbGF5ZXJJbnZlbnRv",
            "cnkSOwoKY3VycmVuY2llcxgBIAMoCzInLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLkN1cnJlbmN5QW1vdW50Ej4KDmludmVudG9yeUl0ZW1zGAIgAygLMiYu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuSW52ZW50b3J5SXRlbSKTAgoNSW52",
            "ZW50b3J5SXRlbRIKCgJpZBgBIAEoBRIYChBpdGVtRGVmaW5pdGlvbklkGAIg",
            "ASgFEhAKCHF1YW50aXR5GAMgASgFEg0KBWZsYWdzGAQgASgFEgwKBGRhdGUY",
            "BSABKAMSSgoKcHJvcGVydGllcxgGIAMoCzI2LkF4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyLkludmVudG9yeUl0ZW0uUHJvcGVydGllc0VudHJ5GmEKD1Byb3Bl",
            "cnRpZXNFbnRyeRILCgNrZXkYASABKAkSPQoFdmFsdWUYAiABKAsyLi5BeGxl",
            "Ym9sdC5Cb2x0LlByb3RvYnVmMi5JbnZlbnRvcnlJdGVtUHJvcGVydHk6AjgB",
            "Is8CChdJbnZlbnRvcnlJdGVtRGVmaW5pdGlvbhIKCgJpZBgBIAEoBRITCgtk",
            "aXNwbGF5TmFtZRgCIAEoCRJUCgpwcm9wZXJ0aWVzGAMgAygLMkAuQXhsZWJv",
            "bHQuQm9sdC5Qcm90b2J1ZjIuSW52ZW50b3J5SXRlbURlZmluaXRpb24uUHJv",
            "cGVydGllc0VudHJ5EjkKCGJ1eVByaWNlGAQgAygLMicuQXhsZWJvbHQuQm9s",
            "dC5Qcm90b2J1ZjIuQ3VycmVuY3lBbW91bnQSOgoJc2VsbFByaWNlGAUgAygL",
            "MicuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ3VycmVuY3lBbW91bnQSEwoL",
            "Y2FuQmVUcmFkZWQYBiABKAgaMQoPUHJvcGVydGllc0VudHJ5EgsKA2tleRgB",
            "IAEoCRINCgV2YWx1ZRgCIAEoCToCOAEiiwIKIEludmVudG9yeUl0ZW1Qcm9w",
            "ZXJ0eURlZmluaXRpb25zEhgKEGl0ZW1EZWZpbml0aW9uSWQYASABKAUSXwoL",
            "ZGVmaW5pdGlvbnMYAiADKAsySi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5J",
            "bnZlbnRvcnlJdGVtUHJvcGVydHlEZWZpbml0aW9ucy5EZWZpbml0aW9uc0Vu",
            "dHJ5GmwKEERlZmluaXRpb25zRW50cnkSCwoDa2V5GAEgASgJEkcKBXZhbHVl",
            "GAIgASgLMjguQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuSW52ZW50b3J5SXRl",
            "bVByb3BlcnR5RGVmaW5pdGlvbjoCOAEiwAEKH0ludmVudG9yeUl0ZW1Qcm9w",
            "ZXJ0eURlZmluaXRpb24SDAoEbmFtZRgBIAEoCRI7Cgxwcm9wZXJ0eVR5cGUY",
            "AiABKA4yJS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Qcm9wZXJ0eVR5cGUS",
            "EwoLc2F2ZUluVHJhZGUYAyABKAgSPQoJc2V0QnlUeXBlGAQgASgOMiouQXhs",
            "ZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUHJvcGVydHlTZXRCeVR5cGUiRwoTSW52",
            "ZW50b3J5SXRlbUFtb3VudBIhChlpbnZlbnRvcnlJdGVtRGVmaW5pdGlvbklk",
            "GAEgASgFEg0KBXZhbHVlGAIgASgFIo0BCg5FeGNoYW5nZVJlc3VsdBI7Cgpj",
            "dXJyZW5jaWVzGAEgAygLMicuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ3Vy",
            "cmVuY3lBbW91bnQSPgoOaW52ZW50b3J5SXRlbXMYAiADKAsyJi5BeGxlYm9s",
            "dC5Cb2x0LlByb3RvYnVmMi5JbnZlbnRvcnlJdGVtImkKF0ludmVudG9yeUl0",
            "ZW1Qcm9wZXJ0eWVzEgoKAmlkGAEgASgFEkIKCnByb3BlcnRpZXMYAiADKAsy",
            "Li5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5JbnZlbnRvcnlJdGVtUHJvcGVy",
            "dHkinQEKFUludmVudG9yeUl0ZW1Qcm9wZXJ0eRIzCgR0eXBlGAEgASgOMiUu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUHJvcGVydHlUeXBlEhAKCGludFZh",
            "bHVlGAIgASgFEhIKCmZsb2F0VmFsdWUYAyABKAISEwoLc3RyaW5nVmFsdWUY",
            "BCABKAkSFAoMYm9vbGVhblZhbHVlGAUgASgIIt4BChdJbnZlbnRvcnlJdGVt",
            "UHJvcGVydGllcxIKCgJpZBgBIAEoBRJUCgpwcm9wZXJ0aWVzGAIgAygLMkAu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuSW52ZW50b3J5SXRlbVByb3BlcnRp",
            "ZXMuUHJvcGVydGllc0VudHJ5GmEKD1Byb3BlcnRpZXNFbnRyeRILCgNrZXkY",
            "ASABKAkSPQoFdmFsdWUYAiABKAsyLi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVm",
            "Mi5JbnZlbnRvcnlJdGVtUHJvcGVydHk6AjgBIncKCUl0ZW1GbGFncxI8CgVm",
            "bGFncxgBIAMoCzItLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkl0ZW1GbGFn",
            "cy5GbGFnc0VudHJ5GiwKCkZsYWdzRW50cnkSCwoDa2V5GAEgASgFEg0KBXZh",
            "bHVlGAIgASgFOgI4ASJXCgpSZWNpcGVJbmZvEg4KBnJlY2lwZRgBIAEoCRI5",
            "CghlbnRpdGllcxgCIAMoCzInLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkV4",
            "Y2hhbmdlRW50aXR5IpMBCg5FeGNoYW5nZUVudGl0eRJECg5pbnZlbnRvcnlJ",
            "dGVtcxgBIAMoCzIsLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkludmVudG9y",
            "eUl0ZW1BbW91bnQSOwoKY3VycmVuY2llcxgCIAMoCzInLkF4bGVib2x0LkJv",
            "bHQuUHJvdG9idWYyLkN1cnJlbmN5QW1vdW50IrwBCgpSZXdhcmRJbmZvEjsK",
            "BWl0ZW1zGAEgAygLMiwuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuSW52ZW50",
            "b3J5SXRlbUFtb3VudBI7CgpjdXJyZW5jaWVzGAIgAygLMicuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuQ3VycmVuY3lBbW91bnQSNAoHcmVjaXBlcxgDIAMo",
            "CzIjLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlJlY2lwZUluZm8ifAoGUmV3",
            "YXJkEjUKBWl0ZW1zGAEgAygLMiYuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIu",
            "SW52ZW50b3J5SXRlbRI7CgpjdXJyZW5jaWVzGAIgAygLMicuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuQ3VycmVuY3lBbW91bnQqSAoJU3RvcmVDb2RlEhQK",
            "EEdPT0dMX1BMQVlfU1RPUkUQABITCg9BUFBMRV9BUFBfU1RPUkUQARIQCgxB",
            "TUFaT05fU1RPUkUQAio7CgxQcm9wZXJ0eVR5cGUSBwoDSU5UEAASCQoFRkxP",
            "QVQQARIKCgZTVFJJTkcQAhILCgdCT09MRUFOEAMqSQoRUHJvcGVydHlTZXRC",
            "eVR5cGUSDwoLR0FNRV9TRVJWRVIQABIXChNPRkZJQ0FMX0dBTUVfU0VSVkVS",
            "EAESCgoGQ0xJRU5UEAJiBnByb3RvMw=="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.StoreCode), typeof(global::Axlebolt.Bolt.Protobuf2.PropertyType), typeof(global::Axlebolt.Bolt.Protobuf2.PropertySetByType), }, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayerInventory), global::Axlebolt.Bolt.Protobuf2.PlayerInventory.Parser, new[]{ "Currencies", "InventoryItems" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItem), global::Axlebolt.Bolt.Protobuf2.InventoryItem.Parser, new[]{ "Id", "ItemDefinitionId", "Quantity", "Flags", "Date", "Properties" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemDefinition), global::Axlebolt.Bolt.Protobuf2.InventoryItemDefinition.Parser, new[]{ "Id", "DisplayName", "Properties", "BuyPrice", "SellPrice", "CanBeTraded" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinitions), global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinitions.Parser, new[]{ "ItemDefinitionId", "Definitions" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition), global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition.Parser, new[]{ "Name", "PropertyType", "SaveInTrade", "SetByType" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount), global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount.Parser, new[]{ "InventoryItemDefinitionId", "Value" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ExchangeResult), global::Axlebolt.Bolt.Protobuf2.ExchangeResult.Parser, new[]{ "Currencies", "InventoryItems" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyes), global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyes.Parser, new[]{ "Id", "Properties" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty), global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser, new[]{ "Type", "IntValue", "FloatValue", "StringValue", "BooleanValue" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InventoryItemProperties), global::Axlebolt.Bolt.Protobuf2.InventoryItemProperties.Parser, new[]{ "Id", "Properties" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ItemFlags), global::Axlebolt.Bolt.Protobuf2.ItemFlags.Parser, new[]{ "Flags" }, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RecipeInfo), global::Axlebolt.Bolt.Protobuf2.RecipeInfo.Parser, new[]{ "Recipe", "Entities" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ExchangeEntity), global::Axlebolt.Bolt.Protobuf2.ExchangeEntity.Parser, new[]{ "InventoryItems", "Currencies" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RewardInfo), global::Axlebolt.Bolt.Protobuf2.RewardInfo.Parser, new[]{ "Items", "Currencies", "Recipes" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Reward), global::Axlebolt.Bolt.Protobuf2.Reward.Parser, new[]{ "Items", "Currencies" }, null, null, null)
          }));
    }

  }
  public enum StoreCode {
    [pbr::OriginalName("GOOGL_PLAY_STORE")] GooglPlayStore = 0,
    [pbr::OriginalName("APPLE_APP_STORE")] AppleAppStore = 1,
    [pbr::OriginalName("AMAZON_STORE")] AmazonStore = 2,
  }

  public enum PropertyType {
    [pbr::OriginalName("INT")] Int = 0,
    [pbr::OriginalName("FLOAT")] Float = 1,
    [pbr::OriginalName("STRING")] String = 2,
    [pbr::OriginalName("BOOLEAN")] Boolean = 3,
  }

  public enum PropertySetByType {
    [pbr::OriginalName("GAME_SERVER")] GameServer = 0,
    [pbr::OriginalName("OFFICAL_GAME_SERVER")] OfficalGameServer = 1,
    [pbr::OriginalName("CLIENT")] Client = 2,
  }


  public sealed partial class PlayerInventory : pb::IMessage<PlayerInventory> {
    private static readonly pb::MessageParser<PlayerInventory> _parser = new pb::MessageParser<PlayerInventory>(() => new PlayerInventory());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayerInventory> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerInventory() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerInventory(PlayerInventory other) : this() {
      currencies_ = other.currencies_.Clone();
      inventoryItems_ = other.inventoryItems_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerInventory Clone() {
      return new PlayerInventory(this);
    }

    public const int CurrenciesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_currencies_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> currencies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> Currencies {
      get { return currencies_; }
    }

    public const int InventoryItemsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItem> _repeated_inventoryItems_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItem.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> inventoryItems_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> InventoryItems {
      get { return inventoryItems_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayerInventory);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayerInventory other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!currencies_.Equals(other.currencies_)) return false;
      if(!inventoryItems_.Equals(other.inventoryItems_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= currencies_.GetHashCode();
      hash ^= inventoryItems_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      currencies_.WriteTo(output, _repeated_currencies_codec);
      inventoryItems_.WriteTo(output, _repeated_inventoryItems_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += currencies_.CalculateSize(_repeated_currencies_codec);
      size += inventoryItems_.CalculateSize(_repeated_inventoryItems_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayerInventory other) {
      if (other == null) {
        return;
      }
      currencies_.Add(other.currencies_);
      inventoryItems_.Add(other.inventoryItems_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            currencies_.AddEntriesFrom(input, _repeated_currencies_codec);
            break;
          }
          case 18: {
            inventoryItems_.AddEntriesFrom(input, _repeated_inventoryItems_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItem : pb::IMessage<InventoryItem> {
    private static readonly pb::MessageParser<InventoryItem> _parser = new pb::MessageParser<InventoryItem>(() => new InventoryItem());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItem> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItem() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItem(InventoryItem other) : this() {
      id_ = other.id_;
      itemDefinitionId_ = other.itemDefinitionId_;
      quantity_ = other.quantity_;
      flags_ = other.flags_;
      date_ = other.date_;
      properties_ = other.properties_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItem Clone() {
      return new InventoryItem(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int ItemDefinitionIdFieldNumber = 2;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int QuantityFieldNumber = 3;
    private int quantity_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Quantity {
      get { return quantity_; }
      set {
        quantity_ = value;
      }
    }

    public const int FlagsFieldNumber = 4;
    private int flags_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Flags {
      get { return flags_; }
      set {
        flags_ = value;
      }
    }

    public const int DateFieldNumber = 5;
    private long date_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Date {
      get { return date_; }
      set {
        date_ = value;
      }
    }

    public const int PropertiesFieldNumber = 6;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec _map_properties_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser), 50);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItem);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItem other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (Quantity != other.Quantity) return false;
      if (Flags != other.Flags) return false;
      if (Date != other.Date) return false;
      if (!Properties.Equals(other.Properties)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      if (Quantity != 0) hash ^= Quantity.GetHashCode();
      if (Flags != 0) hash ^= Flags.GetHashCode();
      if (Date != 0L) hash ^= Date.GetHashCode();
      hash ^= Properties.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Quantity != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Quantity);
      }
      if (Flags != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(Flags);
      }
      if (Date != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(Date);
      }
      properties_.WriteTo(output, _map_properties_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      if (Quantity != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Quantity);
      }
      if (Flags != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Flags);
      }
      if (Date != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Date);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItem other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      if (other.Quantity != 0) {
        Quantity = other.Quantity;
      }
      if (other.Flags != 0) {
        Flags = other.Flags;
      }
      if (other.Date != 0L) {
        Date = other.Date;
      }
      properties_.Add(other.properties_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 24: {
            Quantity = input.ReadInt32();
            break;
          }
          case 32: {
            Flags = input.ReadInt32();
            break;
          }
          case 40: {
            Date = input.ReadInt64();
            break;
          }
          case 50: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemDefinition : pb::IMessage<InventoryItemDefinition> {
    private static readonly pb::MessageParser<InventoryItemDefinition> _parser = new pb::MessageParser<InventoryItemDefinition>(() => new InventoryItemDefinition());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemDefinition> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemDefinition() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemDefinition(InventoryItemDefinition other) : this() {
      id_ = other.id_;
      displayName_ = other.displayName_;
      properties_ = other.properties_.Clone();
      buyPrice_ = other.buyPrice_.Clone();
      sellPrice_ = other.sellPrice_.Clone();
      canBeTraded_ = other.canBeTraded_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemDefinition Clone() {
      return new InventoryItemDefinition(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int DisplayNameFieldNumber = 2;
    private string displayName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string DisplayName {
      get { return displayName_; }
      set {
        displayName_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PropertiesFieldNumber = 3;
    private static readonly pbc::MapField<string, string>.Codec _map_properties_codec
        = new pbc::MapField<string, string>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForString(18), 26);
    private readonly pbc::MapField<string, string> properties_ = new pbc::MapField<string, string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, string> Properties {
      get { return properties_; }
    }

    public const int BuyPriceFieldNumber = 4;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_buyPrice_codec
        = pb::FieldCodec.ForMessage(34, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> buyPrice_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> BuyPrice {
      get { return buyPrice_; }
    }

    public const int SellPriceFieldNumber = 5;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_sellPrice_codec
        = pb::FieldCodec.ForMessage(42, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> sellPrice_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> SellPrice {
      get { return sellPrice_; }
    }

    public const int CanBeTradedFieldNumber = 6;
    private bool canBeTraded_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool CanBeTraded {
      get { return canBeTraded_; }
      set {
        canBeTraded_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemDefinition);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemDefinition other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (DisplayName != other.DisplayName) return false;
      if (!Properties.Equals(other.Properties)) return false;
      if(!buyPrice_.Equals(other.buyPrice_)) return false;
      if(!sellPrice_.Equals(other.sellPrice_)) return false;
      if (CanBeTraded != other.CanBeTraded) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (DisplayName.Length != 0) hash ^= DisplayName.GetHashCode();
      hash ^= Properties.GetHashCode();
      hash ^= buyPrice_.GetHashCode();
      hash ^= sellPrice_.GetHashCode();
      if (CanBeTraded != false) hash ^= CanBeTraded.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (DisplayName.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(DisplayName);
      }
      properties_.WriteTo(output, _map_properties_codec);
      buyPrice_.WriteTo(output, _repeated_buyPrice_codec);
      sellPrice_.WriteTo(output, _repeated_sellPrice_codec);
      if (CanBeTraded != false) {
        output.WriteRawTag(48);
        output.WriteBool(CanBeTraded);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (DisplayName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(DisplayName);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      size += buyPrice_.CalculateSize(_repeated_buyPrice_codec);
      size += sellPrice_.CalculateSize(_repeated_sellPrice_codec);
      if (CanBeTraded != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemDefinition other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.DisplayName.Length != 0) {
        DisplayName = other.DisplayName;
      }
      properties_.Add(other.properties_);
      buyPrice_.Add(other.buyPrice_);
      sellPrice_.Add(other.sellPrice_);
      if (other.CanBeTraded != false) {
        CanBeTraded = other.CanBeTraded;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 18: {
            DisplayName = input.ReadString();
            break;
          }
          case 26: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
          case 34: {
            buyPrice_.AddEntriesFrom(input, _repeated_buyPrice_codec);
            break;
          }
          case 42: {
            sellPrice_.AddEntriesFrom(input, _repeated_sellPrice_codec);
            break;
          }
          case 48: {
            CanBeTraded = input.ReadBool();
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemPropertyDefinitions : pb::IMessage<InventoryItemPropertyDefinitions> {
    private static readonly pb::MessageParser<InventoryItemPropertyDefinitions> _parser = new pb::MessageParser<InventoryItemPropertyDefinitions>(() => new InventoryItemPropertyDefinitions());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemPropertyDefinitions> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinitions() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinitions(InventoryItemPropertyDefinitions other) : this() {
      itemDefinitionId_ = other.itemDefinitionId_;
      definitions_ = other.definitions_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinitions Clone() {
      return new InventoryItemPropertyDefinitions(this);
    }

    public const int ItemDefinitionIdFieldNumber = 1;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int DefinitionsFieldNumber = 2;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition>.Codec _map_definitions_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition.Parser), 18);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition> definitions_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemPropertyDefinition> Definitions {
      get { return definitions_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemPropertyDefinitions);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemPropertyDefinitions other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (!Definitions.Equals(other.Definitions)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      hash ^= Definitions.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemDefinitionId);
      }
      definitions_.WriteTo(output, _map_definitions_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      size += definitions_.CalculateSize(_map_definitions_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemPropertyDefinitions other) {
      if (other == null) {
        return;
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      definitions_.Add(other.definitions_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 18: {
            definitions_.AddEntriesFrom(input, _map_definitions_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemPropertyDefinition : pb::IMessage<InventoryItemPropertyDefinition> {
    private static readonly pb::MessageParser<InventoryItemPropertyDefinition> _parser = new pb::MessageParser<InventoryItemPropertyDefinition>(() => new InventoryItemPropertyDefinition());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemPropertyDefinition> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinition() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinition(InventoryItemPropertyDefinition other) : this() {
      name_ = other.name_;
      propertyType_ = other.propertyType_;
      saveInTrade_ = other.saveInTrade_;
      setByType_ = other.setByType_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyDefinition Clone() {
      return new InventoryItemPropertyDefinition(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PropertyTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PropertyType propertyType_ = 0;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PropertyType PropertyType {
      get { return propertyType_; }
      set {
        propertyType_ = value;
      }
    }

    public const int SaveInTradeFieldNumber = 3;
    private bool saveInTrade_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool SaveInTrade {
      get { return saveInTrade_; }
      set {
        saveInTrade_ = value;
      }
    }

    public const int SetByTypeFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.PropertySetByType setByType_ = 0;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PropertySetByType SetByType {
      get { return setByType_; }
      set {
        setByType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemPropertyDefinition);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemPropertyDefinition other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (PropertyType != other.PropertyType) return false;
      if (SaveInTrade != other.SaveInTrade) return false;
      if (SetByType != other.SetByType) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (PropertyType != 0) hash ^= PropertyType.GetHashCode();
      if (SaveInTrade != false) hash ^= SaveInTrade.GetHashCode();
      if (SetByType != 0) hash ^= SetByType.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (PropertyType != 0) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PropertyType);
      }
      if (SaveInTrade != false) {
        output.WriteRawTag(24);
        output.WriteBool(SaveInTrade);
      }
      if (SetByType != 0) {
        output.WriteRawTag(32);
        output.WriteEnum((int) SetByType);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (PropertyType != 0) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PropertyType);
      }
      if (SaveInTrade != false) {
        size += 1 + 1;
      }
      if (SetByType != 0) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) SetByType);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemPropertyDefinition other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.PropertyType != 0) {
        PropertyType = other.PropertyType;
      }
      if (other.SaveInTrade != false) {
        SaveInTrade = other.SaveInTrade;
      }
      if (other.SetByType != 0) {
        SetByType = other.SetByType;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            propertyType_ = (global::Axlebolt.Bolt.Protobuf2.PropertyType) input.ReadEnum();
            break;
          }
          case 24: {
            SaveInTrade = input.ReadBool();
            break;
          }
          case 32: {
            setByType_ = (global::Axlebolt.Bolt.Protobuf2.PropertySetByType) input.ReadEnum();
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemAmount : pb::IMessage<InventoryItemAmount> {
    private static readonly pb::MessageParser<InventoryItemAmount> _parser = new pb::MessageParser<InventoryItemAmount>(() => new InventoryItemAmount());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemAmount> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemAmount() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemAmount(InventoryItemAmount other) : this() {
      inventoryItemDefinitionId_ = other.inventoryItemDefinitionId_;
      value_ = other.value_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemAmount Clone() {
      return new InventoryItemAmount(this);
    }

    public const int InventoryItemDefinitionIdFieldNumber = 1;
    private int inventoryItemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int InventoryItemDefinitionId {
      get { return inventoryItemDefinitionId_; }
      set {
        inventoryItemDefinitionId_ = value;
      }
    }

    public const int ValueFieldNumber = 2;
    private int value_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Value {
      get { return value_; }
      set {
        value_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemAmount);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemAmount other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InventoryItemDefinitionId != other.InventoryItemDefinitionId) return false;
      if (Value != other.Value) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InventoryItemDefinitionId != 0) hash ^= InventoryItemDefinitionId.GetHashCode();
      if (Value != 0) hash ^= Value.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (InventoryItemDefinitionId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(InventoryItemDefinitionId);
      }
      if (Value != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Value);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InventoryItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(InventoryItemDefinitionId);
      }
      if (Value != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Value);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemAmount other) {
      if (other == null) {
        return;
      }
      if (other.InventoryItemDefinitionId != 0) {
        InventoryItemDefinitionId = other.InventoryItemDefinitionId;
      }
      if (other.Value != 0) {
        Value = other.Value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            InventoryItemDefinitionId = input.ReadInt32();
            break;
          }
          case 16: {
            Value = input.ReadInt32();
            break;
          }
        }
      }
    }

  }

  public sealed partial class ExchangeResult : pb::IMessage<ExchangeResult> {
    private static readonly pb::MessageParser<ExchangeResult> _parser = new pb::MessageParser<ExchangeResult>(() => new ExchangeResult());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ExchangeResult> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeResult() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeResult(ExchangeResult other) : this() {
      currencies_ = other.currencies_.Clone();
      inventoryItems_ = other.inventoryItems_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeResult Clone() {
      return new ExchangeResult(this);
    }

    public const int CurrenciesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_currencies_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> currencies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> Currencies {
      get { return currencies_; }
    }

    public const int InventoryItemsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItem> _repeated_inventoryItems_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItem.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> inventoryItems_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> InventoryItems {
      get { return inventoryItems_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ExchangeResult);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ExchangeResult other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!currencies_.Equals(other.currencies_)) return false;
      if(!inventoryItems_.Equals(other.inventoryItems_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= currencies_.GetHashCode();
      hash ^= inventoryItems_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      currencies_.WriteTo(output, _repeated_currencies_codec);
      inventoryItems_.WriteTo(output, _repeated_inventoryItems_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += currencies_.CalculateSize(_repeated_currencies_codec);
      size += inventoryItems_.CalculateSize(_repeated_inventoryItems_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ExchangeResult other) {
      if (other == null) {
        return;
      }
      currencies_.Add(other.currencies_);
      inventoryItems_.Add(other.inventoryItems_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            currencies_.AddEntriesFrom(input, _repeated_currencies_codec);
            break;
          }
          case 18: {
            inventoryItems_.AddEntriesFrom(input, _repeated_inventoryItems_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemPropertyes : pb::IMessage<InventoryItemPropertyes> {
    private static readonly pb::MessageParser<InventoryItemPropertyes> _parser = new pb::MessageParser<InventoryItemPropertyes>(() => new InventoryItemPropertyes());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemPropertyes> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyes() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyes(InventoryItemPropertyes other) : this() {
      id_ = other.id_;
      properties_ = other.properties_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemPropertyes Clone() {
      return new InventoryItemPropertyes(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int PropertiesFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> _repeated_properties_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemPropertyes);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemPropertyes other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if(!properties_.Equals(other.properties_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      hash ^= properties_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      properties_.WriteTo(output, _repeated_properties_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      size += properties_.CalculateSize(_repeated_properties_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemPropertyes other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      properties_.Add(other.properties_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 18: {
            properties_.AddEntriesFrom(input, _repeated_properties_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemProperty : pb::IMessage<InventoryItemProperty> {
    private static readonly pb::MessageParser<InventoryItemProperty> _parser = new pb::MessageParser<InventoryItemProperty>(() => new InventoryItemProperty());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemProperty> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperty() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperty(InventoryItemProperty other) : this() {
      type_ = other.type_;
      intValue_ = other.intValue_;
      floatValue_ = other.floatValue_;
      stringValue_ = other.stringValue_;
      booleanValue_ = other.booleanValue_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperty Clone() {
      return new InventoryItemProperty(this);
    }

    public const int TypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PropertyType type_ = 0;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PropertyType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int IntValueFieldNumber = 2;
    private int intValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int IntValue {
      get { return intValue_; }
      set {
        intValue_ = value;
      }
    }

    public const int FloatValueFieldNumber = 3;
    private float floatValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float FloatValue {
      get { return floatValue_; }
      set {
        floatValue_ = value;
      }
    }

    public const int StringValueFieldNumber = 4;
    private string stringValue_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string StringValue {
      get { return stringValue_; }
      set {
        stringValue_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int BooleanValueFieldNumber = 5;
    private bool booleanValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool BooleanValue {
      get { return booleanValue_; }
      set {
        booleanValue_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemProperty);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemProperty other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Type != other.Type) return false;
      if (IntValue != other.IntValue) return false;
      if (FloatValue != other.FloatValue) return false;
      if (StringValue != other.StringValue) return false;
      if (BooleanValue != other.BooleanValue) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Type != 0) hash ^= Type.GetHashCode();
      if (IntValue != 0) hash ^= IntValue.GetHashCode();
      if (FloatValue != 0F) hash ^= FloatValue.GetHashCode();
      if (StringValue.Length != 0) hash ^= StringValue.GetHashCode();
      if (BooleanValue != false) hash ^= BooleanValue.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Type != 0) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (IntValue != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(FloatValue);
      }
      if (StringValue.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(StringValue);
      }
      if (BooleanValue != false) {
        output.WriteRawTag(40);
        output.WriteBool(BooleanValue);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Type != 0) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (IntValue != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(IntValue);
      }
      if (FloatValue != 0F) {
        size += 1 + 4;
      }
      if (StringValue.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(StringValue);
      }
      if (BooleanValue != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemProperty other) {
      if (other == null) {
        return;
      }
      if (other.Type != 0) {
        Type = other.Type;
      }
      if (other.IntValue != 0) {
        IntValue = other.IntValue;
      }
      if (other.FloatValue != 0F) {
        FloatValue = other.FloatValue;
      }
      if (other.StringValue.Length != 0) {
        StringValue = other.StringValue;
      }
      if (other.BooleanValue != false) {
        BooleanValue = other.BooleanValue;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            type_ = (global::Axlebolt.Bolt.Protobuf2.PropertyType) input.ReadEnum();
            break;
          }
          case 16: {
            IntValue = input.ReadInt32();
            break;
          }
          case 29: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 34: {
            StringValue = input.ReadString();
            break;
          }
          case 40: {
            BooleanValue = input.ReadBool();
            break;
          }
        }
      }
    }

  }

  public sealed partial class InventoryItemProperties : pb::IMessage<InventoryItemProperties> {
    private static readonly pb::MessageParser<InventoryItemProperties> _parser = new pb::MessageParser<InventoryItemProperties>(() => new InventoryItemProperties());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InventoryItemProperties> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[9]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperties() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperties(InventoryItemProperties other) : this() {
      id_ = other.id_;
      properties_ = other.properties_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InventoryItemProperties Clone() {
      return new InventoryItemProperties(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int PropertiesFieldNumber = 2;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec _map_properties_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec(pb::FieldCodec.ForString(10), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser), 18);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InventoryItemProperties);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InventoryItemProperties other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (!Properties.Equals(other.Properties)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      hash ^= Properties.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      properties_.WriteTo(output, _map_properties_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InventoryItemProperties other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      properties_.Add(other.properties_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 18: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class ItemFlags : pb::IMessage<ItemFlags> {
    private static readonly pb::MessageParser<ItemFlags> _parser = new pb::MessageParser<ItemFlags>(() => new ItemFlags());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ItemFlags> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[10]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ItemFlags() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ItemFlags(ItemFlags other) : this() {
      flags_ = other.flags_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ItemFlags Clone() {
      return new ItemFlags(this);
    }

    public const int FlagsFieldNumber = 1;
    private static readonly pbc::MapField<int, int>.Codec _map_flags_codec
        = new pbc::MapField<int, int>.Codec(pb::FieldCodec.ForInt32(8), pb::FieldCodec.ForInt32(16), 10);
    private readonly pbc::MapField<int, int> flags_ = new pbc::MapField<int, int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<int, int> Flags {
      get { return flags_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ItemFlags);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ItemFlags other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!Flags.Equals(other.Flags)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= Flags.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      flags_.WriteTo(output, _map_flags_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += flags_.CalculateSize(_map_flags_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ItemFlags other) {
      if (other == null) {
        return;
      }
      flags_.Add(other.flags_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            flags_.AddEntriesFrom(input, _map_flags_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class RecipeInfo : pb::IMessage<RecipeInfo> {
    private static readonly pb::MessageParser<RecipeInfo> _parser = new pb::MessageParser<RecipeInfo>(() => new RecipeInfo());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RecipeInfo> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[11]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RecipeInfo() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RecipeInfo(RecipeInfo other) : this() {
      recipe_ = other.recipe_;
      entities_ = other.entities_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RecipeInfo Clone() {
      return new RecipeInfo(this);
    }

    public const int RecipeFieldNumber = 1;
    private string recipe_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Recipe {
      get { return recipe_; }
      set {
        recipe_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int EntitiesFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ExchangeEntity> _repeated_entities_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.ExchangeEntity.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ExchangeEntity> entities_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ExchangeEntity>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ExchangeEntity> Entities {
      get { return entities_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RecipeInfo);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RecipeInfo other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Recipe != other.Recipe) return false;
      if(!entities_.Equals(other.entities_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Recipe.Length != 0) hash ^= Recipe.GetHashCode();
      hash ^= entities_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Recipe.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Recipe);
      }
      entities_.WriteTo(output, _repeated_entities_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Recipe.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Recipe);
      }
      size += entities_.CalculateSize(_repeated_entities_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RecipeInfo other) {
      if (other == null) {
        return;
      }
      if (other.Recipe.Length != 0) {
        Recipe = other.Recipe;
      }
      entities_.Add(other.entities_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Recipe = input.ReadString();
            break;
          }
          case 18: {
            entities_.AddEntriesFrom(input, _repeated_entities_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class ExchangeEntity : pb::IMessage<ExchangeEntity> {
    private static readonly pb::MessageParser<ExchangeEntity> _parser = new pb::MessageParser<ExchangeEntity>(() => new ExchangeEntity());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ExchangeEntity> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[12]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeEntity() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeEntity(ExchangeEntity other) : this() {
      inventoryItems_ = other.inventoryItems_.Clone();
      currencies_ = other.currencies_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ExchangeEntity Clone() {
      return new ExchangeEntity(this);
    }

    public const int InventoryItemsFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> _repeated_inventoryItems_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> inventoryItems_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> InventoryItems {
      get { return inventoryItems_; }
    }

    public const int CurrenciesFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_currencies_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> currencies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> Currencies {
      get { return currencies_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ExchangeEntity);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ExchangeEntity other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!inventoryItems_.Equals(other.inventoryItems_)) return false;
      if(!currencies_.Equals(other.currencies_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= inventoryItems_.GetHashCode();
      hash ^= currencies_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      inventoryItems_.WriteTo(output, _repeated_inventoryItems_codec);
      currencies_.WriteTo(output, _repeated_currencies_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += inventoryItems_.CalculateSize(_repeated_inventoryItems_codec);
      size += currencies_.CalculateSize(_repeated_currencies_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ExchangeEntity other) {
      if (other == null) {
        return;
      }
      inventoryItems_.Add(other.inventoryItems_);
      currencies_.Add(other.currencies_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            inventoryItems_.AddEntriesFrom(input, _repeated_inventoryItems_codec);
            break;
          }
          case 18: {
            currencies_.AddEntriesFrom(input, _repeated_currencies_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class RewardInfo : pb::IMessage<RewardInfo> {
    private static readonly pb::MessageParser<RewardInfo> _parser = new pb::MessageParser<RewardInfo>(() => new RewardInfo());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RewardInfo> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[13]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RewardInfo() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RewardInfo(RewardInfo other) : this() {
      items_ = other.items_.Clone();
      currencies_ = other.currencies_.Clone();
      recipes_ = other.recipes_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RewardInfo Clone() {
      return new RewardInfo(this);
    }

    public const int ItemsFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> _repeated_items_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> items_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItemAmount> Items {
      get { return items_; }
    }

    public const int CurrenciesFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_currencies_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> currencies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> Currencies {
      get { return currencies_; }
    }

    public const int RecipesFieldNumber = 3;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.RecipeInfo> _repeated_recipes_codec
        = pb::FieldCodec.ForMessage(26, global::Axlebolt.Bolt.Protobuf2.RecipeInfo.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.RecipeInfo> recipes_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.RecipeInfo>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.RecipeInfo> Recipes {
      get { return recipes_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RewardInfo);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RewardInfo other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!items_.Equals(other.items_)) return false;
      if(!currencies_.Equals(other.currencies_)) return false;
      if(!recipes_.Equals(other.recipes_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= items_.GetHashCode();
      hash ^= currencies_.GetHashCode();
      hash ^= recipes_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      items_.WriteTo(output, _repeated_items_codec);
      currencies_.WriteTo(output, _repeated_currencies_codec);
      recipes_.WriteTo(output, _repeated_recipes_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += items_.CalculateSize(_repeated_items_codec);
      size += currencies_.CalculateSize(_repeated_currencies_codec);
      size += recipes_.CalculateSize(_repeated_recipes_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RewardInfo other) {
      if (other == null) {
        return;
      }
      items_.Add(other.items_);
      currencies_.Add(other.currencies_);
      recipes_.Add(other.recipes_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            items_.AddEntriesFrom(input, _repeated_items_codec);
            break;
          }
          case 18: {
            currencies_.AddEntriesFrom(input, _repeated_currencies_codec);
            break;
          }
          case 26: {
            recipes_.AddEntriesFrom(input, _repeated_recipes_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class Reward : pb::IMessage<Reward> {
    private static readonly pb::MessageParser<Reward> _parser = new pb::MessageParser<Reward>(() => new Reward());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Reward> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor.MessageTypes[14]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Reward() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Reward(Reward other) : this() {
      items_ = other.items_.Clone();
      currencies_ = other.currencies_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Reward Clone() {
      return new Reward(this);
    }

    public const int ItemsFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.InventoryItem> _repeated_items_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.InventoryItem.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> items_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.InventoryItem> Items {
      get { return items_; }
    }

    public const int CurrenciesFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> _repeated_currencies_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> currencies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.CurrencyAmount> Currencies {
      get { return currencies_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Reward);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Reward other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!items_.Equals(other.items_)) return false;
      if(!currencies_.Equals(other.currencies_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= items_.GetHashCode();
      hash ^= currencies_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      items_.WriteTo(output, _repeated_items_codec);
      currencies_.WriteTo(output, _repeated_currencies_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += items_.CalculateSize(_repeated_items_codec);
      size += currencies_.CalculateSize(_repeated_currencies_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Reward other) {
      if (other == null) {
        return;
      }
      items_.Add(other.items_);
      currencies_.Add(other.currencies_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            items_.AddEntriesFrom(input, _repeated_items_codec);
            break;
          }
          case 18: {
            currencies_.AddEntriesFrom(input, _repeated_currencies_codec);
            break;
          }
        }
      }
    }

  }


}

