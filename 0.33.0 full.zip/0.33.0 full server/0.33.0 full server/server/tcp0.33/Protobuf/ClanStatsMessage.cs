#pragma warning disable 1591, 0612, 3021, 8981

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2
{

  public static partial class ClanStatsMessageReflection
  {


    public static pbr::FileDescriptor Descriptor
    {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static ClanStatsMessageReflection()
    {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChZDbGFuU3RhdHNNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMiKNAQoOQ2xhbk1lbWJlclN0YXQSDgoGc3RhdElkGAEgASgJEjIKBHR5",
            "cGUYAiABKA4yJC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5TdGF0RGVmVHlw",
            "ZRIQCghpbnRWYWx1ZRgDIAEoBRISCgpmbG9hdFZhbHVlGAQgASgCEhEKCWxv",
            "bmdWYWx1ZRgFIAEoAyKHAQoIQ2xhblN0YXQSMgoEdHlwZRgBIAEoDjIkLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLlN0YXREZWZUeXBlEhAKCGludFZhbHVl",
            "GAIgASgFEhIKCmZsb2F0VmFsdWUYAyABKAISEQoJbG9uZ1ZhbHVlGAQgASgD",
            "Eg4KBnN0YXRJZBgFIAEoCSJfCglDbGFuU3RhdHMSDgoGY2xhbklkGAEgASgJ",
            "EjAKBXN0YXRzGAIgAygLMiEuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ2xh",
            "blN0YXQSEAoIc2Vhc29uSWQYAyABKAkiWwoPQ2xhbk1lbWJlclN0YXRzEhAK",
            "CHBsYXllcklkGAEgASgJEjYKBXN0YXRzGAIgAygLMicuQXhsZWJvbHQuQm9s",
            "dC5Qcm90b2J1ZjIuQ2xhbk1lbWJlclN0YXQioAEKDENsYW5TdGF0c01hcBI/",
            "CgVzdGF0cxgBIAMoCzIwLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkNsYW5T",
            "dGF0c01hcC5TdGF0c0VudHJ5Gk8KClN0YXRzRW50cnkSCwoDa2V5GAEgASgJ",
            "EjAKBXZhbHVlGAIgASgLMiEuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ2xh",
            "blN0YXQ6AjgBIjkKGkdldEN1cnJlbnRDbGFuU3RhdHNSZXF1ZXN0EhsKE2Fk",
            "ZExlYWRlcmJvYXJkU3RhdHMYASABKAgi3QEKG0dldEN1cnJlbnRDbGFuU3Rh",
            "dHNSZXNwb25zZRIOCgZjbGFuSWQYASABKAkSNAoFc3RhdHMYAiABKAsyJS5B",
            "eGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuU3RhdHNNYXASNQoJY2xhblN0",
            "YXRzGAMgASgLMiIuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ2xhblN0YXRz",
            "EkEKD2NsYW5NZW1iZXJTdGF0cxgEIAMoCzIoLkF4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyLkNsYW5NZW1iZXJTdGF0cyJCChNHZXRDbGFuU3RhdHNSZXF1ZXN0",
            "Eg4KBmNsYW5JZBgBIAEoCRIbChNhZGRMZWFkZXJib2FyZFN0YXRzGAIgASgI",
            "ItYBChRHZXRDbGFuU3RhdHNSZXNwb25zZRIOCgZjbGFuSWQYASABKAkSNAoF",
            "c3RhdHMYAiABKAsyJS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuU3Rh",
            "dHNNYXASNQoJY2xhblN0YXRzGAMgASgLMiIuQXhsZWJvbHQuQm9sdC5Qcm90",
            "b2J1ZjIuQ2xhblN0YXRzEkEKD2NsYW5NZW1iZXJTdGF0cxgEIAMoCzIoLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLkNsYW5NZW1iZXJTdGF0cyo4CgtTdGF0",
            "RGVmVHlwZRIHCgNJbnQQABIJCgVGbG9hdBABEgsKB0F2Z3JhdGUQAhIICgRM",
            "b25nEANiBnByb3RvMw=="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { },
          new pbr::GeneratedClrTypeInfo(new[] { typeof(global::Axlebolt.Bolt.Protobuf2.StatDefType), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanMemberStat), global::Axlebolt.Bolt.Protobuf2.ClanMemberStat.Parser, new[]{ "StatId", "Type", "IntValue", "FloatValue", "LongValue" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanStat), global::Axlebolt.Bolt.Protobuf2.ClanStat.Parser, new[]{ "Type", "IntValue", "FloatValue", "LongValue", "StatId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanStats), global::Axlebolt.Bolt.Protobuf2.ClanStats.Parser, new[]{ "ClanId", "Stats", "SeasonId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanMemberStats), global::Axlebolt.Bolt.Protobuf2.ClanMemberStats.Parser, new[]{ "PlayerId", "Stats" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanStatsMap), global::Axlebolt.Bolt.Protobuf2.ClanStatsMap.Parser, new[]{ "Stats" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetCurrentClanStatsRequest), global::Axlebolt.Bolt.Protobuf2.GetCurrentClanStatsRequest.Parser, new[]{ "AddLeaderboardStats" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetCurrentClanStatsResponse), global::Axlebolt.Bolt.Protobuf2.GetCurrentClanStatsResponse.Parser, new[]{ "ClanId", "Stats", "ClanStats", "ClanMemberStats" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetClanStatsRequest), global::Axlebolt.Bolt.Protobuf2.GetClanStatsRequest.Parser, new[]{ "ClanId", "AddLeaderboardStats" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetClanStatsResponse), global::Axlebolt.Bolt.Protobuf2.GetClanStatsResponse.Parser, new[]{ "ClanId", "Stats", "ClanStats", "ClanMemberStats" }, null, null, null, null)
          }));
    }

  }


  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanMemberStat : pb::IMessage<ClanMemberStat>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<ClanMemberStat> _parser = new pb::MessageParser<ClanMemberStat>(() => new ClanMemberStat());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanMemberStat> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStat()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStat(ClanMemberStat other) : this()
    {
      statId_ = other.statId_;
      type_ = other.type_;
      intValue_ = other.intValue_;
      floatValue_ = other.floatValue_;
      longValue_ = other.longValue_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStat Clone()
    {
      return new ClanMemberStat(this);
    }

    public const int StatIdFieldNumber = 1;
    private string statId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string StatId
    {
      get { return statId_; }
      set
      {
        statId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.StatDefType type_ = global::Axlebolt.Bolt.Protobuf2.StatDefType.Int;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.StatDefType Type
    {
      get { return type_; }
      set
      {
        type_ = value;
      }
    }

    public const int IntValueFieldNumber = 3;
    private int intValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int IntValue
    {
      get { return intValue_; }
      set
      {
        intValue_ = value;
      }
    }

    public const int FloatValueFieldNumber = 4;
    private float floatValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float FloatValue
    {
      get { return floatValue_; }
      set
      {
        floatValue_ = value;
      }
    }

    public const int LongValueFieldNumber = 5;
    private long longValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long LongValue
    {
      get { return longValue_; }
      set
      {
        longValue_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as ClanMemberStat);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanMemberStat other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (StatId != other.StatId) return false;
      if (Type != other.Type) return false;
      if (IntValue != other.IntValue) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(FloatValue, other.FloatValue)) return false;
      if (LongValue != other.LongValue) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (StatId.Length != 0) hash ^= StatId.GetHashCode();
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int) hash ^= Type.GetHashCode();
      if (IntValue != 0) hash ^= IntValue.GetHashCode();
      if (FloatValue != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(FloatValue);
      if (LongValue != 0L) hash ^= LongValue.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (StatId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(StatId);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Type);
      }
      if (IntValue != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(FloatValue);
      }
      if (LongValue != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(LongValue);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (StatId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(StatId);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        output.WriteRawTag(16);
        output.WriteEnum((int)Type);
      }
      if (IntValue != 0)
      {
        output.WriteRawTag(24);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F)
      {
        output.WriteRawTag(37);
        output.WriteFloat(FloatValue);
      }
      if (LongValue != 0L)
      {
        output.WriteRawTag(40);
        output.WriteInt64(LongValue);
      }
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (StatId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(StatId);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int)Type);
      }
      if (IntValue != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(IntValue);
      }
      if (FloatValue != 0F)
      {
        size += 1 + 4;
      }
      if (LongValue != 0L)
      {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(LongValue);
      }
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanMemberStat other)
    {
      if (other == null)
      {
        return;
      }
      if (other.StatId.Length != 0)
      {
        StatId = other.StatId;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        Type = other.Type;
      }
      if (other.IntValue != 0)
      {
        IntValue = other.IntValue;
      }
      if (other.FloatValue != 0F)
      {
        FloatValue = other.FloatValue;
      }
      if (other.LongValue != 0L)
      {
        LongValue = other.LongValue;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            StatId = input.ReadString();
            break;
          }
          case 16: {
            Type = (global::Axlebolt.Bolt.Protobuf2.StatDefType) input.ReadEnum();
            break;
          }
          case 24: {
            IntValue = input.ReadInt32();
            break;
          }
          case 37: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 40: {
            LongValue = input.ReadInt64();
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              StatId = input.ReadString();
              break;
            }
          case 16:
            {
              Type = (global::Axlebolt.Bolt.Protobuf2.StatDefType)input.ReadEnum();
              break;
            }
          case 24:
            {
              IntValue = input.ReadInt32();
              break;
            }
          case 37:
            {
              FloatValue = input.ReadFloat();
              break;
            }
          case 40:
            {
              LongValue = input.ReadInt64();
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanStat : pb::IMessage<ClanStat>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<ClanStat> _parser = new pb::MessageParser<ClanStat>(() => new ClanStat());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanStat> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStat()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStat(ClanStat other) : this()
    {
      type_ = other.type_;
      intValue_ = other.intValue_;
      floatValue_ = other.floatValue_;
      longValue_ = other.longValue_;
      statId_ = other.statId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStat Clone()
    {
      return new ClanStat(this);
    }

    public const int TypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.StatDefType type_ = global::Axlebolt.Bolt.Protobuf2.StatDefType.Int;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.StatDefType Type
    {
      get { return type_; }
      set
      {
        type_ = value;
      }
    }

    public const int IntValueFieldNumber = 2;
    private int intValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int IntValue
    {
      get { return intValue_; }
      set
      {
        intValue_ = value;
      }
    }

    public const int FloatValueFieldNumber = 3;
    private float floatValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float FloatValue
    {
      get { return floatValue_; }
      set
      {
        floatValue_ = value;
      }
    }

    public const int LongValueFieldNumber = 4;
    private long longValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long LongValue
    {
      get { return longValue_; }
      set
      {
        longValue_ = value;
      }
    }

    public const int StatIdFieldNumber = 5;
    private string statId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string StatId
    {
      get { return statId_; }
      set
      {
        statId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as ClanStat);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanStat other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (Type != other.Type) return false;
      if (IntValue != other.IntValue) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(FloatValue, other.FloatValue)) return false;
      if (LongValue != other.LongValue) return false;
      if (StatId != other.StatId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int) hash ^= Type.GetHashCode();
      if (IntValue != 0) hash ^= IntValue.GetHashCode();
      if (FloatValue != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(FloatValue);
      if (LongValue != 0L) hash ^= LongValue.GetHashCode();
      if (StatId.Length != 0) hash ^= StatId.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (IntValue != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(FloatValue);
      }
      if (LongValue != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(LongValue);
      }
      if (StatId.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(StatId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        output.WriteRawTag(8);
        output.WriteEnum((int)Type);
      }
      if (IntValue != 0)
      {
        output.WriteRawTag(16);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F)
      {
        output.WriteRawTag(29);
        output.WriteFloat(FloatValue);
      }
      if (LongValue != 0L)
      {
        output.WriteRawTag(32);
        output.WriteInt64(LongValue);
      }
      if (StatId.Length != 0)
      {
        output.WriteRawTag(42);
        output.WriteString(StatId);
      }
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int)Type);
      }
      if (IntValue != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(IntValue);
      }
      if (FloatValue != 0F)
      {
        size += 1 + 4;
      }
      if (LongValue != 0L)
      {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(LongValue);
      }
      if (StatId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(StatId);
      }
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanStat other)
    {
      if (other == null)
      {
        return;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.StatDefType.Int)
      {
        Type = other.Type;
      }
      if (other.IntValue != 0)
      {
        IntValue = other.IntValue;
      }
      if (other.FloatValue != 0F)
      {
        FloatValue = other.FloatValue;
      }
      if (other.LongValue != 0L)
      {
        LongValue = other.LongValue;
      }
      if (other.StatId.Length != 0)
      {
        StatId = other.StatId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Type = (global::Axlebolt.Bolt.Protobuf2.StatDefType) input.ReadEnum();
            break;
          }
          case 16: {
            IntValue = input.ReadInt32();
            break;
          }
          case 29: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 32: {
            LongValue = input.ReadInt64();
            break;
          }
          case 42: {
            StatId = input.ReadString();
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8:
            {
              Type = (global::Axlebolt.Bolt.Protobuf2.StatDefType)input.ReadEnum();
              break;
            }
          case 16:
            {
              IntValue = input.ReadInt32();
              break;
            }
          case 29:
            {
              FloatValue = input.ReadFloat();
              break;
            }
          case 32:
            {
              LongValue = input.ReadInt64();
              break;
            }
          case 42:
            {
              StatId = input.ReadString();
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanStats : pb::IMessage<ClanStats>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<ClanStats> _parser = new pb::MessageParser<ClanStats>(() => new ClanStats());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanStats> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStats()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStats(ClanStats other) : this()
    {
      clanId_ = other.clanId_;
      stats_ = other.stats_.Clone();
      seasonId_ = other.seasonId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStats Clone()
    {
      return new ClanStats(this);
    }

    public const int ClanIdFieldNumber = 1;
    private string clanId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ClanId
    {
      get { return clanId_; }
      set
      {
        clanId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StatsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ClanStat> _repeated_stats_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.ClanStat.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanStat> stats_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanStat>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanStat> Stats
    {
      get { return stats_; }
    }

    public const int SeasonIdFieldNumber = 3;
    private string seasonId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string SeasonId
    {
      get { return seasonId_; }
      set
      {
        seasonId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as ClanStats);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanStats other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (ClanId != other.ClanId) return false;
      if (!stats_.Equals(other.stats_)) return false;
      if (SeasonId != other.SeasonId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (ClanId.Length != 0) hash ^= ClanId.GetHashCode();
      hash ^= stats_.GetHashCode();
      if (SeasonId.Length != 0) hash ^= SeasonId.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (ClanId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      stats_.WriteTo(output, _repeated_stats_codec);
      if (SeasonId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(SeasonId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (ClanId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      stats_.WriteTo(ref output, _repeated_stats_codec);
      if (SeasonId.Length != 0)
      {
        output.WriteRawTag(26);
        output.WriteString(SeasonId);
      }
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (ClanId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ClanId);
      }
      size += stats_.CalculateSize(_repeated_stats_codec);
      if (SeasonId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SeasonId);
      }
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanStats other)
    {
      if (other == null)
      {
        return;
      }
      if (other.ClanId.Length != 0)
      {
        ClanId = other.ClanId;
      }
      stats_.Add(other.stats_);
      if (other.SeasonId.Length != 0)
      {
        SeasonId = other.SeasonId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            ClanId = input.ReadString();
            break;
          }
          case 18: {
            stats_.AddEntriesFrom(input, _repeated_stats_codec);
            break;
          }
          case 26: {
            SeasonId = input.ReadString();
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              ClanId = input.ReadString();
              break;
            }
          case 18:
            {
              stats_.AddEntriesFrom(ref input, _repeated_stats_codec);
              break;
            }
          case 26:
            {
              SeasonId = input.ReadString();
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanMemberStats : pb::IMessage<ClanMemberStats>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<ClanMemberStats> _parser = new pb::MessageParser<ClanMemberStats>(() => new ClanMemberStats());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanMemberStats> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStats()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStats(ClanMemberStats other) : this()
    {
      playerId_ = other.playerId_;
      stats_ = other.stats_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberStats Clone()
    {
      return new ClanMemberStats(this);
    }

    public const int PlayerIdFieldNumber = 1;
    private string playerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string PlayerId
    {
      get { return playerId_; }
      set
      {
        playerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StatsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ClanMemberStat> _repeated_stats_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.ClanMemberStat.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStat> stats_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStat>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStat> Stats
    {
      get { return stats_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as ClanMemberStats);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanMemberStats other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (PlayerId != other.PlayerId) return false;
      if (!stats_.Equals(other.stats_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (PlayerId.Length != 0) hash ^= PlayerId.GetHashCode();
      hash ^= stats_.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (PlayerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      stats_.WriteTo(output, _repeated_stats_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (PlayerId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      stats_.WriteTo(ref output, _repeated_stats_codec);
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (PlayerId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PlayerId);
      }
      size += stats_.CalculateSize(_repeated_stats_codec);
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanMemberStats other)
    {
      if (other == null)
      {
        return;
      }
      if (other.PlayerId.Length != 0)
      {
        PlayerId = other.PlayerId;
      }
      stats_.Add(other.stats_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            PlayerId = input.ReadString();
            break;
          }
          case 18: {
            stats_.AddEntriesFrom(input, _repeated_stats_codec);
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              PlayerId = input.ReadString();
              break;
            }
          case 18:
            {
              stats_.AddEntriesFrom(ref input, _repeated_stats_codec);
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanStatsMap : pb::IMessage<ClanStatsMap>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<ClanStatsMap> _parser = new pb::MessageParser<ClanStatsMap>(() => new ClanStatsMap());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanStatsMap> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStatsMap()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStatsMap(ClanStatsMap other) : this()
    {
      stats_ = other.stats_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanStatsMap Clone()
    {
      return new ClanStatsMap(this);
    }

    public const int StatsFieldNumber = 1;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.ClanStat>.Codec _map_stats_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.ClanStat>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.ClanStat.Parser), 10);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.ClanStat> stats_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.ClanStat>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.ClanStat> Stats
    {
      get { return stats_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as ClanStatsMap);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanStatsMap other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (!Stats.Equals(other.Stats)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      hash ^= Stats.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      stats_.WriteTo(output, _map_stats_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      stats_.WriteTo(ref output, _map_stats_codec);
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      size += stats_.CalculateSize(_map_stats_codec);
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanStatsMap other)
    {
      if (other == null)
      {
        return;
      }
      stats_.MergeFrom(other.stats_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            stats_.AddEntriesFrom(input, _map_stats_codec);
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              stats_.AddEntriesFrom(ref input, _map_stats_codec);
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetCurrentClanStatsRequest : pb::IMessage<GetCurrentClanStatsRequest>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<GetCurrentClanStatsRequest> _parser = new pb::MessageParser<GetCurrentClanStatsRequest>(() => new GetCurrentClanStatsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetCurrentClanStatsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsRequest()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsRequest(GetCurrentClanStatsRequest other) : this()
    {
      addLeaderboardStats_ = other.addLeaderboardStats_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsRequest Clone()
    {
      return new GetCurrentClanStatsRequest(this);
    }

    public const int AddLeaderboardStatsFieldNumber = 1;
    private bool addLeaderboardStats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool AddLeaderboardStats
    {
      get { return addLeaderboardStats_; }
      set
      {
        addLeaderboardStats_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as GetCurrentClanStatsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetCurrentClanStatsRequest other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (AddLeaderboardStats != other.AddLeaderboardStats) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (AddLeaderboardStats != false) hash ^= AddLeaderboardStats.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (AddLeaderboardStats != false) {
        output.WriteRawTag(8);
        output.WriteBool(AddLeaderboardStats);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (AddLeaderboardStats != false)
      {
        output.WriteRawTag(8);
        output.WriteBool(AddLeaderboardStats);
      }
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (AddLeaderboardStats != false)
      {
        size += 1 + 1;
      }
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetCurrentClanStatsRequest other)
    {
      if (other == null)
      {
        return;
      }
      if (other.AddLeaderboardStats != false)
      {
        AddLeaderboardStats = other.AddLeaderboardStats;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            AddLeaderboardStats = input.ReadBool();
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8:
            {
              AddLeaderboardStats = input.ReadBool();
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetCurrentClanStatsResponse : pb::IMessage<GetCurrentClanStatsResponse>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<GetCurrentClanStatsResponse> _parser = new pb::MessageParser<GetCurrentClanStatsResponse>(() => new GetCurrentClanStatsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetCurrentClanStatsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsResponse()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsResponse(GetCurrentClanStatsResponse other) : this()
    {
      clanId_ = other.clanId_;
      stats_ = other.stats_ != null ? other.stats_.Clone() : null;
      clanStats_ = other.clanStats_ != null ? other.clanStats_.Clone() : null;
      clanMemberStats_ = other.clanMemberStats_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetCurrentClanStatsResponse Clone()
    {
      return new GetCurrentClanStatsResponse(this);
    }

    public const int ClanIdFieldNumber = 1;
    private string clanId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ClanId
    {
      get { return clanId_; }
      set
      {
        clanId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StatsFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.ClanStatsMap stats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanStatsMap Stats
    {
      get { return stats_; }
      set
      {
        stats_ = value;
      }
    }

    public const int ClanStatsFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.ClanStats clanStats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanStats ClanStats
    {
      get { return clanStats_; }
      set
      {
        clanStats_ = value;
      }
    }

    public const int ClanMemberStatsFieldNumber = 4;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> _repeated_clanMemberStats_codec
        = pb::FieldCodec.ForMessage(34, global::Axlebolt.Bolt.Protobuf2.ClanMemberStats.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> clanMemberStats_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> ClanMemberStats
    {
      get { return clanMemberStats_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as GetCurrentClanStatsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetCurrentClanStatsResponse other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (ClanId != other.ClanId) return false;
      if (!object.Equals(Stats, other.Stats)) return false;
      if (!object.Equals(ClanStats, other.ClanStats)) return false;
      if (!clanMemberStats_.Equals(other.clanMemberStats_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (ClanId.Length != 0) hash ^= ClanId.GetHashCode();
      if (stats_ != null) hash ^= Stats.GetHashCode();
      if (clanStats_ != null) hash ^= ClanStats.GetHashCode();
      hash ^= clanMemberStats_.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (ClanId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (stats_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Stats);
      }
      if (clanStats_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(ClanStats);
      }
      clanMemberStats_.WriteTo(output, _repeated_clanMemberStats_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (ClanId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (stats_ != null)
      {
        output.WriteRawTag(18);
        output.WriteMessage(Stats);
      }
      if (clanStats_ != null)
      {
        output.WriteRawTag(26);
        output.WriteMessage(ClanStats);
      }
      clanMemberStats_.WriteTo(ref output, _repeated_clanMemberStats_codec);
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (ClanId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ClanId);
      }
      if (stats_ != null)
      {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Stats);
      }
      if (clanStats_ != null)
      {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ClanStats);
      }
      size += clanMemberStats_.CalculateSize(_repeated_clanMemberStats_codec);
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetCurrentClanStatsResponse other)
    {
      if (other == null)
      {
        return;
      }
      if (other.ClanId.Length != 0)
      {
        ClanId = other.ClanId;
      }
      if (other.stats_ != null)
      {
        if (stats_ == null)
        {
          Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
        }
        Stats.MergeFrom(other.Stats);
      }
      if (other.clanStats_ != null)
      {
        if (clanStats_ == null)
        {
          ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
        }
        ClanStats.MergeFrom(other.ClanStats);
      }
      clanMemberStats_.Add(other.clanMemberStats_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            ClanId = input.ReadString();
            break;
          }
          case 18: {
            if (stats_ == null) {
              Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
            }
            input.ReadMessage(Stats);
            break;
          }
          case 26: {
            if (clanStats_ == null) {
              ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
            }
            input.ReadMessage(ClanStats);
            break;
          }
          case 34: {
            clanMemberStats_.AddEntriesFrom(input, _repeated_clanMemberStats_codec);
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              ClanId = input.ReadString();
              break;
            }
          case 18:
            {
              if (stats_ == null)
              {
                Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
              }
              input.ReadMessage(Stats);
              break;
            }
          case 26:
            {
              if (clanStats_ == null)
              {
                ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
              }
              input.ReadMessage(ClanStats);
              break;
            }
          case 34:
            {
              clanMemberStats_.AddEntriesFrom(ref input, _repeated_clanMemberStats_codec);
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClanStatsRequest : pb::IMessage<GetClanStatsRequest>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<GetClanStatsRequest> _parser = new pb::MessageParser<GetClanStatsRequest>(() => new GetClanStatsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetClanStatsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsRequest()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsRequest(GetClanStatsRequest other) : this()
    {
      clanId_ = other.clanId_;
      addLeaderboardStats_ = other.addLeaderboardStats_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsRequest Clone()
    {
      return new GetClanStatsRequest(this);
    }

    public const int ClanIdFieldNumber = 1;
    private string clanId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ClanId
    {
      get { return clanId_; }
      set
      {
        clanId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AddLeaderboardStatsFieldNumber = 2;
    private bool addLeaderboardStats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool AddLeaderboardStats
    {
      get { return addLeaderboardStats_; }
      set
      {
        addLeaderboardStats_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as GetClanStatsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetClanStatsRequest other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (ClanId != other.ClanId) return false;
      if (AddLeaderboardStats != other.AddLeaderboardStats) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (ClanId.Length != 0) hash ^= ClanId.GetHashCode();
      if (AddLeaderboardStats != false) hash ^= AddLeaderboardStats.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (ClanId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (AddLeaderboardStats != false) {
        output.WriteRawTag(16);
        output.WriteBool(AddLeaderboardStats);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (ClanId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (AddLeaderboardStats != false)
      {
        output.WriteRawTag(16);
        output.WriteBool(AddLeaderboardStats);
      }
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (ClanId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ClanId);
      }
      if (AddLeaderboardStats != false)
      {
        size += 1 + 1;
      }
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetClanStatsRequest other)
    {
      if (other == null)
      {
        return;
      }
      if (other.ClanId.Length != 0)
      {
        ClanId = other.ClanId;
      }
      if (other.AddLeaderboardStats != false)
      {
        AddLeaderboardStats = other.AddLeaderboardStats;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            ClanId = input.ReadString();
            break;
          }
          case 16: {
            AddLeaderboardStats = input.ReadBool();
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              ClanId = input.ReadString();
              break;
            }
          case 16:
            {
              AddLeaderboardStats = input.ReadBool();
              break;
            }
        }
      }
    }
#endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClanStatsResponse : pb::IMessage<GetClanStatsResponse>
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
#endif
  {
    private static readonly pb::MessageParser<GetClanStatsResponse> _parser = new pb::MessageParser<GetClanStatsResponse>(() => new GetClanStatsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetClanStatsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor
    {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanStatsMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor
    {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsResponse()
    {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsResponse(GetClanStatsResponse other) : this()
    {
      clanId_ = other.clanId_;
      stats_ = other.stats_ != null ? other.stats_.Clone() : null;
      clanStats_ = other.clanStats_ != null ? other.clanStats_.Clone() : null;
      clanMemberStats_ = other.clanMemberStats_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClanStatsResponse Clone()
    {
      return new GetClanStatsResponse(this);
    }

    public const int ClanIdFieldNumber = 1;
    private string clanId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ClanId
    {
      get { return clanId_; }
      set
      {
        clanId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StatsFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.ClanStatsMap stats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanStatsMap Stats
    {
      get { return stats_; }
      set
      {
        stats_ = value;
      }
    }

    public const int ClanStatsFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.ClanStats clanStats_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanStats ClanStats
    {
      get { return clanStats_; }
      set
      {
        clanStats_ = value;
      }
    }

    public const int ClanMemberStatsFieldNumber = 4;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> _repeated_clanMemberStats_codec
        = pb::FieldCodec.ForMessage(34, global::Axlebolt.Bolt.Protobuf2.ClanMemberStats.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> clanMemberStats_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberStats> ClanMemberStats
    {
      get { return clanMemberStats_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other)
    {
      return Equals(other as GetClanStatsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetClanStatsResponse other)
    {
      if (ReferenceEquals(other, null))
      {
        return false;
      }
      if (ReferenceEquals(other, this))
      {
        return true;
      }
      if (ClanId != other.ClanId) return false;
      if (!object.Equals(Stats, other.Stats)) return false;
      if (!object.Equals(ClanStats, other.ClanStats)) return false;
      if (!clanMemberStats_.Equals(other.clanMemberStats_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode()
    {
      int hash = 1;
      if (ClanId.Length != 0) hash ^= ClanId.GetHashCode();
      if (stats_ != null) hash ^= Stats.GetHashCode();
      if (clanStats_ != null) hash ^= ClanStats.GetHashCode();
      hash ^= clanMemberStats_.GetHashCode();
      if (_unknownFields != null)
      {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString()
    {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
#else
      if (ClanId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (stats_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Stats);
      }
      if (clanStats_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(ClanStats);
      }
      clanMemberStats_.WriteTo(output, _repeated_clanMemberStats_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output)
    {
      if (ClanId.Length != 0)
      {
        output.WriteRawTag(10);
        output.WriteString(ClanId);
      }
      if (stats_ != null)
      {
        output.WriteRawTag(18);
        output.WriteMessage(Stats);
      }
      if (clanStats_ != null)
      {
        output.WriteRawTag(26);
        output.WriteMessage(ClanStats);
      }
      clanMemberStats_.WriteTo(ref output, _repeated_clanMemberStats_codec);
      if (_unknownFields != null)
      {
        _unknownFields.WriteTo(ref output);
      }
    }
#endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize()
    {
      int size = 0;
      if (ClanId.Length != 0)
      {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ClanId);
      }
      if (stats_ != null)
      {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Stats);
      }
      if (clanStats_ != null)
      {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ClanStats);
      }
      size += clanMemberStats_.CalculateSize(_repeated_clanMemberStats_codec);
      if (_unknownFields != null)
      {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetClanStatsResponse other)
    {
      if (other == null)
      {
        return;
      }
      if (other.ClanId.Length != 0)
      {
        ClanId = other.ClanId;
      }
      if (other.stats_ != null)
      {
        if (stats_ == null)
        {
          Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
        }
        Stats.MergeFrom(other.Stats);
      }
      if (other.clanStats_ != null)
      {
        if (clanStats_ == null)
        {
          ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
        }
        ClanStats.MergeFrom(other.ClanStats);
      }
      clanMemberStats_.Add(other.clanMemberStats_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input)
    {
#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
#else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            ClanId = input.ReadString();
            break;
          }
          case 18: {
            if (stats_ == null) {
              Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
            }
            input.ReadMessage(Stats);
            break;
          }
          case 26: {
            if (clanStats_ == null) {
              ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
            }
            input.ReadMessage(ClanStats);
            break;
          }
          case 34: {
            clanMemberStats_.AddEntriesFrom(input, _repeated_clanMemberStats_codec);
            break;
          }
        }
      }
#endif
    }

#if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input)
    {
      uint tag;
      while ((tag = input.ReadTag()) != 0)
      {
        if ((tag & 7) == 4)
        {

          return;
        }
        switch (tag)
        {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
            {
              ClanId = input.ReadString();
              break;
            }
          case 18:
            {
              if (stats_ == null)
              {
                Stats = new global::Axlebolt.Bolt.Protobuf2.ClanStatsMap();
              }
              input.ReadMessage(Stats);
              break;
            }
          case 26:
            {
              if (clanStats_ == null)
              {
                ClanStats = new global::Axlebolt.Bolt.Protobuf2.ClanStats();
              }
              input.ReadMessage(ClanStats);
              break;
            }
          case 34:
            {
              clanMemberStats_.AddEntriesFrom(ref input, _repeated_clanMemberStats_codec);
              break;
            }
        }
      }
    }
#endif

  }


}

