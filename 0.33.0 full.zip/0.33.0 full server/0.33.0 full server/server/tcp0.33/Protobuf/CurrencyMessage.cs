#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class CurrencyMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static CurrencyMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChVDdXJyZW5jeU1lc3NhZ2UucHJvdG8SF0F4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyIkwKCEN1cnJlbmN5EgoKAmlkGAEgASgFEhUKDWV4Y2hhbmdlUmF0aW8Y",
            "AiABKAISHQoVZXhjaGFuZ2VibGVDdXJyZW5jaWVzGAMgAygFIkUKDkN1cnJl",
            "bmN5QW1vdW50EhIKCmN1cnJlbmN5SWQYASABKAUSEAoIb2xkVmFsdWUYAiAB",
            "KAUSDQoFdmFsdWUYAyABKAJiBnByb3RvMw=="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Currency), global::Axlebolt.Bolt.Protobuf2.Currency.Parser, new[]{ "Id", "ExchangeRatio", "ExchangebleCurrencies" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CurrencyAmount), global::Axlebolt.Bolt.Protobuf2.CurrencyAmount.Parser, new[]{ "CurrencyId", "OldValue", "Value" }, null, null, null)
          }));
    }

  }
  public sealed partial class Currency : pb::IMessage<Currency> {
    private static readonly pb::MessageParser<Currency> _parser = new pb::MessageParser<Currency>(() => new Currency());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Currency> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Currency() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Currency(Currency other) : this() {
      id_ = other.id_;
      exchangeRatio_ = other.exchangeRatio_;
      exchangebleCurrencies_ = other.exchangebleCurrencies_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Currency Clone() {
      return new Currency(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int ExchangeRatioFieldNumber = 2;
    private float exchangeRatio_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float ExchangeRatio {
      get { return exchangeRatio_; }
      set {
        exchangeRatio_ = value;
      }
    }

    public const int ExchangebleCurrenciesFieldNumber = 3;
    private static readonly pb::FieldCodec<int> _repeated_exchangebleCurrencies_codec
        = pb::FieldCodec.ForInt32(26);
    private readonly pbc::RepeatedField<int> exchangebleCurrencies_ = new pbc::RepeatedField<int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<int> ExchangebleCurrencies {
      get { return exchangebleCurrencies_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Currency);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Currency other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (ExchangeRatio != other.ExchangeRatio) return false;
      if(!exchangebleCurrencies_.Equals(other.exchangebleCurrencies_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (ExchangeRatio != 0F) hash ^= ExchangeRatio.GetHashCode();
      hash ^= exchangebleCurrencies_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (ExchangeRatio != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(ExchangeRatio);
      }
      exchangebleCurrencies_.WriteTo(output, _repeated_exchangebleCurrencies_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (ExchangeRatio != 0F) {
        size += 1 + 4;
      }
      size += exchangebleCurrencies_.CalculateSize(_repeated_exchangebleCurrencies_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Currency other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.ExchangeRatio != 0F) {
        ExchangeRatio = other.ExchangeRatio;
      }
      exchangebleCurrencies_.Add(other.exchangebleCurrencies_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 21: {
            ExchangeRatio = input.ReadFloat();
            break;
          }
          case 26:
          case 24: {
            exchangebleCurrencies_.AddEntriesFrom(input, _repeated_exchangebleCurrencies_codec);
            break;
          }
        }
      }
    }

  }

  public sealed partial class CurrencyAmount : pb::IMessage<CurrencyAmount> {
    private static readonly pb::MessageParser<CurrencyAmount> _parser = new pb::MessageParser<CurrencyAmount>(() => new CurrencyAmount());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<CurrencyAmount> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrencyAmount() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrencyAmount(CurrencyAmount other) : this() {
      currencyId_ = other.currencyId_;
      oldValue_ = other.oldValue_;
      value_ = other.value_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CurrencyAmount Clone() {
      return new CurrencyAmount(this);
    }

    public const int CurrencyIdFieldNumber = 1;
    private int currencyId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CurrencyId {
      get { return currencyId_; }
      set {
        currencyId_ = value;
      }
    }

    public const int OldValueFieldNumber = 2;
    private int oldValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int OldValue {
      get { return oldValue_; }
      set {
        oldValue_ = value;
      }
    }

    public const int ValueFieldNumber = 3;
    private float value_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float Value {
      get { return value_; }
      set {
        value_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as CurrencyAmount);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(CurrencyAmount other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (CurrencyId != other.CurrencyId) return false;
      if (OldValue != other.OldValue) return false;
      if (Value != other.Value) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (CurrencyId != 0) hash ^= CurrencyId.GetHashCode();
      if (OldValue != 0) hash ^= OldValue.GetHashCode();
      if (Value != 0F) hash ^= Value.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (CurrencyId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(CurrencyId);
      }
      if (OldValue != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(OldValue);
      }
      if (Value != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(Value);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (CurrencyId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrencyId);
      }
      if (OldValue != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(OldValue);
      }
      if (Value != 0F) {
        size += 1 + 4;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(CurrencyAmount other) {
      if (other == null) {
        return;
      }
      if (other.CurrencyId != 0) {
        CurrencyId = other.CurrencyId;
      }
      if (other.OldValue != 0) {
        OldValue = other.OldValue;
      }
      if (other.Value != 0F) {
        Value = other.Value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 8: {
            CurrencyId = input.ReadInt32();
            break;
          }
          case 16: {
            OldValue = input.ReadInt32();
            break;
          }
          case 29: {
            Value = input.ReadFloat();
            break;
          }
        }
      }
    }

  }


}

