using System;
using Google.Protobuf;
using Google.Protobuf.Collections;
using Google.Protobuf.Reflection;

namespace Axlebolt.Bolt.Protobuf2
{
    public sealed partial class Attributes : IMessage<Attributes>
    {
        private static readonly MessageParser<Attributes> _parser =
            new MessageParser<Attributes>(() => new Attributes());
        private static readonly MapField<string, Attribute>.Codec _map_map_codec =
            new MapField<string, Attribute>.Codec(
                FieldCodec.ForString(10, string.Empty),
                FieldCodec.ForMessage(18, Attribute.Parser),
                10);

        private readonly MapField<string, Attribute> map_ = new MapField<string, Attribute>();
        private UnknownFieldSet _unknownFields;

        public static MessageParser<Attributes> Parser => _parser;
        public static MessageDescriptor Descriptor => null;
        MessageDescriptor IMessage.Descriptor => Descriptor;
        public MapField<string, Attribute> Map => map_;

        public Attributes() { }
        public Attributes(Attributes other)
        {
            map_ = other.map_.Clone();
            _unknownFields = UnknownFieldSet.Clone(other._unknownFields);
        }

        public Attributes Clone() => new Attributes(this);
        public override bool Equals(object other) => Equals(other as Attributes);
        public bool Equals(Attributes other) =>
            !ReferenceEquals(other, null) && (ReferenceEquals(other, this) ||
            (map_.Equals(other.map_) && Equals(_unknownFields, other._unknownFields)));
        public override int GetHashCode()
        {
            int hash = 1;
            hash ^= map_.GetHashCode();
            if (_unknownFields != null) hash ^= _unknownFields.GetHashCode();
            return hash;
        }
        public override string ToString() => $"Attributes(count={map_.Count})";

        public void WriteTo(CodedOutputStream output)
        {
            map_.WriteTo(output, _map_map_codec);
            if (_unknownFields != null) _unknownFields.WriteTo(output);
        }

        public int CalculateSize()
        {
            int size = map_.CalculateSize(_map_map_codec);
            if (_unknownFields != null) size += _unknownFields.CalculateSize();
            return size;
        }

        public void MergeFrom(Attributes other)
        {
            if (other == null) return;
            map_.Add(other.map_);
            _unknownFields = UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
        }

        public void MergeFrom(CodedInputStream input)
        {
            uint tag;
            while ((tag = input.ReadTag()) != 0)
            {
                if (tag == 10) map_.AddEntriesFrom(input, _map_map_codec);
                else _unknownFields = UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            }
        }
    }

    public sealed partial class Attribute : IMessage<Attribute>
    {
        private static readonly MessageParser<Attribute> _parser =
            new MessageParser<Attribute>(() => new Attribute());
        private UnknownFieldSet _unknownFields;
        private PropertyType type_;
        private int int_;
        private float float_;
        private string string_ = string.Empty;
        private bool boolean_;

        public static MessageParser<Attribute> Parser => _parser;
        public static MessageDescriptor Descriptor => null;
        MessageDescriptor IMessage.Descriptor => Descriptor;

        public PropertyType Type => type_;
        public int Int { get => int_; set { int_ = value; type_ = PropertyType.Int; } }
        public float Float { get => float_; set { float_ = value; type_ = PropertyType.Float; } }
        public string String { get => string_; set { string_ = value ?? string.Empty; type_ = PropertyType.String; } }
        public bool Boolean { get => boolean_; set { boolean_ = value; type_ = PropertyType.Boolean; } }

        public Attribute() { }
        public Attribute(Attribute other)
        {
            type_ = other.type_;
            int_ = other.int_;
            float_ = other.float_;
            string_ = other.string_;
            boolean_ = other.boolean_;
            _unknownFields = UnknownFieldSet.Clone(other._unknownFields);
        }

        public Attribute Clone() => new Attribute(this);
        public override bool Equals(object other) => Equals(other as Attribute);
        public bool Equals(Attribute other)
        {
            if (ReferenceEquals(other, null)) return false;
            if (ReferenceEquals(other, this)) return true;
            return type_ == other.type_ && int_ == other.int_ && float_.Equals(other.float_) &&
                   string_ == other.string_ && boolean_ == other.boolean_ &&
                   Equals(_unknownFields, other._unknownFields);
        }
        public override int GetHashCode()
        {
            int hash = 1;
            if (type_ != PropertyType.Int) hash ^= type_.GetHashCode();
            if (int_ != 0) hash ^= int_.GetHashCode();
            if (float_ != 0F) hash ^= float_.GetHashCode();
            if (string_.Length != 0) hash ^= string_.GetHashCode();
            if (boolean_) hash ^= boolean_.GetHashCode();
            if (_unknownFields != null) hash ^= _unknownFields.GetHashCode();
            return hash;
        }
        public override string ToString() => $"Attribute(type={type_})";

        public void WriteTo(CodedOutputStream output)
        {
            if (type_ != PropertyType.Int) { output.WriteRawTag(8); output.WriteEnum((int)type_); }
            if (int_ != 0) { output.WriteRawTag(16); output.WriteInt32(int_); }
            if (float_ != 0F) { output.WriteRawTag(29); output.WriteFloat(float_); }
            if (string_.Length != 0) { output.WriteRawTag(34); output.WriteString(string_); }
            if (boolean_) { output.WriteRawTag(40); output.WriteBool(boolean_); }
            if (_unknownFields != null) _unknownFields.WriteTo(output);
        }

        public int CalculateSize()
        {
            int size = 0;
            if (type_ != PropertyType.Int) size += 1 + CodedOutputStream.ComputeEnumSize((int)type_);
            if (int_ != 0) size += 1 + CodedOutputStream.ComputeInt32Size(int_);
            if (float_ != 0F) size += 5;
            if (string_.Length != 0) size += 1 + CodedOutputStream.ComputeStringSize(string_);
            if (boolean_) size += 2;
            if (_unknownFields != null) size += _unknownFields.CalculateSize();
            return size;
        }

        public void MergeFrom(Attribute other)
        {
            if (other == null) return;
            type_ = other.type_;
            if (other.int_ != 0) int_ = other.int_;
            if (other.float_ != 0F) float_ = other.float_;
            if (other.string_.Length != 0) string_ = other.string_;
            if (other.boolean_) boolean_ = true;
            _unknownFields = UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
        }

        public void MergeFrom(CodedInputStream input)
        {
            uint tag;
            while ((tag = input.ReadTag()) != 0)
            {
                switch (tag)
                {
                    case 8: type_ = (PropertyType)input.ReadEnum(); break;
                    case 16: int_ = input.ReadInt32(); break;
                    case 29: float_ = input.ReadFloat(); break;
                    case 34: string_ = input.ReadString(); break;
                    case 40: boolean_ = input.ReadBool(); break;
                    default: _unknownFields = UnknownFieldSet.MergeFieldFrom(_unknownFields, input); break;
                }
            }
        }
    }
}
