#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class StorageMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static StorageMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChRTdG9yYWdlTWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1",
            "ZjIiKQoHU3RvcmFnZRIQCghmaWxlbmFtZRgBIAEoCRIMCgRmaWxlGAIgASgM",
            "YgZwcm90bzM="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Storage), global::Axlebolt.Bolt.Protobuf2.Storage.Parser, new[]{ "Filename", "File" }, null, null, null)
          }));
    }

  }
  public sealed partial class Storage : pb::IMessage<Storage> {
    private static readonly pb::MessageParser<Storage> _parser = new pb::MessageParser<Storage>(() => new Storage());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Storage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.StorageMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Storage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Storage(Storage other) : this() {
      filename_ = other.filename_;
      file_ = other.file_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Storage Clone() {
      return new Storage(this);
    }

    public const int FilenameFieldNumber = 1;
    private string filename_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Filename {
      get { return filename_; }
      set {
        filename_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int FileFieldNumber = 2;
    private pb::ByteString file_ = pb::ByteString.Empty;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString File {
      get { return file_; }
      set {
        file_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Storage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Storage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Filename != other.Filename) return false;
      if (File != other.File) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Filename.Length != 0) hash ^= Filename.GetHashCode();
      if (File.Length != 0) hash ^= File.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Filename.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Filename);
      }
      if (File.Length != 0) {
        output.WriteRawTag(18);
        output.WriteBytes(File);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Filename.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Filename);
      }
      if (File.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(File);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Storage other) {
      if (other == null) {
        return;
      }
      if (other.Filename.Length != 0) {
        Filename = other.Filename;
      }
      if (other.File.Length != 0) {
        File = other.File;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Filename = input.ReadString();
            break;
          }
          case 18: {
            File = input.ReadBytes();
            break;
          }
        }
      }
    }

  }


}

