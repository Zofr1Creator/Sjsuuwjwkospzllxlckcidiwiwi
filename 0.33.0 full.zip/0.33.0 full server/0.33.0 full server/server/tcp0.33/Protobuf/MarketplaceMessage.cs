#pragma warning disable 1591, 0612, 3021, 8981

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class MarketplaceMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static MarketplaceMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChhNYXJrZXRwbGFjZU1lc3NhZ2UucHJvdG8SF0F4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyGhNQbGF5ZXJNZXNzYWdlLnByb3RvGhZJbnZlbnRvcnlNZXNzYWdl",
            "LnByb3RvIoUBChNNYXJrZXRwbGFjZVNldHRpbmdzEhkKEWNvbW1pc3Npb25Q",
            "ZXJjZW50GAEgASgCEhUKDW1pbkNvbW1pc3Npb24YAiABKAISEgoKY3VycmVu",
            "Y3lJZBgDIAEoBRIPCgdlbmFibGVkGAQgASgIEhcKD2Jhbm5lZFVudGlsRGF0",
            "ZRgFIAEoAyJrCgVUcmFkZRIKCgJpZBgBIAEoBRISCgpzYWxlc0NvdW50GAIg",
            "ASgFEhYKDnB1cmNoYXNlc0NvdW50GAMgASgFEhIKCnNhbGVzUHJpY2UYBCAB",
            "KAISFgoOcHVyY2hhc2VzUHJpY2UYBSABKAIigQMKC09wZW5SZXF1ZXN0EgoK",
            "AmlkGAEgASgJEjAKB2NyZWF0b3IYAiABKAsyHy5BeGxlYm9sdC5Cb2x0LlBy",
            "b3RvYnVmMi5QbGF5ZXISGAoQaXRlbURlZmluaXRpb25JZBgDIAEoBRINCgVw",
            "cmljZRgEIAEoAhISCgpjcmVhdGVEYXRlGAUgASgDEjgKBHR5cGUYBiABKA4y",
            "Ki5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5NYXJrZXRSZXF1ZXN0VHlwZRIQ",
            "CghxdWFudGl0eRgHIAEoBRJICgpwcm9wZXJ0aWVzGAggAygLMjQuQXhsZWJv",
            "bHQuQm9sdC5Qcm90b2J1ZjIuT3BlblJlcXVlc3QuUHJvcGVydGllc0VudHJ5",
            "GmEKD1Byb3BlcnRpZXNFbnRyeRILCgNrZXkYASABKAkSPQoFdmFsdWUYAiAB",
            "KAsyLi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5JbnZlbnRvcnlJdGVtUHJv",
            "cGVydHk6AjgBIq4ECg1DbG9zZWRSZXF1ZXN0EgoKAmlkGAEgASgJEhAKCG9y",
            "aWdpbklkGAIgASgJEjAKB2NyZWF0b3IYAyABKAsyHy5BeGxlYm9sdC5Cb2x0",
            "LlByb3RvYnVmMi5QbGF5ZXISGAoQaXRlbURlZmluaXRpb25JZBgEIAEoBRIN",
            "CgVwcmljZRgFIAEoAhISCgpjcmVhdGVEYXRlGAYgASgDEhEKCWNsb3NlRGF0",
            "ZRgHIAEoAxI4CgR0eXBlGAggASgOMiouQXhsZWJvbHQuQm9sdC5Qcm90b2J1",
            "ZjIuTWFya2V0UmVxdWVzdFR5cGUSMAoHcGFydG5lchgJIAEoCzIfLkF4bGVi",
            "b2x0LkJvbHQuUHJvdG9idWYyLlBsYXllchIYChBwYXJ0bmVyUmVxdWVzdElk",
            "GAogASgJEjYKBnJlYXNvbhgLIAEoDjImLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLkNsb3NpbmdSZWFzb24SEAoIcXVhbnRpdHkYDCABKAUSSgoKcHJvcGVy",
            "dGllcxgNIAMoCzI2LkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkNsb3NlZFJl",
            "cXVlc3QuUHJvcGVydGllc0VudHJ5GmEKD1Byb3BlcnRpZXNFbnRyeRILCgNr",
            "ZXkYASABKAkSPQoFdmFsdWUYAiABKAsyLi5BeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMi5JbnZlbnRvcnlJdGVtUHJvcGVydHk6AjgBIqwDChFQcm9jZXNzaW5n",
            "UmVxdWVzdBIKCgJpZBgBIAEoCRIZChFpdGVtRGVmaW5pdGlvbklkXxgCIAEo",
            "BRINCgVwcmljZRgDIAEoAhISCgpjcmVhdGVEYXRlGAQgASgDEjgKBHR5cGUY",
            "BSABKA4yKi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5NYXJrZXRSZXF1ZXN0",
            "VHlwZRIVCg1zYWxlUmVxdWVzdElkGAYgASgJEjcKBXN0YXRlGAcgASgOMigu",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUHJvY2Vzc2luZ1N0YXRlEhAKCHF1",
            "YW50aXR5GAggASgFEk4KCnByb3BlcnRpZXMYCSADKAsyOi5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5Qcm9jZXNzaW5nUmVxdWVzdC5Qcm9wZXJ0aWVzRW50",
            "cnkaYQoPUHJvcGVydGllc0VudHJ5EgsKA2tleRgBIAEoCRI9CgV2YWx1ZRgC",
            "IAEoCzIuLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkludmVudG9yeUl0ZW1Q",
            "cm9wZXJ0eToCOAEiGgoMR2V0VHJhZGVBcmdzEgoKAmlkGAEgASgFIioKDUdl",
            "dFRyYWRlc0FyZ3MSGQoRaXRlbURlZmluaXRpb25JZHMYASADKAUiMgoRQ3Jl",
            "YXRlU2FsZVJlcXVlc3QSDgoGaXRlbUlkGAEgASgFEg0KBXByaWNlGAIgASgC",
            "IicKEkNyZWF0ZVNhbGVSZXNwb25zZRIRCglyZXF1ZXN0SWQYASABKAkiHwoR",
            "Q2FuY2VsUmVxdWVzdEFyZ3MSCgoCaWQYASABKAkiSgogR2V0VHJhZGVPcGVu",
            "UHVyY2hhc2VSZXF1ZXN0c0FyZ3MSCgoCaWQYASABKAUSDAoEcGFnZRgCIAEo",
            "BRIMCgRzaXplGAMgASgFIqUBChVHZXRDbG9zZWRSZXF1ZXN0c0FyZ3MSOAoE",
            "dHlwZRgBIAEoDjIqLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLk1hcmtldFJl",
            "cXVlc3RUeXBlEjYKBnJlYXNvbhgCIAEoDjImLkF4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyLkNsb3NpbmdSZWFzb24SDAoEcGFnZRgDIAEoBRIMCgRzaXplGAQg",
            "ASgFIioKGENyZWF0ZVB1cmNoYXNlQnlTYWxlQXJncxIOCgZzYWxlSWQYASAB",
            "KAkiNgoVQ3JlYXRlU2FsZVJlcXVlc3RBcmdzEg4KBml0ZW1JZBgBIAEoBRIN",
            "CgVwcmljZRgCIAEoAiJWChlDcmVhdGVQdXJjaGFzZVJlcXVlc3RBcmdzEhgK",
            "EGl0ZW1EZWZpbml0aW9uSWQYASABKAUSDQoFcHJpY2UYAiABKAISEAoIcXVh",
            "bnRpdHkYAyABKAUijgEKGkdldENsb3NlZFJlcXVlc3RzQ291bnRBcmdzEjgK",
            "BHR5cGUYASABKA4yKi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5NYXJrZXRS",
            "ZXF1ZXN0VHlwZRI2CgZyZWFzb24YAiABKA4yJi5BeGxlYm9sdC5Cb2x0LlBy",
            "b3RvYnVmMi5DbG9zaW5nUmVhc29uIkYKHEdldFRyYWRlT3BlblNhbGVSZXF1",
            "ZXN0c0FyZ3MSCgoCaWQYASABKAUSDAoEcGFnZRgCIAEoBRIMCgRzaXplGAMg",
            "ASgFIlMKGk9uUGxheWVyUmVxdWVzdE9wZW5lZEV2ZW50EjUKB3JlcXVlc3QY",
            "ASABKAsyJC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5PcGVuUmVxdWVzdCKR",
            "AQoaT25QbGF5ZXJSZXF1ZXN0Q2xvc2VkRXZlbnQSNwoHcmVxdWVzdBgBIAEo",
            "CzImLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkNsb3NlZFJlcXVlc3QSOgoE",
            "aXRlbRgCIAEoCzIsLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBsYXllcklu",
            "dmVudG9yeUl0ZW0iRAoTT25UcmFkZVVwZGF0ZWRFdmVudBItCgV0cmFkZRgB",
            "IAEoCzIeLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlRyYWRlIlQKGU9uVHJh",
            "ZGVSZXF1ZXN0Q2xvc2VkRXZlbnQSNwoHcmVxdWVzdBgBIAEoCzImLkF4bGVi",
            "b2x0LkJvbHQuUHJvdG9idWYyLkNsb3NlZFJlcXVlc3QiUgoZT25UcmFkZVJl",
            "cXVlc3RPcGVuZWRFdmVudBI1CgdyZXF1ZXN0GAEgASgLMiQuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuT3BlblJlcXVlc3QqcwoNQ2xvc2luZ1JlYXNvbhIO",
            "CgpOb25lUmVhc29uEAASFgoSU3VjY2Vzc1RyYW5zYWN0aW9uEAESEgoOTm90",
            "RW5vdWdoRnVuZHMQAhINCglDYW5jZWxsZWQQAxIXChNTYWxlUmVxdWVzdE5v",
            "dEZvdW5kEAQqRwoRTWFya2V0UmVxdWVzdFR5cGUSDAoITm9uZVR5cGUQABIP",
            "CgtTYWxlUmVxdWVzdBABEhMKD1B1cmNoYXNlUmVxdWVzdBACKi8KD1Byb2Nl",
            "c3NpbmdTdGF0ZRIMCghDcmVhdGluZxAAEg4KCkNhbmNlbGxpbmcQAWIGcHJv",
            "dG8z"
          ));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.InventoryMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.ClosingReason), typeof(global::Axlebolt.Bolt.Protobuf2.MarketRequestType), typeof(global::Axlebolt.Bolt.Protobuf2.ProcessingState), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.MarketplaceSettings), global::Axlebolt.Bolt.Protobuf2.MarketplaceSettings.Parser, new[]{ "CommissionPercent", "MinCommission", "CurrencyId", "Enabled", "BannedUntilDate" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Trade), global::Axlebolt.Bolt.Protobuf2.Trade.Parser, new[]{ "Id", "SalesCount", "PurchasesCount", "SalesPrice", "PurchasesPrice" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OpenRequest), global::Axlebolt.Bolt.Protobuf2.OpenRequest.Parser, new[]{ "Id", "Creator", "ItemDefinitionId", "Price", "CreateDate", "Type", "Quantity", "Properties" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClosedRequest), global::Axlebolt.Bolt.Protobuf2.ClosedRequest.Parser, new[]{ "Id", "OriginId", "Creator", "ItemDefinitionId", "Price", "CreateDate", "CloseDate", "Type", "Partner", "PartnerRequestId", "Reason", "Quantity", "Properties" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ProcessingRequest), global::Axlebolt.Bolt.Protobuf2.ProcessingRequest.Parser, new[]{ "Id", "ItemDefinitionId", "Price", "CreateDate", "Type", "SaleRequestId", "State", "Quantity", "Properties" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetTradeArgs), global::Axlebolt.Bolt.Protobuf2.GetTradeArgs.Parser, new[]{ "Id" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetTradesArgs), global::Axlebolt.Bolt.Protobuf2.GetTradesArgs.Parser, new[]{ "ItemDefinitionIds" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreateSaleRequest), global::Axlebolt.Bolt.Protobuf2.CreateSaleRequest.Parser, new[]{ "ItemId", "Price" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreateSaleResponse), global::Axlebolt.Bolt.Protobuf2.CreateSaleResponse.Parser, new[]{ "RequestId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CancelRequestArgs), global::Axlebolt.Bolt.Protobuf2.CancelRequestArgs.Parser, new[]{ "Id" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetTradeOpenPurchaseRequestsArgs), global::Axlebolt.Bolt.Protobuf2.GetTradeOpenPurchaseRequestsArgs.Parser, new[]{ "Id", "Page", "Size" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetClosedRequestsArgs), global::Axlebolt.Bolt.Protobuf2.GetClosedRequestsArgs.Parser, new[]{ "Type", "Reason", "Page", "Size" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreatePurchaseBySaleArgs), global::Axlebolt.Bolt.Protobuf2.CreatePurchaseBySaleArgs.Parser, new[]{ "SaleId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreateSaleRequestArgs), global::Axlebolt.Bolt.Protobuf2.CreateSaleRequestArgs.Parser, new[]{ "ItemId", "Price" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreatePurchaseRequestArgs), global::Axlebolt.Bolt.Protobuf2.CreatePurchaseRequestArgs.Parser, new[]{ "ItemDefinitionId", "Price", "Quantity" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetClosedRequestsCountArgs), global::Axlebolt.Bolt.Protobuf2.GetClosedRequestsCountArgs.Parser, new[]{ "Type", "Reason" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetTradeOpenSaleRequestsArgs), global::Axlebolt.Bolt.Protobuf2.GetTradeOpenSaleRequestsArgs.Parser, new[]{ "Id", "Page", "Size" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnPlayerRequestOpenedEvent), global::Axlebolt.Bolt.Protobuf2.OnPlayerRequestOpenedEvent.Parser, new[]{ "Request" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnPlayerRequestClosedEvent), global::Axlebolt.Bolt.Protobuf2.OnPlayerRequestClosedEvent.Parser, new[]{ "Request", "Item" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnTradeUpdatedEvent), global::Axlebolt.Bolt.Protobuf2.OnTradeUpdatedEvent.Parser, new[]{ "Trade" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnTradeRequestClosedEvent), global::Axlebolt.Bolt.Protobuf2.OnTradeRequestClosedEvent.Parser, new[]{ "Request" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnTradeRequestOpenedEvent), global::Axlebolt.Bolt.Protobuf2.OnTradeRequestOpenedEvent.Parser, new[]{ "Request" }, null, null, null, null)
          }));
    }

  }
  public enum ClosingReason {
    [pbr::OriginalName("NoneReason")] NoneReason = 0,
    [pbr::OriginalName("SuccessTransaction")] SuccessTransaction = 1,
    [pbr::OriginalName("NotEnoughFunds")] NotEnoughFunds = 2,
    [pbr::OriginalName("Cancelled")] Cancelled = 3,
    [pbr::OriginalName("SaleRequestNotFound")] SaleRequestNotFound = 4,
  }

  public enum MarketRequestType {
    [pbr::OriginalName("NoneType")] NoneType = 0,
    [pbr::OriginalName("SaleRequest")] SaleRequest = 1,
    [pbr::OriginalName("PurchaseRequest")] PurchaseRequest = 2,
  }

  public enum ProcessingState {
    [pbr::OriginalName("Creating")] Creating = 0,
    [pbr::OriginalName("Cancelling")] Cancelling = 1,
  }


  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class MarketplaceSettings : pb::IMessage<MarketplaceSettings>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<MarketplaceSettings> _parser = new pb::MessageParser<MarketplaceSettings>(() => new MarketplaceSettings());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<MarketplaceSettings> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public MarketplaceSettings() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public MarketplaceSettings(MarketplaceSettings other) : this() {
      commissionPercent_ = other.commissionPercent_;
      minCommission_ = other.minCommission_;
      currencyId_ = other.currencyId_;
      enabled_ = other.enabled_;
      bannedUntilDate_ = other.bannedUntilDate_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public MarketplaceSettings Clone() {
      return new MarketplaceSettings(this);
    }

    public const int CommissionPercentFieldNumber = 1;
    private float commissionPercent_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float CommissionPercent {
      get { return commissionPercent_; }
      set {
        commissionPercent_ = value;
      }
    }

    public const int MinCommissionFieldNumber = 2;
    private float minCommission_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float MinCommission {
      get { return minCommission_; }
      set {
        minCommission_ = value;
      }
    }

    public const int CurrencyIdFieldNumber = 3;
    private int currencyId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CurrencyId {
      get { return currencyId_; }
      set {
        currencyId_ = value;
      }
    }

    public const int EnabledFieldNumber = 4;
    private bool enabled_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Enabled {
      get { return enabled_; }
      set {
        enabled_ = value;
      }
    }

    public const int BannedUntilDateFieldNumber = 5;
    private long bannedUntilDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long BannedUntilDate {
      get { return bannedUntilDate_; }
      set {
        bannedUntilDate_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as MarketplaceSettings);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(MarketplaceSettings other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(CommissionPercent, other.CommissionPercent)) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(MinCommission, other.MinCommission)) return false;
      if (CurrencyId != other.CurrencyId) return false;
      if (Enabled != other.Enabled) return false;
      if (BannedUntilDate != other.BannedUntilDate) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (CommissionPercent != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(CommissionPercent);
      if (MinCommission != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(MinCommission);
      if (CurrencyId != 0) hash ^= CurrencyId.GetHashCode();
      if (Enabled != false) hash ^= Enabled.GetHashCode();
      if (BannedUntilDate != 0L) hash ^= BannedUntilDate.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (CommissionPercent != 0F) {
        output.WriteRawTag(13);
        output.WriteFloat(CommissionPercent);
      }
      if (MinCommission != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(MinCommission);
      }
      if (CurrencyId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(CurrencyId);
      }
      if (Enabled != false) {
        output.WriteRawTag(32);
        output.WriteBool(Enabled);
      }
      if (BannedUntilDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(BannedUntilDate);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (CommissionPercent != 0F) {
        output.WriteRawTag(13);
        output.WriteFloat(CommissionPercent);
      }
      if (MinCommission != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(MinCommission);
      }
      if (CurrencyId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(CurrencyId);
      }
      if (Enabled != false) {
        output.WriteRawTag(32);
        output.WriteBool(Enabled);
      }
      if (BannedUntilDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(BannedUntilDate);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (CommissionPercent != 0F) {
        size += 1 + 4;
      }
      if (MinCommission != 0F) {
        size += 1 + 4;
      }
      if (CurrencyId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrencyId);
      }
      if (Enabled != false) {
        size += 1 + 1;
      }
      if (BannedUntilDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(BannedUntilDate);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(MarketplaceSettings other) {
      if (other == null) {
        return;
      }
      if (other.CommissionPercent != 0F) {
        CommissionPercent = other.CommissionPercent;
      }
      if (other.MinCommission != 0F) {
        MinCommission = other.MinCommission;
      }
      if (other.CurrencyId != 0) {
        CurrencyId = other.CurrencyId;
      }
      if (other.Enabled != false) {
        Enabled = other.Enabled;
      }
      if (other.BannedUntilDate != 0L) {
        BannedUntilDate = other.BannedUntilDate;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 13: {
            CommissionPercent = input.ReadFloat();
            break;
          }
          case 21: {
            MinCommission = input.ReadFloat();
            break;
          }
          case 24: {
            CurrencyId = input.ReadInt32();
            break;
          }
          case 32: {
            Enabled = input.ReadBool();
            break;
          }
          case 40: {
            BannedUntilDate = input.ReadInt64();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 13: {
            CommissionPercent = input.ReadFloat();
            break;
          }
          case 21: {
            MinCommission = input.ReadFloat();
            break;
          }
          case 24: {
            CurrencyId = input.ReadInt32();
            break;
          }
          case 32: {
            Enabled = input.ReadBool();
            break;
          }
          case 40: {
            BannedUntilDate = input.ReadInt64();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class Trade : pb::IMessage<Trade>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<Trade> _parser = new pb::MessageParser<Trade>(() => new Trade());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<Trade> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Trade() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Trade(Trade other) : this() {
      id_ = other.id_;
      salesCount_ = other.salesCount_;
      purchasesCount_ = other.purchasesCount_;
      salesPrice_ = other.salesPrice_;
      purchasesPrice_ = other.purchasesPrice_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Trade Clone() {
      return new Trade(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int SalesCountFieldNumber = 2;
    private int salesCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int SalesCount {
      get { return salesCount_; }
      set {
        salesCount_ = value;
      }
    }

    public const int PurchasesCountFieldNumber = 3;
    private int purchasesCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int PurchasesCount {
      get { return purchasesCount_; }
      set {
        purchasesCount_ = value;
      }
    }

    public const int SalesPriceFieldNumber = 4;
    private float salesPrice_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float SalesPrice {
      get { return salesPrice_; }
      set {
        salesPrice_ = value;
      }
    }

    public const int PurchasesPriceFieldNumber = 5;
    private float purchasesPrice_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float PurchasesPrice {
      get { return purchasesPrice_; }
      set {
        purchasesPrice_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as Trade);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(Trade other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (SalesCount != other.SalesCount) return false;
      if (PurchasesCount != other.PurchasesCount) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(SalesPrice, other.SalesPrice)) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(PurchasesPrice, other.PurchasesPrice)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (SalesCount != 0) hash ^= SalesCount.GetHashCode();
      if (PurchasesCount != 0) hash ^= PurchasesCount.GetHashCode();
      if (SalesPrice != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(SalesPrice);
      if (PurchasesPrice != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(PurchasesPrice);
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (SalesCount != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(SalesCount);
      }
      if (PurchasesCount != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(PurchasesCount);
      }
      if (SalesPrice != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(SalesPrice);
      }
      if (PurchasesPrice != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(PurchasesPrice);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (SalesCount != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(SalesCount);
      }
      if (PurchasesCount != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(PurchasesCount);
      }
      if (SalesPrice != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(SalesPrice);
      }
      if (PurchasesPrice != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(PurchasesPrice);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (SalesCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(SalesCount);
      }
      if (PurchasesCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(PurchasesCount);
      }
      if (SalesPrice != 0F) {
        size += 1 + 4;
      }
      if (PurchasesPrice != 0F) {
        size += 1 + 4;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(Trade other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.SalesCount != 0) {
        SalesCount = other.SalesCount;
      }
      if (other.PurchasesCount != 0) {
        PurchasesCount = other.PurchasesCount;
      }
      if (other.SalesPrice != 0F) {
        SalesPrice = other.SalesPrice;
      }
      if (other.PurchasesPrice != 0F) {
        PurchasesPrice = other.PurchasesPrice;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            SalesCount = input.ReadInt32();
            break;
          }
          case 24: {
            PurchasesCount = input.ReadInt32();
            break;
          }
          case 37: {
            SalesPrice = input.ReadFloat();
            break;
          }
          case 45: {
            PurchasesPrice = input.ReadFloat();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            SalesCount = input.ReadInt32();
            break;
          }
          case 24: {
            PurchasesCount = input.ReadInt32();
            break;
          }
          case 37: {
            SalesPrice = input.ReadFloat();
            break;
          }
          case 45: {
            PurchasesPrice = input.ReadFloat();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OpenRequest : pb::IMessage<OpenRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OpenRequest> _parser = new pb::MessageParser<OpenRequest>(() => new OpenRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OpenRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OpenRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OpenRequest(OpenRequest other) : this() {
      id_ = other.id_;
      creator_ = other.creator_ != null ? other.creator_.Clone() : null;
      itemDefinitionId_ = other.itemDefinitionId_;
      price_ = other.price_;
      createDate_ = other.createDate_;
      type_ = other.type_;
      quantity_ = other.quantity_;
      properties_ = other.properties_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OpenRequest Clone() {
      return new OpenRequest(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CreatorFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Player creator_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player Creator {
      get { return creator_; }
      set {
        creator_ = value;
      }
    }

    public const int ItemDefinitionIdFieldNumber = 3;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int PriceFieldNumber = 4;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    public const int CreateDateFieldNumber = 5;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int TypeFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.MarketRequestType type_ = global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MarketRequestType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int QuantityFieldNumber = 7;
    private int quantity_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Quantity {
      get { return quantity_; }
      set {
        quantity_ = value;
      }
    }

    public const int PropertiesFieldNumber = 8;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec _map_properties_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser), 66);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OpenRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OpenRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (!object.Equals(Creator, other.Creator)) return false;
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      if (CreateDate != other.CreateDate) return false;
      if (Type != other.Type) return false;
      if (Quantity != other.Quantity) return false;
      if (!Properties.Equals(other.Properties)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (creator_ != null) hash ^= Creator.GetHashCode();
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) hash ^= Type.GetHashCode();
      if (Quantity != 0) hash ^= Quantity.GetHashCode();
      hash ^= Properties.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (creator_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Creator);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Type);
      }
      if (Quantity != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (creator_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Creator);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(37);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Type);
      }
      if (Quantity != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(ref output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (creator_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Creator);
      }
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (Quantity != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Quantity);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OpenRequest other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.creator_ != null) {
        if (creator_ == null) {
          Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Creator.MergeFrom(other.Creator);
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        Type = other.Type;
      }
      if (other.Quantity != 0) {
        Quantity = other.Quantity;
      }
      properties_.MergeFrom(other.properties_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (creator_ == null) {
              Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Creator);
            break;
          }
          case 24: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 37: {
            Price = input.ReadFloat();
            break;
          }
          case 40: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 48: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 56: {
            Quantity = input.ReadInt32();
            break;
          }
          case 66: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (creator_ == null) {
              Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Creator);
            break;
          }
          case 24: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 37: {
            Price = input.ReadFloat();
            break;
          }
          case 40: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 48: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 56: {
            Quantity = input.ReadInt32();
            break;
          }
          case 66: {
            properties_.AddEntriesFrom(ref input, _map_properties_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClosedRequest : pb::IMessage<ClosedRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClosedRequest> _parser = new pb::MessageParser<ClosedRequest>(() => new ClosedRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClosedRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClosedRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClosedRequest(ClosedRequest other) : this() {
      id_ = other.id_;
      originId_ = other.originId_;
      creator_ = other.creator_ != null ? other.creator_.Clone() : null;
      itemDefinitionId_ = other.itemDefinitionId_;
      price_ = other.price_;
      createDate_ = other.createDate_;
      closeDate_ = other.closeDate_;
      type_ = other.type_;
      partner_ = other.partner_ != null ? other.partner_.Clone() : null;
      partnerRequestId_ = other.partnerRequestId_;
      reason_ = other.reason_;
      quantity_ = other.quantity_;
      properties_ = other.properties_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClosedRequest Clone() {
      return new ClosedRequest(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int OriginIdFieldNumber = 2;
    private string originId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string OriginId {
      get { return originId_; }
      set {
        originId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CreatorFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Player creator_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player Creator {
      get { return creator_; }
      set {
        creator_ = value;
      }
    }

    public const int ItemDefinitionIdFieldNumber = 4;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int PriceFieldNumber = 5;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    public const int CreateDateFieldNumber = 6;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int CloseDateFieldNumber = 7;
    private long closeDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CloseDate {
      get { return closeDate_; }
      set {
        closeDate_ = value;
      }
    }

    public const int TypeFieldNumber = 8;
    private global::Axlebolt.Bolt.Protobuf2.MarketRequestType type_ = global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MarketRequestType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int PartnerFieldNumber = 9;
    private global::Axlebolt.Bolt.Protobuf2.Player partner_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player Partner {
      get { return partner_; }
      set {
        partner_ = value;
      }
    }

    public const int PartnerRequestIdFieldNumber = 10;
    private string partnerRequestId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string PartnerRequestId {
      get { return partnerRequestId_; }
      set {
        partnerRequestId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ReasonFieldNumber = 11;
    private global::Axlebolt.Bolt.Protobuf2.ClosingReason reason_ = global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClosingReason Reason {
      get { return reason_; }
      set {
        reason_ = value;
      }
    }

    public const int QuantityFieldNumber = 12;
    private int quantity_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Quantity {
      get { return quantity_; }
      set {
        quantity_ = value;
      }
    }

    public const int PropertiesFieldNumber = 13;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec _map_properties_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser), 106);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClosedRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClosedRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (OriginId != other.OriginId) return false;
      if (!object.Equals(Creator, other.Creator)) return false;
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      if (CreateDate != other.CreateDate) return false;
      if (CloseDate != other.CloseDate) return false;
      if (Type != other.Type) return false;
      if (!object.Equals(Partner, other.Partner)) return false;
      if (PartnerRequestId != other.PartnerRequestId) return false;
      if (Reason != other.Reason) return false;
      if (Quantity != other.Quantity) return false;
      if (!Properties.Equals(other.Properties)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (OriginId.Length != 0) hash ^= OriginId.GetHashCode();
      if (creator_ != null) hash ^= Creator.GetHashCode();
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (CloseDate != 0L) hash ^= CloseDate.GetHashCode();
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) hash ^= Type.GetHashCode();
      if (partner_ != null) hash ^= Partner.GetHashCode();
      if (PartnerRequestId.Length != 0) hash ^= PartnerRequestId.GetHashCode();
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) hash ^= Reason.GetHashCode();
      if (Quantity != 0) hash ^= Quantity.GetHashCode();
      hash ^= Properties.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (OriginId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(OriginId);
      }
      if (creator_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Creator);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(48);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(56);
        output.WriteInt64(CloseDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(64);
        output.WriteEnum((int) Type);
      }
      if (partner_ != null) {
        output.WriteRawTag(74);
        output.WriteMessage(Partner);
      }
      if (PartnerRequestId.Length != 0) {
        output.WriteRawTag(82);
        output.WriteString(PartnerRequestId);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(88);
        output.WriteEnum((int) Reason);
      }
      if (Quantity != 0) {
        output.WriteRawTag(96);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (OriginId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(OriginId);
      }
      if (creator_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Creator);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(48);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(56);
        output.WriteInt64(CloseDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(64);
        output.WriteEnum((int) Type);
      }
      if (partner_ != null) {
        output.WriteRawTag(74);
        output.WriteMessage(Partner);
      }
      if (PartnerRequestId.Length != 0) {
        output.WriteRawTag(82);
        output.WriteString(PartnerRequestId);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(88);
        output.WriteEnum((int) Reason);
      }
      if (Quantity != 0) {
        output.WriteRawTag(96);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(ref output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (OriginId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(OriginId);
      }
      if (creator_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Creator);
      }
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (CloseDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CloseDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (partner_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Partner);
      }
      if (PartnerRequestId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PartnerRequestId);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Reason);
      }
      if (Quantity != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Quantity);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClosedRequest other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.OriginId.Length != 0) {
        OriginId = other.OriginId;
      }
      if (other.creator_ != null) {
        if (creator_ == null) {
          Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Creator.MergeFrom(other.Creator);
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.CloseDate != 0L) {
        CloseDate = other.CloseDate;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        Type = other.Type;
      }
      if (other.partner_ != null) {
        if (partner_ == null) {
          Partner = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Partner.MergeFrom(other.Partner);
      }
      if (other.PartnerRequestId.Length != 0) {
        PartnerRequestId = other.PartnerRequestId;
      }
      if (other.Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        Reason = other.Reason;
      }
      if (other.Quantity != 0) {
        Quantity = other.Quantity;
      }
      properties_.MergeFrom(other.properties_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            OriginId = input.ReadString();
            break;
          }
          case 26: {
            if (creator_ == null) {
              Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Creator);
            break;
          }
          case 32: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 45: {
            Price = input.ReadFloat();
            break;
          }
          case 48: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 56: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 64: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 74: {
            if (partner_ == null) {
              Partner = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Partner);
            break;
          }
          case 82: {
            PartnerRequestId = input.ReadString();
            break;
          }
          case 88: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
          case 96: {
            Quantity = input.ReadInt32();
            break;
          }
          case 106: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            OriginId = input.ReadString();
            break;
          }
          case 26: {
            if (creator_ == null) {
              Creator = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Creator);
            break;
          }
          case 32: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 45: {
            Price = input.ReadFloat();
            break;
          }
          case 48: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 56: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 64: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 74: {
            if (partner_ == null) {
              Partner = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Partner);
            break;
          }
          case 82: {
            PartnerRequestId = input.ReadString();
            break;
          }
          case 88: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
          case 96: {
            Quantity = input.ReadInt32();
            break;
          }
          case 106: {
            properties_.AddEntriesFrom(ref input, _map_properties_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ProcessingRequest : pb::IMessage<ProcessingRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ProcessingRequest> _parser = new pb::MessageParser<ProcessingRequest>(() => new ProcessingRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ProcessingRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ProcessingRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ProcessingRequest(ProcessingRequest other) : this() {
      id_ = other.id_;
      itemDefinitionId_ = other.itemDefinitionId_;
      price_ = other.price_;
      createDate_ = other.createDate_;
      type_ = other.type_;
      saleRequestId_ = other.saleRequestId_;
      state_ = other.state_;
      quantity_ = other.quantity_;
      properties_ = other.properties_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ProcessingRequest Clone() {
      return new ProcessingRequest(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ItemDefinitionIdFieldNumber = 2;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int PriceFieldNumber = 3;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    public const int CreateDateFieldNumber = 4;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int TypeFieldNumber = 5;
    private global::Axlebolt.Bolt.Protobuf2.MarketRequestType type_ = global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MarketRequestType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int SaleRequestIdFieldNumber = 6;
    private string saleRequestId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string SaleRequestId {
      get { return saleRequestId_; }
      set {
        saleRequestId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StateFieldNumber = 7;
    private global::Axlebolt.Bolt.Protobuf2.ProcessingState state_ = global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ProcessingState State {
      get { return state_; }
      set {
        state_ = value;
      }
    }

    public const int QuantityFieldNumber = 8;
    private int quantity_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Quantity {
      get { return quantity_; }
      set {
        quantity_ = value;
      }
    }

    public const int PropertiesFieldNumber = 9;
    private static readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec _map_properties_codec
        = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty.Parser), 74);
    private readonly pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> properties_ = new pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::MapField<string, global::Axlebolt.Bolt.Protobuf2.InventoryItemProperty> Properties {
      get { return properties_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ProcessingRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ProcessingRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      if (CreateDate != other.CreateDate) return false;
      if (Type != other.Type) return false;
      if (SaleRequestId != other.SaleRequestId) return false;
      if (State != other.State) return false;
      if (Quantity != other.Quantity) return false;
      if (!Properties.Equals(other.Properties)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) hash ^= Type.GetHashCode();
      if (SaleRequestId.Length != 0) hash ^= SaleRequestId.GetHashCode();
      if (State != global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating) hash ^= State.GetHashCode();
      if (Quantity != 0) hash ^= Quantity.GetHashCode();
      hash ^= Properties.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(40);
        output.WriteEnum((int) Type);
      }
      if (SaleRequestId.Length != 0) {
        output.WriteRawTag(50);
        output.WriteString(SaleRequestId);
      }
      if (State != global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating) {
        output.WriteRawTag(56);
        output.WriteEnum((int) State);
      }
      if (Quantity != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(29);
        output.WriteFloat(Price);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(40);
        output.WriteEnum((int) Type);
      }
      if (SaleRequestId.Length != 0) {
        output.WriteRawTag(50);
        output.WriteString(SaleRequestId);
      }
      if (State != global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating) {
        output.WriteRawTag(56);
        output.WriteEnum((int) State);
      }
      if (Quantity != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(Quantity);
      }
      properties_.WriteTo(ref output, _map_properties_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (SaleRequestId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SaleRequestId);
      }
      if (State != global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) State);
      }
      if (Quantity != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Quantity);
      }
      size += properties_.CalculateSize(_map_properties_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ProcessingRequest other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        Type = other.Type;
      }
      if (other.SaleRequestId.Length != 0) {
        SaleRequestId = other.SaleRequestId;
      }
      if (other.State != global::Axlebolt.Bolt.Protobuf2.ProcessingState.Creating) {
        State = other.State;
      }
      if (other.Quantity != 0) {
        Quantity = other.Quantity;
      }
      properties_.MergeFrom(other.properties_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 16: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 29: {
            Price = input.ReadFloat();
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 50: {
            SaleRequestId = input.ReadString();
            break;
          }
          case 56: {
            State = (global::Axlebolt.Bolt.Protobuf2.ProcessingState) input.ReadEnum();
            break;
          }
          case 64: {
            Quantity = input.ReadInt32();
            break;
          }
          case 74: {
            properties_.AddEntriesFrom(input, _map_properties_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 16: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 29: {
            Price = input.ReadFloat();
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 50: {
            SaleRequestId = input.ReadString();
            break;
          }
          case 56: {
            State = (global::Axlebolt.Bolt.Protobuf2.ProcessingState) input.ReadEnum();
            break;
          }
          case 64: {
            Quantity = input.ReadInt32();
            break;
          }
          case 74: {
            properties_.AddEntriesFrom(ref input, _map_properties_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetTradeArgs : pb::IMessage<GetTradeArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetTradeArgs> _parser = new pb::MessageParser<GetTradeArgs>(() => new GetTradeArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetTradeArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeArgs(GetTradeArgs other) : this() {
      id_ = other.id_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeArgs Clone() {
      return new GetTradeArgs(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetTradeArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetTradeArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetTradeArgs other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetTradesArgs : pb::IMessage<GetTradesArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetTradesArgs> _parser = new pb::MessageParser<GetTradesArgs>(() => new GetTradesArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetTradesArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradesArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradesArgs(GetTradesArgs other) : this() {
      itemDefinitionIds_ = other.itemDefinitionIds_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradesArgs Clone() {
      return new GetTradesArgs(this);
    }

    public const int ItemDefinitionIdsFieldNumber = 1;
    private static readonly pb::FieldCodec<int> _repeated_itemDefinitionIds_codec
        = pb::FieldCodec.ForInt32(10);
    private readonly pbc::RepeatedField<int> itemDefinitionIds_ = new pbc::RepeatedField<int>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<int> ItemDefinitionIds {
      get { return itemDefinitionIds_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetTradesArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetTradesArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!itemDefinitionIds_.Equals(other.itemDefinitionIds_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= itemDefinitionIds_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      itemDefinitionIds_.WriteTo(output, _repeated_itemDefinitionIds_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      itemDefinitionIds_.WriteTo(ref output, _repeated_itemDefinitionIds_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      size += itemDefinitionIds_.CalculateSize(_repeated_itemDefinitionIds_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetTradesArgs other) {
      if (other == null) {
        return;
      }
      itemDefinitionIds_.Add(other.itemDefinitionIds_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10:
          case 8: {
            itemDefinitionIds_.AddEntriesFrom(input, _repeated_itemDefinitionIds_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10:
          case 8: {
            itemDefinitionIds_.AddEntriesFrom(ref input, _repeated_itemDefinitionIds_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CreateSaleRequest : pb::IMessage<CreateSaleRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreateSaleRequest> _parser = new pb::MessageParser<CreateSaleRequest>(() => new CreateSaleRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CreateSaleRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequest(CreateSaleRequest other) : this() {
      itemId_ = other.itemId_;
      price_ = other.price_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequest Clone() {
      return new CreateSaleRequest(this);
    }

    public const int ItemIdFieldNumber = 1;
    private int itemId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemId {
      get { return itemId_; }
      set {
        itemId_ = value;
      }
    }

    public const int PriceFieldNumber = 2;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CreateSaleRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CreateSaleRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (ItemId != other.ItemId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (ItemId != 0) hash ^= ItemId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (ItemId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (ItemId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (ItemId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CreateSaleRequest other) {
      if (other == null) {
        return;
      }
      if (other.ItemId != 0) {
        ItemId = other.ItemId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            ItemId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            ItemId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CreateSaleResponse : pb::IMessage<CreateSaleResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreateSaleResponse> _parser = new pb::MessageParser<CreateSaleResponse>(() => new CreateSaleResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CreateSaleResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleResponse(CreateSaleResponse other) : this() {
      requestId_ = other.requestId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleResponse Clone() {
      return new CreateSaleResponse(this);
    }

    public const int RequestIdFieldNumber = 1;
    private string requestId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string RequestId {
      get { return requestId_; }
      set {
        requestId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CreateSaleResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CreateSaleResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (RequestId != other.RequestId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (RequestId.Length != 0) hash ^= RequestId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (RequestId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(RequestId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CreateSaleResponse other) {
      if (other == null) {
        return;
      }
      if (other.RequestId.Length != 0) {
        RequestId = other.RequestId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CancelRequestArgs : pb::IMessage<CancelRequestArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CancelRequestArgs> _parser = new pb::MessageParser<CancelRequestArgs>(() => new CancelRequestArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CancelRequestArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[9]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CancelRequestArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CancelRequestArgs(CancelRequestArgs other) : this() {
      id_ = other.id_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CancelRequestArgs Clone() {
      return new CancelRequestArgs(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CancelRequestArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CancelRequestArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CancelRequestArgs other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetTradeOpenPurchaseRequestsArgs : pb::IMessage<GetTradeOpenPurchaseRequestsArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetTradeOpenPurchaseRequestsArgs> _parser = new pb::MessageParser<GetTradeOpenPurchaseRequestsArgs>(() => new GetTradeOpenPurchaseRequestsArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetTradeOpenPurchaseRequestsArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[10]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenPurchaseRequestsArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenPurchaseRequestsArgs(GetTradeOpenPurchaseRequestsArgs other) : this() {
      id_ = other.id_;
      page_ = other.page_;
      size_ = other.size_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenPurchaseRequestsArgs Clone() {
      return new GetTradeOpenPurchaseRequestsArgs(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int PageFieldNumber = 2;
    private int page_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Page {
      get { return page_; }
      set {
        page_ = value;
      }
    }

    public const int SizeFieldNumber = 3;
    private int size_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Size {
      get { return size_; }
      set {
        size_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetTradeOpenPurchaseRequestsArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetTradeOpenPurchaseRequestsArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Page != other.Page) return false;
      if (Size != other.Size) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (Page != 0) hash ^= Page.GetHashCode();
      if (Size != 0) hash ^= Size.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Page != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Page != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (Page != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Page);
      }
      if (Size != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Size);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetTradeOpenPurchaseRequestsArgs other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.Page != 0) {
        Page = other.Page;
      }
      if (other.Size != 0) {
        Size = other.Size;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            Page = input.ReadInt32();
            break;
          }
          case 24: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            Page = input.ReadInt32();
            break;
          }
          case 24: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClosedRequestsArgs : pb::IMessage<GetClosedRequestsArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetClosedRequestsArgs> _parser = new pb::MessageParser<GetClosedRequestsArgs>(() => new GetClosedRequestsArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetClosedRequestsArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[11]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsArgs(GetClosedRequestsArgs other) : this() {
      type_ = other.type_;
      reason_ = other.reason_;
      page_ = other.page_;
      size_ = other.size_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsArgs Clone() {
      return new GetClosedRequestsArgs(this);
    }

    public const int TypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.MarketRequestType type_ = global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MarketRequestType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int ReasonFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.ClosingReason reason_ = global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClosingReason Reason {
      get { return reason_; }
      set {
        reason_ = value;
      }
    }

    public const int PageFieldNumber = 3;
    private int page_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Page {
      get { return page_; }
      set {
        page_ = value;
      }
    }

    public const int SizeFieldNumber = 4;
    private int size_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Size {
      get { return size_; }
      set {
        size_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetClosedRequestsArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetClosedRequestsArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Type != other.Type) return false;
      if (Reason != other.Reason) return false;
      if (Page != other.Page) return false;
      if (Size != other.Size) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) hash ^= Type.GetHashCode();
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) hash ^= Reason.GetHashCode();
      if (Page != 0) hash ^= Page.GetHashCode();
      if (Size != 0) hash ^= Size.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Reason);
      }
      if (Page != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Reason);
      }
      if (Page != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Reason);
      }
      if (Page != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Page);
      }
      if (Size != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Size);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetClosedRequestsArgs other) {
      if (other == null) {
        return;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        Type = other.Type;
      }
      if (other.Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        Reason = other.Reason;
      }
      if (other.Page != 0) {
        Page = other.Page;
      }
      if (other.Size != 0) {
        Size = other.Size;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 16: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
          case 24: {
            Page = input.ReadInt32();
            break;
          }
          case 32: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 16: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
          case 24: {
            Page = input.ReadInt32();
            break;
          }
          case 32: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CreatePurchaseBySaleArgs : pb::IMessage<CreatePurchaseBySaleArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreatePurchaseBySaleArgs> _parser = new pb::MessageParser<CreatePurchaseBySaleArgs>(() => new CreatePurchaseBySaleArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CreatePurchaseBySaleArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[12]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseBySaleArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseBySaleArgs(CreatePurchaseBySaleArgs other) : this() {
      saleId_ = other.saleId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseBySaleArgs Clone() {
      return new CreatePurchaseBySaleArgs(this);
    }

    public const int SaleIdFieldNumber = 1;
    private string saleId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string SaleId {
      get { return saleId_; }
      set {
        saleId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CreatePurchaseBySaleArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CreatePurchaseBySaleArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (SaleId != other.SaleId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (SaleId.Length != 0) hash ^= SaleId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (SaleId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(SaleId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (SaleId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(SaleId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (SaleId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SaleId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CreatePurchaseBySaleArgs other) {
      if (other == null) {
        return;
      }
      if (other.SaleId.Length != 0) {
        SaleId = other.SaleId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            SaleId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            SaleId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CreateSaleRequestArgs : pb::IMessage<CreateSaleRequestArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreateSaleRequestArgs> _parser = new pb::MessageParser<CreateSaleRequestArgs>(() => new CreateSaleRequestArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CreateSaleRequestArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[13]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequestArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequestArgs(CreateSaleRequestArgs other) : this() {
      itemId_ = other.itemId_;
      price_ = other.price_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreateSaleRequestArgs Clone() {
      return new CreateSaleRequestArgs(this);
    }

    public const int ItemIdFieldNumber = 1;
    private int itemId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemId {
      get { return itemId_; }
      set {
        itemId_ = value;
      }
    }

    public const int PriceFieldNumber = 2;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CreateSaleRequestArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CreateSaleRequestArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (ItemId != other.ItemId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (ItemId != 0) hash ^= ItemId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (ItemId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (ItemId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (ItemId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CreateSaleRequestArgs other) {
      if (other == null) {
        return;
      }
      if (other.ItemId != 0) {
        ItemId = other.ItemId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            ItemId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            ItemId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class CreatePurchaseRequestArgs : pb::IMessage<CreatePurchaseRequestArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreatePurchaseRequestArgs> _parser = new pb::MessageParser<CreatePurchaseRequestArgs>(() => new CreatePurchaseRequestArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<CreatePurchaseRequestArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[14]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseRequestArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseRequestArgs(CreatePurchaseRequestArgs other) : this() {
      itemDefinitionId_ = other.itemDefinitionId_;
      price_ = other.price_;
      quantity_ = other.quantity_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public CreatePurchaseRequestArgs Clone() {
      return new CreatePurchaseRequestArgs(this);
    }

    public const int ItemDefinitionIdFieldNumber = 1;
    private int itemDefinitionId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ItemDefinitionId {
      get { return itemDefinitionId_; }
      set {
        itemDefinitionId_ = value;
      }
    }

    public const int PriceFieldNumber = 2;
    private float price_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public float Price {
      get { return price_; }
      set {
        price_ = value;
      }
    }

    public const int QuantityFieldNumber = 3;
    private int quantity_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Quantity {
      get { return quantity_; }
      set {
        quantity_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as CreatePurchaseRequestArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(CreatePurchaseRequestArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (ItemDefinitionId != other.ItemDefinitionId) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(Price, other.Price)) return false;
      if (Quantity != other.Quantity) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (ItemDefinitionId != 0) hash ^= ItemDefinitionId.GetHashCode();
      if (Price != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(Price);
      if (Quantity != 0) hash ^= Quantity.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (Quantity != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Quantity);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (ItemDefinitionId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ItemDefinitionId);
      }
      if (Price != 0F) {
        output.WriteRawTag(21);
        output.WriteFloat(Price);
      }
      if (Quantity != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Quantity);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (ItemDefinitionId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ItemDefinitionId);
      }
      if (Price != 0F) {
        size += 1 + 4;
      }
      if (Quantity != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Quantity);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(CreatePurchaseRequestArgs other) {
      if (other == null) {
        return;
      }
      if (other.ItemDefinitionId != 0) {
        ItemDefinitionId = other.ItemDefinitionId;
      }
      if (other.Price != 0F) {
        Price = other.Price;
      }
      if (other.Quantity != 0) {
        Quantity = other.Quantity;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
          case 24: {
            Quantity = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            ItemDefinitionId = input.ReadInt32();
            break;
          }
          case 21: {
            Price = input.ReadFloat();
            break;
          }
          case 24: {
            Quantity = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetClosedRequestsCountArgs : pb::IMessage<GetClosedRequestsCountArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetClosedRequestsCountArgs> _parser = new pb::MessageParser<GetClosedRequestsCountArgs>(() => new GetClosedRequestsCountArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetClosedRequestsCountArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[15]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsCountArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsCountArgs(GetClosedRequestsCountArgs other) : this() {
      type_ = other.type_;
      reason_ = other.reason_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetClosedRequestsCountArgs Clone() {
      return new GetClosedRequestsCountArgs(this);
    }

    public const int TypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.MarketRequestType type_ = global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MarketRequestType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int ReasonFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.ClosingReason reason_ = global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClosingReason Reason {
      get { return reason_; }
      set {
        reason_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetClosedRequestsCountArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetClosedRequestsCountArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Type != other.Type) return false;
      if (Reason != other.Reason) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) hash ^= Type.GetHashCode();
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) hash ^= Reason.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Reason);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        output.WriteRawTag(8);
        output.WriteEnum((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Reason);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Reason);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetClosedRequestsCountArgs other) {
      if (other == null) {
        return;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.MarketRequestType.NoneType) {
        Type = other.Type;
      }
      if (other.Reason != global::Axlebolt.Bolt.Protobuf2.ClosingReason.NoneReason) {
        Reason = other.Reason;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 16: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Type = (global::Axlebolt.Bolt.Protobuf2.MarketRequestType) input.ReadEnum();
            break;
          }
          case 16: {
            Reason = (global::Axlebolt.Bolt.Protobuf2.ClosingReason) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class GetTradeOpenSaleRequestsArgs : pb::IMessage<GetTradeOpenSaleRequestsArgs>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetTradeOpenSaleRequestsArgs> _parser = new pb::MessageParser<GetTradeOpenSaleRequestsArgs>(() => new GetTradeOpenSaleRequestsArgs());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<GetTradeOpenSaleRequestsArgs> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[16]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenSaleRequestsArgs() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenSaleRequestsArgs(GetTradeOpenSaleRequestsArgs other) : this() {
      id_ = other.id_;
      page_ = other.page_;
      size_ = other.size_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public GetTradeOpenSaleRequestsArgs Clone() {
      return new GetTradeOpenSaleRequestsArgs(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int PageFieldNumber = 2;
    private int page_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Page {
      get { return page_; }
      set {
        page_ = value;
      }
    }

    public const int SizeFieldNumber = 3;
    private int size_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Size {
      get { return size_; }
      set {
        size_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as GetTradeOpenSaleRequestsArgs);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(GetTradeOpenSaleRequestsArgs other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Page != other.Page) return false;
      if (Size != other.Size) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (Page != 0) hash ^= Page.GetHashCode();
      if (Size != 0) hash ^= Size.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Page != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Page != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(Page);
      }
      if (Size != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Size);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (Page != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Page);
      }
      if (Size != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Size);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(GetTradeOpenSaleRequestsArgs other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.Page != 0) {
        Page = other.Page;
      }
      if (other.Size != 0) {
        Size = other.Size;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            Page = input.ReadInt32();
            break;
          }
          case 24: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 16: {
            Page = input.ReadInt32();
            break;
          }
          case 24: {
            Size = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnPlayerRequestOpenedEvent : pb::IMessage<OnPlayerRequestOpenedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnPlayerRequestOpenedEvent> _parser = new pb::MessageParser<OnPlayerRequestOpenedEvent>(() => new OnPlayerRequestOpenedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnPlayerRequestOpenedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[17]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestOpenedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestOpenedEvent(OnPlayerRequestOpenedEvent other) : this() {
      request_ = other.request_ != null ? other.request_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestOpenedEvent Clone() {
      return new OnPlayerRequestOpenedEvent(this);
    }

    public const int RequestFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.OpenRequest request_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.OpenRequest Request {
      get { return request_; }
      set {
        request_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnPlayerRequestOpenedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnPlayerRequestOpenedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Request, other.Request)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (request_ != null) hash ^= Request.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (request_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Request);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnPlayerRequestOpenedEvent other) {
      if (other == null) {
        return;
      }
      if (other.request_ != null) {
        if (request_ == null) {
          Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
        }
        Request.MergeFrom(other.Request);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnPlayerRequestClosedEvent : pb::IMessage<OnPlayerRequestClosedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnPlayerRequestClosedEvent> _parser = new pb::MessageParser<OnPlayerRequestClosedEvent>(() => new OnPlayerRequestClosedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnPlayerRequestClosedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[18]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestClosedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestClosedEvent(OnPlayerRequestClosedEvent other) : this() {
      request_ = other.request_ != null ? other.request_.Clone() : null;
      item_ = other.item_ != null ? other.item_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerRequestClosedEvent Clone() {
      return new OnPlayerRequestClosedEvent(this);
    }

    public const int RequestFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.ClosedRequest request_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClosedRequest Request {
      get { return request_; }
      set {
        request_ = value;
      }
    }

    public const int ItemFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.InventoryItem item_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.InventoryItem Item {
      get { return item_; }
      set {
        item_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnPlayerRequestClosedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnPlayerRequestClosedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Request, other.Request)) return false;
      if (!object.Equals(Item, other.Item)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (request_ != null) hash ^= Request.GetHashCode();
      if (item_ != null) hash ^= Item.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (item_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Item);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (item_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Item);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (request_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Request);
      }
      if (item_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Item);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnPlayerRequestClosedEvent other) {
      if (other == null) {
        return;
      }
      if (other.request_ != null) {
        if (request_ == null) {
          Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
        }
        Request.MergeFrom(other.Request);
      }
      if (other.item_ != null) {
        if (item_ == null) {
          Item = new global::Axlebolt.Bolt.Protobuf2.InventoryItem();
        }
        Item.MergeFrom(other.Item);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
            }
            input.ReadMessage(Request);
            break;
          }
          case 18: {
            if (item_ == null) {
              Item = new global::Axlebolt.Bolt.Protobuf2.InventoryItem();
            }
            input.ReadMessage(Item);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
            }
            input.ReadMessage(Request);
            break;
          }
          case 18: {
            if (item_ == null) {
              Item = new global::Axlebolt.Bolt.Protobuf2.InventoryItem();
            }
            input.ReadMessage(Item);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnTradeUpdatedEvent : pb::IMessage<OnTradeUpdatedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnTradeUpdatedEvent> _parser = new pb::MessageParser<OnTradeUpdatedEvent>(() => new OnTradeUpdatedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnTradeUpdatedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[19]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeUpdatedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeUpdatedEvent(OnTradeUpdatedEvent other) : this() {
      trade_ = other.trade_ != null ? other.trade_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeUpdatedEvent Clone() {
      return new OnTradeUpdatedEvent(this);
    }

    public const int TradeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Trade trade_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Trade Trade {
      get { return trade_; }
      set {
        trade_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnTradeUpdatedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnTradeUpdatedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Trade, other.Trade)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (trade_ != null) hash ^= Trade.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (trade_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Trade);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (trade_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Trade);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (trade_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Trade);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnTradeUpdatedEvent other) {
      if (other == null) {
        return;
      }
      if (other.trade_ != null) {
        if (trade_ == null) {
          Trade = new global::Axlebolt.Bolt.Protobuf2.Trade();
        }
        Trade.MergeFrom(other.Trade);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (trade_ == null) {
              Trade = new global::Axlebolt.Bolt.Protobuf2.Trade();
            }
            input.ReadMessage(Trade);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (trade_ == null) {
              Trade = new global::Axlebolt.Bolt.Protobuf2.Trade();
            }
            input.ReadMessage(Trade);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnTradeRequestClosedEvent : pb::IMessage<OnTradeRequestClosedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnTradeRequestClosedEvent> _parser = new pb::MessageParser<OnTradeRequestClosedEvent>(() => new OnTradeRequestClosedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnTradeRequestClosedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[20]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestClosedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestClosedEvent(OnTradeRequestClosedEvent other) : this() {
      request_ = other.request_ != null ? other.request_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestClosedEvent Clone() {
      return new OnTradeRequestClosedEvent(this);
    }

    public const int RequestFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.ClosedRequest request_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClosedRequest Request {
      get { return request_; }
      set {
        request_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnTradeRequestClosedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnTradeRequestClosedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Request, other.Request)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (request_ != null) hash ^= Request.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (request_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Request);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnTradeRequestClosedEvent other) {
      if (other == null) {
        return;
      }
      if (other.request_ != null) {
        if (request_ == null) {
          Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
        }
        Request.MergeFrom(other.Request);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.ClosedRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnTradeRequestOpenedEvent : pb::IMessage<OnTradeRequestOpenedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnTradeRequestOpenedEvent> _parser = new pb::MessageParser<OnTradeRequestOpenedEvent>(() => new OnTradeRequestOpenedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnTradeRequestOpenedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MarketplaceMessageReflection.Descriptor.MessageTypes[21]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestOpenedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestOpenedEvent(OnTradeRequestOpenedEvent other) : this() {
      request_ = other.request_ != null ? other.request_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnTradeRequestOpenedEvent Clone() {
      return new OnTradeRequestOpenedEvent(this);
    }

    public const int RequestFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.OpenRequest request_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.OpenRequest Request {
      get { return request_; }
      set {
        request_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnTradeRequestOpenedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnTradeRequestOpenedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Request, other.Request)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (request_ != null) hash ^= Request.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (request_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Request);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (request_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Request);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnTradeRequestOpenedEvent other) {
      if (other == null) {
        return;
      }
      if (other.request_ != null) {
        if (request_ == null) {
          Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
        }
        Request.MergeFrom(other.Request);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (request_ == null) {
              Request = new global::Axlebolt.Bolt.Protobuf2.OpenRequest();
            }
            input.ReadMessage(Request);
            break;
          }
        }
      }
    }
    #endif

  }


}

