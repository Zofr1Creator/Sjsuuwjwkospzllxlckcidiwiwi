#pragma warning disable 1591, 0612, 3021, 8981

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class ClanMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static ClanMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChFDbGFuTWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIa",
            "FEZyaWVuZHNNZXNzYWdlLnByb3RvGhVDdXJyZW5jeU1lc3NhZ2UucHJvdG8a",
            "E1BsYXllck1lc3NhZ2UucHJvdG8iygEKBENsYW4SCgoCaWQYASABKAkSDAoE",
            "bmFtZRgCIAEoCRILCgN0YWcYAyABKAkSMwoIY2xhblR5cGUYBCABKA4yIS5B",
            "eGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuVHlwZRIQCghhdmF0YXJJZBgF",
            "IAEoCRISCgpjcmVhdGVEYXRlGAYgASgDEhMKC21lYmVyc0NvdW50GAcgASgF",
            "EhYKDm1heE1lbWJlckNvdW50GAggASgFEhMKC2Rlc2NyaXB0aW9uGAkgASgJ",
            "In0KCkNsYW5NZW1iZXISOwoMUGxheWVyRnJpZW5kGAEgASgLMiUuQXhsZWJv",
            "bHQuQm9sdC5Qcm90b2J1ZjIuUGxheWVyRnJpZW5kEg4KBmNsYW5JZBgCIAEo",
            "CRIOCgZyb2xlSWQYAyABKAUSEgoKY3JlYXRlRGF0ZRgEIAEoAyKXAQoOQ2xh",
            "bk1lbWJlclJvbGUSCgoCaWQYASABKAUSDAoEbmFtZRgCIAEoCRINCgVsZXZl",
            "bBgDIAEoBRIUCgxkZXNjcmlwcHRpb24YBCABKAkSRgoLcGVybWlzc2lvbnMY",
            "BSADKA4yMS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuTWVtYmVyUm9s",
            "ZVBlcm1pc3Npb24imwIKDENsYW5TZXR0aW5ncxIbChNpbml0aWFsTWVtYmVy",
            "c0NvdW50GAEgASgFEhkKEW1lbWJlcnNDb3VudExpbWl0GAIgASgFEkgKF21l",
            "bWJlcnNDb3VudFVwZ3JhZGVDb3N0GAMgASgLMicuQXhsZWJvbHQuQm9sdC5Q",
            "cm90b2J1ZjIuQ3VycmVuY3lBbW91bnQSSAoXY2hhbmdlQ2xhbk5hbWVPclRh",
            "Z0Nvc3QYBCABKAsyJy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DdXJyZW5j",
            "eUFtb3VudBI/Cg5jbGFuQ3JlYXRlQ29zdBgFIAEoCzInLkF4bGVib2x0LkJv",
            "bHQuUHJvdG9idWYyLkN1cnJlbmN5QW1vdW50IuQBCg9DbGFuSm9pblJlcXVl",
            "c3QSCgoCaWQYASABKAkSKwoEY2xhbhgCIAEoCzIdLkF4bGVib2x0LkJvbHQu",
            "UHJvdG9idWYyLkNsYW4SNgoNcmVxdWVzdFNlbmRlchgDIAEoCzIfLkF4bGVi",
            "b2x0LkJvbHQuUHJvdG9idWYyLlBsYXllchISCgpjcmVhdGVEYXRlGAQgASgD",
            "EhEKCWNsb3NlRGF0ZRgFIAEoAxI5CgtyZXF1ZXN0VHlwZRgGIAEoDjIkLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLlJlcXVlc3RUeXBlIp4CChFDbGFuSW52",
            "aXRlUmVxdWVzdBIKCgJpZBgBIAEoCRIrCgRjbGFuGAIgASgLMh0uQXhsZWJv",
            "bHQuQm9sdC5Qcm90b2J1ZjIuQ2xhbhI2Cg1yZXF1ZXN0U2VuZGVyGAMgASgL",
            "Mh8uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUGxheWVyEhIKCmNyZWF0ZURh",
            "dGUYBCABKAMSEQoJY2xvc2VEYXRlGAUgASgDEjkKC3JlcXVlc3RUeXBlGAYg",
            "ASgOMiQuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUmVxdWVzdFR5cGUSNgoN",
            "aW52aXRlZFBsYXllchgHIAEoCzIfLkF4bGVib2x0LkJvbHQuUHJvdG9idWYy",
            "LlBsYXllciJHChlPbkFzc2lnbmVkTGVhZGVyUm9sZUV2ZW50EhUKDW9sZExl",
            "YWRlclJvbGUYASABKAUSEwoLbmV3TGVhZGVySWQYAiABKAkiRQoTT25LaWNr",
            "ZWRNZW1iZXJFdmVudBIWCg5raWNrZXJNZW1iZXJJZBgBIAEoCRIWCg5raWNr",
            "ZWRNZW1iZXJJZBgCIAEoCSJLChFPbkNsYW5UeXBlQ2hhbmdlZBI2CgtuZXdD",
            "bGFuVHlwZRgBIAEoDjIhLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkNsYW5U",
            "eXBlIq4BChlPbk1lbWJlckpvaW5lZFRvQ2xhbkV2ZW50EjcKCmNsYW5NZW1i",
            "ZXIYASABKAsyIy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuTWVtYmVy",
            "EjsKDGpvaW5DbGFuVHlwZRgCIAEoDjIlLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLkpvaW5DbGFuVHlwZRIbChNqb2luUmVxdWVzdEFjY2VwdG9yGAMgASgJ",
            "Il8KE09uQXNzaWduZWRSb2xlRXZlbnQSEQoJbmV3Um9sZUlkGAEgASgFEhoK",
            "EmFzc2lnbmF0b3JNZW1iZXJJZBgCIAEoCRIZChFhc3NpZ25pbmdNZW1iZXJJ",
            "ZBgDIAEoCSJCChNPbkpvaW5lZFRvQ2xhbkV2ZW50EisKBGNsYW4YASABKAsy",
            "HS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuIiIKDk9uTGVmdEZyb21D",
            "bGFuEhAKCG1lbWJlcklkGAEgASgJImYKGU9uUGxheWVyQXR0cmlidXRlc0No",
            "YW5nZWQSEAoIcGxheWVySWQYASABKAkSNwoKYXR0cmlidXRlcxgCIAEoCzIj",
            "LkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkF0dHJpYnV0ZXMihwEKFE9uSW52",
            "aXRlZFRvQ2xhbkV2ZW50EhEKCXJlcXVlc3RJZBgBIAEoCRIrCgRjbGFuGAIg",
            "ASgLMh0uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQ2xhbhIvCgZwbGF5ZXIY",
            "AyABKAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXIiJgoNT25L",
            "aWNrZWRFdmVudBIVCg1raWNraW5nUmVhc29uGAEgASgJIj4KHk9uQ2xhbk1h",
            "eE1lbWJlcnNDb3VudEluY3JlYXNlZBIcChRuZXdNZW1iZXJzQ291bnRWYWx1",
            "ZRgBIAEoBSJCChdPbkNsYW5UYWdBbmROYW1lQ2hhbmdlZBISCgpuZXdDbGFu",
            "VGFnGAEgASgJEhMKC25ld0NsYW5OYW1lGAIgASgJIl0KF09uSm9pblJlcXVl",
            "c3RUYWtlbkV2ZW50EhEKCXJlcXVlc3RJZBgBIAEoCRIvCgZwbGF5ZXIYAiAB",
            "KAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXIi1AEKDkNsYW5M",
            "b2dNZXNzYWdlEhMKC2NsYW5Mb2dUeXBlGAEgASgFEhcKD2NoYW5nZWRDbGFu",
            "VHlwZRgCIAEoBRIXCg9jaGFuZ2VkQ2xhbk5hbWUYAyABKAkSFgoOY2hhbmdl",
            "ZENsYW5UYWcYBCABKAkSFQoNcHJpbWFyeU1lbWJlchgFIAEoCRIXCg9zZWNv",
            "bmRhcnlNZW1iZXIYBiABKAkSHQoVY2hhbmdlZE1heE1lbWJlckNvdW50GAcg",
            "ASgFEhQKDGFzc2lnbmVkUm9sZRgIIAEoBSI0Cg9DbGFuQ2hhdE1lc3NhZ2US",
            "EAoIc2VuZGVySWQYASABKAkSDwoHbWVzc2FnZRgCIAEoCSLnAQoPQ2xhblVz",
            "ZXJNZXNzYWdlEgoKAmlkGAEgASgJEhEKCXRpbWVzdGFtcBgCIAEoAxI5Cgtt",
            "ZXNzYWdlVHlwZRgDIAEoDjIkLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLk1l",
            "c3NhZ2VUeXBlEj0KC2NoYXRNZXNzYWdlGAQgASgLMiguQXhsZWJvbHQuQm9s",
            "dC5Qcm90b2J1ZjIuQ2xhbkNoYXRNZXNzYWdlEjsKCmxvZ01lc3NhZ2UYBSAB",
            "KAsyJy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5DbGFuTG9nTWVzc2FnZSox",
            "CghDbGFuVHlwZRIKCgZDbG9zZWQQABINCglCeVJlcXVlc3QQARIKCgZPcGVu",
            "ZWQQAipGCgtSZXF1ZXN0VHlwZRITCg9Ob25lVHlwZVJlcXVlc3QQABIPCgtP",
            "cGVuUmVxdWVzdBABEhEKDUNsb3NlZFJlcXVlc3QQAirvAQoYQ2xhbk1lbWJl",
            "clJvbGVQZXJtaXNzaW9uEhYKEkNoYW5nZUNsYW5TZXR0aW5ncxAAEhAKDEFj",
            "Y2VwdE1lbWJlchABEhAKDEludml0ZU1lbWJlchACEhIKDktpY2tNZW1iZXJM",
            "ZXNzEAMSEwoPS2lja01lbWJlckVxdWFsEAQSEgoOQXNzaWduUm9sZUxlc3MQ",
            "BRITCg9Bc3NpZ25Sb2xlRXF1YWwQBhIUChBDcmVhdGVDbGFuQmF0dGxlEAcS",
            "EgoOSm9pbkNsYW5CYXR0bGUQCBIbChdVcGdyYWRlQ2xhbk1lbWJlcnNDb3Vu",
            "dBAJKmgKDEpvaW5DbGFuVHlwZRIZChVCeUFjY2VwdEludml0ZVJlcXVlc3QQ",
            "ABIXChNCeUFjY2VwdEpvaW5SZXF1ZXN0EAESEgoOSm9pblRvT3BlbkNsYW4Q",
            "AhIQCgxOb25lSm9pblR5cGUQAyo8CgtNZXNzYWdlVHlwZRIMCghOb25lVHlw",
            "ZRAAEg8KC0NoYXRNZXNzYWdlEAESDgoKTG9nTWVzc2FnZRACYgZwcm90bzM="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.FriendsMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.CurrencyMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.ClanType), typeof(global::Axlebolt.Bolt.Protobuf2.RequestType), typeof(global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission), typeof(global::Axlebolt.Bolt.Protobuf2.JoinClanType), typeof(global::Axlebolt.Bolt.Protobuf2.MessageType), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Clan), global::Axlebolt.Bolt.Protobuf2.Clan.Parser, new[]{ "Id", "Name", "Tag", "ClanType", "AvatarId", "CreateDate", "MebersCount", "MaxMemberCount", "Description" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanMember), global::Axlebolt.Bolt.Protobuf2.ClanMember.Parser, new[]{ "PlayerFriend", "ClanId", "RoleId", "CreateDate" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanMemberRole), global::Axlebolt.Bolt.Protobuf2.ClanMemberRole.Parser, new[]{ "Id", "Name", "Level", "Descripption", "Permissions" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanSettings), global::Axlebolt.Bolt.Protobuf2.ClanSettings.Parser, new[]{ "InitialMembersCount", "MembersCountLimit", "MembersCountUpgradeCost", "ChangeClanNameOrTagCost", "ClanCreateCost" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanJoinRequest), global::Axlebolt.Bolt.Protobuf2.ClanJoinRequest.Parser, new[]{ "Id", "Clan", "RequestSender", "CreateDate", "CloseDate", "RequestType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanInviteRequest), global::Axlebolt.Bolt.Protobuf2.ClanInviteRequest.Parser, new[]{ "Id", "Clan", "RequestSender", "CreateDate", "CloseDate", "RequestType", "InvitedPlayer" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnAssignedLeaderRoleEvent), global::Axlebolt.Bolt.Protobuf2.OnAssignedLeaderRoleEvent.Parser, new[]{ "OldLeaderRole", "NewLeaderId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnKickedMemberEvent), global::Axlebolt.Bolt.Protobuf2.OnKickedMemberEvent.Parser, new[]{ "KickerMemberId", "KickedMemberId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnClanTypeChanged), global::Axlebolt.Bolt.Protobuf2.OnClanTypeChanged.Parser, new[]{ "NewClanType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnMemberJoinedToClanEvent), global::Axlebolt.Bolt.Protobuf2.OnMemberJoinedToClanEvent.Parser, new[]{ "ClanMember", "JoinClanType", "JoinRequestAcceptor" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnAssignedRoleEvent), global::Axlebolt.Bolt.Protobuf2.OnAssignedRoleEvent.Parser, new[]{ "NewRoleId", "AssignatorMemberId", "AssigningMemberId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnJoinedToClanEvent), global::Axlebolt.Bolt.Protobuf2.OnJoinedToClanEvent.Parser, new[]{ "Clan" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLeftFromClan), global::Axlebolt.Bolt.Protobuf2.OnLeftFromClan.Parser, new[]{ "MemberId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnPlayerAttributesChanged), global::Axlebolt.Bolt.Protobuf2.OnPlayerAttributesChanged.Parser, new[]{ "PlayerId", "Attributes" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnInvitedToClanEvent), global::Axlebolt.Bolt.Protobuf2.OnInvitedToClanEvent.Parser, new[]{ "RequestId", "Clan", "Player" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnKickedEvent), global::Axlebolt.Bolt.Protobuf2.OnKickedEvent.Parser, new[]{ "KickingReason" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnClanMaxMembersCountIncreased), global::Axlebolt.Bolt.Protobuf2.OnClanMaxMembersCountIncreased.Parser, new[]{ "NewMembersCountValue" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnClanTagAndNameChanged), global::Axlebolt.Bolt.Protobuf2.OnClanTagAndNameChanged.Parser, new[]{ "NewClanTag", "NewClanName" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnJoinRequestTakenEvent), global::Axlebolt.Bolt.Protobuf2.OnJoinRequestTakenEvent.Parser, new[]{ "RequestId", "Player" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanLogMessage), global::Axlebolt.Bolt.Protobuf2.ClanLogMessage.Parser, new[]{ "ClanLogType", "ChangedClanType", "ChangedClanName", "ChangedClanTag", "PrimaryMember", "SecondaryMember", "ChangedMaxMemberCount", "AssignedRole" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanChatMessage), global::Axlebolt.Bolt.Protobuf2.ClanChatMessage.Parser, new[]{ "SenderId", "Message" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ClanUserMessage), global::Axlebolt.Bolt.Protobuf2.ClanUserMessage.Parser, new[]{ "Id", "Timestamp", "MessageType", "ChatMessage", "LogMessage" }, null, null, null, null)
          }));
    }

  }
  public enum ClanType {
    [pbr::OriginalName("Closed")] Closed = 0,
    [pbr::OriginalName("ByRequest")] ByRequest = 1,
    [pbr::OriginalName("Opened")] Opened = 2,
  }

  public enum RequestType {
    [pbr::OriginalName("NoneTypeRequest")] NoneTypeRequest = 0,
    [pbr::OriginalName("OpenRequest")] OpenRequest = 1,
    [pbr::OriginalName("ClosedRequest")] ClosedRequest = 2,
  }

  public enum ClanMemberRolePermission {
    [pbr::OriginalName("ChangeClanSettings")] ChangeClanSettings = 0,
    [pbr::OriginalName("AcceptMember")] AcceptMember = 1,
    [pbr::OriginalName("InviteMember")] InviteMember = 2,
    [pbr::OriginalName("KickMemberLess")] KickMemberLess = 3,
    [pbr::OriginalName("KickMemberEqual")] KickMemberEqual = 4,
    [pbr::OriginalName("AssignRoleLess")] AssignRoleLess = 5,
    [pbr::OriginalName("AssignRoleEqual")] AssignRoleEqual = 6,
    [pbr::OriginalName("CreateClanBattle")] CreateClanBattle = 7,
    [pbr::OriginalName("JoinClanBattle")] JoinClanBattle = 8,
    [pbr::OriginalName("UpgradeClanMembersCount")] UpgradeClanMembersCount = 9,
  }

  public enum JoinClanType {
    [pbr::OriginalName("ByAcceptInviteRequest")] ByAcceptInviteRequest = 0,
    [pbr::OriginalName("ByAcceptJoinRequest")] ByAcceptJoinRequest = 1,
    [pbr::OriginalName("JoinToOpenClan")] JoinToOpenClan = 2,
    [pbr::OriginalName("NoneJoinType")] NoneJoinType = 3,
  }

  public enum MessageType {
    [pbr::OriginalName("NoneType")] NoneType = 0,
    [pbr::OriginalName("ChatMessage")] ChatMessage = 1,
    [pbr::OriginalName("LogMessage")] LogMessage = 2,
  }


  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class Clan : pb::IMessage<Clan>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<Clan> _parser = new pb::MessageParser<Clan>(() => new Clan());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<Clan> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Clan() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Clan(Clan other) : this() {
      id_ = other.id_;
      name_ = other.name_;
      tag_ = other.tag_;
      clanType_ = other.clanType_;
      avatarId_ = other.avatarId_;
      createDate_ = other.createDate_;
      mebersCount_ = other.mebersCount_;
      maxMemberCount_ = other.maxMemberCount_;
      description_ = other.description_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public Clan Clone() {
      return new Clan(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NameFieldNumber = 2;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TagFieldNumber = 3;
    private string tag_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Tag {
      get { return tag_; }
      set {
        tag_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ClanTypeFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.ClanType clanType_ = global::Axlebolt.Bolt.Protobuf2.ClanType.Closed;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanType ClanType {
      get { return clanType_; }
      set {
        clanType_ = value;
      }
    }

    public const int AvatarIdFieldNumber = 5;
    private string avatarId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string AvatarId {
      get { return avatarId_; }
      set {
        avatarId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CreateDateFieldNumber = 6;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int MebersCountFieldNumber = 7;
    private int mebersCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int MebersCount {
      get { return mebersCount_; }
      set {
        mebersCount_ = value;
      }
    }

    public const int MaxMemberCountFieldNumber = 8;
    private int maxMemberCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int MaxMemberCount {
      get { return maxMemberCount_; }
      set {
        maxMemberCount_ = value;
      }
    }

    public const int DescriptionFieldNumber = 9;
    private string description_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Description {
      get { return description_; }
      set {
        description_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as Clan);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(Clan other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Name != other.Name) return false;
      if (Tag != other.Tag) return false;
      if (ClanType != other.ClanType) return false;
      if (AvatarId != other.AvatarId) return false;
      if (CreateDate != other.CreateDate) return false;
      if (MebersCount != other.MebersCount) return false;
      if (MaxMemberCount != other.MaxMemberCount) return false;
      if (Description != other.Description) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (Tag.Length != 0) hash ^= Tag.GetHashCode();
      if (ClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) hash ^= ClanType.GetHashCode();
      if (AvatarId.Length != 0) hash ^= AvatarId.GetHashCode();
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (MebersCount != 0) hash ^= MebersCount.GetHashCode();
      if (MaxMemberCount != 0) hash ^= MaxMemberCount.GetHashCode();
      if (Description.Length != 0) hash ^= Description.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Name);
      }
      if (Tag.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Tag);
      }
      if (ClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        output.WriteRawTag(32);
        output.WriteEnum((int) ClanType);
      }
      if (AvatarId.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(AvatarId);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(48);
        output.WriteInt64(CreateDate);
      }
      if (MebersCount != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(MebersCount);
      }
      if (MaxMemberCount != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(MaxMemberCount);
      }
      if (Description.Length != 0) {
        output.WriteRawTag(74);
        output.WriteString(Description);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Name);
      }
      if (Tag.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Tag);
      }
      if (ClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        output.WriteRawTag(32);
        output.WriteEnum((int) ClanType);
      }
      if (AvatarId.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(AvatarId);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(48);
        output.WriteInt64(CreateDate);
      }
      if (MebersCount != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(MebersCount);
      }
      if (MaxMemberCount != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(MaxMemberCount);
      }
      if (Description.Length != 0) {
        output.WriteRawTag(74);
        output.WriteString(Description);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (Tag.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Tag);
      }
      if (ClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) ClanType);
      }
      if (AvatarId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AvatarId);
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (MebersCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MebersCount);
      }
      if (MaxMemberCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxMemberCount);
      }
      if (Description.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Description);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(Clan other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.Tag.Length != 0) {
        Tag = other.Tag;
      }
      if (other.ClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        ClanType = other.ClanType;
      }
      if (other.AvatarId.Length != 0) {
        AvatarId = other.AvatarId;
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.MebersCount != 0) {
        MebersCount = other.MebersCount;
      }
      if (other.MaxMemberCount != 0) {
        MaxMemberCount = other.MaxMemberCount;
      }
      if (other.Description.Length != 0) {
        Description = other.Description;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Name = input.ReadString();
            break;
          }
          case 26: {
            Tag = input.ReadString();
            break;
          }
          case 32: {
            ClanType = (global::Axlebolt.Bolt.Protobuf2.ClanType) input.ReadEnum();
            break;
          }
          case 42: {
            AvatarId = input.ReadString();
            break;
          }
          case 48: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 56: {
            MebersCount = input.ReadInt32();
            break;
          }
          case 64: {
            MaxMemberCount = input.ReadInt32();
            break;
          }
          case 74: {
            Description = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Name = input.ReadString();
            break;
          }
          case 26: {
            Tag = input.ReadString();
            break;
          }
          case 32: {
            ClanType = (global::Axlebolt.Bolt.Protobuf2.ClanType) input.ReadEnum();
            break;
          }
          case 42: {
            AvatarId = input.ReadString();
            break;
          }
          case 48: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 56: {
            MebersCount = input.ReadInt32();
            break;
          }
          case 64: {
            MaxMemberCount = input.ReadInt32();
            break;
          }
          case 74: {
            Description = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanMember : pb::IMessage<ClanMember>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanMember> _parser = new pb::MessageParser<ClanMember>(() => new ClanMember());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanMember> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMember() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMember(ClanMember other) : this() {
      playerFriend_ = other.playerFriend_ != null ? other.playerFriend_.Clone() : null;
      clanId_ = other.clanId_;
      roleId_ = other.roleId_;
      createDate_ = other.createDate_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMember Clone() {
      return new ClanMember(this);
    }

    public const int PlayerFriendFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend playerFriend_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend PlayerFriend {
      get { return playerFriend_; }
      set {
        playerFriend_ = value;
      }
    }

    public const int ClanIdFieldNumber = 2;
    private string clanId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ClanId {
      get { return clanId_; }
      set {
        clanId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int RoleIdFieldNumber = 3;
    private int roleId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int RoleId {
      get { return roleId_; }
      set {
        roleId_ = value;
      }
    }

    public const int CreateDateFieldNumber = 4;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanMember);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanMember other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(PlayerFriend, other.PlayerFriend)) return false;
      if (ClanId != other.ClanId) return false;
      if (RoleId != other.RoleId) return false;
      if (CreateDate != other.CreateDate) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (playerFriend_ != null) hash ^= PlayerFriend.GetHashCode();
      if (ClanId.Length != 0) hash ^= ClanId.GetHashCode();
      if (RoleId != 0) hash ^= RoleId.GetHashCode();
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (playerFriend_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PlayerFriend);
      }
      if (ClanId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(ClanId);
      }
      if (RoleId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(RoleId);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (playerFriend_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PlayerFriend);
      }
      if (ClanId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(ClanId);
      }
      if (RoleId != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(RoleId);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (playerFriend_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PlayerFriend);
      }
      if (ClanId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ClanId);
      }
      if (RoleId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(RoleId);
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanMember other) {
      if (other == null) {
        return;
      }
      if (other.playerFriend_ != null) {
        if (playerFriend_ == null) {
          PlayerFriend = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        PlayerFriend.MergeFrom(other.PlayerFriend);
      }
      if (other.ClanId.Length != 0) {
        ClanId = other.ClanId;
      }
      if (other.RoleId != 0) {
        RoleId = other.RoleId;
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (playerFriend_ == null) {
              PlayerFriend = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(PlayerFriend);
            break;
          }
          case 18: {
            ClanId = input.ReadString();
            break;
          }
          case 24: {
            RoleId = input.ReadInt32();
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (playerFriend_ == null) {
              PlayerFriend = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(PlayerFriend);
            break;
          }
          case 18: {
            ClanId = input.ReadString();
            break;
          }
          case 24: {
            RoleId = input.ReadInt32();
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanMemberRole : pb::IMessage<ClanMemberRole>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanMemberRole> _parser = new pb::MessageParser<ClanMemberRole>(() => new ClanMemberRole());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanMemberRole> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberRole() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberRole(ClanMemberRole other) : this() {
      id_ = other.id_;
      name_ = other.name_;
      level_ = other.level_;
      descripption_ = other.descripption_;
      permissions_ = other.permissions_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanMemberRole Clone() {
      return new ClanMemberRole(this);
    }

    public const int IdFieldNumber = 1;
    private int id_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Id {
      get { return id_; }
      set {
        id_ = value;
      }
    }

    public const int NameFieldNumber = 2;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LevelFieldNumber = 3;
    private int level_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int Level {
      get { return level_; }
      set {
        level_ = value;
      }
    }

    public const int DescripptionFieldNumber = 4;
    private string descripption_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Descripption {
      get { return descripption_; }
      set {
        descripption_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PermissionsFieldNumber = 5;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission> _repeated_permissions_codec
        = pb::FieldCodec.ForEnum(42, x => (int) x, x => (global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission) x);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission> permissions_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.ClanMemberRolePermission> Permissions {
      get { return permissions_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanMemberRole);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanMemberRole other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Name != other.Name) return false;
      if (Level != other.Level) return false;
      if (Descripption != other.Descripption) return false;
      if(!permissions_.Equals(other.permissions_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id != 0) hash ^= Id.GetHashCode();
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (Level != 0) hash ^= Level.GetHashCode();
      if (Descripption.Length != 0) hash ^= Descripption.GetHashCode();
      hash ^= permissions_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Name);
      }
      if (Level != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Level);
      }
      if (Descripption.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Descripption);
      }
      permissions_.WriteTo(output, _repeated_permissions_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Id);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Name);
      }
      if (Level != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Level);
      }
      if (Descripption.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Descripption);
      }
      permissions_.WriteTo(ref output, _repeated_permissions_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Id);
      }
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (Level != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Level);
      }
      if (Descripption.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Descripption);
      }
      size += permissions_.CalculateSize(_repeated_permissions_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanMemberRole other) {
      if (other == null) {
        return;
      }
      if (other.Id != 0) {
        Id = other.Id;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.Level != 0) {
        Level = other.Level;
      }
      if (other.Descripption.Length != 0) {
        Descripption = other.Descripption;
      }
      permissions_.Add(other.permissions_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 18: {
            Name = input.ReadString();
            break;
          }
          case 24: {
            Level = input.ReadInt32();
            break;
          }
          case 34: {
            Descripption = input.ReadString();
            break;
          }
          case 42:
          case 40: {
            permissions_.AddEntriesFrom(input, _repeated_permissions_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Id = input.ReadInt32();
            break;
          }
          case 18: {
            Name = input.ReadString();
            break;
          }
          case 24: {
            Level = input.ReadInt32();
            break;
          }
          case 34: {
            Descripption = input.ReadString();
            break;
          }
          case 42:
          case 40: {
            permissions_.AddEntriesFrom(ref input, _repeated_permissions_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanSettings : pb::IMessage<ClanSettings>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanSettings> _parser = new pb::MessageParser<ClanSettings>(() => new ClanSettings());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanSettings> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanSettings() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanSettings(ClanSettings other) : this() {
      initialMembersCount_ = other.initialMembersCount_;
      membersCountLimit_ = other.membersCountLimit_;
      membersCountUpgradeCost_ = other.membersCountUpgradeCost_ != null ? other.membersCountUpgradeCost_.Clone() : null;
      changeClanNameOrTagCost_ = other.changeClanNameOrTagCost_ != null ? other.changeClanNameOrTagCost_.Clone() : null;
      clanCreateCost_ = other.clanCreateCost_ != null ? other.clanCreateCost_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanSettings Clone() {
      return new ClanSettings(this);
    }

    public const int InitialMembersCountFieldNumber = 1;
    private int initialMembersCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int InitialMembersCount {
      get { return initialMembersCount_; }
      set {
        initialMembersCount_ = value;
      }
    }

    public const int MembersCountLimitFieldNumber = 2;
    private int membersCountLimit_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int MembersCountLimit {
      get { return membersCountLimit_; }
      set {
        membersCountLimit_ = value;
      }
    }

    public const int MembersCountUpgradeCostFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.CurrencyAmount membersCountUpgradeCost_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.CurrencyAmount MembersCountUpgradeCost {
      get { return membersCountUpgradeCost_; }
      set {
        membersCountUpgradeCost_ = value;
      }
    }

    public const int ChangeClanNameOrTagCostFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.CurrencyAmount changeClanNameOrTagCost_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.CurrencyAmount ChangeClanNameOrTagCost {
      get { return changeClanNameOrTagCost_; }
      set {
        changeClanNameOrTagCost_ = value;
      }
    }

    public const int ClanCreateCostFieldNumber = 5;
    private global::Axlebolt.Bolt.Protobuf2.CurrencyAmount clanCreateCost_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.CurrencyAmount ClanCreateCost {
      get { return clanCreateCost_; }
      set {
        clanCreateCost_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanSettings);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanSettings other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InitialMembersCount != other.InitialMembersCount) return false;
      if (MembersCountLimit != other.MembersCountLimit) return false;
      if (!object.Equals(MembersCountUpgradeCost, other.MembersCountUpgradeCost)) return false;
      if (!object.Equals(ChangeClanNameOrTagCost, other.ChangeClanNameOrTagCost)) return false;
      if (!object.Equals(ClanCreateCost, other.ClanCreateCost)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (InitialMembersCount != 0) hash ^= InitialMembersCount.GetHashCode();
      if (MembersCountLimit != 0) hash ^= MembersCountLimit.GetHashCode();
      if (membersCountUpgradeCost_ != null) hash ^= MembersCountUpgradeCost.GetHashCode();
      if (changeClanNameOrTagCost_ != null) hash ^= ChangeClanNameOrTagCost.GetHashCode();
      if (clanCreateCost_ != null) hash ^= ClanCreateCost.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InitialMembersCount != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(InitialMembersCount);
      }
      if (MembersCountLimit != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(MembersCountLimit);
      }
      if (membersCountUpgradeCost_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(MembersCountUpgradeCost);
      }
      if (changeClanNameOrTagCost_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(ChangeClanNameOrTagCost);
      }
      if (clanCreateCost_ != null) {
        output.WriteRawTag(42);
        output.WriteMessage(ClanCreateCost);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InitialMembersCount != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(InitialMembersCount);
      }
      if (MembersCountLimit != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(MembersCountLimit);
      }
      if (membersCountUpgradeCost_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(MembersCountUpgradeCost);
      }
      if (changeClanNameOrTagCost_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(ChangeClanNameOrTagCost);
      }
      if (clanCreateCost_ != null) {
        output.WriteRawTag(42);
        output.WriteMessage(ClanCreateCost);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (InitialMembersCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(InitialMembersCount);
      }
      if (MembersCountLimit != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MembersCountLimit);
      }
      if (membersCountUpgradeCost_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(MembersCountUpgradeCost);
      }
      if (changeClanNameOrTagCost_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ChangeClanNameOrTagCost);
      }
      if (clanCreateCost_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ClanCreateCost);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanSettings other) {
      if (other == null) {
        return;
      }
      if (other.InitialMembersCount != 0) {
        InitialMembersCount = other.InitialMembersCount;
      }
      if (other.MembersCountLimit != 0) {
        MembersCountLimit = other.MembersCountLimit;
      }
      if (other.membersCountUpgradeCost_ != null) {
        if (membersCountUpgradeCost_ == null) {
          MembersCountUpgradeCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
        }
        MembersCountUpgradeCost.MergeFrom(other.MembersCountUpgradeCost);
      }
      if (other.changeClanNameOrTagCost_ != null) {
        if (changeClanNameOrTagCost_ == null) {
          ChangeClanNameOrTagCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
        }
        ChangeClanNameOrTagCost.MergeFrom(other.ChangeClanNameOrTagCost);
      }
      if (other.clanCreateCost_ != null) {
        if (clanCreateCost_ == null) {
          ClanCreateCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
        }
        ClanCreateCost.MergeFrom(other.ClanCreateCost);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            InitialMembersCount = input.ReadInt32();
            break;
          }
          case 16: {
            MembersCountLimit = input.ReadInt32();
            break;
          }
          case 26: {
            if (membersCountUpgradeCost_ == null) {
              MembersCountUpgradeCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(MembersCountUpgradeCost);
            break;
          }
          case 34: {
            if (changeClanNameOrTagCost_ == null) {
              ChangeClanNameOrTagCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(ChangeClanNameOrTagCost);
            break;
          }
          case 42: {
            if (clanCreateCost_ == null) {
              ClanCreateCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(ClanCreateCost);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            InitialMembersCount = input.ReadInt32();
            break;
          }
          case 16: {
            MembersCountLimit = input.ReadInt32();
            break;
          }
          case 26: {
            if (membersCountUpgradeCost_ == null) {
              MembersCountUpgradeCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(MembersCountUpgradeCost);
            break;
          }
          case 34: {
            if (changeClanNameOrTagCost_ == null) {
              ChangeClanNameOrTagCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(ChangeClanNameOrTagCost);
            break;
          }
          case 42: {
            if (clanCreateCost_ == null) {
              ClanCreateCost = new global::Axlebolt.Bolt.Protobuf2.CurrencyAmount();
            }
            input.ReadMessage(ClanCreateCost);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanJoinRequest : pb::IMessage<ClanJoinRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanJoinRequest> _parser = new pb::MessageParser<ClanJoinRequest>(() => new ClanJoinRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanJoinRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanJoinRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanJoinRequest(ClanJoinRequest other) : this() {
      id_ = other.id_;
      clan_ = other.clan_ != null ? other.clan_.Clone() : null;
      requestSender_ = other.requestSender_ != null ? other.requestSender_.Clone() : null;
      createDate_ = other.createDate_;
      closeDate_ = other.closeDate_;
      requestType_ = other.requestType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanJoinRequest Clone() {
      return new ClanJoinRequest(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ClanFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Clan clan_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Clan Clan {
      get { return clan_; }
      set {
        clan_ = value;
      }
    }

    public const int RequestSenderFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Player requestSender_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player RequestSender {
      get { return requestSender_; }
      set {
        requestSender_ = value;
      }
    }

    public const int CreateDateFieldNumber = 4;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int CloseDateFieldNumber = 5;
    private long closeDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CloseDate {
      get { return closeDate_; }
      set {
        closeDate_ = value;
      }
    }

    public const int RequestTypeFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.RequestType requestType_ = global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.RequestType RequestType {
      get { return requestType_; }
      set {
        requestType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanJoinRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanJoinRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (!object.Equals(Clan, other.Clan)) return false;
      if (!object.Equals(RequestSender, other.RequestSender)) return false;
      if (CreateDate != other.CreateDate) return false;
      if (CloseDate != other.CloseDate) return false;
      if (RequestType != other.RequestType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (clan_ != null) hash ^= Clan.GetHashCode();
      if (requestSender_ != null) hash ^= RequestSender.GetHashCode();
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (CloseDate != 0L) hash ^= CloseDate.GetHashCode();
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) hash ^= RequestType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (requestSender_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(RequestSender);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        output.WriteRawTag(48);
        output.WriteEnum((int) RequestType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (requestSender_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(RequestSender);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        output.WriteRawTag(48);
        output.WriteEnum((int) RequestType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (clan_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Clan);
      }
      if (requestSender_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(RequestSender);
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (CloseDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) RequestType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanJoinRequest other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.clan_ != null) {
        if (clan_ == null) {
          Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
        }
        Clan.MergeFrom(other.Clan);
      }
      if (other.requestSender_ != null) {
        if (requestSender_ == null) {
          RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        RequestSender.MergeFrom(other.RequestSender);
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.CloseDate != 0L) {
        CloseDate = other.CloseDate;
      }
      if (other.RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        RequestType = other.RequestType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (requestSender_ == null) {
              RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(RequestSender);
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 48: {
            RequestType = (global::Axlebolt.Bolt.Protobuf2.RequestType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (requestSender_ == null) {
              RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(RequestSender);
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 48: {
            RequestType = (global::Axlebolt.Bolt.Protobuf2.RequestType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanInviteRequest : pb::IMessage<ClanInviteRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanInviteRequest> _parser = new pb::MessageParser<ClanInviteRequest>(() => new ClanInviteRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanInviteRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanInviteRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanInviteRequest(ClanInviteRequest other) : this() {
      id_ = other.id_;
      clan_ = other.clan_ != null ? other.clan_.Clone() : null;
      requestSender_ = other.requestSender_ != null ? other.requestSender_.Clone() : null;
      createDate_ = other.createDate_;
      closeDate_ = other.closeDate_;
      requestType_ = other.requestType_;
      invitedPlayer_ = other.invitedPlayer_ != null ? other.invitedPlayer_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanInviteRequest Clone() {
      return new ClanInviteRequest(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ClanFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Clan clan_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Clan Clan {
      get { return clan_; }
      set {
        clan_ = value;
      }
    }

    public const int RequestSenderFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Player requestSender_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player RequestSender {
      get { return requestSender_; }
      set {
        requestSender_ = value;
      }
    }

    public const int CreateDateFieldNumber = 4;
    private long createDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CreateDate {
      get { return createDate_; }
      set {
        createDate_ = value;
      }
    }

    public const int CloseDateFieldNumber = 5;
    private long closeDate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long CloseDate {
      get { return closeDate_; }
      set {
        closeDate_ = value;
      }
    }

    public const int RequestTypeFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.RequestType requestType_ = global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.RequestType RequestType {
      get { return requestType_; }
      set {
        requestType_ = value;
      }
    }

    public const int InvitedPlayerFieldNumber = 7;
    private global::Axlebolt.Bolt.Protobuf2.Player invitedPlayer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player InvitedPlayer {
      get { return invitedPlayer_; }
      set {
        invitedPlayer_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanInviteRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanInviteRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (!object.Equals(Clan, other.Clan)) return false;
      if (!object.Equals(RequestSender, other.RequestSender)) return false;
      if (CreateDate != other.CreateDate) return false;
      if (CloseDate != other.CloseDate) return false;
      if (RequestType != other.RequestType) return false;
      if (!object.Equals(InvitedPlayer, other.InvitedPlayer)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (clan_ != null) hash ^= Clan.GetHashCode();
      if (requestSender_ != null) hash ^= RequestSender.GetHashCode();
      if (CreateDate != 0L) hash ^= CreateDate.GetHashCode();
      if (CloseDate != 0L) hash ^= CloseDate.GetHashCode();
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) hash ^= RequestType.GetHashCode();
      if (invitedPlayer_ != null) hash ^= InvitedPlayer.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (requestSender_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(RequestSender);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        output.WriteRawTag(48);
        output.WriteEnum((int) RequestType);
      }
      if (invitedPlayer_ != null) {
        output.WriteRawTag(58);
        output.WriteMessage(InvitedPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (requestSender_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(RequestSender);
      }
      if (CreateDate != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(CreateDate);
      }
      if (CloseDate != 0L) {
        output.WriteRawTag(40);
        output.WriteInt64(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        output.WriteRawTag(48);
        output.WriteEnum((int) RequestType);
      }
      if (invitedPlayer_ != null) {
        output.WriteRawTag(58);
        output.WriteMessage(InvitedPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (clan_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Clan);
      }
      if (requestSender_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(RequestSender);
      }
      if (CreateDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CreateDate);
      }
      if (CloseDate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(CloseDate);
      }
      if (RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) RequestType);
      }
      if (invitedPlayer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(InvitedPlayer);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanInviteRequest other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.clan_ != null) {
        if (clan_ == null) {
          Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
        }
        Clan.MergeFrom(other.Clan);
      }
      if (other.requestSender_ != null) {
        if (requestSender_ == null) {
          RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        RequestSender.MergeFrom(other.RequestSender);
      }
      if (other.CreateDate != 0L) {
        CreateDate = other.CreateDate;
      }
      if (other.CloseDate != 0L) {
        CloseDate = other.CloseDate;
      }
      if (other.RequestType != global::Axlebolt.Bolt.Protobuf2.RequestType.NoneTypeRequest) {
        RequestType = other.RequestType;
      }
      if (other.invitedPlayer_ != null) {
        if (invitedPlayer_ == null) {
          InvitedPlayer = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        InvitedPlayer.MergeFrom(other.InvitedPlayer);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (requestSender_ == null) {
              RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(RequestSender);
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 48: {
            RequestType = (global::Axlebolt.Bolt.Protobuf2.RequestType) input.ReadEnum();
            break;
          }
          case 58: {
            if (invitedPlayer_ == null) {
              InvitedPlayer = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(InvitedPlayer);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (requestSender_ == null) {
              RequestSender = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(RequestSender);
            break;
          }
          case 32: {
            CreateDate = input.ReadInt64();
            break;
          }
          case 40: {
            CloseDate = input.ReadInt64();
            break;
          }
          case 48: {
            RequestType = (global::Axlebolt.Bolt.Protobuf2.RequestType) input.ReadEnum();
            break;
          }
          case 58: {
            if (invitedPlayer_ == null) {
              InvitedPlayer = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(InvitedPlayer);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnAssignedLeaderRoleEvent : pb::IMessage<OnAssignedLeaderRoleEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnAssignedLeaderRoleEvent> _parser = new pb::MessageParser<OnAssignedLeaderRoleEvent>(() => new OnAssignedLeaderRoleEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnAssignedLeaderRoleEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedLeaderRoleEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedLeaderRoleEvent(OnAssignedLeaderRoleEvent other) : this() {
      oldLeaderRole_ = other.oldLeaderRole_;
      newLeaderId_ = other.newLeaderId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedLeaderRoleEvent Clone() {
      return new OnAssignedLeaderRoleEvent(this);
    }

    public const int OldLeaderRoleFieldNumber = 1;
    private int oldLeaderRole_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int OldLeaderRole {
      get { return oldLeaderRole_; }
      set {
        oldLeaderRole_ = value;
      }
    }

    public const int NewLeaderIdFieldNumber = 2;
    private string newLeaderId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string NewLeaderId {
      get { return newLeaderId_; }
      set {
        newLeaderId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnAssignedLeaderRoleEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnAssignedLeaderRoleEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (OldLeaderRole != other.OldLeaderRole) return false;
      if (NewLeaderId != other.NewLeaderId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (OldLeaderRole != 0) hash ^= OldLeaderRole.GetHashCode();
      if (NewLeaderId.Length != 0) hash ^= NewLeaderId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (OldLeaderRole != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(OldLeaderRole);
      }
      if (NewLeaderId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(NewLeaderId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (OldLeaderRole != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(OldLeaderRole);
      }
      if (NewLeaderId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(NewLeaderId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (OldLeaderRole != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(OldLeaderRole);
      }
      if (NewLeaderId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(NewLeaderId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnAssignedLeaderRoleEvent other) {
      if (other == null) {
        return;
      }
      if (other.OldLeaderRole != 0) {
        OldLeaderRole = other.OldLeaderRole;
      }
      if (other.NewLeaderId.Length != 0) {
        NewLeaderId = other.NewLeaderId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            OldLeaderRole = input.ReadInt32();
            break;
          }
          case 18: {
            NewLeaderId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            OldLeaderRole = input.ReadInt32();
            break;
          }
          case 18: {
            NewLeaderId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnKickedMemberEvent : pb::IMessage<OnKickedMemberEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnKickedMemberEvent> _parser = new pb::MessageParser<OnKickedMemberEvent>(() => new OnKickedMemberEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnKickedMemberEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedMemberEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedMemberEvent(OnKickedMemberEvent other) : this() {
      kickerMemberId_ = other.kickerMemberId_;
      kickedMemberId_ = other.kickedMemberId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedMemberEvent Clone() {
      return new OnKickedMemberEvent(this);
    }

    public const int KickerMemberIdFieldNumber = 1;
    private string kickerMemberId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string KickerMemberId {
      get { return kickerMemberId_; }
      set {
        kickerMemberId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int KickedMemberIdFieldNumber = 2;
    private string kickedMemberId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string KickedMemberId {
      get { return kickedMemberId_; }
      set {
        kickedMemberId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnKickedMemberEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnKickedMemberEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (KickerMemberId != other.KickerMemberId) return false;
      if (KickedMemberId != other.KickedMemberId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (KickerMemberId.Length != 0) hash ^= KickerMemberId.GetHashCode();
      if (KickedMemberId.Length != 0) hash ^= KickedMemberId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (KickerMemberId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickerMemberId);
      }
      if (KickedMemberId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(KickedMemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (KickerMemberId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickerMemberId);
      }
      if (KickedMemberId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(KickedMemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (KickerMemberId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickerMemberId);
      }
      if (KickedMemberId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickedMemberId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnKickedMemberEvent other) {
      if (other == null) {
        return;
      }
      if (other.KickerMemberId.Length != 0) {
        KickerMemberId = other.KickerMemberId;
      }
      if (other.KickedMemberId.Length != 0) {
        KickedMemberId = other.KickedMemberId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            KickerMemberId = input.ReadString();
            break;
          }
          case 18: {
            KickedMemberId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            KickerMemberId = input.ReadString();
            break;
          }
          case 18: {
            KickedMemberId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnClanTypeChanged : pb::IMessage<OnClanTypeChanged>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnClanTypeChanged> _parser = new pb::MessageParser<OnClanTypeChanged>(() => new OnClanTypeChanged());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnClanTypeChanged> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTypeChanged() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTypeChanged(OnClanTypeChanged other) : this() {
      newClanType_ = other.newClanType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTypeChanged Clone() {
      return new OnClanTypeChanged(this);
    }

    public const int NewClanTypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.ClanType newClanType_ = global::Axlebolt.Bolt.Protobuf2.ClanType.Closed;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanType NewClanType {
      get { return newClanType_; }
      set {
        newClanType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnClanTypeChanged);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnClanTypeChanged other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (NewClanType != other.NewClanType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (NewClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) hash ^= NewClanType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (NewClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        output.WriteRawTag(8);
        output.WriteEnum((int) NewClanType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (NewClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        output.WriteRawTag(8);
        output.WriteEnum((int) NewClanType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (NewClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) NewClanType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnClanTypeChanged other) {
      if (other == null) {
        return;
      }
      if (other.NewClanType != global::Axlebolt.Bolt.Protobuf2.ClanType.Closed) {
        NewClanType = other.NewClanType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            NewClanType = (global::Axlebolt.Bolt.Protobuf2.ClanType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            NewClanType = (global::Axlebolt.Bolt.Protobuf2.ClanType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnMemberJoinedToClanEvent : pb::IMessage<OnMemberJoinedToClanEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnMemberJoinedToClanEvent> _parser = new pb::MessageParser<OnMemberJoinedToClanEvent>(() => new OnMemberJoinedToClanEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnMemberJoinedToClanEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[9]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnMemberJoinedToClanEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnMemberJoinedToClanEvent(OnMemberJoinedToClanEvent other) : this() {
      clanMember_ = other.clanMember_ != null ? other.clanMember_.Clone() : null;
      joinClanType_ = other.joinClanType_;
      joinRequestAcceptor_ = other.joinRequestAcceptor_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnMemberJoinedToClanEvent Clone() {
      return new OnMemberJoinedToClanEvent(this);
    }

    public const int ClanMemberFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.ClanMember clanMember_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanMember ClanMember {
      get { return clanMember_; }
      set {
        clanMember_ = value;
      }
    }

    public const int JoinClanTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.JoinClanType joinClanType_ = global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.JoinClanType JoinClanType {
      get { return joinClanType_; }
      set {
        joinClanType_ = value;
      }
    }

    public const int JoinRequestAcceptorFieldNumber = 3;
    private string joinRequestAcceptor_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string JoinRequestAcceptor {
      get { return joinRequestAcceptor_; }
      set {
        joinRequestAcceptor_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnMemberJoinedToClanEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnMemberJoinedToClanEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(ClanMember, other.ClanMember)) return false;
      if (JoinClanType != other.JoinClanType) return false;
      if (JoinRequestAcceptor != other.JoinRequestAcceptor) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (clanMember_ != null) hash ^= ClanMember.GetHashCode();
      if (JoinClanType != global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest) hash ^= JoinClanType.GetHashCode();
      if (JoinRequestAcceptor.Length != 0) hash ^= JoinRequestAcceptor.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (clanMember_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(ClanMember);
      }
      if (JoinClanType != global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest) {
        output.WriteRawTag(16);
        output.WriteEnum((int) JoinClanType);
      }
      if (JoinRequestAcceptor.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(JoinRequestAcceptor);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (clanMember_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(ClanMember);
      }
      if (JoinClanType != global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest) {
        output.WriteRawTag(16);
        output.WriteEnum((int) JoinClanType);
      }
      if (JoinRequestAcceptor.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(JoinRequestAcceptor);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (clanMember_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ClanMember);
      }
      if (JoinClanType != global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) JoinClanType);
      }
      if (JoinRequestAcceptor.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(JoinRequestAcceptor);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnMemberJoinedToClanEvent other) {
      if (other == null) {
        return;
      }
      if (other.clanMember_ != null) {
        if (clanMember_ == null) {
          ClanMember = new global::Axlebolt.Bolt.Protobuf2.ClanMember();
        }
        ClanMember.MergeFrom(other.ClanMember);
      }
      if (other.JoinClanType != global::Axlebolt.Bolt.Protobuf2.JoinClanType.ByAcceptInviteRequest) {
        JoinClanType = other.JoinClanType;
      }
      if (other.JoinRequestAcceptor.Length != 0) {
        JoinRequestAcceptor = other.JoinRequestAcceptor;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (clanMember_ == null) {
              ClanMember = new global::Axlebolt.Bolt.Protobuf2.ClanMember();
            }
            input.ReadMessage(ClanMember);
            break;
          }
          case 16: {
            JoinClanType = (global::Axlebolt.Bolt.Protobuf2.JoinClanType) input.ReadEnum();
            break;
          }
          case 26: {
            JoinRequestAcceptor = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (clanMember_ == null) {
              ClanMember = new global::Axlebolt.Bolt.Protobuf2.ClanMember();
            }
            input.ReadMessage(ClanMember);
            break;
          }
          case 16: {
            JoinClanType = (global::Axlebolt.Bolt.Protobuf2.JoinClanType) input.ReadEnum();
            break;
          }
          case 26: {
            JoinRequestAcceptor = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnAssignedRoleEvent : pb::IMessage<OnAssignedRoleEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnAssignedRoleEvent> _parser = new pb::MessageParser<OnAssignedRoleEvent>(() => new OnAssignedRoleEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnAssignedRoleEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[10]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedRoleEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedRoleEvent(OnAssignedRoleEvent other) : this() {
      newRoleId_ = other.newRoleId_;
      assignatorMemberId_ = other.assignatorMemberId_;
      assigningMemberId_ = other.assigningMemberId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnAssignedRoleEvent Clone() {
      return new OnAssignedRoleEvent(this);
    }

    public const int NewRoleIdFieldNumber = 1;
    private int newRoleId_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int NewRoleId {
      get { return newRoleId_; }
      set {
        newRoleId_ = value;
      }
    }

    public const int AssignatorMemberIdFieldNumber = 2;
    private string assignatorMemberId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string AssignatorMemberId {
      get { return assignatorMemberId_; }
      set {
        assignatorMemberId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AssigningMemberIdFieldNumber = 3;
    private string assigningMemberId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string AssigningMemberId {
      get { return assigningMemberId_; }
      set {
        assigningMemberId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnAssignedRoleEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnAssignedRoleEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (NewRoleId != other.NewRoleId) return false;
      if (AssignatorMemberId != other.AssignatorMemberId) return false;
      if (AssigningMemberId != other.AssigningMemberId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (NewRoleId != 0) hash ^= NewRoleId.GetHashCode();
      if (AssignatorMemberId.Length != 0) hash ^= AssignatorMemberId.GetHashCode();
      if (AssigningMemberId.Length != 0) hash ^= AssigningMemberId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (NewRoleId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(NewRoleId);
      }
      if (AssignatorMemberId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(AssignatorMemberId);
      }
      if (AssigningMemberId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(AssigningMemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (NewRoleId != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(NewRoleId);
      }
      if (AssignatorMemberId.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(AssignatorMemberId);
      }
      if (AssigningMemberId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(AssigningMemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (NewRoleId != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(NewRoleId);
      }
      if (AssignatorMemberId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AssignatorMemberId);
      }
      if (AssigningMemberId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AssigningMemberId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnAssignedRoleEvent other) {
      if (other == null) {
        return;
      }
      if (other.NewRoleId != 0) {
        NewRoleId = other.NewRoleId;
      }
      if (other.AssignatorMemberId.Length != 0) {
        AssignatorMemberId = other.AssignatorMemberId;
      }
      if (other.AssigningMemberId.Length != 0) {
        AssigningMemberId = other.AssigningMemberId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            NewRoleId = input.ReadInt32();
            break;
          }
          case 18: {
            AssignatorMemberId = input.ReadString();
            break;
          }
          case 26: {
            AssigningMemberId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            NewRoleId = input.ReadInt32();
            break;
          }
          case 18: {
            AssignatorMemberId = input.ReadString();
            break;
          }
          case 26: {
            AssigningMemberId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnJoinedToClanEvent : pb::IMessage<OnJoinedToClanEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnJoinedToClanEvent> _parser = new pb::MessageParser<OnJoinedToClanEvent>(() => new OnJoinedToClanEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnJoinedToClanEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[11]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinedToClanEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinedToClanEvent(OnJoinedToClanEvent other) : this() {
      clan_ = other.clan_ != null ? other.clan_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinedToClanEvent Clone() {
      return new OnJoinedToClanEvent(this);
    }

    public const int ClanFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Clan clan_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Clan Clan {
      get { return clan_; }
      set {
        clan_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnJoinedToClanEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnJoinedToClanEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Clan, other.Clan)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (clan_ != null) hash ^= Clan.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (clan_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Clan);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (clan_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Clan);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (clan_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Clan);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnJoinedToClanEvent other) {
      if (other == null) {
        return;
      }
      if (other.clan_ != null) {
        if (clan_ == null) {
          Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
        }
        Clan.MergeFrom(other.Clan);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnLeftFromClan : pb::IMessage<OnLeftFromClan>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLeftFromClan> _parser = new pb::MessageParser<OnLeftFromClan>(() => new OnLeftFromClan());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnLeftFromClan> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[12]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnLeftFromClan() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnLeftFromClan(OnLeftFromClan other) : this() {
      memberId_ = other.memberId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnLeftFromClan Clone() {
      return new OnLeftFromClan(this);
    }

    public const int MemberIdFieldNumber = 1;
    private string memberId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string MemberId {
      get { return memberId_; }
      set {
        memberId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnLeftFromClan);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnLeftFromClan other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (MemberId != other.MemberId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (MemberId.Length != 0) hash ^= MemberId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (MemberId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(MemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (MemberId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(MemberId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (MemberId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(MemberId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnLeftFromClan other) {
      if (other == null) {
        return;
      }
      if (other.MemberId.Length != 0) {
        MemberId = other.MemberId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            MemberId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            MemberId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnPlayerAttributesChanged : pb::IMessage<OnPlayerAttributesChanged>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnPlayerAttributesChanged> _parser = new pb::MessageParser<OnPlayerAttributesChanged>(() => new OnPlayerAttributesChanged());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnPlayerAttributesChanged> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[13]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerAttributesChanged() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerAttributesChanged(OnPlayerAttributesChanged other) : this() {
      playerId_ = other.playerId_;
      attributes_ = other.attributes_ != null ? other.attributes_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnPlayerAttributesChanged Clone() {
      return new OnPlayerAttributesChanged(this);
    }

    public const int PlayerIdFieldNumber = 1;
    private string playerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string PlayerId {
      get { return playerId_; }
      set {
        playerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AttributesFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Attributes attributes_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Attributes Attributes {
      get { return attributes_; }
      set {
        attributes_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnPlayerAttributesChanged);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnPlayerAttributesChanged other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (PlayerId != other.PlayerId) return false;
      if (!object.Equals(Attributes, other.Attributes)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (PlayerId.Length != 0) hash ^= PlayerId.GetHashCode();
      if (attributes_ != null) hash ^= Attributes.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (PlayerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      if (attributes_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Attributes);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (PlayerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(PlayerId);
      }
      if (attributes_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Attributes);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (PlayerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PlayerId);
      }
      if (attributes_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Attributes);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnPlayerAttributesChanged other) {
      if (other == null) {
        return;
      }
      if (other.PlayerId.Length != 0) {
        PlayerId = other.PlayerId;
      }
      if (other.attributes_ != null) {
        if (attributes_ == null) {
          Attributes = new global::Axlebolt.Bolt.Protobuf2.Attributes();
        }
        Attributes.MergeFrom(other.Attributes);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            PlayerId = input.ReadString();
            break;
          }
          case 18: {
            if (attributes_ == null) {
              Attributes = new global::Axlebolt.Bolt.Protobuf2.Attributes();
            }
            input.ReadMessage(Attributes);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            PlayerId = input.ReadString();
            break;
          }
          case 18: {
            if (attributes_ == null) {
              Attributes = new global::Axlebolt.Bolt.Protobuf2.Attributes();
            }
            input.ReadMessage(Attributes);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnInvitedToClanEvent : pb::IMessage<OnInvitedToClanEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnInvitedToClanEvent> _parser = new pb::MessageParser<OnInvitedToClanEvent>(() => new OnInvitedToClanEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnInvitedToClanEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[14]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnInvitedToClanEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnInvitedToClanEvent(OnInvitedToClanEvent other) : this() {
      requestId_ = other.requestId_;
      clan_ = other.clan_ != null ? other.clan_.Clone() : null;
      player_ = other.player_ != null ? other.player_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnInvitedToClanEvent Clone() {
      return new OnInvitedToClanEvent(this);
    }

    public const int RequestIdFieldNumber = 1;
    private string requestId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string RequestId {
      get { return requestId_; }
      set {
        requestId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ClanFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Clan clan_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Clan Clan {
      get { return clan_; }
      set {
        clan_ = value;
      }
    }

    public const int PlayerFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Player player_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player Player {
      get { return player_; }
      set {
        player_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnInvitedToClanEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnInvitedToClanEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (RequestId != other.RequestId) return false;
      if (!object.Equals(Clan, other.Clan)) return false;
      if (!object.Equals(Player, other.Player)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (RequestId.Length != 0) hash ^= RequestId.GetHashCode();
      if (clan_ != null) hash ^= Clan.GetHashCode();
      if (player_ != null) hash ^= Player.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (player_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Player);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (clan_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Clan);
      }
      if (player_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(Player);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (RequestId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(RequestId);
      }
      if (clan_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Clan);
      }
      if (player_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Player);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnInvitedToClanEvent other) {
      if (other == null) {
        return;
      }
      if (other.RequestId.Length != 0) {
        RequestId = other.RequestId;
      }
      if (other.clan_ != null) {
        if (clan_ == null) {
          Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
        }
        Clan.MergeFrom(other.Clan);
      }
      if (other.player_ != null) {
        if (player_ == null) {
          Player = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Player.MergeFrom(other.Player);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
          case 18: {
            if (clan_ == null) {
              Clan = new global::Axlebolt.Bolt.Protobuf2.Clan();
            }
            input.ReadMessage(Clan);
            break;
          }
          case 26: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnKickedEvent : pb::IMessage<OnKickedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnKickedEvent> _parser = new pb::MessageParser<OnKickedEvent>(() => new OnKickedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnKickedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[15]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedEvent(OnKickedEvent other) : this() {
      kickingReason_ = other.kickingReason_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnKickedEvent Clone() {
      return new OnKickedEvent(this);
    }

    public const int KickingReasonFieldNumber = 1;
    private string kickingReason_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string KickingReason {
      get { return kickingReason_; }
      set {
        kickingReason_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnKickedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnKickedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (KickingReason != other.KickingReason) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (KickingReason.Length != 0) hash ^= KickingReason.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (KickingReason.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickingReason);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (KickingReason.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickingReason);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (KickingReason.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickingReason);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnKickedEvent other) {
      if (other == null) {
        return;
      }
      if (other.KickingReason.Length != 0) {
        KickingReason = other.KickingReason;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            KickingReason = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            KickingReason = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnClanMaxMembersCountIncreased : pb::IMessage<OnClanMaxMembersCountIncreased>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnClanMaxMembersCountIncreased> _parser = new pb::MessageParser<OnClanMaxMembersCountIncreased>(() => new OnClanMaxMembersCountIncreased());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnClanMaxMembersCountIncreased> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[16]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanMaxMembersCountIncreased() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanMaxMembersCountIncreased(OnClanMaxMembersCountIncreased other) : this() {
      newMembersCountValue_ = other.newMembersCountValue_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanMaxMembersCountIncreased Clone() {
      return new OnClanMaxMembersCountIncreased(this);
    }

    public const int NewMembersCountValueFieldNumber = 1;
    private int newMembersCountValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int NewMembersCountValue {
      get { return newMembersCountValue_; }
      set {
        newMembersCountValue_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnClanMaxMembersCountIncreased);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnClanMaxMembersCountIncreased other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (NewMembersCountValue != other.NewMembersCountValue) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (NewMembersCountValue != 0) hash ^= NewMembersCountValue.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (NewMembersCountValue != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(NewMembersCountValue);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (NewMembersCountValue != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(NewMembersCountValue);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (NewMembersCountValue != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(NewMembersCountValue);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnClanMaxMembersCountIncreased other) {
      if (other == null) {
        return;
      }
      if (other.NewMembersCountValue != 0) {
        NewMembersCountValue = other.NewMembersCountValue;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            NewMembersCountValue = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            NewMembersCountValue = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnClanTagAndNameChanged : pb::IMessage<OnClanTagAndNameChanged>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnClanTagAndNameChanged> _parser = new pb::MessageParser<OnClanTagAndNameChanged>(() => new OnClanTagAndNameChanged());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnClanTagAndNameChanged> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[17]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTagAndNameChanged() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTagAndNameChanged(OnClanTagAndNameChanged other) : this() {
      newClanTag_ = other.newClanTag_;
      newClanName_ = other.newClanName_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnClanTagAndNameChanged Clone() {
      return new OnClanTagAndNameChanged(this);
    }

    public const int NewClanTagFieldNumber = 1;
    private string newClanTag_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string NewClanTag {
      get { return newClanTag_; }
      set {
        newClanTag_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NewClanNameFieldNumber = 2;
    private string newClanName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string NewClanName {
      get { return newClanName_; }
      set {
        newClanName_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnClanTagAndNameChanged);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnClanTagAndNameChanged other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (NewClanTag != other.NewClanTag) return false;
      if (NewClanName != other.NewClanName) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (NewClanTag.Length != 0) hash ^= NewClanTag.GetHashCode();
      if (NewClanName.Length != 0) hash ^= NewClanName.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (NewClanTag.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(NewClanTag);
      }
      if (NewClanName.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(NewClanName);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (NewClanTag.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(NewClanTag);
      }
      if (NewClanName.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(NewClanName);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (NewClanTag.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(NewClanTag);
      }
      if (NewClanName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(NewClanName);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnClanTagAndNameChanged other) {
      if (other == null) {
        return;
      }
      if (other.NewClanTag.Length != 0) {
        NewClanTag = other.NewClanTag;
      }
      if (other.NewClanName.Length != 0) {
        NewClanName = other.NewClanName;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            NewClanTag = input.ReadString();
            break;
          }
          case 18: {
            NewClanName = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            NewClanTag = input.ReadString();
            break;
          }
          case 18: {
            NewClanName = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class OnJoinRequestTakenEvent : pb::IMessage<OnJoinRequestTakenEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnJoinRequestTakenEvent> _parser = new pb::MessageParser<OnJoinRequestTakenEvent>(() => new OnJoinRequestTakenEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<OnJoinRequestTakenEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[18]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinRequestTakenEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinRequestTakenEvent(OnJoinRequestTakenEvent other) : this() {
      requestId_ = other.requestId_;
      player_ = other.player_ != null ? other.player_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public OnJoinRequestTakenEvent Clone() {
      return new OnJoinRequestTakenEvent(this);
    }

    public const int RequestIdFieldNumber = 1;
    private string requestId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string RequestId {
      get { return requestId_; }
      set {
        requestId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayerFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Player player_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.Player Player {
      get { return player_; }
      set {
        player_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as OnJoinRequestTakenEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(OnJoinRequestTakenEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (RequestId != other.RequestId) return false;
      if (!object.Equals(Player, other.Player)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (RequestId.Length != 0) hash ^= RequestId.GetHashCode();
      if (player_ != null) hash ^= Player.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (player_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Player);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (RequestId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RequestId);
      }
      if (player_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Player);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (RequestId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(RequestId);
      }
      if (player_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Player);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(OnJoinRequestTakenEvent other) {
      if (other == null) {
        return;
      }
      if (other.RequestId.Length != 0) {
        RequestId = other.RequestId;
      }
      if (other.player_ != null) {
        if (player_ == null) {
          Player = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Player.MergeFrom(other.Player);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
          case 18: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            RequestId = input.ReadString();
            break;
          }
          case 18: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanLogMessage : pb::IMessage<ClanLogMessage>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanLogMessage> _parser = new pb::MessageParser<ClanLogMessage>(() => new ClanLogMessage());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanLogMessage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[19]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanLogMessage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanLogMessage(ClanLogMessage other) : this() {
      clanLogType_ = other.clanLogType_;
      changedClanType_ = other.changedClanType_;
      changedClanName_ = other.changedClanName_;
      changedClanTag_ = other.changedClanTag_;
      primaryMember_ = other.primaryMember_;
      secondaryMember_ = other.secondaryMember_;
      changedMaxMemberCount_ = other.changedMaxMemberCount_;
      assignedRole_ = other.assignedRole_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanLogMessage Clone() {
      return new ClanLogMessage(this);
    }

    public const int ClanLogTypeFieldNumber = 1;
    private int clanLogType_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ClanLogType {
      get { return clanLogType_; }
      set {
        clanLogType_ = value;
      }
    }

    public const int ChangedClanTypeFieldNumber = 2;
    private int changedClanType_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ChangedClanType {
      get { return changedClanType_; }
      set {
        changedClanType_ = value;
      }
    }

    public const int ChangedClanNameFieldNumber = 3;
    private string changedClanName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ChangedClanName {
      get { return changedClanName_; }
      set {
        changedClanName_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ChangedClanTagFieldNumber = 4;
    private string changedClanTag_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string ChangedClanTag {
      get { return changedClanTag_; }
      set {
        changedClanTag_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PrimaryMemberFieldNumber = 5;
    private string primaryMember_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string PrimaryMember {
      get { return primaryMember_; }
      set {
        primaryMember_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int SecondaryMemberFieldNumber = 6;
    private string secondaryMember_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string SecondaryMember {
      get { return secondaryMember_; }
      set {
        secondaryMember_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ChangedMaxMemberCountFieldNumber = 7;
    private int changedMaxMemberCount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int ChangedMaxMemberCount {
      get { return changedMaxMemberCount_; }
      set {
        changedMaxMemberCount_ = value;
      }
    }

    public const int AssignedRoleFieldNumber = 8;
    private int assignedRole_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int AssignedRole {
      get { return assignedRole_; }
      set {
        assignedRole_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanLogMessage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanLogMessage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (ClanLogType != other.ClanLogType) return false;
      if (ChangedClanType != other.ChangedClanType) return false;
      if (ChangedClanName != other.ChangedClanName) return false;
      if (ChangedClanTag != other.ChangedClanTag) return false;
      if (PrimaryMember != other.PrimaryMember) return false;
      if (SecondaryMember != other.SecondaryMember) return false;
      if (ChangedMaxMemberCount != other.ChangedMaxMemberCount) return false;
      if (AssignedRole != other.AssignedRole) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (ClanLogType != 0) hash ^= ClanLogType.GetHashCode();
      if (ChangedClanType != 0) hash ^= ChangedClanType.GetHashCode();
      if (ChangedClanName.Length != 0) hash ^= ChangedClanName.GetHashCode();
      if (ChangedClanTag.Length != 0) hash ^= ChangedClanTag.GetHashCode();
      if (PrimaryMember.Length != 0) hash ^= PrimaryMember.GetHashCode();
      if (SecondaryMember.Length != 0) hash ^= SecondaryMember.GetHashCode();
      if (ChangedMaxMemberCount != 0) hash ^= ChangedMaxMemberCount.GetHashCode();
      if (AssignedRole != 0) hash ^= AssignedRole.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (ClanLogType != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ClanLogType);
      }
      if (ChangedClanType != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ChangedClanType);
      }
      if (ChangedClanName.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(ChangedClanName);
      }
      if (ChangedClanTag.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(ChangedClanTag);
      }
      if (PrimaryMember.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(PrimaryMember);
      }
      if (SecondaryMember.Length != 0) {
        output.WriteRawTag(50);
        output.WriteString(SecondaryMember);
      }
      if (ChangedMaxMemberCount != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(ChangedMaxMemberCount);
      }
      if (AssignedRole != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(AssignedRole);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (ClanLogType != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(ClanLogType);
      }
      if (ChangedClanType != 0) {
        output.WriteRawTag(16);
        output.WriteInt32(ChangedClanType);
      }
      if (ChangedClanName.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(ChangedClanName);
      }
      if (ChangedClanTag.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(ChangedClanTag);
      }
      if (PrimaryMember.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(PrimaryMember);
      }
      if (SecondaryMember.Length != 0) {
        output.WriteRawTag(50);
        output.WriteString(SecondaryMember);
      }
      if (ChangedMaxMemberCount != 0) {
        output.WriteRawTag(56);
        output.WriteInt32(ChangedMaxMemberCount);
      }
      if (AssignedRole != 0) {
        output.WriteRawTag(64);
        output.WriteInt32(AssignedRole);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (ClanLogType != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ClanLogType);
      }
      if (ChangedClanType != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ChangedClanType);
      }
      if (ChangedClanName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ChangedClanName);
      }
      if (ChangedClanTag.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ChangedClanTag);
      }
      if (PrimaryMember.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PrimaryMember);
      }
      if (SecondaryMember.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SecondaryMember);
      }
      if (ChangedMaxMemberCount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(ChangedMaxMemberCount);
      }
      if (AssignedRole != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(AssignedRole);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanLogMessage other) {
      if (other == null) {
        return;
      }
      if (other.ClanLogType != 0) {
        ClanLogType = other.ClanLogType;
      }
      if (other.ChangedClanType != 0) {
        ChangedClanType = other.ChangedClanType;
      }
      if (other.ChangedClanName.Length != 0) {
        ChangedClanName = other.ChangedClanName;
      }
      if (other.ChangedClanTag.Length != 0) {
        ChangedClanTag = other.ChangedClanTag;
      }
      if (other.PrimaryMember.Length != 0) {
        PrimaryMember = other.PrimaryMember;
      }
      if (other.SecondaryMember.Length != 0) {
        SecondaryMember = other.SecondaryMember;
      }
      if (other.ChangedMaxMemberCount != 0) {
        ChangedMaxMemberCount = other.ChangedMaxMemberCount;
      }
      if (other.AssignedRole != 0) {
        AssignedRole = other.AssignedRole;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            ClanLogType = input.ReadInt32();
            break;
          }
          case 16: {
            ChangedClanType = input.ReadInt32();
            break;
          }
          case 26: {
            ChangedClanName = input.ReadString();
            break;
          }
          case 34: {
            ChangedClanTag = input.ReadString();
            break;
          }
          case 42: {
            PrimaryMember = input.ReadString();
            break;
          }
          case 50: {
            SecondaryMember = input.ReadString();
            break;
          }
          case 56: {
            ChangedMaxMemberCount = input.ReadInt32();
            break;
          }
          case 64: {
            AssignedRole = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            ClanLogType = input.ReadInt32();
            break;
          }
          case 16: {
            ChangedClanType = input.ReadInt32();
            break;
          }
          case 26: {
            ChangedClanName = input.ReadString();
            break;
          }
          case 34: {
            ChangedClanTag = input.ReadString();
            break;
          }
          case 42: {
            PrimaryMember = input.ReadString();
            break;
          }
          case 50: {
            SecondaryMember = input.ReadString();
            break;
          }
          case 56: {
            ChangedMaxMemberCount = input.ReadInt32();
            break;
          }
          case 64: {
            AssignedRole = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanChatMessage : pb::IMessage<ClanChatMessage>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanChatMessage> _parser = new pb::MessageParser<ClanChatMessage>(() => new ClanChatMessage());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanChatMessage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[20]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanChatMessage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanChatMessage(ClanChatMessage other) : this() {
      senderId_ = other.senderId_;
      message_ = other.message_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanChatMessage Clone() {
      return new ClanChatMessage(this);
    }

    public const int SenderIdFieldNumber = 1;
    private string senderId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string SenderId {
      get { return senderId_; }
      set {
        senderId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int MessageFieldNumber = 2;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanChatMessage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanChatMessage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (SenderId != other.SenderId) return false;
      if (Message != other.Message) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (SenderId.Length != 0) hash ^= SenderId.GetHashCode();
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (SenderId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(SenderId);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (SenderId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(SenderId);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (SenderId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SenderId);
      }
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanChatMessage other) {
      if (other == null) {
        return;
      }
      if (other.SenderId.Length != 0) {
        SenderId = other.SenderId;
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            SenderId = input.ReadString();
            break;
          }
          case 18: {
            Message = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            SenderId = input.ReadString();
            break;
          }
          case 18: {
            Message = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  [global::System.Diagnostics.DebuggerDisplayAttribute("{ToString(),nq}")]
  public sealed partial class ClanUserMessage : pb::IMessage<ClanUserMessage>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ClanUserMessage> _parser = new pb::MessageParser<ClanUserMessage>(() => new ClanUserMessage());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pb::MessageParser<ClanUserMessage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ClanMessageReflection.Descriptor.MessageTypes[21]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanUserMessage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanUserMessage(ClanUserMessage other) : this() {
      id_ = other.id_;
      timestamp_ = other.timestamp_;
      messageType_ = other.messageType_;
      chatMessage_ = other.chatMessage_ != null ? other.chatMessage_.Clone() : null;
      logMessage_ = other.logMessage_ != null ? other.logMessage_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public ClanUserMessage Clone() {
      return new ClanUserMessage(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TimestampFieldNumber = 2;
    private long timestamp_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public long Timestamp {
      get { return timestamp_; }
      set {
        timestamp_ = value;
      }
    }

    public const int MessageTypeFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.MessageType messageType_ = global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.MessageType MessageType {
      get { return messageType_; }
      set {
        messageType_ = value;
      }
    }

    public const int ChatMessageFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.ClanChatMessage chatMessage_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanChatMessage ChatMessage {
      get { return chatMessage_; }
      set {
        chatMessage_ = value;
      }
    }

    public const int LogMessageFieldNumber = 5;
    private global::Axlebolt.Bolt.Protobuf2.ClanLogMessage logMessage_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public global::Axlebolt.Bolt.Protobuf2.ClanLogMessage LogMessage {
      get { return logMessage_; }
      set {
        logMessage_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override bool Equals(object other) {
      return Equals(other as ClanUserMessage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public bool Equals(ClanUserMessage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Timestamp != other.Timestamp) return false;
      if (MessageType != other.MessageType) return false;
      if (!object.Equals(ChatMessage, other.ChatMessage)) return false;
      if (!object.Equals(LogMessage, other.LogMessage)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Timestamp != 0L) hash ^= Timestamp.GetHashCode();
      if (MessageType != global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType) hash ^= MessageType.GetHashCode();
      if (chatMessage_ != null) hash ^= ChatMessage.GetHashCode();
      if (logMessage_ != null) hash ^= LogMessage.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Timestamp != 0L) {
        output.WriteRawTag(16);
        output.WriteInt64(Timestamp);
      }
      if (MessageType != global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType) {
        output.WriteRawTag(24);
        output.WriteEnum((int) MessageType);
      }
      if (chatMessage_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(ChatMessage);
      }
      if (logMessage_ != null) {
        output.WriteRawTag(50);
        output.WriteMessage(LogMessage);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Timestamp != 0L) {
        output.WriteRawTag(16);
        output.WriteInt64(Timestamp);
      }
      if (MessageType != global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType) {
        output.WriteRawTag(24);
        output.WriteEnum((int) MessageType);
      }
      if (chatMessage_ != null) {
        output.WriteRawTag(34);
        output.WriteMessage(ChatMessage);
      }
      if (logMessage_ != null) {
        output.WriteRawTag(50);
        output.WriteMessage(LogMessage);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Timestamp != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Timestamp);
      }
      if (MessageType != global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) MessageType);
      }
      if (chatMessage_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(ChatMessage);
      }
      if (logMessage_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(LogMessage);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(ClanUserMessage other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Timestamp != 0L) {
        Timestamp = other.Timestamp;
      }
      if (other.MessageType != global::Axlebolt.Bolt.Protobuf2.MessageType.NoneType) {
        MessageType = other.MessageType;
      }
      if (other.chatMessage_ != null) {
        if (chatMessage_ == null) {
          ChatMessage = new global::Axlebolt.Bolt.Protobuf2.ClanChatMessage();
        }
        ChatMessage.MergeFrom(other.ChatMessage);
      }
      if (other.logMessage_ != null) {
        if (logMessage_ == null) {
          LogMessage = new global::Axlebolt.Bolt.Protobuf2.ClanLogMessage();
        }
        LogMessage.MergeFrom(other.LogMessage);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 16: {
            Timestamp = input.ReadInt64();
            break;
          }
          case 24: {
            MessageType = (global::Axlebolt.Bolt.Protobuf2.MessageType) input.ReadEnum();
            break;
          }
          case 34: {
            if (chatMessage_ == null) {
              ChatMessage = new global::Axlebolt.Bolt.Protobuf2.ClanChatMessage();
            }
            input.ReadMessage(ChatMessage);
            break;
          }
          case 50: {
            if (logMessage_ == null) {
              LogMessage = new global::Axlebolt.Bolt.Protobuf2.ClanLogMessage();
            }
            input.ReadMessage(LogMessage);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    [global::System.CodeDom.Compiler.GeneratedCode("protoc", null)]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
      if ((tag & 7) == 4) {

        return;
      }
      switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 16: {
            Timestamp = input.ReadInt64();
            break;
          }
          case 24: {
            MessageType = (global::Axlebolt.Bolt.Protobuf2.MessageType) input.ReadEnum();
            break;
          }
          case 34: {
            if (chatMessage_ == null) {
              ChatMessage = new global::Axlebolt.Bolt.Protobuf2.ClanChatMessage();
            }
            input.ReadMessage(ChatMessage);
            break;
          }
          case 50: {
            if (logMessage_ == null) {
              LogMessage = new global::Axlebolt.Bolt.Protobuf2.ClanLogMessage();
            }
            input.ReadMessage(LogMessage);
            break;
          }
        }
      }
    }
    #endif

  }


}

