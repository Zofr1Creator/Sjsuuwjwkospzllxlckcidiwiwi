#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class GroupsMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static GroupsMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChNHcm91cHNNZXNzYWdlLnByb3RvEhdBeGxlYm9sdC5Cb2x0LlByb3RvYnVm",
            "MhoTUGxheWVyTWVzc2FnZS5wcm90byJlCgVHcm91cBIKCgJpZBgBIAEoCRIM",
            "CgRuYW1lGAIgASgJEhAKCGF2YXRhcklkGAMgASgJEjAKB3BsYXllcnMYBCAD",
            "KAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXJiBnByb3RvMw=="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Group), global::Axlebolt.Bolt.Protobuf2.Group.Parser, new[]{ "Id", "Name", "AvatarId", "Players" }, null, null, null)
          }));
    }

  }
  public sealed partial class Group : pb::IMessage<Group> {
    private static readonly pb::MessageParser<Group> _parser = new pb::MessageParser<Group>(() => new Group());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Group> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.GroupsMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Group() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Group(Group other) : this() {
      id_ = other.id_;
      name_ = other.name_;
      avatarId_ = other.avatarId_;
      players_ = other.players_.Clone();
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Group Clone() {
      return new Group(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NameFieldNumber = 2;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AvatarIdFieldNumber = 3;
    private string avatarId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string AvatarId {
      get { return avatarId_; }
      set {
        avatarId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayersFieldNumber = 4;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Player> _repeated_players_codec
        = pb::FieldCodec.ForMessage(34, global::Axlebolt.Bolt.Protobuf2.Player.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> players_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> Players {
      get { return players_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Group);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Group other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (Name != other.Name) return false;
      if (AvatarId != other.AvatarId) return false;
      if(!players_.Equals(other.players_)) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (AvatarId.Length != 0) hash ^= AvatarId.GetHashCode();
      hash ^= players_.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Name);
      }
      if (AvatarId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(AvatarId);
      }
      players_.WriteTo(output, _repeated_players_codec);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (AvatarId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AvatarId);
      }
      size += players_.CalculateSize(_repeated_players_codec);
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Group other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.AvatarId.Length != 0) {
        AvatarId = other.AvatarId;
      }
      players_.Add(other.players_);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            Name = input.ReadString();
            break;
          }
          case 26: {
            AvatarId = input.ReadString();
            break;
          }
          case 34: {
            players_.AddEntriesFrom(input, _repeated_players_codec);
            break;
          }
        }
      }
    }

  }


}

