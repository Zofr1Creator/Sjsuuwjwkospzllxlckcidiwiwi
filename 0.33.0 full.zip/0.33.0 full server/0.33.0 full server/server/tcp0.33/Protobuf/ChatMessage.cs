#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class ChatMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static ChatMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChFDaGF0TWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIa",
            "E0dyb3Vwc01lc3NhZ2UucHJvdG8aFEZyaWVuZHNNZXNzYWdlLnByb3RvGhNQ",
            "bGF5ZXJNZXNzYWdlLnByb3RvIpQBCghDaGF0VXNlchI1CgZwbGF5ZXIYASAB",
            "KAsyJS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXJGcmllbmQSLQoF",
            "Z3JvdXAYAiABKAsyHi5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Hcm91cBIP",
            "CgdtZXNzYWdlGAMgASgJEhEKCXRpbWVzdGFtcBgEIAEoAyJTCgtVc2VyTWVz",
            "c2FnZRIQCghzZW5kZXJJZBgBIAEoCRIPCgdtZXNzYWdlGAIgASgJEhEKCXRp",
            "bWVzdGFtcBgDIAEoAxIOCgZpc1JlYWQYBCABKAgibAoVR2xvYmFsQ2hhdFVz",
            "ZXJNZXNzYWdlEg8KB21lc3NhZ2UYASABKAkSLwoGc2VuZGVyGAIgASgLMh8u",
            "QXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUGxheWVyEhEKCXRpbWVzdGFtcBgD",
            "IAEoA2IGcHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.GroupsMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.FriendsMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ChatUser), global::Axlebolt.Bolt.Protobuf2.ChatUser.Parser, new[]{ "Player", "Group", "Message", "Timestamp" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.UserMessage), global::Axlebolt.Bolt.Protobuf2.UserMessage.Parser, new[]{ "SenderId", "Message", "Timestamp", "IsRead" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GlobalChatUserMessage), global::Axlebolt.Bolt.Protobuf2.GlobalChatUserMessage.Parser, new[]{ "Message", "Sender", "Timestamp" }, null, null, null)
          }));
    }

  }
  public sealed partial class ChatUser : pb::IMessage<ChatUser> {
    private static readonly pb::MessageParser<ChatUser> _parser = new pb::MessageParser<ChatUser>(() => new ChatUser());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ChatUser> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChatMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChatUser() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChatUser(ChatUser other) : this() {
      Player = other.player_ != null ? other.Player.Clone() : null;
      Group = other.group_ != null ? other.Group.Clone() : null;
      message_ = other.message_;
      timestamp_ = other.timestamp_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChatUser Clone() {
      return new ChatUser(this);
    }

    public const int PlayerFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend player_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend Player {
      get { return player_; }
      set {
        player_ = value;
      }
    }

    public const int GroupFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Group group_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Group Group {
      get { return group_; }
      set {
        group_ = value;
      }
    }

    public const int MessageFieldNumber = 3;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TimestampFieldNumber = 4;
    private long timestamp_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Timestamp {
      get { return timestamp_; }
      set {
        timestamp_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ChatUser);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ChatUser other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Player, other.Player)) return false;
      if (!object.Equals(Group, other.Group)) return false;
      if (Message != other.Message) return false;
      if (Timestamp != other.Timestamp) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (player_ != null) hash ^= Player.GetHashCode();
      if (group_ != null) hash ^= Group.GetHashCode();
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (Timestamp != 0L) hash ^= Timestamp.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (player_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Player);
      }
      if (group_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Group);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Message);
      }
      if (Timestamp != 0L) {
        output.WriteRawTag(32);
        output.WriteInt64(Timestamp);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (player_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Player);
      }
      if (group_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Group);
      }
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (Timestamp != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Timestamp);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ChatUser other) {
      if (other == null) {
        return;
      }
      if (other.player_ != null) {
        if (player_ == null) {
          player_ = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        Player.MergeFrom(other.Player);
      }
      if (other.group_ != null) {
        if (group_ == null) {
          group_ = new global::Axlebolt.Bolt.Protobuf2.Group();
        }
        Group.MergeFrom(other.Group);
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      if (other.Timestamp != 0L) {
        Timestamp = other.Timestamp;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            if (player_ == null) {
              player_ = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(player_);
            break;
          }
          case 18: {
            if (group_ == null) {
              group_ = new global::Axlebolt.Bolt.Protobuf2.Group();
            }
            input.ReadMessage(group_);
            break;
          }
          case 26: {
            Message = input.ReadString();
            break;
          }
          case 32: {
            Timestamp = input.ReadInt64();
            break;
          }
        }
      }
    }

  }

  public sealed partial class UserMessage : pb::IMessage<UserMessage> {
    private static readonly pb::MessageParser<UserMessage> _parser = new pb::MessageParser<UserMessage>(() => new UserMessage());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<UserMessage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChatMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserMessage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserMessage(UserMessage other) : this() {
      senderId_ = other.senderId_;
      message_ = other.message_;
      timestamp_ = other.timestamp_;
      isRead_ = other.isRead_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public UserMessage Clone() {
      return new UserMessage(this);
    }

    public const int SenderIdFieldNumber = 1;
    private string senderId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string SenderId {
      get { return senderId_; }
      set {
        senderId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int MessageFieldNumber = 2;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TimestampFieldNumber = 3;
    private long timestamp_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Timestamp {
      get { return timestamp_; }
      set {
        timestamp_ = value;
      }
    }

    public const int IsReadFieldNumber = 4;
    private bool isRead_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool IsRead {
      get { return isRead_; }
      set {
        isRead_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as UserMessage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(UserMessage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (SenderId != other.SenderId) return false;
      if (Message != other.Message) return false;
      if (Timestamp != other.Timestamp) return false;
      if (IsRead != other.IsRead) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (SenderId.Length != 0) hash ^= SenderId.GetHashCode();
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (Timestamp != 0L) hash ^= Timestamp.GetHashCode();
      if (IsRead != false) hash ^= IsRead.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (SenderId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(SenderId);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Message);
      }
      if (Timestamp != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Timestamp);
      }
      if (IsRead != false) {
        output.WriteRawTag(32);
        output.WriteBool(IsRead);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (SenderId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(SenderId);
      }
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (Timestamp != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Timestamp);
      }
      if (IsRead != false) {
        size += 1 + 1;
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(UserMessage other) {
      if (other == null) {
        return;
      }
      if (other.SenderId.Length != 0) {
        SenderId = other.SenderId;
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      if (other.Timestamp != 0L) {
        Timestamp = other.Timestamp;
      }
      if (other.IsRead != false) {
        IsRead = other.IsRead;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            SenderId = input.ReadString();
            break;
          }
          case 18: {
            Message = input.ReadString();
            break;
          }
          case 24: {
            Timestamp = input.ReadInt64();
            break;
          }
          case 32: {
            IsRead = input.ReadBool();
            break;
          }
        }
      }
    }

  }

  public sealed partial class GlobalChatUserMessage : pb::IMessage<GlobalChatUserMessage> {
    private static readonly pb::MessageParser<GlobalChatUserMessage> _parser = new pb::MessageParser<GlobalChatUserMessage>(() => new GlobalChatUserMessage());
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GlobalChatUserMessage> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.ChatMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GlobalChatUserMessage() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GlobalChatUserMessage(GlobalChatUserMessage other) : this() {
      message_ = other.message_;
      Sender = other.sender_ != null ? other.Sender.Clone() : null;
      timestamp_ = other.timestamp_;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GlobalChatUserMessage Clone() {
      return new GlobalChatUserMessage(this);
    }

    public const int MessageFieldNumber = 1;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int SenderFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.Player sender_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Player Sender {
      get { return sender_; }
      set {
        sender_ = value;
      }
    }

    public const int TimestampFieldNumber = 3;
    private long timestamp_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Timestamp {
      get { return timestamp_; }
      set {
        timestamp_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GlobalChatUserMessage);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GlobalChatUserMessage other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Message != other.Message) return false;
      if (!object.Equals(Sender, other.Sender)) return false;
      if (Timestamp != other.Timestamp) return false;
      return true;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (sender_ != null) hash ^= Sender.GetHashCode();
      if (Timestamp != 0L) hash ^= Timestamp.GetHashCode();
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
      if (Message.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Message);
      }
      if (sender_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(Sender);
      }
      if (Timestamp != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Timestamp);
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (sender_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Sender);
      }
      if (Timestamp != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Timestamp);
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GlobalChatUserMessage other) {
      if (other == null) {
        return;
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      if (other.sender_ != null) {
        if (sender_ == null) {
          sender_ = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Sender.MergeFrom(other.Sender);
      }
      if (other.Timestamp != 0L) {
        Timestamp = other.Timestamp;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            input.SkipLastField();
            break;
          case 10: {
            Message = input.ReadString();
            break;
          }
          case 18: {
            if (sender_ == null) {
              sender_ = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(sender_);
            break;
          }
          case 24: {
            Timestamp = input.ReadInt64();
            break;
          }
        }
      }
    }

  }


}

