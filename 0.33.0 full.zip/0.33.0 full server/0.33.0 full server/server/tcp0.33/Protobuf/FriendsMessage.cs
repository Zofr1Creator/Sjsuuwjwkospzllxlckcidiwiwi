#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class FriendsMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static FriendsMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChRGcmllbmRzTWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1",
            "ZjIaE1BsYXllck1lc3NhZ2UucHJvdG8itQEKDFBsYXllckZyaWVuZBIvCgZw",
            "bGF5ZXIYASABKAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXIS",
            "RwoScmVsYXRpb25zaGlwU3RhdHVzGAIgASgOMisuQXhsZWJvbHQuQm9sdC5Q",
            "cm90b2J1ZjIuUmVsYXRpb25zaGlwU3RhdHVzEh4KFmxhc3RSZWxhdGlvbnNo",
            "aXBVcGRhdGUYAyABKAMSCwoDbXNnGAQgASgJKnAKElJlbGF0aW9uc2hpcFN0",
            "YXR1cxIICgROb25lEAASCwoHQmxvY2tlZBABEhQKEFJlcXVlc3RSZWNpcGll",
            "bnQQAhIKCgZGcmllbmQQAxIUChBSZXF1ZXN0SW5pdGlhdG9yEAQSCwoHSWdu",
            "b3JlZBAFKkEKDU1lc3NhZ2VTdGF0dXMSCAoEU2VudBAAEgwKCFJlY2VpdmVk",
            "EAESCAoEUmVhZBACEg4KClNlbnRGYWlsZWQQA2IGcHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.RelationshipStatus), typeof(global::Axlebolt.Bolt.Protobuf2.MessageStatus), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.PlayerFriend), global::Axlebolt.Bolt.Protobuf2.PlayerFriend.Parser, new[]{ "Player", "RelationshipStatus", "LastRelationshipUpdate", "Msg" }, null, null, null, null)
          }));
    }

  }
  public enum RelationshipStatus {
    [pbr::OriginalName("None")] None = 0,
    [pbr::OriginalName("Blocked")] Blocked = 1,
    [pbr::OriginalName("RequestInitiator")] RequestInitiator = 2,
    [pbr::OriginalName("Friend")] Friend = 3,
    [pbr::OriginalName("RequestRecipient")] RequestRecipient = 4,
    [pbr::OriginalName("Ignored")] Ignored = 5,
  }

  public enum MessageStatus {
    [pbr::OriginalName("Sent")] Sent = 0,
    [pbr::OriginalName("Received")] Received = 1,
    [pbr::OriginalName("Read")] Read = 2,
    [pbr::OriginalName("SentFailed")] SentFailed = 3,
  }


  public sealed partial class PlayerFriend : pb::IMessage<PlayerFriend>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<PlayerFriend> _parser = new pb::MessageParser<PlayerFriend>(() => new PlayerFriend());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<PlayerFriend> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.FriendsMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerFriend() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerFriend(PlayerFriend other) : this() {
      player_ = other.player_ != null ? other.player_.Clone() : null;
      relationshipStatus_ = other.relationshipStatus_;
      lastRelationshipUpdate_ = other.lastRelationshipUpdate_;
      msg_ = other.msg_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public PlayerFriend Clone() {
      return new PlayerFriend(this);
    }

    public const int PlayerFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Player player_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Player Player {
      get { return player_; }
      set {
        player_ = value;
      }
    }

    public const int RelationshipStatusFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.RelationshipStatus relationshipStatus_ = global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.RelationshipStatus RelationshipStatus {
      get { return relationshipStatus_; }
      set {
        relationshipStatus_ = value;
      }
    }

    public const int LastRelationshipUpdateFieldNumber = 3;
    private long lastRelationshipUpdate_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long LastRelationshipUpdate {
      get { return lastRelationshipUpdate_; }
      set {
        lastRelationshipUpdate_ = value;
      }
    }

    public const int MsgFieldNumber = 4;
    private string msg_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Msg {
      get { return msg_; }
      set {
        msg_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as PlayerFriend);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(PlayerFriend other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Player, other.Player)) return false;
      if (RelationshipStatus != other.RelationshipStatus) return false;
      if (LastRelationshipUpdate != other.LastRelationshipUpdate) return false;
      if (Msg != other.Msg) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (player_ != null) hash ^= Player.GetHashCode();
      if (RelationshipStatus != global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None) hash ^= RelationshipStatus.GetHashCode();
      if (LastRelationshipUpdate != 0L) hash ^= LastRelationshipUpdate.GetHashCode();
      if (Msg.Length != 0) hash ^= Msg.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (player_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Player);
      }
      if (RelationshipStatus != global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None) {
        output.WriteRawTag(16);
        output.WriteEnum((int) RelationshipStatus);
      }
      if (LastRelationshipUpdate != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(LastRelationshipUpdate);
      }
      if (Msg.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Msg);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (player_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Player);
      }
      if (RelationshipStatus != global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None) {
        output.WriteRawTag(16);
        output.WriteEnum((int) RelationshipStatus);
      }
      if (LastRelationshipUpdate != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(LastRelationshipUpdate);
      }
      if (Msg.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Msg);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (player_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Player);
      }
      if (RelationshipStatus != global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) RelationshipStatus);
      }
      if (LastRelationshipUpdate != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(LastRelationshipUpdate);
      }
      if (Msg.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Msg);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(PlayerFriend other) {
      if (other == null) {
        return;
      }
      if (other.player_ != null) {
        if (player_ == null) {
          Player = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Player.MergeFrom(other.Player);
      }
      if (other.RelationshipStatus != global::Axlebolt.Bolt.Protobuf2.RelationshipStatus.None) {
        RelationshipStatus = other.RelationshipStatus;
      }
      if (other.LastRelationshipUpdate != 0L) {
        LastRelationshipUpdate = other.LastRelationshipUpdate;
      }
      if (other.Msg.Length != 0) {
        Msg = other.Msg;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
          case 16: {
            RelationshipStatus = (global::Axlebolt.Bolt.Protobuf2.RelationshipStatus) input.ReadEnum();
            break;
          }
          case 24: {
            LastRelationshipUpdate = input.ReadInt64();
            break;
          }
          case 34: {
            Msg = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (player_ == null) {
              Player = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Player);
            break;
          }
          case 16: {
            RelationshipStatus = (global::Axlebolt.Bolt.Protobuf2.RelationshipStatus) input.ReadEnum();
            break;
          }
          case 24: {
            LastRelationshipUpdate = input.ReadInt64();
            break;
          }
          case 34: {
            Msg = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }


}

