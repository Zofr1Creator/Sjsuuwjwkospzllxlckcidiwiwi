#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class AuthMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static AuthMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChFBdXRoTWVzc2FnZS5wcm90bxIXQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIa",
            "E0NvbW1vbk1lc3NhZ2UucHJvdG8iGwoJSGFuZHNoYWtlEg4KBnRpY2tldBgB",
            "IAEoCSJvChFIYW5kc2hha2VSZXNwb25zZRIPCgdjb3VudHJ5GAEgASgJEjYK",
            "CHNldHRpbmdzGAIgAygLMiQuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuQm9s",
            "dFNldHRpbmcSEQoJdGltZXN0YW1wGAMgASgDIrYBCgtCb2x0U2V0dGluZxIL",
            "CgNrZXkYASABKAkSNgoEdHlwZRgCIAEoDjIoLkF4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyLkJvbHRTZXR0aW5nVHlwZRITCgtzdHJpbmdWYWx1ZRgDIAEoCRIQ",
            "CghpbnRWYWx1ZRgEIAEoBRISCgpmbG9hdFZhbHVlGAUgASgCEhQKDGJvb2xl",
            "YW5WYWx1ZRgGIAEoCBIRCglsb25nVmFsdWUYByABKAMitwEKCkF1dGhHb29n",
            "bGUSDgoGZ2FtZUlkGAEgASgJEhMKC2dhbWVWZXJzaW9uGAIgASgJEjMKCHBs",
            "YXRmb3JtGAMgASgOMiEuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuUGxhdGZv",
            "cm0SEAoIYXV0aENvZGUYBCABKAkSDgoGbG9jYWxlGAUgASgJEi0KBXN0b3Jl",
            "GAYgASgOMh4uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuU3RvcmUiyAEKEUdv",
            "b2dsZUF1dGhSZXF1ZXN0EjcKCmF1dGhHb29nbGUYASABKAsyIy5BeGxlYm9s",
            "dC5Cb2x0LlByb3RvYnVmMi5BdXRoR29vZ2xlEkEKD2FwcFZlcmlmaWNhdGlv",
            "bhgCIAEoCzIoLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkFwcFZlcmlmaWNh",
            "dGlvbhI3CgpkZXZpY2VJbmZvGAMgASgLMiMuQXhsZWJvbHQuQm9sdC5Qcm90",
            "b2J1ZjIuRGV2aWNlSW5mbyJfChJHb29nbGVBdXRoUmVzcG9uc2USEAoGdGlj",
            "a2V0GAEgASgJSAASFgoMdGlja2V0QmluYXJ5GAIgASgMSAASFAoMcGxheWVy",
            "VGlja2V0GAMgASgJQgkKB3RpY2tldHMitgEKCUF1dGhUb2tlbhIOCgZnYW1l",
            "SWQYASABKAkSEwoLZ2FtZVZlcnNpb24YAiABKAkSMwoIcGxhdGZvcm0YAyAB",
            "KA4yIS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF0Zm9ybRIQCghhdXRo",
            "Q29kZRgEIAEoCRIOCgZsb2NhbGUYBSABKAkSLQoFc3RvcmUYBiABKA4yHi5B",
            "eGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5TdG9yZSI3Cg9FbnZpcm9ubWVudElu",
            "Zm8SDwoHdmVyc2lvbhgBIAEoBRITCgtlbnZpcm9ubWVudBgCIAEoDCLaAgoP",
            "QXBwVmVyaWZpY2F0aW9uEhAKCGlzUm9vdGVkGAEgASgIEg8KB2Fwa0hhc2gY",
            "AiABKAkSGQoRanNvbkZvcmJpZGRlbkFwcHMYAyADKAkSDAoEcGF0aBgEIAEo",
            "CRITCgtjb250ZW50SGFzaBgFIAEoCRJOCgthcHBTbmFwc2hvdBgGIAMoCzI5",
            "LkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkFwcFZlcmlmaWNhdGlvbi5BcHBT",
            "bmFwc2hvdEVudHJ5EgkKAW4YByABKAwSCQoBZRgIIAEoDBI9CgtlbnZpcm9u",
            "bWVudBgJIAEoCzIoLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkVudmlyb25t",
            "ZW50SW5mbxINCgV0b2tlbhgKIAEoCRoyChBBcHBTbmFwc2hvdEVudHJ5EgsK",
            "A2tleRgBIAEoCRINCgV2YWx1ZRgCIAEoCToCOAEiQgoKRGV2aWNlSW5mbxIQ",
            "CghkZXZpY2VJZBgBIAEoCRITCgtkZXZpY2VNb2RlbBgCIAEoCRINCgVhZHNJ",
            "ZBgDIAEoCSpJCg9Cb2x0U2V0dGluZ1R5cGUSCgoGU3RyaW5nEAASCwoHSW50",
            "ZWdlchABEgkKBUZsb2F0EAISCAoEQm9vbBADEggKBExvbmcQBGIGcHJvdG8z"));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CommonMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.BoltSettingType), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Handshake), global::Axlebolt.Bolt.Protobuf2.Handshake.Parser, new[]{ "Ticket" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.HandshakeResponse), global::Axlebolt.Bolt.Protobuf2.HandshakeResponse.Parser, new[]{ "Country", "Settings", "Timestamp" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.BoltSetting), global::Axlebolt.Bolt.Protobuf2.BoltSetting.Parser, new[]{ "Key", "Type", "StringValue", "IntValue", "FloatValue", "BooleanValue", "LongValue" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.AuthGoogle), global::Axlebolt.Bolt.Protobuf2.AuthGoogle.Parser, new[]{ "GameId", "GameVersion", "Platform", "AuthCode", "Locale", "Store" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GoogleAuthRequest), global::Axlebolt.Bolt.Protobuf2.GoogleAuthRequest.Parser, new[]{ "AuthGoogle", "AppVerification", "DeviceInfo" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GoogleAuthResponse), global::Axlebolt.Bolt.Protobuf2.GoogleAuthResponse.Parser, new[]{ "Ticket", "TicketBinary", "PlayerTicket" }, new[]{ "Tickets" }, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.AuthToken), global::Axlebolt.Bolt.Protobuf2.AuthToken.Parser, new[]{ "GameId", "GameVersion", "Platform", "AuthCode", "Locale", "Store" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo), global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo.Parser, new[]{ "Version", "Environment" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.AppVerification), global::Axlebolt.Bolt.Protobuf2.AppVerification.Parser, new[]{ "IsRooted", "ApkHash", "JsonForbiddenApps", "Path", "ContentHash", "AppSnapshot", "N", "E", "Environment", "Token" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.DeviceInfo), global::Axlebolt.Bolt.Protobuf2.DeviceInfo.Parser, new[]{ "DeviceId", "DeviceModel", "AdsId" }, null, null, null, null)
          }));
    }

  }
  public enum BoltSettingType {
    [pbr::OriginalName("String")] String = 0,
    [pbr::OriginalName("Integer")] Integer = 1,
    [pbr::OriginalName("Float")] Float = 2,
    [pbr::OriginalName("Bool")] Bool = 3,
    [pbr::OriginalName("Long")] Long = 4,
  }



  public sealed partial class Handshake : pb::IMessage<Handshake>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<Handshake> _parser = new pb::MessageParser<Handshake>(() => new Handshake());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Handshake> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Handshake() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Handshake(Handshake other) : this() {
      ticket_ = other.ticket_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Handshake Clone() {
      return new Handshake(this);
    }

    public const int TicketFieldNumber = 1;
    private string ticket_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Ticket {
      get { return ticket_; }
      set {
        ticket_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Handshake);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Handshake other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Ticket != other.Ticket) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Ticket.Length != 0) hash ^= Ticket.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Ticket.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Ticket);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Ticket.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Ticket);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Ticket.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Ticket);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Handshake other) {
      if (other == null) {
        return;
      }
      if (other.Ticket.Length != 0) {
        Ticket = other.Ticket;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Ticket = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Ticket = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class HandshakeResponse : pb::IMessage<HandshakeResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<HandshakeResponse> _parser = new pb::MessageParser<HandshakeResponse>(() => new HandshakeResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<HandshakeResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public HandshakeResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public HandshakeResponse(HandshakeResponse other) : this() {
      country_ = other.country_;
      settings_ = other.settings_.Clone();
      timestamp_ = other.timestamp_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public HandshakeResponse Clone() {
      return new HandshakeResponse(this);
    }

    public const int CountryFieldNumber = 1;
    private string country_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Country {
      get { return country_; }
      set {
        country_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int SettingsFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.BoltSetting> _repeated_settings_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.BoltSetting.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.BoltSetting> settings_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.BoltSetting>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.BoltSetting> Settings {
      get { return settings_; }
    }

    public const int TimestampFieldNumber = 3;
    private long timestamp_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Timestamp {
      get { return timestamp_; }
      set {
        timestamp_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as HandshakeResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(HandshakeResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Country != other.Country) return false;
      if(!settings_.Equals(other.settings_)) return false;
      if (Timestamp != other.Timestamp) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Country.Length != 0) hash ^= Country.GetHashCode();
      hash ^= settings_.GetHashCode();
      if (Timestamp != 0L) hash ^= Timestamp.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Country.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Country);
      }
      settings_.WriteTo(output, _repeated_settings_codec);
      if (Timestamp != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Timestamp);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Country.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Country);
      }
      settings_.WriteTo(ref output, _repeated_settings_codec);
      if (Timestamp != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Timestamp);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Country.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Country);
      }
      size += settings_.CalculateSize(_repeated_settings_codec);
      if (Timestamp != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Timestamp);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(HandshakeResponse other) {
      if (other == null) {
        return;
      }
      if (other.Country.Length != 0) {
        Country = other.Country;
      }
      settings_.Add(other.settings_);
      if (other.Timestamp != 0L) {
        Timestamp = other.Timestamp;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Country = input.ReadString();
            break;
          }
          case 18: {
            settings_.AddEntriesFrom(input, _repeated_settings_codec);
            break;
          }
          case 24: {
            Timestamp = input.ReadInt64();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Country = input.ReadString();
            break;
          }
          case 18: {
            settings_.AddEntriesFrom(ref input, _repeated_settings_codec);
            break;
          }
          case 24: {
            Timestamp = input.ReadInt64();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class BoltSetting : pb::IMessage<BoltSetting>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<BoltSetting> _parser = new pb::MessageParser<BoltSetting>(() => new BoltSetting());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<BoltSetting> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public BoltSetting() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public BoltSetting(BoltSetting other) : this() {
      key_ = other.key_;
      type_ = other.type_;
      stringValue_ = other.stringValue_;
      intValue_ = other.intValue_;
      floatValue_ = other.floatValue_;
      booleanValue_ = other.booleanValue_;
      longValue_ = other.longValue_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public BoltSetting Clone() {
      return new BoltSetting(this);
    }

    public const int KeyFieldNumber = 1;
    private string key_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Key {
      get { return key_; }
      set {
        key_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int TypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.BoltSettingType type_ = global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.BoltSettingType Type {
      get { return type_; }
      set {
        type_ = value;
      }
    }

    public const int StringValueFieldNumber = 3;
    private string stringValue_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string StringValue {
      get { return stringValue_; }
      set {
        stringValue_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int IntValueFieldNumber = 4;
    private int intValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int IntValue {
      get { return intValue_; }
      set {
        intValue_ = value;
      }
    }

    public const int FloatValueFieldNumber = 5;
    private float floatValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public float FloatValue {
      get { return floatValue_; }
      set {
        floatValue_ = value;
      }
    }

    public const int BooleanValueFieldNumber = 6;
    private bool booleanValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool BooleanValue {
      get { return booleanValue_; }
      set {
        booleanValue_ = value;
      }
    }

    public const int LongValueFieldNumber = 7;
    private long longValue_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long LongValue {
      get { return longValue_; }
      set {
        longValue_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as BoltSetting);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(BoltSetting other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Key != other.Key) return false;
      if (Type != other.Type) return false;
      if (StringValue != other.StringValue) return false;
      if (IntValue != other.IntValue) return false;
      if (!pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.Equals(FloatValue, other.FloatValue)) return false;
      if (BooleanValue != other.BooleanValue) return false;
      if (LongValue != other.LongValue) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Key.Length != 0) hash ^= Key.GetHashCode();
      if (Type != global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String) hash ^= Type.GetHashCode();
      if (StringValue.Length != 0) hash ^= StringValue.GetHashCode();
      if (IntValue != 0) hash ^= IntValue.GetHashCode();
      if (FloatValue != 0F) hash ^= pbc::ProtobufEqualityComparers.BitwiseSingleEqualityComparer.GetHashCode(FloatValue);
      if (BooleanValue != false) hash ^= BooleanValue.GetHashCode();
      if (LongValue != 0L) hash ^= LongValue.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Key.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Key);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Type);
      }
      if (StringValue.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(StringValue);
      }
      if (IntValue != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(FloatValue);
      }
      if (BooleanValue != false) {
        output.WriteRawTag(48);
        output.WriteBool(BooleanValue);
      }
      if (LongValue != 0L) {
        output.WriteRawTag(56);
        output.WriteInt64(LongValue);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Key.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Key);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String) {
        output.WriteRawTag(16);
        output.WriteEnum((int) Type);
      }
      if (StringValue.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(StringValue);
      }
      if (IntValue != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(IntValue);
      }
      if (FloatValue != 0F) {
        output.WriteRawTag(45);
        output.WriteFloat(FloatValue);
      }
      if (BooleanValue != false) {
        output.WriteRawTag(48);
        output.WriteBool(BooleanValue);
      }
      if (LongValue != 0L) {
        output.WriteRawTag(56);
        output.WriteInt64(LongValue);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Key.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Key);
      }
      if (Type != global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Type);
      }
      if (StringValue.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(StringValue);
      }
      if (IntValue != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(IntValue);
      }
      if (FloatValue != 0F) {
        size += 1 + 4;
      }
      if (BooleanValue != false) {
        size += 1 + 1;
      }
      if (LongValue != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(LongValue);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(BoltSetting other) {
      if (other == null) {
        return;
      }
      if (other.Key.Length != 0) {
        Key = other.Key;
      }
      if (other.Type != global::Axlebolt.Bolt.Protobuf2.BoltSettingType.String) {
        Type = other.Type;
      }
      if (other.StringValue.Length != 0) {
        StringValue = other.StringValue;
      }
      if (other.IntValue != 0) {
        IntValue = other.IntValue;
      }
      if (other.FloatValue != 0F) {
        FloatValue = other.FloatValue;
      }
      if (other.BooleanValue != false) {
        BooleanValue = other.BooleanValue;
      }
      if (other.LongValue != 0L) {
        LongValue = other.LongValue;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Key = input.ReadString();
            break;
          }
          case 16: {
            Type = (global::Axlebolt.Bolt.Protobuf2.BoltSettingType) input.ReadEnum();
            break;
          }
          case 26: {
            StringValue = input.ReadString();
            break;
          }
          case 32: {
            IntValue = input.ReadInt32();
            break;
          }
          case 45: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 48: {
            BooleanValue = input.ReadBool();
            break;
          }
          case 56: {
            LongValue = input.ReadInt64();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Key = input.ReadString();
            break;
          }
          case 16: {
            Type = (global::Axlebolt.Bolt.Protobuf2.BoltSettingType) input.ReadEnum();
            break;
          }
          case 26: {
            StringValue = input.ReadString();
            break;
          }
          case 32: {
            IntValue = input.ReadInt32();
            break;
          }
          case 45: {
            FloatValue = input.ReadFloat();
            break;
          }
          case 48: {
            BooleanValue = input.ReadBool();
            break;
          }
          case 56: {
            LongValue = input.ReadInt64();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class AuthGoogle : pb::IMessage<AuthGoogle>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<AuthGoogle> _parser = new pb::MessageParser<AuthGoogle>(() => new AuthGoogle());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<AuthGoogle> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthGoogle() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthGoogle(AuthGoogle other) : this() {
      gameId_ = other.gameId_;
      gameVersion_ = other.gameVersion_;
      platform_ = other.platform_;
      authCode_ = other.authCode_;
      locale_ = other.locale_;
      store_ = other.store_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthGoogle Clone() {
      return new AuthGoogle(this);
    }

    public const int GameIdFieldNumber = 1;
    private string gameId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameId {
      get { return gameId_; }
      set {
        gameId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int GameVersionFieldNumber = 2;
    private string gameVersion_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameVersion {
      get { return gameVersion_; }
      set {
        gameVersion_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlatformFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Platform platform_ = global::Axlebolt.Bolt.Protobuf2.Platform.Unknown;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Platform Platform {
      get { return platform_; }
      set {
        platform_ = value;
      }
    }

    public const int AuthCodeFieldNumber = 4;
    private string authCode_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string AuthCode {
      get { return authCode_; }
      set {
        authCode_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LocaleFieldNumber = 5;
    private string locale_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Locale {
      get { return locale_; }
      set {
        locale_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StoreFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.Store store_ = global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Store Store {
      get { return store_; }
      set {
        store_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as AuthGoogle);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(AuthGoogle other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameId != other.GameId) return false;
      if (GameVersion != other.GameVersion) return false;
      if (Platform != other.Platform) return false;
      if (AuthCode != other.AuthCode) return false;
      if (Locale != other.Locale) return false;
      if (Store != other.Store) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameId.Length != 0) hash ^= GameId.GetHashCode();
      if (GameVersion.Length != 0) hash ^= GameVersion.GetHashCode();
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) hash ^= Platform.GetHashCode();
      if (AuthCode.Length != 0) hash ^= AuthCode.GetHashCode();
      if (Locale.Length != 0) hash ^= Locale.GetHashCode();
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) hash ^= Store.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (GameId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameId);
      }
      if (GameVersion.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        output.WriteRawTag(24);
        output.WriteEnum((int) Platform);
      }
      if (AuthCode.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(AuthCode);
      }
      if (Locale.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Store);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (GameId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameId);
      }
      if (GameVersion.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        output.WriteRawTag(24);
        output.WriteEnum((int) Platform);
      }
      if (AuthCode.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(AuthCode);
      }
      if (Locale.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Store);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameId);
      }
      if (GameVersion.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Platform);
      }
      if (AuthCode.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AuthCode);
      }
      if (Locale.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Store);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(AuthGoogle other) {
      if (other == null) {
        return;
      }
      if (other.GameId.Length != 0) {
        GameId = other.GameId;
      }
      if (other.GameVersion.Length != 0) {
        GameVersion = other.GameVersion;
      }
      if (other.Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        Platform = other.Platform;
      }
      if (other.AuthCode.Length != 0) {
        AuthCode = other.AuthCode;
      }
      if (other.Locale.Length != 0) {
        Locale = other.Locale;
      }
      if (other.Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        Store = other.Store;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            GameId = input.ReadString();
            break;
          }
          case 18: {
            GameVersion = input.ReadString();
            break;
          }
          case 24: {
            Platform = (global::Axlebolt.Bolt.Protobuf2.Platform) input.ReadEnum();
            break;
          }
          case 34: {
            AuthCode = input.ReadString();
            break;
          }
          case 42: {
            Locale = input.ReadString();
            break;
          }
          case 48: {
            Store = (global::Axlebolt.Bolt.Protobuf2.Store) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            GameId = input.ReadString();
            break;
          }
          case 18: {
            GameVersion = input.ReadString();
            break;
          }
          case 24: {
            Platform = (global::Axlebolt.Bolt.Protobuf2.Platform) input.ReadEnum();
            break;
          }
          case 34: {
            AuthCode = input.ReadString();
            break;
          }
          case 42: {
            Locale = input.ReadString();
            break;
          }
          case 48: {
            Store = (global::Axlebolt.Bolt.Protobuf2.Store) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GoogleAuthRequest : pb::IMessage<GoogleAuthRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GoogleAuthRequest> _parser = new pb::MessageParser<GoogleAuthRequest>(() => new GoogleAuthRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GoogleAuthRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthRequest(GoogleAuthRequest other) : this() {
      authGoogle_ = other.authGoogle_ != null ? other.authGoogle_.Clone() : null;
      appVerification_ = other.appVerification_ != null ? other.appVerification_.Clone() : null;
      deviceInfo_ = other.deviceInfo_ != null ? other.deviceInfo_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthRequest Clone() {
      return new GoogleAuthRequest(this);
    }

    public const int AuthGoogleFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.AuthGoogle authGoogle_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.AuthGoogle AuthGoogle {
      get { return authGoogle_; }
      set {
        authGoogle_ = value;
      }
    }

    public const int AppVerificationFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.AppVerification appVerification_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.AppVerification AppVerification {
      get { return appVerification_; }
      set {
        appVerification_ = value;
      }
    }

    public const int DeviceInfoFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.DeviceInfo deviceInfo_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.DeviceInfo DeviceInfo {
      get { return deviceInfo_; }
      set {
        deviceInfo_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GoogleAuthRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GoogleAuthRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(AuthGoogle, other.AuthGoogle)) return false;
      if (!object.Equals(AppVerification, other.AppVerification)) return false;
      if (!object.Equals(DeviceInfo, other.DeviceInfo)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (authGoogle_ != null) hash ^= AuthGoogle.GetHashCode();
      if (appVerification_ != null) hash ^= AppVerification.GetHashCode();
      if (deviceInfo_ != null) hash ^= DeviceInfo.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (authGoogle_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(AuthGoogle);
      }
      if (appVerification_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(AppVerification);
      }
      if (deviceInfo_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(DeviceInfo);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (authGoogle_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(AuthGoogle);
      }
      if (appVerification_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(AppVerification);
      }
      if (deviceInfo_ != null) {
        output.WriteRawTag(26);
        output.WriteMessage(DeviceInfo);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (authGoogle_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(AuthGoogle);
      }
      if (appVerification_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(AppVerification);
      }
      if (deviceInfo_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(DeviceInfo);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GoogleAuthRequest other) {
      if (other == null) {
        return;
      }
      if (other.authGoogle_ != null) {
        if (authGoogle_ == null) {
          AuthGoogle = new global::Axlebolt.Bolt.Protobuf2.AuthGoogle();
        }
        AuthGoogle.MergeFrom(other.AuthGoogle);
      }
      if (other.appVerification_ != null) {
        if (appVerification_ == null) {
          AppVerification = new global::Axlebolt.Bolt.Protobuf2.AppVerification();
        }
        AppVerification.MergeFrom(other.AppVerification);
      }
      if (other.deviceInfo_ != null) {
        if (deviceInfo_ == null) {
          DeviceInfo = new global::Axlebolt.Bolt.Protobuf2.DeviceInfo();
        }
        DeviceInfo.MergeFrom(other.DeviceInfo);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (authGoogle_ == null) {
              AuthGoogle = new global::Axlebolt.Bolt.Protobuf2.AuthGoogle();
            }
            input.ReadMessage(AuthGoogle);
            break;
          }
          case 18: {
            if (appVerification_ == null) {
              AppVerification = new global::Axlebolt.Bolt.Protobuf2.AppVerification();
            }
            input.ReadMessage(AppVerification);
            break;
          }
          case 26: {
            if (deviceInfo_ == null) {
              DeviceInfo = new global::Axlebolt.Bolt.Protobuf2.DeviceInfo();
            }
            input.ReadMessage(DeviceInfo);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (authGoogle_ == null) {
              AuthGoogle = new global::Axlebolt.Bolt.Protobuf2.AuthGoogle();
            }
            input.ReadMessage(AuthGoogle);
            break;
          }
          case 18: {
            if (appVerification_ == null) {
              AppVerification = new global::Axlebolt.Bolt.Protobuf2.AppVerification();
            }
            input.ReadMessage(AppVerification);
            break;
          }
          case 26: {
            if (deviceInfo_ == null) {
              DeviceInfo = new global::Axlebolt.Bolt.Protobuf2.DeviceInfo();
            }
            input.ReadMessage(DeviceInfo);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GoogleAuthResponse : pb::IMessage<GoogleAuthResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GoogleAuthResponse> _parser = new pb::MessageParser<GoogleAuthResponse>(() => new GoogleAuthResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GoogleAuthResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthResponse(GoogleAuthResponse other) : this() {
      playerTicket_ = other.playerTicket_;
      switch (other.TicketsCase) {
        case TicketsOneofCase.Ticket:
          Ticket = other.Ticket;
          break;
        case TicketsOneofCase.TicketBinary:
          TicketBinary = other.TicketBinary;
          break;
      }

      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GoogleAuthResponse Clone() {
      return new GoogleAuthResponse(this);
    }

    public const int TicketFieldNumber = 1;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Ticket {
      get { return ticketsCase_ == TicketsOneofCase.Ticket ? (string) tickets_ : ""; }
      set {
        tickets_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
        ticketsCase_ = TicketsOneofCase.Ticket;
      }
    }

    public const int TicketBinaryFieldNumber = 2;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString TicketBinary {
      get { return ticketsCase_ == TicketsOneofCase.TicketBinary ? (pb::ByteString) tickets_ : pb::ByteString.Empty; }
      set {
        tickets_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
        ticketsCase_ = TicketsOneofCase.TicketBinary;
      }
    }

    public const int PlayerTicketFieldNumber = 3;
    private string playerTicket_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string PlayerTicket {
      get { return playerTicket_; }
      set {
        playerTicket_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    private object tickets_;

    public enum TicketsOneofCase {
      None = 0,
      Ticket = 1,
      TicketBinary = 2,
    }
    private TicketsOneofCase ticketsCase_ = TicketsOneofCase.None;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public TicketsOneofCase TicketsCase {
      get { return ticketsCase_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void ClearTickets() {
      ticketsCase_ = TicketsOneofCase.None;
      tickets_ = null;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GoogleAuthResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GoogleAuthResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Ticket != other.Ticket) return false;
      if (TicketBinary != other.TicketBinary) return false;
      if (PlayerTicket != other.PlayerTicket) return false;
      if (TicketsCase != other.TicketsCase) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (ticketsCase_ == TicketsOneofCase.Ticket) hash ^= Ticket.GetHashCode();
      if (ticketsCase_ == TicketsOneofCase.TicketBinary) hash ^= TicketBinary.GetHashCode();
      if (PlayerTicket.Length != 0) hash ^= PlayerTicket.GetHashCode();
      hash ^= (int) ticketsCase_;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (ticketsCase_ == TicketsOneofCase.Ticket) {
        output.WriteRawTag(10);
        output.WriteString(Ticket);
      }
      if (ticketsCase_ == TicketsOneofCase.TicketBinary) {
        output.WriteRawTag(18);
        output.WriteBytes(TicketBinary);
      }
      if (PlayerTicket.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(PlayerTicket);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (ticketsCase_ == TicketsOneofCase.Ticket) {
        output.WriteRawTag(10);
        output.WriteString(Ticket);
      }
      if (ticketsCase_ == TicketsOneofCase.TicketBinary) {
        output.WriteRawTag(18);
        output.WriteBytes(TicketBinary);
      }
      if (PlayerTicket.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(PlayerTicket);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (ticketsCase_ == TicketsOneofCase.Ticket) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Ticket);
      }
      if (ticketsCase_ == TicketsOneofCase.TicketBinary) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(TicketBinary);
      }
      if (PlayerTicket.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(PlayerTicket);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GoogleAuthResponse other) {
      if (other == null) {
        return;
      }
      if (other.PlayerTicket.Length != 0) {
        PlayerTicket = other.PlayerTicket;
      }
      switch (other.TicketsCase) {
        case TicketsOneofCase.Ticket:
          Ticket = other.Ticket;
          break;
        case TicketsOneofCase.TicketBinary:
          TicketBinary = other.TicketBinary;
          break;
      }

      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Ticket = input.ReadString();
            break;
          }
          case 18: {
            TicketBinary = input.ReadBytes();
            break;
          }
          case 26: {
            PlayerTicket = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Ticket = input.ReadString();
            break;
          }
          case 18: {
            TicketBinary = input.ReadBytes();
            break;
          }
          case 26: {
            PlayerTicket = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class AuthToken : pb::IMessage<AuthToken>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<AuthToken> _parser = new pb::MessageParser<AuthToken>(() => new AuthToken());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<AuthToken> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthToken() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthToken(AuthToken other) : this() {
      gameId_ = other.gameId_;
      gameVersion_ = other.gameVersion_;
      platform_ = other.platform_;
      authCode_ = other.authCode_;
      locale_ = other.locale_;
      store_ = other.store_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AuthToken Clone() {
      return new AuthToken(this);
    }

    public const int GameIdFieldNumber = 1;
    private string gameId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameId {
      get { return gameId_; }
      set {
        gameId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int GameVersionFieldNumber = 2;
    private string gameVersion_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameVersion {
      get { return gameVersion_; }
      set {
        gameVersion_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlatformFieldNumber = 3;
    private global::Axlebolt.Bolt.Protobuf2.Platform platform_ = global::Axlebolt.Bolt.Protobuf2.Platform.Unknown;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Platform Platform {
      get { return platform_; }
      set {
        platform_ = value;
      }
    }

    public const int AuthCodeFieldNumber = 4;
    private string authCode_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string AuthCode {
      get { return authCode_; }
      set {
        authCode_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LocaleFieldNumber = 5;
    private string locale_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Locale {
      get { return locale_; }
      set {
        locale_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int StoreFieldNumber = 6;
    private global::Axlebolt.Bolt.Protobuf2.Store store_ = global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Store Store {
      get { return store_; }
      set {
        store_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as AuthToken);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(AuthToken other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameId != other.GameId) return false;
      if (GameVersion != other.GameVersion) return false;
      if (Platform != other.Platform) return false;
      if (AuthCode != other.AuthCode) return false;
      if (Locale != other.Locale) return false;
      if (Store != other.Store) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameId.Length != 0) hash ^= GameId.GetHashCode();
      if (GameVersion.Length != 0) hash ^= GameVersion.GetHashCode();
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) hash ^= Platform.GetHashCode();
      if (AuthCode.Length != 0) hash ^= AuthCode.GetHashCode();
      if (Locale.Length != 0) hash ^= Locale.GetHashCode();
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) hash ^= Store.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (GameId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameId);
      }
      if (GameVersion.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        output.WriteRawTag(24);
        output.WriteEnum((int) Platform);
      }
      if (AuthCode.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(AuthCode);
      }
      if (Locale.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Store);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (GameId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameId);
      }
      if (GameVersion.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        output.WriteRawTag(24);
        output.WriteEnum((int) Platform);
      }
      if (AuthCode.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(AuthCode);
      }
      if (Locale.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        output.WriteRawTag(48);
        output.WriteEnum((int) Store);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameId);
      }
      if (GameVersion.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameVersion);
      }
      if (Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Platform);
      }
      if (AuthCode.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AuthCode);
      }
      if (Locale.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Locale);
      }
      if (Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) Store);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(AuthToken other) {
      if (other == null) {
        return;
      }
      if (other.GameId.Length != 0) {
        GameId = other.GameId;
      }
      if (other.GameVersion.Length != 0) {
        GameVersion = other.GameVersion;
      }
      if (other.Platform != global::Axlebolt.Bolt.Protobuf2.Platform.Unknown) {
        Platform = other.Platform;
      }
      if (other.AuthCode.Length != 0) {
        AuthCode = other.AuthCode;
      }
      if (other.Locale.Length != 0) {
        Locale = other.Locale;
      }
      if (other.Store != global::Axlebolt.Bolt.Protobuf2.Store.GooglePlay) {
        Store = other.Store;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            GameId = input.ReadString();
            break;
          }
          case 18: {
            GameVersion = input.ReadString();
            break;
          }
          case 24: {
            Platform = (global::Axlebolt.Bolt.Protobuf2.Platform) input.ReadEnum();
            break;
          }
          case 34: {
            AuthCode = input.ReadString();
            break;
          }
          case 42: {
            Locale = input.ReadString();
            break;
          }
          case 48: {
            Store = (global::Axlebolt.Bolt.Protobuf2.Store) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            GameId = input.ReadString();
            break;
          }
          case 18: {
            GameVersion = input.ReadString();
            break;
          }
          case 24: {
            Platform = (global::Axlebolt.Bolt.Protobuf2.Platform) input.ReadEnum();
            break;
          }
          case 34: {
            AuthCode = input.ReadString();
            break;
          }
          case 42: {
            Locale = input.ReadString();
            break;
          }
          case 48: {
            Store = (global::Axlebolt.Bolt.Protobuf2.Store) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class EnvironmentInfo : pb::IMessage<EnvironmentInfo>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<EnvironmentInfo> _parser = new pb::MessageParser<EnvironmentInfo>(() => new EnvironmentInfo());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<EnvironmentInfo> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public EnvironmentInfo() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public EnvironmentInfo(EnvironmentInfo other) : this() {
      version_ = other.version_;
      environment_ = other.environment_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public EnvironmentInfo Clone() {
      return new EnvironmentInfo(this);
    }

    public const int VersionFieldNumber = 1;
    private int version_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Version {
      get { return version_; }
      set {
        version_ = value;
      }
    }

    public const int EnvironmentFieldNumber = 2;
    private pb::ByteString environment_ = pb::ByteString.Empty;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString Environment {
      get { return environment_; }
      set {
        environment_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as EnvironmentInfo);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(EnvironmentInfo other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Version != other.Version) return false;
      if (Environment != other.Environment) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Version != 0) hash ^= Version.GetHashCode();
      if (Environment.Length != 0) hash ^= Environment.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Version != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Version);
      }
      if (Environment.Length != 0) {
        output.WriteRawTag(18);
        output.WriteBytes(Environment);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Version != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Version);
      }
      if (Environment.Length != 0) {
        output.WriteRawTag(18);
        output.WriteBytes(Environment);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Version != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Version);
      }
      if (Environment.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(Environment);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(EnvironmentInfo other) {
      if (other == null) {
        return;
      }
      if (other.Version != 0) {
        Version = other.Version;
      }
      if (other.Environment.Length != 0) {
        Environment = other.Environment;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Version = input.ReadInt32();
            break;
          }
          case 18: {
            Environment = input.ReadBytes();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Version = input.ReadInt32();
            break;
          }
          case 18: {
            Environment = input.ReadBytes();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class AppVerification : pb::IMessage<AppVerification>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<AppVerification> _parser = new pb::MessageParser<AppVerification>(() => new AppVerification());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<AppVerification> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AppVerification() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AppVerification(AppVerification other) : this() {
      isRooted_ = other.isRooted_;
      apkHash_ = other.apkHash_;
      jsonForbiddenApps_ = other.jsonForbiddenApps_.Clone();
      path_ = other.path_;
      contentHash_ = other.contentHash_;
      appSnapshot_ = other.appSnapshot_.Clone();
      n_ = other.n_;
      e_ = other.e_;
      environment_ = other.environment_ != null ? other.environment_.Clone() : null;
      token_ = other.token_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public AppVerification Clone() {
      return new AppVerification(this);
    }

    public const int IsRootedFieldNumber = 1;
    private bool isRooted_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool IsRooted {
      get { return isRooted_; }
      set {
        isRooted_ = value;
      }
    }

    public const int ApkHashFieldNumber = 2;
    private string apkHash_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string ApkHash {
      get { return apkHash_; }
      set {
        apkHash_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int JsonForbiddenAppsFieldNumber = 3;
    private static readonly pb::FieldCodec<string> _repeated_jsonForbiddenApps_codec
        = pb::FieldCodec.ForString(26);
    private readonly pbc::RepeatedField<string> jsonForbiddenApps_ = new pbc::RepeatedField<string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<string> JsonForbiddenApps {
      get { return jsonForbiddenApps_; }
    }

    public const int PathFieldNumber = 4;
    private string path_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Path {
      get { return path_; }
      set {
        path_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int ContentHashFieldNumber = 5;
    private string contentHash_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string ContentHash {
      get { return contentHash_; }
      set {
        contentHash_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AppSnapshotFieldNumber = 6;
    private static readonly pbc::MapField<string, string>.Codec _map_appSnapshot_codec
        = new pbc::MapField<string, string>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForString(18, ""), 50);
    private readonly pbc::MapField<string, string> appSnapshot_ = new pbc::MapField<string, string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, string> AppSnapshot {
      get { return appSnapshot_; }
    }

    public const int NFieldNumber = 7;
    private pb::ByteString n_ = pb::ByteString.Empty;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString N {
      get { return n_; }
      set {
        n_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int EFieldNumber = 8;
    private pb::ByteString e_ = pb::ByteString.Empty;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pb::ByteString E {
      get { return e_; }
      set {
        e_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int EnvironmentFieldNumber = 9;
    private global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo environment_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo Environment {
      get { return environment_; }
      set {
        environment_ = value;
      }
    }

    public const int TokenFieldNumber = 10;
    private string token_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Token {
      get { return token_; }
      set {
        token_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as AppVerification);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(AppVerification other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (IsRooted != other.IsRooted) return false;
      if (ApkHash != other.ApkHash) return false;
      if(!jsonForbiddenApps_.Equals(other.jsonForbiddenApps_)) return false;
      if (Path != other.Path) return false;
      if (ContentHash != other.ContentHash) return false;
      if (!AppSnapshot.Equals(other.AppSnapshot)) return false;
      if (N != other.N) return false;
      if (E != other.E) return false;
      if (!object.Equals(Environment, other.Environment)) return false;
      if (Token != other.Token) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (IsRooted != false) hash ^= IsRooted.GetHashCode();
      if (ApkHash.Length != 0) hash ^= ApkHash.GetHashCode();
      hash ^= jsonForbiddenApps_.GetHashCode();
      if (Path.Length != 0) hash ^= Path.GetHashCode();
      if (ContentHash.Length != 0) hash ^= ContentHash.GetHashCode();
      hash ^= AppSnapshot.GetHashCode();
      if (N.Length != 0) hash ^= N.GetHashCode();
      if (E.Length != 0) hash ^= E.GetHashCode();
      if (environment_ != null) hash ^= Environment.GetHashCode();
      if (Token.Length != 0) hash ^= Token.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (IsRooted != false) {
        output.WriteRawTag(8);
        output.WriteBool(IsRooted);
      }
      if (ApkHash.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(ApkHash);
      }
      jsonForbiddenApps_.WriteTo(output, _repeated_jsonForbiddenApps_codec);
      if (Path.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Path);
      }
      if (ContentHash.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(ContentHash);
      }
      appSnapshot_.WriteTo(output, _map_appSnapshot_codec);
      if (N.Length != 0) {
        output.WriteRawTag(58);
        output.WriteBytes(N);
      }
      if (E.Length != 0) {
        output.WriteRawTag(66);
        output.WriteBytes(E);
      }
      if (environment_ != null) {
        output.WriteRawTag(74);
        output.WriteMessage(Environment);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(82);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (IsRooted != false) {
        output.WriteRawTag(8);
        output.WriteBool(IsRooted);
      }
      if (ApkHash.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(ApkHash);
      }
      jsonForbiddenApps_.WriteTo(ref output, _repeated_jsonForbiddenApps_codec);
      if (Path.Length != 0) {
        output.WriteRawTag(34);
        output.WriteString(Path);
      }
      if (ContentHash.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(ContentHash);
      }
      appSnapshot_.WriteTo(ref output, _map_appSnapshot_codec);
      if (N.Length != 0) {
        output.WriteRawTag(58);
        output.WriteBytes(N);
      }
      if (E.Length != 0) {
        output.WriteRawTag(66);
        output.WriteBytes(E);
      }
      if (environment_ != null) {
        output.WriteRawTag(74);
        output.WriteMessage(Environment);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(82);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (IsRooted != false) {
        size += 1 + 1;
      }
      if (ApkHash.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ApkHash);
      }
      size += jsonForbiddenApps_.CalculateSize(_repeated_jsonForbiddenApps_codec);
      if (Path.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Path);
      }
      if (ContentHash.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(ContentHash);
      }
      size += appSnapshot_.CalculateSize(_map_appSnapshot_codec);
      if (N.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(N);
      }
      if (E.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeBytesSize(E);
      }
      if (environment_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Environment);
      }
      if (Token.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Token);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(AppVerification other) {
      if (other == null) {
        return;
      }
      if (other.IsRooted != false) {
        IsRooted = other.IsRooted;
      }
      if (other.ApkHash.Length != 0) {
        ApkHash = other.ApkHash;
      }
      jsonForbiddenApps_.Add(other.jsonForbiddenApps_);
      if (other.Path.Length != 0) {
        Path = other.Path;
      }
      if (other.ContentHash.Length != 0) {
        ContentHash = other.ContentHash;
      }
      appSnapshot_.Add(other.appSnapshot_);
      if (other.N.Length != 0) {
        N = other.N;
      }
      if (other.E.Length != 0) {
        E = other.E;
      }
      if (other.environment_ != null) {
        if (environment_ == null) {
          Environment = new global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo();
        }
        Environment.MergeFrom(other.Environment);
      }
      if (other.Token.Length != 0) {
        Token = other.Token;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            IsRooted = input.ReadBool();
            break;
          }
          case 18: {
            ApkHash = input.ReadString();
            break;
          }
          case 26: {
            jsonForbiddenApps_.AddEntriesFrom(input, _repeated_jsonForbiddenApps_codec);
            break;
          }
          case 34: {
            Path = input.ReadString();
            break;
          }
          case 42: {
            ContentHash = input.ReadString();
            break;
          }
          case 50: {
            appSnapshot_.AddEntriesFrom(input, _map_appSnapshot_codec);
            break;
          }
          case 58: {
            N = input.ReadBytes();
            break;
          }
          case 66: {
            E = input.ReadBytes();
            break;
          }
          case 74: {
            if (environment_ == null) {
              Environment = new global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo();
            }
            input.ReadMessage(Environment);
            break;
          }
          case 82: {
            Token = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            IsRooted = input.ReadBool();
            break;
          }
          case 18: {
            ApkHash = input.ReadString();
            break;
          }
          case 26: {
            jsonForbiddenApps_.AddEntriesFrom(ref input, _repeated_jsonForbiddenApps_codec);
            break;
          }
          case 34: {
            Path = input.ReadString();
            break;
          }
          case 42: {
            ContentHash = input.ReadString();
            break;
          }
          case 50: {
            appSnapshot_.AddEntriesFrom(ref input, _map_appSnapshot_codec);
            break;
          }
          case 58: {
            N = input.ReadBytes();
            break;
          }
          case 66: {
            E = input.ReadBytes();
            break;
          }
          case 74: {
            if (environment_ == null) {
              Environment = new global::Axlebolt.Bolt.Protobuf2.EnvironmentInfo();
            }
            input.ReadMessage(Environment);
            break;
          }
          case 82: {
            Token = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class DeviceInfo : pb::IMessage<DeviceInfo>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<DeviceInfo> _parser = new pb::MessageParser<DeviceInfo>(() => new DeviceInfo());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<DeviceInfo> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.AuthMessageReflection.Descriptor.MessageTypes[9]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeviceInfo() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeviceInfo(DeviceInfo other) : this() {
      deviceId_ = other.deviceId_;
      deviceModel_ = other.deviceModel_;
      adsId_ = other.adsId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeviceInfo Clone() {
      return new DeviceInfo(this);
    }

    public const int DeviceIdFieldNumber = 1;
    private string deviceId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string DeviceId {
      get { return deviceId_; }
      set {
        deviceId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int DeviceModelFieldNumber = 2;
    private string deviceModel_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string DeviceModel {
      get { return deviceModel_; }
      set {
        deviceModel_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int AdsIdFieldNumber = 3;
    private string adsId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string AdsId {
      get { return adsId_; }
      set {
        adsId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as DeviceInfo);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(DeviceInfo other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (DeviceId != other.DeviceId) return false;
      if (DeviceModel != other.DeviceModel) return false;
      if (AdsId != other.AdsId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (DeviceId.Length != 0) hash ^= DeviceId.GetHashCode();
      if (DeviceModel.Length != 0) hash ^= DeviceModel.GetHashCode();
      if (AdsId.Length != 0) hash ^= AdsId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (DeviceId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(DeviceId);
      }
      if (DeviceModel.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(DeviceModel);
      }
      if (AdsId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(AdsId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (DeviceId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(DeviceId);
      }
      if (DeviceModel.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(DeviceModel);
      }
      if (AdsId.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(AdsId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (DeviceId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(DeviceId);
      }
      if (DeviceModel.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(DeviceModel);
      }
      if (AdsId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(AdsId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(DeviceInfo other) {
      if (other == null) {
        return;
      }
      if (other.DeviceId.Length != 0) {
        DeviceId = other.DeviceId;
      }
      if (other.DeviceModel.Length != 0) {
        DeviceModel = other.DeviceModel;
      }
      if (other.AdsId.Length != 0) {
        AdsId = other.AdsId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            DeviceId = input.ReadString();
            break;
          }
          case 18: {
            DeviceModel = input.ReadString();
            break;
          }
          case 26: {
            AdsId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            DeviceId = input.ReadString();
            break;
          }
          case 18: {
            DeviceModel = input.ReadString();
            break;
          }
          case 26: {
            AdsId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }


}

