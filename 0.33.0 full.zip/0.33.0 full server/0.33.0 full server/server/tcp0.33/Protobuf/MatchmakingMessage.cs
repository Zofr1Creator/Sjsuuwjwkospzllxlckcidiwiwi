#pragma warning disable 1591, 0612, 3021

using pb = global::Google.Protobuf;
using pbc = global::Google.Protobuf.Collections;
using pbr = global::Google.Protobuf.Reflection;
using scg = global::System.Collections.Generic;
namespace Axlebolt.Bolt.Protobuf2 {

  public static partial class MatchmakingMessageReflection {


    public static pbr::FileDescriptor Descriptor {
      get { return descriptor; }
    }
    private static pbr::FileDescriptor descriptor;

    static MatchmakingMessageReflection() {
      byte[] descriptorData = global::System.Convert.FromBase64String(
          string.Concat(
            "ChhNYXRjaG1ha2luZ01lc3NhZ2UucHJvdG8SF0F4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyGhNDb21tb25NZXNzYWdlLnByb3RvGhRGcmllbmRzTWVzc2FnZS5w",
            "cm90bxoTUGxheWVyTWVzc2FnZS5wcm90byKJAgoRR2FtZVNlcnZlckRldGFp",
            "bHMSCgoCaWQYASABKAkSOAoLZ2FtZV9zZXJ2ZXIYAiABKAsyIy5BeGxlYm9s",
            "dC5Cb2x0LlByb3RvYnVmMi5HYW1lU2VydmVyEgsKA21hcBgDIAEoCRIXCg9j",
            "dXJyZW50X3BsYXllcnMYBCABKAUSEwoLbWF4X3BsYXllcnMYBSABKAUSEwoL",
            "Ym90X3BsYXllcnMYBiABKAUSGAoQcmVxdWlyZV9wYXNzd29yZBgHIAEoCBIP",
            "Cgd2ZXJzaW9uGAggASgJEhsKE3N1Y2Nlc3NmdWxfcmVzcG9uc2UYCSABKAgS",
            "FgoOZG9fbm90X3JlZnJlc2gYCiABKAgiugUKBUxvYmJ5EgoKAmlkGAEgASgJ",
            "EhIKCm93bmVyX2dwaWQYAiABKAkSDAoEbmFtZRgDIAEoCRI2Cgpsb2JieV90",
            "eXBlGAQgASgOMiIuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuTG9iYnlUeXBl",
            "EhAKCGpvaW5hYmxlGAUgASgIEhMKC21heF9tZW1iZXJzGAYgASgFEjYKBGRh",
            "dGEYByADKAsyKC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Mb2JieS5EYXRh",
            "RW50cnkSNgoHbWVtYmVycxgIIAMoCzIlLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLlBsYXllckZyaWVuZBI2CgdpbnZpdGVzGAkgAygLMiUuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuUGxheWVyRnJpZW5kEjgKC2dhbWVfc2VydmVyGAog",
            "ASgLMiMuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuR2FtZVNlcnZlchI4Cgtw",
            "aG90b25fZ2FtZRgLIAEoCzIjLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBo",
            "b3RvbkdhbWUSFgoObWF4X3NwZWN0YXRvcnMYDCABKAUSOQoKc3BlY3RhdG9y",
            "cxgNIAMoCzIlLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBsYXllckZyaWVu",
            "ZBJAChFzcGVjdGF0b3JfaW52aXRlcxgOIAMoCzIlLkF4bGVib2x0LkJvbHQu",
            "UHJvdG9idWYyLlBsYXllckZyaWVuZBIZChFudW1iZXJfb2ZfbWVtYmVycxgP",
            "IAEoBRIcChRudW1iZXJfb2Zfc3BlY3RhdG9ycxgQIAEoBRINCgV0b2tlbhgR",
            "IAEoCRorCglEYXRhRW50cnkSCwoDa2V5GAEgASgJEg0KBXZhbHVlGAIgASgJ",
            "OgI4ASK+AQoLTG9iYnlJbnZpdGUSEAoIbG9iYnlfaWQYASABKAkSPAoNaW52",
            "aXRlX3NlbmRlchgCIAEoCzIlLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBs",
            "YXllckZyaWVuZBIMCgRkYXRlGAMgASgDEj0KC3BsYXllcl90eXBlGAQgASgO",
            "MiguQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuTG9iYnlQbGF5ZXJUeXBlEhIK",
            "CmxvYmJ5X25hbWUYBSABKAkiLQoZR2V0TG9iYnlHYW1lU2VydmVyUmVxdWVz",
            "dBIQCghsb2JieV9pZBgBIAEoCSJlChpHZXRMb2JieUdhbWVTZXJ2ZXJSZXNw",
            "b25zZRJHChNnYW1lX3NlcnZlcl9kZXRhaWxzGAEgASgLMiouQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuR2FtZVNlcnZlckRldGFpbHMiNQobR2V0R2FtZVNl",
            "cnZlckRldGFpbHNSZXF1ZXN0EhYKDmdhbWVfc2VydmVyX2lkGAEgASgJImcK",
            "HEdldEdhbWVTZXJ2ZXJEZXRhaWxzUmVzcG9uc2USRwoTZ2FtZV9zZXJ2ZXJf",
            "ZGV0YWlscxgBIAEoCzIqLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkdhbWVT",
            "ZXJ2ZXJEZXRhaWxzIiMKE1NldExvYmJ5TmFtZVJlcXVlc3QSDAoEbmFtZRgB",
            "IAEoCSIWChRTZXRMb2JieU5hbWVSZXNwb25zZSJnChJTZWFyY2hMb2JieVJl",
            "cXVlc3QSDgoGYW1vdW50GAEgASgFEjAKB2ZpbHRlcnMYAiADKAsyHy5BeGxl",
            "Ym9sdC5Cb2x0LlByb3RvYnVmMi5GaWx0ZXISDwoHdmVyc2lvbhgDIAEoBSJG",
            "ChNTZWFyY2hMb2JieVJlc3BvbnNlEi8KB2xvYmJpZXMYASADKAsyHi5BeGxl",
            "Ym9sdC5Cb2x0LlByb3RvYnVmMi5Mb2JieSJ0ChJKb2luTG9iYnlBc1JlcXVl",
            "c3QSEAoIbG9iYnlfaWQYASABKAkSPQoLcGxheWVyX3R5cGUYAiABKA4yKC5B",
            "eGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Mb2JieVBsYXllclR5cGUSDQoFdG9r",
            "ZW4YAyABKAkiRAoTSm9pbkxvYmJ5QXNSZXNwb25zZRItCgVsb2JieRgBIAEo",
            "CzIeLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLkxvYmJ5IjMKGVNldExvYmJ5",
            "R2FtZVNlcnZlclJlcXVlc3QSFgoOZ2FtZV9zZXJ2ZXJfaWQYASABKAkiHAoa",
            "U2V0TG9iYnlHYW1lU2VydmVyUmVzcG9uc2UicwocSW52aXRlUGxheWVyVG9M",
            "b2JieUFzUmVxdWVzdBIUCgxpbnZpdGVkX2dwaWQYASABKAkSPQoLcGxheWVy",
            "X3R5cGUYAiABKA4yKC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Mb2JieVBs",
            "YXllclR5cGUiHwodSW52aXRlUGxheWVyVG9Mb2JieUFzUmVzcG9uc2UiJAoU",
            "U2V0TG9iYnlPd25lclJlcXVlc3QSDAoEZ3BpZBgBIAEoCSIXChVTZXRMb2Ji",
            "eU93bmVyUmVzcG9uc2UiJgoWRGVsZXRlTG9iYnlEYXRhUmVxdWVzdBIMCgRr",
            "ZXlzGAEgAygJIhkKF0RlbGV0ZUxvYmJ5RGF0YVJlc3BvbnNlIhoKGEdldElu",
            "dml0ZXNUb0xvYmJ5UmVxdWVzdCJYChlHZXRJbnZpdGVzVG9Mb2JieVJlc3Bv",
            "bnNlEjsKDWxvYmJ5X2ludml0ZXMYASADKAsyJC5BeGxlYm9sdC5Cb2x0LlBy",
            "b3RvYnVmMi5Mb2JieUludml0ZSIyChpJbnZpdGVQbGF5ZXJUb0xvYmJ5UmVx",
            "dWVzdBIUCgxpbnZpdGVkX2dwaWQYASABKAkiHQobSW52aXRlUGxheWVyVG9M",
            "b2JieVJlc3BvbnNlIjAKGVNldExvYmJ5TWF4TWVtYmVyc1JlcXVlc3QSEwoL",
            "bWF4X21lbWJlcnMYASABKAUiHAoaU2V0TG9iYnlNYXhNZW1iZXJzUmVzcG9u",
            "c2UiPAokUmV2b2tlUGxheWVySW52aXRhdGlvblRvTG9iYnlSZXF1ZXN0EhQK",
            "DHJldm9rZWRfZ3BpZBgBIAEoCSInCiVSZXZva2VQbGF5ZXJJbnZpdGF0aW9u",
            "VG9Mb2JieVJlc3BvbnNlIjEKGktpY2tQbGF5ZXJGcm9tTG9iYnlSZXF1ZXN0",
            "EhMKC2tpY2tlZF9ncGlkGAEgASgJIh0KG0tpY2tQbGF5ZXJGcm9tTG9iYnlS",
            "ZXNwb25zZSK1AQogQ3JlYXRlTG9iYnlXaXRoU3BlY3RhdG9yc1JlcXVlc3QS",
            "DAoEbmFtZRgBIAEoCRI2Cgpsb2JieV90eXBlGAIgASgOMiIuQXhsZWJvbHQu",
            "Qm9sdC5Qcm90b2J1ZjIuTG9iYnlUeXBlEhMKC21heF9tZW1iZXJzGAMgASgF",
            "EhYKDm1heF9zcGVjdGF0b3JzGAQgASgFEh4KFmRhdGFfdmlzaWJsZV9pbl9z",
            "ZWFyY2gYBSADKAkiUgohQ3JlYXRlTG9iYnlXaXRoU3BlY3RhdG9yc1Jlc3Bv",
            "bnNlEi0KBWxvYmJ5GAEgASgLMh4uQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIu",
            "TG9iYnkiKgoXU2VuZExvYmJ5Q2hhdE1zZ1JlcXVlc3QSDwoHbWVzc2FnZRgB",
            "IAEoCSIaChhTZW5kTG9iYnlDaGF0TXNnUmVzcG9uc2UiVQoZU2V0TG9iYnlQ",
            "aG90b25HYW1lUmVxdWVzdBI4CgtwaG90b25fZ2FtZRgBIAEoCzIjLkF4bGVi",
            "b2x0LkJvbHQuUHJvdG9idWYyLlBob3RvbkdhbWUiHAoaU2V0TG9iYnlQaG90",
            "b25HYW1lUmVzcG9uc2UiMgoeUmVmdXNlSW52aXRhdGlvblRvTG9iYnlSZXF1",
            "ZXN0EhAKCGxvYmJ5X2lkGAEgASgJIiEKH1JlZnVzZUludml0YXRpb25Ub0xv",
            "YmJ5UmVzcG9uc2UiNQobR2V0R2FtZVNlcnZlclBsYXllcnNSZXF1ZXN0EhYK",
            "DmdhbWVfc2VydmVyX2lkGAEgASgJIlAKHEdldEdhbWVTZXJ2ZXJQbGF5ZXJz",
            "UmVzcG9uc2USMAoHcGxheWVycxgBIAMoCzIfLkF4bGVib2x0LkJvbHQuUHJv",
            "dG9idWYyLlBsYXllciIjCg9HZXRMb2JieVJlcXVlc3QSEAoIbG9iYnlfaWQY",
            "ASABKAkiQQoQR2V0TG9iYnlSZXNwb25zZRItCgVsb2JieRgBIAEoCzIeLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLkxvYmJ5IisKF1NldExvYmJ5Sm9pbmFi",
            "bGVSZXF1ZXN0EhAKCGpvaW5hYmxlGAEgASgIIhoKGFNldExvYmJ5Sm9pbmFi",
            "bGVSZXNwb25zZSJdChxDaGFuZ2VMb2JieVBsYXllclR5cGVSZXF1ZXN0Ej0K",
            "C3BsYXllcl90eXBlGAEgASgOMiguQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIu",
            "TG9iYnlQbGF5ZXJUeXBlIh8KHUNoYW5nZUxvYmJ5UGxheWVyVHlwZVJlc3Bv",
            "bnNlIiQKEEpvaW5Mb2JieVJlcXVlc3QSEAoIbG9iYnlfaWQYASABKAkiQgoR",
            "Sm9pbkxvYmJ5UmVzcG9uc2USLQoFbG9iYnkYASABKAsyHi5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5Mb2JieSI2ChxTZXRMb2JieU1heFNwZWN0YXRvcnNS",
            "ZXF1ZXN0EhYKDm1heF9zcGVjdGF0b3JzGAEgASgFIh8KHVNldExvYmJ5TWF4",
            "U3BlY3RhdG9yc1Jlc3BvbnNlIpIBChdSZXF1ZXN0TG9iYnlMaXN0UmVxdWVz",
            "dBJFCg9kaXN0YW5jZV9maWx0ZXIYASABKA4yLC5BeGxlYm9sdC5Cb2x0LlBy",
            "b3RvYnVmMi5Mb2JieURpc3RhbmNlRmlsdGVyEjAKB2ZpbHRlcnMYAiADKAsy",
            "Hy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5GaWx0ZXIiSwoYUmVxdWVzdExv",
            "YmJ5TGlzdFJlc3BvbnNlEi8KB2xvYmJpZXMYASADKAsyHi5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5Mb2JieSIqChZHZXRMb2JieU1lbWJlcnNSZXF1ZXN0",
            "EhAKCGxvYmJ5X2lkGAEgASgJIksKF0dldExvYmJ5TWVtYmVyc1Jlc3BvbnNl",
            "EjAKB3BsYXllcnMYASADKAsyHy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5Q",
            "bGF5ZXIicAohQ2hhbmdlTG9iYnlPdGhlclBsYXllclR5cGVSZXF1ZXN0EgwK",
            "BGdwaWQYASABKAkSPQoLcGxheWVyX3R5cGUYAiABKA4yKC5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5Mb2JieVBsYXllclR5cGUiJAoiQ2hhbmdlTG9iYnlP",
            "dGhlclBsYXllclR5cGVSZXNwb25zZSItChlHZXRMb2JieVBob3RvbkdhbWVS",
            "ZXF1ZXN0EhAKCGxvYmJ5X2lkGAEgASgJIlYKGkdldExvYmJ5UGhvdG9uR2Ft",
            "ZVJlc3BvbnNlEjgKC3Bob3Rvbl9nYW1lGAEgASgLMiMuQXhsZWJvbHQuQm9s",
            "dC5Qcm90b2J1ZjIuUGhvdG9uR2FtZSJIChNTZXRMb2JieURhdGFSZXF1ZXN0",
            "EjEKBGRhdGEYASABKAsyIy5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5EaWN0",
            "aW9uYXJ5IhYKFFNldExvYmJ5RGF0YVJlc3BvbnNlIigKFEdldExvYmJ5T3du",
            "ZXJSZXF1ZXN0EhAKCGxvYmJ5X2lkGAEgASgJIkcKFUdldExvYmJ5T3duZXJS",
            "ZXNwb25zZRIuCgVvd25lchgBIAEoCzIfLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLlBsYXllciITChFMZWF2ZUxvYmJ5UmVxdWVzdCIUChJMZWF2ZUxvYmJ5",
            "UmVzcG9uc2UiTQoTU2V0TG9iYnlUeXBlUmVxdWVzdBI2Cgpsb2JieV90eXBl",
            "GAEgASgOMiIuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIuTG9iYnlUeXBlIhYK",
            "FFNldExvYmJ5VHlwZVJlc3BvbnNlIl4KFFNldFBob3RvbkdhbWVSZXF1ZXN0",
            "EgwKBGdwaWQYASABKAkSOAoLcGhvdG9uX2dhbWUYAiABKAsyIy5BeGxlYm9s",
            "dC5Cb2x0LlByb3RvYnVmMi5QaG90b25HYW1lIhcKFVNldFBob3RvbkdhbWVS",
            "ZXNwb25zZSJOChpPblJlZnVzZUludml0ZVRvTG9iYnlFdmVudBIaChJpbnZp",
            "dGVfc2VuZGVyX2dwaWQYASABKAkSFAoMaW52aXRlZF9ncGlkGAIgASgJIn0K",
            "IU9uTmV3U3BlY3RhdG9ySW52aXRlZFRvTG9iYnlFdmVudBIaChJpbnZpdGVf",
            "c2VuZGVyX2dwaWQYASABKAkSPAoNbmV3X3NwZWN0YXRvchgCIAEoCzIlLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLlBsYXllckZyaWVuZCJYChtPbk5ld1Bs",
            "YXllckpvaW5lZExvYmJ5RXZlbnQSOQoKbmV3X3BsYXllchgBIAEoCzIlLkF4",
            "bGVib2x0LkJvbHQuUHJvdG9idWYyLlBsYXllckZyaWVuZCI4ChdPbkxvYmJ5",
            "Q2hhdE1lc3NhZ2VFdmVudBIMCgRncGlkGAEgASgJEg8KB21lc3NhZ2UYAiAB",
            "KAkiTgoaT25SZXZva2VJbnZpdGVUb0xvYmJ5RXZlbnQSGgoSaW52aXRlX3Nl",
            "bmRlcl9ncGlkGAEgASgJEhQKDGludml0ZWRfZ3BpZBgCIAEoCSJZCh1Pbkxv",
            "YmJ5UGhvdG9uR2FtZUNoYW5nZWRFdmVudBI4CgtwaG90b25fZ2FtZRgBIAEo",
            "CzIjLkF4bGVib2x0LkJvbHQuUHJvdG9idWYyLlBob3RvbkdhbWUiOgogT25M",
            "b2JieU1heFNwZWN0YXRvcnNDaGFuZ2VkRXZlbnQSFgoObWF4X3NwZWN0YXRv",
            "cnMYASABKAUiUAocT25QbGF5ZXJLaWNrZWRGcm9tTG9iYnlFdmVudBIbChNr",
            "aWNrX2luaXRpYXRvcl9ncGlkGAEgASgJEhMKC2tpY2tlZF9ncGlkGAIgASgJ",
            "ImwKHU9uTG9iYnlQbGF5ZXJUeXBlQ2hhbmdlZEV2ZW50EgwKBGdwaWQYASAB",
            "KAkSPQoLcGxheWVyX3R5cGUYAiABKA4yKC5BeGxlYm9sdC5Cb2x0LlByb3Rv",
            "YnVmMi5Mb2JieVBsYXllclR5cGUiXgoeT25OZXdTcGVjdGF0b3JKb2luZWRM",
            "b2JieUV2ZW50EjwKDW5ld19zcGVjdGF0b3IYASABKAsyJS5BeGxlYm9sdC5C",
            "b2x0LlByb3RvYnVmMi5QbGF5ZXJGcmllbmQiJwoXT25Mb2JieU5hbWVDaGFu",
            "Z2VkRXZlbnQSDAoEbmFtZRgBIAEoCSJMChdPbkxvYmJ5RGF0YUNoYW5nZWRF",
            "dmVudBIxCgRkYXRhGAEgASgLMiMuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIu",
            "RGljdGlvbmFyeSJZCh1PbkxvYmJ5R2FtZVNlcnZlckNoYW5nZWRFdmVudBI4",
            "CgtnYW1lX3NlcnZlchgBIAEoCzIjLkF4bGVib2x0LkJvbHQuUHJvdG9idWYy",
            "LkdhbWVTZXJ2ZXIiKwoWT25QbGF5ZXJMZWZ0TG9iYnlFdmVudBIRCglsZWZ0",
            "X2dwaWQYASABKAkiLwobT25Mb2JieUpvaW5hYmxlQ2hhbmdlZEV2ZW50EhAK",
            "CGpvaW5hYmxlGAEgASgIIlQKHE9uUmVjZWl2ZWRJbnZpdGVUb0xvYmJ5RXZl",
            "bnQSNAoGaW52aXRlGAEgASgLMiQuQXhsZWJvbHQuQm9sdC5Qcm90b2J1ZjIu",
            "TG9iYnlJbnZpdGUiNAodT25Mb2JieU1heE1lbWJlcnNDaGFuZ2VkRXZlbnQS",
            "EwoLbWF4X21lbWJlcnMYASABKAUiUQoXT25Mb2JieVR5cGVDaGFuZ2VkRXZl",
            "bnQSNgoKbG9iYnlfdHlwZRgBIAEoDjIiLkF4bGVib2x0LkJvbHQuUHJvdG9i",
            "dWYyLkxvYmJ5VHlwZSJ3Ch5Pbk5ld1BsYXllckludml0ZWRUb0xvYmJ5RXZl",
            "bnQSGgoSaW52aXRlX3NlbmRlcl9ncGlkGAEgASgJEjkKCm5ld19wbGF5ZXIY",
            "AiABKAsyJS5BeGxlYm9sdC5Cb2x0LlByb3RvYnVmMi5QbGF5ZXJGcmllbmQi",
            "NAoYT25Mb2JieU93bmVyQ2hhbmdlZEV2ZW50EhgKEGxvYmJ5X293bmVyX2dw",
            "aWQYASABKAkiXQolT25SZWNlaXZlZFNwZWN0YXRvckludml0ZVRvTG9iYnlF",
            "dmVudBI0CgZpbnZpdGUYASABKAsyJC5BeGxlYm9sdC5Cb2x0LlByb3RvYnVm",
            "Mi5Mb2JieUludml0ZSpFCglMb2JieVR5cGUSCwoHUFJJVkFURRAAEhAKDEZS",
            "SUVORFNfT05MWRABEgoKBlBVQkxJQxACEg0KCUlOVklTSUJMRRADKjUKD0xv",
            "YmJ5UGxheWVyVHlwZRIHCgNBTlkQABIKCgZNRU1CRVIQARINCglTUEVDVEFU",
            "T1IQAipFChNMb2JieURpc3RhbmNlRmlsdGVyEgkKBUNMT1NFEAASCwoHREVG",
            "QVVMVBABEgcKA0ZBUhACEg0KCVdPUkxEV0lERRADYgZwcm90bzM="));
      descriptor = pbr::FileDescriptor.FromGeneratedCode(descriptorData,
          new pbr::FileDescriptor[] { global::Axlebolt.Bolt.Protobuf2.CommonMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.FriendsMessageReflection.Descriptor, global::Axlebolt.Bolt.Protobuf2.PlayerMessageReflection.Descriptor, },
          new pbr::GeneratedClrTypeInfo(new[] {typeof(global::Axlebolt.Bolt.Protobuf2.LobbyType), typeof(global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType), typeof(global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter), }, null, new pbr::GeneratedClrTypeInfo[] {
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GameServerDetails), global::Axlebolt.Bolt.Protobuf2.GameServerDetails.Parser, new[]{ "Id", "GameServer", "Map", "CurrentPlayers", "MaxPlayers", "BotPlayers", "RequirePassword", "Version", "SuccessfulResponse", "DoNotRefresh" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.Lobby), global::Axlebolt.Bolt.Protobuf2.Lobby.Parser, new[]{ "Id", "OwnerGpid", "Name", "LobbyType", "Joinable", "MaxMembers", "Data", "Members", "Invites", "GameServer", "PhotonGame", "MaxSpectators", "Spectators", "SpectatorInvites", "NumberOfMembers", "NumberOfSpectators", "Token" }, null, null, null, new pbr::GeneratedClrTypeInfo[] { null, }),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.LobbyInvite), global::Axlebolt.Bolt.Protobuf2.LobbyInvite.Parser, new[]{ "LobbyId", "InviteSender", "Date", "PlayerType", "LobbyName" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyGameServerRequest), global::Axlebolt.Bolt.Protobuf2.GetLobbyGameServerRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyGameServerResponse), global::Axlebolt.Bolt.Protobuf2.GetLobbyGameServerResponse.Parser, new[]{ "GameServerDetails" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetGameServerDetailsRequest), global::Axlebolt.Bolt.Protobuf2.GetGameServerDetailsRequest.Parser, new[]{ "GameServerId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetGameServerDetailsResponse), global::Axlebolt.Bolt.Protobuf2.GetGameServerDetailsResponse.Parser, new[]{ "GameServerDetails" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyNameRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyNameRequest.Parser, new[]{ "Name" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyNameResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyNameResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SearchLobbyRequest), global::Axlebolt.Bolt.Protobuf2.SearchLobbyRequest.Parser, new[]{ "Amount", "Filters", "Version" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SearchLobbyResponse), global::Axlebolt.Bolt.Protobuf2.SearchLobbyResponse.Parser, new[]{ "Lobbies" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.JoinLobbyAsRequest), global::Axlebolt.Bolt.Protobuf2.JoinLobbyAsRequest.Parser, new[]{ "LobbyId", "PlayerType", "Token" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.JoinLobbyAsResponse), global::Axlebolt.Bolt.Protobuf2.JoinLobbyAsResponse.Parser, new[]{ "Lobby" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyGameServerRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyGameServerRequest.Parser, new[]{ "GameServerId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyGameServerResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyGameServerResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyAsRequest), global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyAsRequest.Parser, new[]{ "InvitedGpid", "PlayerType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyAsResponse), global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyAsResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyOwnerRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyOwnerRequest.Parser, new[]{ "Gpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyOwnerResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyOwnerResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.DeleteLobbyDataRequest), global::Axlebolt.Bolt.Protobuf2.DeleteLobbyDataRequest.Parser, new[]{ "Keys" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.DeleteLobbyDataResponse), global::Axlebolt.Bolt.Protobuf2.DeleteLobbyDataResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetInvitesToLobbyRequest), global::Axlebolt.Bolt.Protobuf2.GetInvitesToLobbyRequest.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetInvitesToLobbyResponse), global::Axlebolt.Bolt.Protobuf2.GetInvitesToLobbyResponse.Parser, new[]{ "LobbyInvites" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyRequest), global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyRequest.Parser, new[]{ "InvitedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyResponse), global::Axlebolt.Bolt.Protobuf2.InvitePlayerToLobbyResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxMembersRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxMembersRequest.Parser, new[]{ "MaxMembers" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxMembersResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxMembersResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RevokePlayerInvitationToLobbyRequest), global::Axlebolt.Bolt.Protobuf2.RevokePlayerInvitationToLobbyRequest.Parser, new[]{ "RevokedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RevokePlayerInvitationToLobbyResponse), global::Axlebolt.Bolt.Protobuf2.RevokePlayerInvitationToLobbyResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.KickPlayerFromLobbyRequest), global::Axlebolt.Bolt.Protobuf2.KickPlayerFromLobbyRequest.Parser, new[]{ "KickedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.KickPlayerFromLobbyResponse), global::Axlebolt.Bolt.Protobuf2.KickPlayerFromLobbyResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreateLobbyWithSpectatorsRequest), global::Axlebolt.Bolt.Protobuf2.CreateLobbyWithSpectatorsRequest.Parser, new[]{ "Name", "LobbyType", "MaxMembers", "MaxSpectators", "DataVisibleInSearch" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.CreateLobbyWithSpectatorsResponse), global::Axlebolt.Bolt.Protobuf2.CreateLobbyWithSpectatorsResponse.Parser, new[]{ "Lobby" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SendLobbyChatMsgRequest), global::Axlebolt.Bolt.Protobuf2.SendLobbyChatMsgRequest.Parser, new[]{ "Message" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SendLobbyChatMsgResponse), global::Axlebolt.Bolt.Protobuf2.SendLobbyChatMsgResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyPhotonGameRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyPhotonGameRequest.Parser, new[]{ "PhotonGame" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyPhotonGameResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyPhotonGameResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RefuseInvitationToLobbyRequest), global::Axlebolt.Bolt.Protobuf2.RefuseInvitationToLobbyRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RefuseInvitationToLobbyResponse), global::Axlebolt.Bolt.Protobuf2.RefuseInvitationToLobbyResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetGameServerPlayersRequest), global::Axlebolt.Bolt.Protobuf2.GetGameServerPlayersRequest.Parser, new[]{ "GameServerId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetGameServerPlayersResponse), global::Axlebolt.Bolt.Protobuf2.GetGameServerPlayersResponse.Parser, new[]{ "Players" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyRequest), global::Axlebolt.Bolt.Protobuf2.GetLobbyRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyResponse), global::Axlebolt.Bolt.Protobuf2.GetLobbyResponse.Parser, new[]{ "Lobby" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyJoinableRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyJoinableRequest.Parser, new[]{ "Joinable" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyJoinableResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyJoinableResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ChangeLobbyPlayerTypeRequest), global::Axlebolt.Bolt.Protobuf2.ChangeLobbyPlayerTypeRequest.Parser, new[]{ "PlayerType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ChangeLobbyPlayerTypeResponse), global::Axlebolt.Bolt.Protobuf2.ChangeLobbyPlayerTypeResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.JoinLobbyRequest), global::Axlebolt.Bolt.Protobuf2.JoinLobbyRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.JoinLobbyResponse), global::Axlebolt.Bolt.Protobuf2.JoinLobbyResponse.Parser, new[]{ "Lobby" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxSpectatorsRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxSpectatorsRequest.Parser, new[]{ "MaxSpectators" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxSpectatorsResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyMaxSpectatorsResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RequestLobbyListRequest), global::Axlebolt.Bolt.Protobuf2.RequestLobbyListRequest.Parser, new[]{ "DistanceFilter", "Filters" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.RequestLobbyListResponse), global::Axlebolt.Bolt.Protobuf2.RequestLobbyListResponse.Parser, new[]{ "Lobbies" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyMembersRequest), global::Axlebolt.Bolt.Protobuf2.GetLobbyMembersRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyMembersResponse), global::Axlebolt.Bolt.Protobuf2.GetLobbyMembersResponse.Parser, new[]{ "Players" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ChangeLobbyOtherPlayerTypeRequest), global::Axlebolt.Bolt.Protobuf2.ChangeLobbyOtherPlayerTypeRequest.Parser, new[]{ "Gpid", "PlayerType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.ChangeLobbyOtherPlayerTypeResponse), global::Axlebolt.Bolt.Protobuf2.ChangeLobbyOtherPlayerTypeResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyPhotonGameRequest), global::Axlebolt.Bolt.Protobuf2.GetLobbyPhotonGameRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyPhotonGameResponse), global::Axlebolt.Bolt.Protobuf2.GetLobbyPhotonGameResponse.Parser, new[]{ "PhotonGame" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyDataRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyDataRequest.Parser, new[]{ "Data" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyDataResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyDataResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyOwnerRequest), global::Axlebolt.Bolt.Protobuf2.GetLobbyOwnerRequest.Parser, new[]{ "LobbyId" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.GetLobbyOwnerResponse), global::Axlebolt.Bolt.Protobuf2.GetLobbyOwnerResponse.Parser, new[]{ "Owner" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.LeaveLobbyRequest), global::Axlebolt.Bolt.Protobuf2.LeaveLobbyRequest.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.LeaveLobbyResponse), global::Axlebolt.Bolt.Protobuf2.LeaveLobbyResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyTypeRequest), global::Axlebolt.Bolt.Protobuf2.SetLobbyTypeRequest.Parser, new[]{ "LobbyType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetLobbyTypeResponse), global::Axlebolt.Bolt.Protobuf2.SetLobbyTypeResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetPhotonGameRequest), global::Axlebolt.Bolt.Protobuf2.SetPhotonGameRequest.Parser, new[]{ "Gpid", "PhotonGame" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.SetPhotonGameResponse), global::Axlebolt.Bolt.Protobuf2.SetPhotonGameResponse.Parser, null, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnRefuseInviteToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnRefuseInviteToLobbyEvent.Parser, new[]{ "InviteSenderGpid", "InvitedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnNewSpectatorInvitedToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnNewSpectatorInvitedToLobbyEvent.Parser, new[]{ "InviteSenderGpid", "NewSpectator" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnNewPlayerJoinedLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnNewPlayerJoinedLobbyEvent.Parser, new[]{ "NewPlayer" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyChatMessageEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyChatMessageEvent.Parser, new[]{ "Gpid", "Message" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnRevokeInviteToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnRevokeInviteToLobbyEvent.Parser, new[]{ "InviteSenderGpid", "InvitedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyPhotonGameChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyPhotonGameChangedEvent.Parser, new[]{ "PhotonGame" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyMaxSpectatorsChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyMaxSpectatorsChangedEvent.Parser, new[]{ "MaxSpectators" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnPlayerKickedFromLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnPlayerKickedFromLobbyEvent.Parser, new[]{ "KickInitiatorGpid", "KickedGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyPlayerTypeChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyPlayerTypeChangedEvent.Parser, new[]{ "Gpid", "PlayerType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnNewSpectatorJoinedLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnNewSpectatorJoinedLobbyEvent.Parser, new[]{ "NewSpectator" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyNameChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyNameChangedEvent.Parser, new[]{ "Name" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyDataChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyDataChangedEvent.Parser, new[]{ "Data" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyGameServerChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyGameServerChangedEvent.Parser, new[]{ "GameServer" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnPlayerLeftLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnPlayerLeftLobbyEvent.Parser, new[]{ "LeftGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyJoinableChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyJoinableChangedEvent.Parser, new[]{ "Joinable" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnReceivedInviteToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnReceivedInviteToLobbyEvent.Parser, new[]{ "Invite" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyMaxMembersChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyMaxMembersChangedEvent.Parser, new[]{ "MaxMembers" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyTypeChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyTypeChangedEvent.Parser, new[]{ "LobbyType" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnNewPlayerInvitedToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnNewPlayerInvitedToLobbyEvent.Parser, new[]{ "InviteSenderGpid", "NewPlayer" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnLobbyOwnerChangedEvent), global::Axlebolt.Bolt.Protobuf2.OnLobbyOwnerChangedEvent.Parser, new[]{ "LobbyOwnerGpid" }, null, null, null, null),
            new pbr::GeneratedClrTypeInfo(typeof(global::Axlebolt.Bolt.Protobuf2.OnReceivedSpectatorInviteToLobbyEvent), global::Axlebolt.Bolt.Protobuf2.OnReceivedSpectatorInviteToLobbyEvent.Parser, new[]{ "Invite" }, null, null, null, null)
          }));
    }

  }
  public enum LobbyType {
    [pbr::OriginalName("PRIVATE")] Private = 0,
    [pbr::OriginalName("FRIENDS_ONLY")] FriendsOnly = 1,
    [pbr::OriginalName("PUBLIC")] Public = 2,
    [pbr::OriginalName("INVISIBLE")] Invisible = 3,
  }

  public enum LobbyPlayerType {
    [pbr::OriginalName("ANY")] Any = 0,
    [pbr::OriginalName("MEMBER")] Member = 1,
    [pbr::OriginalName("SPECTATOR")] Spectator = 2,
  }

  public enum LobbyDistanceFilter {
    [pbr::OriginalName("CLOSE")] Close = 0,
    [pbr::OriginalName("DEFAULT")] Default = 1,
    [pbr::OriginalName("FAR")] Far = 2,
    [pbr::OriginalName("WORLDWIDE")] Worldwide = 3,
  }


  public sealed partial class GameServerDetails : pb::IMessage<GameServerDetails>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GameServerDetails> _parser = new pb::MessageParser<GameServerDetails>(() => new GameServerDetails());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GameServerDetails> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[0]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GameServerDetails() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GameServerDetails(GameServerDetails other) : this() {
      id_ = other.id_;
      gameServer_ = other.gameServer_ != null ? other.gameServer_.Clone() : null;
      map_ = other.map_;
      currentPlayers_ = other.currentPlayers_;
      maxPlayers_ = other.maxPlayers_;
      botPlayers_ = other.botPlayers_;
      requirePassword_ = other.requirePassword_;
      version_ = other.version_;
      successfulResponse_ = other.successfulResponse_;
      doNotRefresh_ = other.doNotRefresh_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GameServerDetails Clone() {
      return new GameServerDetails(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int GameServerFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.GameServer gameServer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.GameServer GameServer {
      get { return gameServer_; }
      set {
        gameServer_ = value;
      }
    }

    public const int MapFieldNumber = 3;
    private string map_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Map {
      get { return map_; }
      set {
        map_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int CurrentPlayersFieldNumber = 4;
    private int currentPlayers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CurrentPlayers {
      get { return currentPlayers_; }
      set {
        currentPlayers_ = value;
      }
    }

    public const int MaxPlayersFieldNumber = 5;
    private int maxPlayers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxPlayers {
      get { return maxPlayers_; }
      set {
        maxPlayers_ = value;
      }
    }

    public const int BotPlayersFieldNumber = 6;
    private int botPlayers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int BotPlayers {
      get { return botPlayers_; }
      set {
        botPlayers_ = value;
      }
    }

    public const int RequirePasswordFieldNumber = 7;
    private bool requirePassword_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool RequirePassword {
      get { return requirePassword_; }
      set {
        requirePassword_ = value;
      }
    }

    public const int VersionFieldNumber = 8;
    private string version_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Version {
      get { return version_; }
      set {
        version_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int SuccessfulResponseFieldNumber = 9;
    private bool successfulResponse_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool SuccessfulResponse {
      get { return successfulResponse_; }
      set {
        successfulResponse_ = value;
      }
    }

    public const int DoNotRefreshFieldNumber = 10;
    private bool doNotRefresh_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool DoNotRefresh {
      get { return doNotRefresh_; }
      set {
        doNotRefresh_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GameServerDetails);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GameServerDetails other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (!object.Equals(GameServer, other.GameServer)) return false;
      if (Map != other.Map) return false;
      if (CurrentPlayers != other.CurrentPlayers) return false;
      if (MaxPlayers != other.MaxPlayers) return false;
      if (BotPlayers != other.BotPlayers) return false;
      if (RequirePassword != other.RequirePassword) return false;
      if (Version != other.Version) return false;
      if (SuccessfulResponse != other.SuccessfulResponse) return false;
      if (DoNotRefresh != other.DoNotRefresh) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (gameServer_ != null) hash ^= GameServer.GetHashCode();
      if (Map.Length != 0) hash ^= Map.GetHashCode();
      if (CurrentPlayers != 0) hash ^= CurrentPlayers.GetHashCode();
      if (MaxPlayers != 0) hash ^= MaxPlayers.GetHashCode();
      if (BotPlayers != 0) hash ^= BotPlayers.GetHashCode();
      if (RequirePassword != false) hash ^= RequirePassword.GetHashCode();
      if (Version.Length != 0) hash ^= Version.GetHashCode();
      if (SuccessfulResponse != false) hash ^= SuccessfulResponse.GetHashCode();
      if (DoNotRefresh != false) hash ^= DoNotRefresh.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (gameServer_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(GameServer);
      }
      if (Map.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Map);
      }
      if (CurrentPlayers != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(CurrentPlayers);
      }
      if (MaxPlayers != 0) {
        output.WriteRawTag(40);
        output.WriteInt32(MaxPlayers);
      }
      if (BotPlayers != 0) {
        output.WriteRawTag(48);
        output.WriteInt32(BotPlayers);
      }
      if (RequirePassword != false) {
        output.WriteRawTag(56);
        output.WriteBool(RequirePassword);
      }
      if (Version.Length != 0) {
        output.WriteRawTag(66);
        output.WriteString(Version);
      }
      if (SuccessfulResponse != false) {
        output.WriteRawTag(72);
        output.WriteBool(SuccessfulResponse);
      }
      if (DoNotRefresh != false) {
        output.WriteRawTag(80);
        output.WriteBool(DoNotRefresh);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (gameServer_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(GameServer);
      }
      if (Map.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Map);
      }
      if (CurrentPlayers != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(CurrentPlayers);
      }
      if (MaxPlayers != 0) {
        output.WriteRawTag(40);
        output.WriteInt32(MaxPlayers);
      }
      if (BotPlayers != 0) {
        output.WriteRawTag(48);
        output.WriteInt32(BotPlayers);
      }
      if (RequirePassword != false) {
        output.WriteRawTag(56);
        output.WriteBool(RequirePassword);
      }
      if (Version.Length != 0) {
        output.WriteRawTag(66);
        output.WriteString(Version);
      }
      if (SuccessfulResponse != false) {
        output.WriteRawTag(72);
        output.WriteBool(SuccessfulResponse);
      }
      if (DoNotRefresh != false) {
        output.WriteRawTag(80);
        output.WriteBool(DoNotRefresh);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (gameServer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(GameServer);
      }
      if (Map.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Map);
      }
      if (CurrentPlayers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(CurrentPlayers);
      }
      if (MaxPlayers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxPlayers);
      }
      if (BotPlayers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(BotPlayers);
      }
      if (RequirePassword != false) {
        size += 1 + 1;
      }
      if (Version.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Version);
      }
      if (SuccessfulResponse != false) {
        size += 1 + 1;
      }
      if (DoNotRefresh != false) {
        size += 1 + 1;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GameServerDetails other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.gameServer_ != null) {
        if (gameServer_ == null) {
          GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
        }
        GameServer.MergeFrom(other.GameServer);
      }
      if (other.Map.Length != 0) {
        Map = other.Map;
      }
      if (other.CurrentPlayers != 0) {
        CurrentPlayers = other.CurrentPlayers;
      }
      if (other.MaxPlayers != 0) {
        MaxPlayers = other.MaxPlayers;
      }
      if (other.BotPlayers != 0) {
        BotPlayers = other.BotPlayers;
      }
      if (other.RequirePassword != false) {
        RequirePassword = other.RequirePassword;
      }
      if (other.Version.Length != 0) {
        Version = other.Version;
      }
      if (other.SuccessfulResponse != false) {
        SuccessfulResponse = other.SuccessfulResponse;
      }
      if (other.DoNotRefresh != false) {
        DoNotRefresh = other.DoNotRefresh;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
          case 26: {
            Map = input.ReadString();
            break;
          }
          case 32: {
            CurrentPlayers = input.ReadInt32();
            break;
          }
          case 40: {
            MaxPlayers = input.ReadInt32();
            break;
          }
          case 48: {
            BotPlayers = input.ReadInt32();
            break;
          }
          case 56: {
            RequirePassword = input.ReadBool();
            break;
          }
          case 66: {
            Version = input.ReadString();
            break;
          }
          case 72: {
            SuccessfulResponse = input.ReadBool();
            break;
          }
          case 80: {
            DoNotRefresh = input.ReadBool();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
          case 26: {
            Map = input.ReadString();
            break;
          }
          case 32: {
            CurrentPlayers = input.ReadInt32();
            break;
          }
          case 40: {
            MaxPlayers = input.ReadInt32();
            break;
          }
          case 48: {
            BotPlayers = input.ReadInt32();
            break;
          }
          case 56: {
            RequirePassword = input.ReadBool();
            break;
          }
          case 66: {
            Version = input.ReadString();
            break;
          }
          case 72: {
            SuccessfulResponse = input.ReadBool();
            break;
          }
          case 80: {
            DoNotRefresh = input.ReadBool();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class Lobby : pb::IMessage<Lobby>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<Lobby> _parser = new pb::MessageParser<Lobby>(() => new Lobby());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<Lobby> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[1]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Lobby() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Lobby(Lobby other) : this() {
      id_ = other.id_;
      ownerGpid_ = other.ownerGpid_;
      name_ = other.name_;
      lobbyType_ = other.lobbyType_;
      joinable_ = other.joinable_;
      maxMembers_ = other.maxMembers_;
      data_ = other.data_.Clone();
      members_ = other.members_.Clone();
      invites_ = other.invites_.Clone();
      gameServer_ = other.gameServer_ != null ? other.gameServer_.Clone() : null;
      photonGame_ = other.photonGame_ != null ? other.photonGame_.Clone() : null;
      maxSpectators_ = other.maxSpectators_;
      spectators_ = other.spectators_.Clone();
      spectatorInvites_ = other.spectatorInvites_.Clone();
      numberOfMembers_ = other.numberOfMembers_;
      numberOfSpectators_ = other.numberOfSpectators_;
      token_ = other.token_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public Lobby Clone() {
      return new Lobby(this);
    }

    public const int IdFieldNumber = 1;
    private string id_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Id {
      get { return id_; }
      set {
        id_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int OwnerGpidFieldNumber = 2;
    private string ownerGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string OwnerGpid {
      get { return ownerGpid_; }
      set {
        ownerGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NameFieldNumber = 3;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LobbyTypeFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.LobbyType lobbyType_ = global::Axlebolt.Bolt.Protobuf2.LobbyType.Private;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyType LobbyType {
      get { return lobbyType_; }
      set {
        lobbyType_ = value;
      }
    }

    public const int JoinableFieldNumber = 5;
    private bool joinable_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Joinable {
      get { return joinable_; }
      set {
        joinable_ = value;
      }
    }

    public const int MaxMembersFieldNumber = 6;
    private int maxMembers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxMembers {
      get { return maxMembers_; }
      set {
        maxMembers_ = value;
      }
    }

    public const int DataFieldNumber = 7;
    private static readonly pbc::MapField<string, string>.Codec _map_data_codec
        = new pbc::MapField<string, string>.Codec(pb::FieldCodec.ForString(10, ""), pb::FieldCodec.ForString(18, ""), 58);
    private readonly pbc::MapField<string, string> data_ = new pbc::MapField<string, string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::MapField<string, string> Data {
      get { return data_; }
    }

    public const int MembersFieldNumber = 8;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> _repeated_members_codec
        = pb::FieldCodec.ForMessage(66, global::Axlebolt.Bolt.Protobuf2.PlayerFriend.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> members_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> Members {
      get { return members_; }
    }

    public const int InvitesFieldNumber = 9;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> _repeated_invites_codec
        = pb::FieldCodec.ForMessage(74, global::Axlebolt.Bolt.Protobuf2.PlayerFriend.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> invites_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> Invites {
      get { return invites_; }
    }

    public const int GameServerFieldNumber = 10;
    private global::Axlebolt.Bolt.Protobuf2.GameServer gameServer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.GameServer GameServer {
      get { return gameServer_; }
      set {
        gameServer_ = value;
      }
    }

    public const int PhotonGameFieldNumber = 11;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    public const int MaxSpectatorsFieldNumber = 12;
    private int maxSpectators_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxSpectators {
      get { return maxSpectators_; }
      set {
        maxSpectators_ = value;
      }
    }

    public const int SpectatorsFieldNumber = 13;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> _repeated_spectators_codec
        = pb::FieldCodec.ForMessage(106, global::Axlebolt.Bolt.Protobuf2.PlayerFriend.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> spectators_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> Spectators {
      get { return spectators_; }
    }

    public const int SpectatorInvitesFieldNumber = 14;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> _repeated_spectatorInvites_codec
        = pb::FieldCodec.ForMessage(114, global::Axlebolt.Bolt.Protobuf2.PlayerFriend.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> spectatorInvites_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.PlayerFriend> SpectatorInvites {
      get { return spectatorInvites_; }
    }

    public const int NumberOfMembersFieldNumber = 15;
    private int numberOfMembers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int NumberOfMembers {
      get { return numberOfMembers_; }
      set {
        numberOfMembers_ = value;
      }
    }

    public const int NumberOfSpectatorsFieldNumber = 16;
    private int numberOfSpectators_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int NumberOfSpectators {
      get { return numberOfSpectators_; }
      set {
        numberOfSpectators_ = value;
      }
    }

    public const int TokenFieldNumber = 17;
    private string token_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Token {
      get { return token_; }
      set {
        token_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as Lobby);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(Lobby other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Id != other.Id) return false;
      if (OwnerGpid != other.OwnerGpid) return false;
      if (Name != other.Name) return false;
      if (LobbyType != other.LobbyType) return false;
      if (Joinable != other.Joinable) return false;
      if (MaxMembers != other.MaxMembers) return false;
      if (!Data.Equals(other.Data)) return false;
      if(!members_.Equals(other.members_)) return false;
      if(!invites_.Equals(other.invites_)) return false;
      if (!object.Equals(GameServer, other.GameServer)) return false;
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      if (MaxSpectators != other.MaxSpectators) return false;
      if(!spectators_.Equals(other.spectators_)) return false;
      if(!spectatorInvites_.Equals(other.spectatorInvites_)) return false;
      if (NumberOfMembers != other.NumberOfMembers) return false;
      if (NumberOfSpectators != other.NumberOfSpectators) return false;
      if (Token != other.Token) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Id.Length != 0) hash ^= Id.GetHashCode();
      if (OwnerGpid.Length != 0) hash ^= OwnerGpid.GetHashCode();
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) hash ^= LobbyType.GetHashCode();
      if (Joinable != false) hash ^= Joinable.GetHashCode();
      if (MaxMembers != 0) hash ^= MaxMembers.GetHashCode();
      hash ^= Data.GetHashCode();
      hash ^= members_.GetHashCode();
      hash ^= invites_.GetHashCode();
      if (gameServer_ != null) hash ^= GameServer.GetHashCode();
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (MaxSpectators != 0) hash ^= MaxSpectators.GetHashCode();
      hash ^= spectators_.GetHashCode();
      hash ^= spectatorInvites_.GetHashCode();
      if (NumberOfMembers != 0) hash ^= NumberOfMembers.GetHashCode();
      if (NumberOfSpectators != 0) hash ^= NumberOfSpectators.GetHashCode();
      if (Token.Length != 0) hash ^= Token.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (OwnerGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(OwnerGpid);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(32);
        output.WriteEnum((int) LobbyType);
      }
      if (Joinable != false) {
        output.WriteRawTag(40);
        output.WriteBool(Joinable);
      }
      if (MaxMembers != 0) {
        output.WriteRawTag(48);
        output.WriteInt32(MaxMembers);
      }
      data_.WriteTo(output, _map_data_codec);
      members_.WriteTo(output, _repeated_members_codec);
      invites_.WriteTo(output, _repeated_invites_codec);
      if (gameServer_ != null) {
        output.WriteRawTag(82);
        output.WriteMessage(GameServer);
      }
      if (photonGame_ != null) {
        output.WriteRawTag(90);
        output.WriteMessage(PhotonGame);
      }
      if (MaxSpectators != 0) {
        output.WriteRawTag(96);
        output.WriteInt32(MaxSpectators);
      }
      spectators_.WriteTo(output, _repeated_spectators_codec);
      spectatorInvites_.WriteTo(output, _repeated_spectatorInvites_codec);
      if (NumberOfMembers != 0) {
        output.WriteRawTag(120);
        output.WriteInt32(NumberOfMembers);
      }
      if (NumberOfSpectators != 0) {
        output.WriteRawTag(128, 1);
        output.WriteInt32(NumberOfSpectators);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(138, 1);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Id.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Id);
      }
      if (OwnerGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(OwnerGpid);
      }
      if (Name.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(32);
        output.WriteEnum((int) LobbyType);
      }
      if (Joinable != false) {
        output.WriteRawTag(40);
        output.WriteBool(Joinable);
      }
      if (MaxMembers != 0) {
        output.WriteRawTag(48);
        output.WriteInt32(MaxMembers);
      }
      data_.WriteTo(ref output, _map_data_codec);
      members_.WriteTo(ref output, _repeated_members_codec);
      invites_.WriteTo(ref output, _repeated_invites_codec);
      if (gameServer_ != null) {
        output.WriteRawTag(82);
        output.WriteMessage(GameServer);
      }
      if (photonGame_ != null) {
        output.WriteRawTag(90);
        output.WriteMessage(PhotonGame);
      }
      if (MaxSpectators != 0) {
        output.WriteRawTag(96);
        output.WriteInt32(MaxSpectators);
      }
      spectators_.WriteTo(ref output, _repeated_spectators_codec);
      spectatorInvites_.WriteTo(ref output, _repeated_spectatorInvites_codec);
      if (NumberOfMembers != 0) {
        output.WriteRawTag(120);
        output.WriteInt32(NumberOfMembers);
      }
      if (NumberOfSpectators != 0) {
        output.WriteRawTag(128, 1);
        output.WriteInt32(NumberOfSpectators);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(138, 1);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Id.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Id);
      }
      if (OwnerGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(OwnerGpid);
      }
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) LobbyType);
      }
      if (Joinable != false) {
        size += 1 + 1;
      }
      if (MaxMembers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxMembers);
      }
      size += data_.CalculateSize(_map_data_codec);
      size += members_.CalculateSize(_repeated_members_codec);
      size += invites_.CalculateSize(_repeated_invites_codec);
      if (gameServer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(GameServer);
      }
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (MaxSpectators != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxSpectators);
      }
      size += spectators_.CalculateSize(_repeated_spectators_codec);
      size += spectatorInvites_.CalculateSize(_repeated_spectatorInvites_codec);
      if (NumberOfMembers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(NumberOfMembers);
      }
      if (NumberOfSpectators != 0) {
        size += 2 + pb::CodedOutputStream.ComputeInt32Size(NumberOfSpectators);
      }
      if (Token.Length != 0) {
        size += 2 + pb::CodedOutputStream.ComputeStringSize(Token);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(Lobby other) {
      if (other == null) {
        return;
      }
      if (other.Id.Length != 0) {
        Id = other.Id;
      }
      if (other.OwnerGpid.Length != 0) {
        OwnerGpid = other.OwnerGpid;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        LobbyType = other.LobbyType;
      }
      if (other.Joinable != false) {
        Joinable = other.Joinable;
      }
      if (other.MaxMembers != 0) {
        MaxMembers = other.MaxMembers;
      }
      data_.Add(other.data_);
      members_.Add(other.members_);
      invites_.Add(other.invites_);
      if (other.gameServer_ != null) {
        if (gameServer_ == null) {
          GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
        }
        GameServer.MergeFrom(other.GameServer);
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      if (other.MaxSpectators != 0) {
        MaxSpectators = other.MaxSpectators;
      }
      spectators_.Add(other.spectators_);
      spectatorInvites_.Add(other.spectatorInvites_);
      if (other.NumberOfMembers != 0) {
        NumberOfMembers = other.NumberOfMembers;
      }
      if (other.NumberOfSpectators != 0) {
        NumberOfSpectators = other.NumberOfSpectators;
      }
      if (other.Token.Length != 0) {
        Token = other.Token;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            OwnerGpid = input.ReadString();
            break;
          }
          case 26: {
            Name = input.ReadString();
            break;
          }
          case 32: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
          case 40: {
            Joinable = input.ReadBool();
            break;
          }
          case 48: {
            MaxMembers = input.ReadInt32();
            break;
          }
          case 58: {
            data_.AddEntriesFrom(input, _map_data_codec);
            break;
          }
          case 66: {
            members_.AddEntriesFrom(input, _repeated_members_codec);
            break;
          }
          case 74: {
            invites_.AddEntriesFrom(input, _repeated_invites_codec);
            break;
          }
          case 82: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
          case 90: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
          case 96: {
            MaxSpectators = input.ReadInt32();
            break;
          }
          case 106: {
            spectators_.AddEntriesFrom(input, _repeated_spectators_codec);
            break;
          }
          case 114: {
            spectatorInvites_.AddEntriesFrom(input, _repeated_spectatorInvites_codec);
            break;
          }
          case 120: {
            NumberOfMembers = input.ReadInt32();
            break;
          }
          case 128: {
            NumberOfSpectators = input.ReadInt32();
            break;
          }
          case 138: {
            Token = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Id = input.ReadString();
            break;
          }
          case 18: {
            OwnerGpid = input.ReadString();
            break;
          }
          case 26: {
            Name = input.ReadString();
            break;
          }
          case 32: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
          case 40: {
            Joinable = input.ReadBool();
            break;
          }
          case 48: {
            MaxMembers = input.ReadInt32();
            break;
          }
          case 58: {
            data_.AddEntriesFrom(ref input, _map_data_codec);
            break;
          }
          case 66: {
            members_.AddEntriesFrom(ref input, _repeated_members_codec);
            break;
          }
          case 74: {
            invites_.AddEntriesFrom(ref input, _repeated_invites_codec);
            break;
          }
          case 82: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
          case 90: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
          case 96: {
            MaxSpectators = input.ReadInt32();
            break;
          }
          case 106: {
            spectators_.AddEntriesFrom(ref input, _repeated_spectators_codec);
            break;
          }
          case 114: {
            spectatorInvites_.AddEntriesFrom(ref input, _repeated_spectatorInvites_codec);
            break;
          }
          case 120: {
            NumberOfMembers = input.ReadInt32();
            break;
          }
          case 128: {
            NumberOfSpectators = input.ReadInt32();
            break;
          }
          case 138: {
            Token = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class LobbyInvite : pb::IMessage<LobbyInvite>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<LobbyInvite> _parser = new pb::MessageParser<LobbyInvite>(() => new LobbyInvite());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<LobbyInvite> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[2]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LobbyInvite() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LobbyInvite(LobbyInvite other) : this() {
      lobbyId_ = other.lobbyId_;
      inviteSender_ = other.inviteSender_ != null ? other.inviteSender_.Clone() : null;
      date_ = other.date_;
      playerType_ = other.playerType_;
      lobbyName_ = other.lobbyName_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LobbyInvite Clone() {
      return new LobbyInvite(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int InviteSenderFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend inviteSender_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend InviteSender {
      get { return inviteSender_; }
      set {
        inviteSender_ = value;
      }
    }

    public const int DateFieldNumber = 3;
    private long date_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public long Date {
      get { return date_; }
      set {
        date_ = value;
      }
    }

    public const int PlayerTypeFieldNumber = 4;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    public const int LobbyNameFieldNumber = 5;
    private string lobbyName_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyName {
      get { return lobbyName_; }
      set {
        lobbyName_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as LobbyInvite);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(LobbyInvite other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      if (!object.Equals(InviteSender, other.InviteSender)) return false;
      if (Date != other.Date) return false;
      if (PlayerType != other.PlayerType) return false;
      if (LobbyName != other.LobbyName) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (inviteSender_ != null) hash ^= InviteSender.GetHashCode();
      if (Date != 0L) hash ^= Date.GetHashCode();
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (LobbyName.Length != 0) hash ^= LobbyName.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (inviteSender_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(InviteSender);
      }
      if (Date != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Date);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(32);
        output.WriteEnum((int) PlayerType);
      }
      if (LobbyName.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(LobbyName);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (inviteSender_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(InviteSender);
      }
      if (Date != 0L) {
        output.WriteRawTag(24);
        output.WriteInt64(Date);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(32);
        output.WriteEnum((int) PlayerType);
      }
      if (LobbyName.Length != 0) {
        output.WriteRawTag(42);
        output.WriteString(LobbyName);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (inviteSender_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(InviteSender);
      }
      if (Date != 0L) {
        size += 1 + pb::CodedOutputStream.ComputeInt64Size(Date);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (LobbyName.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyName);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(LobbyInvite other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      if (other.inviteSender_ != null) {
        if (inviteSender_ == null) {
          InviteSender = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        InviteSender.MergeFrom(other.InviteSender);
      }
      if (other.Date != 0L) {
        Date = other.Date;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      if (other.LobbyName.Length != 0) {
        LobbyName = other.LobbyName;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
          case 18: {
            if (inviteSender_ == null) {
              InviteSender = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(InviteSender);
            break;
          }
          case 24: {
            Date = input.ReadInt64();
            break;
          }
          case 32: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
          case 42: {
            LobbyName = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
          case 18: {
            if (inviteSender_ == null) {
              InviteSender = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(InviteSender);
            break;
          }
          case 24: {
            Date = input.ReadInt64();
            break;
          }
          case 32: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
          case 42: {
            LobbyName = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyGameServerRequest : pb::IMessage<GetLobbyGameServerRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyGameServerRequest> _parser = new pb::MessageParser<GetLobbyGameServerRequest>(() => new GetLobbyGameServerRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyGameServerRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[3]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerRequest(GetLobbyGameServerRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerRequest Clone() {
      return new GetLobbyGameServerRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyGameServerRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyGameServerRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyGameServerRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyGameServerResponse : pb::IMessage<GetLobbyGameServerResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyGameServerResponse> _parser = new pb::MessageParser<GetLobbyGameServerResponse>(() => new GetLobbyGameServerResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyGameServerResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[4]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerResponse(GetLobbyGameServerResponse other) : this() {
      gameServerDetails_ = other.gameServerDetails_ != null ? other.gameServerDetails_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyGameServerResponse Clone() {
      return new GetLobbyGameServerResponse(this);
    }

    public const int GameServerDetailsFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.GameServerDetails gameServerDetails_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.GameServerDetails GameServerDetails {
      get { return gameServerDetails_; }
      set {
        gameServerDetails_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyGameServerResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyGameServerResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(GameServerDetails, other.GameServerDetails)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (gameServerDetails_ != null) hash ^= GameServerDetails.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (gameServerDetails_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServerDetails);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (gameServerDetails_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServerDetails);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (gameServerDetails_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(GameServerDetails);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyGameServerResponse other) {
      if (other == null) {
        return;
      }
      if (other.gameServerDetails_ != null) {
        if (gameServerDetails_ == null) {
          GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
        }
        GameServerDetails.MergeFrom(other.GameServerDetails);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (gameServerDetails_ == null) {
              GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
            }
            input.ReadMessage(GameServerDetails);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (gameServerDetails_ == null) {
              GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
            }
            input.ReadMessage(GameServerDetails);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetGameServerDetailsRequest : pb::IMessage<GetGameServerDetailsRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetGameServerDetailsRequest> _parser = new pb::MessageParser<GetGameServerDetailsRequest>(() => new GetGameServerDetailsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetGameServerDetailsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[5]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsRequest(GetGameServerDetailsRequest other) : this() {
      gameServerId_ = other.gameServerId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsRequest Clone() {
      return new GetGameServerDetailsRequest(this);
    }

    public const int GameServerIdFieldNumber = 1;
    private string gameServerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameServerId {
      get { return gameServerId_; }
      set {
        gameServerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetGameServerDetailsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetGameServerDetailsRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameServerId != other.GameServerId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameServerId.Length != 0) hash ^= GameServerId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameServerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameServerId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetGameServerDetailsRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameServerId.Length != 0) {
        GameServerId = other.GameServerId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetGameServerDetailsResponse : pb::IMessage<GetGameServerDetailsResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetGameServerDetailsResponse> _parser = new pb::MessageParser<GetGameServerDetailsResponse>(() => new GetGameServerDetailsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetGameServerDetailsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[6]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsResponse(GetGameServerDetailsResponse other) : this() {
      gameServerDetails_ = other.gameServerDetails_ != null ? other.gameServerDetails_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerDetailsResponse Clone() {
      return new GetGameServerDetailsResponse(this);
    }

    public const int GameServerDetailsFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.GameServerDetails gameServerDetails_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.GameServerDetails GameServerDetails {
      get { return gameServerDetails_; }
      set {
        gameServerDetails_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetGameServerDetailsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetGameServerDetailsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(GameServerDetails, other.GameServerDetails)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (gameServerDetails_ != null) hash ^= GameServerDetails.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (gameServerDetails_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServerDetails);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (gameServerDetails_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServerDetails);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (gameServerDetails_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(GameServerDetails);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetGameServerDetailsResponse other) {
      if (other == null) {
        return;
      }
      if (other.gameServerDetails_ != null) {
        if (gameServerDetails_ == null) {
          GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
        }
        GameServerDetails.MergeFrom(other.GameServerDetails);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (gameServerDetails_ == null) {
              GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
            }
            input.ReadMessage(GameServerDetails);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (gameServerDetails_ == null) {
              GameServerDetails = new global::Axlebolt.Bolt.Protobuf2.GameServerDetails();
            }
            input.ReadMessage(GameServerDetails);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyNameRequest : pb::IMessage<SetLobbyNameRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyNameRequest> _parser = new pb::MessageParser<SetLobbyNameRequest>(() => new SetLobbyNameRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyNameRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[7]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameRequest(SetLobbyNameRequest other) : this() {
      name_ = other.name_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameRequest Clone() {
      return new SetLobbyNameRequest(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyNameRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyNameRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyNameRequest other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyNameResponse : pb::IMessage<SetLobbyNameResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyNameResponse> _parser = new pb::MessageParser<SetLobbyNameResponse>(() => new SetLobbyNameResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyNameResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[8]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameResponse(SetLobbyNameResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyNameResponse Clone() {
      return new SetLobbyNameResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyNameResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyNameResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyNameResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SearchLobbyRequest : pb::IMessage<SearchLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SearchLobbyRequest> _parser = new pb::MessageParser<SearchLobbyRequest>(() => new SearchLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SearchLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[9]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyRequest(SearchLobbyRequest other) : this() {
      amount_ = other.amount_;
      filters_ = other.filters_.Clone();
      version_ = other.version_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyRequest Clone() {
      return new SearchLobbyRequest(this);
    }

    public const int AmountFieldNumber = 1;
    private int amount_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Amount {
      get { return amount_; }
      set {
        amount_ = value;
      }
    }

    public const int FiltersFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Filter> _repeated_filters_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.Filter.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter> filters_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter> Filters {
      get { return filters_; }
    }

    public const int VersionFieldNumber = 3;
    private int version_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int Version {
      get { return version_; }
      set {
        version_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SearchLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SearchLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Amount != other.Amount) return false;
      if(!filters_.Equals(other.filters_)) return false;
      if (Version != other.Version) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Amount != 0) hash ^= Amount.GetHashCode();
      hash ^= filters_.GetHashCode();
      if (Version != 0) hash ^= Version.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Amount != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Amount);
      }
      filters_.WriteTo(output, _repeated_filters_codec);
      if (Version != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Version);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Amount != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(Amount);
      }
      filters_.WriteTo(ref output, _repeated_filters_codec);
      if (Version != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(Version);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Amount != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Amount);
      }
      size += filters_.CalculateSize(_repeated_filters_codec);
      if (Version != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(Version);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SearchLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.Amount != 0) {
        Amount = other.Amount;
      }
      filters_.Add(other.filters_);
      if (other.Version != 0) {
        Version = other.Version;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Amount = input.ReadInt32();
            break;
          }
          case 18: {
            filters_.AddEntriesFrom(input, _repeated_filters_codec);
            break;
          }
          case 24: {
            Version = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Amount = input.ReadInt32();
            break;
          }
          case 18: {
            filters_.AddEntriesFrom(ref input, _repeated_filters_codec);
            break;
          }
          case 24: {
            Version = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SearchLobbyResponse : pb::IMessage<SearchLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SearchLobbyResponse> _parser = new pb::MessageParser<SearchLobbyResponse>(() => new SearchLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SearchLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[10]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyResponse(SearchLobbyResponse other) : this() {
      lobbies_ = other.lobbies_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SearchLobbyResponse Clone() {
      return new SearchLobbyResponse(this);
    }

    public const int LobbiesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Lobby> _repeated_lobbies_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.Lobby.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby> lobbies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby> Lobbies {
      get { return lobbies_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SearchLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SearchLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!lobbies_.Equals(other.lobbies_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= lobbies_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      lobbies_.WriteTo(output, _repeated_lobbies_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      lobbies_.WriteTo(ref output, _repeated_lobbies_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += lobbies_.CalculateSize(_repeated_lobbies_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SearchLobbyResponse other) {
      if (other == null) {
        return;
      }
      lobbies_.Add(other.lobbies_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            lobbies_.AddEntriesFrom(input, _repeated_lobbies_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            lobbies_.AddEntriesFrom(ref input, _repeated_lobbies_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class JoinLobbyAsRequest : pb::IMessage<JoinLobbyAsRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<JoinLobbyAsRequest> _parser = new pb::MessageParser<JoinLobbyAsRequest>(() => new JoinLobbyAsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<JoinLobbyAsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[11]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsRequest(JoinLobbyAsRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      playerType_ = other.playerType_;
      token_ = other.token_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsRequest Clone() {
      return new JoinLobbyAsRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayerTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    public const int TokenFieldNumber = 3;
    private string token_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Token {
      get { return token_; }
      set {
        token_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as JoinLobbyAsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(JoinLobbyAsRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      if (PlayerType != other.PlayerType) return false;
      if (Token != other.Token) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (Token.Length != 0) hash ^= Token.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (Token.Length != 0) {
        output.WriteRawTag(26);
        output.WriteString(Token);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (Token.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Token);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(JoinLobbyAsRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      if (other.Token.Length != 0) {
        Token = other.Token;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
          case 26: {
            Token = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
          case 26: {
            Token = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class JoinLobbyAsResponse : pb::IMessage<JoinLobbyAsResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<JoinLobbyAsResponse> _parser = new pb::MessageParser<JoinLobbyAsResponse>(() => new JoinLobbyAsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<JoinLobbyAsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[12]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsResponse(JoinLobbyAsResponse other) : this() {
      lobby_ = other.lobby_ != null ? other.lobby_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyAsResponse Clone() {
      return new JoinLobbyAsResponse(this);
    }

    public const int LobbyFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Lobby lobby_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Lobby Lobby {
      get { return lobby_; }
      set {
        lobby_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as JoinLobbyAsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(JoinLobbyAsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Lobby, other.Lobby)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (lobby_ != null) hash ^= Lobby.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (lobby_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Lobby);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(JoinLobbyAsResponse other) {
      if (other == null) {
        return;
      }
      if (other.lobby_ != null) {
        if (lobby_ == null) {
          Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
        }
        Lobby.MergeFrom(other.Lobby);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyGameServerRequest : pb::IMessage<SetLobbyGameServerRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyGameServerRequest> _parser = new pb::MessageParser<SetLobbyGameServerRequest>(() => new SetLobbyGameServerRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyGameServerRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[13]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerRequest(SetLobbyGameServerRequest other) : this() {
      gameServerId_ = other.gameServerId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerRequest Clone() {
      return new SetLobbyGameServerRequest(this);
    }

    public const int GameServerIdFieldNumber = 1;
    private string gameServerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameServerId {
      get { return gameServerId_; }
      set {
        gameServerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyGameServerRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyGameServerRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameServerId != other.GameServerId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameServerId.Length != 0) hash ^= GameServerId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameServerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameServerId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyGameServerRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameServerId.Length != 0) {
        GameServerId = other.GameServerId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyGameServerResponse : pb::IMessage<SetLobbyGameServerResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyGameServerResponse> _parser = new pb::MessageParser<SetLobbyGameServerResponse>(() => new SetLobbyGameServerResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyGameServerResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[14]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerResponse(SetLobbyGameServerResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyGameServerResponse Clone() {
      return new SetLobbyGameServerResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyGameServerResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyGameServerResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyGameServerResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class InvitePlayerToLobbyAsRequest : pb::IMessage<InvitePlayerToLobbyAsRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<InvitePlayerToLobbyAsRequest> _parser = new pb::MessageParser<InvitePlayerToLobbyAsRequest>(() => new InvitePlayerToLobbyAsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InvitePlayerToLobbyAsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[15]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsRequest(InvitePlayerToLobbyAsRequest other) : this() {
      invitedGpid_ = other.invitedGpid_;
      playerType_ = other.playerType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsRequest Clone() {
      return new InvitePlayerToLobbyAsRequest(this);
    }

    public const int InvitedGpidFieldNumber = 1;
    private string invitedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InvitedGpid {
      get { return invitedGpid_; }
      set {
        invitedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayerTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InvitePlayerToLobbyAsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InvitePlayerToLobbyAsRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InvitedGpid != other.InvitedGpid) return false;
      if (PlayerType != other.PlayerType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InvitedGpid.Length != 0) hash ^= InvitedGpid.GetHashCode();
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InvitedGpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InvitedGpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InvitedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InvitedGpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InvitePlayerToLobbyAsRequest other) {
      if (other == null) {
        return;
      }
      if (other.InvitedGpid.Length != 0) {
        InvitedGpid = other.InvitedGpid;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InvitedGpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InvitedGpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class InvitePlayerToLobbyAsResponse : pb::IMessage<InvitePlayerToLobbyAsResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<InvitePlayerToLobbyAsResponse> _parser = new pb::MessageParser<InvitePlayerToLobbyAsResponse>(() => new InvitePlayerToLobbyAsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InvitePlayerToLobbyAsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[16]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsResponse(InvitePlayerToLobbyAsResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyAsResponse Clone() {
      return new InvitePlayerToLobbyAsResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InvitePlayerToLobbyAsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InvitePlayerToLobbyAsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InvitePlayerToLobbyAsResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyOwnerRequest : pb::IMessage<SetLobbyOwnerRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyOwnerRequest> _parser = new pb::MessageParser<SetLobbyOwnerRequest>(() => new SetLobbyOwnerRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyOwnerRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[17]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerRequest(SetLobbyOwnerRequest other) : this() {
      gpid_ = other.gpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerRequest Clone() {
      return new SetLobbyOwnerRequest(this);
    }

    public const int GpidFieldNumber = 1;
    private string gpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Gpid {
      get { return gpid_; }
      set {
        gpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyOwnerRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyOwnerRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Gpid != other.Gpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Gpid.Length != 0) hash ^= Gpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Gpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Gpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyOwnerRequest other) {
      if (other == null) {
        return;
      }
      if (other.Gpid.Length != 0) {
        Gpid = other.Gpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyOwnerResponse : pb::IMessage<SetLobbyOwnerResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyOwnerResponse> _parser = new pb::MessageParser<SetLobbyOwnerResponse>(() => new SetLobbyOwnerResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyOwnerResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[18]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerResponse(SetLobbyOwnerResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyOwnerResponse Clone() {
      return new SetLobbyOwnerResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyOwnerResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyOwnerResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyOwnerResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class DeleteLobbyDataRequest : pb::IMessage<DeleteLobbyDataRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<DeleteLobbyDataRequest> _parser = new pb::MessageParser<DeleteLobbyDataRequest>(() => new DeleteLobbyDataRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<DeleteLobbyDataRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[19]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataRequest(DeleteLobbyDataRequest other) : this() {
      keys_ = other.keys_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataRequest Clone() {
      return new DeleteLobbyDataRequest(this);
    }

    public const int KeysFieldNumber = 1;
    private static readonly pb::FieldCodec<string> _repeated_keys_codec
        = pb::FieldCodec.ForString(10);
    private readonly pbc::RepeatedField<string> keys_ = new pbc::RepeatedField<string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<string> Keys {
      get { return keys_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as DeleteLobbyDataRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(DeleteLobbyDataRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!keys_.Equals(other.keys_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= keys_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      keys_.WriteTo(output, _repeated_keys_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      keys_.WriteTo(ref output, _repeated_keys_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += keys_.CalculateSize(_repeated_keys_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(DeleteLobbyDataRequest other) {
      if (other == null) {
        return;
      }
      keys_.Add(other.keys_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            keys_.AddEntriesFrom(input, _repeated_keys_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            keys_.AddEntriesFrom(ref input, _repeated_keys_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class DeleteLobbyDataResponse : pb::IMessage<DeleteLobbyDataResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<DeleteLobbyDataResponse> _parser = new pb::MessageParser<DeleteLobbyDataResponse>(() => new DeleteLobbyDataResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<DeleteLobbyDataResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[20]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataResponse(DeleteLobbyDataResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public DeleteLobbyDataResponse Clone() {
      return new DeleteLobbyDataResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as DeleteLobbyDataResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(DeleteLobbyDataResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(DeleteLobbyDataResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class GetInvitesToLobbyRequest : pb::IMessage<GetInvitesToLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetInvitesToLobbyRequest> _parser = new pb::MessageParser<GetInvitesToLobbyRequest>(() => new GetInvitesToLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetInvitesToLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[21]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyRequest(GetInvitesToLobbyRequest other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyRequest Clone() {
      return new GetInvitesToLobbyRequest(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetInvitesToLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetInvitesToLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetInvitesToLobbyRequest other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class GetInvitesToLobbyResponse : pb::IMessage<GetInvitesToLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetInvitesToLobbyResponse> _parser = new pb::MessageParser<GetInvitesToLobbyResponse>(() => new GetInvitesToLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetInvitesToLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[22]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyResponse(GetInvitesToLobbyResponse other) : this() {
      lobbyInvites_ = other.lobbyInvites_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetInvitesToLobbyResponse Clone() {
      return new GetInvitesToLobbyResponse(this);
    }

    public const int LobbyInvitesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.LobbyInvite> _repeated_lobbyInvites_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.LobbyInvite.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.LobbyInvite> lobbyInvites_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.LobbyInvite>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.LobbyInvite> LobbyInvites {
      get { return lobbyInvites_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetInvitesToLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetInvitesToLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!lobbyInvites_.Equals(other.lobbyInvites_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= lobbyInvites_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      lobbyInvites_.WriteTo(output, _repeated_lobbyInvites_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      lobbyInvites_.WriteTo(ref output, _repeated_lobbyInvites_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += lobbyInvites_.CalculateSize(_repeated_lobbyInvites_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetInvitesToLobbyResponse other) {
      if (other == null) {
        return;
      }
      lobbyInvites_.Add(other.lobbyInvites_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            lobbyInvites_.AddEntriesFrom(input, _repeated_lobbyInvites_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            lobbyInvites_.AddEntriesFrom(ref input, _repeated_lobbyInvites_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class InvitePlayerToLobbyRequest : pb::IMessage<InvitePlayerToLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<InvitePlayerToLobbyRequest> _parser = new pb::MessageParser<InvitePlayerToLobbyRequest>(() => new InvitePlayerToLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InvitePlayerToLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[23]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyRequest(InvitePlayerToLobbyRequest other) : this() {
      invitedGpid_ = other.invitedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyRequest Clone() {
      return new InvitePlayerToLobbyRequest(this);
    }

    public const int InvitedGpidFieldNumber = 1;
    private string invitedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InvitedGpid {
      get { return invitedGpid_; }
      set {
        invitedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InvitePlayerToLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InvitePlayerToLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InvitedGpid != other.InvitedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InvitedGpid.Length != 0) hash ^= InvitedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InvitedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InvitedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InvitePlayerToLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.InvitedGpid.Length != 0) {
        InvitedGpid = other.InvitedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class InvitePlayerToLobbyResponse : pb::IMessage<InvitePlayerToLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<InvitePlayerToLobbyResponse> _parser = new pb::MessageParser<InvitePlayerToLobbyResponse>(() => new InvitePlayerToLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<InvitePlayerToLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[24]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyResponse(InvitePlayerToLobbyResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public InvitePlayerToLobbyResponse Clone() {
      return new InvitePlayerToLobbyResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as InvitePlayerToLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(InvitePlayerToLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(InvitePlayerToLobbyResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyMaxMembersRequest : pb::IMessage<SetLobbyMaxMembersRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyMaxMembersRequest> _parser = new pb::MessageParser<SetLobbyMaxMembersRequest>(() => new SetLobbyMaxMembersRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyMaxMembersRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[25]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersRequest(SetLobbyMaxMembersRequest other) : this() {
      maxMembers_ = other.maxMembers_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersRequest Clone() {
      return new SetLobbyMaxMembersRequest(this);
    }

    public const int MaxMembersFieldNumber = 1;
    private int maxMembers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxMembers {
      get { return maxMembers_; }
      set {
        maxMembers_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyMaxMembersRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyMaxMembersRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (MaxMembers != other.MaxMembers) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (MaxMembers != 0) hash ^= MaxMembers.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (MaxMembers != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxMembers);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (MaxMembers != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxMembers);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (MaxMembers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxMembers);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyMaxMembersRequest other) {
      if (other == null) {
        return;
      }
      if (other.MaxMembers != 0) {
        MaxMembers = other.MaxMembers;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            MaxMembers = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            MaxMembers = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyMaxMembersResponse : pb::IMessage<SetLobbyMaxMembersResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyMaxMembersResponse> _parser = new pb::MessageParser<SetLobbyMaxMembersResponse>(() => new SetLobbyMaxMembersResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyMaxMembersResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[26]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersResponse(SetLobbyMaxMembersResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxMembersResponse Clone() {
      return new SetLobbyMaxMembersResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyMaxMembersResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyMaxMembersResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyMaxMembersResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class RevokePlayerInvitationToLobbyRequest : pb::IMessage<RevokePlayerInvitationToLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RevokePlayerInvitationToLobbyRequest> _parser = new pb::MessageParser<RevokePlayerInvitationToLobbyRequest>(() => new RevokePlayerInvitationToLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RevokePlayerInvitationToLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[27]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyRequest(RevokePlayerInvitationToLobbyRequest other) : this() {
      revokedGpid_ = other.revokedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyRequest Clone() {
      return new RevokePlayerInvitationToLobbyRequest(this);
    }

    public const int RevokedGpidFieldNumber = 1;
    private string revokedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string RevokedGpid {
      get { return revokedGpid_; }
      set {
        revokedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RevokePlayerInvitationToLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RevokePlayerInvitationToLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (RevokedGpid != other.RevokedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (RevokedGpid.Length != 0) hash ^= RevokedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (RevokedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RevokedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (RevokedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(RevokedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (RevokedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(RevokedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RevokePlayerInvitationToLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.RevokedGpid.Length != 0) {
        RevokedGpid = other.RevokedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            RevokedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            RevokedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class RevokePlayerInvitationToLobbyResponse : pb::IMessage<RevokePlayerInvitationToLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RevokePlayerInvitationToLobbyResponse> _parser = new pb::MessageParser<RevokePlayerInvitationToLobbyResponse>(() => new RevokePlayerInvitationToLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RevokePlayerInvitationToLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[28]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyResponse(RevokePlayerInvitationToLobbyResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RevokePlayerInvitationToLobbyResponse Clone() {
      return new RevokePlayerInvitationToLobbyResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RevokePlayerInvitationToLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RevokePlayerInvitationToLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RevokePlayerInvitationToLobbyResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class KickPlayerFromLobbyRequest : pb::IMessage<KickPlayerFromLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<KickPlayerFromLobbyRequest> _parser = new pb::MessageParser<KickPlayerFromLobbyRequest>(() => new KickPlayerFromLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<KickPlayerFromLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[29]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyRequest(KickPlayerFromLobbyRequest other) : this() {
      kickedGpid_ = other.kickedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyRequest Clone() {
      return new KickPlayerFromLobbyRequest(this);
    }

    public const int KickedGpidFieldNumber = 1;
    private string kickedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string KickedGpid {
      get { return kickedGpid_; }
      set {
        kickedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as KickPlayerFromLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(KickPlayerFromLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (KickedGpid != other.KickedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (KickedGpid.Length != 0) hash ^= KickedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (KickedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (KickedGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (KickedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(KickPlayerFromLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.KickedGpid.Length != 0) {
        KickedGpid = other.KickedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            KickedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            KickedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class KickPlayerFromLobbyResponse : pb::IMessage<KickPlayerFromLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<KickPlayerFromLobbyResponse> _parser = new pb::MessageParser<KickPlayerFromLobbyResponse>(() => new KickPlayerFromLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<KickPlayerFromLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[30]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyResponse(KickPlayerFromLobbyResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public KickPlayerFromLobbyResponse Clone() {
      return new KickPlayerFromLobbyResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as KickPlayerFromLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(KickPlayerFromLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(KickPlayerFromLobbyResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class CreateLobbyWithSpectatorsRequest : pb::IMessage<CreateLobbyWithSpectatorsRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreateLobbyWithSpectatorsRequest> _parser = new pb::MessageParser<CreateLobbyWithSpectatorsRequest>(() => new CreateLobbyWithSpectatorsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<CreateLobbyWithSpectatorsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[31]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsRequest(CreateLobbyWithSpectatorsRequest other) : this() {
      name_ = other.name_;
      lobbyType_ = other.lobbyType_;
      maxMembers_ = other.maxMembers_;
      maxSpectators_ = other.maxSpectators_;
      dataVisibleInSearch_ = other.dataVisibleInSearch_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsRequest Clone() {
      return new CreateLobbyWithSpectatorsRequest(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int LobbyTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.LobbyType lobbyType_ = global::Axlebolt.Bolt.Protobuf2.LobbyType.Private;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyType LobbyType {
      get { return lobbyType_; }
      set {
        lobbyType_ = value;
      }
    }

    public const int MaxMembersFieldNumber = 3;
    private int maxMembers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxMembers {
      get { return maxMembers_; }
      set {
        maxMembers_ = value;
      }
    }

    public const int MaxSpectatorsFieldNumber = 4;
    private int maxSpectators_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxSpectators {
      get { return maxSpectators_; }
      set {
        maxSpectators_ = value;
      }
    }

    public const int DataVisibleInSearchFieldNumber = 5;
    private static readonly pb::FieldCodec<string> _repeated_dataVisibleInSearch_codec
        = pb::FieldCodec.ForString(42);
    private readonly pbc::RepeatedField<string> dataVisibleInSearch_ = new pbc::RepeatedField<string>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<string> DataVisibleInSearch {
      get { return dataVisibleInSearch_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as CreateLobbyWithSpectatorsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(CreateLobbyWithSpectatorsRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      if (LobbyType != other.LobbyType) return false;
      if (MaxMembers != other.MaxMembers) return false;
      if (MaxSpectators != other.MaxSpectators) return false;
      if(!dataVisibleInSearch_.Equals(other.dataVisibleInSearch_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) hash ^= LobbyType.GetHashCode();
      if (MaxMembers != 0) hash ^= MaxMembers.GetHashCode();
      if (MaxSpectators != 0) hash ^= MaxSpectators.GetHashCode();
      hash ^= dataVisibleInSearch_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(16);
        output.WriteEnum((int) LobbyType);
      }
      if (MaxMembers != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(MaxMembers);
      }
      if (MaxSpectators != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(MaxSpectators);
      }
      dataVisibleInSearch_.WriteTo(output, _repeated_dataVisibleInSearch_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(16);
        output.WriteEnum((int) LobbyType);
      }
      if (MaxMembers != 0) {
        output.WriteRawTag(24);
        output.WriteInt32(MaxMembers);
      }
      if (MaxSpectators != 0) {
        output.WriteRawTag(32);
        output.WriteInt32(MaxSpectators);
      }
      dataVisibleInSearch_.WriteTo(ref output, _repeated_dataVisibleInSearch_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) LobbyType);
      }
      if (MaxMembers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxMembers);
      }
      if (MaxSpectators != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxSpectators);
      }
      size += dataVisibleInSearch_.CalculateSize(_repeated_dataVisibleInSearch_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(CreateLobbyWithSpectatorsRequest other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      if (other.LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        LobbyType = other.LobbyType;
      }
      if (other.MaxMembers != 0) {
        MaxMembers = other.MaxMembers;
      }
      if (other.MaxSpectators != 0) {
        MaxSpectators = other.MaxSpectators;
      }
      dataVisibleInSearch_.Add(other.dataVisibleInSearch_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
          case 24: {
            MaxMembers = input.ReadInt32();
            break;
          }
          case 32: {
            MaxSpectators = input.ReadInt32();
            break;
          }
          case 42: {
            dataVisibleInSearch_.AddEntriesFrom(input, _repeated_dataVisibleInSearch_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
          case 16: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
          case 24: {
            MaxMembers = input.ReadInt32();
            break;
          }
          case 32: {
            MaxSpectators = input.ReadInt32();
            break;
          }
          case 42: {
            dataVisibleInSearch_.AddEntriesFrom(ref input, _repeated_dataVisibleInSearch_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class CreateLobbyWithSpectatorsResponse : pb::IMessage<CreateLobbyWithSpectatorsResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<CreateLobbyWithSpectatorsResponse> _parser = new pb::MessageParser<CreateLobbyWithSpectatorsResponse>(() => new CreateLobbyWithSpectatorsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<CreateLobbyWithSpectatorsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[32]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsResponse(CreateLobbyWithSpectatorsResponse other) : this() {
      lobby_ = other.lobby_ != null ? other.lobby_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public CreateLobbyWithSpectatorsResponse Clone() {
      return new CreateLobbyWithSpectatorsResponse(this);
    }

    public const int LobbyFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Lobby lobby_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Lobby Lobby {
      get { return lobby_; }
      set {
        lobby_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as CreateLobbyWithSpectatorsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(CreateLobbyWithSpectatorsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Lobby, other.Lobby)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (lobby_ != null) hash ^= Lobby.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (lobby_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Lobby);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(CreateLobbyWithSpectatorsResponse other) {
      if (other == null) {
        return;
      }
      if (other.lobby_ != null) {
        if (lobby_ == null) {
          Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
        }
        Lobby.MergeFrom(other.Lobby);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SendLobbyChatMsgRequest : pb::IMessage<SendLobbyChatMsgRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SendLobbyChatMsgRequest> _parser = new pb::MessageParser<SendLobbyChatMsgRequest>(() => new SendLobbyChatMsgRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SendLobbyChatMsgRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[33]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgRequest(SendLobbyChatMsgRequest other) : this() {
      message_ = other.message_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgRequest Clone() {
      return new SendLobbyChatMsgRequest(this);
    }

    public const int MessageFieldNumber = 1;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SendLobbyChatMsgRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SendLobbyChatMsgRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Message != other.Message) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Message.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Message.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SendLobbyChatMsgRequest other) {
      if (other == null) {
        return;
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Message = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Message = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SendLobbyChatMsgResponse : pb::IMessage<SendLobbyChatMsgResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SendLobbyChatMsgResponse> _parser = new pb::MessageParser<SendLobbyChatMsgResponse>(() => new SendLobbyChatMsgResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SendLobbyChatMsgResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[34]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgResponse(SendLobbyChatMsgResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SendLobbyChatMsgResponse Clone() {
      return new SendLobbyChatMsgResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SendLobbyChatMsgResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SendLobbyChatMsgResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SendLobbyChatMsgResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyPhotonGameRequest : pb::IMessage<SetLobbyPhotonGameRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyPhotonGameRequest> _parser = new pb::MessageParser<SetLobbyPhotonGameRequest>(() => new SetLobbyPhotonGameRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyPhotonGameRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[35]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameRequest(SetLobbyPhotonGameRequest other) : this() {
      photonGame_ = other.photonGame_ != null ? other.photonGame_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameRequest Clone() {
      return new SetLobbyPhotonGameRequest(this);
    }

    public const int PhotonGameFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyPhotonGameRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyPhotonGameRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyPhotonGameRequest other) {
      if (other == null) {
        return;
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyPhotonGameResponse : pb::IMessage<SetLobbyPhotonGameResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyPhotonGameResponse> _parser = new pb::MessageParser<SetLobbyPhotonGameResponse>(() => new SetLobbyPhotonGameResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyPhotonGameResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[36]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameResponse(SetLobbyPhotonGameResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyPhotonGameResponse Clone() {
      return new SetLobbyPhotonGameResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyPhotonGameResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyPhotonGameResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyPhotonGameResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class RefuseInvitationToLobbyRequest : pb::IMessage<RefuseInvitationToLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RefuseInvitationToLobbyRequest> _parser = new pb::MessageParser<RefuseInvitationToLobbyRequest>(() => new RefuseInvitationToLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RefuseInvitationToLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[37]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyRequest(RefuseInvitationToLobbyRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyRequest Clone() {
      return new RefuseInvitationToLobbyRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RefuseInvitationToLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RefuseInvitationToLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RefuseInvitationToLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class RefuseInvitationToLobbyResponse : pb::IMessage<RefuseInvitationToLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RefuseInvitationToLobbyResponse> _parser = new pb::MessageParser<RefuseInvitationToLobbyResponse>(() => new RefuseInvitationToLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RefuseInvitationToLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[38]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyResponse(RefuseInvitationToLobbyResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RefuseInvitationToLobbyResponse Clone() {
      return new RefuseInvitationToLobbyResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RefuseInvitationToLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RefuseInvitationToLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RefuseInvitationToLobbyResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class GetGameServerPlayersRequest : pb::IMessage<GetGameServerPlayersRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetGameServerPlayersRequest> _parser = new pb::MessageParser<GetGameServerPlayersRequest>(() => new GetGameServerPlayersRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetGameServerPlayersRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[39]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersRequest(GetGameServerPlayersRequest other) : this() {
      gameServerId_ = other.gameServerId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersRequest Clone() {
      return new GetGameServerPlayersRequest(this);
    }

    public const int GameServerIdFieldNumber = 1;
    private string gameServerId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string GameServerId {
      get { return gameServerId_; }
      set {
        gameServerId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetGameServerPlayersRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetGameServerPlayersRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (GameServerId != other.GameServerId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (GameServerId.Length != 0) hash ^= GameServerId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (GameServerId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(GameServerId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (GameServerId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(GameServerId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetGameServerPlayersRequest other) {
      if (other == null) {
        return;
      }
      if (other.GameServerId.Length != 0) {
        GameServerId = other.GameServerId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            GameServerId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetGameServerPlayersResponse : pb::IMessage<GetGameServerPlayersResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetGameServerPlayersResponse> _parser = new pb::MessageParser<GetGameServerPlayersResponse>(() => new GetGameServerPlayersResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetGameServerPlayersResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[40]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersResponse(GetGameServerPlayersResponse other) : this() {
      players_ = other.players_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetGameServerPlayersResponse Clone() {
      return new GetGameServerPlayersResponse(this);
    }

    public const int PlayersFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Player> _repeated_players_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.Player.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> players_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> Players {
      get { return players_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetGameServerPlayersResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetGameServerPlayersResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!players_.Equals(other.players_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= players_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      players_.WriteTo(output, _repeated_players_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      players_.WriteTo(ref output, _repeated_players_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += players_.CalculateSize(_repeated_players_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetGameServerPlayersResponse other) {
      if (other == null) {
        return;
      }
      players_.Add(other.players_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            players_.AddEntriesFrom(input, _repeated_players_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            players_.AddEntriesFrom(ref input, _repeated_players_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyRequest : pb::IMessage<GetLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyRequest> _parser = new pb::MessageParser<GetLobbyRequest>(() => new GetLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[41]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyRequest(GetLobbyRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyRequest Clone() {
      return new GetLobbyRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyResponse : pb::IMessage<GetLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyResponse> _parser = new pb::MessageParser<GetLobbyResponse>(() => new GetLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[42]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyResponse(GetLobbyResponse other) : this() {
      lobby_ = other.lobby_ != null ? other.lobby_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyResponse Clone() {
      return new GetLobbyResponse(this);
    }

    public const int LobbyFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Lobby lobby_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Lobby Lobby {
      get { return lobby_; }
      set {
        lobby_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Lobby, other.Lobby)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (lobby_ != null) hash ^= Lobby.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (lobby_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Lobby);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyResponse other) {
      if (other == null) {
        return;
      }
      if (other.lobby_ != null) {
        if (lobby_ == null) {
          Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
        }
        Lobby.MergeFrom(other.Lobby);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyJoinableRequest : pb::IMessage<SetLobbyJoinableRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyJoinableRequest> _parser = new pb::MessageParser<SetLobbyJoinableRequest>(() => new SetLobbyJoinableRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyJoinableRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[43]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableRequest(SetLobbyJoinableRequest other) : this() {
      joinable_ = other.joinable_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableRequest Clone() {
      return new SetLobbyJoinableRequest(this);
    }

    public const int JoinableFieldNumber = 1;
    private bool joinable_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Joinable {
      get { return joinable_; }
      set {
        joinable_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyJoinableRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyJoinableRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Joinable != other.Joinable) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Joinable != false) hash ^= Joinable.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Joinable != false) {
        output.WriteRawTag(8);
        output.WriteBool(Joinable);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Joinable != false) {
        output.WriteRawTag(8);
        output.WriteBool(Joinable);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Joinable != false) {
        size += 1 + 1;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyJoinableRequest other) {
      if (other == null) {
        return;
      }
      if (other.Joinable != false) {
        Joinable = other.Joinable;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Joinable = input.ReadBool();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Joinable = input.ReadBool();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyJoinableResponse : pb::IMessage<SetLobbyJoinableResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyJoinableResponse> _parser = new pb::MessageParser<SetLobbyJoinableResponse>(() => new SetLobbyJoinableResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyJoinableResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[44]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableResponse(SetLobbyJoinableResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyJoinableResponse Clone() {
      return new SetLobbyJoinableResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyJoinableResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyJoinableResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyJoinableResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class ChangeLobbyPlayerTypeRequest : pb::IMessage<ChangeLobbyPlayerTypeRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ChangeLobbyPlayerTypeRequest> _parser = new pb::MessageParser<ChangeLobbyPlayerTypeRequest>(() => new ChangeLobbyPlayerTypeRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ChangeLobbyPlayerTypeRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[45]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeRequest(ChangeLobbyPlayerTypeRequest other) : this() {
      playerType_ = other.playerType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeRequest Clone() {
      return new ChangeLobbyPlayerTypeRequest(this);
    }

    public const int PlayerTypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ChangeLobbyPlayerTypeRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ChangeLobbyPlayerTypeRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (PlayerType != other.PlayerType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(8);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(8);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ChangeLobbyPlayerTypeRequest other) {
      if (other == null) {
        return;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class ChangeLobbyPlayerTypeResponse : pb::IMessage<ChangeLobbyPlayerTypeResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ChangeLobbyPlayerTypeResponse> _parser = new pb::MessageParser<ChangeLobbyPlayerTypeResponse>(() => new ChangeLobbyPlayerTypeResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ChangeLobbyPlayerTypeResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[46]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeResponse(ChangeLobbyPlayerTypeResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyPlayerTypeResponse Clone() {
      return new ChangeLobbyPlayerTypeResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ChangeLobbyPlayerTypeResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ChangeLobbyPlayerTypeResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ChangeLobbyPlayerTypeResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class JoinLobbyRequest : pb::IMessage<JoinLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<JoinLobbyRequest> _parser = new pb::MessageParser<JoinLobbyRequest>(() => new JoinLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<JoinLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[47]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyRequest(JoinLobbyRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyRequest Clone() {
      return new JoinLobbyRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as JoinLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(JoinLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(JoinLobbyRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class JoinLobbyResponse : pb::IMessage<JoinLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<JoinLobbyResponse> _parser = new pb::MessageParser<JoinLobbyResponse>(() => new JoinLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<JoinLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[48]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyResponse(JoinLobbyResponse other) : this() {
      lobby_ = other.lobby_ != null ? other.lobby_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public JoinLobbyResponse Clone() {
      return new JoinLobbyResponse(this);
    }

    public const int LobbyFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Lobby lobby_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Lobby Lobby {
      get { return lobby_; }
      set {
        lobby_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as JoinLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(JoinLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Lobby, other.Lobby)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (lobby_ != null) hash ^= Lobby.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (lobby_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Lobby);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (lobby_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Lobby);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(JoinLobbyResponse other) {
      if (other == null) {
        return;
      }
      if (other.lobby_ != null) {
        if (lobby_ == null) {
          Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
        }
        Lobby.MergeFrom(other.Lobby);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (lobby_ == null) {
              Lobby = new global::Axlebolt.Bolt.Protobuf2.Lobby();
            }
            input.ReadMessage(Lobby);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyMaxSpectatorsRequest : pb::IMessage<SetLobbyMaxSpectatorsRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyMaxSpectatorsRequest> _parser = new pb::MessageParser<SetLobbyMaxSpectatorsRequest>(() => new SetLobbyMaxSpectatorsRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyMaxSpectatorsRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[49]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsRequest(SetLobbyMaxSpectatorsRequest other) : this() {
      maxSpectators_ = other.maxSpectators_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsRequest Clone() {
      return new SetLobbyMaxSpectatorsRequest(this);
    }

    public const int MaxSpectatorsFieldNumber = 1;
    private int maxSpectators_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxSpectators {
      get { return maxSpectators_; }
      set {
        maxSpectators_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyMaxSpectatorsRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyMaxSpectatorsRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (MaxSpectators != other.MaxSpectators) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (MaxSpectators != 0) hash ^= MaxSpectators.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (MaxSpectators != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxSpectators);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (MaxSpectators != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxSpectators);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (MaxSpectators != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxSpectators);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyMaxSpectatorsRequest other) {
      if (other == null) {
        return;
      }
      if (other.MaxSpectators != 0) {
        MaxSpectators = other.MaxSpectators;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            MaxSpectators = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            MaxSpectators = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyMaxSpectatorsResponse : pb::IMessage<SetLobbyMaxSpectatorsResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyMaxSpectatorsResponse> _parser = new pb::MessageParser<SetLobbyMaxSpectatorsResponse>(() => new SetLobbyMaxSpectatorsResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyMaxSpectatorsResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[50]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsResponse(SetLobbyMaxSpectatorsResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyMaxSpectatorsResponse Clone() {
      return new SetLobbyMaxSpectatorsResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyMaxSpectatorsResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyMaxSpectatorsResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyMaxSpectatorsResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class RequestLobbyListRequest : pb::IMessage<RequestLobbyListRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RequestLobbyListRequest> _parser = new pb::MessageParser<RequestLobbyListRequest>(() => new RequestLobbyListRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RequestLobbyListRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[51]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListRequest(RequestLobbyListRequest other) : this() {
      distanceFilter_ = other.distanceFilter_;
      filters_ = other.filters_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListRequest Clone() {
      return new RequestLobbyListRequest(this);
    }

    public const int DistanceFilterFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter distanceFilter_ = global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter DistanceFilter {
      get { return distanceFilter_; }
      set {
        distanceFilter_ = value;
      }
    }

    public const int FiltersFieldNumber = 2;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Filter> _repeated_filters_codec
        = pb::FieldCodec.ForMessage(18, global::Axlebolt.Bolt.Protobuf2.Filter.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter> filters_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Filter> Filters {
      get { return filters_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RequestLobbyListRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RequestLobbyListRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (DistanceFilter != other.DistanceFilter) return false;
      if(!filters_.Equals(other.filters_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (DistanceFilter != global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close) hash ^= DistanceFilter.GetHashCode();
      hash ^= filters_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (DistanceFilter != global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close) {
        output.WriteRawTag(8);
        output.WriteEnum((int) DistanceFilter);
      }
      filters_.WriteTo(output, _repeated_filters_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (DistanceFilter != global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close) {
        output.WriteRawTag(8);
        output.WriteEnum((int) DistanceFilter);
      }
      filters_.WriteTo(ref output, _repeated_filters_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (DistanceFilter != global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) DistanceFilter);
      }
      size += filters_.CalculateSize(_repeated_filters_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RequestLobbyListRequest other) {
      if (other == null) {
        return;
      }
      if (other.DistanceFilter != global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter.Close) {
        DistanceFilter = other.DistanceFilter;
      }
      filters_.Add(other.filters_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            DistanceFilter = (global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter) input.ReadEnum();
            break;
          }
          case 18: {
            filters_.AddEntriesFrom(input, _repeated_filters_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            DistanceFilter = (global::Axlebolt.Bolt.Protobuf2.LobbyDistanceFilter) input.ReadEnum();
            break;
          }
          case 18: {
            filters_.AddEntriesFrom(ref input, _repeated_filters_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class RequestLobbyListResponse : pb::IMessage<RequestLobbyListResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<RequestLobbyListResponse> _parser = new pb::MessageParser<RequestLobbyListResponse>(() => new RequestLobbyListResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<RequestLobbyListResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[52]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListResponse(RequestLobbyListResponse other) : this() {
      lobbies_ = other.lobbies_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public RequestLobbyListResponse Clone() {
      return new RequestLobbyListResponse(this);
    }

    public const int LobbiesFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Lobby> _repeated_lobbies_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.Lobby.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby> lobbies_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Lobby> Lobbies {
      get { return lobbies_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as RequestLobbyListResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(RequestLobbyListResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!lobbies_.Equals(other.lobbies_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= lobbies_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      lobbies_.WriteTo(output, _repeated_lobbies_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      lobbies_.WriteTo(ref output, _repeated_lobbies_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += lobbies_.CalculateSize(_repeated_lobbies_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(RequestLobbyListResponse other) {
      if (other == null) {
        return;
      }
      lobbies_.Add(other.lobbies_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            lobbies_.AddEntriesFrom(input, _repeated_lobbies_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            lobbies_.AddEntriesFrom(ref input, _repeated_lobbies_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyMembersRequest : pb::IMessage<GetLobbyMembersRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyMembersRequest> _parser = new pb::MessageParser<GetLobbyMembersRequest>(() => new GetLobbyMembersRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyMembersRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[53]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersRequest(GetLobbyMembersRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersRequest Clone() {
      return new GetLobbyMembersRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyMembersRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyMembersRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyMembersRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyMembersResponse : pb::IMessage<GetLobbyMembersResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyMembersResponse> _parser = new pb::MessageParser<GetLobbyMembersResponse>(() => new GetLobbyMembersResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyMembersResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[54]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersResponse(GetLobbyMembersResponse other) : this() {
      players_ = other.players_.Clone();
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyMembersResponse Clone() {
      return new GetLobbyMembersResponse(this);
    }

    public const int PlayersFieldNumber = 1;
    private static readonly pb::FieldCodec<global::Axlebolt.Bolt.Protobuf2.Player> _repeated_players_codec
        = pb::FieldCodec.ForMessage(10, global::Axlebolt.Bolt.Protobuf2.Player.Parser);
    private readonly pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> players_ = new pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player>();
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public pbc::RepeatedField<global::Axlebolt.Bolt.Protobuf2.Player> Players {
      get { return players_; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyMembersResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyMembersResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if(!players_.Equals(other.players_)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      hash ^= players_.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      players_.WriteTo(output, _repeated_players_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      players_.WriteTo(ref output, _repeated_players_codec);
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      size += players_.CalculateSize(_repeated_players_codec);
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyMembersResponse other) {
      if (other == null) {
        return;
      }
      players_.Add(other.players_);
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            players_.AddEntriesFrom(input, _repeated_players_codec);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            players_.AddEntriesFrom(ref input, _repeated_players_codec);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class ChangeLobbyOtherPlayerTypeRequest : pb::IMessage<ChangeLobbyOtherPlayerTypeRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ChangeLobbyOtherPlayerTypeRequest> _parser = new pb::MessageParser<ChangeLobbyOtherPlayerTypeRequest>(() => new ChangeLobbyOtherPlayerTypeRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ChangeLobbyOtherPlayerTypeRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[55]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeRequest(ChangeLobbyOtherPlayerTypeRequest other) : this() {
      gpid_ = other.gpid_;
      playerType_ = other.playerType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeRequest Clone() {
      return new ChangeLobbyOtherPlayerTypeRequest(this);
    }

    public const int GpidFieldNumber = 1;
    private string gpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Gpid {
      get { return gpid_; }
      set {
        gpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayerTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ChangeLobbyOtherPlayerTypeRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ChangeLobbyOtherPlayerTypeRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Gpid != other.Gpid) return false;
      if (PlayerType != other.PlayerType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Gpid.Length != 0) hash ^= Gpid.GetHashCode();
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Gpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ChangeLobbyOtherPlayerTypeRequest other) {
      if (other == null) {
        return;
      }
      if (other.Gpid.Length != 0) {
        Gpid = other.Gpid;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class ChangeLobbyOtherPlayerTypeResponse : pb::IMessage<ChangeLobbyOtherPlayerTypeResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<ChangeLobbyOtherPlayerTypeResponse> _parser = new pb::MessageParser<ChangeLobbyOtherPlayerTypeResponse>(() => new ChangeLobbyOtherPlayerTypeResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<ChangeLobbyOtherPlayerTypeResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[56]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeResponse(ChangeLobbyOtherPlayerTypeResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public ChangeLobbyOtherPlayerTypeResponse Clone() {
      return new ChangeLobbyOtherPlayerTypeResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as ChangeLobbyOtherPlayerTypeResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(ChangeLobbyOtherPlayerTypeResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(ChangeLobbyOtherPlayerTypeResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyPhotonGameRequest : pb::IMessage<GetLobbyPhotonGameRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyPhotonGameRequest> _parser = new pb::MessageParser<GetLobbyPhotonGameRequest>(() => new GetLobbyPhotonGameRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyPhotonGameRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[57]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameRequest(GetLobbyPhotonGameRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameRequest Clone() {
      return new GetLobbyPhotonGameRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyPhotonGameRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyPhotonGameRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyPhotonGameRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyPhotonGameResponse : pb::IMessage<GetLobbyPhotonGameResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyPhotonGameResponse> _parser = new pb::MessageParser<GetLobbyPhotonGameResponse>(() => new GetLobbyPhotonGameResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyPhotonGameResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[58]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameResponse(GetLobbyPhotonGameResponse other) : this() {
      photonGame_ = other.photonGame_ != null ? other.photonGame_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyPhotonGameResponse Clone() {
      return new GetLobbyPhotonGameResponse(this);
    }

    public const int PhotonGameFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyPhotonGameResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyPhotonGameResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyPhotonGameResponse other) {
      if (other == null) {
        return;
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyDataRequest : pb::IMessage<SetLobbyDataRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyDataRequest> _parser = new pb::MessageParser<SetLobbyDataRequest>(() => new SetLobbyDataRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyDataRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[59]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataRequest(SetLobbyDataRequest other) : this() {
      data_ = other.data_ != null ? other.data_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataRequest Clone() {
      return new SetLobbyDataRequest(this);
    }

    public const int DataFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Dictionary data_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Dictionary Data {
      get { return data_; }
      set {
        data_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyDataRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyDataRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Data, other.Data)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (data_ != null) hash ^= Data.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (data_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Data);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (data_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Data);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (data_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Data);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyDataRequest other) {
      if (other == null) {
        return;
      }
      if (other.data_ != null) {
        if (data_ == null) {
          Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
        }
        Data.MergeFrom(other.Data);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (data_ == null) {
              Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
            }
            input.ReadMessage(Data);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (data_ == null) {
              Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
            }
            input.ReadMessage(Data);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyDataResponse : pb::IMessage<SetLobbyDataResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyDataResponse> _parser = new pb::MessageParser<SetLobbyDataResponse>(() => new SetLobbyDataResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyDataResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[60]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataResponse(SetLobbyDataResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyDataResponse Clone() {
      return new SetLobbyDataResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyDataResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyDataResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyDataResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyOwnerRequest : pb::IMessage<GetLobbyOwnerRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyOwnerRequest> _parser = new pb::MessageParser<GetLobbyOwnerRequest>(() => new GetLobbyOwnerRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyOwnerRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[61]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerRequest(GetLobbyOwnerRequest other) : this() {
      lobbyId_ = other.lobbyId_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerRequest Clone() {
      return new GetLobbyOwnerRequest(this);
    }

    public const int LobbyIdFieldNumber = 1;
    private string lobbyId_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyId {
      get { return lobbyId_; }
      set {
        lobbyId_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyOwnerRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyOwnerRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyId != other.LobbyId) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyId.Length != 0) hash ^= LobbyId.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyId.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyId);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyId.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyId);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyOwnerRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyId.Length != 0) {
        LobbyId = other.LobbyId;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyId = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class GetLobbyOwnerResponse : pb::IMessage<GetLobbyOwnerResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<GetLobbyOwnerResponse> _parser = new pb::MessageParser<GetLobbyOwnerResponse>(() => new GetLobbyOwnerResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<GetLobbyOwnerResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[62]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerResponse(GetLobbyOwnerResponse other) : this() {
      owner_ = other.owner_ != null ? other.owner_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public GetLobbyOwnerResponse Clone() {
      return new GetLobbyOwnerResponse(this);
    }

    public const int OwnerFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Player owner_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Player Owner {
      get { return owner_; }
      set {
        owner_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as GetLobbyOwnerResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(GetLobbyOwnerResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Owner, other.Owner)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (owner_ != null) hash ^= Owner.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (owner_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Owner);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (owner_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Owner);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (owner_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Owner);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(GetLobbyOwnerResponse other) {
      if (other == null) {
        return;
      }
      if (other.owner_ != null) {
        if (owner_ == null) {
          Owner = new global::Axlebolt.Bolt.Protobuf2.Player();
        }
        Owner.MergeFrom(other.Owner);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (owner_ == null) {
              Owner = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Owner);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (owner_ == null) {
              Owner = new global::Axlebolt.Bolt.Protobuf2.Player();
            }
            input.ReadMessage(Owner);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class LeaveLobbyRequest : pb::IMessage<LeaveLobbyRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<LeaveLobbyRequest> _parser = new pb::MessageParser<LeaveLobbyRequest>(() => new LeaveLobbyRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<LeaveLobbyRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[63]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyRequest(LeaveLobbyRequest other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyRequest Clone() {
      return new LeaveLobbyRequest(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as LeaveLobbyRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(LeaveLobbyRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(LeaveLobbyRequest other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class LeaveLobbyResponse : pb::IMessage<LeaveLobbyResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<LeaveLobbyResponse> _parser = new pb::MessageParser<LeaveLobbyResponse>(() => new LeaveLobbyResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<LeaveLobbyResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[64]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyResponse(LeaveLobbyResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public LeaveLobbyResponse Clone() {
      return new LeaveLobbyResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as LeaveLobbyResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(LeaveLobbyResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(LeaveLobbyResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyTypeRequest : pb::IMessage<SetLobbyTypeRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyTypeRequest> _parser = new pb::MessageParser<SetLobbyTypeRequest>(() => new SetLobbyTypeRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyTypeRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[65]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeRequest(SetLobbyTypeRequest other) : this() {
      lobbyType_ = other.lobbyType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeRequest Clone() {
      return new SetLobbyTypeRequest(this);
    }

    public const int LobbyTypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyType lobbyType_ = global::Axlebolt.Bolt.Protobuf2.LobbyType.Private;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyType LobbyType {
      get { return lobbyType_; }
      set {
        lobbyType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyTypeRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyTypeRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyType != other.LobbyType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) hash ^= LobbyType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(8);
        output.WriteEnum((int) LobbyType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(8);
        output.WriteEnum((int) LobbyType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) LobbyType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyTypeRequest other) {
      if (other == null) {
        return;
      }
      if (other.LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        LobbyType = other.LobbyType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetLobbyTypeResponse : pb::IMessage<SetLobbyTypeResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetLobbyTypeResponse> _parser = new pb::MessageParser<SetLobbyTypeResponse>(() => new SetLobbyTypeResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetLobbyTypeResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[66]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeResponse(SetLobbyTypeResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetLobbyTypeResponse Clone() {
      return new SetLobbyTypeResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetLobbyTypeResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetLobbyTypeResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetLobbyTypeResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class SetPhotonGameRequest : pb::IMessage<SetPhotonGameRequest>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetPhotonGameRequest> _parser = new pb::MessageParser<SetPhotonGameRequest>(() => new SetPhotonGameRequest());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetPhotonGameRequest> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[67]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameRequest() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameRequest(SetPhotonGameRequest other) : this() {
      gpid_ = other.gpid_;
      photonGame_ = other.photonGame_ != null ? other.photonGame_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameRequest Clone() {
      return new SetPhotonGameRequest(this);
    }

    public const int GpidFieldNumber = 1;
    private string gpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Gpid {
      get { return gpid_; }
      set {
        gpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PhotonGameFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetPhotonGameRequest);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetPhotonGameRequest other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Gpid != other.Gpid) return false;
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Gpid.Length != 0) hash ^= Gpid.GetHashCode();
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (photonGame_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (photonGame_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Gpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Gpid);
      }
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetPhotonGameRequest other) {
      if (other == null) {
        return;
      }
      if (other.Gpid.Length != 0) {
        Gpid = other.Gpid;
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 18: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 18: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class SetPhotonGameResponse : pb::IMessage<SetPhotonGameResponse>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<SetPhotonGameResponse> _parser = new pb::MessageParser<SetPhotonGameResponse>(() => new SetPhotonGameResponse());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<SetPhotonGameResponse> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[68]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameResponse() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameResponse(SetPhotonGameResponse other) : this() {
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public SetPhotonGameResponse Clone() {
      return new SetPhotonGameResponse(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as SetPhotonGameResponse);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(SetPhotonGameResponse other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(SetPhotonGameResponse other) {
      if (other == null) {
        return;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
        }
      }
    }
    #endif

  }

  public sealed partial class OnRefuseInviteToLobbyEvent : pb::IMessage<OnRefuseInviteToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnRefuseInviteToLobbyEvent> _parser = new pb::MessageParser<OnRefuseInviteToLobbyEvent>(() => new OnRefuseInviteToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnRefuseInviteToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[69]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRefuseInviteToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRefuseInviteToLobbyEvent(OnRefuseInviteToLobbyEvent other) : this() {
      inviteSenderGpid_ = other.inviteSenderGpid_;
      invitedGpid_ = other.invitedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRefuseInviteToLobbyEvent Clone() {
      return new OnRefuseInviteToLobbyEvent(this);
    }

    public const int InviteSenderGpidFieldNumber = 1;
    private string inviteSenderGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InviteSenderGpid {
      get { return inviteSenderGpid_; }
      set {
        inviteSenderGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int InvitedGpidFieldNumber = 2;
    private string invitedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InvitedGpid {
      get { return invitedGpid_; }
      set {
        invitedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnRefuseInviteToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnRefuseInviteToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InviteSenderGpid != other.InviteSenderGpid) return false;
      if (InvitedGpid != other.InvitedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InviteSenderGpid.Length != 0) hash ^= InviteSenderGpid.GetHashCode();
      if (InvitedGpid.Length != 0) hash ^= InvitedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InviteSenderGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InvitedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnRefuseInviteToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.InviteSenderGpid.Length != 0) {
        InviteSenderGpid = other.InviteSenderGpid;
      }
      if (other.InvitedGpid.Length != 0) {
        InvitedGpid = other.InvitedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnNewSpectatorInvitedToLobbyEvent : pb::IMessage<OnNewSpectatorInvitedToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnNewSpectatorInvitedToLobbyEvent> _parser = new pb::MessageParser<OnNewSpectatorInvitedToLobbyEvent>(() => new OnNewSpectatorInvitedToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnNewSpectatorInvitedToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[70]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorInvitedToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorInvitedToLobbyEvent(OnNewSpectatorInvitedToLobbyEvent other) : this() {
      inviteSenderGpid_ = other.inviteSenderGpid_;
      newSpectator_ = other.newSpectator_ != null ? other.newSpectator_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorInvitedToLobbyEvent Clone() {
      return new OnNewSpectatorInvitedToLobbyEvent(this);
    }

    public const int InviteSenderGpidFieldNumber = 1;
    private string inviteSenderGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InviteSenderGpid {
      get { return inviteSenderGpid_; }
      set {
        inviteSenderGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NewSpectatorFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend newSpectator_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend NewSpectator {
      get { return newSpectator_; }
      set {
        newSpectator_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnNewSpectatorInvitedToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnNewSpectatorInvitedToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InviteSenderGpid != other.InviteSenderGpid) return false;
      if (!object.Equals(NewSpectator, other.NewSpectator)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InviteSenderGpid.Length != 0) hash ^= InviteSenderGpid.GetHashCode();
      if (newSpectator_ != null) hash ^= NewSpectator.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (newSpectator_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(NewSpectator);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (newSpectator_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(NewSpectator);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InviteSenderGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InviteSenderGpid);
      }
      if (newSpectator_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(NewSpectator);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnNewSpectatorInvitedToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.InviteSenderGpid.Length != 0) {
        InviteSenderGpid = other.InviteSenderGpid;
      }
      if (other.newSpectator_ != null) {
        if (newSpectator_ == null) {
          NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        NewSpectator.MergeFrom(other.NewSpectator);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            if (newSpectator_ == null) {
              NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewSpectator);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            if (newSpectator_ == null) {
              NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewSpectator);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnNewPlayerJoinedLobbyEvent : pb::IMessage<OnNewPlayerJoinedLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnNewPlayerJoinedLobbyEvent> _parser = new pb::MessageParser<OnNewPlayerJoinedLobbyEvent>(() => new OnNewPlayerJoinedLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnNewPlayerJoinedLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[71]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerJoinedLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerJoinedLobbyEvent(OnNewPlayerJoinedLobbyEvent other) : this() {
      newPlayer_ = other.newPlayer_ != null ? other.newPlayer_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerJoinedLobbyEvent Clone() {
      return new OnNewPlayerJoinedLobbyEvent(this);
    }

    public const int NewPlayerFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend newPlayer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend NewPlayer {
      get { return newPlayer_; }
      set {
        newPlayer_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnNewPlayerJoinedLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnNewPlayerJoinedLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(NewPlayer, other.NewPlayer)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (newPlayer_ != null) hash ^= NewPlayer.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (newPlayer_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(NewPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (newPlayer_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(NewPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (newPlayer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(NewPlayer);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnNewPlayerJoinedLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.newPlayer_ != null) {
        if (newPlayer_ == null) {
          NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        NewPlayer.MergeFrom(other.NewPlayer);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (newPlayer_ == null) {
              NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewPlayer);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (newPlayer_ == null) {
              NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewPlayer);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyChatMessageEvent : pb::IMessage<OnLobbyChatMessageEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyChatMessageEvent> _parser = new pb::MessageParser<OnLobbyChatMessageEvent>(() => new OnLobbyChatMessageEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyChatMessageEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[72]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyChatMessageEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyChatMessageEvent(OnLobbyChatMessageEvent other) : this() {
      gpid_ = other.gpid_;
      message_ = other.message_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyChatMessageEvent Clone() {
      return new OnLobbyChatMessageEvent(this);
    }

    public const int GpidFieldNumber = 1;
    private string gpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Gpid {
      get { return gpid_; }
      set {
        gpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int MessageFieldNumber = 2;
    private string message_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Message {
      get { return message_; }
      set {
        message_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyChatMessageEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyChatMessageEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Gpid != other.Gpid) return false;
      if (Message != other.Message) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Gpid.Length != 0) hash ^= Gpid.GetHashCode();
      if (Message.Length != 0) hash ^= Message.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (Message.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(Message);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Gpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Gpid);
      }
      if (Message.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Message);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyChatMessageEvent other) {
      if (other == null) {
        return;
      }
      if (other.Gpid.Length != 0) {
        Gpid = other.Gpid;
      }
      if (other.Message.Length != 0) {
        Message = other.Message;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 18: {
            Message = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 18: {
            Message = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnRevokeInviteToLobbyEvent : pb::IMessage<OnRevokeInviteToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnRevokeInviteToLobbyEvent> _parser = new pb::MessageParser<OnRevokeInviteToLobbyEvent>(() => new OnRevokeInviteToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnRevokeInviteToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[73]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRevokeInviteToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRevokeInviteToLobbyEvent(OnRevokeInviteToLobbyEvent other) : this() {
      inviteSenderGpid_ = other.inviteSenderGpid_;
      invitedGpid_ = other.invitedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnRevokeInviteToLobbyEvent Clone() {
      return new OnRevokeInviteToLobbyEvent(this);
    }

    public const int InviteSenderGpidFieldNumber = 1;
    private string inviteSenderGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InviteSenderGpid {
      get { return inviteSenderGpid_; }
      set {
        inviteSenderGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int InvitedGpidFieldNumber = 2;
    private string invitedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InvitedGpid {
      get { return invitedGpid_; }
      set {
        invitedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnRevokeInviteToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnRevokeInviteToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InviteSenderGpid != other.InviteSenderGpid) return false;
      if (InvitedGpid != other.InvitedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InviteSenderGpid.Length != 0) hash ^= InviteSenderGpid.GetHashCode();
      if (InvitedGpid.Length != 0) hash ^= InvitedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(InvitedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InviteSenderGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InviteSenderGpid);
      }
      if (InvitedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InvitedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnRevokeInviteToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.InviteSenderGpid.Length != 0) {
        InviteSenderGpid = other.InviteSenderGpid;
      }
      if (other.InvitedGpid.Length != 0) {
        InvitedGpid = other.InvitedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            InvitedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyPhotonGameChangedEvent : pb::IMessage<OnLobbyPhotonGameChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyPhotonGameChangedEvent> _parser = new pb::MessageParser<OnLobbyPhotonGameChangedEvent>(() => new OnLobbyPhotonGameChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyPhotonGameChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[74]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPhotonGameChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPhotonGameChangedEvent(OnLobbyPhotonGameChangedEvent other) : this() {
      photonGame_ = other.photonGame_ != null ? other.photonGame_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPhotonGameChangedEvent Clone() {
      return new OnLobbyPhotonGameChangedEvent(this);
    }

    public const int PhotonGameFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PhotonGame photonGame_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PhotonGame PhotonGame {
      get { return photonGame_; }
      set {
        photonGame_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyPhotonGameChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyPhotonGameChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(PhotonGame, other.PhotonGame)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (photonGame_ != null) hash ^= PhotonGame.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (photonGame_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(PhotonGame);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (photonGame_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(PhotonGame);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyPhotonGameChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.photonGame_ != null) {
        if (photonGame_ == null) {
          PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
        }
        PhotonGame.MergeFrom(other.PhotonGame);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (photonGame_ == null) {
              PhotonGame = new global::Axlebolt.Bolt.Protobuf2.PhotonGame();
            }
            input.ReadMessage(PhotonGame);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyMaxSpectatorsChangedEvent : pb::IMessage<OnLobbyMaxSpectatorsChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyMaxSpectatorsChangedEvent> _parser = new pb::MessageParser<OnLobbyMaxSpectatorsChangedEvent>(() => new OnLobbyMaxSpectatorsChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyMaxSpectatorsChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[75]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxSpectatorsChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxSpectatorsChangedEvent(OnLobbyMaxSpectatorsChangedEvent other) : this() {
      maxSpectators_ = other.maxSpectators_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxSpectatorsChangedEvent Clone() {
      return new OnLobbyMaxSpectatorsChangedEvent(this);
    }

    public const int MaxSpectatorsFieldNumber = 1;
    private int maxSpectators_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxSpectators {
      get { return maxSpectators_; }
      set {
        maxSpectators_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyMaxSpectatorsChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyMaxSpectatorsChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (MaxSpectators != other.MaxSpectators) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (MaxSpectators != 0) hash ^= MaxSpectators.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (MaxSpectators != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxSpectators);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (MaxSpectators != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxSpectators);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (MaxSpectators != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxSpectators);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyMaxSpectatorsChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.MaxSpectators != 0) {
        MaxSpectators = other.MaxSpectators;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            MaxSpectators = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            MaxSpectators = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnPlayerKickedFromLobbyEvent : pb::IMessage<OnPlayerKickedFromLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnPlayerKickedFromLobbyEvent> _parser = new pb::MessageParser<OnPlayerKickedFromLobbyEvent>(() => new OnPlayerKickedFromLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnPlayerKickedFromLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[76]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerKickedFromLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerKickedFromLobbyEvent(OnPlayerKickedFromLobbyEvent other) : this() {
      kickInitiatorGpid_ = other.kickInitiatorGpid_;
      kickedGpid_ = other.kickedGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerKickedFromLobbyEvent Clone() {
      return new OnPlayerKickedFromLobbyEvent(this);
    }

    public const int KickInitiatorGpidFieldNumber = 1;
    private string kickInitiatorGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string KickInitiatorGpid {
      get { return kickInitiatorGpid_; }
      set {
        kickInitiatorGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int KickedGpidFieldNumber = 2;
    private string kickedGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string KickedGpid {
      get { return kickedGpid_; }
      set {
        kickedGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnPlayerKickedFromLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnPlayerKickedFromLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (KickInitiatorGpid != other.KickInitiatorGpid) return false;
      if (KickedGpid != other.KickedGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (KickInitiatorGpid.Length != 0) hash ^= KickInitiatorGpid.GetHashCode();
      if (KickedGpid.Length != 0) hash ^= KickedGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (KickInitiatorGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickInitiatorGpid);
      }
      if (KickedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(KickedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (KickInitiatorGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(KickInitiatorGpid);
      }
      if (KickedGpid.Length != 0) {
        output.WriteRawTag(18);
        output.WriteString(KickedGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (KickInitiatorGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickInitiatorGpid);
      }
      if (KickedGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(KickedGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnPlayerKickedFromLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.KickInitiatorGpid.Length != 0) {
        KickInitiatorGpid = other.KickInitiatorGpid;
      }
      if (other.KickedGpid.Length != 0) {
        KickedGpid = other.KickedGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            KickInitiatorGpid = input.ReadString();
            break;
          }
          case 18: {
            KickedGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            KickInitiatorGpid = input.ReadString();
            break;
          }
          case 18: {
            KickedGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyPlayerTypeChangedEvent : pb::IMessage<OnLobbyPlayerTypeChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyPlayerTypeChangedEvent> _parser = new pb::MessageParser<OnLobbyPlayerTypeChangedEvent>(() => new OnLobbyPlayerTypeChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyPlayerTypeChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[77]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPlayerTypeChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPlayerTypeChangedEvent(OnLobbyPlayerTypeChangedEvent other) : this() {
      gpid_ = other.gpid_;
      playerType_ = other.playerType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyPlayerTypeChangedEvent Clone() {
      return new OnLobbyPlayerTypeChangedEvent(this);
    }

    public const int GpidFieldNumber = 1;
    private string gpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Gpid {
      get { return gpid_; }
      set {
        gpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int PlayerTypeFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType playerType_ = global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType PlayerType {
      get { return playerType_; }
      set {
        playerType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyPlayerTypeChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyPlayerTypeChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Gpid != other.Gpid) return false;
      if (PlayerType != other.PlayerType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Gpid.Length != 0) hash ^= Gpid.GetHashCode();
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) hash ^= PlayerType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Gpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        output.WriteRawTag(16);
        output.WriteEnum((int) PlayerType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Gpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Gpid);
      }
      if (PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) PlayerType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyPlayerTypeChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.Gpid.Length != 0) {
        Gpid = other.Gpid;
      }
      if (other.PlayerType != global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType.Any) {
        PlayerType = other.PlayerType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Gpid = input.ReadString();
            break;
          }
          case 16: {
            PlayerType = (global::Axlebolt.Bolt.Protobuf2.LobbyPlayerType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnNewSpectatorJoinedLobbyEvent : pb::IMessage<OnNewSpectatorJoinedLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnNewSpectatorJoinedLobbyEvent> _parser = new pb::MessageParser<OnNewSpectatorJoinedLobbyEvent>(() => new OnNewSpectatorJoinedLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnNewSpectatorJoinedLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[78]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorJoinedLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorJoinedLobbyEvent(OnNewSpectatorJoinedLobbyEvent other) : this() {
      newSpectator_ = other.newSpectator_ != null ? other.newSpectator_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewSpectatorJoinedLobbyEvent Clone() {
      return new OnNewSpectatorJoinedLobbyEvent(this);
    }

    public const int NewSpectatorFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend newSpectator_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend NewSpectator {
      get { return newSpectator_; }
      set {
        newSpectator_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnNewSpectatorJoinedLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnNewSpectatorJoinedLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(NewSpectator, other.NewSpectator)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (newSpectator_ != null) hash ^= NewSpectator.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (newSpectator_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(NewSpectator);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (newSpectator_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(NewSpectator);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (newSpectator_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(NewSpectator);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnNewSpectatorJoinedLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.newSpectator_ != null) {
        if (newSpectator_ == null) {
          NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        NewSpectator.MergeFrom(other.NewSpectator);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (newSpectator_ == null) {
              NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewSpectator);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (newSpectator_ == null) {
              NewSpectator = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewSpectator);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyNameChangedEvent : pb::IMessage<OnLobbyNameChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyNameChangedEvent> _parser = new pb::MessageParser<OnLobbyNameChangedEvent>(() => new OnLobbyNameChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyNameChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[79]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyNameChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyNameChangedEvent(OnLobbyNameChangedEvent other) : this() {
      name_ = other.name_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyNameChangedEvent Clone() {
      return new OnLobbyNameChangedEvent(this);
    }

    public const int NameFieldNumber = 1;
    private string name_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string Name {
      get { return name_; }
      set {
        name_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyNameChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyNameChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Name != other.Name) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Name.Length != 0) hash ^= Name.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Name.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(Name);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Name.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(Name);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyNameChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.Name.Length != 0) {
        Name = other.Name;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            Name = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyDataChangedEvent : pb::IMessage<OnLobbyDataChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyDataChangedEvent> _parser = new pb::MessageParser<OnLobbyDataChangedEvent>(() => new OnLobbyDataChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyDataChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[80]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyDataChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyDataChangedEvent(OnLobbyDataChangedEvent other) : this() {
      data_ = other.data_ != null ? other.data_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyDataChangedEvent Clone() {
      return new OnLobbyDataChangedEvent(this);
    }

    public const int DataFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.Dictionary data_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.Dictionary Data {
      get { return data_; }
      set {
        data_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyDataChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyDataChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Data, other.Data)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (data_ != null) hash ^= Data.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (data_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Data);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (data_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Data);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (data_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Data);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyDataChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.data_ != null) {
        if (data_ == null) {
          Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
        }
        Data.MergeFrom(other.Data);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (data_ == null) {
              Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
            }
            input.ReadMessage(Data);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (data_ == null) {
              Data = new global::Axlebolt.Bolt.Protobuf2.Dictionary();
            }
            input.ReadMessage(Data);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyGameServerChangedEvent : pb::IMessage<OnLobbyGameServerChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyGameServerChangedEvent> _parser = new pb::MessageParser<OnLobbyGameServerChangedEvent>(() => new OnLobbyGameServerChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyGameServerChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[81]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyGameServerChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyGameServerChangedEvent(OnLobbyGameServerChangedEvent other) : this() {
      gameServer_ = other.gameServer_ != null ? other.gameServer_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyGameServerChangedEvent Clone() {
      return new OnLobbyGameServerChangedEvent(this);
    }

    public const int GameServerFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.GameServer gameServer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.GameServer GameServer {
      get { return gameServer_; }
      set {
        gameServer_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyGameServerChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyGameServerChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(GameServer, other.GameServer)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (gameServer_ != null) hash ^= GameServer.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (gameServer_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (gameServer_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(GameServer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (gameServer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(GameServer);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyGameServerChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.gameServer_ != null) {
        if (gameServer_ == null) {
          GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
        }
        GameServer.MergeFrom(other.GameServer);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (gameServer_ == null) {
              GameServer = new global::Axlebolt.Bolt.Protobuf2.GameServer();
            }
            input.ReadMessage(GameServer);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnPlayerLeftLobbyEvent : pb::IMessage<OnPlayerLeftLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnPlayerLeftLobbyEvent> _parser = new pb::MessageParser<OnPlayerLeftLobbyEvent>(() => new OnPlayerLeftLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnPlayerLeftLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[82]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerLeftLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerLeftLobbyEvent(OnPlayerLeftLobbyEvent other) : this() {
      leftGpid_ = other.leftGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnPlayerLeftLobbyEvent Clone() {
      return new OnPlayerLeftLobbyEvent(this);
    }

    public const int LeftGpidFieldNumber = 1;
    private string leftGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LeftGpid {
      get { return leftGpid_; }
      set {
        leftGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnPlayerLeftLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnPlayerLeftLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LeftGpid != other.LeftGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LeftGpid.Length != 0) hash ^= LeftGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LeftGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LeftGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LeftGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LeftGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LeftGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LeftGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnPlayerLeftLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.LeftGpid.Length != 0) {
        LeftGpid = other.LeftGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LeftGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LeftGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyJoinableChangedEvent : pb::IMessage<OnLobbyJoinableChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyJoinableChangedEvent> _parser = new pb::MessageParser<OnLobbyJoinableChangedEvent>(() => new OnLobbyJoinableChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyJoinableChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[83]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyJoinableChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyJoinableChangedEvent(OnLobbyJoinableChangedEvent other) : this() {
      joinable_ = other.joinable_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyJoinableChangedEvent Clone() {
      return new OnLobbyJoinableChangedEvent(this);
    }

    public const int JoinableFieldNumber = 1;
    private bool joinable_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Joinable {
      get { return joinable_; }
      set {
        joinable_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyJoinableChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyJoinableChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (Joinable != other.Joinable) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (Joinable != false) hash ^= Joinable.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (Joinable != false) {
        output.WriteRawTag(8);
        output.WriteBool(Joinable);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (Joinable != false) {
        output.WriteRawTag(8);
        output.WriteBool(Joinable);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (Joinable != false) {
        size += 1 + 1;
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyJoinableChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.Joinable != false) {
        Joinable = other.Joinable;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            Joinable = input.ReadBool();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            Joinable = input.ReadBool();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnReceivedInviteToLobbyEvent : pb::IMessage<OnReceivedInviteToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnReceivedInviteToLobbyEvent> _parser = new pb::MessageParser<OnReceivedInviteToLobbyEvent>(() => new OnReceivedInviteToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnReceivedInviteToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[84]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedInviteToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedInviteToLobbyEvent(OnReceivedInviteToLobbyEvent other) : this() {
      invite_ = other.invite_ != null ? other.invite_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedInviteToLobbyEvent Clone() {
      return new OnReceivedInviteToLobbyEvent(this);
    }

    public const int InviteFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyInvite invite_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyInvite Invite {
      get { return invite_; }
      set {
        invite_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnReceivedInviteToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnReceivedInviteToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Invite, other.Invite)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (invite_ != null) hash ^= Invite.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (invite_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Invite);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (invite_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Invite);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (invite_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Invite);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnReceivedInviteToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.invite_ != null) {
        if (invite_ == null) {
          Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
        }
        Invite.MergeFrom(other.Invite);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (invite_ == null) {
              Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
            }
            input.ReadMessage(Invite);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (invite_ == null) {
              Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
            }
            input.ReadMessage(Invite);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyMaxMembersChangedEvent : pb::IMessage<OnLobbyMaxMembersChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyMaxMembersChangedEvent> _parser = new pb::MessageParser<OnLobbyMaxMembersChangedEvent>(() => new OnLobbyMaxMembersChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyMaxMembersChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[85]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxMembersChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxMembersChangedEvent(OnLobbyMaxMembersChangedEvent other) : this() {
      maxMembers_ = other.maxMembers_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyMaxMembersChangedEvent Clone() {
      return new OnLobbyMaxMembersChangedEvent(this);
    }

    public const int MaxMembersFieldNumber = 1;
    private int maxMembers_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int MaxMembers {
      get { return maxMembers_; }
      set {
        maxMembers_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyMaxMembersChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyMaxMembersChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (MaxMembers != other.MaxMembers) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (MaxMembers != 0) hash ^= MaxMembers.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (MaxMembers != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxMembers);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (MaxMembers != 0) {
        output.WriteRawTag(8);
        output.WriteInt32(MaxMembers);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (MaxMembers != 0) {
        size += 1 + pb::CodedOutputStream.ComputeInt32Size(MaxMembers);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyMaxMembersChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.MaxMembers != 0) {
        MaxMembers = other.MaxMembers;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            MaxMembers = input.ReadInt32();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            MaxMembers = input.ReadInt32();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyTypeChangedEvent : pb::IMessage<OnLobbyTypeChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyTypeChangedEvent> _parser = new pb::MessageParser<OnLobbyTypeChangedEvent>(() => new OnLobbyTypeChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyTypeChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[86]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyTypeChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyTypeChangedEvent(OnLobbyTypeChangedEvent other) : this() {
      lobbyType_ = other.lobbyType_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyTypeChangedEvent Clone() {
      return new OnLobbyTypeChangedEvent(this);
    }

    public const int LobbyTypeFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyType lobbyType_ = global::Axlebolt.Bolt.Protobuf2.LobbyType.Private;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyType LobbyType {
      get { return lobbyType_; }
      set {
        lobbyType_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyTypeChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyTypeChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyType != other.LobbyType) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) hash ^= LobbyType.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(8);
        output.WriteEnum((int) LobbyType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        output.WriteRawTag(8);
        output.WriteEnum((int) LobbyType);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        size += 1 + pb::CodedOutputStream.ComputeEnumSize((int) LobbyType);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyTypeChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.LobbyType != global::Axlebolt.Bolt.Protobuf2.LobbyType.Private) {
        LobbyType = other.LobbyType;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 8: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 8: {
            LobbyType = (global::Axlebolt.Bolt.Protobuf2.LobbyType) input.ReadEnum();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnNewPlayerInvitedToLobbyEvent : pb::IMessage<OnNewPlayerInvitedToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnNewPlayerInvitedToLobbyEvent> _parser = new pb::MessageParser<OnNewPlayerInvitedToLobbyEvent>(() => new OnNewPlayerInvitedToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnNewPlayerInvitedToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[87]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerInvitedToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerInvitedToLobbyEvent(OnNewPlayerInvitedToLobbyEvent other) : this() {
      inviteSenderGpid_ = other.inviteSenderGpid_;
      newPlayer_ = other.newPlayer_ != null ? other.newPlayer_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnNewPlayerInvitedToLobbyEvent Clone() {
      return new OnNewPlayerInvitedToLobbyEvent(this);
    }

    public const int InviteSenderGpidFieldNumber = 1;
    private string inviteSenderGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string InviteSenderGpid {
      get { return inviteSenderGpid_; }
      set {
        inviteSenderGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    public const int NewPlayerFieldNumber = 2;
    private global::Axlebolt.Bolt.Protobuf2.PlayerFriend newPlayer_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.PlayerFriend NewPlayer {
      get { return newPlayer_; }
      set {
        newPlayer_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnNewPlayerInvitedToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnNewPlayerInvitedToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (InviteSenderGpid != other.InviteSenderGpid) return false;
      if (!object.Equals(NewPlayer, other.NewPlayer)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (InviteSenderGpid.Length != 0) hash ^= InviteSenderGpid.GetHashCode();
      if (newPlayer_ != null) hash ^= NewPlayer.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (newPlayer_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(NewPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (InviteSenderGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(InviteSenderGpid);
      }
      if (newPlayer_ != null) {
        output.WriteRawTag(18);
        output.WriteMessage(NewPlayer);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (InviteSenderGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(InviteSenderGpid);
      }
      if (newPlayer_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(NewPlayer);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnNewPlayerInvitedToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.InviteSenderGpid.Length != 0) {
        InviteSenderGpid = other.InviteSenderGpid;
      }
      if (other.newPlayer_ != null) {
        if (newPlayer_ == null) {
          NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
        }
        NewPlayer.MergeFrom(other.NewPlayer);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            if (newPlayer_ == null) {
              NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewPlayer);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            InviteSenderGpid = input.ReadString();
            break;
          }
          case 18: {
            if (newPlayer_ == null) {
              NewPlayer = new global::Axlebolt.Bolt.Protobuf2.PlayerFriend();
            }
            input.ReadMessage(NewPlayer);
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnLobbyOwnerChangedEvent : pb::IMessage<OnLobbyOwnerChangedEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnLobbyOwnerChangedEvent> _parser = new pb::MessageParser<OnLobbyOwnerChangedEvent>(() => new OnLobbyOwnerChangedEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnLobbyOwnerChangedEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[88]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyOwnerChangedEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyOwnerChangedEvent(OnLobbyOwnerChangedEvent other) : this() {
      lobbyOwnerGpid_ = other.lobbyOwnerGpid_;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnLobbyOwnerChangedEvent Clone() {
      return new OnLobbyOwnerChangedEvent(this);
    }

    public const int LobbyOwnerGpidFieldNumber = 1;
    private string lobbyOwnerGpid_ = "";
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public string LobbyOwnerGpid {
      get { return lobbyOwnerGpid_; }
      set {
        lobbyOwnerGpid_ = pb::ProtoPreconditions.CheckNotNull(value, "value");
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnLobbyOwnerChangedEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnLobbyOwnerChangedEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (LobbyOwnerGpid != other.LobbyOwnerGpid) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (LobbyOwnerGpid.Length != 0) hash ^= LobbyOwnerGpid.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (LobbyOwnerGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyOwnerGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (LobbyOwnerGpid.Length != 0) {
        output.WriteRawTag(10);
        output.WriteString(LobbyOwnerGpid);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (LobbyOwnerGpid.Length != 0) {
        size += 1 + pb::CodedOutputStream.ComputeStringSize(LobbyOwnerGpid);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnLobbyOwnerChangedEvent other) {
      if (other == null) {
        return;
      }
      if (other.LobbyOwnerGpid.Length != 0) {
        LobbyOwnerGpid = other.LobbyOwnerGpid;
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            LobbyOwnerGpid = input.ReadString();
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            LobbyOwnerGpid = input.ReadString();
            break;
          }
        }
      }
    }
    #endif

  }

  public sealed partial class OnReceivedSpectatorInviteToLobbyEvent : pb::IMessage<OnReceivedSpectatorInviteToLobbyEvent>
  #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      , pb::IBufferMessage
  #endif
  {
    private static readonly pb::MessageParser<OnReceivedSpectatorInviteToLobbyEvent> _parser = new pb::MessageParser<OnReceivedSpectatorInviteToLobbyEvent>(() => new OnReceivedSpectatorInviteToLobbyEvent());
    private pb::UnknownFieldSet _unknownFields;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pb::MessageParser<OnReceivedSpectatorInviteToLobbyEvent> Parser { get { return _parser; } }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public static pbr::MessageDescriptor Descriptor {
      get { return global::Axlebolt.Bolt.Protobuf2.MatchmakingMessageReflection.Descriptor.MessageTypes[89]; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    pbr::MessageDescriptor pb::IMessage.Descriptor {
      get { return Descriptor; }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedSpectatorInviteToLobbyEvent() {
      OnConstruction();
    }

    partial void OnConstruction();

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedSpectatorInviteToLobbyEvent(OnReceivedSpectatorInviteToLobbyEvent other) : this() {
      invite_ = other.invite_ != null ? other.invite_.Clone() : null;
      _unknownFields = pb::UnknownFieldSet.Clone(other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public OnReceivedSpectatorInviteToLobbyEvent Clone() {
      return new OnReceivedSpectatorInviteToLobbyEvent(this);
    }

    public const int InviteFieldNumber = 1;
    private global::Axlebolt.Bolt.Protobuf2.LobbyInvite invite_;
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public global::Axlebolt.Bolt.Protobuf2.LobbyInvite Invite {
      get { return invite_; }
      set {
        invite_ = value;
      }
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override bool Equals(object other) {
      return Equals(other as OnReceivedSpectatorInviteToLobbyEvent);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public bool Equals(OnReceivedSpectatorInviteToLobbyEvent other) {
      if (ReferenceEquals(other, null)) {
        return false;
      }
      if (ReferenceEquals(other, this)) {
        return true;
      }
      if (!object.Equals(Invite, other.Invite)) return false;
      return Equals(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override int GetHashCode() {
      int hash = 1;
      if (invite_ != null) hash ^= Invite.GetHashCode();
      if (_unknownFields != null) {
        hash ^= _unknownFields.GetHashCode();
      }
      return hash;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public override string ToString() {
      return pb::JsonFormatter.ToDiagnosticString(this);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void WriteTo(pb::CodedOutputStream output) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      output.WriteRawMessage(this);
    #else
      if (invite_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Invite);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(output);
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalWriteTo(ref pb::WriteContext output) {
      if (invite_ != null) {
        output.WriteRawTag(10);
        output.WriteMessage(Invite);
      }
      if (_unknownFields != null) {
        _unknownFields.WriteTo(ref output);
      }
    }
    #endif

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public int CalculateSize() {
      int size = 0;
      if (invite_ != null) {
        size += 1 + pb::CodedOutputStream.ComputeMessageSize(Invite);
      }
      if (_unknownFields != null) {
        size += _unknownFields.CalculateSize();
      }
      return size;
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(OnReceivedSpectatorInviteToLobbyEvent other) {
      if (other == null) {
        return;
      }
      if (other.invite_ != null) {
        if (invite_ == null) {
          Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
        }
        Invite.MergeFrom(other.Invite);
      }
      _unknownFields = pb::UnknownFieldSet.MergeFrom(_unknownFields, other._unknownFields);
    }

    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    public void MergeFrom(pb::CodedInputStream input) {
    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
      input.ReadRawMessage(this);
    #else
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, input);
            break;
          case 10: {
            if (invite_ == null) {
              Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
            }
            input.ReadMessage(Invite);
            break;
          }
        }
      }
    #endif
    }

    #if !GOOGLE_PROTOBUF_REFSTRUCT_COMPATIBILITY_MODE
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute]
    void pb::IBufferMessage.InternalMergeFrom(ref pb::ParseContext input) {
      uint tag;
      while ((tag = input.ReadTag()) != 0) {
        switch(tag) {
          default:
            _unknownFields = pb::UnknownFieldSet.MergeFieldFrom(_unknownFields, ref input);
            break;
          case 10: {
            if (invite_ == null) {
              Invite = new global::Axlebolt.Bolt.Protobuf2.LobbyInvite();
            }
            input.ReadMessage(Invite);
            break;
          }
        }
      }
    }
    #endif

  }


}

