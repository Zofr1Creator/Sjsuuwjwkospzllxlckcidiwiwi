@echo off
setlocal
cd /d "%~dp0"

where dotnet >nul 2>&1
if errorlevel 1 (
    echo .NET 8 was not found.
    pause
    exit /b 1
)

if not exist "bin\Release\net8.0\TspServer.dll" (
    dotnet restore TspServer.csproj --nologo
    if errorlevel 1 goto :fail
    dotnet build TspServer.csproj -c Release --no-restore --nologo
    if errorlevel 1 goto :fail
)

dotnet "bin\Release\net8.0\TspServer.dll"
set code=%errorlevel%
if not "%code%"=="0" pause
exit /b %code%

:fail
echo Build failed.
pause
exit /b 1
