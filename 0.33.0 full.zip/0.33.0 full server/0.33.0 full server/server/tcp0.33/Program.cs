using System;
using System.IO;
using System.Net.Sockets;
using System.Threading.Tasks;
using TspServer.MongoDB;
using TspServer.RpcServer;
using TspServer.RpcServer.Api;

namespace TspServer
{
    internal static class Program
    {
        private static string _startupStage = "startup";

        public static async Task Main()
        {
            TrySetConsoleTitle();
            Console.WriteLine("TspServer");

            try
            {
                ServerOptions cfg = ServerOptions.Current;

                _startupStage = "public ip";
                string publicHost = await cfg.EnsurePublicHostAsync().ConfigureAwait(false);
                Console.WriteLine($"Public IP: {publicHost}");

                await WaitForMongoAsync(cfg).ConfigureAwait(false);

                RunStep("database init", BoltServer.InitializeDatabase);
                Console.WriteLine("Database: ready");

                _startupStage = "bolt";
                var server = new BoltServer(cfg.BoltPort);

                RunStep("background services", () =>
                {
                    if (cfg.EnablePresenceBridge)
                        PresenceBridgeServer.Start();
                    LiveBanReconciler.Start();
                    CommerceAdminServer.Start();
                    DonationBridgeServer.Start();
                });

                RunStep("manifest", ManifestServer.Start);

                Console.WriteLine($"Manifest: {cfg.PublicHost}:{cfg.ManifestPort}");
                Console.WriteLine($"Bolt: {cfg.PublicHost}:{cfg.BoltPort}");

                RunStep("content", ContentHttpServer.Start);
                Console.WriteLine("Server started.");

                WriteReadyFile(cfg);
                _startupStage = "running";
                await server.RunAsync().ConfigureAwait(false);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine($"[ERROR] {_startupStage}: {FriendlyError(ex)}");
                if (ReadBool("BOLT_STARTUP_TRACE", false))
                    Console.WriteLine(ex);
                WaitBeforeExit();
                Environment.ExitCode = 1;
            }
        }

        private static void RunStep(string stage, Action action)
        {
            _startupStage = stage;
            action();
        }

        private static async Task WaitForMongoAsync(ServerOptions cfg)
        {
            _startupStage = "mongodb";
            Console.WriteLine("MongoDB: connecting...");
            bool waitingPrinted = false;

            while (true)
            {
                try
                {
                    MongoStartup.WaitUntilReady(cfg, timeoutSeconds: 5);
                    Console.WriteLine("MongoDB: connected");
                    return;
                }
                catch (System.Exception ex)
                {
                    if (!waitingPrinted)
                    {
                        Console.WriteLine($"MongoDB: waiting ({ShortMessage(ex)})");
                        waitingPrinted = true;
                    }

                    await Task.Delay(2000).ConfigureAwait(false);
                }
            }
        }

        private static string FriendlyError(System.Exception ex)
        {
            System.Exception root = ex;
            while (root.InnerException != null)
                root = root.InnerException;

            if (root is SocketException socket && socket.SocketErrorCode == SocketError.AddressAlreadyInUse)
                return "Port is already in use. Close the other server process or change the port in config.";

            if (root is FileNotFoundException fileNotFound)
                return fileNotFound.Message;

            return $"{root.GetType().Name}: {root.Message}";
        }

        private static string ShortMessage(System.Exception ex)
        {
            System.Exception root = ex;
            while (root.InnerException != null)
                root = root.InnerException;

            string message = root.Message ?? root.GetType().Name;
            int newline = message.IndexOfAny(new[] { '\r', '\n' });
            if (newline >= 0)
                message = message[..newline];
            if (message.Length > 120)
                message = message[..120] + "...";
            return message;
        }

        private static void WaitBeforeExit()
        {
            try
            {
                if (!Console.IsInputRedirected)
                {
                    Console.WriteLine("Press any key to close...");
                    Console.ReadKey(intercept: true);
                }
            }
            catch
            {
            }
        }

        private static void TrySetConsoleTitle()
        {
            try
            {
                Console.Title = "TspServer";
            }
            catch (IOException)
            {
            }
            catch (PlatformNotSupportedException)
            {
            }
        }

        private static void WriteReadyFile(ServerOptions options)
        {
            string path = Environment.GetEnvironmentVariable("BOLT_READY_FILE") ?? string.Empty;
            if (string.IsNullOrWhiteSpace(path))
                return;

            string? directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(directory))
                Directory.CreateDirectory(directory);

            File.WriteAllText(
                path,
                $"utc={DateTime.UtcNow:O} manifest={options.ManifestPort} " +
                $"bolt={options.BoltPort} photon={options.PhotonPort} host={options.PublicHost}");
        }

        private static bool ReadBool(string key, bool fallback)
        {
            string? value = Environment.GetEnvironmentVariable(key);
            if (string.IsNullOrWhiteSpace(value))
                return fallback;

            return value.Equals("1", StringComparison.OrdinalIgnoreCase) ||
                   value.Equals("true", StringComparison.OrdinalIgnoreCase) ||
                   value.Equals("yes", StringComparison.OrdinalIgnoreCase) ||
                   value.Equals("on", StringComparison.OrdinalIgnoreCase);
        }
    }
}
