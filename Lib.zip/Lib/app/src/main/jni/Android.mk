LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := dobby
LOCAL_SRC_FILES := libraries/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)

LOCAL_MODULE    := ProjectZero

LOCAL_CFLAGS := -w -s -fvisibility=hidden -fexceptions -O2
LOCAL_CPPFLAGS := -w -s -fvisibility=hidden -std=c++17 -fexceptions -O2
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all
LOCAL_LDLIBS := -llog -landroid

LOCAL_STATIC_LIBRARIES := dobby
LOCAL_SRC_FILES := main.cpp
    
include $(BUILD_SHARED_LIBRARY)

include $(CLEAR_VARS)

LOCAL_MODULE    := MoonProject

LOCAL_CFLAGS := -w -s -fvisibility=hidden -fexceptions -O2 -DNDEBUG
LOCAL_CPPFLAGS := -w -s -fvisibility=hidden -std=c++17 -fexceptions -O2 -DNDEBUG
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all
LOCAL_LDLIBS := -llog -landroid

LOCAL_STATIC_LIBRARIES := dobby
LOCAL_SRC_FILES := moon.cpp
    
include $(BUILD_SHARED_LIBRARY)
