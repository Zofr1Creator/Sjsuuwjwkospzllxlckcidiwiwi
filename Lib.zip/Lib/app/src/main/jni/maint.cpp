#include <pthread.h>
#include <jni.h>
#include <string.h>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include "Includes/Obfuscate.h"
#include "Includes/Utils.h"
#include "Includes/Logger.h"
#include "Includes/ESP.h"
#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>
#include "Unity/Vector2.H"
#include "Unity/Vector3.h"
#include "Unity/Vector4.h"
#include "Unity/Rect.H"
#include "Unity/Color.H"
#include "Unity/Quaternion.H"
#include "Includes/bools.cpp"
#include "Unity/Unity.h"
    using namespace std;
std::string utf16le_to_utf8(const std::u16string &u16str) {
    if (u16str.empty()) { return std::string(); }
    const char16_t *p = u16str.data();
    std::u16string::size_type len = u16str.length();
    if (p[0] == 0xFEFF) {
        p += 1;
        len -= 1;
    }

    std::string u8str;
    u8str.reserve(len * 3);

    char16_t u16char;
    for (std::u16string::size_type i = 0; i < len; ++i) {

        u16char = p[i];

        if (u16char < 0x0080) {
            u8str.push_back((char) (u16char & 0x00FF));
            continue;
        }
        if (u16char >= 0x0080 && u16char <= 0x07FF) {
            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
        if (u16char >= 0xD800 && u16char <= 0xDBFF) {
            uint32_t highSur = u16char;
            uint32_t lowSur = p[++i];
            uint32_t codePoint = highSur - 0xD800;
            codePoint <<= 10;
            codePoint |= lowSur - 0xDC00;
            codePoint += 0x10000;
            u8str.push_back((char) ((codePoint >> 18) | 0xF0));
            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));
            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));
            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));
            continue;
        }
        {
            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));
            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
    }

    return u8str;
}
typedef struct _monoString {
    void *klass;
    void *monitor;
    int length;
    char chars[1];
    int getLength() {
        return length;
    }
    const char *toChars(){
        u16string ss((char16_t *) getChars(), 0, getLength());
        string str = utf16le_to_utf8(ss);
        return str.c_str();
    }
    char *getChars() {
        return chars;
    }
    std::string get_string() {

      return std::string(toChars());
}
} monoString;

monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0x1127114);

    return String_CreateString(NULL, str);
}

#include "includes/Dobby/dobby.h"


#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"
JavaVM* publicVM;
JNIEnv* publicEnv;
int  glWidth, glHeight;
#include <EGL/egl.h>
#include <GLES2/gl2.h>

uintptr_t address = 0;
#include "Includes/Config.cpp"
int num2 = 1;


int converrt(char num[]) {
   int len = strlen(num);
   int base = 1;
   int temp = 0;
   for (int i=len-1; i>=0; i--) {
      if (num[i]>='0' && num[i]<='9') {
         temp += (num[i] - 48)*base;
         base = base * 16;
      }
      else if (num[i]>='A' && num[i]<='F') {
         temp += (num[i] - 55)*base;
         base = base*16;
      }
   }
   return temp;
}
bool equals(std::string target, std::string search) {
    if (target.find(search) != std::string::npos) {
        return true;
    } else {
        return false;
    }
}
void replaceAll(std::string& str, const std::string& from, const std::string& to) {
    if(from.empty())
        return;
    size_t start_pos = 0;
    while((start_pos = str.find(from, start_pos)) != std::string::npos) {
        str.replace(start_pos, from.length(), to);
        start_pos += to.length(); 
    }
}
bool isLength(std::string from, int value) {
    if (from.length() == value) {
        return true;
    } else {
        return false;
    }
}
std::string gen_random(const int len) {
    static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);

    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    
    return tmp_s;
}

        int test = 0;






template<typename T>
void CopyTo(monoArray<T>* from, monoArray<T>* to, int count)
{
    void (*String_CreateString)(monoArray<T> *inst, monoArray<T>* to, int obj) = (void (*)(monoArray<T> *,monoArray<T>*, int))getAbsoluteAddress("libil2cpp.so", 0xF9A4A4);

    String_CreateString(from, to, count);
}
void Resize(monoArray<void **> * &array, int newsize) {
    void (*String_CreateString)(monoArray<void **> * &array, int obj) = (void (*)(monoArray<void **> * &, int))getAbsoluteAddress("libil2cpp.so", 0x154AFC4);

    String_CreateString(array, newsize);
}
template<typename T>
void SetItem(monoArray<T> *item, int index, void* object) {
    void (*String_CreateString)(monoArray<T> *instance, int index, void* obj) = (void (*)(monoArray<T> *, int, void*))getAbsoluteAddress("libil2cpp.so", 0xF99D24);

    String_CreateString(item, index, object);
}

void AddItem(void *item, void * object) {
    void (*String_CreateString)(void *instance, void * obj) = (void (*)(void *, void *))getAbsoluteAddress("libil2cpp.so", 0x189585C);

    String_CreateString(item, object);
}

void* ToBytes(void* inst,void* type)
{
    void *(*IL2CPPObject_Create)(void *klass, void* aboba) = (void *(*)(void *, void*))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x1091404")));
    void *arr = IL2CPPObject_Create(inst,type);
    return arr;
}
void* ass;
void *(*GetMsCorLib)();
void *(*Negr)(void* inst);
void *(*GetInstanceBPA)();
void* CreateInstance(void* type)
{
    void *(*IL2CPPObject_Create)(void *klass) = (void *(*)(void *))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xF945E4")));
    void *arr = IL2CPPObject_Create(type);
    return arr;
}
void* CreateInstance(void* type, monoArray<void **>* params)
{
    void *(*IL2CPPObject_Create)(void *klass, monoArray<void **>* params) = (void *(*)(void *, monoArray<void **>*))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xF945B4")));
    void *arr = IL2CPPObject_Create(type, params);
    return arr;
}
template<typename T>
monoArray<T> *CreateNativeCSharpArray(void* type,int startingLength){
    monoArray<T> *(*IL2CPPArray_Create)(void *klass, int startingLength) = (monoArray<T> *(*)(void *, int))getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xF9EC28")));
    monoArray<T> *arr = IL2CPPArray_Create(type, startingLength);
    
    return arr;
}

void *(*GetType)(void* inst,monoString* object);
void *(*GetAssembly)(void* type);
void *(*GetType1)(void* inst);
void (*old_BoltUnityApiInit)(...);
void BoltUnityApiInit() {
    LOGI("lol");
    old_BoltUnityApiInit();
    *(monoString* *) ((uint64_t) GetInstanceBPA() + 0xC) = CreateMonoString(OBFUSCATE("5.42.82.49"));
    *(monoString* *) ((uint64_t) GetInstanceBPA() + 0x8) = CreateMonoString(OBFUSCATE("5.42.82.49"));
}

void Load1(void* inst) {
    *(monoArray<void**>* *) ((uint64_t) inst + 0x1C) = CreateNativeCSharpArray<void **>(GetType(ass,CreateMonoString(OBFUSCATE("Axlebolt.Bolt.GameEvents.BoltGameEvent"))), 0);
}

void Load2(void* inst) {
    void* settings = CreateInstance(GetType(ass,CreateMonoString(OBFUSCATE("Axlebolt.Bolt.Marketplace.BoltMarketplaceSettings"))));
    *(bool *) ((uint64_t) settings + 0x8) = false;
    *(void**) ((uint64_t) inst + 0x34) = settings;
}

void Load3(void* inst) {
    void* settings = CreateInstance(GetType(ass,CreateMonoString(OBFUSCATE("Axlebolt.Bolt.Clans.BoltClanSettings"))));
    *(int *) ((uint64_t) settings + 0x8) = 10;
    *(int *) ((uint64_t) settings + 0xC) = 1000;
    *(void* *) ((uint64_t) settings + 0x10) = NULL;
    *(void* *) ((uint64_t) settings + 0x14) = NULL;
    *(void* *) ((uint64_t) settings + 0x18) = NULL;
    *(void**) ((uint64_t) inst + 0x78) = settings;
}

void LoadNULL(void* inst) {
    return;
}
void (*old_Client)(...);
void Client(void* inst, void *Assembly) {
    ass = Assembly;
    old_Client(inst,Assembly);
}
void* (*old_AER)(...);
void* AER(void* inst, void* filter, void* view, void* cc) {
    *(bool *) ((uint64_t) filter + 0x2C) = true;
    return old_AER(inst, filter, view, cc);
}

void *(*old_Connect)(...);
void *Connect(monoString *aboba, int port, monoString* AppId, monoString* gameVersion) {
    return old_Connect(aboba, port, CreateMonoString(OBFUSCATE("2a7187ca-798d-4817-b4f3-1ee23fa75256")), gameVersion);
}

void *GetRole(void* inst,int roleId) {
    void* role = CreateInstance(GetType(ass,CreateMonoString(OBFUSCATE("Axlebolt.Bolt.Clans.BoltClanMemberRole"))));
    *(int *) ((uint64_t) role + 0x8) = roleId;
    *(monoString* *) ((uint64_t) role + 0xC) = CreateMonoString((to_string(roleId)).c_str());
    *(int *) ((uint64_t) role + 0x10) = 1;
    *(monoString* *) ((uint64_t) role + 0x14) = CreateMonoString(OBFUSCATE("Skitlse Privatla"));
    *(monoArray<void**>* *) ((uint64_t) role + 0x18) = CreateNativeCSharpArray<void **>(GetType(ass,CreateMonoString(OBFUSCATE("Axlebolt.Bolt.Clans.BoltClanMemberRolePermission"))), 0);;
    return role;
}


void *cheat(void *) {
    do {
        sleep(1);
    } while (!isLibraryLoaded(OBFUSCATE("libil2cpp.so")));
    LOGI("loaded");
    Negr = (void *(*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x108CB98")));
    GetAssembly = (void *(*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x110CE50")));
    GetMsCorLib = (void *(*)()) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0xD57E20")));
    GetInstanceBPA = (void *(*)()) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x965EF0")));
    GetType = (void *(*)(void*,monoString*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x110CD40")));
    GetType1 = (void *(*)(void*)) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10F922C")));
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7CCDA4"))), (void *) Load1, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x9ABBFC"))), (void *) Load2, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7bcfa0"))), (void *) Load3, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x980e14"))), (void *) LoadNULL, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x983720"))), (void *) LoadNULL, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x985D24"))), (void *) LoadNULL, (void **) NULL);
    
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x13C90B0"))), (void *) BoltUnityApiInit, (void **) &old_BoltUnityApiInit);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7BDC9C"))), (void *) GetRole, (void **) NULL);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x10739E8"))), (void *) Client, (void **) &old_Client);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x7FF710"))), (void *) Connect, (void **) &old_Connect);
    MSHookFunction((void *) getAbsoluteAddress(OBFUSCATE("libil2cpp.so"), string2Offset(OBFUSCATE("0x63D82C"))), (void *) AER, (void **) &old_AER);
    
    
    
    return NULL;
}
__attribute__((constructor)) static void atary(){
    pthread_t ptid;
    pthread_create(&ptid, NULL, cheat, NULL);
}
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    publicVM = vm;
    publicEnv = globalEnv;
    srand((unsigned)time(NULL) * getpid());

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}