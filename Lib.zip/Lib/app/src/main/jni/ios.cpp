template<typename T>
void CopyTo(monoArray<T>* from, monoArray<T>* to, int count)
{
    void (*String_CreateString)(monoArray<T> *inst, monoArray<T>* to, int obj) = (void (*)(monoArray<T> *,monoArray<T>*, int))getRealOffset(0x23C8E70);

    String_CreateString(from, to, count);
}
void Resize(monoArray<void **> * &array, int newsize) {
    void (*String_CreateString)(monoArray<void **> * &array, int obj) = (void (*)(monoArray<void **> * &, int))getRealOffset(0x1990CAC);

    String_CreateString(array, newsize);
}
template<typename T>
void SetItem(monoArray<T> *item, int index, void* object) {
    void (*String_CreateString)(monoArray<T> *instance, int index, void* obj) = (void (*)(monoArray<T> *, int, void*))getRealOffset(0x23C88B0);

    String_CreateString(item, index, object);
}

void AddItem(void *item, void * object) {
    void (*String_CreateString)(void *instance, void * obj) = (void (*)(void *, void *))getRealOffset(0x189585C);

    String_CreateString(item, object);
}

void* ToBytes(void* inst,void* type)
{
    void *(*IL2CPPObject_Create)(void *klass, void* aboba) = (void *(*)(void *, void*))getRealOffset(ENCRYPTOFFSET("0x1091404"));
    void *arr = IL2CPPObject_Create(inst,type);
    return arr;
}
void* ass;
void *(*GetMsCorLib)();
void *(*Negr)(void* inst);
void *(*GetInstanceBPA)();
void* CreateInstance(void* type)
{
    void *(*IL2CPPObject_Create)(void *klass) = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x23C4434"));
    void *arr = IL2CPPObject_Create(type);
    return arr;
}
void* CreateInstance(void* type, monoArray<void **>* params)
{
    void *(*IL2CPPObject_Create)(void *klass, monoArray<void **>* params) = (void *(*)(void *, monoArray<void **>*))getRealOffset(ENCRYPTOFFSET("0x23C441C"));
    void *arr = IL2CPPObject_Create(type, params);
    return arr;
}
template<typename T>
monoArray<T> *CreateNativeCSharpArray(void* type,int startingLength){
    monoArray<T> *(*IL2CPPArray_Create)(void *klass, int startingLength) = (monoArray<T> *(*)(void *, int))getRealOffset(ENCRYPTOFFSET("0x23CC4D4"));
    monoArray<T> *arr = IL2CPPArray_Create(type, startingLength);
    
    return arr;
}

void *(*GetType)(void* inst,monoString* object);
void *(*GetAssembly)(void* type);
void *(*GetType1)(void* inst);
void (*old_BoltUnityApiInit)(...);
void BoltUnityApiInit() {
    old_BoltUnityApiInit();
    *(monoString* *) ((uint64_t) GetInstanceBPA() + 0x10) = CreateMonoString(ENCRYPT("5.42.82.49"));
    *(monoString* *) ((uint64_t) GetInstanceBPA() + 0x18) = CreateMonoString(ENCRYPT("5.42.82.49"));
}

void (*old_BoltPlayerApiInit)(...);
void BoltPlayerApiInit(monoString* gameId, monoString* gameVersion, int platform, monoString* isoCode) {
    
    
    old_BoltPlayerApiInit(gameId, gameVersion, platform, isoCode);
   
}
void (*old_Load1)(...);
void Load1(void* inst) {
    *(monoArray<void**>* *) ((uint64_t) inst + 0x38) = CreateNativeCSharpArray<void **>(GetType(ass,CreateMonoString(ENCRYPT("Axlebolt.Bolt.GameEvents.BoltGameEvent"))), 0);
}
void (*old_Load2)(...);
void Load2(void* inst) {
    void* settings = CreateInstance(GetType(ass,CreateMonoString(ENCRYPT("Axlebolt.Bolt.Marketplace.BoltMarketplaceSettings"))));
    *(bool *) ((uint64_t) settings + 0x10) = false;
    *(void**) ((uint64_t) inst + 0x68) = settings;
}
void (*old_Load3)(...);
void Load3(void* inst) {
    void* settings = CreateInstance(GetType(ass,CreateMonoString(ENCRYPT("Axlebolt.Bolt.Clans.BoltClanSettings"))));
    *(int *) ((uint64_t) settings + 0x10) = 10;
    *(int *) ((uint64_t) settings + 0x14) = 1000;;
    *(void**) ((uint64_t) inst + 0xF0) = settings;
}
void (*old_Load4)(...);
void Load4(void* inst) {
    
}
void (*old_Load5)(...);
void Load5(void* inst) {
    
}
void (*old_Load6)(...);
void Load6(void* inst) {
    
}
void (*old_Client)(...);
void Client(void* inst, void *Assembly) {
    ass = Assembly;
    old_Client(inst,Assembly);
}
void* (*old_AER)(...);
void* AER(void* inst, void* filter, void* view, void* cc) {
    *(bool *) ((uint64_t) filter + 0x50) = true;
    return old_AER(inst, filter, view, cc);
}

void *(*old_Connect)(...);
void *Connect(monoString *aboba, int port, monoString* AppId, monoString* gameVersion) {
    return old_Connect(aboba, port, CreateMonoString(ENCRYPT("2a7187ca-798d-4817-b4f3-1ee23fa75256")), gameVersion);
}
void *(*old_GetRole)(...);
void *GetRole(void* inst,int roleId) {
    void* role = CreateInstance(GetType(ass,CreateMonoString(ENCRYPT("Axlebolt.Bolt.Clans.BoltClanMemberRole"))));
    *(int *) ((uint64_t) role + 0x10) = roleId;
    *(monoString* *) ((uint64_t) role + 0x18) = CreateMonoString((to_string(roleId)).c_str());
    *(int *) ((uint64_t) role + 0x20) = 1;
    *(monoString* *) ((uint64_t) role + 0x28) = CreateMonoString(ENCRYPT("Skitlse Privatla"));
    *(monoArray<void**>* *) ((uint64_t) role + 0x30) = CreateNativeCSharpArray<void **>(GetType(ass,CreateMonoString(ENCRYPT("Axlebolt.Bolt.Clans.BoltClanMemberRolePermission"))), 0);;
    return role;
}
    
    Negr = (void *(*)(void*)) getRealOffset(ENCRYPTOFFSET("0x108CB98"));
    GetAssembly = (void *(*)(void*)) getRealOffset(ENCRYPTOFFSET("0x22E27E0"));
    GetMsCorLib = (void *(*)()) getRealOffset(ENCRYPTOFFSET("0x1F23AD8"));
    GetInstanceBPA = (void *(*)()) getRealOffset(ENCRYPTOFFSET("0x1793764"));
    GetType = (void *(*)(void*,monoString*)) getRealOffset(ENCRYPTOFFSET("0x22E2720"));
    GetType1 = (void *(*)(void*)) getRealOffset(ENCRYPTOFFSET("0x22D3B84"));
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17B98A0")), (void *) Load1, (void **) &old_Load1);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17C495C")), (void *) Load2, (void **) &old_Load2);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17AE6A0")), (void *) Load3, (void **) &old_Load3);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17A87F4")), (void *) Load4, (void **) &old_Load4);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17AA40C")), (void *) Load5, (void **) &old_Load5);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17AC0A0")), (void *) Load6, (void **) &old_Load6);
    
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x13F4A28")), (void *) BoltUnityApiInit, (void **) &old_BoltUnityApiInit);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x17AF048")), (void *) GetRole, (void **) &old_GetRole);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x1EE45E8")), (void *) Client, (void **) &old_Client);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x15D74D8")), (void *) Connect, (void **) &old_Connect);
    MSHookFunction((void *) getRealOffset(ENCRYPTOFFSET("0x15AD248")), (void *) AER, (void **) &old_AER);
    