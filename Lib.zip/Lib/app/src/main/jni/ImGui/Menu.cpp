#if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "imgui.h"
#ifndef IMGUI_DISABLE


#include <ctype.h>          
#include <limits.h>         
#include <math.h>           
#include <stdio.h>          
#include <stdlib.h>         
#if defined(_MSC_VER) && _MSC_VER <= 1500 
#include <stddef.h>         
#else
#include <stdint.h>         
#endif


#ifdef _MSC_VER
#pragma warning (disable: 4127)     
#pragma warning (disable: 4996)     
#pragma warning (disable: 26451)    
#endif


#if defined(__clang__)
#if __has_warning("-Wunknown-warning-option")
#pragma clang diagnostic ignored "-Wunknown-warning-option"         
#endif
#pragma clang diagnostic ignored "-Wunknown-pragmas"                
#pragma clang diagnostic ignored "-Wold-style-cast"                 
#pragma clang diagnostic ignored "-Wdeprecated-declarations"        
#pragma clang diagnostic ignored "-Wint-to-void-pointer-cast"       
#pragma clang diagnostic ignored "-Wformat-security"                
#pragma clang diagnostic ignored "-Wexit-time-destructors"          
#pragma clang diagnostic ignored "-Wunused-macros"                  
#pragma clang diagnostic ignored "-Wzero-as-null-pointer-constant"  
#pragma clang diagnostic ignored "-Wdouble-promotion"               
#pragma clang diagnostic ignored "-Wreserved-id-macro"              
#pragma clang diagnostic ignored "-Wimplicit-int-float-conversion"  
#elif defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wpragmas"                  
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"      
#pragma GCC diagnostic ignored "-Wformat-security"          
#pragma GCC diagnostic ignored "-Wdouble-promotion"         
#pragma GCC diagnostic ignored "-Wconversion"               
#pragma GCC diagnostic ignored "-Wmisleading-indentation"   
#endif


#ifdef _WIN32
#define IM_NEWLINE  "\r\n"
#else
#define IM_NEWLINE  "\n"
#endif


#if defined(_MSC_VER) && !defined(snprintf)
#define snprintf    _snprintf
#endif
#if defined(_MSC_VER) && !defined(vsnprintf)
#define vsnprintf   _vsnprintf
#endif



#ifdef _MSC_VER
#define IM_PRId64   "I64d"
#define IM_PRIu64   "I64u"
#else
#define IM_PRId64   "lld"
#define IM_PRIu64   "llu"
#endif





#define IM_MIN(A, B)            (((A) < (B)) ? (A) : (B))
#define IM_MAX(A, B)            (((A) >= (B)) ? (A) : (B))
#define IM_CLAMP(V, MN, MX)     ((V) < (MN) ? (MN) : (V) > (MX) ? (MX) : (V))


#ifndef IMGUI_CDECL
#ifdef _MSC_VER
#define IMGUI_CDECL __cdecl
#else
#define IMGUI_CDECL
#endif
#endif







static void HelpMarker(const char* desc)
{
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

void ShowMenu(bool* p_open = NULL) {
    IM_ASSERT(ImGui::GetCurrentContext() != NULL && "Missing dear imgui context. Refer to examples app!");
    
    static bool no_titlebar = false;
    static bool no_scrollbar = false;
    static bool no_menu = false;
    static bool no_move = false;
    static bool no_resize = false;
    static bool no_collapse = false;
    static bool no_close = false;
    static bool no_nav = false;
    static bool no_background = false;
    static bool no_bring_to_front = false;
    static bool unsaved_document = false;

    static int page = 1;
    
    ImGuiWindowFlags window_flags = 0;
    if (no_titlebar)        window_flags |= ImGuiWindowFlags_NoTitleBar;
    if (no_scrollbar)       window_flags |= ImGuiWindowFlags_NoScrollbar;
    if (!no_menu)           window_flags |= ImGuiWindowFlags_MenuBar;
    if (no_move)            window_flags |= ImGuiWindowFlags_NoMove;
    if (no_resize)          window_flags |= ImGuiWindowFlags_NoResize;
    if (no_collapse)        window_flags |= ImGuiWindowFlags_NoCollapse;
    if (no_nav)             window_flags |= ImGuiWindowFlags_NoNav;
    if (no_background)      window_flags |= ImGuiWindowFlags_NoBackground;
    if (no_bring_to_front)  window_flags |= ImGuiWindowFlags_NoBringToFrontOnFocus;
    if (unsaved_document)   window_flags |= ImGuiWindowFlags_UnsavedDocument;
    if (no_close)           p_open = NULL; 

    
    
    const ImGuiViewport* main_viewport = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(ImVec2(main_viewport->WorkPos.x + 650, main_viewport->WorkPos.y + 20), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(650, 480), ImGuiCond_FirstUseEver);

    
    if (!ImGui::Begin("Modded By SKITLSE", p_open, window_flags))
    {
        
        ImGui::End();
        return;
    }
    ImGui::PushItemWidth(ImGui::GetFontSize() * -12);
    
    if (ImGui::BeginMenuBar())
    {
        if (ImGui::Button("Menu"))
        {
            page = 1;
        }
        if (ImGui::Button("Misc"))
        {
            page = 2;
        }
        ImGui::EndMenuBar();
    }
    
    
    if (page == 1) {
        if (ImGui::CollapsingHeader("Test"))
        {
            static bool buyt = true;
            ImGui::Text("Norka:");
            ImGui::Checkbox("Top", &buyt);
        
         }
    } else if (page == 2) {
        if (ImGui::Button("Dark"))
        {
            ImGui::StyleColorsDark();
        }
        if (ImGui::Button("Light"))
        {
            ImGui::StyleColorsLight();
        }
        if (ImGui::Button("Classic"))
        {
            ImGui::StyleColorsClassic();
        }
    }
}
#endif