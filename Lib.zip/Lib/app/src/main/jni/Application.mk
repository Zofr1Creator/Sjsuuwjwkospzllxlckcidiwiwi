# arm64 only for Standoff 2
APP_ABI := arm64-v8a armeabi-v7a
# APP_PLATFORM := android-18 #APP_PLATFORM does not need to be set. It will automatically defaulting
APP_STL := c++_static
APP_OPTIM := release
APP_THIN_ARCHIVE := true
APP_PIE 		:= true
APP_ALLOW_MISSING_DEPS := true