#include "bools.hpp"

boools Vars;