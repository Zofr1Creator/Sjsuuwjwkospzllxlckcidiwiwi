template<typename T>
class Singleton
{
public:
  static T &instance()
  {
    if (!instance)
      instance_ = new T;
    return *instance_;
  }
private:
  static T *instance_;
};
