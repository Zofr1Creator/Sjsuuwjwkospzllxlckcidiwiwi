#include "json.hpp"

#include <fstream>
#include <experimental/filesystem>
nlohmann::json config;
class ConfigFile;
template<typename T>
void Load(T &value, std::string str);
template<typename T>
void Save(T &value, std::string str);
class ConfigFile
{
public:
ConfigFile(const std::string name, const std::string path)
{
this->name = name;
this->path = path;
}
std::string GetName() { return name; };
std::string GetPath() { return path; };
private:
std::string name, path;
};
std::vector<std::string> GetAllConfigs();
std::vector<ConfigFile> GetFolderConfigs(const std::string path, const std::string ext);
void SaveConfig(std::string path)
{
std::ofstream output_file(path);
if (!output_file.good())
return;
Save(Vars.ESPp,"esp_enable");
Save(Vars.ESPLine,"esp_line");
Save(Vars.ESPBox,"esp_box");
Save(Vars.ESPrgb,"esp_rgb");
Save(Vars.ESPCrosshair,"esp_crosahair");
Save(Vars.col1[0],"esp_red");
Save(Vars.col1[1],"esp_green");
Save(Vars.col1[2],"esp_blue");
Save(Vars.handspos,"hadsposition_enable");
Save(Vars.X1,"hadsposition_x");
Save(Vars.Y1,"hadsposition_y");
Save(Vars.Z1,"hadsposition_z");
Save(Vars.Aim,"aim_enable");
Save(Vars.AimFov,"aim_fov");
Save(Vars.ESPCircle,"aim_circle");
Save(Vars.dist,"aim_fovSize");
Save(Vars.AimDist,"aim_distance");
Save(Vars.DistRad,"aim_distance_radius");
Save(Vars.AimLine,"aim_line");
Save(Vars.legitSk,"skinchanger_enable");
Save(Vars.knifeidCT,"CTknife");
Save(Vars.knifeSkinCT,"CTskinKnife");
Save(Vars.knifeidT,"Tknife");
Save(Vars.knifeSkinT,"TskinKnife");
Save(Vars.g22skin,"g22Skin");
Save(Vars.g22,"g22");
Save(Vars.uspskin,"uspSkin");
Save(Vars.usp,"usp");
Save(Vars.p350skin,"p350Skin");
Save(Vars.p350,"p350");
Save(Vars.deagleskin,"deagleSkin");
Save(Vars.deagle,"deagle");
Save(Vars.tec9skin,"tec9Skin");
Save(Vars.tec9,"tec9");
Save(Vars.fivesevenskin,"fivesevenSkin");
Save(Vars.fiveseven,"fiveseven");
Save(Vars.ump45skin,"ump45Skin");
Save(Vars.ump45,"ump45");
Save(Vars.mp7skin,"mp7Skin");
Save(Vars.mp7,"mp7");
Save(Vars.p90skin,"p90Skin");
Save(Vars.p90,"p90");
Save(Vars.mp5skin,"mp5Skin");
Save(Vars.mp5,"mp5");
Save(Vars.m4a1skin,"m4a1Skin");
Save(Vars.m4a1,"m4a1");
Save(Vars.akrskin,"akrSkin");
Save(Vars.akr,"akr");
Save(Vars.akr12skin,"akr12Skin");
Save(Vars.akr12,"akr12");
Save(Vars.m4skin,"m4Skin");
Save(Vars.m4,"m4");
Save(Vars.m16skin,"m16Skin");
Save(Vars.m16,"m16");
Save(Vars.famasskin,"famasSkin");
Save(Vars.famas,"famas");
Save(Vars.fnfalskin,"fnfalSkin");
Save(Vars.fnfal,"fnfal");
Save(Vars.awmskin,"awmSkin");
Save(Vars.awm,"awm");
Save(Vars.m40skin,"m40Skin");
Save(Vars.m40,"m40");
Save(Vars.m110skin,"m110Skin");
Save(Vars.m110,"m110");
Save(Vars.sm1014skin,"sm1014Skin");
Save(Vars.sm1014,"sm1014");
Save(Vars.fabmskin,"fabmSkin");
Save(Vars.fabm,"fabm");
Save(Vars.m60skin,"m60Skin");
Save(Vars.m60,"m60");
Save(Vars.kinfet,"kinfet");
Save(Vars.m9tskin,"m9tskin");
Save(Vars.karambittskin,"karambittskin");
Save(Vars.jkomandotskin,"jkomandotskin");
Save(Vars.butterflytskin,"butterflytskin");
Save(Vars.fliptskin,"fliptskin");
Save(Vars.kunaitskin,"kunaitskin");
Save(Vars.scorpiontskin,"scorpiontskin");
Save(Vars.tantotskin,"tantotskin");
Save(Vars.daggertskin,"daggertskin");
Save(Vars.kinfect,"kinfect");
Save(Vars.m9ctskin,"m9ctskin");
Save(Vars.karambitctskin,"karambitctskin");
Save(Vars.jkomandoctskin,"jkomandoctskin");
Save(Vars.butterflyctskin,"butterflyctskin");
Save(Vars.flipctskin,"flipctskin");
Save(Vars.kunaictskin,"kunaictskin");
Save(Vars.scorpionctskin,"scorpionctskin");
Save(Vars.tantoctskin,"tantoctskin");
Save(Vars.daggerctskin,"daggerctskin");

output_file << std::setw(4) << config << std::endl;
output_file.close();
}

void LoadConfig(std::string path)
{
std::ifstream input_file(path);
if (!input_file.good())
return;
try
{
config << input_file;
}
catch (...)
{
input_file.close();
return;
}
Load(Vars.ESPp,"esp_enable");
Load(Vars.ESPLine,"esp_line");
Load(Vars.ESPBox,"esp_box");
Load(Vars.ESPrgb,"esp_rgb");
Load(Vars.ESPCrosshair,"esp_crosahair");
Load(Vars.col1[0],"esp_red");
Load(Vars.col1[1],"esp_green");
Load(Vars.col1[2],"esp_blue");
Load(Vars.handspos,"hadsposition_enable");
Load(Vars.X1,"hadsposition_x");
Load(Vars.Y1,"hadsposition_y");
Load(Vars.Z1,"hadsposition_z");
Load(Vars.Aim,"aim_enable");
Load(Vars.AimFov,"aim_fov");
Load(Vars.ESPCircle,"aim_circle");
Load(Vars.dist,"aim_fovSize");
Load(Vars.AimDist,"aim_distance");
Load(Vars.DistRad,"aim_distance_radius");
Load(Vars.AimLine,"aim_line");
Load(Vars.legitSk,"skinchanger_enable");
Load(Vars.knifeidCT,"CTknife");
Load(Vars.knifeSkinCT,"CTskinKnife");
Load(Vars.knifeidT,"Tknife");
Load(Vars.knifeSkinT,"TskinKnife");
Load(Vars.g22skin,"g22Skin");
Load(Vars.g22,"g22");
Load(Vars.uspskin,"uspSkin");
Load(Vars.usp,"usp");
Load(Vars.p350skin,"p350Skin");
Load(Vars.p350,"p350");
Load(Vars.deagleskin,"deagleSkin");
Load(Vars.deagle,"deagle");
Load(Vars.tec9skin,"tec9Skin");
Load(Vars.tec9,"tec9");
Load(Vars.fivesevenskin,"fivesevenSkin");
Load(Vars.fiveseven,"fiveseven");
Load(Vars.ump45skin,"ump45Skin");
Load(Vars.ump45,"ump45");
Load(Vars.mp7skin,"mp7Skin");
Load(Vars.mp7,"mp7");
Load(Vars.p90skin,"p90Skin");
Load(Vars.p90,"p90");
Load(Vars.mp5skin,"mp5Skin");
Load(Vars.mp5,"mp5");
Load(Vars.m4a1skin,"m4a1Skin");
Load(Vars.m4a1,"m4a1");
Load(Vars.akrskin,"akrSkin");
Load(Vars.akr,"akr");
Load(Vars.akr12skin,"akr12Skin");
Load(Vars.akr12,"akr12");
Load(Vars.m4skin,"m4Skin");
Load(Vars.m4,"m4");
Load(Vars.m16skin,"m16Skin");
Load(Vars.m16,"m16");
Load(Vars.famasskin,"famasSkin");
Load(Vars.famas,"famas");
Load(Vars.fnfalskin,"fnfalSkin");
Load(Vars.fnfal,"fnfal");
Load(Vars.awmskin,"awmSkin");
Load(Vars.awm,"awm");
Load(Vars.m40skin,"m40Skin");
Load(Vars.m40,"m40");
Load(Vars.m110skin,"m110Skin");
Load(Vars.m110,"m110");
Load(Vars.sm1014skin,"sm1014Skin");
Load(Vars.sm1014,"sm1014");
Load(Vars.fabmskin,"fabmSkin");
Load(Vars.fabm,"fabm");
Load(Vars.m60skin,"m60Skin");
Load(Vars.m60,"m60");
Load(Vars.kinfet,"kinfet");
Load(Vars.m9tskin,"m9tskin");
Load(Vars.karambittskin,"karambittskin");
Load(Vars.jkomandotskin,"jkomandotskin");
Load(Vars.butterflytskin,"butterflytskin");
Load(Vars.fliptskin,"fliptskin");
Load(Vars.kunaitskin,"kunaitskin");
Load(Vars.scorpiontskin,"scorpiontskin");
Load(Vars.tantotskin,"tantotskin");
Load(Vars.daggertskin,"daggertskin");
Load(Vars.kinfect,"kinfect");
Load(Vars.m9ctskin,"m9ctskin");
Load(Vars.karambitctskin,"karambitctskin");
Load(Vars.jkomandoctskin,"jkomandoctskin");
Load(Vars.butterflyctskin,"butterflyctskin");
Load(Vars.flipctskin,"flipctskin");
Load(Vars.kunaictskin,"kunaictskin");
Load(Vars.scorpionctskin,"scorpionctskin");
Load(Vars.tantoctskin,"tantoctskin");
Load(Vars.daggerctskin,"daggerctskin");


input_file.close();
}
std::vector<std::string> GetAllConfigs()
{
namespace fs = std::experimental::filesystem;
std::string fPath = "/sdcard/SkitlseCfg/";
std::vector<ConfigFile> config_files = GetFolderConfigs(fPath, ".cfg");
std::vector<std::string> config_file_names;
for (auto config = config_files.begin(); config != config_files.end(); config++)
config_file_names.emplace_back(config->GetName());
std::sort(config_file_names.begin(), config_file_names.end());
return config_file_names;
}
std::vector<ConfigFile> GetFolderConfigs(const std::string path, const std::string ext)
{
namespace fs = std::experimental::filesystem;
std::vector<ConfigFile> config_files;
if (fs::exists(path) && fs::is_directory(path))
{
for (auto it = fs::recursive_directory_iterator(path); it != fs::recursive_directory_iterator(); it++)
{
if (fs::is_regular_file(*it) && it->path().extension() == ext)
{
std::string fPath = path + it->path().filename().string();
std::string tmp_f_name = it->path().filename().string();
size_t pos = tmp_f_name.find(".");
std::string fName = (std::string::npos == pos) ? tmp_f_name : tmp_f_name.substr(0, pos);
ConfigFile new_config(fName, fPath);
config_files.emplace_back(new_config);
}
}
}
return config_files;
}
template<typename T>
void Load(T &value, std::string str)
{
if (config[str].empty())
return;
value = config[str].get<T>();
}
template<typename T>
void Save(T &value, std::string str)
{
config[str] = value;
}
void CfgInit()
{
std::string config_folder = "/sdcard/SkitlseCfg/";
}