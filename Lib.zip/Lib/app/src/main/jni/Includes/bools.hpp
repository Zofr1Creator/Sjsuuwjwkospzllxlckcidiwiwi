#pragma once
#include <string>
#include <vector>
#include <map>

class boools {
public:
       bool ESPp, ESPLine, ESPBox, Aim,AimFov, AimDist, AimLine, ESPrgb, ESPCrosshair, ESPCircle, handspos, legitSk = false;
       int boneid, crosshairS, knifeidT, knifeidCT, knifeSkinT, knifeSkinCT, g22skin, uspskin, p350skin, deagleskin, tec9skin, fivesevenskin, ump45skin, mp7skin, p90skin, mp5skin,m4a1skin, akrskin,akr12skin, m4skin,m16skin,famasskin,fnfalskin,awmskin,m40skin,m110skin,sm1014skin,fabmskin,m60skin;
       float circleS, X1, Y1, Z1, upval, upval2,dist,DistRad;
       float col1[3] = { 1.0f, 0.0f, 0.0f };
       std::string Hwid;
       bool spoof;
       bool head, neck, hip = false;
       int g22,usp,p350,deagle,tec9,fiveseven,ump45,mp7,p90,mp5,m4a1,akr,akr12,m4,m16,famas,fnfal,awm,m40,m110,sm1014,fabm,m60,kinfet,kinfect,m9tskin,karambittskin,jkomandotskin,butterflytskin,fliptskin,kunaitskin,scorpiontskin,tantotskin,daggertskin,m9ctskin,karambitctskin,jkomandoctskin,butterflyctskin,flipctskin,kunaictskin,scorpionctskin,tantoctskin,daggerctskin = 0;
};
extern boools Vars;

