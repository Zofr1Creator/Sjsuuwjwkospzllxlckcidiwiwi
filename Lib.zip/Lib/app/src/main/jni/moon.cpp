// Libka0.22 — backup before crash fix attempts
// SSL bypass + host redirect + key exchange bypass (working state before reconnect crash)

#include <pthread.h>
#include <jni.h>
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <android/log.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ptrace.h>
#include <cstdlib>
#include <cstdio>
#include <cstdarg>
#include <vector>
#include "Includes/Dobby/dobby.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "MoonProject", __VA_ARGS__)




static volatile bool g_security_ok = true;
static pthread_mutex_t g_security_mutex = PTHREAD_MUTEX_INITIALIZER;

__attribute__((always_inline))
static inline void secure_exit() {
    pthread_mutex_lock(&g_security_mutex);
    g_security_ok = false;
    pthread_mutex_unlock(&g_security_mutex);
    LOG("SECURITY VIOLATION: Terminating process.");
    kill(getpid(), SIGKILL);
    _exit(0);
}




static bool is_whitelisted_lib(const char* path) {
    static const char* whitelist[] = {
        "libil2cpp.so", "libunity.so", "libmain.so", "libc.so", "libm.so",
        "liblog.so", "libdl.so", "libz.so", "libstdc++.so", "libc++.so",
        "libc++_shared.so", "libGLESv2.so", "libGLESv3.so", "libEGL.so",
        "libvulkan.so", "libandroid.so", "libOpenSLES.so", "linker", "linker64",
        "libProjectZero.so", "libnative.so", "libswappy.so", "libswappyVk.so",
        "libFirebaseCppAnalytics.so", "libFirebaseCppApp-6.0.0.so",
        "libFirebaseCppMessaging.so", "libfmod.so", "libfmodL.so",
        "libfmodstudio.so", "libfmodstudioL.so", "libnative-googlesignin.so",
        "/system/", "/vendor/", "/apex/", nullptr
    };
    for (int i = 0; whitelist[i] != nullptr; i++) {
        if (strstr(path, whitelist[i]) != nullptr) return true;
    }
    return false;
}

static bool is_suspicious_path(const char* path) {
    if (strstr(path, "com.nevergames.standnever") != nullptr) return false;
    static const char* suspicious[] = {
        "/data/data/", "/data/local/tmp/", "/sdcard/", "/storage/",
        "frida", "xposed", "substrate", "gg", "gameguardian", "cheat",
        "hack", "mod", "inject", "hook", nullptr
    };
    for (int i = 0; suspicious[i] != nullptr; i++) {
        if (strcasestr(path, suspicious[i]) != nullptr) return true;
    }
    return false;
}

static void scan_loaded_libraries() {
    char line[512];
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, ".so") == nullptr) continue;
        if (strstr(line, "r-x") == nullptr && strstr(line, "r--") == nullptr) continue;
        char* path = strchr(line, '/');
        if (!path) continue;
        char* newline = strchr(path, '\n');
        if (newline) *newline = '\0';
        if (!is_whitelisted_lib(path) && is_suspicious_path(path)) {
            LOG("THREAT DETECTED: Illegal library loaded: %s", path);
            fclose(fp);
            secure_exit();
            return;
        }
    }
    fclose(fp);
}




static bool check_function_hooked(void* func_addr) {
    if (!func_addr) return false;
    unsigned char* bytes = (unsigned char*)func_addr;
    if (bytes[0] == 0x50 && bytes[1] == 0x00 && bytes[2] == 0x00 && bytes[3] == 0x58) return true;
    if (bytes[0] == 0x51 && bytes[1] == 0x00 && bytes[2] == 0x00 && bytes[3] == 0x58) return true;
    if ((bytes[3] & 0xFC) == 0x14) return true;
    if ((bytes[3] & 0xFC) == 0x94) return true;
    if (bytes[0] == 0x04 && bytes[1] == 0xF0 && bytes[2] == 0x1F && bytes[3] == 0xE5) return true;
    if ((bytes[3] & 0x0F) == 0x0A) return true;
    if ((bytes[3] & 0x0F) == 0x0B) return true;
    return false;
}

static int open_wrapper(const char* path, int flags, ...) {
    va_list args;
    va_start(args, flags);
    mode_t mode = va_arg(args, mode_t);
    va_end(args);
    return open(path, flags, mode);
}

static void verify_critical_functions() {
    void* funcs[] = {
        (void*)dlopen,
        (void*)dlsym,
        (void*)mmap,
        (void*)mprotect,
        (void*)open_wrapper,
        (void*)read,
        (void*)ptrace,
        nullptr
    };
    for (int i = 0; funcs[i] != nullptr; i++) {
        if (check_function_hooked(funcs[i])) { secure_exit(); return; }
    }
}




static void scan_for_cheat_tools() {
    char line[512];
    FILE* fp = fopen("/proc/self/maps", "r");
    if (fp) {
        while (fgets(line, sizeof(line), fp)) {
            if (strcasestr(line, "GameGuardian") || strcasestr(line, "gg.android") || strcasestr(line, "frida")) {
                fclose(fp); secure_exit(); return;
            }
        }
        fclose(fp);
    }
    DIR* dir = opendir("/proc");
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            if (entry->d_type != DT_DIR) continue;
            char cmdline_path[256];
            snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%s/cmdline", entry->d_name);
            FILE* fpc = fopen(cmdline_path, "r");
            if (fpc) {
                char cmdline[256] = {0};
                fread(cmdline, 1, sizeof(cmdline) - 1, fpc);
                fclose(fpc);
                if (strcasestr(cmdline, "gameguardian") || strcasestr(cmdline, "frida-server")) {
                    closedir(dir); secure_exit(); return;
                }
            }
        }
        closedir(dir);
    }
}




typedef void* monoString;
static void* (*il2cpp_string_new)(const char*) = nullptr;

uintptr_t get_lib_base(const char* lib_name) {
    char line[512];
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, lib_name)) {
            uintptr_t base = (uintptr_t)strtoull(line, NULL, 16);
            fclose(fp);
            return base;
        }
    }
    fclose(fp);
    return 0;
}

static void* make_string(const char* s) {
    if (il2cpp_string_new) return il2cpp_string_new(s);
    return nullptr;
}

// CKOFFFHGGOC — Connect(string host, int port) — RVA: 0x2F56C34
void (*orig_Connect)(void*, monoString, int);
void hook_Connect(void* self, monoString host, int port) {
    void* newHost = make_string("144.31.157.245");
    LOG("hook_Connect: redirecting to custom API");
    orig_Connect(self, newHost ? newHost : host, port);
}

// OKMBLDNLPBF(ConnectionConfig) — RVA: 0x2F56C5C
// offset 0x10 = Host (string), offset 0x28 = UseSSL (bool)
void* (*orig_ConnectConfig)(void*, void*);
void* hook_ConnectConfig(void* self, void* config) {
    if (config) {
        *(bool*)((uintptr_t)config + 0x28) = false;
        void* newHost = make_string("144.31.157.245");
        if (newHost) {
            *(void**)((uintptr_t)config + 0x10) = newHost;
            LOG("hook_ConnectConfig: host redirected, SSL disabled");
        } else {
            LOG("hook_ConnectConfig: SSL disabled (host unchanged - string_new not ready)");
        }
    }
    return orig_ConnectConfig(self, config);
}

// BDPBABAHNLL — ExchangeKeysAsync — RVA: 0x2F585D8
void (*orig_KeyExchange)(void*, void*);
void hook_KeyExchange(void* self, void* ct) {
    LOG("Key exchange bypassed");
}




void* security_thread(void*) {
    sleep(10);
    while (g_security_ok) {
        scan_loaded_libraries();
        verify_critical_functions();
        scan_for_cheat_tools();
        sleep(5);
    }
    return nullptr;
}

void* moon_thread(void*) {
    LOG("MoonProject thread started");
    uintptr_t base = 0;
    for (int i = 0; i < 30 && !base; i++) {
        base = get_lib_base("libil2cpp.so");
        if (!base) sleep(1);
    }
    if (!base) { LOG("Failed to find libil2cpp.so base"); return nullptr; }
    void* handle = dlopen("libil2cpp.so", RTLD_NOW);
    if (handle) {
        il2cpp_string_new = (void* (*)(const char*))dlsym(handle, "il2cpp_string_new");
    }

    // ConnectAsync(string host, int port)
    DobbyHook((void*)(base + 0x2F56C34), (void*)hook_Connect, (void**)&orig_Connect);

    // ConnectWithConfigAsync(ConnectionConfig) — SSL bypass + host redirect
    DobbyHook((void*)(base + 0x2F56C5C), (void*)hook_ConnectConfig, (void**)&orig_ConnectConfig);

    // ExchangeKeysAsync — bypass
    DobbyHook((void*)(base + 0x2F585D8), (void*)hook_KeyExchange, (void**)&orig_KeyExchange);

    LOG("MoonProject hooks applied successfully");
    return nullptr;
}

__attribute__((constructor)) void lib_moon_main() {
    pthread_t t1, t2;
    pthread_create(&t1, nullptr, moon_thread, nullptr);
    pthread_detach(t1);
    pthread_create(&t2, nullptr, security_thread, nullptr);
    pthread_detach(t2);
}

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) { return JNI_VERSION_1_6; }
