using Axlebolt.Bolt.Chat;
using Axlebolt.Bolt.Friends;
using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Chat.Mappers
{
    public class ChatMessageMapper : MessageMapper<UserMessage, BoltChatMessage>
    {
        public static readonly ChatMessageMapper Instance = new ChatMessageMapper();

        public override BoltChatMessage ToOriginal(UserMessage proto)
        {
            return new BoltChatMessage
            {
                Message = proto.Message,
                Timestamp = proto.Timestamp,
                IsRead = proto.IsRead
            };
        }

        public BoltChatMessage ToOriginal(UserMessage proto, BoltFriend existingFriend)
        {
            return new BoltChatMessage
            {
                Sender = existingFriend,
                Message = proto.Message,
                Timestamp = proto.Timestamp,
                IsRead = proto.IsRead
            };
        }
    }
}