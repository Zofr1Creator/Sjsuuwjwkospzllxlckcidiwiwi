using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Friends;
using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Chat.Events;
using Axlebolt.Bolt.Chat.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Avatar;

namespace Axlebolt.Bolt.Chat
{
	public class BoltChatService : BoltService<BoltChatService>
	{
		public class FriendsEventListener : IFriendsRemoteEventListener
		{
			private readonly BoltChatService _service;

			public FriendsEventListener(BoltChatService service)
			{
				_service = service;
			}

			public void OnFriendNameChanged(string friendId, string newName)
			{
				if (_service._chats.ContainsKey(friendId))
				{
					BoltChat boltChat = _service._chats[friendId];
					boltChat.Friend.Name = newName;
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnNewFriendshipRequest(PlayerFriend playerFriend)
			{
				if (_service._chats.ContainsKey(playerFriend.Player.Id))
				{
					BoltChat boltChat = _service._chats[playerFriend.Player.Id];
					Axlebolt.Bolt.Friends.RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, Axlebolt.Bolt.Friends.RelationshipStatus>.ToOriginal(playerFriend.RelationshipStatus);
					boltChat.Friend.Relationship = relationship;
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnRevokeFriendshipRequest(string friendId)
			{
				if (_service._chats.ContainsKey(friendId))
				{
					BoltChat boltChat = _service._chats[friendId];
					boltChat.Friend.Relationship = Axlebolt.Bolt.Friends.RelationshipStatus.None;
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnPlayerStatusChanged(string friendId, Axlebolt.Bolt.Protobuf.PlayerStatus newStatus)
			{
				if (_service._chats.ContainsKey(friendId))
				{
					BoltChat boltChat = _service._chats[friendId];
					boltChat.Friend.PlayerStatus = PlayerStatusMapper.Instance.ToOriginal(newStatus);
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnFriendAdded(PlayerFriend playerFriend)
			{
				if (_service._chats.ContainsKey(playerFriend.Player.Id))
				{
					BoltChat boltChat = _service._chats[playerFriend.Player.Id];
					Axlebolt.Bolt.Friends.RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, Axlebolt.Bolt.Friends.RelationshipStatus>.ToOriginal(playerFriend.RelationshipStatus);
					boltChat.Friend.Relationship = relationship;
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnFriendRemoved(string friendId)
			{
				if (_service._chats.ContainsKey(friendId))
				{
					BoltChat boltChat = _service._chats[friendId];
					boltChat.Friend.Relationship = Axlebolt.Bolt.Friends.RelationshipStatus.None;
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnFriendAvatarChanged(string friendId, string avatarId)
			{
				if (_service._chats.ContainsKey(friendId))
				{
					BoltChat boltChat = _service._chats[friendId];
					//boltChat.Friend.AvatarId = avatarId;
					boltChat.Friend.Avatar = BoltAvatar.Create(avatarId, null);
					_service.ChatMemberUpdatedEvent.Invoke(new ChatEventArgs(boltChat));
				}
			}

			public void OnPlayerAttributesChanged(OnPlayerAttributesChanged arg)
			{
			}
		}

		public class MessagesEventListener : IMessagesRemoteEventListener
		{
			private readonly BoltChatService _service;

			public MessagesEventListener(BoltChatService service)
			{
				_service = service;
			}

			public void OnMsgFromFriend(UserMessage userMessage)
			{
				if (!_service._chats.ContainsKey(userMessage.SenderId))
				{
					PlayerFriend playerFriend = _service._friendsRemoteService.GetPlayerFriend(userMessage.SenderId);
					BoltFriend friend = FriendMapper.Instance.ToOriginal(playerFriend);
					BoltChat boltChat = new BoltChat(friend, userMessage.Message, userMessage.Timestamp, 1);
					_service._chats.TryAdd(userMessage.SenderId, boltChat);
					_service.IncrementUnreadChatsCount();
					_service.ChatAddedEvent.Invoke(new ChatEventArgs(boltChat));
				}
				else
				{
					BoltChat boltChat2 = _service._chats[userMessage.SenderId];
					if (boltChat2.UnreadMsgsCount == 0)
					{
						_service.IncrementUnreadChatsCount();
					}
					boltChat2.Message = userMessage.Message;
					boltChat2.Timestamp = userMessage.Timestamp;
					boltChat2.UnreadMsgsCount++;
					_service.ChatUpdatedEvent.Invoke(new ChatEventArgs(boltChat2));
				}
				BoltChat boltChat3 = _service._chats[userMessage.SenderId];
				BoltChatMessage userMessage2 = ChatMessageMapper.Instance.ToOriginal(userMessage, boltChat3.Friend);
                IncomingChatMsgEventArgs arg = new IncomingChatMsgEventArgs(userMessage2);
				_service.MessageFromFriendEvent.Invoke(arg);
			}
		}

		private const string GlobalChatTopic = "global_chat_";

		private readonly ChatRemoteService _chatRemoteService;

		private readonly FriendsRemoteService _friendsRemoteService;

		private readonly ConcurrentDictionary<string, BoltChat> _chats;

		private readonly FriendsEventListener _remoteFriendsEventListener;

		private readonly MessagesEventListener _remoteMessagesEventListener;

		public readonly BoltEvent<IncomingChatMsgEventArgs> MessageFromFriendEvent = new BoltEvent<IncomingChatMsgEventArgs>();

		public readonly BoltEvent<ChatEventArgs> ChatUpdatedEvent = new BoltEvent<ChatEventArgs>();

		public readonly BoltEvent<ChatEventArgs> ChatMemberUpdatedEvent = new BoltEvent<ChatEventArgs>();

		public readonly BoltEvent<UnreadChatsCountChangedEventArgs> UnreadChatsCountChangedEvent = new BoltEvent<UnreadChatsCountChangedEventArgs>();

		public readonly BoltEvent<ChatEventArgs> ChatAddedEvent = new BoltEvent<ChatEventArgs>();

		private int _unreadChats;

		public int GetUnreaChatsCount()
		{
			return _unreadChats;
		}

		public BoltChat GetFriendChat(string friendId)
		{
			_chats.TryGetValue(friendId, out var value);
			return value;
		}

		public BoltChatService()
		{
			_chatRemoteService = new ChatRemoteService(BoltPlayerApi.Instance.ClientService);
			_friendsRemoteService = new FriendsRemoteService(BoltPlayerApi.Instance.ClientService);
			_chats = new ConcurrentDictionary<string, BoltChat>();
			_remoteFriendsEventListener = new FriendsEventListener(this);
			_remoteMessagesEventListener = new MessagesEventListener(this);
		}

		public List<BoltChat> GetChats()
		{
			return _chats.Values.OrderByDescending((BoltChat chat) => chat.Timestamp).ToList();
		}

		internal override void BindEvents()
		{
			BoltPlayerApi.Instance.AddEventListener(_remoteFriendsEventListener);
			BoltPlayerApi.Instance.AddEventListener(_remoteMessagesEventListener);
		}

		internal override void UnbindEvents()
		{
			BoltPlayerApi.Instance.RemoveEventListener(_remoteFriendsEventListener);
			BoltPlayerApi.Instance.RemoveEventListener(_remoteMessagesEventListener);
		}

		public Task DeleteFriendMsgs(string friendId)
		{
			if (friendId == null)
			{
				throw new ArgumentNullException("friendId");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				_chatRemoteService.DeleteFriendMsgs(friendId);
				_chats.TryRemove(friendId, out var _);
			});
		}

		public Task ReadFriendMsgs(string friendId)
		{
			if (friendId == null)
			{
				throw new ArgumentNullException("friendId");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				if (_chats.ContainsKey(friendId))
				{
					_chatRemoteService.ReadFriendMsgs(friendId);
					DecrementUnreadChatsCount();
					_chats[friendId].UnreadMsgsCount = 0;
					ChatUpdatedEvent.Invoke(new ChatEventArgs(_chats[friendId]));
				}
			});
		}

		public Task<BoltChatMessage[]> GetFriendMsgs(string friendId, int offset, int length)
		{
			if (friendId == null)
			{
				throw new ArgumentNullException("friendId");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Offset offset2 = new Offset
				{
					Offset_ = offset,
					Length = length
				};
				UserMessage[] friendMsgs = _chatRemoteService.GetFriendMsgs(friendId, offset2);
				return friendMsgs.Select((UserMessage message) => message.SenderId.Equals(BoltService<BoltPlayerService>.Instance.Player.Id) ? ChatMessageMapper.Instance.ToOriginal(message) : ChatMessageMapper.Instance.ToOriginal(message, _chats[message.SenderId].Friend)).ToArray();
			});
		}

		public Task<BoltChatMessage> SendFriendMsg(string friendId, string msg)
		{
			if (friendId == null)
			{
				throw new ArgumentNullException("friendId");
			}
			if (msg == null)
			{
				throw new ArgumentNullException("msg");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				_chatRemoteService.SendFriendMsg(friendId, msg);
				if (!_chats.ContainsKey(friendId))
				{
					PlayerFriend playerFriend = _friendsRemoteService.GetPlayerFriend(friendId);
					BoltFriend friend = FriendMapper.Instance.ToOriginal(playerFriend);
					BoltChat boltChat = new BoltChat(friend, msg, GetCurrentTimeMillis(), 0);
					_chats.TryAdd(friendId, boltChat);
					ChatAddedEvent.Invoke(new ChatEventArgs(boltChat));
					return new BoltChatMessage
					{
						Message = msg,
						Timestamp = boltChat.Timestamp,
						IsRead = false
					};
				}
				BoltChat boltChat2 = _chats[friendId];
				boltChat2.Message = msg;
				boltChat2.Timestamp = GetCurrentTimeMillis();
				ChatUpdatedEvent.Invoke(new ChatEventArgs(boltChat2));
				return new BoltChatMessage
				{
					Message = msg,
					Timestamp = boltChat2.Timestamp,
					IsRead = false
				};
			});
		}

		internal override void Load()
		{
			IEnumerable<ChatUser> enumerable = LoadChats();
			_chats.Clear();
			foreach (ChatUser item in enumerable)
			{
				if (item.Group == null)
				{
					BoltChat boltChat = ChatMapper.Instance.ToOriginal(item, isGroup: false);
					_chats.TryAdd(boltChat.Friend.Id, boltChat);
				}
				else
				{
					BoltChat boltChat2 = ChatMapper.Instance.ToOriginal(item, isGroup: true);
					_chats.TryAdd(boltChat2.Group.Id, boltChat2);
				}
			}
		}

		private IEnumerable<ChatUser> LoadChats()
		{
			_unreadChats = _chatRemoteService.GetUnreadChatUsersCount();
			return _chatRemoteService.GetChatUsers();
		}

		private void IncrementUnreadChatsCount()
		{
			_unreadChats++;
			UnreadChatsCountChangedEventArgs arg = new UnreadChatsCountChangedEventArgs(_unreadChats);
			UnreadChatsCountChangedEvent.Invoke(arg);
		}

		private void DecrementUnreadChatsCount()
		{
			_unreadChats--;
			UnreadChatsCountChangedEventArgs arg = new UnreadChatsCountChangedEventArgs(_unreadChats);
			UnreadChatsCountChangedEvent.Invoke(arg);
		}

		private static long GetCurrentTimeMillis()
		{
			return (long)DateTime.Now.ToUniversalTime().Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
		}
	}
}
