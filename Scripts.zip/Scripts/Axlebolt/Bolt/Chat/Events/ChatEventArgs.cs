using Axlebolt.Bolt.Chat;
using System;

namespace Axlebolt.Bolt.Chat.Events
{
    public class ChatEventArgs
    {
        public ChatEventArgs(BoltChat chat)
        {
            BoltChat = chat;
        }

        public BoltChat BoltChat { get; }
    }
}
