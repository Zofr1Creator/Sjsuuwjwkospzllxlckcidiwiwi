using Axlebolt.Bolt.Clans;
using Axlebolt.Bolt.Chat;

namespace Axlebolt.Bolt.Chat.Events
{
    public class IncomingChatMsgEventArgs
    {
        public IncomingChatMsgEventArgs(BoltChatMessage chatMessage)
        {
            ChatMessage = chatMessage;
        }

        public BoltChatMessage ChatMessage { get; }
    }
}