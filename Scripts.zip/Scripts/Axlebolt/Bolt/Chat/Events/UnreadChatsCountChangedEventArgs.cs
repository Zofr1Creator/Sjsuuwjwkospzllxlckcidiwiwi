namespace Axlebolt.Bolt.Chat.Events
{
	public class UnreadChatsCountChangedEventArgs
	{
		public int UnreadChatsCount { get; }

		public UnreadChatsCountChangedEventArgs(int count)
		{
			UnreadChatsCount = count;
		}
	}
}
