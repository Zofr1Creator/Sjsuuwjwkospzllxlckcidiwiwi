using System;
using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Chat
{
	public class BoltChat
	{
		public BoltFriend Friend { get; }

		public BoltGroup Group { get; }

		public bool IsGroup { get; }

		public string Message { get; internal set; }

		public long Timestamp { get; internal set; }

		public int UnreadMsgsCount { get; internal set; }

		public BoltChat(BoltFriend friend, string message, long timestamp, int unreadMsgsCount)
		{
			if (friend == null)
			{
				throw new ArgumentNullException();
			}
			Friend = friend;
			IsGroup = false;
			Message = message;
			Timestamp = timestamp;
			UnreadMsgsCount = unreadMsgsCount;
		}

		public BoltChat(BoltGroup group, string message, long timesTamp, int unreadMsgsCount)
		{
			if (group == null)
			{
				throw new ArgumentNullException();
			}
			Group = group;
			IsGroup = true;
			Message = message;
			Timestamp = timesTamp;
			UnreadMsgsCount = unreadMsgsCount;
		}
	}
}
