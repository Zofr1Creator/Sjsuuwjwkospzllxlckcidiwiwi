using System;

namespace Axlebolt.Bolt.Chat.Exceptions
{
    public class ServiceIsBusyException : Exception
    {
        public ServiceIsBusyException() : base("The service is currently busy. Please try again later.")
        {
        }

        public ServiceIsBusyException(string message) : base(message)
        {
        }

        public ServiceIsBusyException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}