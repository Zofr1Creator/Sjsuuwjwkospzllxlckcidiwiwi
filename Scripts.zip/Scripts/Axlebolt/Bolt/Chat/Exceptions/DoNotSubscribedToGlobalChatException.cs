using System;

namespace Axlebolt.Bolt.Chat.Exceptions
{
    public class DoNotSubscribedToGlobalChatException : Exception
    {
    }
}
