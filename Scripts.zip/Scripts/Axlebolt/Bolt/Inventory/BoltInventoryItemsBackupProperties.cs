using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemsBackupProperties
	{
		public Dictionary<string, BoltInventoryItemProperty> Properties;

		public int ItemId { get; set; }
	}
}
