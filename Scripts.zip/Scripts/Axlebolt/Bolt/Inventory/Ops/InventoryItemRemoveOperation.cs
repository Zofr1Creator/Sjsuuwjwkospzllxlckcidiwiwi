namespace Axlebolt.Bolt.Inventory.Ops
{
	public class InventoryItemRemoveOperation : Operation
	{
		public int InventoryItemId { get; }

		public InventoryItemRemoveOperation(int inventoryItemId)
		{
			InventoryItemId = inventoryItemId;
		}
	}
}
