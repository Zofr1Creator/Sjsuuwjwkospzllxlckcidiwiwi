namespace Axlebolt.Bolt.Inventory.Ops
{
	public abstract class Operation
	{
	}
}
