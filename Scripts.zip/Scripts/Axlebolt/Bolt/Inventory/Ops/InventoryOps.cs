using System;
using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory.Ops
{
	internal class InventoryOps
	{
		private readonly BoltInventoryService _service;

		private readonly List<Operation> _operations = new List<Operation>();

		internal InventoryOps(BoltInventoryService service)
		{
			_service = service;
		}

		public void AddAmount(int currencyId, float amount)
		{
			_operations.Add(new CurrencyAmountOperation(currencyId, amount));
		}

		public void RemoveAmount(int currencyId, float amount)
		{
			_operations.Add(new CurrencyAmountOperation(currencyId, 0f - amount));
		}

		public void Add(BoltInventoryItem inventoryItem)
		{
			if (inventoryItem == null)
			{
				throw new ArgumentNullException("inventoryItem");
			}
			_operations.Add(new InventoryItemAddOperation(inventoryItem));
		}

		public void Remove(int inventoryItemId)
		{
			_operations.Add(new InventoryItemRemoveOperation(inventoryItemId));
		}

		public void Consume(int inventoryItemId, int count = 1)
		{
			_operations.Add(new InventoryItemConsumeOperation(inventoryItemId, count));
		}

		public void Set(BoltInventoryItem inventoryItem)
		{
			if (inventoryItem == null)
			{
				throw new ArgumentNullException("inventoryItem");
			}
			Remove(inventoryItem.Id);
			Add(inventoryItem);
		}

		public void Apply()
		{
			_service.ApplyOperations(_operations);
			_operations.Clear();
		}
	}
}
