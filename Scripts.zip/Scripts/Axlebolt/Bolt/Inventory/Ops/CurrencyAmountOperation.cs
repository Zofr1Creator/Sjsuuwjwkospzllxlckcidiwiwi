namespace Axlebolt.Bolt.Inventory.Ops
{
	public class CurrencyAmountOperation : Operation
	{
		public int CurrencyId { get; }

		public float Amount { get; }

		public CurrencyAmountOperation(int currencyId, float amount)
		{
			CurrencyId = currencyId;
			Amount = amount;
		}
	}
}
