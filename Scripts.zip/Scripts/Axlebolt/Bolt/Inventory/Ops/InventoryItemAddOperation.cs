namespace Axlebolt.Bolt.Inventory.Ops
{
	public class InventoryItemAddOperation : Operation
	{
		public BoltInventoryItem Item { get; }

		public InventoryItemAddOperation(BoltInventoryItem item)
		{
			Item = item;
		}
	}
	public class InventoryItemADdOperation : Operation
	{
	}
}
