namespace Axlebolt.Bolt.Inventory.Ops
{
	public class InventoryItemConsumeOperation : Operation
	{
		public int InventoryItemId { get; }

		public int Quantity { get; }

		public InventoryItemConsumeOperation(int inventoryItemId, int quantity)
		{
			InventoryItemId = inventoryItemId;
			Quantity = quantity;
		}
	}
}
