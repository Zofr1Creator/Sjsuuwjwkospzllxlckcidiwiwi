namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryResult
	{
		public BoltInventoryItem[] InventoryItems { get; }

		public BoltCurrencyAmounts Currencies { get; }

		public BoltInventoryResult(BoltCurrencyAmounts currencies, BoltInventoryItem[] inventoryItems)
		{
			InventoryItems = inventoryItems;
			Currencies = currencies;
		}

		public bool HasItems()
		{
			return InventoryItems.Length != 0;
		}

		public bool HasCurrencies()
		{
			return Currencies.Count != 0;
		}
	}
}
