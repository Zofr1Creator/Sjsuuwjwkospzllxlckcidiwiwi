namespace Axlebolt.Bolt.Inventory
{
	public enum BoltItemPropertyDefinitionType
	{
		String = 0,
		Float = 1,
		Integer = 2,
		Boolean = 3
	}
}
