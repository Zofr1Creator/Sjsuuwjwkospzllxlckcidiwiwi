using UnityEngine;

namespace Axlebolt.Bolt.Inventory
{
    public class BoltItemDefinitionAmount
    {
        private readonly int _itemDefinitionId;

        private readonly int _value;

        public int ItemDefinitionId => _itemDefinitionId; 

        public int Value => _value;  

        public BoltItemDefinitionAmount(int itemDefinitionId, int value)
        {
            _itemDefinitionId = itemDefinitionId;
            _value = value;
        }
    }
}
