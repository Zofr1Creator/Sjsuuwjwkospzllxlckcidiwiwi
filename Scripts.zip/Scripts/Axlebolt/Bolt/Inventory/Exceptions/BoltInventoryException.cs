namespace Axlebolt.Bolt.Inventory.Exceptions
{
	public class BoltInventoryException : BoltException
	{
		public BoltInventoryException(string message)
			: base(message)
		{
		}
	}
}
