namespace Axlebolt.Bolt.Inventory
{
	public enum BoltItemPropertySetByType
	{
		GameServer = 0,
		OfficialGameServer = 1,
		Client = 2
	}
}
