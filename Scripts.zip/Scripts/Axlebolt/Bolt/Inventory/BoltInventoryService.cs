using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Inventory.Events;
using Axlebolt.Bolt.Inventory.Exceptions;
using Axlebolt.Bolt.Inventory.Mappers;
using Axlebolt.Bolt.Inventory.Ops;
using Axlebolt.Bolt.Protobuf;
using Google.Protobuf.Collections;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryService : BoltService<BoltInventoryService>
	{
		public class AdsRemoteEventListener : IAdsRemoteEventListener
		{
			private readonly BoltInventoryService _service;

			public AdsRemoteEventListener(BoltInventoryService service)
			{
				_service = service;
			}

			public void OnAdRewarded(CurrencyAmount[] currencyAmounts, InventoryItem[] items, InventoryItem[] exchangeItems, CurrencyAmount[] exchangeCurrencies)
			{
				List<BoltInventoryItem> list = InventoryItemMapper.Instance.ToOriginalList(items);
				List<BoltInventoryItem> list2 = InventoryItemMapper.Instance.ToOriginalList(exchangeItems);
				BoltCurrencyAmounts boltCurrencyAmounts = new BoltCurrencyAmounts();
				BoltCurrencyAmounts boltCurrencyAmounts2 = new BoltCurrencyAmounts();
				InventoryOps inventoryOps = _service.CreateInventoryOps();
				foreach (BoltInventoryItem item in list)
				{
					inventoryOps.Add(item);
				}
				foreach (BoltInventoryItem item2 in list2)
				{
					inventoryOps.Add(item2);
				}
				foreach (CurrencyAmount currencyAmount in currencyAmounts)
				{
					inventoryOps.AddAmount(currencyAmount.CurrencyId, currencyAmount.Value);
					boltCurrencyAmounts.AddAmount(currencyAmount.CurrencyId, currencyAmount.Value);
				}
				foreach (CurrencyAmount currencyAmount2 in exchangeCurrencies)
				{
					inventoryOps.AddAmount(currencyAmount2.CurrencyId, currencyAmount2.Value);
					boltCurrencyAmounts2.AddAmount(currencyAmount2.CurrencyId, currencyAmount2.Value);
				}
				inventoryOps.Apply();
				InvokeOnAdRewardedEvent(boltCurrencyAmounts, list, list2, boltCurrencyAmounts2);
			}

			private void InvokeOnAdRewardedEvent(BoltCurrencyAmounts curr, List<BoltInventoryItem> originalItems, List<BoltInventoryItem> exchangeItems, BoltCurrencyAmounts exchangeCurrencies)
			{
				AdRewardedEventArgs arg = new AdRewardedEventArgs(curr, originalItems, exchangeItems, exchangeCurrencies);
				_service.AdRewardedEvent.Invoke(arg);
			}
		}

		private readonly InventoryRemoteService _inventoryRemoteService;

		private readonly AdsRemoteService _adsRemoteService;

		private readonly GoogleInAppRemoteService _googleInAppRemoteService;

		private readonly AppStoreInAppRemoteService _appStoreInAppRemoteService;

		private readonly AmazonInAppRemoteService _amazonInAppRemoteService;

		private Dictionary<int, BoltInventoryItemDefinition> _inventoryDefinitions;

		private readonly AdsRemoteEventListener _remoteEventListener;

		private Dictionary<int, BoltInventoryItem> _inventoryItems;

		private BoltCurrencyAmounts _currencies;

		public readonly BoltEvent<AdRewardedEventArgs> AdRewardedEvent = new BoltEvent<AdRewardedEventArgs>();

		public readonly BoltEvent<InventoryItemsUpdatedEventArgs> InventoryItemsUpdatedEvent = new BoltEvent<InventoryItemsUpdatedEventArgs>();

		public readonly BoltEvent<CurrenciesUpdatedEventArgs> CurrenciesUpdatedEvent = new BoltEvent<CurrenciesUpdatedEventArgs>();

		private readonly List<BoltInventoryItemsBackupProperties> _backupChangedProperties;

		private readonly Dictionary<int, BoltInventoryItemPropertyDefinitions> _itemPropertyDefinitions;

		public BoltInventoryService()
		{
			_inventoryRemoteService = new InventoryRemoteService(BoltPlayerApi.Instance.ClientService);
			_inventoryItems = new Dictionary<int, BoltInventoryItem>();
			_adsRemoteService = new AdsRemoteService(BoltPlayerApi.Instance.ClientService);
			_inventoryDefinitions = new Dictionary<int, BoltInventoryItemDefinition>();
			_backupChangedProperties = new List<BoltInventoryItemsBackupProperties>();
			_itemPropertyDefinitions = new Dictionary<int, BoltInventoryItemPropertyDefinitions>();
			_remoteEventListener = new AdsRemoteEventListener(this);
			_googleInAppRemoteService = new GoogleInAppRemoteService(BoltPlayerApi.Instance.ClientService);
			_appStoreInAppRemoteService = new AppStoreInAppRemoteService(BoltPlayerApi.Instance.ClientService);
			_amazonInAppRemoteService = new AmazonInAppRemoteService(BoltPlayerApi.Instance.ClientService);
		}

		internal override void BindEvents()
		{
			BoltPlayerApi.Instance.AddEventListener(_remoteEventListener);
		}

		internal override void UnbindEvents()
		{
			BoltPlayerApi.Instance.RemoveEventListener(_remoteEventListener);
		}

		public BoltInventoryItem[] GetInventoryItems()
		{
			return _inventoryItems.Values.ToArray();
		}

        public Task<BoltInventoryItem[]> GetFriendInventoryItemsByIdAsync(string playerId, int[] itemDefinitions)
        {
            return BoltPlayerApi.Instance.Async(() =>
            {
                InventoryItem[] protoItems = _inventoryRemoteService.GetPlayerInventory(playerId, itemDefinitions);
                return InventoryItemMapper.Instance.ToOriginalArray(protoItems);
            });
        }

        public BoltInventoryItem[] GetFriendInventoryItemsById(string playerId, int[] itemDefinitions)
        {
            InventoryItem[] protoItems = _inventoryRemoteService.GetPlayerInventory(playerId, itemDefinitions);
            return InventoryItemMapper.Instance.ToOriginalArray(protoItems);
        }

        public BoltInventoryItem GetInventoryItem(int id)
		{
			if (IsInventoryItemExists(id))
			{
				return _inventoryItems[id];
			}
			throw new BoltInventoryException($"InventoryItem with id {id} not found");
		}

		public bool IsInventoryItemExists(int id)
		{
			return _inventoryItems.ContainsKey(id);
		}

		public BoltCurrencyAmounts GetCurrencies()
		{
			return _currencies;
		}

		internal InventoryOps CreateInventoryOps()
		{
			return new InventoryOps(this);
		}

		public float GetCurrencyAmount(int id)
		{
			if (_currencies.ContainsKey(id))
			{
				return _currencies[id];
			}
			throw new BoltInventoryException($"Currency with id {id} not found");
		}

		public BoltInventoryItemDefinition GetInventoryItemDefinition(int id)
		{
			if (_inventoryDefinitions.ContainsKey(id))
			{
				return _inventoryDefinitions[id];
			}
			throw new BoltInventoryException($"Definition with id {id} not found");
		}

		public List<BoltInventoryItemDefinition> GetInventoryItemDefinitions()
		{
			return _inventoryDefinitions.Values.ToList();
		}

		public void SetInventoryItemProperty(int itemId, string propertyName, int value)
		{
			SetProperty(itemId, propertyName, new BoltInventoryItemProperty(value));
		}

		public void SetInventoryItemProperty(int itemId, string propertyName, float value)
		{
			SetProperty(itemId, propertyName, new BoltInventoryItemProperty(value));
		}

		public void SetInventoryItemProperty(int itemId, string propertyName, string value)
		{
			SetProperty(itemId, propertyName, new BoltInventoryItemProperty(value));
		}

		public void SetInventoryItemProperty(int itemId, string propertyName, bool value)
		{
			SetProperty(itemId, propertyName, new BoltInventoryItemProperty(value));
		}

		private void SetProperty(int itemId, string propertyName, BoltInventoryItemProperty value)
		{
			if (!_inventoryItems.ContainsKey(itemId))
			{
				throw new BoltInventoryException($"Item with id {itemId} not found!");
			}
			BoltInventoryItem boltInventoryItem = _inventoryItems[itemId];
			BoltInventoryItemPropertyDefinitions boltInventoryItemPropertyDefinitions = _itemPropertyDefinitions[boltInventoryItem.Definition.Id];
			if (!boltInventoryItemPropertyDefinitions.Definitions.ContainsKey(propertyName))
			{
				throw new BoltInventoryException($"Property definition with name {propertyName} not found!");
			}
			if (!boltInventoryItemPropertyDefinitions.Definitions[propertyName].SetByType.Equals(BoltItemPropertySetByType.Client))
			{
				throw new BoltInventoryException($"Property with name {propertyName} can't be applied to item {itemId} by Client!");
			}
			if (!IsSameType(value, boltInventoryItemPropertyDefinitions.Definitions[propertyName].Type))
			{
				throw new BoltInventoryException($"Property with name {propertyName} has incorrent type!");
			}
			boltInventoryItem.ItemProperties.ChangedProperties[propertyName] = value;
		}

        public Task ApplyInventoryItemAsync(int consumedItemId, int appliedItemId, string appliedPropertyName, bool isRemovable)
        {
            return BoltPlayerApi.Instance.Async(delegate
            {
				ApplyInventoryItem(consumedItemId, appliedItemId, appliedPropertyName, isRemovable);
            });
        }

        public void ApplyInventoryItem(int consumedItemId, int appliedItemId, string appliedPropertyName, bool isRemovable)
        {
            var remoteItem = _inventoryRemoteService.ApplyInventoryItem(consumedItemId, appliedItemId, appliedPropertyName, isRemovable);
            var ops = CreateInventoryOps();
            ops.Remove(consumedItemId);
            ops.Remove(appliedItemId);
            ops.Add(InventoryItemMapper.Instance.ToOriginal(remoteItem));
            ops.Apply();
        }

        /*public Task ActivateCoupon(string couponId)
        {
            return BoltPlayerApi.Instance.Async(delegate
            {
                _inventoryRemoteService.ActivateCoupon(new ActivateCouponRequest
                {
                    CouponId = couponId
                });
            });
        }*/

        public Task ActivateCoupon(string couponId)
        {
            return BoltPlayerApi.Instance.Async(() =>
            {
                var request = new ActivateCouponRequest
                {
                    CouponId = couponId
                };

                var response = _inventoryRemoteService.ActivateCoupon(request);

                var ops = CreateInventoryOps();

                if (response.InventoryItems != null)
                {
                    var inventoryItems = InventoryItemMapper.Instance.ToOriginalArray(response.InventoryItems);
                    foreach (var item in inventoryItems)
                    {
                        ops.Add(item);
                    }
                }

                if (response.Currencies != null)
                {
                    var currencies = CurrencyAmountMapper.Instance.ToOriginalArray(response.Currencies);
                    foreach (var currency in currencies)
                    {
                        ops.AddAmount(currency.CurrencyId, currency.Value);
                    }
                }

                ops.Apply();
            });
        }

        public Task RemoveInventoryItemPropertyAsync(int itemId, string propertyName)
        {
            return BoltPlayerApi.Instance.Async(delegate
            {
				RemoveInventoryItemProperty(itemId, propertyName);
            });
        }

        public void RemoveInventoryItemProperty(int itemId, string propertyName)
        {
            var remoteItem = _inventoryRemoteService.RemoveInventoryItemProperty(itemId, propertyName);
            var ops = CreateInventoryOps();
            ops.Remove(itemId);
            ops.Add(InventoryItemMapper.Instance.ToOriginal(remoteItem));
            ops.Apply();
        }

        private static bool IsSameType(BoltInventoryItemProperty value, BoltItemPropertyDefinitionType type)
		{
			if (value.IsInt && type == BoltItemPropertyDefinitionType.Integer)
			{
				return true;
			}
			if (value.IsFloat && type == BoltItemPropertyDefinitionType.Float)
			{
				return true;
			}
			if (value.IsBool && type == BoltItemPropertyDefinitionType.Boolean)
			{
				return true;
			}
			return value.IsString && type == BoltItemPropertyDefinitionType.String;
		}

		public Task UpdateChangedProperties()
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				List<InventoryItemProperties> list = new List<InventoryItemProperties>();
				foreach (int key in _inventoryItems.Keys)
				{
					Dictionary<string, BoltInventoryItemProperty> changedProperties = _inventoryItems[key].ItemProperties.ChangedProperties;
					InventoryItemProperties inventoryItemProperties = new InventoryItemProperties();
					foreach (string key2 in changedProperties.Keys)
					{
						InventoryItemProperty inventoryItemProperty = new InventoryItemProperty();
						if (changedProperties[key2].IsBool)
						{
							inventoryItemProperty.BooleanValue = changedProperties[key2].BoolValue;
							inventoryItemProperty.Type = PropertyType.Boolean;
						}
						if (changedProperties[key2].IsInt)
						{
							inventoryItemProperty.IntValue = changedProperties[key2].IntValue;
							inventoryItemProperty.Type = PropertyType.Int;
						}
						if (changedProperties[key2].IsFloat)
						{
							inventoryItemProperty.FloatValue = changedProperties[key2].FloatValue;
							inventoryItemProperty.Type = PropertyType.Float;
						}
						if (changedProperties[key2].IsString)
						{
							inventoryItemProperty.StringValue = changedProperties[key2].StringValue;
							inventoryItemProperty.Type = PropertyType.String;
						}
						inventoryItemProperties.Properties.Add(key2, inventoryItemProperty);
						if (!_inventoryItems[key].ItemProperties.Properties.ContainsKey(key2))
						{
							_inventoryItems[key].ItemProperties.Properties.Add(key2, changedProperties[key2]);
						}
						else
						{
							_inventoryItems[key].ItemProperties.Properties[key2] = changedProperties[key2];
						}
					}
					inventoryItemProperties.Id = key;
					list.Add(inventoryItemProperties);
					_inventoryItems[key].ItemProperties.ChangedProperties.Clear();
				}
				_inventoryRemoteService.SetInventoryItemsProperties(list.ToArray());
			});
		}

		public Task<BoltInventoryItem> ConsumeInventoryItems(int inventoryItemId, int quantity)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				InventoryItem proto = _inventoryRemoteService.ConsumeInventoryItem(inventoryItemId, quantity);
				BoltInventoryItem boltInventoryItem = InventoryItemMapper.Instance.ToOriginal(proto);
				InventoryOps inventoryOps = CreateInventoryOps();
				inventoryOps.Remove(inventoryItemId);
				if (boltInventoryItem.Quantity != 0)
				{
					inventoryOps.Add(boltInventoryItem);
				}
				inventoryOps.Apply();
				return boltInventoryItem;
			});
		}

		public Task TransferInventoryItems(int fromItemId, int toItemId, int quantity)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				InventoryItem[] source = _inventoryRemoteService.TransferInventoryItems(fromItemId, toItemId, quantity);
				List<BoltInventoryItem> list = InventoryItemMapper.Instance.ToOriginalList(source.ToList());
				InventoryOps inventoryOps = CreateInventoryOps();
				inventoryOps.Remove(fromItemId);
				foreach (BoltInventoryItem item in list)
				{
					inventoryOps.Set(item);
				}
				inventoryOps.Apply();
			});
		}

		public Task<BoltInventoryItem[]> BuyInventoryItems(int definitionId, int quantity, int currencyId, bool toManyItems)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				InventoryItem[] source = _inventoryRemoteService.BuyInventoryItem(definitionId, quantity, currencyId, toManyItems);
				List<BoltInventoryItem> list = InventoryItemMapper.Instance.ToOriginalList(source.ToList());
				float amount = _inventoryDefinitions[definitionId].BuyPrice[currencyId] * (float)quantity;
				InventoryOps inventoryOps = CreateInventoryOps();
				inventoryOps.RemoveAmount(currencyId, amount);
				foreach (BoltInventoryItem item in list)
				{
					inventoryOps.Add(item);
				}
				inventoryOps.Apply();
				return list.ToArray();
			});
		}

		public Task<BoltInventoryItem> SellInventoryItems(int inventoryItemId, int quantity, int currencyId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				InventoryItem proto = _inventoryRemoteService.SellInventoryItem(inventoryItemId, quantity, currencyId);
				BoltInventoryItem boltInventoryItem = InventoryItemMapper.Instance.ToOriginal(proto);
				InventoryOps inventoryOps = CreateInventoryOps();
				inventoryOps.Set(boltInventoryItem);
				_inventoryItems[inventoryItemId] = boltInventoryItem;
				int id = boltInventoryItem.Definition.Id;
				float amount = _inventoryDefinitions[id].SellPrice[currencyId] * (float)quantity;
				inventoryOps.AddAmount(currencyId, amount);
				inventoryOps.Apply();
				return boltInventoryItem;
			});
		}

		public Task<BoltInventoryResult> ExchangeInventoryItems(string recipeCode, BoltCurrencyAmounts currencies, int[] inventoryItemIds)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				CurrencyAmount[] currencies2 = CurrencyAmountsMapper.Instance.ToProto(currencies);
				ExchangeResult proto = _inventoryRemoteService.ExchangeInventoryItems(recipeCode, currencies2, inventoryItemIds);
				BoltInventoryResult boltInventoryResult = ExchangeResultMapper.Instance.ToOriginal(proto);
				InventoryOps inventoryOps = CreateInventoryOps();
				foreach (KeyValuePair<int, float> currency in currencies)
				{
					inventoryOps.RemoveAmount(currency.Key, currency.Value);
				}
				int[] array = inventoryItemIds;
				foreach (int inventoryItemId in array)
				{
					inventoryOps.Remove(inventoryItemId);
				}
				foreach (KeyValuePair<int, float> currency2 in boltInventoryResult.Currencies)
				{
					inventoryOps.AddAmount(currency2.Key, currency2.Value);
				}
				BoltInventoryItem[] inventoryItems = boltInventoryResult.InventoryItems;
				foreach (BoltInventoryItem inventoryItem in inventoryItems)
				{
					inventoryOps.Add(inventoryItem);
				}
				inventoryOps.Apply();
				return boltInventoryResult;
			});
		}

		public Task<BoltInventoryResult> ConfirmGooglePurchase(string json, string signature)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				PlayerInventory inApps = _googleInAppRemoteService.BuyInApp(json, signature);
				return ProcessInAppResult(inApps);
			});
		}

		public Task<BoltInventoryResult> ConfirmAppStorePurchase(string base64)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				PlayerInventory inApps = _appStoreInAppRemoteService.BuyInApp(base64);
				return ProcessInAppResult(inApps);
			});
		}

		public Task<BoltInventoryResult> ConfirmAmazonPurchase(string transactionId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				PlayerInventory inApps = _amazonInAppRemoteService.BuyInApp(transactionId);
				return ProcessInAppResult(inApps);
			});
		}

		private BoltInventoryResult ProcessInAppResult(PlayerInventory inApps)
		{
			InventoryOps inventoryOps = CreateInventoryOps();
			List<BoltInventoryItem> list = InventoryItemMapper.Instance.ToOriginalList(inApps.InventoryItems);
			foreach (BoltInventoryItem item in list)
			{
				inventoryOps.Add(item);
			}
			foreach (CurrencyAmount currency in inApps.Currencies)
			{
				inventoryOps.AddAmount(currency.CurrencyId, currency.Value);
			}
			inventoryOps.Apply();
			return InventoryResultMapper.Instancce.ToOriginal(inApps);
		}

		public Task SetInventoryItemFlags(int itemId, int flag)
		{
			return SetInventoryItemsFlags(new Dictionary<int, int> { { itemId, flag } });
		}

		public Task SetInventoryItemsFlags(Dictionary<int, int> itemFlags)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ItemFlags itemFlags2 = new ItemFlags();
				lock (this)
				{
					foreach (int key in itemFlags.Keys)
					{
						itemFlags2.Flags.Add(key, itemFlags[key]);
						_inventoryItems[key].Flags = itemFlags[key];
					}
				}
				_inventoryRemoteService.SetInventoryItemFlags(itemFlags2);
			});
		}

		public Task GiveAdReward(string conditions)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_adsRemoteService.GiveAdReward(conditions);
			});
		}

		internal override void Load()
		{
			_inventoryDefinitions = LoadPlayerInventoryItemDefinitions().ToDictionary((BoltInventoryItemDefinition item) => item.Id, (BoltInventoryItemDefinition item) => item);
			InventoryItemMapper.Instance.Definitions = _inventoryDefinitions;
			PlayerInventory playerInventory = _inventoryRemoteService.GetPlayerInventory();
			List<BoltInventoryItem> source = InventoryItemMapper.Instance.ToOriginalList(playerInventory.InventoryItems.ToList());
			_inventoryItems = source.ToDictionary((BoltInventoryItem item) => item.Id, (BoltInventoryItem item) => item);
			_currencies = CurrencyAmountsMapper.Instance.ToOriginal(playerInventory.Currencies.ToArray());
			foreach (BoltInventoryItemsBackupProperties backupChangedProperty in _backupChangedProperties)
			{
				if (_inventoryItems.ContainsKey(backupChangedProperty.ItemId))
				{
					_inventoryItems[backupChangedProperty.ItemId].ItemProperties.ChangedProperties = backupChangedProperty.Properties;
				}
			}
			_backupChangedProperties.Clear();
			InventoryItemPropertyDefinitions[] inventoryItemPropertyDefinitions = _inventoryRemoteService.GetInventoryItemPropertyDefinitions();
			InventoryItemPropertyDefinitions[] array = inventoryItemPropertyDefinitions;
			foreach (InventoryItemPropertyDefinitions inventoryItemPropertyDefinitions2 in array)
			{
				MapField<string, InventoryItemPropertyDefinition> defsMap = inventoryItemPropertyDefinitions2.Definitions;
				Dictionary<string, BoltInventoryItemPropertyDefinition> definitions = defsMap.Keys.ToDictionary((string key) => key, (string key) => ItemPropertyDefinitionMapper.Instance.ToOriginal(defsMap[key]));
				BoltInventoryItemPropertyDefinitions value = new BoltInventoryItemPropertyDefinitions
				{
					DefinitionId = inventoryItemPropertyDefinitions2.ItemDefinitionId,
					Definitions = definitions
				};
				_itemPropertyDefinitions[inventoryItemPropertyDefinitions2.ItemDefinitionId] = value;
			}
		}

		internal override void Unload()
		{
			foreach (int key in _inventoryItems.Keys)
			{
				if (_inventoryItems[key].ItemProperties.ChangedProperties.Count != 0)
				{
					BoltInventoryItemsBackupProperties item = new BoltInventoryItemsBackupProperties
					{
						ItemId = key,
						Properties = _inventoryItems[key].ItemProperties.ChangedProperties
					};
					_backupChangedProperties.Add(item);
				}
			}
			_itemPropertyDefinitions.Clear();
		}

		private IEnumerable<BoltInventoryItemDefinition> LoadPlayerInventoryItemDefinitions()
		{
			return InventoryItemDefinitionMapper.Instance.ToOriginalList(_inventoryRemoteService.GetInventoryItemDefinitions());
		}

		internal void ApplyOperations(List<Operation> operations)
		{
			lock (this)
			{
				bool flag = false;
				bool flag2 = false;
				foreach (Operation operation in operations)
				{
					if (operation is CurrencyAmountOperation currencyAmountOperation)
					{
						_currencies.AddAmount(currencyAmountOperation.CurrencyId, currencyAmountOperation.Amount);
						flag = true;
					}
					if (operation is InventoryItemAddOperation inventoryItemAddOperation)
					{
						_inventoryItems.Add(inventoryItemAddOperation.Item.Id, inventoryItemAddOperation.Item);
						flag2 = true;
					}
					if (operation is InventoryItemRemoveOperation inventoryItemRemoveOperation)
					{
						_inventoryItems.Remove(inventoryItemRemoveOperation.InventoryItemId);
						flag2 = true;
					}
					if (!(operation is InventoryItemConsumeOperation inventoryItemConsumeOperation))
					{
						continue;
					}
					int inventoryItemId = inventoryItemConsumeOperation.InventoryItemId;
					if (_inventoryItems.ContainsKey(inventoryItemId))
					{
						_inventoryItems[inventoryItemId].Quantity -= inventoryItemConsumeOperation.Quantity;
						if (_inventoryItems[inventoryItemId].Quantity <= 0)
						{
							_inventoryItems.Remove(inventoryItemId);
						}
						flag2 = true;
					}
				}
				if (flag)
				{
					InvokeOnCurrenciesUpdatedEvent();
				}
				if (flag2)
				{
					InvokeOnInventoryItemsUpdatedEvent();
				}
			}
		}

		private void InvokeOnInventoryItemsUpdatedEvent()
		{
			InventoryItemsUpdatedEventArgs arg = new InventoryItemsUpdatedEventArgs();
			InventoryItemsUpdatedEvent.Invoke(arg);
		}

		private void InvokeOnCurrenciesUpdatedEvent()
		{
			CurrenciesUpdatedEventArgs arg = new CurrenciesUpdatedEventArgs();
			CurrenciesUpdatedEvent.Invoke(arg);
		}
	}
}
