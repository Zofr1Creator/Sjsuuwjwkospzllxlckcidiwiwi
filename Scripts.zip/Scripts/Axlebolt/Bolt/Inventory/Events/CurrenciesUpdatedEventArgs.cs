namespace Axlebolt.Bolt.Inventory.Events
{
	public class CurrenciesUpdatedEventArgs
	{
	}
}
