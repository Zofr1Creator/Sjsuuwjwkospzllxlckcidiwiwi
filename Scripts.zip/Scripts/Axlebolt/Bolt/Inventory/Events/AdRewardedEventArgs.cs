using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory.Events
{
	public class AdRewardedEventArgs
	{
		public BoltCurrencyAmounts Currencies { get; set; }

		public List<BoltInventoryItem> Items { get; set; }

		public List<BoltInventoryItem> ExchangeItems { get; set; }

		public BoltCurrencyAmounts ExchangeCurrencies { get; set; }

		public AdRewardedEventArgs(BoltCurrencyAmounts currs, List<BoltInventoryItem> items, List<BoltInventoryItem> exItems, BoltCurrencyAmounts exCurrencies)
		{
			Currencies = currs;
			Items = items;
			ExchangeItems = exItems;
			ExchangeCurrencies = exCurrencies;
		}
	}
}
