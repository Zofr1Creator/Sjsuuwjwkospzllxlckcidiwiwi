namespace Axlebolt.Bolt.Inventory.Events
{
	public class InventoryItemsUpdatedEventArgs
	{
	}
}
