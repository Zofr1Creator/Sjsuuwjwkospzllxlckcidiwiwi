using UnityEngine;

namespace Axlebolt.Bolt.Inventory
{
    public class BoltExchangeResult
    {
        private BoltItemDefinitionAmount[] _items;

        private BoltCurrencyAmount[] _currencies;

        public BoltItemDefinitionAmount[] Items
        {
            get { return _items; }
            set { _items = value; }
        }

        public BoltCurrencyAmount[] Currencies
        {
            get { return _currencies; }
            set { _currencies = value; }
        }

        /*public BoltExchangeResult()
        {
            _items = new BoltItemDefinitionAmount[0]; 
            _currencies = new BoltCurrencyAmount[0]; 
        }*/
    }
}
