using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltCurrencyAmounts : Dictionary<int, float>
	{
		public BoltCurrencyAmounts()
		{
		}

		public BoltCurrencyAmounts(int currencyId, float amount)
		{
			SetAmount(currencyId, amount);
		}

		public bool HasValues()
		{
			return base.Values.Count != 0;
		}

		public bool HasCurrency(int id)
		{
			return ContainsKey(id);
		}

		public void AddAmount(int currencyId, float amount)
		{
			if (!HasCurrency(currencyId))
			{
				base[currencyId] = 0f;
			}
			base[currencyId] += amount;
		}

		public void SubtractAmount(int currencyId, float amount)
		{
			if (!HasCurrency(currencyId))
			{
				base[currencyId] = 0f;
			}
			base[currencyId] -= amount;
		}

		public void SetAmount(int currencyId, float amount)
		{
			base[currencyId] = amount;
		}
	}
}
