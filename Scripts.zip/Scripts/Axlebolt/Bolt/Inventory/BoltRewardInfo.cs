using System.Linq;

namespace Axlebolt.Bolt.Inventory
{
    public class BoltRewardInfo
    {
        public BoltItemDefinitionAmount[] Items { get; set; } = new BoltItemDefinitionAmount[0];

        public BoltCurrencyAmount[] Currencies { get; set; } = new BoltCurrencyAmount[0];

        public BoltRecipeInfo[] Recipes { get; set; } = new BoltRecipeInfo[0];

        public BoltCurrencyAmount GetCurrencyAmount(int currencyId)
        {
            return Currencies.FirstOrDefault(c => c.CurrencyId == currencyId);
        }

        public bool HasCurrencyAmount(int currencyId)
        {
            return Currencies.Any(c => c.CurrencyId == currencyId);
        }

        public bool IsEmpty()
        {
            bool noItems = Items == null || Items.Length == 0;
            bool noCurrencies = Currencies == null || Currencies.Length == 0;
            bool noRecipes = Recipes == null || Recipes.Length == 0;
            return noItems && noCurrencies && noRecipes;
        }
    }
}