namespace Axlebolt.Bolt.Inventory
{
    public class BoltRecipeInfo
    {
        public string Recipe { get; set; }

        public BoltExchangeResult[] Results { get; set; } = new BoltExchangeResult[0];
    }
}
