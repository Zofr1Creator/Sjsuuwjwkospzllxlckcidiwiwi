namespace Axlebolt.Bolt.Inventory
{
    public class BoltCurrencyAmount
    {
        public int CurrencyId { get; }

        public float Value { get; }

        public BoltCurrencyAmount(int currencyId, float value)
        {
            CurrencyId = currencyId;
            Value = value;
        }
    }
}
