using System;
using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemProperties
	{
		public Dictionary<string, BoltInventoryItemProperty> ChangedProperties { get; internal set; }

		public Dictionary<string, BoltInventoryItemProperty> Properties { get; }

		internal BoltInventoryItemProperties(Dictionary<string, BoltInventoryItemProperty> properties)
		{
			Properties = properties;
			ChangedProperties = new Dictionary<string, BoltInventoryItemProperty>();
		}

		public int GetIntProperty(string key, int defaultValue = 0)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (ChangedProperties.ContainsKey(key) && ChangedProperties[key].IsInt)
			{
				return ChangedProperties[key].IntValue;
			}
			if (Properties.ContainsKey(key) && Properties[key].IsInt)
			{
				return Properties[key].IntValue;
			}
			return defaultValue;
		}

		public string GetStringProperty(string key, string defaultValue = null)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (ChangedProperties.ContainsKey(key) && ChangedProperties[key].IsString)
			{
				return ChangedProperties[key].StringValue;
			}
			if (Properties.ContainsKey(key) && Properties[key].IsString)
			{
				return Properties[key].StringValue;
			}
			return defaultValue;
		}

		public float GetFloatProperty(string key, float defaultValue = 0f)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (ChangedProperties.ContainsKey(key) && ChangedProperties[key].IsFloat)
			{
				return ChangedProperties[key].FloatValue;
			}
			if (Properties.ContainsKey(key) && Properties[key].IsFloat)
			{
				return Properties[key].FloatValue;
			}
			return defaultValue;
		}

		public bool GetBoolValue(string key, bool defaultValue = false)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key");
			}
			if (ChangedProperties.ContainsKey(key) && ChangedProperties[key].IsBool)
			{
				return ChangedProperties[key].BoolValue;
			}
			if (Properties.ContainsKey(key) && Properties[key].IsBool)
			{
				return Properties[key].BoolValue;
			}
			return defaultValue;
		}
	}
}
