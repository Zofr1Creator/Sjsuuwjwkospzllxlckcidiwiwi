namespace Axlebolt.Bolt.Inventory
{
	public enum BoltStoreCode
	{
		GooglePlayStore = 0,
		IosAppStore = 1
	}
}
