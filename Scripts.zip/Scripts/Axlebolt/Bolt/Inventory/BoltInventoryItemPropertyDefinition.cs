namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemPropertyDefinition
	{
		public string Name { get; set; }

		public BoltItemPropertyDefinitionType Type { get; set; }

		public bool SaveInTrade { get; set; }

		public BoltItemPropertySetByType SetByType { get; set; }
	}
}
