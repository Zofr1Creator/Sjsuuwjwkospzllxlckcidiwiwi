namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItem
	{
		public int Id { get; set; }

		public BoltInventoryItemDefinition Definition { get; set; }

		public int Quantity { get; set; }

		public int Flags { get; set; }

		public long Date { get; set; }

		public BoltInventoryItemProperties ItemProperties { get; set; }
	}
}
