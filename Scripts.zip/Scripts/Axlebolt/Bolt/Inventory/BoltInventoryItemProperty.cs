namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemProperty
	{
		public int IntValue { get; }

		public float FloatValue { get; }

		public string StringValue { get; }

		public bool BoolValue { get; }

		public bool IsInt { get; }

		public bool IsFloat { get; }

		public bool IsString { get; }

		public bool IsBool { get; }

		public BoltInventoryItemProperty(int intValue)
		{
			IntValue = intValue;
			IsInt = true;
		}

		public BoltInventoryItemProperty(float floatValue)
		{
			FloatValue = floatValue;
			IsFloat = true;
		}

		public BoltInventoryItemProperty(string stringValue)
		{
			StringValue = stringValue;
			IsString = true;
		}

		public BoltInventoryItemProperty(bool boolValue)
		{
			BoolValue = boolValue;
			IsBool = true;
		}
	}
}
