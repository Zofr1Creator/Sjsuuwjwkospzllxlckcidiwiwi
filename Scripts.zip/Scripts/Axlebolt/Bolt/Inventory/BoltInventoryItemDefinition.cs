using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemDefinition
	{
		public int Id { get; set; }

		public string DisplayName { get; set; }

		public Dictionary<int, float> BuyPrice { get; set; }

		public Dictionary<int, float> SellPrice { get; set; }

		public Dictionary<string, string> Properties { get; set; }

		public bool CanBeTraded { get; set; }
	}
}
