using System.Collections.Generic;

namespace Axlebolt.Bolt.Inventory
{
	public class BoltInventoryItemPropertyDefinitions
	{
		public int DefinitionId { get; set; }

		public Dictionary<string, BoltInventoryItemPropertyDefinition> Definitions { get; set; }
	}
}
