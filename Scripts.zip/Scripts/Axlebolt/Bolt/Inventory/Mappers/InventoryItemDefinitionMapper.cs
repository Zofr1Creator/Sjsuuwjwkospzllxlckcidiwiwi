using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class InventoryItemDefinitionMapper : MessageMapper<InventoryItemDefinition, BoltInventoryItemDefinition>
	{
		public static readonly InventoryItemDefinitionMapper Instance = new InventoryItemDefinitionMapper();

		public override BoltInventoryItemDefinition ToOriginal(InventoryItemDefinition proto)
		{
			return new BoltInventoryItemDefinition
			{
				Id = proto.Id,
				DisplayName = proto.DisplayName,
				BuyPrice = proto.BuyPrice.ToDictionary((CurrencyAmount curr) => curr.CurrencyId, (CurrencyAmount curr) => curr.Value),
				SellPrice = proto.SellPrice.ToDictionary((CurrencyAmount curr) => curr.CurrencyId, (CurrencyAmount curr) => curr.Value),
				Properties = GetOriginalProperties(proto),
				CanBeTraded = proto.CanBeTraded
			};
		}

		private static Dictionary<string, string> GetOriginalProperties(InventoryItemDefinition proto)
		{
			return proto.Properties.Keys.ToDictionary((string key) => key, (string key) => proto.Properties[key]);
		}
	}
}
