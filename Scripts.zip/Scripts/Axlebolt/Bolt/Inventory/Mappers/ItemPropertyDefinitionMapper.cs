using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class ItemPropertyDefinitionMapper : MessageMapper<InventoryItemPropertyDefinition, BoltInventoryItemPropertyDefinition>
	{
		public static readonly ItemPropertyDefinitionMapper Instance = new ItemPropertyDefinitionMapper();

		public override BoltInventoryItemPropertyDefinition ToOriginal(InventoryItemPropertyDefinition proto)
		{
			return new BoltInventoryItemPropertyDefinition
			{
				Name = proto.Name,
				SaveInTrade = proto.SaveInTrade,
				Type = FillType(proto.PropertyType),
				SetByType = FillSetByType(proto.SetByType)
			};
		}

		private BoltItemPropertyDefinitionType FillType(PropertyType propertyType)
		{
			switch (propertyType)
			{
			case PropertyType.Float:
				return BoltItemPropertyDefinitionType.Float;
			case PropertyType.Boolean:
				return BoltItemPropertyDefinitionType.Boolean;
			case PropertyType.Int:
				return BoltItemPropertyDefinitionType.Integer;
			case PropertyType.String:
				return BoltItemPropertyDefinitionType.String;
			default:
				throw new ArgumentOutOfRangeException("propertyType", propertyType, null);
			}
		}

		private BoltItemPropertySetByType FillSetByType(PropertySetByType propertySetByType)
		{
			switch (propertySetByType)
			{
			case PropertySetByType.GameServer:
				return BoltItemPropertySetByType.GameServer;
			case PropertySetByType.OfficialGameServer:
				return BoltItemPropertySetByType.OfficialGameServer;
			case PropertySetByType.Client:
				return BoltItemPropertySetByType.Client;
			default:
				throw new ArgumentOutOfRangeException("propertySetByType", propertySetByType, null);
			}
		}
	}
}
