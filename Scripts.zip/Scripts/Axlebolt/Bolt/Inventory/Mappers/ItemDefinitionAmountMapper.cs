using Axlebolt.Bolt.GameEvents.Mappers;
using System;

namespace Axlebolt.Bolt.Inventory.Mappers
{
    public class ItemDefinitionAmountMapper : MessageMapper<Axlebolt.Bolt.Protobuf.InventoryItemAmount, Axlebolt.Bolt.Inventory.BoltItemDefinitionAmount>
    {
        public static readonly ItemDefinitionAmountMapper Instance = new ItemDefinitionAmountMapper();

        public override Axlebolt.Bolt.Inventory.BoltItemDefinitionAmount ToOriginal(Axlebolt.Bolt.Protobuf.InventoryItemAmount proto)
        {
            return new Axlebolt.Bolt.Inventory.BoltItemDefinitionAmount(proto.InventoryItemDefinitionId, proto.Value);
        }
    }
}
