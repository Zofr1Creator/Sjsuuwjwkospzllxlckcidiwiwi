using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class CurrencyAmountsMapper : MessageMapper<CurrencyAmount[], BoltCurrencyAmounts>
	{
		public static readonly CurrencyAmountsMapper Instance = new CurrencyAmountsMapper();

		public override BoltCurrencyAmounts ToOriginal(CurrencyAmount[] protoCurrencies)
		{
			BoltCurrencyAmounts boltCurrencyAmounts = new BoltCurrencyAmounts();
			foreach (CurrencyAmount currencyAmount in protoCurrencies)
			{
				boltCurrencyAmounts.Add(currencyAmount.CurrencyId, currencyAmount.Value);
			}
			return boltCurrencyAmounts;
		}

		public override CurrencyAmount[] ToProto(BoltCurrencyAmounts originalCurrencies)
		{
			CurrencyAmount[] array = new CurrencyAmount[originalCurrencies.Count];
			int num = 0;
			foreach (KeyValuePair<int, float> originalCurrency in originalCurrencies)
			{
				array[num] = new CurrencyAmount
				{
					CurrencyId = originalCurrency.Key,
					Value = originalCurrency.Value
				};
				num++;
			}
			return array;
		}
	}
}
