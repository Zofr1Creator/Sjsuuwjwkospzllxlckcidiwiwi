using System.Linq;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class InventoryResultMapper : MessageMapper<PlayerInventory, BoltInventoryResult>
	{
		public static readonly InventoryResultMapper Instancce = new InventoryResultMapper();

		public override BoltInventoryResult ToOriginal(PlayerInventory proto)
		{
			BoltInventoryItem[] inventoryItems = InventoryItemMapper.Instance.ToOriginalArray(proto.InventoryItems);
			BoltCurrencyAmounts currencies = CurrencyAmountsMapper.Instance.ToOriginal(proto.Currencies.ToArray());
			return new BoltInventoryResult(currencies, inventoryItems);
		}
	}
}
