using System;

namespace Axlebolt.Bolt.Inventory.Mappers
{
    public class CurrencyAmountMapper : MessageMapper<Axlebolt.Bolt.Protobuf.CurrencyAmount, BoltCurrencyAmount>
    {
        public static readonly CurrencyAmountMapper Instance = new CurrencyAmountMapper();

        public override BoltCurrencyAmount ToOriginal(Axlebolt.Bolt.Protobuf.CurrencyAmount proto)
        {
            return new BoltCurrencyAmount(currencyId: proto.CurrencyId, value: proto.Value);
        }
    }
}
