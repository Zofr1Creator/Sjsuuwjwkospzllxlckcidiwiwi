using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class InventoryItemMapper : MessageMapper<InventoryItem, BoltInventoryItem>
	{
		public static readonly InventoryItemMapper Instance = new InventoryItemMapper();

		public Dictionary<int, BoltInventoryItemDefinition> Definitions { get; internal set; }

		public override BoltInventoryItem ToOriginal(InventoryItem proto)
		{
			return new BoltInventoryItem
			{
				Definition = (Definitions.ContainsKey(proto.ItemDefinitionId) ? Definitions[proto.ItemDefinitionId] : null),
				Id = proto.Id,
				Quantity = proto.Quantity,
				Flags = proto.Flags,
				Date = proto.Date,
				ItemProperties = new BoltInventoryItemProperties(FillProperties(proto.Properties))
			};
		}

		private static Dictionary<string, BoltInventoryItemProperty> FillProperties(IDictionary<string, InventoryItemProperty> protoProperties)
		{
			Dictionary<string, BoltInventoryItemProperty> dictionary = new Dictionary<string, BoltInventoryItemProperty>();
			foreach (string key in protoProperties.Keys)
			{
				switch (protoProperties[key].Type)
				{
				case PropertyType.Float:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].FloatValue));
					break;
				case PropertyType.Int:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].IntValue));
					break;
				case PropertyType.String:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].StringValue));
					break;
				case PropertyType.Boolean:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].BooleanValue));
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}
			}
			return dictionary;
		}
	}
}
