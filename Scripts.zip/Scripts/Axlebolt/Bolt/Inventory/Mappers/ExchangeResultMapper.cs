using System.Linq;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class ExchangeResultMapper : MessageMapper<ExchangeResult, BoltInventoryResult>
	{
		public static readonly ExchangeResultMapper Instance = new ExchangeResultMapper();

		public override BoltInventoryResult ToOriginal(ExchangeResult proto)
		{
			BoltInventoryItem[] inventoryItems = InventoryItemMapper.Instance.ToOriginalArray(proto.InventoryItems);
			BoltCurrencyAmounts currencies = CurrencyAmountsMapper.Instance.ToOriginal(proto.Currencies.ToArray());
			return new BoltInventoryResult(currencies, inventoryItems);
		}
	}
}
