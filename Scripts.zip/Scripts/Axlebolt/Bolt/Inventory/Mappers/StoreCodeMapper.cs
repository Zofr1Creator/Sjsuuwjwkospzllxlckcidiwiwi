using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Inventory.Mappers
{
	public class StoreCodeMapper : EnumMapper<StoreCode, BoltStoreCode>
	{
	}
}
