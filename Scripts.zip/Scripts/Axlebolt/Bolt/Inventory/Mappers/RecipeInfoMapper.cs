using System;
using Google.Protobuf.Collections;

namespace Axlebolt.Bolt.Inventory.Mappers
{
    public class RecipeInfoMapper : MessageMapper<Axlebolt.Bolt.Protobuf.RecipeInfo, Axlebolt.Bolt.Inventory.BoltRecipeInfo>
    {
        public static readonly RecipeInfoMapper Instance = new RecipeInfoMapper();

        public override Axlebolt.Bolt.Inventory.BoltRecipeInfo ToOriginal(Axlebolt.Bolt.Protobuf.RecipeInfo proto)
        {
            var entities = proto.Entities;
            if (entities == null)
            {
                throw new ArgumentNullException(nameof(proto.Entities), "Entities cannot be null");
            }

            var exchangeResults = new Axlebolt.Bolt.Inventory.BoltExchangeResult[entities.Count];
            int index = 0;

            foreach (var entity in entities)
            {
                var exchangeResult = new Axlebolt.Bolt.Inventory.BoltExchangeResult
                {
                    Items = ItemDefinitionAmountMapper.Instance.ToOriginalArray(entity.InventoryItems),
                    Currencies = Axlebolt.Bolt.Inventory.Mappers.CurrencyAmountMapper.Instance.ToOriginalArray(entity.Currencies)
                };

                exchangeResults[index] = exchangeResult;
                index++;
            }

            var recipeInfo = new Axlebolt.Bolt.Inventory.BoltRecipeInfo
            {
                Recipe = proto.Recipe,
                Results = exchangeResults
            };

            return recipeInfo;
        }
    }
}
