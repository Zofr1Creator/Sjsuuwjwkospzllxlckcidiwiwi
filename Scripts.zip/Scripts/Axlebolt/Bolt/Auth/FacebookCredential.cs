namespace Axlebolt.Bolt.Auth
{
	public class FacebookCredential : ICredential
	{
		public string Token { get; }

		public FacebookCredential(string token)
		{
			Token = token;
		}
	}
}
