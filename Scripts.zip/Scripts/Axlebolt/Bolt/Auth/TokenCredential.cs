namespace Axlebolt.Bolt.Auth
{
	public class TokenCredential : ICredential
	{
		public string Token { get; }

		public TokenCredential(string token)
		{
			Token = token;
		}
	}
}
