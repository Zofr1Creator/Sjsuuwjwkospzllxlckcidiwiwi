namespace Axlebolt.Bolt.Auth
{
	public interface ICredential
	{
	}
}
