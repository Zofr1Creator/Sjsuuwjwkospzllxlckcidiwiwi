using System;

namespace Axlebolt.Bolt.Auth
{
	public class GoogleCredential : ICredential
	{
		public string ServerAuthCode { get; }

		public GoogleCredential(string serverAuthCode)
		{
			if (string.IsNullOrEmpty(serverAuthCode))
			{
				throw new ArgumentNullException("serverAuthCode");
			}
			ServerAuthCode = serverAuthCode;
		}
	}
}
