using System;

namespace Axlebolt.Bolt.Auth
{
	public class GameCenterCredential : ICredential
	{
		public string PlayerId { get; }

		public string BundleId { get; }

		public string PublicKeyUrl { get; }

		public byte[] Signature { get; }

		public long Timestamp { get; }

		public byte[] Salt { get; }

		public string DefaultName { get; }

		public GameCenterCredential(string playerId, string bundleId, string publicKeyUrl, byte[] signature, long timestamp, byte[] salt, string defaultName)
		{
			if (string.IsNullOrEmpty(playerId))
			{
				throw new ArgumentNullException("playerId");
			}
			if (string.IsNullOrEmpty(bundleId))
			{
				throw new ArgumentNullException("bundleId");
			}
			if (string.IsNullOrEmpty(publicKeyUrl))
			{
				throw new ArgumentNullException("publicKeyUrl");
			}
			if (string.IsNullOrEmpty(defaultName))
			{
				throw new ArgumentNullException("defaultName");
			}
			PlayerId = playerId;
			BundleId = bundleId;
			PublicKeyUrl = publicKeyUrl;
			Signature = signature;
			Timestamp = timestamp;
			Salt = salt;
			DefaultName = defaultName;
		}
	}
}
