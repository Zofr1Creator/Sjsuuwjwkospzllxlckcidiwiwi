using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Player.Events;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Avatar
{
    public class BoltAvatarService : BoltService<BoltAvatarService>
    {
        public readonly BoltEvent<AvatarLoadedEventArgs> AvatarsLoadedEvent = new BoltEvent<AvatarLoadedEventArgs>();

        private readonly AvatarRemoteService _friendsRemoteService;

        private readonly string _path;

        private readonly ConcurrentQueue<BoltAvatar> _asyncByPassCacheType = new ConcurrentQueue<BoltAvatar>();

        private readonly ConcurrentQueue<BoltAvatar> _asyncUseCacheType = new ConcurrentQueue<BoltAvatar>();

        internal BoltAvatarService(string path)
        {
            if (path == null)
            {
                throw new ArgumentNullException("path");
            }
            _path = Path.Combine(path, "bolt_avatars");
            if (!Directory.Exists(_path))
            {
                Directory.CreateDirectory(_path);
            }
            _friendsRemoteService = new AvatarRemoteService(BoltPlayerApi.Instance.ClientService);
            RpcSupport.Logger.Debug($"BoltAvatars path is {_path}");
            BoltPlayerApi.Instance.AddJob(ProcessQueue);
        }

        internal override void Load()
        {
        }

        internal override void Unload()
        {
        }

        private void ProcessQueue()
        {
            HashSet<BoltAvatar> hashSet = new HashSet<BoltAvatar>();
            BoltAvatar result;
            while (_asyncUseCacheType.TryDequeue(out result))
            {
                hashSet.Add(result);
            }
            HashSet<BoltAvatar> hashSet2 = new HashSet<BoltAvatar>();
            while (_asyncByPassCacheType.TryDequeue(out result))
            {
                hashSet2.Add(result);
            }
            try
            {
                if (hashSet.Count > 0)
                {
                    LoadAvatar(hashSet, BoltCacheMode.Use);
                    AvatarsLoadedEvent.Invoke(new AvatarLoadedEventArgs(hashSet, null));
                }
            }
            catch (Exception ex)
            {
                AvatarsLoadedEvent.Invoke(new AvatarLoadedEventArgs(hashSet, ex));
            }
            try
            {
                if (hashSet2.Count > 0)
                {
                    LoadAvatar(hashSet2, BoltCacheMode.ByPass);
                    AvatarsLoadedEvent.Invoke(new AvatarLoadedEventArgs(hashSet2, null));
                }
            }
            catch (Exception ex2)
            {
                AvatarsLoadedEvent.Invoke(new AvatarLoadedEventArgs(hashSet2, ex2));
            }
        }

        public void LoadAvatarAsync(BoltAvatar player, BoltCacheMode cacheMode)
        {
            if (cacheMode == BoltCacheMode.ByPass)
            {
                if (!_asyncByPassCacheType.Contains(player))
                {
                    _asyncByPassCacheType.Enqueue(player);
                }
            }
            else if (!_asyncUseCacheType.Contains(player))
            {
                _asyncUseCacheType.Enqueue(player);
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void LoadAvatar(BoltAvatar player, BoltCacheMode cacheMode)
        {
            LoadAvatar(new BoltAvatar[1] { player }, cacheMode);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void LoadAvatar(IEnumerable<BoltAvatar> players, BoltCacheMode cacheMode)
        {
            players = players.Where((BoltAvatar player) => !string.IsNullOrEmpty(player.Id) && player.Data == null).ToArray();
            LoadFromCache(players);
            LoadFromServer(players, cacheMode);
        }

        private void LoadFromServer(IEnumerable<BoltAvatar> players, BoltCacheMode cacheMode)
        {
            players = players.Where((BoltAvatar player) => !IsCached(player.Id)).ToArray();
            if (!players.Any())
            {
                return;
            }
            Dictionary<string, byte[]> fromServer = GetFromServer(players.Select((BoltAvatar player) => player.Id).ToArray());
            foreach (BoltAvatar player in players)
            {
                if (fromServer.ContainsKey(player.Id))
                {
                    player.Data = fromServer[player.Id];
                    if (player.Data.Length == 0)
                    {
                        player.Data = null;
                    }
                }
            }
            if (cacheMode == BoltCacheMode.ByPass)
            {
                return;
            }
            foreach (BoltAvatar player2 in players)
            {
                SaveToCache(player2.Id, player2.Data);
            }
        }

        private void LoadFromCache(IEnumerable<BoltAvatar> players)
        {
            foreach (BoltAvatar item in players.Where((BoltAvatar player) => IsCached(player.Id)))
            {
                item.Data = GetFromCache(item.Id);
            }
        }

        private Dictionary<string, byte[]> GetFromServer(string[] avatarIds)
        {
            AvatarBinary[] avatars = _friendsRemoteService.GetAvatars(avatarIds);
            Dictionary<string, byte[]> dictionary = new Dictionary<string, byte[]>();
            AvatarBinary[] array = avatars;
            foreach (AvatarBinary avatarBinary in array)
            {
                dictionary[avatarBinary.Id] = avatarBinary.Avatar?.ToByteArray();
            }
            return dictionary;
        }

        public byte[] GetFromCache(string avatarId)
        {
            try
            {
                string avatarPath = GetAvatarPath(avatarId);
                return File.ReadAllBytes(avatarPath);
            }
            catch (Exception msg)
            {
                Logger.Error(msg);
                return new byte[0];
            }
        }

        public void SaveToCache(string avatarId, byte[] bytes)
        {
            try
            {
                if (bytes != null)
                {
                    string avatarPath = GetAvatarPath(avatarId);
                    File.WriteAllBytes(avatarPath, bytes);
                }
            }
            catch (Exception msg)
            {
                Logger.Error(msg);
            }
        }

        public bool IsCached(string avatarId)
        {
            return File.Exists(GetAvatarPath(avatarId));
        }

        private string GetAvatarPath(string avatarId)
        {
            return Path.Combine(_path, avatarId + ".jpg");
        }
    }
}