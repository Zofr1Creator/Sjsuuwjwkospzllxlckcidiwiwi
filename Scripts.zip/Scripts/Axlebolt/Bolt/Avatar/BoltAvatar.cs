using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Axlebolt.Bolt.Avatar
{
    public class BoltAvatar
    {
        public string Id { get; }

        public byte[] Data { get; set; }

        private BoltAvatar(string id, byte[] data)
        {
            Id = id;
            Data = data;
        }

        public static BoltAvatar Create(string id, byte[] data = null)
        {
            /*if (string.IsNullOrEmpty(id))
                return null;*/

            /*try
            {
                return new BoltAvatar(id, data);
            }
            catch (Exception ex)
            {
                Debug.LogError($"Avatar creation failed: {ex.Message}");
                return null;
            }*/

            return new BoltAvatar(id, data);
        }
    }
}
