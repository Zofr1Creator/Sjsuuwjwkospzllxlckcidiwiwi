namespace Axlebolt.Bolt.Discovery
{
	public class Response
	{
		public FieldDiscovery[] Discovery { get; internal set; }
	}
}
