namespace Axlebolt.Bolt.Discovery
{
	public class FieldCheck
	{
		public string Node { get; internal set; }

		public string CheckID { get; internal set; }

		public string Name { get; internal set; }

		public string Status { get; internal set; }

		public string ServiceID { get; internal set; }

		public string ServiceName { get; internal set; }
	}
}
