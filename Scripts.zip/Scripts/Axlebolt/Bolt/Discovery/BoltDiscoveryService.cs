namespace Axlebolt.Bolt.Discovery
{
	public class BoltDiscoveryService : BoltService<BoltDiscoveryService>
	{
		private const string STATUS_OK = "passing";

		internal override void Load()
		{
			DiscoverNodes();
		}

		public void DiscoverNodes()
		{
		}

		public string GetNodeURL()
		{
			return null;
		}
	}
}
