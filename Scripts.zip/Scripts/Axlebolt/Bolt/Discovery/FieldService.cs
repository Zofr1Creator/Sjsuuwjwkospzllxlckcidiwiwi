namespace Axlebolt.Bolt.Discovery
{
	public class FieldService
	{
		public string ID { get; internal set; }

		public string Service { get; internal set; }

		public string Address { get; internal set; }

		public int Port { get; internal set; }
	}
}
