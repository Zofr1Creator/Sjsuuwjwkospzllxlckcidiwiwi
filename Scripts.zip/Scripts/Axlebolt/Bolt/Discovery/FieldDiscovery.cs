namespace Axlebolt.Bolt.Discovery
{
	public class FieldDiscovery
	{
		public FieldNode Node { get; internal set; }

		public FieldService Service { get; internal set; }

		public FieldCheck[] Checks { get; internal set; }
	}
}
