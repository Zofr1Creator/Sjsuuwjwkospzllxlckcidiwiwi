namespace Axlebolt.Bolt.Discovery
{
	public class FieldNode
	{
	}
}
