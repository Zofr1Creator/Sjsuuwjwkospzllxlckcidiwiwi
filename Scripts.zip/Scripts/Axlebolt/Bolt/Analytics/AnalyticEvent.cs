namespace Axlebolt.Bolt.Analytics
{
	public class AnalyticEvent
	{
		public string Category { get; set; }

		public string Event { get; set; }

		public int Value { get; set; }

		public bool Increment { get; set; }

		public AnalyticEvent(string category, string @event, int value, bool increment)
		{
			Category = category;
			Event = @event;
			Value = value;
			Increment = increment;
		}
	}
}
