using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Analytics
{
    public class BoltAnalytics : BoltService<BoltAnalytics>
    {
        private readonly AnalyticsRemoteService _analyticsRemoteService;

        private readonly ConcurrentQueue<AnalyticEvent> _queue;

        private readonly BoltPlayerApi boltPlayerApi;

        private readonly BoltGameServerApi boltGameServerApi;

        private const int MaxEventsPerRequest = 20;

        public BoltAnalytics()
        {
            _queue = new ConcurrentQueue<AnalyticEvent>();
            if (BoltPlayerApi.IsInitialized)
            {
                boltPlayerApi = BoltPlayerApi.Instance;
                _analyticsRemoteService = new AnalyticsRemoteService(BoltPlayerApi.Instance.ClientService);
                boltPlayerApi.AddJob(ProcessQueue);
            }
            else
            {
                boltGameServerApi = BoltGameServerApi.Instance;
                _analyticsRemoteService = new AnalyticsRemoteService(BoltGameServerApi.Instance.ClientService);
                boltGameServerApi.AddJob(ProcessQueue);
            }
        }

        internal override void Load()
        {
        }

        internal override void Unload()
        {
        }

        private void ProcessQueue()
        {
            if (!IsBoltConnected())
            {
                return;
            }
            List<AnalyticEvent> list = new List<AnalyticEvent>();
            AnalyticEvent result;
            while (_queue.TryDequeue(out result))
            {
                list.Add(result);
                if (list.Count > 20)
                {
                    break;
                }
            }
            WorkerSend(list);
        }

        public void SendEventInc(string category, string @event, int count = 1)
        {
            _queue.Enqueue(new AnalyticEvent(category, @event, count, increment: true));
        }

        public void SendEventValue(string category, string @event, int value)
        {
            _queue.Enqueue(new AnalyticEvent(category, @event, value, increment: false));
        }

        public int QueuedEvents()
        {
            return _queue.Count;
        }

        private void WorkerSend(List<AnalyticEvent> events)
        {
            try
            {
                if (IsBoltConnected())
                {
                    SendRequestViaRpc(events);
                }
                else
                {
                    Logger.Debug("Bolt isn't connected. Send via RPC failed.");
                }
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
            }
        }

        private bool IsBoltConnected()
        {
            if (BoltPlayerApi.IsInitialized)
            {
                return boltPlayerApi.IsConnectedAndReady;
            }
            return BoltGameServerApi.IsInitialized && boltGameServerApi.IsConnectedAndReady;
        }

        private void SendRequestViaRpc(List<AnalyticEvent> events)
        {
            if (events.Count != 0)
            {
                UserEvent[] array = new UserEvent[events.Count];
                for (int i = 0; i < events.Count; i++)
                {
                    AnalyticEvent analyticEvent = events[i];
                    array[i] = new UserEvent
                    {
                        Category = analyticEvent.Category,
                        Event = analyticEvent.Event,
                        Value = analyticEvent.Value,
                        Increment = analyticEvent.Increment
                    };
                }
                _analyticsRemoteService.Event(array);
                if (Logger.LogDebug)
                {
                    Logger.Debug($"{events.Count} events were successfully sent!");
                }
            }
        }
    }
}
