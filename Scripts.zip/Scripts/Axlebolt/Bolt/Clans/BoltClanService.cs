using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Api.Exception;
using Axlebolt.Bolt.Clans.Event;
using Axlebolt.Bolt.Clans.Exception;
using Axlebolt.Bolt.Clans.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans
{
	public class BoltClanService : BoltService<BoltClanService>
	{
		public class ClansRemoteEventListener : IClansRemoteEventListener
		{
			private readonly BoltClanService _service;

			private readonly PlayerAttributesMapper _playerAttributesMapper = new PlayerAttributesMapper();

			public ClansRemoteEventListener(BoltClanService boltClanService)
			{
				_service = boltClanService;
			}

			public void OnMemberJoinedToClan(OnMemberJoinedToClanEvent arg)
			{
				BoltClanMember boltClanMember = BoltClanMemberMapper.Instance.ToOriginal(arg.ClanMember);
				_service._clanMembers.TryAdd(boltClanMember.Id, boltClanMember);
				_service.InvokeOnClanMemberJoined(boltClanMember);
			}

			public void OnJoinedToClan(OnJoinedToClanEvent arg)
			{
				BoltClan clan = BoltClanMapper.Instance.ToOriginal(arg.Clan);
				_service._clan = clan;
				IEnumerable<BoltClanMember> allClanMembers = _service.GetAllClanMembers();
				foreach (BoltClanMember item in allClanMembers)
				{
					_service._clanMembers.TryAdd(item.Id, item);
				}
				_service.InvokeOnJoinedToClan(clan);
			}

			public void OnLeftFromClan(OnLeftFromClan arg0)
			{
				if (!_service._clanMembers.ContainsKey(arg0.MemberId))
				{
					throw new BoltClansException($"Member with id {arg0.MemberId} not found!");
				}
				BoltClanMember boltClanMember = _service._clanMembers[arg0.MemberId];
				if (!boltClanMember.Player.Id.Equals(BoltService<BoltPlayerService>.Instance.Player.Id))
				{
					_service._clanMembers.TryRemove(boltClanMember.Id, out var _);
					_service.InvokeOnMemberLeftFromClan(boltClanMember);
				}
			}

			public void OnClanUpgrade(OnClanUpgradeEvent onClanUpgradeEvent)
			{
				_service._clan.Level = onClanUpgradeEvent.ClanLevel.LevelNumber;
				_service.InvokeOnClanUpgrade(onClanUpgradeEvent.ClanLevel.LevelNumber, onClanUpgradeEvent.ClanLevel.MaxMembersCount);
			}

			public void OnJoinRequestTaken(OnJoinRequestTakenEvent arg0)
			{
				BoltPlayer player = PlayerMapper.Instance.ToOriginal(arg0.Player);
				_service.InvokeOnJoinRequestTaken(player, arg0.RequestId);
			}

			public void OnInvitedToClanEvent(OnInvitedToClanEvent arg0)
			{
				BoltClan clan = BoltClanMapper.Instance.ToOriginal(arg0.Clan);
				BoltPlayer player = PlayerMapper.Instance.ToOriginal(arg0.Player);
				_service.InvokeOnInvitedToClan(player, clan, arg0.RequestId);
			}

			public void OnClanNameChanged(OnClanNameChanged arg0)
			{
				_service._clan.Name = arg0.NewName;
				_service.InvokeOnClanNameChanged(arg0.NewName);
			}

			public void OnKickedEvent(OnKickedEvent arg0)
			{
				_service._clanMembers.Clear();
				_service._clan = null;
				_service._clanMemberRoles.Clear();
				_service._unreadMessagesCount = 0;
				_service.InvokeOnKicked(arg0.KickingReason);
			}

			public void OnKickedMember(OnKickedMemberEvent arg0)
			{
				if (!_service._clanMembers.ContainsKey(arg0.KickedMemberId))
				{
					throw new BoltClansException($"Member with id {arg0.KickedMemberId} not found!");
				}
				if (!_service._clanMembers.ContainsKey(arg0.KickerMemberId))
				{
					throw new BoltClansException($"Member with id {arg0.KickerMemberId} not found!");
				}
				BoltClanMember kickerMember = _service._clanMembers[arg0.KickerMemberId];
				BoltClanMember kickedMember = _service._clanMembers[arg0.KickedMemberId];
				_service._clanMembers.TryRemove(arg0.KickedMemberId, out var _);
				_service.InvokeOnKickedMember(kickerMember, kickedMember);
			}

			public void OnIncomingClanMessage(OnIncomingClanMessage arg0)
			{
				BoltClanMember clanMember = _service._clanMembers.Values.First((BoltClanMember mem) => mem.Player.Id == arg0.Message.SenderId);
				_service._unreadMessagesCount++;
				_service.InvokeOnIncomingMessage(clanMember, arg0.Message.Message, arg0.Message.Timestamp);
			}

			public void OnClanTypeChanged(OnClanTypeChanged arg0)
			{
				BoltClanType clanType = BoltClanTypeMapper.Instance.ToOriginal(arg0.NewClanType);
				_service._clan.ClanType = clanType;
				_service.InvokeOnClanTypeChanged(clanType);
			}

			public void OnRequestDeclined(OnRequestDeclined arg0)
			{
				BoltPlayer player = PlayerMapper.Instance.ToOriginal(arg0.InvitedPlayer);
				BoltClan clan = BoltClanMapper.Instance.ToOriginal(arg0.ClanToJoin);
				BoltClanRequestType requestType = BoltClanRequestTypeMapper.Instance.ToOriginal(arg0.RequestType);
				_service.InvokeOnRequestDeclined(requestType, player, clan);
			}

			public void OnAssignedRoleEvent(OnAssignedRoleEvent arg0)
			{
				if (!_service._clanMembers.ContainsKey(arg0.AssignatorMemberId))
				{
					throw new BoltClansException($"Member with id {arg0.AssignatorMemberId} not found!");
				}
				if (!_service._clanMembers.ContainsKey(arg0.AssigningMemberId))
				{
					throw new BoltClansException($"Member with id {arg0.AssigningMemberId} not found!");
				}
				BoltClanMember assignatorMember = _service._clanMembers[arg0.AssignatorMemberId];
				BoltClanMember boltClanMember = _service._clanMembers[arg0.AssigningMemberId];
				BoltClanMemberRole boltClanMemberRole = BoltClanMemberRoleMapper.Instance.ToOriginal(arg0.NewRole);
				if (boltClanMember.Player.Id.Equals(BoltService<BoltPlayerService>.Instance.Player.Id))
				{
					_service.InvokeOnAssignedRole(boltClanMemberRole, assignatorMember);
				}
				else
				{
					_service.InvokeOnAssignedRoleToMember(boltClanMemberRole, assignatorMember, boltClanMember);
				}
				_service._clanMembers[arg0.AssigningMemberId].Role = boltClanMemberRole;
			}

			public void OnPlayerAttributesChanged(OnPlayerAttributesChanged arg)
			{
				if (_service._clanMembers.ContainsKey(arg.PlayerId))
				{
					BoltClanMember boltClanMember = _service._clanMembers[arg.PlayerId];
					boltClanMember.Player.SetAttributes(_playerAttributesMapper.ToOriginalMap(arg.Attributes.Map));
				}
			}
		}

		private readonly ClanRemoteService _clanRemoteService;

		private BoltClan _clan;

		private readonly ClansRemoteEventListener _remoteEventListener;

		public readonly BoltEvent<ClanMemberJoinedEventArgs> ClanMemberJoinedEvent = new BoltEvent<ClanMemberJoinedEventArgs>();

		public readonly BoltEvent<JoinedToClanEventArgs> JoinedToClanEvent = new BoltEvent<JoinedToClanEventArgs>();

		public readonly BoltEvent<OnLeftFromClanEventArgs> OnMemberLeftFromClanEvent = new BoltEvent<OnLeftFromClanEventArgs>();

		public readonly BoltEvent<OnJoinRequestTakenEventArgs> OnJoinRequestTakenEvent = new BoltEvent<OnJoinRequestTakenEventArgs>();

		public readonly BoltEvent<OnInvitedToClanEventArgs> OnInvitedToClanEvent = new BoltEvent<OnInvitedToClanEventArgs>();

		public readonly BoltEvent<OnClanNameChangedEventArgs> OnClanNameChangedEvent = new BoltEvent<OnClanNameChangedEventArgs>();

		public readonly BoltEvent<OnKickedEventArgs> OnKickedEvent = new BoltEvent<OnKickedEventArgs>();

		public readonly BoltEvent<OnKickedMemberEventArgs> OnKickedMemberEvent = new BoltEvent<OnKickedMemberEventArgs>();

		public readonly BoltEvent<OnIncomingMessageEventArgs> OnIncomingMessageEvent = new BoltEvent<OnIncomingMessageEventArgs>();

		public readonly BoltEvent<OnClanTypeChangedArgs> OnClanTypeChangedEvent = new BoltEvent<OnClanTypeChangedArgs>();

		public readonly BoltEvent<OnRequestDeclinedEventArgs> OnRequestDeclinedEvent = new BoltEvent<OnRequestDeclinedEventArgs>();

		public readonly BoltEvent<OnAssignedRoleEventArgs> OnAssignedRoleEvent = new BoltEvent<OnAssignedRoleEventArgs>();

		public readonly BoltEvent<OnAssignedToMemberEventArgs> OnAssignedToMemberEvent = new BoltEvent<OnAssignedToMemberEventArgs>();

		public readonly BoltEvent<OnClanUpgradeEventArgs> OnClanUpgradeEvent = new BoltEvent<OnClanUpgradeEventArgs>();

		private readonly ConcurrentDictionary<string, BoltClanMember> _clanMembers;

		private readonly Dictionary<string, BoltClanMemberRole> _clanMemberRoles;

		private readonly Dictionary<int, BoltClanLevel> _clanLevels;

		private int _unreadMessagesCount;

		internal BoltClanService()
		{
			_clanRemoteService = new ClanRemoteService(BoltPlayerApi.Instance.ClientService);
			_clanMembers = new ConcurrentDictionary<string, BoltClanMember>();
			_remoteEventListener = new ClansRemoteEventListener(this);
			_clanMemberRoles = new Dictionary<string, BoltClanMemberRole>();
			_clanLevels = new Dictionary<int, BoltClanLevel>();
		}

		internal override void BindEvents()
		{
			BoltPlayerApi.Instance.AddEventListener(_remoteEventListener);
		}

		internal override void UnbindEvents()
		{
			BoltPlayerApi.Instance.RemoveEventListener(_remoteEventListener);
		}

		public BoltClan GetClan()
		{
			return _clan;
		}

		public BoltClanMemberRole[] GetRoles()
		{
			return _clanMemberRoles.Values.ToArray();
		}

		public BoltClanLevel[] GetLevels()
		{
			return _clanLevels.Values.ToArray();
		}

		public BoltClanMember[] GetMembers()
		{
			return _clanMembers.Values.ToArray();
		}

		public BoltClanMember GetMember(string memberId)
		{
			if (!_clanMembers.ContainsKey(memberId))
			{
				throw new BoltClansException($"Member with id {memberId} not found!");
			}
			return _clanMembers[memberId];
		}

		public BoltClanMember GetMyMember()
		{
			BoltClanMember boltClanMember = _clanMembers.Values.FirstOrDefault((BoltClanMember member) => member.Player.Id.Equals(BoltService<BoltPlayerService>.Instance.Player.Id));
			if (boltClanMember != null)
			{
				return boltClanMember;
			}
			throw new BoltClansException($"Player with id {BoltService<BoltPlayerService>.Instance.Player.Id} not found!");
		}

		public int GetUnreadMessagesCount()
		{
			return _unreadMessagesCount;
		}

		public Task<BoltClan> CreateClan(string name, string tag, BoltClanType boltClanType)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				Clan proto = _clanRemoteService.CreateClan(name, tag, BoltClanTypeMapper.Instance.ToProto(boltClanType));
				BoltClan boltClan = BoltClanMapper.Instance.ToOriginal(proto);
				_clan = boltClan;
				return boltClan;
			});
		}

		public Task UpgradeClan()
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.UpgradeClan();
			});
		}

		public Task<BoltClan[]> FindClan(string name, string tag, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				Clan[] beans = _clanRemoteService.FindClan(name, tag, page, size);
				return BoltClanMapper.Instance.ToOriginalArray(beans);
			});
		}

		public Task<BoltClan> GetClanById(string id)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				Clan clan = _clanRemoteService.GetClan(id);
				return BoltClanMapper.Instance.ToOriginal(clan);
			});
		}

		public Task<BoltClanOpenRequest[]> GetPlayerOpenRequest(BoltClanRequestType boltClanRequestType, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanOpenRequest[] playerOpenRequests = _clanRemoteService.GetPlayerOpenRequests(BoltClanRequestTypeMapper.Instance.ToProto(boltClanRequestType), page, size);
				return BoltClanOpenRequestMapper.Instance.ToOriginalList(playerOpenRequests).ToArray();
			});
		}

		public Task<BoltClanClosedRequest[]> GetPlayerClosedRequest(BoltClanRequestType boltClanRequestType, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanClosedRequest[] playerClosedRequests = _clanRemoteService.GetPlayerClosedRequests(BoltClanRequestTypeMapper.Instance.ToProto(boltClanRequestType), page, size);
				return BoltClanClosedRequestMapper.Instance.ToOriginalList(playerClosedRequests).ToArray();
			});
		}

		public Task<BoltClanOpenRequest[]> GetClanOpenRequests(BoltClanRequestType boltClanRequestType, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanOpenRequest[] clanOpenRequests = _clanRemoteService.GetClanOpenRequests(BoltClanRequestTypeMapper.Instance.ToProto(boltClanRequestType), page, size);
				return BoltClanOpenRequestMapper.Instance.ToOriginalList(clanOpenRequests).ToArray();
			});
		}

		public Task<BoltClanClosedRequest[]> GetClanClosedRequests(BoltClanRequestType boltClanRequestType, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanClosedRequest[] clanClosedRequests = _clanRemoteService.GetClanClosedRequests(BoltClanRequestTypeMapper.Instance.ToProto(boltClanRequestType), page, size);
				return BoltClanClosedRequestMapper.Instance.ToOriginalList(clanClosedRequests).ToArray();
			});
		}

		public Task RequestToJoinClan(string clanId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.RequestToJoinClan(clanId);
			});
		}

		public Task InviteToClan(string playerId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.InviteToClan(playerId);
			});
		}

		public Task CancelRequest(string requestId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.CancelRequest(requestId);
			});
		}

		public Task DeclineRequest(string requestId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.DeclineRequest(requestId);
			});
		}

		public Task LeaveClan()
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clan = null;
				_clanMembers.Clear();
				_unreadMessagesCount = 0;
				_clanMemberRoles.Clear();
				_clanRemoteService.LeaveClan();
			});
		}

		public Task KickMember(string memberId, string reason)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.KickMember(memberId, reason);
			});
		}

		public Task AssignRole(string memberId, string roleName)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				if (!_clanMembers.ContainsKey(memberId))
				{
					throw new BoltClansException($"Member with id {memberId} not found!");
				}
				BoltClanMemberRole roleByName = GetRoleByName(roleName);
				_clanRemoteService.AssignRoleToMember(memberId, roleName);
				_clanMembers[memberId].Role = roleByName;
			});
		}

		public Task AssignLeaderRole(string memberId, string myNewRoleName)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				if (!_clanMembers.ContainsKey(memberId))
				{
					throw new BoltClansException($"Member with id {memberId} not found!");
				}
				BoltClanMemberRole leaderRole = GetLeaderRole();
				BoltClanMemberRole roleByName = GetRoleByName(myNewRoleName);
				_clanRemoteService.AssignLeaderRole(memberId, myNewRoleName);
				_clanMembers[memberId].Role = leaderRole;
				GetMyMember().Role = roleByName;
			});
		}

		public Task SetClanAvatar(byte[] avatar)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.SetClanAvatar(avatar);
			});
		}

		public Task ChangeClanName(string newName)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.ChangeClanName(newName);
				_clan.Name = newName;
			});
		}

		public Task ChangeClanType(BoltClanType clanType)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanType clanType2 = BoltClanTypeMapper.Instance.ToProto(clanType);
				_clanRemoteService.ChangeClanType(clanType2);
				_clan.ClanType = clanType;
			});
		}

		public Task SendClanMessage(string message)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.SendMsgToClan(message);
			});
		}

		public Task ReadClanMessages()
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_unreadMessagesCount = 0;
				_clanRemoteService.ReadClanMsgs();
			});
		}

		public Task<BoltClanMessage[]> GetClanMessages(int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				ClanUserMessage[] clanMsgs = _clanRemoteService.GetClanMsgs(page, size);
				return BoltClanMessagesMapper.Instance.ToOriginalArray(clanMsgs, _clanMembers).ToArray();
			});
		}

		public Task DeleteClanMessages()
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_clanRemoteService.DeleteClanMsgs();
			});
		}

		private IEnumerable<BoltClanMember> GetAllClanMembers()
		{
			ClanMember[] allClanMembers = _clanRemoteService.GetAllClanMembers();
			return BoltClanMemberMapper.Instance.ToOriginalList(allClanMembers).ToArray();
		}

		private IEnumerable<BoltClanMemberRole> GetClanMemberRoles()
		{
			return BoltClanMemberRoleMapper.Instance.ToOriginalArray(_clanRemoteService.GetRoles());
		}

		private IEnumerable<BoltClanLevel> GetClanLevels()
		{
			return BoltClanLevelMapper.Instance.ToOriginalList(_clanRemoteService.GetLevels());
		}

		internal override void Load()
		{
			try
			{
				_clan = BoltClanMapper.Instance.ToOriginal(_clanRemoteService.GetPlayerClan());
			}
			catch (ClanMemberNotFoundRpcException value)
			{
				Console.WriteLine(value);
				return;
			}
			IEnumerable<BoltClanMemberRole> clanMemberRoles = GetClanMemberRoles();
			foreach (BoltClanMemberRole item in clanMemberRoles)
			{
				_clanMemberRoles.Add(item.Name, item);
			}
			IEnumerable<BoltClanMember> allClanMembers = GetAllClanMembers();
			foreach (BoltClanMember item2 in allClanMembers)
			{
				_clanMembers.TryAdd(item2.Id, item2);
			}
			_unreadMessagesCount = _clanRemoteService.GetUnreadClanMessagesCount();
			IEnumerable<BoltClanLevel> clanLevels = GetClanLevels();
			foreach (BoltClanLevel item3 in clanLevels)
			{
				_clanLevels.Add(item3.LevelNumber, item3);
			}
		}

		internal override void Unload()
		{
			_clan = null;
			_clanMembers.Clear();
			_clanMemberRoles.Clear();
			_unreadMessagesCount = 0;
			_clanLevels.Clear();
		}

		private void InvokeOnClanMemberJoined(BoltClanMember clanMember)
		{
			ClanMemberJoinedEventArgs arg = new ClanMemberJoinedEventArgs
			{
				ClanMember = clanMember
			};
			ClanMemberJoinedEvent.Invoke(arg);
		}

		private void InvokeOnJoinedToClan(BoltClan clan)
		{
			JoinedToClanEventArgs arg = new JoinedToClanEventArgs
			{
				Clan = clan
			};
			JoinedToClanEvent.Invoke(arg);
		}

		private void InvokeOnMemberLeftFromClan(BoltClanMember member)
		{
			OnLeftFromClanEventArgs arg = new OnLeftFromClanEventArgs
			{
				ClanMember = member
			};
			OnMemberLeftFromClanEvent.Invoke(arg);
		}

		private void InvokeOnJoinRequestTaken(BoltPlayer player, string reqId)
		{
			OnJoinRequestTakenEventArgs arg = new OnJoinRequestTakenEventArgs
			{
				Player = player,
				RequestId = reqId
			};
			OnJoinRequestTakenEvent.Invoke(arg);
		}

		private void InvokeOnInvitedToClan(BoltPlayer player, BoltClan clan, string requestId)
		{
			OnInvitedToClanEventArgs arg = new OnInvitedToClanEventArgs
			{
				Clan = clan,
				Player = player,
				RequestId = requestId
			};
			OnInvitedToClanEvent.Invoke(arg);
		}

		private void InvokeOnClanNameChanged(string newName)
		{
			OnClanNameChangedEventArgs arg = new OnClanNameChangedEventArgs
			{
				NewName = newName
			};
			OnClanNameChangedEvent.Invoke(arg);
		}

		private void InvokeOnKicked(string kickingReason)
		{
			OnKickedEventArgs arg = new OnKickedEventArgs
			{
				KickingReason = kickingReason
			};
			OnKickedEvent.Invoke(arg);
		}

		private void InvokeOnKickedMember(BoltClanMember kickerMember, BoltClanMember kickedMember)
		{
			OnKickedMemberEventArgs arg = new OnKickedMemberEventArgs
			{
				KickerMember = kickerMember,
				KickedMember = kickedMember
			};
			OnKickedMemberEvent.Invoke(arg);
		}

		private void InvokeOnIncomingMessage(BoltClanMember clanMember, string message, long timestamp)
		{
			OnIncomingMessageEventArgs arg = new OnIncomingMessageEventArgs
			{
				Message = message,
				Timestamp = timestamp,
				Sender = clanMember
			};
			OnIncomingMessageEvent.Invoke(arg);
		}

		public void InvokeOnClanTypeChanged(BoltClanType clanType)
		{
			OnClanTypeChangedArgs arg = new OnClanTypeChangedArgs
			{
				NewType = clanType
			};
			OnClanTypeChangedEvent.Invoke(arg);
		}

		public void InvokeOnRequestDeclined(BoltClanRequestType requestType, BoltPlayer player, BoltClan clan)
		{
			OnRequestDeclinedEventArgs arg = new OnRequestDeclinedEventArgs
			{
				RequestType = requestType,
				Player = player,
				Clan = clan
			};
			OnRequestDeclinedEvent.Invoke(arg);
		}

		public void InvokeOnAssignedRoleToMember(BoltClanMemberRole newRole, BoltClanMember assignatorMember, BoltClanMember assignedMember)
		{
			OnAssignedToMemberEventArgs arg = new OnAssignedToMemberEventArgs
			{
				NewRole = newRole,
				AssignatorMember = assignatorMember,
				AssignedMember = assignedMember
			};
			OnAssignedToMemberEvent.Invoke(arg);
		}

		public void InvokeOnAssignedRole(BoltClanMemberRole newRole, BoltClanMember assignatorMember)
		{
			OnAssignedRoleEventArgs arg = new OnAssignedRoleEventArgs
			{
				NewRole = newRole,
				AssignatorMember = assignatorMember
			};
			OnAssignedRoleEvent.Invoke(arg);
		}

		public void InvokeOnClanUpgrade(int clanLevelNumber, int maxMembersCount)
		{
			OnClanUpgradeEventArgs arg = new OnClanUpgradeEventArgs
			{
				ClanLevelNumber = clanLevelNumber,
				MaxMembersCount = maxMembersCount
			};
			OnClanUpgradeEvent.Invoke(arg);
		}

		private BoltClanMemberRole GetRoleByName(string name)
		{
			if (!_clanMemberRoles.ContainsKey(name))
			{
				throw new BoltClansException($"Role with name {name} not found!");
			}
			return _clanMemberRoles[name];
		}

		private BoltClanMemberRole GetLeaderRole()
		{
			return _clanMemberRoles.Values.OrderByDescending((BoltClanMemberRole role) => role.Level).First();
		}
	}
}
