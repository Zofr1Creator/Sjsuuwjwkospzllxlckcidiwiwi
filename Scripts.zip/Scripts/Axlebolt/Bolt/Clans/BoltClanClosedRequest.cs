using Axlebolt.Bolt.Clans.Mappers;

namespace Axlebolt.Bolt.Clans
{
	public class BoltClanClosedRequest : BoltClanRequest
	{
		public long CloseDate { get; internal set; }

		public BoltClanRequestClosingReason ClosingReason { get; internal set; }
	}
}
