namespace Axlebolt.Bolt.Clans.Exception
{
	public class BoltClansException : BoltException
	{
		public BoltClansException(string message)
			: base(message)
		{
		}
	}
}
