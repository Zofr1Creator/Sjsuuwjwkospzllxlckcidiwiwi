namespace Axlebolt.Bolt.Clans
{
	public enum BoltClanRequestType
	{
		NoneType = 0,
		JoinRequest = 1,
		InviteRequest = 2
	}
}
