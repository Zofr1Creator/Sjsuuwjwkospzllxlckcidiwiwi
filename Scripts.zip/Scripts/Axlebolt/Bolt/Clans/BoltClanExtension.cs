using System.Collections.Generic;
using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans
{
	public static class BoltClanExtension
	{
		private const string ATTR_CLAN_ID = "CLAN_ID";

		private const string ATTR_CLAN_NAME = "CLAN_NAME";

		private const string ATTR_CLAN_TAG = "CLAN_TAG";

		private const string ATTR_CLAN_AVATAR = "CLAN_AVATAR";

		public static string ClanId(this BoltPlayer player)
		{
			return player.Attributes["CLAN_ID"].stringValue;
		}

		public static string ClanName(this BoltPlayer player)
		{
			return player.Attributes["CLAN_NAME"].stringValue;
		}

		public static string ClanTag(this BoltPlayer player)
		{
			return player.Attributes["CLAN_TAG"].stringValue;
		}

		public static string ClanAvatar(this BoltPlayer player)
		{
			return player.Attributes.ContainsKey("CLAN_AVATAR") ? player.Attributes["CLAN_AVATAR"].stringValue : null;
		}

		public static void SetAttributes(this BoltPlayer player, Dictionary<string, Attribute> arg)
		{
			foreach (KeyValuePair<string, Attribute> item in arg)
			{
				if (player.Attributes.ContainsKey(item.Key))
				{
					player.Attributes[item.Key] = item.Value;
				}
				else
				{
					player.Attributes.Add(item.Key, item.Value);
				}
			}
		}
	}
}
