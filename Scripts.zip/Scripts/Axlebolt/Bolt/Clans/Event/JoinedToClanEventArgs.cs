namespace Axlebolt.Bolt.Clans.Event
{
	public class JoinedToClanEventArgs
	{
		public BoltClan Clan { get; set; }
	}
}
