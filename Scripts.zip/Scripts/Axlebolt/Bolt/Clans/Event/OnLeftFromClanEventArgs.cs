namespace Axlebolt.Bolt.Clans.Event
{
	public class OnLeftFromClanEventArgs
	{
		public BoltClanMember ClanMember { get; internal set; }
	}
}
