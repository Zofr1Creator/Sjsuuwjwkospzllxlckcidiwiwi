namespace Axlebolt.Bolt.Clans.Event
{
	public class OnClanTypeChangedArgs
	{
		public BoltClanType NewType { get; internal set; }
	}
}
