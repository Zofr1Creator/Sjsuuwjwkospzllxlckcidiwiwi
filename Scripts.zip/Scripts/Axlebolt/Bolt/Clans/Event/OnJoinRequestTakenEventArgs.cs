using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans.Event
{
	public class OnJoinRequestTakenEventArgs
	{
		public BoltPlayer Player { get; internal set; }

		public string RequestId { get; internal set; }
	}
}
