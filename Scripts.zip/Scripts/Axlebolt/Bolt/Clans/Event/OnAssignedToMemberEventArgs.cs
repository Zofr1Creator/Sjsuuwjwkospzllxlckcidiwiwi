namespace Axlebolt.Bolt.Clans.Event
{
	public class OnAssignedToMemberEventArgs
	{
		public BoltClanMemberRole NewRole { get; internal set; }

		public BoltClanMember AssignatorMember { get; internal set; }

		public BoltClanMember AssignedMember { get; internal set; }
	}
}
