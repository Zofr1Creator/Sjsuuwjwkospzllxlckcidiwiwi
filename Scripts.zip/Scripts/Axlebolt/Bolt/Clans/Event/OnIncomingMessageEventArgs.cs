namespace Axlebolt.Bolt.Clans.Event
{
	public class OnIncomingMessageEventArgs
	{
		public BoltClanMember Sender { get; internal set; }

		public string Message { get; internal set; }

		public long Timestamp { get; internal set; }
	}
}
