namespace Axlebolt.Bolt.Clans.Event
{
	public class OnKickedEventArgs
	{
		public string KickingReason { get; set; }
	}
}
