namespace Axlebolt.Bolt.Clans.Event
{
	public class OnKickedMemberEventArgs
	{
		public BoltClanMember KickerMember { get; internal set; }

		public BoltClanMember KickedMember { get; internal set; }
	}
}
