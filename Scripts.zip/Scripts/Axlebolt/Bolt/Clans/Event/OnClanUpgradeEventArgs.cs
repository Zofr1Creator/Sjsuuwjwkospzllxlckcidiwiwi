namespace Axlebolt.Bolt.Clans.Event
{
	public class OnClanUpgradeEventArgs
	{
		public int ClanLevelNumber { get; internal set; }

		public int MaxMembersCount { get; internal set; }
	}
}
