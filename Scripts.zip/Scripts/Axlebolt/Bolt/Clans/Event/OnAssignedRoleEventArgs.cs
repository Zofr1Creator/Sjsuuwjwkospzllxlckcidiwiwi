namespace Axlebolt.Bolt.Clans.Event
{
	public class OnAssignedRoleEventArgs
	{
		public BoltClanMemberRole NewRole { get; internal set; }

		public BoltClanMember AssignatorMember { get; internal set; }
	}
}
