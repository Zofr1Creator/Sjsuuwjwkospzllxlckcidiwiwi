using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans.Event
{
	public class OnInvitedToClanEventArgs
	{
		public BoltClan Clan { get; internal set; }

		public BoltPlayer Player { get; internal set; }

		public string RequestId { get; internal set; }
	}
}
