using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans.Event
{
	public class OnRequestDeclinedEventArgs
	{
		public BoltClanRequestType RequestType { get; internal set; }

		public BoltPlayer Player { get; internal set; }

		public BoltClan Clan { get; internal set; }
	}
}
