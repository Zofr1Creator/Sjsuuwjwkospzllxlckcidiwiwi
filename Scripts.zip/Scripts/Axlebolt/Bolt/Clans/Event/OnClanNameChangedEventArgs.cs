namespace Axlebolt.Bolt.Clans.Event
{
	public class OnClanNameChangedEventArgs
	{
		public string NewName { get; internal set; }
	}
}
