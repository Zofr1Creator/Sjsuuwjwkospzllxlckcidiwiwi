namespace Axlebolt.Bolt.Clans.Event
{
	public class ClanMemberJoinedEventArgs
	{
		public BoltClanMember ClanMember { get; internal set; }
	}
}
