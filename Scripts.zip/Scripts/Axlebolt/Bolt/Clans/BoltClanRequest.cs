using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans
{
	public class BoltClanRequest
	{
		public string Id { get; internal set; }

		public BoltClan Clan { get; internal set; }

		public BoltPlayer RequestSender { get; internal set; }

		public long CreateDate { get; internal set; }

		public BoltClanRequestType RequestType { get; internal set; }

		public BoltPlayer InvitedPlayer { get; internal set; }
	}
}
