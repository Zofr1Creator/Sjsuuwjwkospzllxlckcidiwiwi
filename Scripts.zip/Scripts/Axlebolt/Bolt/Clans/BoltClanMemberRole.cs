namespace Axlebolt.Bolt.Clans
{
	public class BoltClanMemberRole
	{
		public string Id { get; set; }

		public string Name { get; set; }

		public int Level { get; set; }

		public string Descripption { get; set; }

		public BoltClanMemberRolePermission[] Permissions { get; internal set; }
	}
}
