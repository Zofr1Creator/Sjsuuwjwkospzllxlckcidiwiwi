namespace Axlebolt.Bolt.Clans
{
	public enum BoltClanType
	{
		Closed = 0,
		InviteOnly = 1,
		Open = 2
	}
}
