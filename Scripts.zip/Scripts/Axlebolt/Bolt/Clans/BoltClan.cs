namespace Axlebolt.Bolt.Clans
{
	public class BoltClan
	{
		public string Id { get; internal set; }

		public string AvatarId { get; internal set; }

		public string Name { get; internal set; }

		public string Tag { get; internal set; }

		public int Level { get; internal set; }

		public BoltClanType ClanType { get; internal set; }

		public long CreateDate { get; internal set; }
	}
}
