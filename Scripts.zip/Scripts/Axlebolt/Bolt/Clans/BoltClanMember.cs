using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Clans
{
	public class BoltClanMember
	{
		public string Id { get; internal set; }

		public BoltPlayer Player { get; internal set; }

		public string ClanId { get; internal set; }

		public BoltClanMemberRole Role { get; internal set; }

		public long CreateDate { get; internal set; }
	}
}
