namespace Axlebolt.Bolt.Clans
{
	public enum BoltClanMemberRolePermission
	{
		ChangeClanSettings = 0,
		AcceptMember = 1,
		InviteMamber = 2,
		KickMemberLess = 3,
		KickMemberEqual = 4,
		AssignRoleLess = 5,
		AssignRoleEqual = 6,
		CreateClanBattle = 7,
		JoinClanBattle = 8
	}
}
