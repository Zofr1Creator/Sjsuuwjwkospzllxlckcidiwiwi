namespace Axlebolt.Bolt.Clans
{
	public class BoltClanMessage
	{
		public BoltClanMember RequestSender { get; internal set; }

		public long Timestamp { get; internal set; }

		public string Message { get; internal set; }
	}
}
