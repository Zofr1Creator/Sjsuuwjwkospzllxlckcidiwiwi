using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.Clans
{
	public class BoltClanLevel
	{
		public int LevelNumber { get; internal set; }

		public int MaxMembersCount { get; internal set; }

		public BoltCurrencyAmounts LevelUpCost { get; internal set; }

		public Dictionary<string, string> CustomProperties { get; internal set; }
	}
}
