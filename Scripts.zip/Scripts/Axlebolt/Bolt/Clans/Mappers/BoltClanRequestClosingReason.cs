namespace Axlebolt.Bolt.Clans.Mappers
{
	public enum BoltClanRequestClosingReason
	{
		AcceptRequest = 0,
		DeclineRequest = 1,
		CancelRequest = 2
	}
}
