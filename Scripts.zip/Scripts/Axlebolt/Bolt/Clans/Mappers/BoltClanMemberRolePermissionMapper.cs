using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanMemberRolePermissionMapper : MessageMapper<ClanMemberRolePermission, BoltClanMemberRolePermission>
	{
		public static readonly BoltClanMemberRolePermissionMapper Instance = new BoltClanMemberRolePermissionMapper();

		public override BoltClanMemberRolePermission ToOriginal(ClanMemberRolePermission proto)
		{
			switch (proto)
			{
			case ClanMemberRolePermission.AcceptMember:
				return BoltClanMemberRolePermission.AcceptMember;
			case ClanMemberRolePermission.InviteMember:
				return BoltClanMemberRolePermission.InviteMamber;
			case ClanMemberRolePermission.AssignRoleLess:
				return BoltClanMemberRolePermission.AssignRoleLess;
			case ClanMemberRolePermission.JoinClanBattle:
				return BoltClanMemberRolePermission.JoinClanBattle;
			case ClanMemberRolePermission.KickMemberLess:
				return BoltClanMemberRolePermission.KickMemberLess;
			case ClanMemberRolePermission.KickMemberEqual:
				return BoltClanMemberRolePermission.KickMemberEqual;
			case ClanMemberRolePermission.CreateClanBattle:
				return BoltClanMemberRolePermission.CreateClanBattle;
			case ClanMemberRolePermission.ChangeClanSettings:
				return BoltClanMemberRolePermission.ChangeClanSettings;
			case ClanMemberRolePermission.AssignRoleEqual:
				return BoltClanMemberRolePermission.AssignRoleEqual;
			default:
				throw new ArgumentOutOfRangeException("proto", proto, null);
			}
		}

		public override ClanMemberRolePermission ToProto(BoltClanMemberRolePermission original)
		{
			switch (original)
			{
			case BoltClanMemberRolePermission.AcceptMember:
				return ClanMemberRolePermission.AcceptMember;
			case BoltClanMemberRolePermission.InviteMamber:
				return ClanMemberRolePermission.InviteMember;
			case BoltClanMemberRolePermission.AssignRoleLess:
				return ClanMemberRolePermission.AssignRoleLess;
			case BoltClanMemberRolePermission.JoinClanBattle:
				return ClanMemberRolePermission.JoinClanBattle;
			case BoltClanMemberRolePermission.KickMemberLess:
				return ClanMemberRolePermission.KickMemberLess;
			case BoltClanMemberRolePermission.AssignRoleEqual:
				return ClanMemberRolePermission.AssignRoleEqual;
			case BoltClanMemberRolePermission.KickMemberEqual:
				return ClanMemberRolePermission.KickMemberEqual;
			case BoltClanMemberRolePermission.CreateClanBattle:
				return ClanMemberRolePermission.CreateClanBattle;
			case BoltClanMemberRolePermission.ChangeClanSettings:
				return ClanMemberRolePermission.ChangeClanSettings;
			default:
				throw new ArgumentOutOfRangeException("original", original, null);
			}
		}
	}
}
