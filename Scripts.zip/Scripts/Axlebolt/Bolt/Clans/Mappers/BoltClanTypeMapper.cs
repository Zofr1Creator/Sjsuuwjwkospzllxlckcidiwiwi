using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanTypeMapper : MessageMapper<ClanType, BoltClanType>
	{
		public static readonly BoltClanTypeMapper Instance = new BoltClanTypeMapper();

		public override BoltClanType ToOriginal(ClanType clanType)
		{
			switch (clanType)
			{
			case ClanType.Open:
				return BoltClanType.Open;
			case ClanType.Closed:
				return BoltClanType.Closed;
			case ClanType.InviteOnly:
				return BoltClanType.InviteOnly;
			default:
				throw new ArgumentOutOfRangeException("clanType", clanType, null);
			}
		}

		public override ClanType ToProto(BoltClanType boltClanType)
		{
			switch (boltClanType)
			{
			case BoltClanType.Open:
				return ClanType.Open;
			case BoltClanType.Closed:
				return ClanType.Closed;
			case BoltClanType.InviteOnly:
				return ClanType.InviteOnly;
			default:
				throw new ArgumentOutOfRangeException("boltClanType", boltClanType, null);
			}
		}
	}
}
