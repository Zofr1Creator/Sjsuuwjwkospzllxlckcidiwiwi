using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanMessagesMapper : MessageMapper<ClanUserMessage, BoltClanMessage>
	{
		public static readonly BoltClanMessagesMapper Instance = new BoltClanMessagesMapper();

		public override BoltClanMessage ToOriginal(ClanUserMessage proto)
		{
			return new BoltClanMessage
			{
				Message = proto.Message,
				Timestamp = proto.Timestamp
			};
		}

		public BoltClanMessage[] ToOriginalArray(IEnumerable<ClanUserMessage> messages, ConcurrentDictionary<string, BoltClanMember> members)
		{
			return messages.Select((ClanUserMessage message) => new BoltClanMessage
			{
				Message = message.Message,
				Timestamp = message.Timestamp,
				RequestSender = members.Values.First((BoltClanMember mem) => mem.Player.Id == message.SenderId)
			}).ToArray();
		}
	}
}
