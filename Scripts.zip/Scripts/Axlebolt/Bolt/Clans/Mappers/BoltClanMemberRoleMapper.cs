using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanMemberRoleMapper : MessageMapper<ClanMemberRole, BoltClanMemberRole>
	{
		public static readonly BoltClanMemberRoleMapper Instance = new BoltClanMemberRoleMapper();

		public override BoltClanMemberRole ToOriginal(ClanMemberRole proto)
		{
			return new BoltClanMemberRole
			{
				Id = proto.Id,
				Name = proto.Name,
				Level = proto.Level,
				Descripption = proto.Descripption,
				Permissions = BoltClanMemberRolePermissionMapper.Instance.ToOriginalArray(proto.Permissions)
			};
		}
	}
}
