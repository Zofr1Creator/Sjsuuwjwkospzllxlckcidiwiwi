using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanMemberMapper : MessageMapper<ClanMember, BoltClanMember>
	{
		public static readonly BoltClanMemberMapper Instance = new BoltClanMemberMapper();

		public override BoltClanMember ToOriginal(ClanMember proto)
		{
			return new BoltClanMember
			{
				Id = proto.Id,
				ClanId = proto.ClanId,
				CreateDate = proto.CreateDate,
				Player = PlayerMapper.Instance.ToOriginal(proto.Player),
				Role = BoltClanMemberRoleMapper.Instance.ToOriginal(proto.Role)
			};
		}
	}
}
