using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanRequestTypeMapper : MessageMapper<RequestType, BoltClanRequestType>
	{
		public static readonly BoltClanRequestTypeMapper Instance = new BoltClanRequestTypeMapper();

		public override BoltClanRequestType ToOriginal(RequestType proto)
		{
			switch (proto)
			{
			case RequestType.NoneType:
				return BoltClanRequestType.NoneType;
			case RequestType.JoinRequest:
				return BoltClanRequestType.JoinRequest;
			case RequestType.InviteRequest:
				return BoltClanRequestType.InviteRequest;
			default:
				throw new ArgumentOutOfRangeException("proto", proto, null);
			}
		}

		public override RequestType ToProto(BoltClanRequestType original)
		{
			switch (original)
			{
			case BoltClanRequestType.NoneType:
				return RequestType.NoneType;
			case BoltClanRequestType.JoinRequest:
				return RequestType.JoinRequest;
			case BoltClanRequestType.InviteRequest:
				return RequestType.InviteRequest;
			default:
				throw new ArgumentOutOfRangeException("original", original, null);
			}
		}
	}
}
