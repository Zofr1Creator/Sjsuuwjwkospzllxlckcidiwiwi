using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanLevelMapper : MessageMapper<ClanLevel, BoltClanLevel>
	{
		public static readonly BoltClanLevelMapper Instance = new BoltClanLevelMapper();

		public override BoltClanLevel ToOriginal(ClanLevel proto)
		{
			return new BoltClanLevel
			{
				LevelNumber = proto.LevelNumber,
				MaxMembersCount = proto.MaxMembersCount,
				LevelUpCost = new BoltCurrencyAmounts { 
				{
					proto.LevelUpCost.CurrencyId,
					proto.LevelUpCost.Value
				} },
				CustomProperties = PropertyToOriginal(proto)
			};
		}

		private Dictionary<string, string> PropertyToOriginal(ClanLevel clanLevel)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (KeyValuePair<string, string> property in clanLevel.Properties)
			{
				dictionary.Add(property.Key, property.Value);
			}
			return dictionary;
		}
	}
}
