using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanMapper : MessageMapper<Clan, BoltClan>
	{
		public static readonly BoltClanMapper Instance = new BoltClanMapper();

		public override BoltClan ToOriginal(Clan proto)
		{
			return new BoltClan
			{
				Id = proto.Id,
				Tag = proto.Tag,
				Name = proto.Name,
				Level = proto.ClanLevel,
				AvatarId = proto.AvatarId,
				CreateDate = proto.CreateDate,
				ClanType = BoltClanTypeMapper.Instance.ToOriginal(proto.ClanType)
			};
		}
	}
}
