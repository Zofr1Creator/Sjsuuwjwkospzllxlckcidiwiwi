using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanRequestClosingReasonMapper : MessageMapper<ClanClosingReason, BoltClanRequestClosingReason>
	{
		public static readonly BoltClanRequestClosingReasonMapper Instance = new BoltClanRequestClosingReasonMapper();

		public override BoltClanRequestClosingReason ToOriginal(ClanClosingReason proto)
		{
			switch (proto)
			{
			case ClanClosingReason.AcceptRequest:
				return BoltClanRequestClosingReason.AcceptRequest;
			case ClanClosingReason.CancelRequest:
				return BoltClanRequestClosingReason.CancelRequest;
			case ClanClosingReason.DeclineRequest:
				return BoltClanRequestClosingReason.DeclineRequest;
			default:
				throw new ArgumentOutOfRangeException("proto", proto, null);
			}
		}

		public override ClanClosingReason ToProto(BoltClanRequestClosingReason original)
		{
			switch (original)
			{
			case BoltClanRequestClosingReason.AcceptRequest:
				return ClanClosingReason.AcceptRequest;
			case BoltClanRequestClosingReason.CancelRequest:
				return ClanClosingReason.CancelRequest;
			case BoltClanRequestClosingReason.DeclineRequest:
				return ClanClosingReason.DeclineRequest;
			default:
				throw new ArgumentOutOfRangeException("original", original, null);
			}
		}
	}
}
