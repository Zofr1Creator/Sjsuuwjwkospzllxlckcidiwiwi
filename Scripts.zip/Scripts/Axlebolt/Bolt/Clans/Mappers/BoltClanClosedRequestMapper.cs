using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanClosedRequestMapper : MessageMapper<ClanClosedRequest, BoltClanClosedRequest>
	{
		public static readonly BoltClanClosedRequestMapper Instance = new BoltClanClosedRequestMapper();

		public override BoltClanClosedRequest ToOriginal(ClanClosedRequest proto)
		{
			return new BoltClanClosedRequest
			{
				Id = proto.ClanRequest.Id,
				Clan = BoltClanMapper.Instance.ToOriginal(proto.ClanRequest.Clan),
				CreateDate = proto.ClanRequest.CreateDate,
				InvitedPlayer = PlayerMapper.Instance.ToOriginal(proto.ClanRequest.InvitedPlayer),
				RequestSender = PlayerMapper.Instance.ToOriginal(proto.ClanRequest.RequestSender),
				RequestType = BoltClanRequestTypeMapper.Instance.ToOriginal(proto.ClanRequest.RequestType),
				ClosingReason = BoltClanRequestClosingReasonMapper.Instance.ToOriginal(proto.ClosingReason),
				CloseDate = proto.CloseDate
			};
		}
	}
}
