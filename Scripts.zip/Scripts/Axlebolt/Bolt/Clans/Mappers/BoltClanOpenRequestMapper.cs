using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Clans.Mappers
{
	public class BoltClanOpenRequestMapper : MessageMapper<ClanOpenRequest, BoltClanOpenRequest>
	{
		public static readonly BoltClanOpenRequestMapper Instance = new BoltClanOpenRequestMapper();

		public override BoltClanOpenRequest ToOriginal(ClanOpenRequest proto)
		{
			return new BoltClanOpenRequest
			{
				Id = proto.ClanRequest.Id,
				Clan = BoltClanMapper.Instance.ToOriginal(proto.ClanRequest.Clan),
				CreateDate = proto.ClanRequest.CreateDate,
				InvitedPlayer = PlayerMapper.Instance.ToOriginal(proto.ClanRequest.InvitedPlayer),
				RequestSender = PlayerMapper.Instance.ToOriginal(proto.ClanRequest.RequestSender),
				RequestType = BoltClanRequestTypeMapper.Instance.ToOriginal(proto.ClanRequest.RequestType)
			};
		}
	}
}
