namespace Axlebolt.Bolt.Clans
{
	public class BoltClanOpenRequest : BoltClanRequest
	{
	}
}
