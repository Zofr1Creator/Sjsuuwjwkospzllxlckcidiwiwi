using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Friends.Mappers
{
	public class RelationshipStatusMapper : EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>
	{
	}
}
