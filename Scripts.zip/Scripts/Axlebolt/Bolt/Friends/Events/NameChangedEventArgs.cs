namespace Axlebolt.Bolt.Friends.Events
{
	public class NameChangedEventArgs
	{
		public string FriendId { get; }

		public string NewName { get; }

		public NameChangedEventArgs(string friendId, string newName)
		{
			FriendId = friendId;
			NewName = newName;
		}

		protected bool Equals(NameChangedEventArgs other)
		{
			return string.Equals(FriendId, other.FriendId) && string.Equals(NewName, other.NewName);
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			if (this == obj)
			{
				return true;
			}
			if (obj.GetType() != GetType())
			{
				return false;
			}
			return Equals((NameChangedEventArgs)obj);
		}

		public override int GetHashCode()
		{
			return (((FriendId != null) ? FriendId.GetHashCode() : 0) * 397) ^ ((NewName != null) ? NewName.GetHashCode() : 0);
		}
	}
}
