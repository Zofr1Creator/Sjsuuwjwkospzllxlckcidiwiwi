namespace Axlebolt.Bolt.Friends.Events
{
	public class FriendshipRequestCountChangedArgs
	{
		public int FriendshiptRequestCount { get; }

		public FriendshipRequestCountChangedArgs(int сount)
		{
			FriendshiptRequestCount = сount;
		}
	}
}
