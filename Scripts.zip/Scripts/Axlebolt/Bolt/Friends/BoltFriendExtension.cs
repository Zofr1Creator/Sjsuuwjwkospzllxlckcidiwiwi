using System.Collections.Generic;
using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Friends
{
	public static class BoltFriendExtension
	{
		public static void SetAttributes(this BoltFriend friend, Dictionary<string, Attribute> arg)
		{
			foreach (KeyValuePair<string, Attribute> item in arg)
			{
				if (friend.Attributes.ContainsKey(item.Key))
				{
					friend.Attributes[item.Key] = item.Value;
				}
				else
				{
					friend.Attributes.Add(item.Key, item.Value);
				}
			}
		}
	}
}
