using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Avatar;
using Axlebolt.Bolt.Friends.Events;
using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Friends
{
	public class BoltFriendsService : BoltService<BoltFriendsService>
	{
		public class FriendsEventListener : IFriendsRemoteEventListener
		{
			private readonly BoltFriendsService _service;

			private readonly PlayerAttributesMapper _playerAttributesMapper = new PlayerAttributesMapper();

			public FriendsEventListener(BoltFriendsService service)
			{
				_service = service;
			}

			public void OnFriendNameChanged(string friendId, string newName)
			{
				if (_service._friends.ContainsKey(friendId))
				{
					_service._friends[friendId].Name = newName;
					NameChangedEventArgs arg = new NameChangedEventArgs(friendId, newName);
					_service.FriendNameChangedEvent.Invoke(arg);
					_service.FriendUpdatedEvent.Invoke(_service._friends[friendId]);
				}
			}

			public void OnNewFriendshipRequest(PlayerFriend playerFriend)
			{
				BoltFriend arg = FriendMapper.Instance.ToOriginal(playerFriend);
				_service.AddFriendshipRequestId(playerFriend.Player.Id);
				_service.NewFriendshipRequestEvent.Invoke(arg);
			}

			public void OnRevokeFriendshipRequest(string friendId)
			{
				_service.RevokeFriendshipEvent.Invoke(friendId);
				_service.RemoveFriendshipRequestId(friendId);
			}

			public void OnPlayerStatusChanged(string friendId, Axlebolt.Bolt.Protobuf.PlayerStatus newStatus)
			{
				if (_service._friends.ContainsKey(friendId))
				{
					BoltFriend boltFriend = _service._friends[friendId];
					boltFriend.PlayerStatus = PlayerStatusMapper.Instance.ToOriginal(newStatus);
					PlayerStatusEventArgs arg = new PlayerStatusEventArgs
					{
						NewPlayerStatus = PlayerStatusMapper.Instance.ToOriginal(newStatus),
						Friend = boltFriend
					};
					_service.FriendOnlineStatusChangeEvent.Invoke(arg);
					_service.FriendUpdatedEvent.Invoke(boltFriend);
				}
			}

			public void OnFriendAdded(PlayerFriend playerFriend)
			{
				BoltFriend boltFriend = FriendMapper.Instance.ToOriginal(playerFriend);
				_service._friends.TryAdd(boltFriend.Id, boltFriend);
				_service.FriendAddedEvent.Invoke(boltFriend);
			}

			public void OnFriendRemoved(string friendId)
			{
				_service.FriendRemovedEvent.Invoke(_service._friends[friendId]);
				_service._friends.TryRemove(friendId, out var _);
			}

			public void OnFriendAvatarChanged(string friendId, string avatarId)
			{
				if (_service._friends.ContainsKey(friendId))
				{
					BoltFriend boltFriend = _service._friends[friendId];
					//boltFriend.AvatarId = avatarId;
					boltFriend.Avatar = BoltAvatar.Create(avatarId, null);
					AvatarEventArgs arg = new AvatarEventArgs(friendId, avatarId);
					_service.FriendAvatarChangeEvent.Invoke(arg);
					_service.FriendUpdatedEvent.Invoke(_service._friends[friendId]);
				}
			}

			public void OnMsgFromFriend(string friendId, string textMessage)
			{
			}

			public void OnPlayerAttributesChanged(OnPlayerAttributesChanged arg)
			{
				if (_service._friends.ContainsKey(arg.PlayerId))
				{
					BoltFriend friend = _service._friends[arg.PlayerId];
					friend.SetAttributes(_playerAttributesMapper.ToOriginalMap(arg.Attributes.Map));
				}
			}
		}

		private readonly FriendsRemoteService _friendsRemoteService;

		private readonly ConcurrentDictionary<string, BoltFriend> _friends;

		public readonly BoltEvent<NameChangedEventArgs> FriendNameChangedEvent = new BoltEvent<NameChangedEventArgs>();

		public readonly BoltEvent<PlayerStatusEventArgs> FriendOnlineStatusChangeEvent = new BoltEvent<PlayerStatusEventArgs>();

		public readonly BoltEvent<AvatarEventArgs> FriendAvatarChangeEvent = new BoltEvent<AvatarEventArgs>();

		public readonly BoltEvent<BoltFriend> FriendUpdatedEvent = new BoltEvent<BoltFriend>();

		public readonly BoltEvent<BoltFriend> FriendAddedEvent = new BoltEvent<BoltFriend>();

		public readonly BoltEvent<BoltFriend> FriendRemovedEvent = new BoltEvent<BoltFriend>();

		public readonly BoltEvent<BoltFriend> NewFriendshipRequestEvent = new BoltEvent<BoltFriend>();

		public readonly BoltEvent<string> RevokeFriendshipEvent = new BoltEvent<string>();

		public readonly BoltEvent<FriendshipRequestCountChangedArgs> FriendshipRequestCountChangedEvent = new BoltEvent<FriendshipRequestCountChangedArgs>();

		private HashSet<string> _friendshipRequestIds;

		private readonly FriendsEventListener _remoteEventListener;

		public BoltFriendsService()
		{
			_friends = new ConcurrentDictionary<string, BoltFriend>();
			_friendsRemoteService = new FriendsRemoteService(BoltPlayerApi.Instance.ClientService);
			_remoteEventListener = new FriendsEventListener(this);
		}

		public int GetFriendshipRequestCount()
		{
			return _friendshipRequestIds.Count;
		}

		internal override void BindEvents()
		{
			BoltPlayerApi.Instance.AddEventListener(_remoteEventListener);
		}

		internal override void UnbindEvents()
		{
			BoltPlayerApi.Instance.RemoveEventListener(_remoteEventListener);
		}

		internal override void Load()
		{
			IEnumerable<PlayerFriend> enumerable = LoadFriends();
			_friends.Clear();
			foreach (PlayerFriend item in enumerable)
			{
				_friends.TryAdd(item.Player.Id, FriendMapper.Instance.ToOriginal(item));
			}
		}

		private IEnumerable<PlayerFriend> LoadFriends()
		{
			string[] playerFriendsIds = _friendsRemoteService.GetPlayerFriendsIds(new Axlebolt.Bolt.Protobuf.RelationshipStatus[1] { Axlebolt.Bolt.Protobuf.RelationshipStatus.RequestInitiator });
			_friendshipRequestIds = new HashSet<string>(playerFriendsIds);
			return _friendsRemoteService.GetPlayerFriends(new Axlebolt.Bolt.Protobuf.RelationshipStatus[1] { Axlebolt.Bolt.Protobuf.RelationshipStatus.Friend }, 0, int.MaxValue);
		}

		public Task<BoltFriend[]> GetFriendsByStatus(RelationshipStatus[] relationshipStatuses, int page, int size)
		{
			if (relationshipStatuses == null)
			{
				throw new ArgumentNullException("relationshipStatuses");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus[] relationshipStatuses2 = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToProto(relationshipStatuses);
				PlayerFriend[] playerFriends = _friendsRemoteService.GetPlayerFriends(relationshipStatuses2, page, size);
				return FriendMapper.Instance.ToOriginalArray(playerFriends);
			});
		}

		public Task<long> GetPlayerFriendsCount(RelationshipStatus[] relationshipStatuses)
		{
			if (relationshipStatuses == null)
			{
				throw new ArgumentNullException("relationshipStatuses");
			}
			return BoltPlayerApi.Instance.Async(() => _friendsRemoteService.GetPlayerFriendsCount(EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToProto(relationshipStatuses)));
		}

		public BoltFriend[] GetFriends()
		{
			return _friends.Values.ToArray();
		}

		public BoltFriend GetFriend(string id)
		{
			_friends.TryGetValue(id, out var value);
			return value;
		}

        public Task<BoltFriend> GetFriendAsync(string id)
        {
            return BoltPlayerApi.Instance.Async(() =>
            {
                PlayerFriend proto = _friendsRemoteService.GetPlayerFriend(id);
                return FriendMapper.Instance.ToOriginal(proto);
            });
        }

        public Task SendFriendRequest(string friendId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				_friendsRemoteService.SendFriendRequest(friendId);
			});
		}

		public Task SendFriendRequest(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.SendFriendRequest(friend.Id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
			});
		}

		public Task RevokeFriendRequest(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.RevokeFriendRequest(friend.Id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
			});
		}

		public Task AcceptFriendRequest(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				string id = friend.Id;
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.AcceptFriendRequest(id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
				InvokeOnFriendAddedEvent(friend);
				RemoveFriendshipRequestId(id);
			});
		}

		public Task IgnoreFriendRequest(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				string id = friend.Id;
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.IgnoreFriendRequest(id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
				RemoveFriendshipRequestId(id);
			});
		}

		public Task BlockFriend(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.BlockFriend(friend.Id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
				InvokeFriendRemovedEvent(friend);
				RemoveFriendshipRequestId(friend.Id);
			});
		}

		public Task UnblockFriend(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.UnblockFriend(friend.Id);
				RelationshipStatus relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				friend.Relationship = relationship;
			});
		}

		public Task RemoveFriend(BoltFriend friend)
		{
			if (friend == null)
			{
				throw new ArgumentNullException("friend");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				Axlebolt.Bolt.Protobuf.RelationshipStatus proto = _friendsRemoteService.RemoveFriend(friend.Id);
				friend.Relationship = EnumMapper<Axlebolt.Bolt.Protobuf.RelationshipStatus, RelationshipStatus>.ToOriginal(proto);
				InvokeFriendRemovedEvent(friend);
			});
		}

		public Task<BoltFriend[]> SearchFriends(string friendIdOrName, int page, int size)
		{
			if (friendIdOrName == null)
			{
				throw new ArgumentNullException("friendIdOrName");
			}
			return BoltPlayerApi.Instance.Async(delegate
			{
				PlayerFriend[] beans = _friendsRemoteService.SearchPlayers(friendIdOrName, page, size);
				return FriendMapper.Instance.ToOriginalArray(beans);
			});
		}

		public Task<BoltFriend> LoadFriend(string playerId)
		{
			return BoltPlayerApi.Instance.Async(() => FriendMapper.Instance.ToOriginal(_friendsRemoteService.GetPlayerFriend(playerId)));
		}

		public Task<long> GetSearchFriendsCount(string friendIdOrName)
		{
			if (friendIdOrName == null)
			{
				throw new ArgumentNullException("friendIdOrName");
			}
			return BoltPlayerApi.Instance.Async(() => _friendsRemoteService.GetPlayersCount(friendIdOrName));
		}

		private void RemoveFriendshipRequestId(string friendId)
		{
			if (_friendshipRequestIds.Remove(friendId))
			{
				FriendshipRequestCountChangedArgs arg = new FriendshipRequestCountChangedArgs(_friendshipRequestIds.Count);
				FriendshipRequestCountChangedEvent.Invoke(arg);
			}
		}

		private void AddFriendshipRequestId(string friendId)
		{
			if (_friendshipRequestIds.Add(friendId))
			{
				FriendshipRequestCountChangedArgs arg = new FriendshipRequestCountChangedArgs(_friendshipRequestIds.Count);
				FriendshipRequestCountChangedEvent.Invoke(arg);
			}
		}

		private void InvokeOnFriendAddedEvent(BoltFriend friend)
		{
			if (_friends.TryAdd(friend.Id, friend))
			{
				FriendAddedEvent.Invoke(friend);
			}
		}

		private void InvokeFriendRemovedEvent(BoltFriend friend)
		{
			if (_friends.TryRemove(friend.Id, out var _))
			{
				FriendRemovedEvent.Invoke(friend);
			}
		}
	}
}
