using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.GameEvents.Events;
using Axlebolt.Bolt.GameEvents.Mappers;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Inventory.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;
using Google.Protobuf.Collections;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltGameEventService : BoltService<BoltGameEventService>
    {
        public class GameEventRemoteEventListener : IGameEventRemoteEventListener
        {
            private readonly BoltGameEventService _service;

            public GameEventRemoteEventListener(BoltGameEventService service)
            {
                _service = service;
            }

            public void OnGamePassChanged(OnGamePassChangedEvent evt)
            {
                if (evt == null) throw new ArgumentNullException(nameof(evt));

                var game = _service.GetGameEvent(evt.EventId);
                if (game == null) return;

                game.Points = evt.Points;
                foreach (var lvl in evt.Levels)
                {
                    var pass = game.GamePasses.FirstOrDefault(p => p.Id == lvl.Key);
                    if (pass != null)
                        pass.CurrentLevel = lvl.Value;
                }

                var ops = BoltInventoryService.Instance.CreateInventoryOps();
                foreach (var cur in evt.Reward?.Currencies)
                    ops.AddAmount(cur.CurrencyId, cur.Value);
                foreach (var item in evt.Reward?.Items)
                    ops.Add(Inventory.Mappers.InventoryItemMapper.Instance.ToOriginal(item));
                ops.Apply();

                var args = new GamePassChangedEventArgs
                {
                    EventId = evt.EventId,
                    Points = evt.Points,
                    Levels = new Dictionary<string, int>(evt.Levels),
                    RewardCurrencies = evt.Reward?.Currencies.ToArray() ?? Array.Empty<CurrencyAmount>(),
                    RewardInventoryItems = evt.Reward?.Items.ToArray() ?? Array.Empty<InventoryItem>()
                };
                _service.GamePassChangedEvent.Invoke(args);
            }
        }

        private readonly GameEventRemoteService _gameEventRemoteService;

        private readonly GameEventMapper _gameEventMapper;

        private readonly GameChallengeMapper _gameChallengeMapper;

        private BoltGameEvent[] _gameEvents;

        private readonly Dictionary<string, BoltGameChallenge[]> _gameChallenges;

        public readonly BoltEvent<GamePassChangedEventArgs> GamePassChangedEvent;

        private readonly GameEventRemoteEventListener _remoteEventListener;

        public BoltGameEventService()
        {
            _gameEventMapper = new GameEventMapper();
            _gameChallengeMapper = new GameChallengeMapper();
            GamePassChangedEvent = new BoltEvent<GamePassChangedEventArgs>();
            _gameChallenges = new Dictionary<string, BoltGameChallenge[]>();

            _gameEventRemoteService = new GameEventRemoteService(BoltPlayerApi.Instance.ClientService);
            _remoteEventListener = new GameEventRemoteEventListener(this);
        }

        internal override void BindEvents() => BoltPlayerApi.Instance.AddEventListener(_remoteEventListener);
        internal override void UnbindEvents() => BoltPlayerApi.Instance.RemoveEventListener(_remoteEventListener);

        internal override void Load()
        {
            _gameChallenges.Clear();

            var response = _gameEventRemoteService.GetCurrentGameEvents();
            _gameEvents = _gameEventMapper.ToOriginalArray(response.GameEvents);
            if (_gameEvents.Length == 0)
                return;

            foreach (var ev in _gameEvents)
            {
                var request = new GetCurrentChallengesRequest
                {
                    GameEventId = ev.Id,
                    Completed = true
                };
                var challengesResp = _gameEventRemoteService.GetCurrentChallenges(request);
                var original = _gameChallengeMapper.ToOriginalArray(challengesResp.Challenges);
                _gameChallenges[ev.Id] = original;
            }
        }

        public BoltGameEvent[] GetGameEvents() => _gameEvents;

        public BoltGameChallenge[] GetGameChallenges(string gameEventId) => _gameChallenges[gameEventId]; 


        public BoltGameChallenge[] GetGameChallenges(string eventId, string type)
        {
            return GetGameChallenges(eventId).Where(gc => gc.Type == type).ToArray();
        }

        public BoltGameEvent GetGameEvent(string eventId)
        {
            return _gameEvents.FirstOrDefault(e => e.Id == eventId);
        }

        public BoltGamePass GetGamePass(string passId)
        {
            return _gameEvents
                .SelectMany(e => e.GamePasses)
                .FirstOrDefault(p => p.Id == passId);
        }

        public BoltGameChallenge GetGameChallenge(string eventId, string challengeId)
        {
            return GetGameChallenges(eventId)
                .FirstOrDefault(c => c.Id == challengeId);
        }

        public Task SetGameChallengeProgressAsync(string gameEventId, string gameChallengeId, int points)
        {
            return BoltPlayerApi.Instance.Async(() =>
            {
                SetGameChallengeProgress(gameEventId, gameChallengeId, points);
            });
        }

        public void SetGameChallengeProgress(string eventId, string challengeId, int points)
        {
            var request = new ProgressChallengeRequest
            {
                GameEventChallengeId = challengeId,
                Points = points
            };

            var response = _gameEventRemoteService.SetChallengeProgress(request, CancellationToken.None);
            if (response == null)
                return;

            var gameEvent = GetGameEvent(eventId);
            if (gameEvent != null)
                gameEvent.Points = response.EventPoints;

            foreach (var kv in response.EventGamePassLevels)
            {
                var pass = GetGamePass(kv.Key);
                if (pass != null)
                    pass.CurrentLevel = kv.Value;
            }

            var challenge = GetGameChallenge(eventId, challengeId);
            if (challenge != null)
                challenge.CurrentPoints = response.ChallengePoints;

            var ops = BoltService<Axlebolt.Bolt.Inventory.BoltInventoryService>.Instance.CreateInventoryOps();

            if (response.EventReward?.Currencies != null)
                foreach (var cur in response.EventReward.Currencies)
                    ops.AddAmount(cur.CurrencyId, cur.Value);

            if (response.EventReward?.Items != null)
                foreach (var item in response.EventReward.Items)
                    ops.Add(Inventory.Mappers.InventoryItemMapper.Instance.ToOriginal(item));

            if (response.ChallengeReward?.Currencies != null)
                foreach (var cur in response.ChallengeReward.Currencies)
                    ops.AddAmount(cur.CurrencyId, cur.Value);

            if (response.ChallengeReward?.Items != null)
                foreach (var item in response.ChallengeReward.Items)
                    ops.Add(Inventory.Mappers.InventoryItemMapper.Instance.ToOriginal(item));

            ops.Apply();
        }

        public int GetCurrentDay(string eventId)
        {
            var ev = GetGameEvent(eventId);
            return ev?.CurrentDay ?? 0;
        }

        public int GetCurrentWeek(string eventId)
        {
            var day = GetCurrentDay(eventId);
            return (day / 7) + 1;
        }

        public async Task SaveChallengeDefinitionAsync(string code, string action, int targetPoints)
        {
            await BoltPlayerApi.Instance.Async(() =>
            {
                _gameEventRemoteService.SaveChallenge(code, action, targetPoints);
            });
        }
    }
}
