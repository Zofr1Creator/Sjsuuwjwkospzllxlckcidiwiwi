using UnityEngine;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.GameEvents.Events
{
    public class GamePassChangedEventArgs
    {
        public string EventId { get; set; }

        public int Points { get; set; }

        public Dictionary<string, int> Levels { get; set; } = new Dictionary<string, int>();

        public CurrencyAmount[] RewardCurrencies { get; set; } = new CurrencyAmount[0];

        public InventoryItem[] RewardInventoryItems { get; set; } = new InventoryItem[0];
    }
}
