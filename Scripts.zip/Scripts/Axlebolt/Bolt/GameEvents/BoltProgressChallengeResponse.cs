using UnityEngine;
using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltProgressChallengeResponse
    {
        public bool Completed { get; set; }

        public int ChallengePoints { get; set; }

        public BoltCurrencyAmount[] ChallengeRewardCurrencies { get; set; } = new BoltCurrencyAmount[0];

        public BoltInventoryItem[] ChallengeRewardInventoryItems { get; set; } = new BoltInventoryItem[0];

        public int EventPoints { get; set; }

        public Dictionary<string, int> Levels { get; set; } = new Dictionary<string, int>();

        public BoltCurrencyAmount[] EventRewardCurrencies { get; set; } = new BoltCurrencyAmount[0];

        public BoltInventoryItem[] EventRewardInventoryItems { get; set; } = new BoltInventoryItem[0];
    }
}
