using System;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.GameEvents;
using Axlebolt.Bolt.Inventory.Mappers;
using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.GameEvents.Mappers
{
    public class GamePassLevelMapper : MessageMapper<GamePassLevel, BoltGamePassLevel>
    {
        public static readonly GamePassLevelMapper Instance = new GamePassLevelMapper();

        public override BoltGamePassLevel ToOriginal(GamePassLevel proto)
        {
            if (proto == null)
                throw new NullReferenceException(nameof(proto));

            return new BoltGamePassLevel(proto.Level, proto.MinPoints, new BoltRewardInfo
            {
                Items = ItemDefinitionAmountMapper.Instance.ToOriginalArray(proto.Reward.Items),
                Currencies = CurrencyAmountMapper.Instance.ToOriginalArray(proto.Reward.Currencies),
                Recipes = RecipeInfoMapper.Instance.ToOriginalArray(proto.Reward.Recipes)
            });
        }
    }
}
