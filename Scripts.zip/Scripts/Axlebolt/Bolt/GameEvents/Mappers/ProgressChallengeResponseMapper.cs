using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.GameEvents;
using Axlebolt.Bolt.Inventory.Mappers;

namespace Axlebolt.Bolt.GameEvents.Mappers
{
    public class ProgressChallengeResponseMapper : MessageMapper<ProgressChallengeResponse, BoltProgressChallengeResponse>
    {
        public static readonly ProgressChallengeResponseMapper Instance = new ProgressChallengeResponseMapper();

        public override BoltProgressChallengeResponse ToOriginal(ProgressChallengeResponse proto)
        {
            var response = new BoltProgressChallengeResponse
            {
                Completed = proto.Completed,
                ChallengePoints = proto.ChallengePoints,
                EventPoints = proto.EventPoints,
                Levels = proto.EventGamePassLevels != null
                    ? new Dictionary<string, int>(proto.EventGamePassLevels)
                    : new Dictionary<string, int>()
            };

            if (proto.ChallengeReward != null)
            {
                if (proto.ChallengeReward.Currencies != null)
                {
                    response.ChallengeRewardCurrencies =
                        CurrencyAmountMapper.Instance.ToOriginalArray(proto.ChallengeReward.Currencies);
                }

                if (proto.ChallengeReward.Items != null)
                {
                    response.ChallengeRewardInventoryItems =
                        InventoryItemMapper.Instance.ToOriginalArray(proto.ChallengeReward.Items);
                }
            }
            
            if (proto.EventReward != null)
            {
                if (proto.EventReward.Currencies != null)
                {
                    response.EventRewardCurrencies =
                        CurrencyAmountMapper.Instance.ToOriginalArray(proto.EventReward.Currencies);
                }

                if (proto.EventReward.Items != null)
                {
                    response.EventRewardInventoryItems =
                        InventoryItemMapper.Instance.ToOriginalArray(proto.EventReward.Items);
                }
            }

            return response;
        }
    }
}
