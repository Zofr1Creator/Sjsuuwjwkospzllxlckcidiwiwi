using System;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.GameEvents;

namespace Axlebolt.Bolt.GameEvents.Mappers
{
    public class GameEventMapper : MessageMapper<CurrentGameEvent, BoltGameEvent>
    {
        public static readonly GameEventMapper Instance = new GameEventMapper();

        public override BoltGameEvent ToOriginal(CurrentGameEvent proto)
        {
            if (proto == null)
                throw new NullReferenceException();

            return new BoltGameEvent
            {
                Id = proto.Id,
                Code = proto.Code,
                DateSince = proto.DateSince,
                DateUntil = proto.DateUntil,
                CurrentDay = proto.CurrentDay,
                DurationDays = proto.DurationDays,
                Points = proto.Points,
                GamePasses = GamePassMapper.Instance.ToOriginalArray(proto.GamePasses)
            };
        }
    }
}
