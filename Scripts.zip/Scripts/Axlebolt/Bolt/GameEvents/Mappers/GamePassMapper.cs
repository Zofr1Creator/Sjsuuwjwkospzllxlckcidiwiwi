using System;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.GameEvents;

namespace Axlebolt.Bolt.GameEvents.Mappers
{
    public class GamePassMapper : MessageMapper<GamePass, BoltGamePass>
    {
        public static readonly GamePassMapper Instance = new GamePassMapper();

        public override BoltGamePass ToOriginal(GamePass proto)
        {
            if (proto == null)
            {
                throw new NullReferenceException();
            }

            return new BoltGamePass(
                id: proto.Id,
                code: proto.Code,
                keyItemDefinitionId: proto.KeyItemDefinitionId,
                gamePassLevels: GamePassLevelMapper.Instance.ToOriginalArray(proto.Levels),
                currentLevel: proto.CurrentLevel
            );
        }
    }
}
