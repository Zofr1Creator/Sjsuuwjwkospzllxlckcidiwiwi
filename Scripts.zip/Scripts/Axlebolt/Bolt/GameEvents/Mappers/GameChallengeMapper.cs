using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.GameEvents;
using Axlebolt.Bolt.Inventory.Mappers;
using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.GameEvents.Mappers
{
    public class GameChallengeMapper : MessageMapper<CurrentChallenge, BoltGameChallenge>
    {
        public static readonly GameChallengeMapper Instance = new GameChallengeMapper();

        /*public override BoltGameChallenge ToOriginal(CurrentChallenge proto)
        {
            var gameChallenge = new BoltGameChallenge
            {
                Id = proto.GameEventChallengeId,
                Code = proto.Code,
                KeyItemDefinitionId = proto.KeyItemDefinitionId,
                Action = proto.Action,
                EventPoints = proto.EventPoints,
                TargetPoints = proto.TargetPoints,
                CurrentPoints = proto.CurrentPoints,
                Name = proto.LocalizedTitle?.Name,
                Description = proto.LocalizedTitle?.Description,
                Type = proto.Type
            };

            if (proto.DayRange != null)
            {
                gameChallenge.DayRange = new Axlebolt.Bolt.Common.DayRange(proto.DayRange.From, proto.DayRange.To);
            }

            if (proto.Reward != null)
            {
                gameChallenge.Reward = new Axlebolt.Bolt.Inventory.BoltRewardInfo
                {
                    Items = proto.Reward.Items != null
                        ? ItemDefinitionAmountMapper.Instance.ToOriginalArray(proto.Reward.Items)
                        : null,
                    Currencies = proto.Reward.Currencies != null
                        ? CurrencyAmountMapper.Instance.ToOriginalArray(proto.Reward.Currencies)
                        : null,
                    Recipes = proto.Reward.Recipes != null
                        ? RecipeInfoMapper.Instance.ToOriginalArray(proto.Reward.Recipes)
                        : null
                };
            }

            return gameChallenge;
        }*/

        public override BoltGameChallenge ToOriginal(CurrentChallenge proto)
        {
            if (proto == null)
                throw new NullReferenceException();

            var challenge = new BoltGameChallenge
            {
                Id = proto.GameEventChallengeId,
                Code = proto.Code,
                KeyItemDefinitionId = proto.KeyItemDefinitionId,
                Action = proto.Action,
                EventPoints = proto.EventPoints,
                TargetPoints = proto.TargetPoints,
                CurrentPoints = proto.CurrentPoints
            };

            if (proto.LocalizedTitle != null)
            {
                challenge.Name = proto.LocalizedTitle.Name;
                challenge.Description = proto.LocalizedTitle.Description;
            }

            if (proto.DayRange != null)
            {
                challenge.DayRange = new Axlebolt.Bolt.Common.DayRange(proto.DayRange.From, proto.DayRange.To);
            }

            if (proto.Type != null)
            {
                challenge.Type = proto.Type;
            }

            if (proto.Reward != null)
            {
                var reward = new BoltRewardInfo();

                if (proto.Reward.Items != null)
                {
                    reward.Items = ItemDefinitionAmountMapper.Instance.ToOriginalArray(proto.Reward.Items);
                }

                if (proto.Reward.Currencies != null)
                {
                    reward.Currencies = CurrencyAmountMapper.Instance.ToOriginalArray(proto.Reward.Currencies);
                }

                if (proto.Reward.Recipes != null)
                {
                    reward.Recipes = RecipeInfoMapper.Instance.ToOriginalArray(proto.Reward.Recipes);
                }

                challenge.Reward = reward;
            }

            return challenge;
        }
    }
}
