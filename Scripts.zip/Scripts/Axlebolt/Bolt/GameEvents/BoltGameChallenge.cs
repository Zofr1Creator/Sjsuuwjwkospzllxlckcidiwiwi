using Axlebolt.Bolt.Common;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Security.Axlebolt.Standoff.Common;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltGameChallenge
    {
        private readonly SafeInt _currentPoints = new SafeInt();

        public string Id { get; set; }

        public string Code { get; set; }

        public int KeyItemDefinitionId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Action { get; set; }

        public DayRange DayRange { get; set; }

        public string Type { get; set; }

        public int EventPoints { get; set; }

        public int TargetPoints { get; set; }

        public int CurrentPoints
        {
            get => _currentPoints.Value;
            set => _currentPoints.Value = value;
        }

        public BoltRewardInfo Reward { get; set; }

        public bool IsCompleted()
        {
            return CurrentPoints >= TargetPoints;
        }
    }
}
