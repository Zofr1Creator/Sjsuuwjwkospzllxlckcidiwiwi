using System.Collections.Generic;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltGamePass
    {
        private readonly Dictionary<int, BoltGamePassLevel> _gamePassLevelByLevel = new Dictionary<int, BoltGamePassLevel>();

        public string Id { get; }

        public string Code { get; }

        public int KeyItemDefinitionId { get; }

        public BoltGamePassLevel[] GamePassLevels { get; }

        public int CurrentLevel { get; set; }

        public BoltGamePass(string id, string code, int keyItemDefinitionId, BoltGamePassLevel[] gamePassLevels, int currentLevel)
        {
            Id = id;
            Code = code;
            KeyItemDefinitionId = keyItemDefinitionId;
            GamePassLevels = gamePassLevels;
            CurrentLevel = currentLevel;

            for (int i = 0; i < gamePassLevels.Length; i++)
            {
                _gamePassLevelByLevel[i] = gamePassLevels[i];
            }
        }

        public BoltGamePassLevel GetGamePassLevel(int level)
        {
            if (_gamePassLevelByLevel.TryGetValue(level, out var gamePassLevel))
            {
                return gamePassLevel;
            }
            return null;
        }
    }
}
