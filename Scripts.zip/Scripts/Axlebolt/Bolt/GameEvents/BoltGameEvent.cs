using UnityEngine;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltGameEvent
    {
        public string Id { get; set; }

        public string Code { get; set; }

        public long DateSince { get; set; }

        public long DateUntil { get; set; }

        public int CurrentDay { get; set; }

        public int DurationDays { get; set; }

        public int DaysLeft => DurationDays - CurrentDay;
        public BoltGamePass[] GamePasses { get; set; }

        public int Points { get; set; }
    }
}
