using Axlebolt.Bolt.Inventory;
using UnityEngine;

namespace Axlebolt.Bolt.GameEvents
{
    public class BoltGamePassLevel
    {
        public int Level { get; set; }

        public int MinPoints { get; set; }

        public BoltRewardInfo Reward { get; set; }

        public BoltGamePassLevel(int level, int minPoints, BoltRewardInfo reward)
        {
            Level = level;
            MinPoints = minPoints;
            Reward = reward;
        }
    }
}
