namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyJoinableChangedEventArgs
	{
		public bool Joinable { get; }

		public LobbyJoinableChangedEventArgs(bool joinable)
		{
			Joinable = joinable;
		}
	}
}
