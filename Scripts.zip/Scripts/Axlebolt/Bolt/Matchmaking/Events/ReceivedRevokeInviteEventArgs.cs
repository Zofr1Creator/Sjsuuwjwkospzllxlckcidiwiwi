using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class ReceivedRevokeInviteEventArgs
	{
		public BoltFriend InviteSender { get; }

		public ReceivedRevokeInviteEventArgs(BoltFriend inviteSender)
		{
			InviteSender = inviteSender;
		}
	}
}
