using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class NewPlayerJoinedEventArgs
	{
		public BoltFriend JoinedPlayer { get; }

		public NewPlayerJoinedEventArgs(BoltFriend joinedPlayer)
		{
			JoinedPlayer = joinedPlayer;
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			if (this == obj)
			{
				return true;
			}
			return obj.GetType() == GetType() && JoinedPlayer.Equals(obj);
		}

		public override int GetHashCode()
		{
			return ((JoinedPlayer != null) ? JoinedPlayer.GetHashCode() : 0) * 397;
		}
	}
}
