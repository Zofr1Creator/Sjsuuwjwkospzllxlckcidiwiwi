using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyPhotonGameChangedEventArgs
	{
		public BoltPhotonGame PhotonGame { get; }

		public LobbyPhotonGameChangedEventArgs(BoltPhotonGame photonGame)
		{
			PhotonGame = photonGame;
		}
	}
}
