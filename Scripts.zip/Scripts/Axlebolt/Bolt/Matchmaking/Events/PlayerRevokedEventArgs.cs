using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class PlayerRevokedEventArgs
	{
		public BoltFriend InviteSender { get; }

		public BoltFriend RevokedPlayer { get; }

		public PlayerRevokedEventArgs(BoltFriend inviteSender, BoltFriend revokedPlayer)
		{
			InviteSender = inviteSender;
			RevokedPlayer = revokedPlayer;
		}
	}
}
