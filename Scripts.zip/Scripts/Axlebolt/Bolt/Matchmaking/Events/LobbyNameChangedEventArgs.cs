namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyNameChangedEventArgs
	{
		public string Name { get; }

		public LobbyNameChangedEventArgs(string name)
		{
			Name = name;
		}
	}
}
