namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class ReceivedInviteEventArgs
	{
		public BoltLobbyInvite LobbyInvite { get; }

		public ReceivedInviteEventArgs(BoltLobbyInvite lobbyInvite)
		{
			LobbyInvite = lobbyInvite;
		}
	}
}
