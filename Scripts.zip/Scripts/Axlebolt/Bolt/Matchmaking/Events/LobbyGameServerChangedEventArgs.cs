namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyGameServerChangedEventArgs
	{
		public BoltGameServer GameServer { get; }

		public LobbyGameServerChangedEventArgs(BoltGameServer gameServer)
		{
			GameServer = gameServer;
		}
	}
}
