namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyPlayerTypeChangedEventArgs
	{
		public string PlayerId { get; }

		public LobbyPlayerType PlayerType { get; }

		public LobbyPlayerTypeChangedEventArgs(string playerId, LobbyPlayerType playerType)
		{
			PlayerId = playerId;
			PlayerType = playerType;
		}
	}
}
