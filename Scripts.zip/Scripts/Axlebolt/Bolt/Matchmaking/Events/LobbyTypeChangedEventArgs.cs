namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyTypeChangedEventArgs
	{
		public BoltLobby.LobbyType LobbyType { get; }

		public LobbyTypeChangedEventArgs(BoltLobby.LobbyType lobbyType)
		{
			LobbyType = lobbyType;
		}
	}
}
