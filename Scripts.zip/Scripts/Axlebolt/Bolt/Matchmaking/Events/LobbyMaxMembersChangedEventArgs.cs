namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyMaxMembersChangedEventArgs
	{
		public int MaxMembers { get; }

		public LobbyMaxMembersChangedEventArgs(int maxMembers)
		{
			MaxMembers = maxMembers;
		}
	}
}
