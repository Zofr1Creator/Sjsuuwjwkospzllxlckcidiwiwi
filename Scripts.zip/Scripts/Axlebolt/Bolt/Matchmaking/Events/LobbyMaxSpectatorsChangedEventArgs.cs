namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyMaxSpectatorsChangedEventArgs
	{
		public int MaxSpectators { get; }

		public LobbyMaxSpectatorsChangedEventArgs(int maxSpectators)
		{
			MaxSpectators = maxSpectators;
		}
	}
}
