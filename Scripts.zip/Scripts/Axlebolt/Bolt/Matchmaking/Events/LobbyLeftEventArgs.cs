namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyLeftEventArgs
	{
		public BoltLobby LobbyLeft { get; }

		public LobbyLeftEventArgs(BoltLobby lobbyLeft)
		{
			LobbyLeft = lobbyLeft;
		}
	}
}
