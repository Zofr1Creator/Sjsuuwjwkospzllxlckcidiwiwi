using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyOwnerChangedEventArgs
	{
		public BoltFriend Owner { get; }

		public LobbyOwnerChangedEventArgs(BoltFriend owner)
		{
			Owner = owner;
		}
	}
}
