using System.Collections.Generic;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyDataChangedEventArgs
	{
		public Dictionary<string, string> LobbyData { get; }

		public LobbyDataChangedEventArgs(Dictionary<string, string> lobbyData)
		{
			LobbyData = lobbyData;
		}
	}
}
