using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class PlayerKickedEventArgs
	{
		public BoltFriend KickInitiator { get; }

		public BoltFriend KickedPlayer { get; }

		public PlayerKickedEventArgs(BoltFriend kickInitiator, BoltFriend kickedPlayer)
		{
			KickInitiator = kickInitiator;
			KickedPlayer = kickedPlayer;
		}
	}
}
