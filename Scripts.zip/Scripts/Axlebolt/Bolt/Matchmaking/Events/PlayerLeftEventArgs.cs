using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class PlayerLeftEventArgs
	{
		public BoltFriend LeftPlayer { get; }

		public PlayerLeftEventArgs(BoltFriend leftPlayer)
		{
			LeftPlayer = leftPlayer;
		}
	}
}
