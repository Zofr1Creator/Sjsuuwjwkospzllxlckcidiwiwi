using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class PlayerRefusedEventArgs
	{
		public BoltFriend InviteSenderPlayer { get; }

		public BoltFriend RefusedPlayer { get; }

		public PlayerRefusedEventArgs(BoltFriend inviteSenderPlayer, BoltFriend refusedPlayer)
		{
			InviteSenderPlayer = inviteSenderPlayer;
			RefusedPlayer = refusedPlayer;
		}
	}
}
