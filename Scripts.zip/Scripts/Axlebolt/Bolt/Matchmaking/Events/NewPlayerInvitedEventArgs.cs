using Axlebolt.Bolt.Friends;

namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class NewPlayerInvitedEventArgs
	{
		public BoltFriend InviteSender { get; }

		public BoltFriend InvitedPlayer { get; }

		public NewPlayerInvitedEventArgs(BoltFriend inviteSender, BoltFriend invitedPlayer)
		{
			InviteSender = inviteSender;
			InvitedPlayer = invitedPlayer;
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			if (this == obj)
			{
				return true;
			}
			return obj.GetType() == GetType() && InvitedPlayer.Equals(obj);
		}

		public override int GetHashCode()
		{
			return ((InvitedPlayer != null) ? InvitedPlayer.GetHashCode() : 0) * 397;
		}
	}
}
