namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyJoinedEventArgs
	{
		public BoltLobby LobbyJoined { get; }

		public LobbyJoinedEventArgs(BoltLobby lobbyJoined)
		{
			LobbyJoined = lobbyJoined;
		}
	}
}
