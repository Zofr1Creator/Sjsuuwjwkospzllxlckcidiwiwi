namespace Axlebolt.Bolt.Matchmaking.Events
{
	public class LobbyChatMessageEventArgs
	{
		public BoltLobbyMessage LobbyMessage { get; }

		public LobbyChatMessageEventArgs(BoltLobbyMessage lobbyMessage)
		{
			LobbyMessage = lobbyMessage;
		}
	}
}
