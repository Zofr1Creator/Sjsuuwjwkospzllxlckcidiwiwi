using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Matchmaking.Mappers
{
	public class LobbyTypeMapper : EnumMapper<Axlebolt.Bolt.Protobuf.LobbyType, BoltLobby.LobbyType>
	{
	}
}
