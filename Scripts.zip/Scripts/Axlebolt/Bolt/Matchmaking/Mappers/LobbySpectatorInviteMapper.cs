using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Matchmaking.Mappers
{
	public class LobbySpectatorInviteMapper : MessageMapper<LobbyInvite, BoltLobbySpectatorInvite>
	{
		public static LobbySpectatorInviteMapper Instance = new LobbySpectatorInviteMapper();

		public override BoltLobbySpectatorInvite ToOriginal(LobbyInvite proto)
		{
			return new BoltLobbySpectatorInvite(proto.LobbyId, FriendMapper.Instance.ToOriginal(proto.InviteCreator), proto.Date);
		}
	}
}
