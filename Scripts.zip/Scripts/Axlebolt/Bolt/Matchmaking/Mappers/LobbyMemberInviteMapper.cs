using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Matchmaking.Mappers
{
	public class LobbyMemberInviteMapper : MessageMapper<LobbyInvite, BoltLobbyMemberInvite>
	{
		public static LobbyMemberInviteMapper Instance = new LobbyMemberInviteMapper();

		public override BoltLobbyMemberInvite ToOriginal(LobbyInvite proto)
		{
			return new BoltLobbyMemberInvite(proto.LobbyId, FriendMapper.Instance.ToOriginal(proto.InviteCreator), proto.Date);
		}
	}
}
