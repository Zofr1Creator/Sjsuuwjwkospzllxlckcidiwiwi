using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Matchmaking.Mappers
{
	public class LobbyPlayerTypeMapper : EnumMapper<Axlebolt.Bolt.Protobuf.LobbyPlayerType, LobbyPlayerType>
	{
	}
}
