using System.Collections.Concurrent;
using System.Collections.Generic;
using Axlebolt.Bolt.Friends;
using Axlebolt.Bolt.Friends.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Matchmaking.Mappers
{
	public class LobbyMapper : MessageMapper<Lobby, BoltLobby>
	{
		public static readonly LobbyMapper Instance = new LobbyMapper();

		public override BoltLobby ToOriginal(Lobby proto)
		{
			ConcurrentDictionary<string, string> data = new ConcurrentDictionary<string, string>(proto.Data);
			List<BoltFriend> lobbyMembers = FriendMapper.Instance.ToOriginalList(proto.Members);
			List<BoltFriend> lobbySpectators = FriendMapper.Instance.ToOriginalList(proto.Spectators);
			List<BoltFriend> lobbyMemberInvites = FriendMapper.Instance.ToOriginalList(proto.Invites);
			List<BoltFriend> lobbySpectatorInvites = FriendMapper.Instance.ToOriginalList(proto.SpectatorInvites);
			BoltGameServer gameServer = GameServerMapper.Instance.ToOriginal(proto.GameServer);
			return new BoltLobby(proto.Id, proto.OwnerPlayerId, proto.Name, EnumMapper<Axlebolt.Bolt.Protobuf.LobbyType, BoltLobby.LobbyType>.ToOriginal(proto.LobbyType), proto.Joinable, proto.MaxMembers, proto.MaxSpectators, data, lobbyMembers, lobbySpectators, lobbyMemberInvites, lobbySpectatorInvites, gameServer, PhotonGameMapper.Instance.ToOriginal(proto.PhotonGame));
		}
	}
}
