using System;
using System.Threading.Tasks;
using Axlebolt.Bolt.Analytics;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Settings;
using Axlebolt.Bolt.Stats;

namespace Axlebolt.Bolt
{
	public class BoltGameServerApi : BoltApi
	{
		private static BoltGameServerApi _instance;

		private readonly string _gameServerApiKey;

		private readonly string _gameVersion;

		private readonly GameServerRemoteService _remoteService;

		public static BoltGameServerApi Instance
		{
			get
			{
				if (_instance == null)
				{
					throw new BoltException(string.Format("{0} is not initialized", "BoltGameServerApi"));
				}
				return _instance;
			}
		}

		public static bool IsInitialized => _instance != null;

		public static void Init(string gameId, string gameServerApiKey, string gameVersion)
		{
			if (_instance != null)
			{
				throw new BoltException(string.Format("{0} already initialized", "BoltGameServerApi"));
			}
			_instance = new BoltGameServerApi(gameId, gameServerApiKey, gameVersion);
			_instance.Services.Add(new BoltGameServerStatsService());
			_instance.Services.Add(new BoltGameServerPlayerService());
			_instance.Services.Add(new BoltGameServerSettingsService());
			_instance.Services.Add(new BoltAnalytics());
		}

		public static void Destroy()
		{
			if (_instance == null)
			{
				return;
			}
			_instance.ClientService.Disconnect();
			_instance.Jobs.Clear();
			foreach (Service service in _instance.Services)
			{
				service.Destroy();
			}
			_instance.Services.Clear();
			_instance = null;
		}

		public BoltGameServerApi(string gameId, string gameServerApiKey, string gameVersion)
			: base(gameId)
		{
			if (gameServerApiKey == null)
			{
				throw new ArgumentNullException("gameServerApiKey");
			}
			_gameServerApiKey = gameServerApiKey;
			_gameVersion = gameVersion;
			_remoteService = new GameServerRemoteService(base.ClientService);
		}

		public Task ConnectToServerAsync()
		{
			return Async(ConnectToServer);
		}

		public void ConnectToServer()
		{
			ConnectAndAuthorize();
		}

		protected override void Auth()
		{
		}

		protected override void Handshake()
		{
			_remoteService.ServerHandshake(new ServerHandshake
			{
				ApiKey = _gameServerApiKey,
				GameId = base.GameId,
				Version = _gameVersion
			});
		}
	}
}
