using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceClosedRequest : BoltMarketplaceRequest
	{
		public string Id { get; internal set; }

		public long CloseDate { get; internal set; }

		public BoltMarketplaceClosingReason Reason { get; internal set; }

		public BoltPlayer Partner { get; internal set; }

		public string PartnerRequestId { get; internal set; }
	}
}
