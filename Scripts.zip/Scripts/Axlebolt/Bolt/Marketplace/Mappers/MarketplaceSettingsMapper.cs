using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceSettingsMapper : MessageMapper<MarketplaceSettings, BoltMarketplaceSettings>
	{
		public static readonly MarketplaceSettingsMapper Instance = new MarketplaceSettingsMapper();

		public override BoltMarketplaceSettings ToOriginal(MarketplaceSettings proto)
		{
			return new BoltMarketplaceSettings
			{
				Enabled = proto.Enabled,
				CurrencyId = proto.CurrencyId,
				CommissionPercent = proto.CommissionPercent,
				MinCommission = proto.MinCommission
			};
		}
	}
}
