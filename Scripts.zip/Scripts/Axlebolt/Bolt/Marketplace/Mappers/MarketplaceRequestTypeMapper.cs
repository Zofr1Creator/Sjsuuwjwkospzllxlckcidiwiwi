using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceRequestTypeMapper : MessageMapper<MarketRequestType, BoltMarketplaceRequestType>
	{
		public static readonly MarketplaceRequestTypeMapper Instance = new MarketplaceRequestTypeMapper();

		public override BoltMarketplaceRequestType ToOriginal(MarketRequestType proto)
		{
			switch (proto)
			{
			case MarketRequestType.PurchaseRequest:
				return BoltMarketplaceRequestType.Purchase;
			case MarketRequestType.SaleRequest:
				return BoltMarketplaceRequestType.Sale;
			default:
				throw new ArgumentOutOfRangeException("proto", proto, null);
			}
		}

		public override MarketRequestType ToProto(BoltMarketplaceRequestType original)
		{
			switch (original)
			{
			case BoltMarketplaceRequestType.Sale:
				return MarketRequestType.SaleRequest;
			case BoltMarketplaceRequestType.Purchase:
				return MarketRequestType.PurchaseRequest;
			default:
				throw new ArgumentOutOfRangeException("original", original, null);
			}
		}
	}
}
