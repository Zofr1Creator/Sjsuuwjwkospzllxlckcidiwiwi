using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceOpenRequestMapper : MessageMapper<OpenRequest, BoltMarketplaceOpenRequest>
	{
		public static readonly MarketplaceOpenRequestMapper Instance = new MarketplaceOpenRequestMapper();

		public override BoltMarketplaceOpenRequest ToOriginal(OpenRequest openRequest)
		{
			return new BoltMarketplaceOpenRequest
			{
				RequestId = openRequest.Id,
				ItemDefinitionId = openRequest.ItemDefinitionId,
				Definition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(openRequest.ItemDefinitionId),
				Creator = ((openRequest.Creator != null) ? PlayerMapper.Instance.ToOriginal(openRequest.Creator) : null),
				CreateDate = openRequest.CreateDate,
				Type = MarketplaceRequestTypeMapper.Instance.ToOriginal(openRequest.Type),
				Price = openRequest.Price,
				Quantity = openRequest.Quantity,
				ItemProperties = new BoltInventoryItemProperties(FillProperties(openRequest.Properties))
			};
		}

		private static Dictionary<string, BoltInventoryItemProperty> FillProperties(IDictionary<string, InventoryItemProperty> protoProperties)
		{
			Dictionary<string, BoltInventoryItemProperty> dictionary = new Dictionary<string, BoltInventoryItemProperty>();
			foreach (string key in protoProperties.Keys)
			{
				switch (protoProperties[key].Type)
				{
				case PropertyType.Float:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].FloatValue));
					break;
				case PropertyType.Int:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].IntValue));
					break;
				case PropertyType.String:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].StringValue));
					break;
				case PropertyType.Boolean:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].BooleanValue));
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}
			}
			return dictionary;
		}
	}
}
