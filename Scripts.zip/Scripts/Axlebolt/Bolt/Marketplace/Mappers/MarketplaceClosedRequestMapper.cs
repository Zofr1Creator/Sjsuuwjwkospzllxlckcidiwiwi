using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceClosedRequestMapper : MessageMapper<ClosedRequest, BoltMarketplaceClosedRequest>
	{
		public static readonly MarketplaceClosedRequestMapper Instance = new MarketplaceClosedRequestMapper();

		public override BoltMarketplaceClosedRequest ToOriginal(ClosedRequest request)
		{
			return new BoltMarketplaceClosedRequest
			{
				Id = request.Id,
				RequestId = request.OriginId,
				ItemDefinitionId = request.ItemDefinitionId,
				Definition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(request.ItemDefinitionId),
				CreateDate = request.CreateDate,
				CloseDate = request.CloseDate,
				Price = request.Price,
				Creator = ((request.Creator != null) ? PlayerMapper.Instance.ToOriginal(request.Creator) : null),
				Type = MarketplaceRequestTypeMapper.Instance.ToOriginal(request.Type),
				Partner = ((request.Partner != null) ? PlayerMapper.Instance.ToOriginal(request.Partner) : null),
				PartnerRequestId = request.PartnerRequestId,
				Reason = MarketplaceClosingReasonMapper.Instance.ToOriginal(request.Reason),
				Quantity = request.Quantity,
				ItemProperties = new BoltInventoryItemProperties(FillProperties(request.Properties))
			};
		}

		private static Dictionary<string, BoltInventoryItemProperty> FillProperties(IDictionary<string, InventoryItemProperty> protoProperties)
		{
			Dictionary<string, BoltInventoryItemProperty> dictionary = new Dictionary<string, BoltInventoryItemProperty>();
			foreach (string key in protoProperties.Keys)
			{
				switch (protoProperties[key].Type)
				{
				case PropertyType.Float:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].FloatValue));
					break;
				case PropertyType.Int:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].IntValue));
					break;
				case PropertyType.String:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].StringValue));
					break;
				case PropertyType.Boolean:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].BooleanValue));
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}
			}
			return dictionary;
		}
	}
}
