using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceTradeMapper : MessageMapper<Trade, BoltMarketplaceTrade>
	{
		public static readonly MarketplaceTradeMapper Instance = new MarketplaceTradeMapper();

		public override BoltMarketplaceTrade ToOriginal(Trade trade)
		{
			return new BoltMarketplaceTrade(trade.Id)
			{
				Definition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(trade.Id),
				SalesCount = trade.SalesCount,
				PurchasesCount = trade.PurchasesCount,
				SalePrice = trade.SalesPrice,
				PurchasePrice = trade.PurchasesPrice
			};
		}
	}
}
