using System;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceClosingReasonMapper : MessageMapper<ClosingReason, BoltMarketplaceClosingReason>
	{
		public static readonly MarketplaceClosingReasonMapper Instance = new MarketplaceClosingReasonMapper();

		public override BoltMarketplaceClosingReason ToOriginal(ClosingReason proto)
		{
			switch (proto)
			{
			case ClosingReason.SuccessTransaction:
				return BoltMarketplaceClosingReason.SuccessTransaction;
			case ClosingReason.NotEnoughFunds:
				return BoltMarketplaceClosingReason.NotEnoughFunds;
			case ClosingReason.Cancelled:
				return BoltMarketplaceClosingReason.Cancelled;
			case ClosingReason.SaleRequestNotFound:
				return BoltMarketplaceClosingReason.SaleRequestNotFound;
			default:
				throw new ArgumentOutOfRangeException("proto", proto, null);
			}
		}

		public override ClosingReason ToProto(BoltMarketplaceClosingReason original)
		{
			switch (original)
			{
			case BoltMarketplaceClosingReason.SuccessTransaction:
				return ClosingReason.SuccessTransaction;
			case BoltMarketplaceClosingReason.NotEnoughFunds:
				return ClosingReason.NotEnoughFunds;
			case BoltMarketplaceClosingReason.Cancelled:
				return ClosingReason.Cancelled;
			case BoltMarketplaceClosingReason.SaleRequestNotFound:
				return ClosingReason.SaleRequestNotFound;
			default:
				throw new ArgumentOutOfRangeException("original", original, null);
			}
		}
	}
}
