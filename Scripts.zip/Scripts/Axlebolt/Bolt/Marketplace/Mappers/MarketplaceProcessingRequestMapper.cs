using System;
using System.Collections.Generic;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Protobuf;

namespace Axlebolt.Bolt.Marketplace.Mappers
{
	public class MarketplaceProcessingRequestMapper : MessageMapper<ProcessingRequest, BoltMarketplaceProcessingRequest>
	{
		public static readonly MarketplaceProcessingRequestMapper Instance = new MarketplaceProcessingRequestMapper();

		public override BoltMarketplaceProcessingRequest ToOriginal(ProcessingRequest request)
		{
			return new BoltMarketplaceProcessingRequest
			{
				RequestId = request.Id,
				ItemDefinitionId = request.ItemDefinitionId,
				Definition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(request.ItemDefinitionId),
				CreateDate = request.CreateDate,
				Type = MarketplaceRequestTypeMapper.Instance.ToOriginal(request.Type),
				Price = request.Price,
				State = ToOriginal(request.State),
				Quantity = request.Quantity,
				ItemProperties = new BoltInventoryItemProperties(FillProperties(request.Properties))
			};
		}

		private static BoltMarketplaceProcessingRequest.ProcessingState ToOriginal(ProcessingState processingState)
		{
			switch (processingState)
			{
			case ProcessingState.Creating:
				return BoltMarketplaceProcessingRequest.ProcessingState.Creating;
			case ProcessingState.Cancelling:
				return BoltMarketplaceProcessingRequest.ProcessingState.Cancelling;
			default:
				throw new ArgumentOutOfRangeException("processingState", processingState, null);
			}
		}

		private static Dictionary<string, BoltInventoryItemProperty> FillProperties(IDictionary<string, InventoryItemProperty> protoProperties)
		{
			Dictionary<string, BoltInventoryItemProperty> dictionary = new Dictionary<string, BoltInventoryItemProperty>();
			foreach (string key in protoProperties.Keys)
			{
				switch (protoProperties[key].Type)
				{
				case PropertyType.Float:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].FloatValue));
					break;
				case PropertyType.Int:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].IntValue));
					break;
				case PropertyType.String:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].StringValue));
					break;
				case PropertyType.Boolean:
					dictionary.Add(key, new BoltInventoryItemProperty(protoProperties[key].BooleanValue));
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}
			}
			return dictionary;
		}
	}
}
