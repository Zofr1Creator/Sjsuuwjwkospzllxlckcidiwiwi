namespace Axlebolt.Bolt.Marketplace
{
	public enum BoltMarketplaceRequestType
	{
		None = 0,
		Sale = 1,
		Purchase = 2
	}
}
