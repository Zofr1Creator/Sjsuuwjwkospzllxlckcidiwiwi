namespace Axlebolt.Bolt.Marketplace.Events
{
	public class NewProcessingRequestEventArgs
	{
		public BoltMarketplaceProcessingRequest Request { get; }

		public NewProcessingRequestEventArgs(BoltMarketplaceProcessingRequest request)
		{
			Request = request;
		}
	}
}
