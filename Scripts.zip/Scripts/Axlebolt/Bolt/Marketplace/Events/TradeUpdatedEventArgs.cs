namespace Axlebolt.Bolt.Marketplace.Events
{
	public class TradeUpdatedEventArgs
	{
		public BoltMarketplaceTrade Trade { get; }

		public TradeUpdatedEventArgs(BoltMarketplaceTrade trade)
		{
			Trade = trade;
		}
	}
}
