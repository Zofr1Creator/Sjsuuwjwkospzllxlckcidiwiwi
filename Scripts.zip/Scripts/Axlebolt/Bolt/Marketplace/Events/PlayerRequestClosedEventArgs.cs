using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.Marketplace.Events
{
	public class PlayerRequestClosedEventArgs
	{
		private BoltMarketplaceClosedRequest _request;

		private BoltInventoryItem _inventoryItem;

		public BoltMarketplaceClosedRequest Request => _request;

		public BoltInventoryItem InventoryItem => _inventoryItem;

		public PlayerRequestClosedEventArgs(BoltMarketplaceClosedRequest request, BoltInventoryItem inventoryItem)
		{
			_request = request;
			_inventoryItem = inventoryItem;
		}
	}
}
