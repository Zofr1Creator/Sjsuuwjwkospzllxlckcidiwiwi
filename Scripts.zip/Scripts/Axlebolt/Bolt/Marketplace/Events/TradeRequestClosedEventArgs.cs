namespace Axlebolt.Bolt.Marketplace.Events
{
	public class TradeRequestClosedEventArgs
	{
		public BoltMarketplaceClosedRequest Request { get; }

		public TradeRequestClosedEventArgs(BoltMarketplaceClosedRequest request)
		{
			Request = request;
		}
	}
}
