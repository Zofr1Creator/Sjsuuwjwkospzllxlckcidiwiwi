namespace Axlebolt.Bolt.Marketplace.Events
{
	public class TradeRequestOpenedEventArgs
	{
		public BoltMarketplaceOpenRequest Request { get; }

		public TradeRequestOpenedEventArgs(BoltMarketplaceOpenRequest request)
		{
			Request = request;
		}
	}
}
