namespace Axlebolt.Bolt.Marketplace.Events
{
	public class PlayerRequestOpenedEventArgs
	{
		public BoltMarketplaceOpenRequest Request { get; }

		public PlayerRequestOpenedEventArgs(BoltMarketplaceOpenRequest request)
		{
			Request = request;
		}
	}
}
