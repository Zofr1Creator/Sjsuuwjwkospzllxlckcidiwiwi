using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Api;
using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Inventory.Mappers;
using Axlebolt.Bolt.Inventory.Ops;
using Axlebolt.Bolt.Marketplace.Events;
using Axlebolt.Bolt.Marketplace.Exceptions;
using Axlebolt.Bolt.Marketplace.Mappers;
using Axlebolt.Bolt.Player;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceService : BoltService<BoltMarketplaceService>
	{
		private class MarketPlaceRemoteEventListener : IMarketplaceRemoteEventListener
		{
			private readonly BoltMarketplaceService _service;

			public MarketPlaceRemoteEventListener(BoltMarketplaceService service)
			{
				_service = service;
			}

			public void OnTradeUpdated(OnTradeUpdatedEvent eventArgs)
			{
				Logger.Debug($"OnTradeUpdated {eventArgs.Trade.Id}");
				BoltMarketplaceTrade trade = MarketplaceTradeMapper.Instance.ToOriginal(eventArgs.Trade);
				_service.TradeUpdatedEvent.Invoke(new TradeUpdatedEventArgs(trade));
			}

			public void OnTradeRequestClosed(OnTradeRequestClosedEvent eventArgs)
			{
				Logger.Debug($"OnTradeRequestClosed {eventArgs.Request.Id}");
				BoltMarketplaceClosedRequest request = MarketplaceClosedRequestMapper.Instance.ToOriginal(eventArgs.Request);
				_service.TradeRequestClosedEvent.Invoke(new TradeRequestClosedEventArgs(request));
			}

			public void OnTradeRequestOpened(OnTradeRequestOpenedEvent eventArgs)
			{
				Logger.Debug($"OnTradeRequestOpened {eventArgs.Request.Id}");
				BoltMarketplaceOpenRequest request = MarketplaceOpenRequestMapper.Instance.ToOriginal(eventArgs.Request);
				_service.TradeRequestOpenedEvent.Invoke(new TradeRequestOpenedEventArgs(request));
			}

			public void OnPlayerRequestOpened(OnPlayerRequestOpenedEvent eventArgs)
			{
				Logger.Debug($"OnPlayerRequestOpened {eventArgs.Request.Id}");
				BoltMarketplaceOpenRequest boltMarketplaceOpenRequest = MarketplaceOpenRequestMapper.Instance.ToOriginal(eventArgs.Request);
				boltMarketplaceOpenRequest.Creator = BoltService<BoltPlayerService>.Instance.Player;
				lock (_service._lock)
				{
					if (_service._processingRequests.ContainsKey(boltMarketplaceOpenRequest.RequestId))
					{
						_service._processingRequests.Remove(boltMarketplaceOpenRequest.RequestId);
					}
					_service._openRequests.Add(boltMarketplaceOpenRequest.RequestId, boltMarketplaceOpenRequest);
				}
				_service.PlayerRequestOpenedEvent.Invoke(new PlayerRequestOpenedEventArgs(boltMarketplaceOpenRequest));
			}

			public void OnPlayerRequestClosed(OnPlayerRequestClosedEvent eventArgs)
			{
				Logger.Debug($"OnPlayerRequestOpened {eventArgs.Request.Id}");
				BoltMarketplaceClosedRequest boltMarketplaceClosedRequest = MarketplaceClosedRequestMapper.Instance.ToOriginal(eventArgs.Request);
				boltMarketplaceClosedRequest.Creator = BoltService<BoltPlayerService>.Instance.Player;
				BoltInventoryItem inventoryItem = ((eventArgs.Item != null) ? InventoryItemMapper.Instance.ToOriginal(eventArgs.Item) : null);
				lock (_service._lock)
				{
					if (boltMarketplaceClosedRequest.Reason == BoltMarketplaceClosingReason.SuccessTransaction)
					{
						InventoryOps inventoryOps = BoltService<BoltInventoryService>.Instance.CreateInventoryOps();
						if (boltMarketplaceClosedRequest.IsSaleRequest)
						{
							inventoryOps.AddAmount(_service.Settings.CurrencyId, boltMarketplaceClosedRequest.Price);
						}
						else
						{
							inventoryOps.Add(inventoryItem);
							inventoryOps.RemoveAmount(_service.Settings.CurrencyId, boltMarketplaceClosedRequest.Price);
						}
						inventoryOps.Apply();
					}
					else if (boltMarketplaceClosedRequest.Reason == BoltMarketplaceClosingReason.Cancelled && boltMarketplaceClosedRequest.IsSaleRequest)
					{
						InventoryOps inventoryOps2 = BoltService<BoltInventoryService>.Instance.CreateInventoryOps();
						inventoryOps2.Add(inventoryItem);
						inventoryOps2.Apply();
					}
					if (_service._openRequests.ContainsKey(boltMarketplaceClosedRequest.RequestId))
					{
						_service._processingRequests.Remove(boltMarketplaceClosedRequest.RequestId);
						_service._openRequests[boltMarketplaceClosedRequest.RequestId].Quantity -= boltMarketplaceClosedRequest.Quantity;
						if (_service._openRequests[boltMarketplaceClosedRequest.RequestId].Quantity <= 0)
						{
							_service._openRequests.Remove(boltMarketplaceClosedRequest.RequestId);
						}
					}
					else if (_service._processingRequests.ContainsKey(boltMarketplaceClosedRequest.RequestId))
					{
						_service._processingRequests[boltMarketplaceClosedRequest.RequestId].Quantity -= boltMarketplaceClosedRequest.Quantity;
						if (_service._processingRequests[boltMarketplaceClosedRequest.RequestId].Quantity <= 0)
						{
							_service._processingRequests.Remove(boltMarketplaceClosedRequest.RequestId);
						}
					}
				}
				PlayerRequestClosedEventArgs arg = new PlayerRequestClosedEventArgs(boltMarketplaceClosedRequest, inventoryItem);
				_service.PlayerRequestClosedEvent.Invoke(arg);
			}
		}

		private const string TradesTopic = "marketplace_trades";

		private const string TradeTopic = "marketplace_trade_";

		private readonly MarketplaceRemoteService _marketPlaceRemoteService;

		private readonly MarketPlaceRemoteEventListener _remoteEventListener;

		private readonly Dictionary<string, BoltMarketplaceProcessingRequest> _processingRequests = new Dictionary<string, BoltMarketplaceProcessingRequest>();

		private readonly Dictionary<string, BoltMarketplaceOpenRequest> _openRequests = new Dictionary<string, BoltMarketplaceOpenRequest>();

		public readonly BoltEvent<NewProcessingRequestEventArgs> NewProcessingRequestEvent = new BoltEvent<NewProcessingRequestEventArgs>();

		public readonly BoltEvent<PlayerRequestOpenedEventArgs> PlayerRequestOpenedEvent = new BoltEvent<PlayerRequestOpenedEventArgs>();

		public readonly BoltEvent<PlayerRequestClosedEventArgs> PlayerRequestClosedEvent = new BoltEvent<PlayerRequestClosedEventArgs>();

		public readonly BoltEvent<TradeUpdatedEventArgs> TradeUpdatedEvent = new BoltEvent<TradeUpdatedEventArgs>();

		public readonly BoltEvent<TradeRequestOpenedEventArgs> TradeRequestOpenedEvent = new BoltEvent<TradeRequestOpenedEventArgs>();

		public readonly BoltEvent<TradeRequestClosedEventArgs> TradeRequestClosedEvent = new BoltEvent<TradeRequestClosedEventArgs>();

		private readonly object _lock = new object();

		public BoltMarketplaceSettings Settings { get; private set; }

		public bool IsEnabled => Settings.Enabled;

		public BoltMarketplaceService()
		{
			_marketPlaceRemoteService = new MarketplaceRemoteService(BoltPlayerApi.Instance.ClientService);
			_remoteEventListener = new MarketPlaceRemoteEventListener(this);
		}

		internal override void Load()
		{
			_processingRequests.Clear();
			_openRequests.Clear();
			MarketplaceSettings marketplaceSettings = _marketPlaceRemoteService.GetMarketplaceSettings();
			Settings = MarketplaceSettingsMapper.Instance.ToOriginal(marketplaceSettings);
			if (Settings.Enabled)
			{
				ProcessingRequest[] playerProcessingRequests = _marketPlaceRemoteService.GetPlayerProcessingRequests();
				ProcessingRequest[] array = playerProcessingRequests;
				foreach (ProcessingRequest processingRequest in array)
				{
					_processingRequests[processingRequest.Id] = MarketplaceProcessingRequestMapper.Instance.ToOriginal(processingRequest);
				}
				OpenRequest[] playerOpenRequests = _marketPlaceRemoteService.GetPlayerOpenRequests();
				OpenRequest[] array2 = playerOpenRequests;
				foreach (OpenRequest openRequest in array2)
				{
					_openRequests[openRequest.Id] = MarketplaceOpenRequestMapper.Instance.ToOriginal(openRequest);
				}
			}
		}

		internal override void PostLoad()
		{
			foreach (KeyValuePair<string, BoltMarketplaceProcessingRequest> processingRequest in _processingRequests)
			{
				processingRequest.Value.Creator = BoltService<BoltPlayerService>.Instance.Player;
			}
			foreach (KeyValuePair<string, BoltMarketplaceOpenRequest> openRequest in _openRequests)
			{
				openRequest.Value.Creator = BoltService<BoltPlayerService>.Instance.Player;
			}
		}

		internal override void BindEvents()
		{
			BoltPlayerApi.Instance.AddEventListener(_remoteEventListener);
		}

		internal override void UnbindEvents()
		{
			BoltPlayerApi.Instance.RemoveEventListener(_remoteEventListener);
		}

		internal override void Unload()
		{
			base.Unload();
			_processingRequests.Clear();
			_openRequests.Clear();
		}

		public Task SubscribeToTrades()
		{
			return BoltPlayerApi.Instance.Subscribe("marketplace_trades");
		}

		public Task UnsubscribeFromTrades()
		{
			return BoltPlayerApi.Instance.Unsubscribe("marketplace_trades");
		}

		public Task SubscribeToTrade(int tradeId)
		{
			return BoltPlayerApi.Instance.Subscribe("marketplace_trade_" + tradeId);
		}

		public Task UnsubscribeFromTrade(int tradeId)
		{
			return BoltPlayerApi.Instance.Unsubscribe("marketplace_trade_" + tradeId);
		}

		public Task<string> CreateSaleRequest(int inventoryItemId, float price)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				BoltInventoryItem inventoryItem = BoltService<BoltInventoryService>.Instance.GetInventoryItem(inventoryItemId);
				CreateSaleRequestArgs args = new CreateSaleRequestArgs
				{
					ItemId = inventoryItemId,
					Price = price
				};
				lock (_lock)
				{
					string text = _marketPlaceRemoteService.CreateSaleRequest(args);
					BoltMarketplaceProcessingRequest request = new BoltMarketplaceProcessingRequest
					{
						RequestId = text,
						ItemDefinitionId = inventoryItem.Definition.Id,
						Creator = BoltService<BoltPlayerService>.Instance.Player,
						Definition = inventoryItem.Definition,
						Price = price,
						CreateDate = BoltPlayerApi.GetTimeInMilliseconds(),
						State = BoltMarketplaceProcessingRequest.ProcessingState.Creating,
						Type = BoltMarketplaceRequestType.Sale,
						ItemProperties = inventoryItem.ItemProperties
					};
					Logger.Debug($"CreateSaleRequest {text}");
					InventoryOps inventoryOps = BoltService<BoltInventoryService>.Instance.CreateInventoryOps();
					inventoryOps.Consume(inventoryItemId);
					inventoryOps.Apply();
					CreateProcessingRequest(request);
					return text;
				}
			});
		}

		private void CreateProcessingRequest(BoltMarketplaceProcessingRequest request)
		{
			_processingRequests.Add(request.RequestId, request);
			NewProcessingRequestEvent.Invoke(new NewProcessingRequestEventArgs(request));
		}

		public Task<string> CreatePurchaseRequestBySale(BoltMarketplaceOpenRequest saleRequest)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				if (saleRequest.IsPurchaseRequest)
				{
					throw new MarketplaceException("Expect sale request, actual is purchase request");
				}
				CreatePurchaseBySaleArgs args = new CreatePurchaseBySaleArgs
				{
					SaleId = saleRequest.RequestId
				};
				lock (_lock)
				{
					string text = _marketPlaceRemoteService.CreatePurchaseRequestBySale(args);
					BoltMarketplaceProcessingRequest request = new BoltMarketplaceProcessingRequest
					{
						RequestId = text,
						ItemDefinitionId = saleRequest.ItemDefinitionId,
						Definition = saleRequest.Definition,
						Creator = BoltService<BoltPlayerService>.Instance.Player,
						Price = saleRequest.Price,
						CreateDate = BoltPlayerApi.GetTimeInMilliseconds(),
						State = BoltMarketplaceProcessingRequest.ProcessingState.Creating,
						Type = BoltMarketplaceRequestType.Purchase,
						BySaleRequestId = saleRequest.RequestId,
						Quantity = 1
					};
					CreateProcessingRequest(request);
					return text;
				}
			});
		}

		public Task<string> CreatePurchaseRequest(int itemDefinitionId, float price, int quantity)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				BoltInventoryItemDefinition inventoryItemDefinition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(itemDefinitionId);
				CreatePurchaseRequestArgs args = new CreatePurchaseRequestArgs
				{
					ItemDefinitionId = itemDefinitionId,
					Price = price,
					Quantity = quantity
				};
				lock (_lock)
				{
					string text = _marketPlaceRemoteService.CreatePurchaseRequest(args);
					BoltMarketplaceProcessingRequest request = new BoltMarketplaceProcessingRequest
					{
						RequestId = text,
						ItemDefinitionId = itemDefinitionId,
						Definition = inventoryItemDefinition,
						Price = price,
						Creator = BoltService<BoltPlayerService>.Instance.Player,
						CreateDate = BoltPlayerApi.GetTimeInMilliseconds(),
						State = BoltMarketplaceProcessingRequest.ProcessingState.Creating,
						Type = BoltMarketplaceRequestType.Purchase,
						Quantity = quantity
					};
					CreateProcessingRequest(request);
					return text;
				}
			});
		}

		public Task CancelRequest(string requestId)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				if (!_openRequests.ContainsKey(requestId))
				{
					throw new MarketplaceException($"OpenRequest with id {requestId} not found");
				}
				BoltMarketplaceOpenRequest boltMarketplaceOpenRequest = _openRequests[requestId];
				lock (_lock)
				{
					_marketPlaceRemoteService.CancelRequest(new CancelRequestArgs
					{
						Id = requestId
					});
					BoltMarketplaceProcessingRequest request = new BoltMarketplaceProcessingRequest
					{
						RequestId = requestId,
						ItemDefinitionId = boltMarketplaceOpenRequest.ItemDefinitionId,
						Definition = boltMarketplaceOpenRequest.Definition,
						Price = boltMarketplaceOpenRequest.Price,
						Creator = BoltService<BoltPlayerService>.Instance.Player,
						CreateDate = BoltPlayerApi.GetTimeInMilliseconds(),
						State = BoltMarketplaceProcessingRequest.ProcessingState.Creating,
						Type = BoltMarketplaceRequestType.Purchase,
						ItemProperties = boltMarketplaceOpenRequest.ItemProperties,
						Quantity = boltMarketplaceOpenRequest.Quantity
					};
					CreateProcessingRequest(request);
				}
			});
		}

		public BoltMarketplaceProcessingRequest[] GetProcessingRequests(BoltMarketplaceRequestType type)
		{
			return (from request in _processingRequests
				where request.Value.Type == type
				select request.Value into request
				orderby request.CreateDate descending
				select request).ToArray();
		}

		public BoltMarketplaceProcessingRequest[] GetProcessingRequests()
		{
			return (from request in _processingRequests
				select request.Value into request
				orderby request.CreateDate descending
				select request).ToArray();
		}

		public BoltMarketplaceProcessingRequest GetProcessingPurchaseRequest(int itemDefinitionId)
		{
			return (from request in _processingRequests
				where request.Value.Type == BoltMarketplaceRequestType.Purchase && request.Value.ItemDefinitionId == itemDefinitionId
				select request.Value).FirstOrDefault();
		}

		public BoltMarketplaceOpenRequest[] GetOpenRequests(BoltMarketplaceRequestType type)
		{
			return (from request in _openRequests
				where request.Value.Type == type
				select request.Value into request
				orderby request.CreateDate descending
				select request).ToArray();
		}

		public BoltMarketplaceOpenRequest[] GetOpenRequests()
		{
			return (from request in _openRequests
				select request.Value into request
				orderby request.CreateDate descending
				select request).ToArray();
		}

		public bool IsOpenRequestExists(string requestId)
		{
			return _openRequests.ContainsKey(requestId);
		}

		public BoltMarketplaceOpenRequest GetOpenRequest(string requestId)
		{
			if (IsOpenRequestExists(requestId))
			{
				return _openRequests[requestId];
			}
			throw new MarketplaceException($"Open request with id {requestId} not found");
		}

		public BoltMarketplaceOpenRequest[] GetOpenSaleRequests(int itemDefinitionId)
		{
			return (from request in _openRequests
				where request.Value.Type == BoltMarketplaceRequestType.Sale && request.Value.ItemDefinitionId == itemDefinitionId
				select request.Value into request
				orderby request.CreateDate descending
				select request).ToArray();
		}

		public BoltMarketplaceOpenRequest GetOpenPurchaseRequest(int itemDefinitionId)
		{
			return (from request in _openRequests
				where request.Value.Type == BoltMarketplaceRequestType.Purchase && request.Value.ItemDefinitionId == itemDefinitionId
				select request.Value).FirstOrDefault();
		}

		public Task<int> GetClosedRequestsCount(BoltMarketplaceRequestType type, BoltMarketplaceClosingReason reason)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				GetClosedRequestsCountArgs getClosedRequestsCountArgs = new GetClosedRequestsCountArgs();
				if (type != 0)
				{
					getClosedRequestsCountArgs.Type = MarketplaceRequestTypeMapper.Instance.ToProto(type);
				}
				if (reason != 0)
				{
					getClosedRequestsCountArgs.Reason = MarketplaceClosingReasonMapper.Instance.ToProto(reason);
				}
				return _marketPlaceRemoteService.GetPlayerClosedRequestsCount(getClosedRequestsCountArgs);
			});
		}

		public Task<BoltMarketplaceClosedRequest[]> GetClosedRequestsAsync(int page, int size)
		{
			return GetClosedRequestsAsync(BoltMarketplaceRequestType.None, BoltMarketplaceClosingReason.None, page, size);
		}

		public Task<BoltMarketplaceClosedRequest[]> GetClosedRequestsAsync(BoltMarketplaceRequestType type, int page, int size)
		{
			return GetClosedRequestsAsync(type, BoltMarketplaceClosingReason.None, page, size);
		}

		public Task<BoltMarketplaceClosedRequest[]> GetClosedRequestsAsync(BoltMarketplaceRequestType type, BoltMarketplaceClosingReason reason, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				GetClosedRequestsArgs getClosedRequestsArgs = new GetClosedRequestsArgs
				{
					Page = page,
					Size = size
				};
				if (type != 0)
				{
					getClosedRequestsArgs.Type = MarketplaceRequestTypeMapper.Instance.ToProto(type);
				}
				if (reason != 0)
				{
					getClosedRequestsArgs.Reason = MarketplaceClosingReasonMapper.Instance.ToProto(reason);
				}
				ClosedRequest[] playerClosedRequests = _marketPlaceRemoteService.GetPlayerClosedRequests(getClosedRequestsArgs);
				return MarketplaceClosedRequestMapper.Instance.ToOriginalArray(playerClosedRequests);
			});
		}

		public Task<BoltMarketplaceOpenRequest[]> GetTradeOpenSaleRequestsAsync(int itemDefinitionId, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				GetTradeOpenSaleRequestsArgs args = new GetTradeOpenSaleRequestsArgs
				{
					Id = itemDefinitionId,
					Page = page,
					Size = size
				};
				OpenRequest[] tradeOpenSaleRequests = _marketPlaceRemoteService.GetTradeOpenSaleRequests(args);
				return MarketplaceOpenRequestMapper.Instance.ToOriginalArray(tradeOpenSaleRequests);
			});
		}

		public Task<BoltMarketplaceOpenRequest[]> GetTradeOpenPurchaseRequestsAsync(int itemDefinitionId, int page, int size)
		{
			return BoltPlayerApi.Instance.Async(delegate
			{
				GetTradeOpenPurchaseRequestsArgs args = new GetTradeOpenPurchaseRequestsArgs
				{
					Id = itemDefinitionId,
					Page = page,
					Size = size
				};
				OpenRequest[] tradeOpenPurchaseRequests = _marketPlaceRemoteService.GetTradeOpenPurchaseRequests(args);
				return MarketplaceOpenRequestMapper.Instance.ToOriginalArray(tradeOpenPurchaseRequests);
			});
		}

		public Task<BoltMarketplaceTrade[]> GetTradesAsync(int[] itemDefinitionIds)
		{
			return BoltPlayerApi.Instance.Async(() => GetTrades(itemDefinitionIds));
		}

		public BoltMarketplaceTrade[] GetTrades(int[] itemDefinitionIds)
		{
			GetTradesArgs getTradesArgs = new GetTradesArgs();
			getTradesArgs.ItemDefinitionIds.AddRange(itemDefinitionIds);
			Trade[] trades = _marketPlaceRemoteService.GetTrades(getTradesArgs);
			List<BoltMarketplaceTrade> list = MarketplaceTradeMapper.Instance.ToOriginalList(trades);
			List<int> list2 = new List<int>(itemDefinitionIds);
			foreach (BoltMarketplaceTrade item in list)
			{
				list2.Remove(item.ItemDefinitionId);
			}
			foreach (int item2 in list2)
			{
				list.Add(GetEmptyTrade(item2));
			}
			return list.ToArray();
		}

		public Task<BoltMarketplaceTrade> GetTradeAsync(int itemDefinitionId)
		{
			return BoltPlayerApi.Instance.Async(() => GetTrade(itemDefinitionId));
		}

		public BoltMarketplaceTrade GetTrade(int itemDefinitionId)
		{
			Trade trade = _marketPlaceRemoteService.GetTrade(new GetTradeArgs
			{
				Id = itemDefinitionId
			});
			if (trade == null)
			{
				return GetEmptyTrade(itemDefinitionId);
			}
			return MarketplaceTradeMapper.Instance.ToOriginal(trade);
		}

		private static BoltMarketplaceTrade GetEmptyTrade(int id)
		{
			return new BoltMarketplaceTrade(id)
			{
				PurchasesCount = 0,
				SalesCount = 0,
				Definition = BoltService<BoltInventoryService>.Instance.GetInventoryItemDefinition(id)
			};
		}
	}
}
