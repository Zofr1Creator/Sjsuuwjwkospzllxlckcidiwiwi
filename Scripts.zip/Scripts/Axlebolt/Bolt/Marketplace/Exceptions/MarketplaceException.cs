using System;

namespace Axlebolt.Bolt.Marketplace.Exceptions
{
	public class MarketplaceException : Exception
	{
		public MarketplaceException(string message)
			: base(message)
		{
		}
	}
}
