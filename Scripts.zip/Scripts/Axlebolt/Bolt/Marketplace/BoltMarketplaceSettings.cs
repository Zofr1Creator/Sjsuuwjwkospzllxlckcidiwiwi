namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceSettings
	{
		public bool Enabled { get; internal set; }

		public float CommissionPercent { get; internal set; }

		public int CurrencyId { get; internal set; }

		public float MinCommission { get; internal set; }
	}
}
