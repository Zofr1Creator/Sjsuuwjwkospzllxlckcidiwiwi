using Axlebolt.Bolt.Inventory;
using Axlebolt.Bolt.Player;

namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceRequest
	{
		public string RequestId { get; internal set; }

		public int ItemDefinitionId { get; internal set; }

		public BoltPlayer Creator { get; internal set; }

		public BoltMarketplaceRequestType Type { get; internal set; }

		public BoltInventoryItemDefinition Definition { get; internal set; }

		public float Price { get; internal set; }

		public long CreateDate { get; internal set; }

		public int Quantity { get; internal set; }

		public string BySaleRequestId { get; internal set; }

		public bool IsSaleRequest => Type == BoltMarketplaceRequestType.Sale;

		public bool IsPurchaseRequest => Type == BoltMarketplaceRequestType.Purchase;

		public BoltInventoryItemProperties ItemProperties { get; internal set; }
	}
}
