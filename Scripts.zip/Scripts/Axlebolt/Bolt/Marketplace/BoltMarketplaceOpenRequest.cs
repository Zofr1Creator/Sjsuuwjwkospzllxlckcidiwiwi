namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceOpenRequest : BoltMarketplaceRequest
	{
	}
}
