using Axlebolt.Bolt.Inventory;

namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceTrade
	{
		public int ItemDefinitionId { get; }

		public BoltInventoryItemDefinition Definition { get; internal set; }

		public int SalesCount { get; internal set; }

		public float SalePrice { get; internal set; }

		public int PurchasesCount { get; internal set; }

		public float PurchasePrice { get; internal set; }

		public BoltMarketplaceTrade(int itemDefinitionId)
		{
			ItemDefinitionId = itemDefinitionId;
		}

		protected bool Equals(BoltMarketplaceTrade other)
		{
			return ItemDefinitionId == other.ItemDefinitionId;
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			if (this == obj)
			{
				return true;
			}
			if (obj.GetType() != GetType())
			{
				return false;
			}
			return Equals((BoltMarketplaceTrade)obj);
		}

		public override int GetHashCode()
		{
			return ItemDefinitionId;
		}
	}
}
