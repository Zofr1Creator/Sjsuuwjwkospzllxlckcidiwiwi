namespace Axlebolt.Bolt.Marketplace
{
	public class BoltMarketplaceProcessingRequest : BoltMarketplaceRequest
	{
		public enum ProcessingState
		{
			Creating = 0,
			Cancelling = 1
		}

		public ProcessingState State { get; set; }
	}
}
