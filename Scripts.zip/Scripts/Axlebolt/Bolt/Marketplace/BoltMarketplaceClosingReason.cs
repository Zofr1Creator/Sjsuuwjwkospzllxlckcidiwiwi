namespace Axlebolt.Bolt.Marketplace
{
	public enum BoltMarketplaceClosingReason
	{
		None = 0,
		SuccessTransaction = 1,
		NotEnoughFunds = 2,
		Cancelled = 3,
		SaleRequestNotFound = 4
	}
}
