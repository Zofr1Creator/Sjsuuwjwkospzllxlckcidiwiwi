using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("AnalyticsRemoteService")]
	public class AnalyticsRemoteService : RpcService
	{
		public AnalyticsRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("event")]
		public void Event(UserEvent[] userEvents, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { userEvents }, ct);
		}
	}
}
