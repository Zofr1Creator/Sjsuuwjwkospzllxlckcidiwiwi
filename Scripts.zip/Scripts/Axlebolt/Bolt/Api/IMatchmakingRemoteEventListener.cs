using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[EventListener("MatchmakingRemoteEventListener")]
	public interface IMatchmakingRemoteEventListener
	{
		[Event("onLobbyDataChanged")]
		void OnLobbyDataChanged(Dictionary data);

		[Event("onNewPlayerJoinedLobby")]
		void OnNewPlayerJoinedLobby(PlayerFriend newPlayer);

		[Event("onLobbyJoinableChanged")]
		void OnLobbyJoinableChanged(bool joinable);

		[Event("onNewSpectatorJoinedLobby")]
		void OnNewSpectatorJoinedLobby(PlayerFriend newSpectator);

		[Event("onLobbyPhotonGameChanged")]
		void OnLobbyPhotonGameChanged(PhotonGame photonGame);

		[Event("onLobbyChatMessage")]
		void OnLobbyChatMessage(string playerId, string message);

		[Event("onLobbyPlayerTypeChanged")]
		void OnLobbyPlayerTypeChanged(string playerId, LobbyPlayerType playerType);

		[Event("onNewPlayerInvitedToLobby")]
		void OnNewPlayerInvitedToLobby(string inviteSenderId, PlayerFriend newPlayer);

		[Event("onReceivedSpectatorInviteToLobby")]
		void OnReceivedSpectatorInviteToLobby(PlayerFriend inviteSender, string lobbyId);

		[Event("onLobbyMaxSpectatorsChanged")]
		void OnLobbyMaxSpectatorsChanged(byte maxSpectators);

		[Event("onLobbyTypeChanged")]
		void OnLobbyTypeChanged(Axlebolt.Bolt.Protobuf.LobbyType lobbyType);

		[Event("onLobbyNameChanged")]
		void OnLobbyNameChanged(string name);

		[Event("onLobbyOwnerChanged")]
		void OnLobbyOwnerChanged(string lobbyOwnerId);

		[Event("onPlayerKickedFromLobby")]
		void OnPlayerKickedFromLobby(string kickInitiatorId, string kickedPlayerId);

		[Event("onNewSpectatorInvitedToLobby")]
		void OnNewSpectatorInvitedToLobby(string inviteSenderId, PlayerFriend newSpectator);

		[Event("onLobbyMaxMembersChanged")]
		void OnLobbyMaxMembersChanged(byte maxMembers);

		[Event("onReceivedInviteToLobby")]
		void OnReceivedInviteToLobby(PlayerFriend inviteSender, string lobbyId);

		[Event("onPlayerLeftLobby")]
		void OnPlayerLeftLobby(string leftPlayerId);

		[Event("onLobbyGameServerChanged")]
		void OnLobbyGameServerChanged(GameServer gameServer);

		[Event("onRevokeInviteToLobby")]
		void OnRevokeInviteToLobby(string inviteSenderId, string invitedPlayerId);

		[Event("onRefuseInviteToLobby")]
		void OnRefuseInviteToLobby(string inviteSenderId, string invitedPlayerId);
	}
}
