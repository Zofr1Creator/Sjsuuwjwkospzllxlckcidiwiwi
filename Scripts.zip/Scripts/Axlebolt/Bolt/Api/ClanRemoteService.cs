using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [RpcService("ClanRemoteService")]
    public class ClanRemoteService : RpcService
    {
        public ClanRemoteService(ClientService client)
            : base(client)
        {
        }

        [Rpc("requestToJoinClan")]
        public void RequestToJoinClan(string clanId, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { clanId }, ct);
        }

        [Rpc("inviteToClan")]
        public void InviteToClan(string playerId, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { playerId }, ct);
        }

        [Rpc("getRoles")]
        public ClanMemberRole[] GetRoles(CancellationToken ct = default(CancellationToken))
        {
            //return (ClanMemberRole[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
            return new ClanMemberRole[0];
        }

        [Rpc("getClan")]
        public Clan GetClan(string clanId, CancellationToken ct = default(CancellationToken))
        {
            //return (Clan)Invoke(MethodBase.GetCurrentMethod(), new object[1] { clanId }, ct);
            return new Clan();
        }

        [Rpc("changeClanType")]
        public void ChangeClanType(ClanType clanType, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { clanType }, ct);
        }

        [Rpc("getPlayerOpenRequests")]
        public ClanOpenRequest[] GetPlayerOpenRequests(RequestType requestType, int page, int size, CancellationToken ct = default(CancellationToken))
        {
            return (ClanOpenRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { requestType, page, size }, ct);
        }

        [Rpc("cancelRequest")]
        public void CancelRequest(string requestId, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { requestId }, ct);
        }

        [Rpc("assignRoleToMember")]
        public void AssignRoleToMember(string memberId, string newRole, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[2] { memberId, newRole }, ct);
        }

        [Rpc("sendMsgToClan")]
        public void SendMsgToClan(string message, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { message }, ct);
        }

        [Rpc("createClan")]
        public Clan CreateClan(string clanName, string clanTag, ClanType clanType, CancellationToken ct = default(CancellationToken))
        {
            return (Clan)Invoke(MethodBase.GetCurrentMethod(), new object[3] { clanName, clanTag, clanType }, ct);
        }

        [Rpc("kickMember")]
        public void KickMember(string memberId, string kickingReason, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[2] { memberId, kickingReason }, ct);
        }

        [Rpc("changeClanName")]
        public void ChangeClanName(string newName, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { newName }, ct);
        }

        [Rpc("assignLeaderRole")]
        public void AssignLeaderRole(string newLeaderMemberId, string myNewRole, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[2] { newLeaderMemberId, myNewRole }, ct);
        }

        [Rpc("getAvatars")]
        public AvatarBinary[] GetAvatars(string[] avatarIds, CancellationToken ct = default(CancellationToken))
        {
            return (AvatarBinary[])Invoke(MethodBase.GetCurrentMethod(), new object[1] { avatarIds }, ct);
        }

        [Rpc("getClanMsgs")]
        public ClanUserMessage[] GetClanMsgs(int page, int size, CancellationToken ct = default(CancellationToken))
        {
            return (ClanUserMessage[])Invoke(MethodBase.GetCurrentMethod(), new object[2] { page, size }, ct);
        }

        [Rpc("getPlayerClosedRequests")]
        public ClanClosedRequest[] GetPlayerClosedRequests(RequestType requestType, int page, int size, CancellationToken ct = default(CancellationToken))
        {
            //return (ClanClosedRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { requestType, page, size }, ct);
            return new ClanClosedRequest[0];
        }

        [Rpc("findClan")]
        public Clan[] FindClan(string clanName, string tag, int page, int size, CancellationToken ct = default(CancellationToken))
        {
            //return (Clan[])Invoke(MethodBase.GetCurrentMethod(), new object[4] { clanName, tag, page, size }, ct);
            return new Clan[0];
        }

        [Rpc("getPlayerClan")]
        public Clan GetPlayerClan(CancellationToken ct = default(CancellationToken))
        {
            //return (Clan)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
            return new Clan();
        }

        [Rpc("getLevels")]
        public ClanLevel[] GetLevels(CancellationToken ct = default(CancellationToken))
        {
            //return (ClanLevel[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
            return new ClanLevel[0];
        }

        [Rpc("declineRequest")]
        public void DeclineRequest(string requestId, CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[1] { requestId }, ct);
        }

        [Rpc("getUnreadClanMessagesCount")]
        public int GetUnreadClanMessagesCount(CancellationToken ct = default(CancellationToken))
        {
            //return (int)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
            return 0;
        }

        [Rpc("getClanOpenRequests")]
        public ClanOpenRequest[] GetClanOpenRequests(RequestType requestType, int page, int size, CancellationToken ct = default(CancellationToken))
        {
            //return (ClanOpenRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { requestType, page, size }, ct);
            return new ClanOpenRequest[0];
        }

        [Rpc("leaveClan")]
        public void LeaveClan(CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
        }

        [Rpc("getAllClanMembers")]
        public ClanMember[] GetAllClanMembers(CancellationToken ct = default(CancellationToken))
        {
            //return (ClanMember[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
            return new ClanMember[0];
        }

        [Rpc("readClanMsgs")]
        public void ReadClanMsgs(CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
        }

        [Rpc("deleteClanMsgs")]
        public void DeleteClanMsgs(CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
        }

        [Rpc("setClanAvatar")]
        public string SetClanAvatar(byte[] avatar, CancellationToken ct = default(CancellationToken))
        {
            return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { avatar }, ct);
        }

        [Rpc("upgradeClan")]
        public void UpgradeClan(CancellationToken ct = default(CancellationToken))
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
        }

        [Rpc("getClanClosedRequests")]
        public ClanClosedRequest[] GetClanClosedRequests(RequestType requestType, int page, int size, CancellationToken ct = default(CancellationToken))
        {
            //return (ClanClosedRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { requestType, page, size }, ct);
            return new ClanClosedRequest[0];
        }
    }
}
