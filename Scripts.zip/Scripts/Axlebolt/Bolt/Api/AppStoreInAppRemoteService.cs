using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("AppStoreInAppRemoteService")]
	public class AppStoreInAppRemoteService : RpcService
	{
		public AppStoreInAppRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("buyInApp")]
		public PlayerInventory BuyInApp(string base64, CancellationToken ct = default(CancellationToken))
		{
			return (PlayerInventory)Invoke(MethodBase.GetCurrentMethod(), new object[1] { base64 }, ct);
		}
	}
}
