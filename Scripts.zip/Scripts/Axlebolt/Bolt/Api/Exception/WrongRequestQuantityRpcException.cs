using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class WrongRequestQuantityRpcException : RpcException
	{
		public WrongRequestQuantityRpcException()
			: base(3314)
		{
		}
	}
}
