using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class GameDoesntSupportClanLevelsRpcException : RpcException
	{
		public GameDoesntSupportClanLevelsRpcException()
			: base(2014)
		{
		}
	}
}
