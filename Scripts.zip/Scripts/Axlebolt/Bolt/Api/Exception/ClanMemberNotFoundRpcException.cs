using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ClanMemberNotFoundRpcException : RpcException
	{
		public ClanMemberNotFoundRpcException()
			: base(2009)
		{
		}
	}
}
