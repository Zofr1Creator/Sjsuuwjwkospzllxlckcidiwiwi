using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ModifiedApkRpcException : RpcException
	{
		public ModifiedApkRpcException()
			: base(1004)
		{
		}
	}
}
