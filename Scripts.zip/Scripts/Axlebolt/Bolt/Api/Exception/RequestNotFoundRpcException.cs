using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class RequestNotFoundRpcException : RpcException
	{
		public RequestNotFoundRpcException()
			: base(3306)
		{
		}
	}
}
