using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InsecuredApkRpcException : RpcException
	{
		public InsecuredApkRpcException()
			: base(1001)
		{
		}
	}
}
