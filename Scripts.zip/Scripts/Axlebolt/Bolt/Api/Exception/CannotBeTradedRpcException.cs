using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class CannotBeTradedRpcException : RpcException
	{
		public CannotBeTradedRpcException()
			: base(3313)
		{
		}
	}
}
