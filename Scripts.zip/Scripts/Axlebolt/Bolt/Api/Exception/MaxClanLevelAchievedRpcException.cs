using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class MaxClanLevelAchievedRpcException : RpcException
	{
		public MaxClanLevelAchievedRpcException()
			: base(2015)
		{
		}
	}
}
