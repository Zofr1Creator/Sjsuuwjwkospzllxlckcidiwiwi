using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class PlayerIsBannedRpcException : RpcException
	{
		public PlayerIsBannedRpcException()
			: base(9999)
		{
		}

		public string GetUntil()
		{
			return GetStringParameter("until");
		}

		public string GetReason()
		{
			return GetStringParameter("reason");
		}

		public string GetBanCode()
		{
			return GetStringParameter("banCode");
		}

		public string GetUid()
		{
			return GetStringParameter("uid");
		}
	}
}
