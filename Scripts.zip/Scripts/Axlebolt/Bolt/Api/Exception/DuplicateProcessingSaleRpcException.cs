using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class DuplicateProcessingSaleRpcException : RpcException
	{
		public DuplicateProcessingSaleRpcException()
			: base(3315)
		{
		}
	}
}
