using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class HackingAppDetectedRpcException : RpcException
	{
		public HackingAppDetectedRpcException()
			: base(1002)
		{
		}

		public string GetAppSnapshot()
		{
			return GetStringParameter("appSnapshot");
		}

		public string GetIndex()
		{
			return GetStringParameter("index");
		}
	}
}
