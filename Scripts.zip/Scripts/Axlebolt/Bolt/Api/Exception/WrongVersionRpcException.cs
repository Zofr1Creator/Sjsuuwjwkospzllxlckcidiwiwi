using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class WrongVersionRpcException : RpcException
	{
		public WrongVersionRpcException()
			: base(2000)
		{
		}
	}
}
