using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ClanHasAlreadyFilledRpcException : RpcException
	{
		public ClanHasAlreadyFilledRpcException()
			: base(2013)
		{
		}
	}
}
