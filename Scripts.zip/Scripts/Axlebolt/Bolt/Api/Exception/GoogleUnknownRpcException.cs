using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class GoogleUnknownRpcException : RpcException
	{
		public GoogleUnknownRpcException()
			: base(2205)
		{
		}
	}
}
