using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class GameCenterApiRpcException : RpcException
	{
		public GameCenterApiRpcException()
			: base(2211)
		{
		}
	}
}
