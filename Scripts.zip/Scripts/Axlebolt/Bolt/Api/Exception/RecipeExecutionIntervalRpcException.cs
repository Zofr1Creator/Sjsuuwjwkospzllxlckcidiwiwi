using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class RecipeExecutionIntervalRpcException : RpcException
	{
		public RecipeExecutionIntervalRpcException()
			: base(3405)
		{
		}
	}
}
