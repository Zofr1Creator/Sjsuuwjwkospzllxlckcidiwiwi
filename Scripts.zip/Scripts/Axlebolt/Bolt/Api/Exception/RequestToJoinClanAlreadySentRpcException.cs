using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class RequestToJoinClanAlreadySentRpcException : RpcException
	{
		public RequestToJoinClanAlreadySentRpcException()
			: base(2010)
		{
		}
	}
}
