using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class PlayerIsAlreadyInClanRpcException : RpcException
	{
		public PlayerIsAlreadyInClanRpcException()
			: base(2011)
		{
		}
	}
}
