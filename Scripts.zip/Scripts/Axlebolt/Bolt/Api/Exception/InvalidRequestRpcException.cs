using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InvalidRequestRpcException : RpcException
	{
		public InvalidRequestRpcException()
			: base(3311)
		{
		}
	}
}
