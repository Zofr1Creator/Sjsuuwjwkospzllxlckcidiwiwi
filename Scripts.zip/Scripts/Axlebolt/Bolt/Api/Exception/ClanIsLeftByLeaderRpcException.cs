using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ClanIsLeftByLeaderRpcException : RpcException
	{
		public ClanIsLeftByLeaderRpcException()
			: base(2012)
		{
		}
	}
}
