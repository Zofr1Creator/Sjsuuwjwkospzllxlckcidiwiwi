using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ThirdPartyServiceUnavailableRpcException : RpcException
	{
		public ThirdPartyServiceUnavailableRpcException()
			: base(8004)
		{
		}
	}
}
