using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InventoryItemDefinitionNotFoundRpcException : RpcException
	{
		public InventoryItemDefinitionNotFoundRpcException()
			: base(3201)
		{
		}
	}
}
