using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class AdRewardInvalidRecipeRpcException : RpcException
	{
		public AdRewardInvalidRecipeRpcException()
			: base(6007)
		{
		}
	}
}
