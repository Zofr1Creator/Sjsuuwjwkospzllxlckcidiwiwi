using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InvalidApiKeyRpcException : RpcException
	{
		public InvalidApiKeyRpcException()
			: base(2007)
		{
		}
	}
}
