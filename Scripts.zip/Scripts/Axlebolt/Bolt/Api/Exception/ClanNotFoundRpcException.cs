using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class ClanNotFoundRpcException : RpcException
	{
		public ClanNotFoundRpcException()
			: base(2008)
		{
		}
	}
}
