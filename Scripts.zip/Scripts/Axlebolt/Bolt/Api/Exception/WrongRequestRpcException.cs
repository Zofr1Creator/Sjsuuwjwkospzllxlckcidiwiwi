using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class WrongRequestRpcException : RpcException
	{
		public WrongRequestRpcException()
			: base(3305)
		{
		}
	}
}
