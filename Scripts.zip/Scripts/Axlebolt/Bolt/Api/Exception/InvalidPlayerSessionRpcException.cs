using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InvalidPlayerSessionRpcException : RpcException
	{
		public InvalidPlayerSessionRpcException()
			: base(3103)
		{
		}
	}
}
