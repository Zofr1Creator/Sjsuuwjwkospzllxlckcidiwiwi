using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class GroupNotFoundRpcException : RpcException
	{
		public GroupNotFoundRpcException()
			: base(5010)
		{
		}
	}
}
