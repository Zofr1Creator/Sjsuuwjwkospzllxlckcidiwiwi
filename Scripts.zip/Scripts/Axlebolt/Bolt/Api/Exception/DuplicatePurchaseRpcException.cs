using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class DuplicatePurchaseRpcException : RpcException
	{
		public DuplicatePurchaseRpcException()
			: base(3312)
		{
		}
	}
}
