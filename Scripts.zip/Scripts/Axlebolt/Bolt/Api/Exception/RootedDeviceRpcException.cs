using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class RootedDeviceRpcException : RpcException
	{
		public RootedDeviceRpcException()
			: base(1003)
		{
		}
	}
}
