using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InAppDefinitionNotFoundRpcException : RpcException
	{
		public InAppDefinitionNotFoundRpcException()
			: base(8002)
		{
		}
	}
}
