using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class WrongRequestPriceRpcException : RpcException
	{
		public WrongRequestPriceRpcException()
			: base(3307)
		{
		}
	}
}
