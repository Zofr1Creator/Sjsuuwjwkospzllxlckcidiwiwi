using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class InvalidPayloadRpcException : RpcException
	{
		public InvalidPayloadRpcException()
			: base(8003)
		{
		}
	}
}
