using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class UnconfirmedTransactionRpcException : RpcException
	{
		public UnconfirmedTransactionRpcException()
			: base(8001)
		{
		}
	}
}
