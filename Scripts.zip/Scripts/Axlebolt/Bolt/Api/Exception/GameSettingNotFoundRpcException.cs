using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api.Exception
{
	public class GameSettingNotFoundRpcException : RpcException
	{
		public GameSettingNotFoundRpcException()
			: base(4003)
		{
		}
	}
}
