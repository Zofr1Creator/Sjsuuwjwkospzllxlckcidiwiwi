using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("AmazonInAppRemoteService")]
	public class AmazonInAppRemoteService : RpcService
	{
		public AmazonInAppRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("buyInApp")]
		public PlayerInventory BuyInApp(string transactionId, CancellationToken ct = default(CancellationToken))
		{
			return (PlayerInventory)Invoke(MethodBase.GetCurrentMethod(), new object[1] { transactionId }, ct);
		}
	}
}
