using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[EventListener("PlayerStatsRemoteEventListener")]
	public interface IPlayerStatsRemoteEventListener
	{
		[Event("onStatUpdated")]
		void OnStatsUpdated(PlayerStat[] updatedStats);
	}
}
