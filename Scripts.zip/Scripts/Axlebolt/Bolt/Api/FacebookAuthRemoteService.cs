using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("FacebookAuthRemoteService")]
	public class FacebookAuthRemoteService : RpcService
	{
		public FacebookAuthRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("protoAuth")]
		public string Auth(AuthFacebook auth, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { auth }, ct);
		}

		[Rpc("auth")]
		public string Auth(string gameId, string gameVersion, Axlebolt.Bolt.Protobuf.Platform platform, string token, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[4] { gameId, gameVersion, platform, token }, ct);
		}

		[Rpc("protoAuthSecured")]
		public string Auth(AuthFacebook auth, AppVerification verification, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[2] { auth, verification }, ct);
		}
	}
}
