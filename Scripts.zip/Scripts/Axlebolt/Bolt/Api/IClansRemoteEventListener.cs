using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [EventListener("ClansRemoteEventListener")]
    public interface IClansRemoteEventListener
    {
        [Event("onLeftFromClan")]
        void OnLeftFromClan(OnLeftFromClan onLeftFromClan);

        [Event("onPlayerAttributesChanged")]
        void OnPlayerAttributesChanged(OnPlayerAttributesChanged onPlayerAttributesChanged);

        [Event("onClanUpgrade")]
        void OnClanUpgrade(OnClanUpgradeEvent onClanUpgradeEvent);

        [Event("OnJoinRequestTaken")]
        void OnJoinRequestTaken(OnJoinRequestTakenEvent onJoinRequestTakenEvent);

        [Event("OnInvitedToClanEvent")]
        void OnInvitedToClanEvent(OnInvitedToClanEvent onInvitedToClanEvent);

        [Event("onClanNameChanged")]
        void OnClanNameChanged(OnClanNameChanged onClanNameChanged);

        [Event("onKickedEvent")]
        void OnKickedEvent(OnKickedEvent onKickedEvent);

        [Event("OnKickedMember")]
        void OnKickedMember(OnKickedMemberEvent onKickedMemberEvent);

        [Event("onIncomingClanMessage")]
        void OnIncomingClanMessage(OnIncomingClanMessage onIncomingClanMessage);

        [Event("onClanTypeChanged")]
        void OnClanTypeChanged(OnClanTypeChanged onClanTypeChanged);

        [Event("onRequestDeclined")]
        void OnRequestDeclined(OnRequestDeclined onRequestDeclined);

        [Event("OnAssignedRoleEvent")]
        void OnAssignedRoleEvent(OnAssignedRoleEvent onAssignedRoleEvent);

        [Event("OnMemberJoinedToClan")]
        void OnMemberJoinedToClan(OnMemberJoinedToClanEvent onMemberJoinedToClanEvent);

        [Event("OnJoinedToClan")]
        void OnJoinedToClan(OnJoinedToClanEvent onJoinedToClanEvent);
    }
}
