using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [RpcService("GameEventRemoteService")]
    public class GameEventRemoteService : RpcService
    {
        public GameEventRemoteService(ClientService client)
            : base(client)
        {
        }

        [Rpc("progressGameEvent")]
        public ProgressGameEventResponse ProgressGameEvent(ProgressGameEventRequest request, CancellationToken ct = default)
        {
            return (ProgressGameEventResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { request }, ct);
        }

        [Rpc("saveChallenge")]
        public void SaveChallenge(string code, string action, int targetPoints, CancellationToken ct = default)
        {
            Invoke(MethodBase.GetCurrentMethod(), new object[] { code, action, targetPoints }, ct);
        }

        [Rpc("getCurrentGameEvents")]
        public GetCurrentGameEventsResponse GetCurrentGameEvents(CancellationToken ct = default)
        {
            return (GetCurrentGameEventsResponse)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
        }

        [Rpc("setChallengeProgress")]
        public ProgressChallengeResponse SetChallengeProgress(ProgressChallengeRequest request, CancellationToken ct = default)
        {
            return (ProgressChallengeResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { request }, ct);
        }

        [Rpc("getCurrentChallenges")]
        public GetCurrentChallengesResponse GetCurrentChallenges(GetCurrentChallengesRequest request, CancellationToken ct = default)
        {
            return (GetCurrentChallengesResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { request }, ct);
        }
    }
}
