using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameServerStatsRemoteService")]
	public class GameServerStatsRemoteService : RpcService
	{
		public GameServerStatsRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("getStats")]
		public Axlebolt.Bolt.Protobuf.Stats GetStats(string playerId, string[] apiNames, CancellationToken ct = default(CancellationToken))
		{
			return (Axlebolt.Bolt.Protobuf.Stats)Invoke(MethodBase.GetCurrentMethod(), new object[2] { playerId, apiNames }, ct);
		}

		[Rpc("storeStats")]
		public void StoreStats(PlayerStats[] stats, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { stats }, ct);
		}

		[Rpc("getPlayersStats")]
		public PlayerStats[] GetPlayersStats(string[] playerIds, string[] apiNames, CancellationToken ct = default(CancellationToken))
		{
			return (PlayerStats[])Invoke(MethodBase.GetCurrentMethod(), new object[2] { playerIds, apiNames }, ct);
		}
	}
}
