using System.Reflection;
using System.Threading;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("BoltRemoteService")]
	public class BoltRemoteService : RpcService
	{
		public BoltRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("unsubscribe")]
		public void Unsubscribe(string topic, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { topic }, ct);
		}

		[Rpc("systemTime")]
		public long SystemTime(CancellationToken ct = default(CancellationToken))
		{
			return (long)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("subscribe")]
		public void Subscribe(string topic, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { topic }, ct);
		}
	}
}
