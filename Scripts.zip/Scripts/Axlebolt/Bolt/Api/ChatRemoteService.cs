using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("ChatRemoteService")]
	public class ChatRemoteService : RpcService
	{
		public ChatRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("getGroupMsgs")]
		public UserMessage[] GetGroupMsgs(string groupId, int page, int pageSize, CancellationToken ct = default(CancellationToken))
		{
			return (UserMessage[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { groupId, page, pageSize }, ct);
		}

		[Rpc("getFriendMsgsByPage")]
		public UserMessage[] GetFriendMsgs(string friendId, Page page, CancellationToken ct = default(CancellationToken))
		{
			return (UserMessage[])Invoke(MethodBase.GetCurrentMethod(), new object[2] { friendId, page }, ct);
		}

		[Rpc("readFriendMsgs")]
		public void ReadFriendMsgs(string friendId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { friendId }, ct);
		}

		[Rpc("sendGlobalChatMessage")]
		public void SendGlobalChatMessage(string topic, string message, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { topic, message }, ct);
		}

		[Rpc("getFriendMsgs")]
		public UserMessage[] GetFriendMsgs(string friendId, int page, int size, CancellationToken ct = default(CancellationToken))
		{
			return (UserMessage[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { friendId, page, size }, ct);
		}

		[Rpc("getChatUsers")]
		public ChatUser[] GetChatUsers(CancellationToken ct = default(CancellationToken))
		{
			return (ChatUser[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("deleteGroupMsgs")]
		public void DeleteGroupMsgs(string groupId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { groupId }, ct);
		}

		[Rpc("readGroupMsgs")]
		public void ReadGroupMsgs(string groupId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { groupId }, ct);
		}

		[Rpc("sendGroupMsg")]
		public void SendGroupMsg(string groupId, string msg, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { groupId, msg }, ct);
		}

		[Rpc("getFriendMsgsByOffset")]
		public UserMessage[] GetFriendMsgs(string friendId, Offset offset, CancellationToken ct = default(CancellationToken))
		{
			return (UserMessage[])Invoke(MethodBase.GetCurrentMethod(), new object[2] { friendId, offset }, ct);
		}

		[Rpc("getUnreadChatUsersCount")]
		public int GetUnreadChatUsersCount(CancellationToken ct = default(CancellationToken))
		{
			return (int)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("deleteFriendMsgs")]
		public void DeleteFriendMsgs(string friendId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { friendId }, ct);
		}

		[Rpc("sendFriendMsg")]
		public void SendFriendMsg(string friendId, string msg, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { friendId, msg }, ct);
		}
	}
}
