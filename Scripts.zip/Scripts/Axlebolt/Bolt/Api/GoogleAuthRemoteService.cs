using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GoogleAuthRemoteService")]
	public class GoogleAuthRemoteService : RpcService
	{
		public GoogleAuthRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("auth")]
		public string Auth(string gameId, string gameVersion, Axlebolt.Bolt.Protobuf.Platform platform, string authCode, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[4] { gameId, gameVersion, platform, authCode }, ct);
		}

		[Rpc("protoAuth")]
		public string Auth(AuthGoogle auth, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { auth }, ct);
		}

		[Rpc("protoAuthSecured")]
		public string Auth(AuthGoogle auth, AppVerification verification, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[2] { auth, verification }, ct);
		}
	}
}
