using System;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [EventListener("GlobalChatRemoteEventListener")]
    public interface IGlobalChatRemoteEventListener
    {
        [Event("onIncomingGlobalChatMessage")]
        void OnIncomingGlobalChatMessage(GlobalChatUserMessage message);
    }
}
