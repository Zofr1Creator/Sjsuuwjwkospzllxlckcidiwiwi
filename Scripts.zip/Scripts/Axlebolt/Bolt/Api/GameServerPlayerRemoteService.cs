using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameServerPlayerRemoteService")]
	public class GameServerPlayerRemoteService : RpcService
	{
		public GameServerPlayerRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("setPhotonGame")]
		public void SetPhotonGame(string playerId, PhotonGame photonGame, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { playerId, photonGame }, ct);
		}
	}
}
