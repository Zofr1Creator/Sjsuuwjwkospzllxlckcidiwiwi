using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[EventListener("AdsRemoteEventListener")]
	public interface IAdsRemoteEventListener
	{
		[Event("onAdRewarded")]
		void OnAdRewarded(CurrencyAmount[] rewardedCurrencies, InventoryItem[] rewardedItems, InventoryItem[] exchangeItems, CurrencyAmount[] exchangeCurrencies);
	}
}
