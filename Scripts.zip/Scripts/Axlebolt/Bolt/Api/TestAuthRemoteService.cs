using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("TestAuthRemoteService")]
	public class TestAuthRemoteService : RpcService
	{
		public TestAuthRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("auth")]
		public string Auth(string gameId, string gameVersion, Axlebolt.Bolt.Protobuf.Platform platform, string token, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[4] { gameId, gameVersion, platform, token }, ct);
		}
	}
}
