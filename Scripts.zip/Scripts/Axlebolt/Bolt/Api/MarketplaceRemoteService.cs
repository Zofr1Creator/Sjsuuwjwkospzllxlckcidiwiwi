using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("MarketplaceRemoteService")]
	public class MarketplaceRemoteService : RpcService
	{
		public MarketplaceRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("createPurchaseRequestBySale")]
		public string CreatePurchaseRequestBySale(CreatePurchaseBySaleArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("createSaleRequest")]
		public string CreateSaleRequest(CreateSaleRequestArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getPlayerClosedRequests")]
		public ClosedRequest[] GetPlayerClosedRequests(GetClosedRequestsArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (ClosedRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getTradeOpenPurchaseRequests")]
		public OpenRequest[] GetTradeOpenPurchaseRequests(GetTradeOpenPurchaseRequestsArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (OpenRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getPlayerOpenRequests")]
		public OpenRequest[] GetPlayerOpenRequests(CancellationToken ct = default(CancellationToken))
		{
			return (OpenRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("getTrade")]
		public Trade GetTrade(GetTradeArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (Trade)Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getPlayerProcessingRequest")]
		public ProcessingRequest[] GetPlayerProcessingRequests(CancellationToken ct = default(CancellationToken))
		{
			return (ProcessingRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("createPurchaseRequest")]
		public string CreatePurchaseRequest(CreatePurchaseRequestArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getTrades")]
		public Trade[] GetTrades(GetTradesArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (Trade[])Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getTradeOpenSaleRequests")]
		public OpenRequest[] GetTradeOpenSaleRequests(GetTradeOpenSaleRequestsArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (OpenRequest[])Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getPlayerClosedRequestsCount")]
		public int GetPlayerClosedRequestsCount(GetClosedRequestsCountArgs args, CancellationToken ct = default(CancellationToken))
		{
			return (int)Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("getMarketplaceSettings")]
		public MarketplaceSettings GetMarketplaceSettings(CancellationToken ct = default(CancellationToken))
		{
			return (MarketplaceSettings)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("cancelRequest")]
		public void CancelRequest(CancelRequestArgs args, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}
	}
}
