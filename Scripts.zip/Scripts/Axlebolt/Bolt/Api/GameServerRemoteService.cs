using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameServerRemoteService")]
	public class GameServerRemoteService : RpcService
	{
		public GameServerRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("serverHandshake")]
		public void ServerHandshake(ServerHandshake handshake, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { handshake }, ct);
		}

		[Rpc("logout")]
		public void Logout(CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}
	}
}
