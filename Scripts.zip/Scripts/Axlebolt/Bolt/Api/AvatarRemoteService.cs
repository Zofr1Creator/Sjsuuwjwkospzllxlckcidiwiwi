using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [RpcService("AvatarRemoteService")]
    public class AvatarRemoteService : RpcService
    {
        public AvatarRemoteService(ClientService client)
            : base(client)
        {
        }

        [Rpc("getAvatars")]
        public AvatarBinary[] GetAvatars(string[] avatarIds, CancellationToken ct = default)
        {
            return (AvatarBinary[])Invoke(MethodBase.GetCurrentMethod(), new object[] { avatarIds }, ct);
        }
    }
}