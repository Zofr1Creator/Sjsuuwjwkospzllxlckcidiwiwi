using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[EventListener("MarketplaceRemoteEventListener")]
	public interface IMarketplaceRemoteEventListener
	{
		[Event("onPlayerRequestOpened")]
		void OnPlayerRequestOpened(OnPlayerRequestOpenedEvent openRequestEvent);

		[Event("onPlayerRequestClosed")]
		void OnPlayerRequestClosed(OnPlayerRequestClosedEvent closedRequestEvent);

		[Event("onTradeUpdated")]
		void OnTradeUpdated(OnTradeUpdatedEvent tradeUpdatedEvent);

		[Event("onTradeRequestOpened")]
		void OnTradeRequestOpened(OnTradeRequestOpenedEvent openedEvent);

		[Event("onTradeRequestClosed")]
		void OnTradeRequestClosed(OnTradeRequestClosedEvent closedEvent);
	}
}
