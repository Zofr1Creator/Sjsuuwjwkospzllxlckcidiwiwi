using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("HackDetectionRemoteService")]
	public class HackDetectionRemoteService : RpcService
	{
		public HackDetectionRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("hackDetection")]
		public void HackDetection(HackDetection hackDetection, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { hackDetection }, ct);
		}

		[Rpc("systemTime")]
		public long SystemTime(CancellationToken ct = default(CancellationToken))
		{
			return (long)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}
	}
}
