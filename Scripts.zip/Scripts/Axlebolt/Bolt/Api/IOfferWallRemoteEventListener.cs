using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[EventListener("OfferWallRemoteEventListener")]
	public interface IOfferWallRemoteEventListener
	{
		[Event("onOfferWallRewarded")]
		void OnOfferWallRewarded(CurrencyAmount[] rewardedCurrencies);
	}
}
