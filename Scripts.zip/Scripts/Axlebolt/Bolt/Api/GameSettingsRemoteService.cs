using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameSettingsRemoteService")]
	public class GameSettingsRemoteService : RpcService
	{
		public GameSettingsRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("getGameSettings")]
		public GameSetting[] GetGameSettings(CancellationToken ct = default(CancellationToken))
		{
			return (GameSetting[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("deleteGameSettings")]
		public void DeleteGameSettings(string settingsId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { settingsId }, ct);
		}

		[Rpc("updateGameSettings")]
		public void UpdateGameSettings(GameSetting settings, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { settings }, ct);
		}
	}
}
