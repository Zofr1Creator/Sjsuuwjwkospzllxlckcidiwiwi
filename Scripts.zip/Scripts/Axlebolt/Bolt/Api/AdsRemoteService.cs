using System.Reflection;
using System.Threading;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("AdsRemoteService")]
	public class AdsRemoteService : RpcService
	{
		public AdsRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("giveAdReward")]
		public void GiveAdReward(string conditions, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { conditions }, ct);
		}
	}
}
