using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GoogleInAppRemoteService")]
	public class GoogleInAppRemoteService : RpcService
	{
		public GoogleInAppRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("buyInApp")]
		public PlayerInventory BuyInApp(string json, string signature, CancellationToken ct = default(CancellationToken))
		{
			return (PlayerInventory)Invoke(MethodBase.GetCurrentMethod(), new object[2] { json, signature }, ct);
		}
	}
}
