using System;
using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("InventoryRemoteService")]
	public class InventoryRemoteService : RpcService
	{
		public InventoryRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("setInventoryItemFlags")]
		public void SetInventoryItemFlags(ItemFlags itemFlags, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { itemFlags }, ct);
		}

		[Rpc("buyInventoryItem")]
		public InventoryItem[] BuyInventoryItem(int inventoryItemId, int quantity, int currencyId, bool toManyItems, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem[])Invoke(MethodBase.GetCurrentMethod(), new object[4] { inventoryItemId, quantity, currencyId, toManyItems }, ct);
		}

		[Rpc("getOtherPlayerItems")]
		public InventoryItem[] GetPlayerInventory(string playerId, int[] itemDefinitionIds, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem[])Invoke(MethodBase.GetCurrentMethod(), new object[2] { playerId, itemDefinitionIds }, ct);
		}

		[Rpc("getPlayerInventory")]
		public PlayerInventory GetPlayerInventory(CancellationToken ct = default(CancellationToken))
		{
			return (PlayerInventory)Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("getInventoryItemPropertyDefinitions")]
		public InventoryItemPropertyDefinitions[] GetInventoryItemPropertyDefinitions(CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItemPropertyDefinitions[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("sellInventoryItem")]
		public InventoryItem SellInventoryItem(int inventoryItemId, int quantity, int currencyId, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem)Invoke(MethodBase.GetCurrentMethod(), new object[3] { inventoryItemId, quantity, currencyId }, ct);
		}

		[Rpc("transferInventoryItems")]
		public InventoryItem[] TransferInventoryItems(int fromItemId, int toItemId, int quantity, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem[])Invoke(MethodBase.GetCurrentMethod(), new object[3] { fromItemId, toItemId, quantity }, ct);
		}

		[Rpc("consumeInventoryItem")]
		public InventoryItem ConsumeInventoryItem(int inventoryItemId, int quantity, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem)Invoke(MethodBase.GetCurrentMethod(), new object[2] { inventoryItemId, quantity }, ct);
		}

		[Rpc("exchangeInventoryItems")]
		public ExchangeResult ExchangeInventoryItems(string recipeCode, CurrencyAmount[] currencies, int[] inventoryItemIds, CancellationToken ct = default(CancellationToken))
		{
			return (ExchangeResult)Invoke(MethodBase.GetCurrentMethod(), new object[3] { recipeCode, currencies, inventoryItemIds }, ct);
		}

		[Rpc("setInventoryItemsProperties")]
		public void SetInventoryItemsProperties(InventoryItemProperties[] args, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { args }, ct);
		}

		[Rpc("tradeInventoryItems")]
		public InventoryItem[] TradeInventoryItems(int[] localItemId, CurrencyAmount[] localCurrencyAmount, long? remotePlayerId, int[] remoteItemId, CurrencyAmount[] remoteCurrencyAmount, CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItem[])Invoke(MethodBase.GetCurrentMethod(), new object[5] { localItemId, localCurrencyAmount, remotePlayerId, remoteItemId, remoteCurrencyAmount }, ct);
		}

		[Rpc("getInventoryItemDefinitions")]
		public InventoryItemDefinition[] GetInventoryItemDefinitions(CancellationToken ct = default(CancellationToken))
		{
			return (InventoryItemDefinition[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

        [Rpc("generateCoupon")]
        public GenerateCouponResponse GenerateCoupon(GenerateCouponRequest request, CancellationToken ct = default)
        {
            return (GenerateCouponResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { request }, ct);
        }

        [Rpc("getPlayerCoupons")]
        public GetPlayerCouponsResponse GetPlayerCoupons(int from, int count, CancellationToken ct = default)
        {
            return (GetPlayerCouponsResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { from, count }, ct);
        }

        [Rpc("activateCoupon")]
        public ActivateCouponResponse ActivateCoupon(ActivateCouponRequest request, CancellationToken ct = default)
        {
            return (ActivateCouponResponse)Invoke(MethodBase.GetCurrentMethod(), new object[] { request }, ct);
        }

        [Rpc("applyInventoryItem")]
        public InventoryItem ApplyInventoryItem(int consumedItemId, int appliedItemId, string appliedPropertyName, bool isRemovable, CancellationToken ct = default)
        {
            return (InventoryItem)Invoke(MethodBase.GetCurrentMethod(), new object[] { consumedItemId, appliedItemId, appliedPropertyName, isRemovable }, ct);
        }

        [Rpc("removeInventoryItemProperty")]
        public InventoryItem RemoveInventoryItemProperty(int itemId, string propertyName, CancellationToken ct = default)
        {
            return (InventoryItem)Invoke(MethodBase.GetCurrentMethod(), new object[] { itemId, propertyName }, ct);
        }
    }
}
