using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameSettingsGameServerRemoteService")]
	public class GameSettingsGameServerRemoteService : RpcService
	{
		public GameSettingsGameServerRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("updateGameSettings")]
		public void UpdateGameSettings(string settingsId, string value, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { settingsId, value }, ct);
		}

		[Rpc("deleteGameSettings")]
		public void DeleteGameSettings(string settingsId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { settingsId }, ct);
		}

		[Rpc("getGameSettings")]
		public GameSetting[] GetGameSettings(CancellationToken ct = default(CancellationToken))
		{
			return (GameSetting[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}
	}
}
