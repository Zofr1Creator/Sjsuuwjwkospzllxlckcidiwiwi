using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
    [EventListener("GameEventRemoteEventListener")]
    public interface IGameEventRemoteEventListener
    {
        [Event("onGamePassChanged")]
        void OnGamePassChanged(OnGamePassChangedEvent gamePassChangedEvent); 
    }
}
