using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("HandshakeRemoteService")]
	public class HandshakeRemoteService : RpcService
	{
		public HandshakeRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("protoHandshake")]
		public void Handshake(Handshake handshake, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { handshake }, ct);
		}

		[Rpc("logout")]
		public void Logout(CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("handshake")]
		public void Handshake(string ticket, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { ticket }, ct);
		}
	}
}
