using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{

    [EventListener("ClanMessagesRemoteEventListener")]
    public interface IClanMessagesRemoteEventListener
    {
        [Event("onIncomingClanChatMessage")]
        void OnIncomingClanChatMessage(ClanUserMessage clanUserMessage);
    }
}
