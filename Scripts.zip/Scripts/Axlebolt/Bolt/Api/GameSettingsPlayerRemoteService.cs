using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameSettingsPlayerRemoteService")]
	public class GameSettingsPlayerRemoteService : RpcService
	{
		public GameSettingsPlayerRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("updateGameSettings")]
		public void UpdateGameSettings(string settingsId, GameSetting settings, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[2] { settingsId, settings }, ct);
		}

		[Rpc("getGameSettings")]
		public GameSetting[] GetGameSettings(CancellationToken ct = default(CancellationToken))
		{
			return (GameSetting[])Invoke(MethodBase.GetCurrentMethod(), new object[0], ct);
		}

		[Rpc("deleteGameSettings")]
		public void DeleteGameSettings(string settingsId, CancellationToken ct = default(CancellationToken))
		{
			Invoke(MethodBase.GetCurrentMethod(), new object[1] { settingsId }, ct);
		}
	}
}
