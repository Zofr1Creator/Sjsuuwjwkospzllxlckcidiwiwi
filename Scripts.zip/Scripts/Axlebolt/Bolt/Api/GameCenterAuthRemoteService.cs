using System.Reflection;
using System.Threading;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport;

namespace Axlebolt.Bolt.Api
{
	[RpcService("GameCenterAuthRemoteService")]
	public class GameCenterAuthRemoteService : RpcService
	{
		public GameCenterAuthRemoteService(ClientService client)
			: base(client)
		{
		}

		[Rpc("auth")]
		public string Auth(string gameId, string gameVersion, Axlebolt.Bolt.Protobuf.Platform platform, string playerId, string bundleId, string publicKeyUrl, byte[] signature, byte[] salt, long timestamp, string defaultName, CancellationToken ct = default(CancellationToken))
		{
			return (string)Invoke(MethodBase.GetCurrentMethod(), new object[10] { gameId, gameVersion, platform, playerId, bundleId, publicKeyUrl, signature, salt, timestamp, defaultName }, ct);
		}
	}
}
