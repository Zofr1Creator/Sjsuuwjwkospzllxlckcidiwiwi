namespace Axlebolt.Bolt.Common
{
    public class DayRange
    {
        public int From { get; }

        public int To { get; }

        public DayRange(int from, int to)
        {
            From = from;
            To = to;
        }
    }
}
