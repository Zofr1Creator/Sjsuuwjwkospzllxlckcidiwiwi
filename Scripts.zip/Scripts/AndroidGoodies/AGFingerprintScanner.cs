using System;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public class AGFingerprintScanner
	{
		[PublicAPI]
		public enum Warning
		{
			[PublicAPI]
			Good,
			[PublicAPI]
			Partial,
			[PublicAPI]
			Insufficient,
			[PublicAPI]
			Dirty,
			[PublicAPI]
			TooSlow,
			[PublicAPI]
			TooFast,
			[PublicAPI]
			Failure
		}

		[PublicAPI]
		public enum Error
		{
			[PublicAPI]
			Unavailable,
			[PublicAPI]
			UnableToProcess,
			[PublicAPI]
			Timeout,
			[PublicAPI]
			NotEnoughSpace,
			[PublicAPI]
			Canceled,
			[PublicAPI]
			Lockout,
			[PublicAPI]
			CryptoObjectInit,
			[PublicAPI]
			DecryptionFailed,
			[PublicAPI]
			EncryptionFailed,
			[PublicAPI]
			Unknown
		}

		private static AndroidJavaObject _goldfingerAjo;

		private static AndroidJavaObject GoldfingerAJO
		{
			get
			{
				if (_goldfingerAjo == null)
				{
					_goldfingerAjo = new AndroidJavaObject("com.deadmosquitogames.goldfinger.Goldfinger$Builder", AGUtils.Activity).CallAJO("build");
				}
				return _goldfingerAjo;
			}
		}

		[PublicAPI]
		public static bool HasFingerprintHardware
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return false;
				}
				return GoldfingerAJO.CallBool("hasFingerprintHardware");
			}
		}

		[PublicAPI]
		public static bool HasEnrolledFingerprint
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return false;
				}
				return GoldfingerAJO.CallBool("hasEnrolledFingerprint");
			}
		}

		[PublicAPI]
		public static void Authenticate(Action onSuccess, Action<Warning> onWarning, Action<Error> onError)
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				GoldfingerAJO.Call("authenticate", new FingerprintCallback(delegate
				{
					onSuccess();
				}, onWarning, onError));
			}
		}

		[PublicAPI]
		public static void Encrypt(string keyName, string value, Action<string> onSuccess, Action<Warning> onWarning, Action<Error> onError)
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				GoldfingerAJO.Call("encrypt", keyName, value, new FingerprintCallback(onSuccess, onWarning, onError));
			}
		}

		[PublicAPI]
		public static void Decrypt(string keyName, string value, Action<string> onSuccess, Action<Warning> onWarning, Action<Error> onError)
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				GoldfingerAJO.Call("decrypt", keyName, value, new FingerprintCallback(onSuccess, onWarning, onError));
			}
		}

		[PublicAPI]
		public static void Cancel()
		{
			if (!AGUtils.IsNotAndroidCheck() && _goldfingerAjo != null)
			{
				_goldfingerAjo.Call("cancel");
				_goldfingerAjo.Dispose();
				_goldfingerAjo = null;
			}
		}
	}
}
