using System;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies.Internal
{
	public class FingerprintCallback : AndroidJavaProxy
	{
		private readonly Action<string> _successCallback;

		private readonly Action<AGFingerprintScanner.Warning> _warningCallback;

		private readonly Action<AGFingerprintScanner.Error> _errorCallback;

		public FingerprintCallback(Action<string> successCallback, Action<AGFingerprintScanner.Warning> warningCallback, Action<AGFingerprintScanner.Error> errorCallback)
			: base("com.deadmosquitogames.goldfinger.Goldfinger$Callback")
		{
			_successCallback = successCallback;
			_warningCallback = warningCallback;
			_errorCallback = errorCallback;
		}

		private void onSuccess(string value)
		{
			GoodiesSceneHelper.Queue(delegate
			{
				_successCallback(value);
			});
		}

		private void onWarning(AndroidJavaObject warning)
		{
			GoodiesSceneHelper.Queue(delegate
			{
				_warningCallback((AGFingerprintScanner.Warning)warning.CallInt("getValue"));
			});
		}

		private void onError(AndroidJavaObject error)
		{
			GoodiesSceneHelper.Queue(delegate
			{
				_errorCallback((AGFingerprintScanner.Error)error.CallInt("getValue"));
			});
		}
	}
}
