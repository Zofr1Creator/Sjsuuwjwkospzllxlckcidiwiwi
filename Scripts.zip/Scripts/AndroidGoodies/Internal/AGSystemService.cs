using System;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies.Internal
{
	public static class AGSystemService
	{
		private const string VIBRATOR_SERVICE = "vibrator";

		private static AndroidJavaObject _vibratorService;

		private const string LOCATION_SERVICE = "location";

		private static AndroidJavaObject _locationService;

		private const string CONNECTIVITY_SERVICE = "connectivity";

		private static AndroidJavaObject _connectivityService;

		private const string WIFI_SERVICE = "wifi";

		private static AndroidJavaObject _wifiService;

		private const string TELEPHONY_SERVICE = "phone";

		private static AndroidJavaObject _telephonyService;

		private const string NOTIFICATION_SERVICE = "notification";

		private static AndroidJavaObject _notificationService;

		private const string CAMERA_SERVICE = "camera";

		private static AndroidJavaObject _cameraService;

		private const string CLIPBOARD_SERVICE = "clipboard";

		private static AndroidJavaObject _clipboardService;

		public static AndroidJavaObject VibratorService
		{
			get
			{
				if (_vibratorService == null)
				{
					_vibratorService = GetSystemService("vibrator", "android.os.Vibrator");
				}
				return _vibratorService;
			}
		}

		public static AndroidJavaObject LocationService
		{
			get
			{
				if (_locationService == null)
				{
					_locationService = GetSystemService("location", "android.location.LocationManager");
				}
				return _locationService;
			}
		}

		public static AndroidJavaObject ConnectivityService
		{
			get
			{
				if (_connectivityService == null)
				{
					_connectivityService = GetSystemService("connectivity", "android.net.ConnectivityManager");
				}
				return _connectivityService;
			}
		}

		public static AndroidJavaObject WifiService
		{
			get
			{
				if (_wifiService == null)
				{
					_wifiService = GetSystemService("wifi", "android.net.wifi.WifiManager");
				}
				return _wifiService;
			}
		}

		public static AndroidJavaObject TelephonyService
		{
			get
			{
				if (_telephonyService == null)
				{
					_telephonyService = GetSystemService("phone", "android.telephony.TelephonyManager");
				}
				return _telephonyService;
			}
		}

		public static AndroidJavaObject NotificationService
		{
			get
			{
				if (_notificationService == null)
				{
					_notificationService = GetSystemService("notification", "android.app.NotificationManager");
				}
				return _notificationService;
			}
		}

		public static AndroidJavaObject CameraService
		{
			get
			{
				if (_cameraService == null)
				{
					_cameraService = GetSystemService("camera", "android.hardware.camera2.CameraManager");
				}
				return _cameraService;
			}
		}

		public static AndroidJavaObject ClipboardService
		{
			get
			{
				if (_clipboardService == null)
				{
					_clipboardService = GetSystemService("clipboard", "android.content.ClipboardManager");
				}
				return _clipboardService;
			}
		}

		private static AndroidJavaObject GetSystemService(string name, string serviceClass)
		{
			try
			{
				AndroidJavaObject source = AGUtils.Activity.CallAJO("getSystemService", name);
				return source.Cast(serviceClass);
			}
			catch (Exception ex)
			{
				if (Debug.isDebugBuild)
				{
					Debug.LogWarning("Failed to get " + name + " service. Error: " + ex.Message);
				}
				return null;
			}
		}
	}
}
