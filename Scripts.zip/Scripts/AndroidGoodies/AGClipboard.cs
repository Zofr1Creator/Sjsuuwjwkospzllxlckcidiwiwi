using System;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	public static class AGClipboard
	{
		[PublicAPI]
		public static void SetClipBoardText([NotNull] string label, [NotNull] string text)
		{
			if (label == null)
			{
				throw new ArgumentNullException("label");
			}
			if (text == null)
			{
				throw new ArgumentNullException("text");
			}
			AGUtils.RunOnUiThread(delegate
			{
				AndroidJavaObject androidJavaObject = "android.content.ClipData".AJCCallStaticOnceAJO("newPlainText", label, text);
				AGSystemService.ClipboardService.Call("setPrimaryClip", androidJavaObject);
			});
		}
	}
}
