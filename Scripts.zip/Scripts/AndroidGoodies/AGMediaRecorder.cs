using System;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	public static class AGMediaRecorder
	{
		public enum AudioEncoder
		{
			[PublicAPI]
			AAC = 3,
			[PublicAPI]
			AAC_ELD = 5,
			[PublicAPI]
			AMR_NB = 1,
			[PublicAPI]
			AMR_WB = 2,
			[PublicAPI]
			DEFAULT = 0,
			[PublicAPI]
			HE_AAC = 4,
			[PublicAPI]
			VORBIS = 6
		}

		[PublicAPI]
		public enum OutputFormat
		{
			[PublicAPI]
			AAC_ADTS = 6,
			[PublicAPI]
			AMR_NB = 3,
			[PublicAPI]
			AMR_WB = 4,
			[PublicAPI]
			DEFAULT = 0,
			[PublicAPI]
			MPEG_2_TS = 8,
			[PublicAPI]
			MPEG_4 = 2,
			[Obsolete("This constant was deprecated in API level 16. Deprecated in favor of MediaRecorder.OutputFormat.AMR_NB")]
			[PublicAPI]
			RAW_AMR = 3,
			[PublicAPI]
			THREE_GPP = 1,
			[PublicAPI]
			WEBM = 9
		}

		private const int MediaRecorderAudioSourceMIC = 1;

		private static AndroidJavaObject _mediaRecorder;

		[PublicAPI]
		public static void StartRecording([NotNull] string fullFilePath, OutputFormat format = OutputFormat.THREE_GPP, AudioEncoder audioEncoder = AudioEncoder.AMR_NB)
		{
			if (fullFilePath == null)
			{
				throw new ArgumentNullException("fullFilePath");
			}
			if (AGUtils.IsNotAndroidCheck())
			{
				return;
			}
			if (_mediaRecorder != null)
			{
				Debug.LogWarning("Can't start recording while another recording is in progress. Please call StopRecording() to stop previous recording.");
				return;
			}
			try
			{
				_mediaRecorder = new AndroidJavaObject("android.media.MediaRecorder");
				_mediaRecorder.Call("setAudioSource", 1);
				_mediaRecorder.Call("setOutputFormat", (int)format);
				_mediaRecorder.Call("setAudioEncoder", (int)audioEncoder);
				_mediaRecorder.Call("setOutputFile", fullFilePath);
				_mediaRecorder.Call("prepare");
				_mediaRecorder.Call("start");
			}
			catch (Exception exception)
			{
				if (Debug.isDebugBuild)
				{
					Debug.LogError("Failed to stard recording audio");
					Debug.LogException(exception);
				}
			}
		}

		[PublicAPI]
		public static bool StopRecording()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return false;
			}
			if (_mediaRecorder == null)
			{
				return false;
			}
			_mediaRecorder.Call("stop");
			_mediaRecorder.Call("release");
			_mediaRecorder.Dispose();
			_mediaRecorder = null;
			return true;
		}
	}
}
