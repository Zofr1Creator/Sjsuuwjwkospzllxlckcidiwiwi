using System;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public static class AGFileUtils
	{
		[PublicAPI]
		public static string ExternalCacheDirectory
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return null;
				}
				return AGUtils.ExternalCacheDirectory.GetAbsolutePath();
			}
		}

		[PublicAPI]
		public static string CacheDirectory
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return null;
				}
				return AGUtils.CacheDirectory.GetAbsolutePath();
			}
		}

		[PublicAPI]
		public static string CodeCacheDirectory
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return null;
				}
				return AGUtils.CodeCacheDirectory.GetAbsolutePath();
			}
		}

		[PublicAPI]
		public static string DataDir
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return null;
				}
				return AGUtils.DataDir.GetAbsolutePath();
			}
		}

		[PublicAPI]
		public static string ObbDir
		{
			get
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return null;
				}
				return AGUtils.ObbDir.GetAbsolutePath();
			}
		}

		[PublicAPI]
		public static string SaveImageToGallery([NotNull] Texture2D texture2D, string title, string folder = null, ImageFormat imageFormat = ImageFormat.PNG)
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return null;
			}
			if (texture2D == null)
			{
				throw new ArgumentNullException("texture2D", "Image to save cannot be null");
			}
			return AndroidPersistanceUtilsInternal.SaveImageToPictures(texture2D, title, folder, imageFormat);
		}

		[PublicAPI]
		public static Texture2D ImageUriToTexture2D(string imageUri)
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return null;
			}
			Check.Argument.IsStrNotNullOrEmpty(imageUri, "imageUri");
			return AGUtils.TextureFromUriInternal(imageUri);
		}
	}
}
