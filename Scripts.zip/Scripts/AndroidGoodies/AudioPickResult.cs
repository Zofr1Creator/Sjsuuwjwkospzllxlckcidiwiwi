using System;
using System.Collections.Generic;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using MiniJSON;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public class AudioPickResult
	{
		[PublicAPI]
		public string OriginalPath { get; private set; }

		[PublicAPI]
		public string DisplayName { get; private set; }

		[PublicAPI]
		public int Size { get; private set; }

		[PublicAPI]
		public string MimeType { get; private set; }

		[PublicAPI]
		public DateTime CreatedAt { get; private set; }

		public static AudioPickResult FromJson(string json)
		{
			AudioPickResult audioPickResult = new AudioPickResult();
			Dictionary<string, object> dictionary = Json.Deserialize(json) as Dictionary<string, object>;
			audioPickResult.OriginalPath = dictionary.GetStr("originalPath");
			audioPickResult.DisplayName = dictionary.GetStr("displayName");
			audioPickResult.MimeType = dictionary.GetStr("mimeType");
			audioPickResult.CreatedAt = CommonUtils.DateTimeFromMillisSinceEpoch((long)dictionary["createdAt"]);
			audioPickResult.Size = (int)(long)dictionary["size"];
			return audioPickResult;
		}

		public override string ToString()
		{
			return $"[AudioPickResult: OriginalPath={OriginalPath}, DisplayName={DisplayName}, Size={Size}, MimeType={MimeType}, CreatedAt={CreatedAt}]";
		}
	}
}
