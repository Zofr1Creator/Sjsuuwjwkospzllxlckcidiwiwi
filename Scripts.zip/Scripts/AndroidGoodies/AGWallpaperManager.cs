using System;
using System.IO;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	public static class AGWallpaperManager
	{
		private const string ACTION_LIVE_WALLPAPER_CHOOSER = "android.service.wallpaper.LIVE_WALLPAPER_CHOOSER";

		private static AndroidJavaObject WallpaperManager => "android.app.WallpaperManager".AJCCallStaticOnceAJO("getInstance", AGUtils.Activity);

		public static void Clear()
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				WallpaperManager.Call("clear");
			}
		}

		public static bool IsWallpaperSupported()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return false;
			}
			if (AGDeviceInfo.SDK_INT >= 23)
			{
				return WallpaperManager.CallBool("isWallpaperSupported");
			}
			return true;
		}

		public static bool IsSetWallpaperAllowed()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return false;
			}
			if (AGDeviceInfo.SDK_INT >= 24)
			{
				return WallpaperManager.CallBool("isSetWallpaperAllowed");
			}
			return true;
		}

		public static void SetWallpaper([NotNull] Texture2D wallpaperTexture)
		{
			if (wallpaperTexture == null)
			{
				throw new ArgumentNullException("wallpaperTexture");
			}
			if (!AGUtils.IsNotAndroidCheck())
			{
				string wallpaperFromFilePath = AndroidPersistanceUtilsInternal.SaveWallpaperImageToExternalStorage(wallpaperTexture);
				SetWallpaperFromFilePath(wallpaperFromFilePath);
			}
		}

		public static void SetWallpaper([NotNull] string imagePath)
		{
			if (imagePath == null)
			{
				throw new ArgumentNullException("imagePath");
			}
			if (!AGUtils.IsNotAndroidCheck())
			{
				CheckIfFileExists(imagePath);
				SetWallpaperFromFilePath(imagePath);
			}
		}

		private static void SetWallpaperFromFilePath(string wallpaperPath)
		{
			AndroidJavaObject androidJavaObject = AGUtils.DecodeBitmap(wallpaperPath);
			WallpaperManager.Call("setBitmap", androidJavaObject);
		}

		public static void ShowCropAndSetWallpaperChooser([NotNull] Texture2D wallpaperTexture)
		{
			if (wallpaperTexture == null)
			{
				throw new ArgumentNullException("wallpaperTexture");
			}
			if (!AGUtils.IsNotAndroidCheck() && AGDeviceInfo.SDK_INT >= 19)
			{
				AndroidJavaObject uri = AndroidPersistanceUtilsInternal.SaveWallpaperImageToExternalStorageUri(wallpaperTexture);
				StartCropAndSetWallpaperActivity(uri);
			}
		}

		public static void ShowCropAndSetWallpaperChooser([NotNull] string imagePath)
		{
			if (imagePath == null)
			{
				throw new ArgumentNullException("imagePath");
			}
			if (!AGUtils.IsNotAndroidCheck() && AGDeviceInfo.SDK_INT >= 19)
			{
				CheckIfFileExists(imagePath);
				AndroidJavaObject uriFromFilePath = AndroidPersistanceUtilsInternal.GetUriFromFilePath(imagePath);
				StartCropAndSetWallpaperActivity(uriFromFilePath);
			}
		}

		private static void StartCropAndSetWallpaperActivity(AndroidJavaObject uri)
		{
			AndroidJavaObject intent = WallpaperManager.CallAJO("getCropAndSetWallpaperIntent", uri);
			AGUtils.StartActivity(intent);
		}

		public static void ShowLiveWallpaperChooser()
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				AndroidIntent androidIntent = new AndroidIntent("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER");
				AGUtils.StartActivity(androidIntent.AJO);
			}
		}

		private static void CheckIfFileExists(string imagePath)
		{
			if (!File.Exists(imagePath))
			{
				Debug.LogError("File doesn't exist: " + imagePath);
			}
		}
	}
}
