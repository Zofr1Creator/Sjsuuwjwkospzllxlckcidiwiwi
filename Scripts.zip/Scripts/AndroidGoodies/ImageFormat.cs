using JetBrains.Annotations;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public enum ImageFormat
	{
		[PublicAPI]
		PNG,
		[PublicAPI]
		JPEG
	}
}
