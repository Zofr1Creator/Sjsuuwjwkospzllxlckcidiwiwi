using System.Collections.Generic;
using System.Linq;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using MiniJSON;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public sealed class ContactPickResult
	{
		[PublicAPI]
		public string DisplayName { get; private set; }

		[PublicAPI]
		public string PhotoUri { get; private set; }

		[PublicAPI]
		public List<string> Phones { get; private set; }

		[PublicAPI]
		public List<string> Emails { get; private set; }

		private ContactPickResult()
		{
			Phones = new List<string>();
			Emails = new List<string>();
		}

		public static ContactPickResult FromJson(string json)
		{
			ContactPickResult contactPickResult = new ContactPickResult();
			Dictionary<string, object> dictionary = Json.Deserialize(json) as Dictionary<string, object>;
			contactPickResult.DisplayName = dictionary.GetStr("displayName");
			contactPickResult.PhotoUri = dictionary.GetStr("photoUri");
			contactPickResult.Phones = ((List<object>)dictionary["phones"]).OfType<string>().ToList();
			contactPickResult.Emails = ((List<object>)dictionary["emails"]).OfType<string>().ToList();
			return contactPickResult;
		}

		public override string ToString()
		{
			return $"[ContactPickResult: DisplayName={DisplayName}]";
		}
	}
}
