using System;
using System.Collections.Generic;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using MiniJSON;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public class ImagePickResult
	{
		[PublicAPI]
		public string OriginalPath { get; private set; }

		[PublicAPI]
		public string DisplayName { get; private set; }

		[PublicAPI]
		public string ThumbnailPath { get; private set; }

		[PublicAPI]
		public string SmallThumbnailPath { get; private set; }

		[PublicAPI]
		public int Width { get; private set; }

		[PublicAPI]
		public int Height { get; private set; }

		[PublicAPI]
		public int Size { get; private set; }

		[PublicAPI]
		public DateTime CreatedAt { get; private set; }

		[PublicAPI]
		public Texture2D LoadTexture2D()
		{
			return AGUtils.Texture2DFromFile(OriginalPath);
		}

		[PublicAPI]
		public Texture2D LoadThumbnailTexture2D()
		{
			return CommonUtils.TextureFromFile(ThumbnailPath);
		}

		[PublicAPI]
		public Texture2D LoadSmallThumbnailTexture2D()
		{
			return CommonUtils.TextureFromFile(SmallThumbnailPath);
		}

		public static ImagePickResult FromJson(string json)
		{
			ImagePickResult imagePickResult = new ImagePickResult();
			Dictionary<string, object> dictionary = Json.Deserialize(json) as Dictionary<string, object>;
			imagePickResult.OriginalPath = dictionary.GetStr("originalPath");
			imagePickResult.ThumbnailPath = dictionary.GetStr("thumbnailPath");
			imagePickResult.SmallThumbnailPath = dictionary.GetStr("thumbnailSmallPath");
			imagePickResult.DisplayName = dictionary.GetStr("displayName");
			imagePickResult.Width = (int)(long)dictionary["width"];
			imagePickResult.Height = (int)(long)dictionary["height"];
			imagePickResult.Size = (int)(long)dictionary["size"];
			imagePickResult.CreatedAt = CommonUtils.DateTimeFromMillisSinceEpoch((long)dictionary["createdAt"]);
			return imagePickResult;
		}

		public override string ToString()
		{
			return $"[ImagePickResult: OriginalPath={OriginalPath}, DisplayName={DisplayName}, ThumbnailPath={ThumbnailPath}, SmallThumbnailPath={SmallThumbnailPath}, Width={Width}, Height={Height}, Size={Size}]";
		}
	}
}
