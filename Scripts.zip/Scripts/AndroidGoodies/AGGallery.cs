using System;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public static class AGGallery
	{
		private static Action<ImagePickResult> _onSuccessAction;

		private static Action<string> _onCancelAction;

		[PublicAPI]
		public static void PickImageFromGallery([NotNull] Action<ImagePickResult> onSuccess, Action<string> onError, ImageResultSize maxSize = ImageResultSize.Original, bool shouldGenerateThumbnails = true)
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				Check.Argument.IsNotNull(onSuccess, "onSuccess");
				_onSuccessAction = onSuccess;
				_onCancelAction = onError;
				AGActivityUtils.PickPhotoFromGallery(maxSize, shouldGenerateThumbnails);
			}
		}

		[PublicAPI]
		public static void SaveImageToGallery([NotNull] Texture2D texture2D, [NotNull] string title, string folder = null, ImageFormat imageFormat = ImageFormat.PNG)
		{
			if (!AGUtils.IsNotAndroidCheck())
			{
				AGFileUtils.SaveImageToGallery(texture2D, title, folder, imageFormat);
			}
		}

		[PublicAPI]
		public static void RefreshFile([NotNull] string filePath)
		{
			Check.Argument.IsStrNotNullOrEmpty(filePath, "path");
			if (!AGUtils.IsNotAndroidCheck())
			{
				AndroidPersistanceUtilsInternal.RefreshGallery(filePath);
			}
		}

		internal static void OnSuccessTrigger(string imageCallbackJson)
		{
			if (_onSuccessAction != null)
			{
				ImagePickResult obj = ImagePickResult.FromJson(imageCallbackJson);
				_onSuccessAction(obj);
			}
		}

		internal static void OnErrorTrigger(string errorMessage)
		{
			if (_onCancelAction != null)
			{
				_onCancelAction(errorMessage);
				_onCancelAction = null;
			}
		}
	}
}
