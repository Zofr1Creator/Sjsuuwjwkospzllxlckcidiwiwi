using JetBrains.Annotations;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public enum ImageResultSize
	{
		[PublicAPI]
		Original = 0,
		[PublicAPI]
		Max256 = 0x100,
		[PublicAPI]
		Max512 = 0x200,
		[PublicAPI]
		Max1024 = 0x400,
		[PublicAPI]
		Max2048 = 0x800
	}
}
