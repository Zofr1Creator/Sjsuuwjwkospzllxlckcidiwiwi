using System;
using System.Collections.Generic;
using DeadMosquito.AndroidGoodies.Internal;
using JetBrains.Annotations;
using UnityEngine;

namespace DeadMosquito.AndroidGoodies
{
	[PublicAPI]
	public static class AGDeviceInfo
	{
		[PublicAPI]
		public static class VersionCodes
		{
			[PublicAPI]
			public const int BASE = 1;

			[PublicAPI]
			public const int BASE_1_1 = 2;

			[PublicAPI]
			public const int CUPCAKE = 3;

			[PublicAPI]
			public const int CUR_DEVELOPMENT = 10000;

			[PublicAPI]
			public const int DONUT = 4;

			[PublicAPI]
			public const int ECLAIR = 5;

			[PublicAPI]
			public const int ECLAIR_0_1 = 6;

			[PublicAPI]
			public const int ECLAIR_MR1 = 7;

			[PublicAPI]
			public const int FROYO = 8;

			[PublicAPI]
			public const int GINGERBREAD = 9;

			[PublicAPI]
			public const int GINGERBREAD_MR1 = 10;

			[PublicAPI]
			public const int HONEYCOMB = 11;

			[PublicAPI]
			public const int HONEYCOMB_MR1 = 12;

			[PublicAPI]
			public const int HONEYCOMB_MR2 = 13;

			[PublicAPI]
			public const int ICE_CREAM_SANDWICH = 14;

			[PublicAPI]
			public const int ICE_CREAM_SANDWICH_MR1 = 15;

			[PublicAPI]
			public const int JELLY_BEAN = 16;

			[PublicAPI]
			public const int JELLY_BEAN_MR1 = 17;

			[PublicAPI]
			public const int JELLY_BEAN_MR2 = 18;

			[PublicAPI]
			public const int KITKAT = 19;

			[PublicAPI]
			public const int KITKAT_WATCH = 20;

			[PublicAPI]
			public const int LOLLIPOP = 21;

			[PublicAPI]
			public const int LOLLIPOP_MR1 = 22;

			[PublicAPI]
			public const int M = 23;

			[PublicAPI]
			public const int N = 24;

			[PublicAPI]
			public const int N_MR1 = 25;

			[PublicAPI]
			public const int O = 26;
		}

		[PublicAPI]
		public static class SystemFeatures
		{
			[PublicAPI]
			public const string FEATURE_AUDIO_LOW_LATENCY = "android.hardware.audio.low_latency";

			[PublicAPI]
			public const string FEATURE_AUDIO_OUTPUT = "android.hardware.audio.output";

			[PublicAPI]
			public const string FEATURE_AUDIO_PRO = "android.hardware.audio.pro";

			[PublicAPI]
			public const string FEATURE_BLUETOOTH = "android.hardware.bluetooth";

			[PublicAPI]
			public const string FEATURE_BLUETOOTH_LE = "android.hardware.bluetooth_le";

			[PublicAPI]
			public const string FEATURE_CAMERA = "android.hardware.camera";

			[PublicAPI]
			public const string FEATURE_CAMERA_AUTOFOCUS = "android.hardware.camera.autofocus";

			[PublicAPI]
			public const string FEATURE_CAMERA_ANY = "android.hardware.camera.any";

			[PublicAPI]
			public const string FEATURE_CAMERA_EXTERNAL = "android.hardware.camera.external";

			[PublicAPI]
			public const string FEATURE_CAMERA_FLASH = "android.hardware.camera.flash";

			[PublicAPI]
			public const string FEATURE_CAMERA_FRONT = "android.hardware.camera.front";

			[PublicAPI]
			public const string FEATURE_CAMERA_LEVEL_FULL = "android.hardware.camera.level.full";

			[PublicAPI]
			public const string FEATURE_CAMERA_CAPABILITY_MANUAL_SENSOR = "android.hardware.camera.capability.manual_sensor";

			[PublicAPI]
			public const string FEATURE_CAMERA_CAPABILITY_MANUAL_POST_PROCESSING = "android.hardware.camera.capability.manual_post_processing";

			[PublicAPI]
			public const string FEATURE_CAMERA_CAPABILITY_RAW = "android.hardware.camera.capability.raw";

			[PublicAPI]
			public const string FEATURE_CONSUMER_IR = "android.hardware.consumerir";

			[PublicAPI]
			public const string FEATURE_LOCATION = "android.hardware.location";

			[PublicAPI]
			public const string FEATURE_LOCATION_GPS = "android.hardware.location.gps";

			[PublicAPI]
			public const string FEATURE_LOCATION_NETWORK = "android.hardware.location.network";

			[PublicAPI]
			public const string FEATURE_MICROPHONE = "android.hardware.microphone";

			[PublicAPI]
			public const string FEATURE_NFC = "android.hardware.nfc";

			[PublicAPI]
			public const string FEATURE_NFC_HCE = "android.hardware.nfc.hce";

			[PublicAPI]
			public const string FEATURE_NFC_HOST_CARD_EMULATION = "android.hardware.nfc.hce";

			[PublicAPI]
			public const string FEATURE_OPENGLES_EXTENSION_PACK = "android.hardware.opengles.aep";

			[PublicAPI]
			public const string FEATURE_SENSOR_ACCELEROMETER = "android.hardware.sensor.accelerometer";

			[PublicAPI]
			public const string FEATURE_SENSOR_BAROMETER = "android.hardware.sensor.barometer";

			[PublicAPI]
			public const string FEATURE_SENSOR_COMPASS = "android.hardware.sensor.compass";

			[PublicAPI]
			public const string FEATURE_SENSOR_GYROSCOPE = "android.hardware.sensor.gyroscope";

			[PublicAPI]
			public const string FEATURE_SENSOR_LIGHT = "android.hardware.sensor.light";

			[PublicAPI]
			public const string FEATURE_SENSOR_PROXIMITY = "android.hardware.sensor.proximity";

			[PublicAPI]
			public const string FEATURE_SENSOR_STEP_COUNTER = "android.hardware.sensor.stepcounter";

			[PublicAPI]
			public const string FEATURE_SENSOR_STEP_DETECTOR = "android.hardware.sensor.stepdetector";

			[PublicAPI]
			public const string FEATURE_SENSOR_HEART_RATE = "android.hardware.sensor.heartrate";

			[PublicAPI]
			public const string FEATURE_SENSOR_HEART_RATE_ECG = "android.hardware.sensor.heartrate.ecg";

			[PublicAPI]
			public const string FEATURE_SENSOR_RELATIVE_HUMIDITY = "android.hardware.sensor.relative_humidity";

			[PublicAPI]
			public const string FEATURE_SENSOR_AMBIENT_TEMPERATURE = "android.hardware.sensor.ambient_temperature";

			[PublicAPI]
			public const string FEATURE_HIFI_SENSORS = "android.hardware.sensor.hifi_sensors";

			[PublicAPI]
			public const string FEATURE_TELEPHONY = "android.hardware.telephony";

			[PublicAPI]
			public const string FEATURE_TELEPHONY_CDMA = "android.hardware.telephony.cdma";

			[PublicAPI]
			public const string FEATURE_TELEPHONY_GSM = "android.hardware.telephony.gsm";

			[PublicAPI]
			public const string FEATURE_USB_HOST = "android.hardware.usb.host";

			[PublicAPI]
			public const string FEATURE_USB_ACCESSORY = "android.hardware.usb.accessory";

			[PublicAPI]
			public const string FEATURE_SIP = "android.software.sip";

			[PublicAPI]
			public const string FEATURE_SIP_VOIP = "android.software.sip.voip";

			[PublicAPI]
			public const string FEATURE_CONNECTION_SERVICE = "android.software.connectionservice";

			[PublicAPI]
			public const string FEATURE_TOUCHSCREEN = "android.hardware.touchscreen";

			[PublicAPI]
			public const string FEATURE_TOUCHSCREEN_MULTITOUCH = "android.hardware.touchscreen.multitouch";

			[PublicAPI]
			public const string FEATURE_TOUCHSCREEN_MULTITOUCH_DISTINCT = "android.hardware.touchscreen.multitouch.distinct";

			[PublicAPI]
			public const string FEATURE_TOUCHSCREEN_MULTITOUCH_JAZZHAND = "android.hardware.touchscreen.multitouch.jazzhand";

			[PublicAPI]
			public const string FEATURE_FAKETOUCH = "android.hardware.faketouch";

			[PublicAPI]
			public const string FEATURE_FAKETOUCH_MULTITOUCH_DISTINCT = "android.hardware.faketouch.multitouch.distinct";

			[PublicAPI]
			public const string FEATURE_FAKETOUCH_MULTITOUCH_JAZZHAND = "android.hardware.faketouch.multitouch.jazzhand";

			[PublicAPI]
			public const string FEATURE_FINGERPRINT = "android.hardware.fingerprint";

			[PublicAPI]
			public const string FEATURE_SCREEN_PORTRAIT = "android.hardware.screen.portrait";

			[PublicAPI]
			public const string FEATURE_SCREEN_LANDSCAPE = "android.hardware.screen.landscape";

			[PublicAPI]
			public const string FEATURE_LIVE_WALLPAPER = "android.software.live_wallpaper";

			[PublicAPI]
			public const string FEATURE_APP_WIDGETS = "android.software.app_widgets";

			[PublicAPI]
			public const string FEATURE_VOICE_RECOGNIZERS = "android.software.voice_recognizers";

			[PublicAPI]
			public const string FEATURE_HOME_SCREEN = "android.software.home_screen";

			[PublicAPI]
			public const string FEATURE_INPUT_METHODS = "android.software.input_methods";

			[PublicAPI]
			public const string FEATURE_DEVICE_ADMIN = "android.software.device_admin";

			[PublicAPI]
			public const string FEATURE_LEANBACK = "android.software.leanback";

			[PublicAPI]
			public const string FEATURE_LEANBACK_ONLY = "android.software.leanback_only";

			[PublicAPI]
			public const string FEATURE_LIVE_TV = "android.software.live_tv";

			[PublicAPI]
			public const string FEATURE_WIFI = "android.hardware.wifi";

			[PublicAPI]
			public const string FEATURE_WIFI_DIRECT = "android.hardware.wifi.direct";

			[PublicAPI]
			public const string FEATURE_AUTOMOTIVE = "android.hardware.type.automotive";

			[PublicAPI]
			public const string FEATURE_WATCH = "android.hardware.type.watch";

			[PublicAPI]
			public const string FEATURE_PRINTING = "android.software.print";

			[PublicAPI]
			public const string FEATURE_BACKUP = "android.software.backup";

			[PublicAPI]
			public const string FEATURE_MANAGED_USERS = "android.software.managed_users";

			[PublicAPI]
			public const string FEATURE_MANAGED_PROFILES = "android.software.managed_users";

			[PublicAPI]
			public const string FEATURE_VERIFIED_BOOT = "android.software.verified_boot";

			[PublicAPI]
			public const string FEATURE_SECURELY_REMOVES_USERS = "android.software.securely_removes_users";

			[PublicAPI]
			public const string FEATURE_WEBVIEW = "android.software.webview";

			[PublicAPI]
			public const string FEATURE_ETHERNET = "android.hardware.ethernet";

			[PublicAPI]
			public const string FEATURE_HDMI_CEC = "android.hardware.hdmi.cec";

			[PublicAPI]
			public const string FEATURE_GAMEPAD = "android.hardware.gamepad";

			[PublicAPI]
			public const string FEATURE_MIDI = "android.software.midi";

			[PublicAPI]
			public static bool HasFlashlight => AGUtils.HasSystemFeature("android.hardware.camera.flash");

			[PublicAPI]
			public static bool HasSystemFeature(string feature)
			{
				if (AGUtils.IsNotAndroidCheck())
				{
					return false;
				}
				return AGUtils.HasSystemFeature(feature);
			}
		}

		[PublicAPI]
		public static string DEVICE => GetBuildClassStaticStr("DEVICE");

		[PublicAPI]
		public static string MODEL => GetBuildClassStaticStr("MODEL");

		[PublicAPI]
		public static string PRODUCT => GetBuildClassStaticStr("PRODUCT");

		[PublicAPI]
		public static string MANUFACTURER => GetBuildClassStaticStr("MANUFACTURER");

		[PublicAPI]
		public static string BASE_OS => GetDeviceStrProperty<string>("android.os.Build$VERSION", "BASE_OS");

		[PublicAPI]
		public static string CODENAME => GetDeviceStrProperty<string>("android.os.Build$VERSION", "CODENAME");

		[PublicAPI]
		public static string INCREMENTAL => GetDeviceStrProperty<string>("android.os.Build$VERSION", "INCREMENTAL");

		[PublicAPI]
		public static int PREVIEW_SDK_INT => GetDeviceStrProperty<int>("android.os.Build$VERSION", "PREVIEW_SDK_INT");

		[PublicAPI]
		public static string RELEASE => GetDeviceStrProperty<string>("android.os.Build$VERSION", "RELEASE");

		[PublicAPI]
		public static int SDK_INT => GetDeviceStrProperty<int>("android.os.Build$VERSION", "SDK_INT");

		[PublicAPI]
		public static string SECURITY_PATCH => GetDeviceStrProperty<string>("android.os.Build$VERSION", "SECURITY_PATCH");

		[PublicAPI]
		public static string GetAndroidId()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return string.Empty;
			}
			try
			{
				using (AndroidJavaObject androidJavaObject = AGUtils.ContentResolver)
				{
					using (AndroidJavaClass ajc = new AndroidJavaClass("android.provider.Settings$Secure"))
					{
						string staticStr = ajc.GetStaticStr("ANDROID_ID");
						return ajc.CallStaticStr("getString", androidJavaObject, staticStr);
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("Failed to get Android Id, reasong: " + ex.Message);
				return string.Empty;
			}
		}

		private static string GetBuildClassStaticStr(string fieldName)
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return string.Empty;
			}
			try
			{
				using (AndroidJavaClass ajc = new AndroidJavaClass("android.os.Build"))
				{
					return ajc.GetStaticStr(fieldName);
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("Failed to get property " + fieldName + ". Check device API level. " + ex.Message);
				return string.Empty;
			}
		}

		private static T GetDeviceStrProperty<T>(string className, string propertyName)
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return default(T);
			}
			try
			{
				using (AndroidJavaClass androidJavaClass = new AndroidJavaClass(className))
				{
					return androidJavaClass.GetStatic<T>(propertyName);
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning($"Failed to get property: {propertyName} of class {className}, reason: {ex.Message}");
				return default(T);
			}
		}

		[PublicAPI]
		public static string GetApplicationPackage()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return string.Empty;
			}
			return AGUtils.Activity.CallAJO("getApplicationContext").CallStr("getPackageName");
		}

		[PublicAPI]
		public static bool IsPackageInstalled(string package)
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return false;
			}
			using (AndroidJavaObject androidJavaObject = AGUtils.PackageManager)
			{
				try
				{
					androidJavaObject.Call<AndroidJavaObject>("getPackageInfo", new object[2] { package, 1 });
					return true;
				}
				catch (AndroidJavaException message)
				{
					Debug.LogWarning(message);
					return false;
				}
			}
		}

		[PublicAPI]
		public static List<PackageInfo> GetInstalledPackages()
		{
			if (AGUtils.IsNotAndroidCheck())
			{
				return new List<PackageInfo>();
			}
			using (AndroidJavaObject ajo = AGUtils.PackageManager)
			{
				List<PackageInfo> list = new List<PackageInfo>();
				List<AndroidJavaObject> list2 = ajo.CallAJO("getInstalledPackages", 0).FromJavaList<AndroidJavaObject>();
				foreach (AndroidJavaObject item in list2)
				{
					list.Add(PackageInfo.FromJavaObj(item));
				}
				return list;
			}
		}
	}
}
