using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB.Game;
using RpcException = Axlebolt.RpcSupport.Protobuf.Exception;

namespace StandRiseServer.RpcServer.Api
{
    public class ChatRemoteService : RpcClass
    {
        public ChatRemoteService(UserService user) : base(user)
        {
        }

        private string GetPlayerId()
        {
            StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId);
            return playerId;
        }

        public override void Invoke(RpcRequest request)
        {
            string playerId = GetPlayerId();

            switch (request.MethodName)
            {
                case "sendFriendMsg":
                    SendFriendMsg(request.Params.ToArray(), request.Id, playerId);
                    break;
                case "getUnreadChatUsersCount":
                    GetUnreadChatUsersCount(request.Id, playerId);
                    break;
                case "getChatUsers":
                    GetChatUsers(request.Id, playerId);
                    break;
                case "readFriendMsgs":
                    ReadFriendMsgs(request.Params.ToArray(), request.Id, playerId);
                    break;
                case "getFriendMsgsByOffset":
                case "getFriendMsgs":
                case "getFriendMsgsByPage":
                    GetFriendMsgsByOffset(request.Params.ToArray(), request.Id, playerId);
                    break;
                case "deleteFriendMsgs":
                    DeleteFriendMsgs(request.Params.ToArray(), request.Id, playerId);
                    break;
                default:
                    MethodNotFound(request.Id);
                    break;
            }
        }

        public override Task InvokeAsync(RpcRequest request)
        {
            Invoke(request);
            return Task.CompletedTask;
        }

        private void SendFriendMsg(BinaryValue[] binaryValues, string guid, string playerId)
        {
            try
            {
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(binaryValues[0]);
                string message = (string)new FromByteMethod(typeof(string)).FromBytes(binaryValues[1]);

                Console.WriteLine($"[Chat] SendFriendMsg: from={playerId} to={friendId} msg='{message}'");
                BoltGameDatabaseProvider.Instance.SaveChatMessage(playerId, friendId, message);
                Console.WriteLine($"[Chat] SendFriendMsg: saved to DB");

                // Отправляем событие получателю если он онлайн
                long timestamp = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
                if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                {
                    var userMsg = new UserMessage
                    {
                        SenderId = playerId,
                        Message = message,
                        Timestamp = timestamp,
                        IsRead = false
                    };
                    var sender = eventSenders.FirstOrDefault(a => a is MessagesRemoteEventSender);
                    sender?.SendEvent("onMsgFromFriend", new object[] { userMsg });
                    Console.WriteLine($"[Chat] SendFriendMsg: event sent to {friendId}");
                }

                ReturnEmpty(guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Chat] SendFriendMsg error: {ex}");
                ReturnEmpty(guid);
            }
        }

        private void GetUnreadChatUsersCount(string guid, string playerId)
        {
            try
            {
                int unreadCount = BoltGameDatabaseProvider.Instance.GetUnreadChatUsersCount(playerId);
                Console.WriteLine($"[Chat] GetUnreadChatUsersCount: playerId={playerId} count={unreadCount}");
                ReturnValue(new ToByteMethod(typeof(int)).ToBytes(unreadCount), guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Chat] GetUnreadChatUsersCount error: {ex}");
                ReturnValue(new ToByteMethod(typeof(int)).ToBytes(0), guid);
            }
        }

        private void GetChatUsers(string guid, string playerId)
        {
            try
            {
                var chatUsers = BoltGameDatabaseProvider.Instance.GetChatUsers(playerId);
                Console.WriteLine($"[Chat] GetChatUsers: playerId={playerId} found {chatUsers.Count} chats");
                var result = new List<ChatUser>();

                foreach (var (friendId, lastMessage, timestamp, unreadCount) in chatUsers)
                {
                    try
                    {
                        PlayerDocument friendDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(friendId));
                        if (friendDoc == null)
                        {
                            Console.WriteLine($"[Chat] GetChatUsers: friendDoc null for {friendId}");
                            continue;
                        }

                        var playerFriend = new PlayerFriend();
                        playerFriend.Player = friendDoc.GetPlayer();
                        playerFriend.RelationshipStatus = RelationshipStatus.Friend;

                        var chatUser = new ChatUser
                        {
                            Message = lastMessage ?? string.Empty,
                            Timestamp = timestamp,
                            Player = playerFriend
                        };
                        result.Add(chatUser);
                        Console.WriteLine($"[Chat] GetChatUsers: added chat with {friendDoc.name}");
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[Chat] GetChatUsers: failed to load friend {friendId}: {ex.Message}");
                    }
                }

                Console.WriteLine($"[Chat] GetChatUsers: returning {result.Count} chats");
                ReturnValue(new ToByteMethod(typeof(ChatUser[])).ToBytes(result.ToArray()), guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Chat] GetChatUsers error: {ex}");
                ReturnValue(new ToByteMethod(typeof(ChatUser[])).ToBytes(new ChatUser[0]), guid);
            }
        }

        private void GetFriendMsgsByOffset(BinaryValue[] binaryValues, string guid, string playerId)
        {
            try
            {
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(binaryValues[0]);
                int offset = 0;
                int length = 50;
                if (binaryValues.Length > 1)
                {
                    try
                    {
                        var offsetObj = new FromByteMethod(typeof(Offset)).FromBytes(binaryValues[1]);
                        if (offsetObj is Offset off)
                        {
                            offset = off.Offset_;
                            length = off.Length > 0 ? off.Length : 50;
                        }
                    }
                    catch { }
                }

                var messages = BoltGameDatabaseProvider.Instance.GetChatMessages(playerId, friendId, offset, length);

                var result = messages.Select(m => new UserMessage
                {
                    SenderId = m.senderId,
                    Message = m.message ?? string.Empty,
                    Timestamp = m.timestamp,
                    IsRead = m.isRead
                }).ToArray();

                ReturnValue(new ToByteMethod(typeof(UserMessage[])).ToBytes(result), guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"GetFriendMsgsByOffset error: {ex}");
                ReturnValue(new ToByteMethod(typeof(UserMessage[])).ToBytes(new UserMessage[0]), guid);
            }
        }

        private void ReadFriendMsgs(BinaryValue[] binaryValues, string guid, string playerId)
        {
            try
            {
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(binaryValues[0]);
                BoltGameDatabaseProvider.Instance.MarkMessagesAsRead(playerId, friendId);
                ReturnEmpty(guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"ReadFriendMsgs error: {ex}");
                ReturnEmpty(guid);
            }
        }

        private void DeleteFriendMsgs(BinaryValue[] binaryValues, string guid, string playerId)
        {
            try
            {
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(binaryValues[0]);
                BoltGameDatabaseProvider.Instance.DeleteChatMessages(playerId, friendId);
                ReturnEmpty(guid);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"DeleteFriendMsgs error: {ex}");
                ReturnEmpty(guid);
            }
        }

        private void ReturnEmpty(string guid)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }

        private void ReturnValue(BinaryValue value, string guid)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = value
                }
            });
        }

        private void MethodNotFound(string guid)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new RpcException
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 404
                    }
                }
            });
        }
    }
}
