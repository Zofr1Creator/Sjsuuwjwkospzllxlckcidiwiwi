using Axlebolt.RpcSupport.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.RpcServer;
using Google.Protobuf;
using MongoDB.Bson;
using Axlebolt.Bolt.Protobuf;
using Google.Protobuf.Collections;
using StandRiseServer.MongoDB.Game;
using MongoDB.Driver;
using FriendHelper = StandRiseServer.MongoDB.Main.FriendHelper;

namespace StandRiseServer.RpcServer.Api
{
    public class MarketplaceRemoteService : RpcClass
    {
        public MarketplaceRemoteService(UserService user) : base(user)
        {
        }

        protected async void getTrades(BinaryValue[] values, string guid)
        {
            try
            {
                Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] getTrades START - guid={guid}");
                Console.Out.Flush();
                
                GetTradesArgs args = (GetTradesArgs)new FromByteMethod(typeof(GetTradesArgs)).FromBytes(values[0]);

                RepeatedField<int> items = args.ItemDefinitionIds;
                Trade[] trades = new Trade[items.Count];

                var BoltGame = BoltGameDatabaseProvider.Instance;
                
                Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] getTrades called for {items.Count} items: [{string.Join(", ", items)}]");
                Console.Out.Flush();
                
                var itemStats = BoltGame.GetMarketplaceStatsForItems(items);
                
                Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] GetMarketplaceStatsForItems returned {itemStats.Count} items with stats");
                Console.Out.Flush();

                for (int i = 0; i < trades.Length; i++)
                {
                    trades[i] = new Trade();
                    trades[i].Id = items[i];
                    
                    if (itemStats.TryGetValue(items[i], out var stats))
                    {
                        trades[i].SalesCount = stats.Count;
                        trades[i].SalesPrice = stats.MinPrice;
                        trades[i].PurchasesCount = 0;
                        trades[i].PurchasesPrice = 0.0f;
                        Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] Item {items[i]}: SalesCount={stats.Count}, MinPrice={stats.MinPrice}");
                    }
                    else
                    {
                        trades[i].SalesCount = 0;
                        trades[i].PurchasesCount = 0;
                        trades[i].SalesPrice = 0.0f;
                        trades[i].PurchasesPrice = 0.0f;
                        Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] Item {items[i]}: No stats found");
                    }
                }
                
                Console.Out.Flush();

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(Trade[])).ToBytes(trades)
                    }
                });
                
                Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] getTrades COMPLETE - guid={guid}");
                Console.Out.Flush();
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[{DateTime.UtcNow:HH:mm:ss.fff}] [MarketplaceRemoteService] Error in getTrades: {ex}");
                Console.Out.Flush();
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500
                        }
                    }
                });
            }
        }

        protected async void getTrade(BinaryValue[] values, string guid)
        {
            try
            {
                GetTradeArgs args = (GetTradeArgs)new FromByteMethod(typeof(GetTradeArgs)).FromBytes(values[0]);

                Trade trade = new Trade();
                trade.Id = args.Id;

                var BoltGame = BoltGameDatabaseProvider.Instance;
                var activeSaleRequests = BoltGame.GetActiveMarketplaceRequestsByItem(args.Id, 0, 100);
                var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = args.Id });

                trade.SalesCount = activeSaleRequests.Count;
                trade.SalesPrice = activeSaleRequests.Count > 0 ? activeSaleRequests.Min(r => r.price) : 0.0f;
                trade.PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity);
                trade.PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0.0f;

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(Trade)).ToBytes(trade)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getTrade: {ex}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500
                        }
                    }
                });
            }
        }

        public async void getMarketplaceSettings(BinaryValue[] values, string guid)
        {
            try
            {
                // Загружаем настройки из БД вместо хардкода
                MarketplaceSettings settings = await BoltGameDatabaseProvider.Instance.GetMarketplaceSettingsAsync();

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(MarketplaceSettings)).ToBytes(settings)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getMarketplaceSettings: {ex}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500
                        }
                    }
                });
            }
        }

        public void getPlayerProcessingRequests(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
            {
                var processingRequests = BoltGameDatabaseProvider.Instance.GetPlayerMarketplaceRequests(playerId, MarketplaceRequestStatus.Processing);
                
                ProcessingRequest[] requests = new ProcessingRequest[processingRequests.Count];
                for (int i = 0; i < processingRequests.Count; i++)
                {
                    var req = processingRequests[i];
                    requests[i] = new ProcessingRequest();
                    requests[i].Id = req._id.ToString();
                    requests[i].ItemDefinitionId = req.itemDefinitionId;
                    requests[i].Quantity = req.quantity;
                    requests[i].State = ProcessingState.Creating;
                    requests[i].Price = req.price;
                    requests[i].Type = (Axlebolt.Bolt.Protobuf.MarketRequestType)req.type;
                    requests[i].SaleRequestId = req._id.ToString();
                    requests[i].CreateDate = req.createDate.Ticks;
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(ProcessingRequest[])).ToBytes(requests)
                    }
                });
            }
            else
            {
                ProcessingRequest[] requests = new ProcessingRequest[0];
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(ProcessingRequest[])).ToBytes(requests)
                    }
                });
            }
            return;
        }


        public async void getPlayerOpenRequests(BinaryValue[] values, string guid)
        {
            try
            {
                if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    var activeRequests = BoltGameDatabaseProvider.Instance.GetPlayerMarketplaceRequests(playerId, MarketplaceRequestStatus.Active);
                    
                    OpenRequest[] requests = new OpenRequest[activeRequests.Count];

                    // PRE-FETCH player once to avoid N queries for N listings
                    PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
                    Axlebolt.Bolt.Protobuf.Player myPlayer = FriendHelper.GetPlayer(playerId);

                    Axlebolt.Bolt.Protobuf.Player player = new Axlebolt.Bolt.Protobuf.Player();
                    if (myPlayer != null && playerDocument != null)
                    {
                        player.Id = myPlayer.Id;
                        player.Uid = myPlayer.Uid;
                        player.Name = myPlayer.Name;
                        player.AvatarId = myPlayer.AvatarId;
                        player.TimeInGame = playerDocument.timeInGame;
                        player.RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch;
                        Axlebolt.Bolt.Protobuf.PlayerStatus playerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus();
                        playerStatus.PlayerId = myPlayer.Id;
                        player.PlayerStatus = playerStatus;
                    }

                    for (int i = 0; i < activeRequests.Count; i++)
                    {
                        var req = activeRequests[i];
                        
                        requests[i] = new OpenRequest();
                        requests[i].Id = req._id.ToString();
                        requests[i].Creator = player;
                        requests[i].ItemDefinitionId = req.itemDefinitionId;
                        requests[i].Price = req.price;
                        requests[i].CreateDate = req.createDate.Ticks;
                        requests[i].Type = (Axlebolt.Bolt.Protobuf.MarketRequestType)req.type;
                        requests[i].Quantity = req.quantity;

                        // ИСПРАВЛЕНИЕ: Копируем свойства (наклейки, stattrack и т.д.)
                        if (req.properties != null)
                        {
                            for (int j = 0; j < 5; j++)
                            {
                                if (req.properties.TryGetValue($"sticker_{j}", out var stickerValue))
                                {
                                    requests[i].Properties.Add($"sticker_{j}", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                                    {
                                        Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                        IntValue = stickerValue.AsInt32
                                    });
                                }
                            }
                            if (req.properties.TryGetValue("stattrack_value", out var stattrackValue))
                            {
                                requests[i].Properties.Add("stattrack_value", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                                {
                                    Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                    IntValue = stattrackValue.AsInt32
                                });
                            }
                        }
                    }

                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Return = new ToByteMethod(typeof(OpenRequest[])).ToBytes(requests)
                        }
                    });
                }
                else
                {
                    OpenRequest[] requests = new OpenRequest[0];
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Return = new ToByteMethod(typeof(OpenRequest[])).ToBytes(requests)
                        }
                    });
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getPlayerOpenRequests: {ex}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500
                        }
                    }
                });
            }
        }

        protected async void createSaleRequest(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                            { 
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                Code = 401
                            }
                        }
                    });
                    return;
                }

                // SECURITY: Check if player is banned from marketplace
                if (StaticClasses.MarketplaceBans.TryGetValue(playerId, out DateTime banExpiry))
                {
                    if (DateTime.UtcNow < banExpiry)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] BLOCKED: Banned player {playerId} attempted marketplace request. Ban expires: {banExpiry}");
                        _user.SendResponce(new ResponseMessage
                        {
                            RpcResponse = new RpcResponse
                            {
                                Id = guid,
                                Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                                { 
                                    Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                    Code = 403 // Forbidden
                                }
                            }
                        });
                        return;
                    }
                    else
                    {
                        // Ban expired, remove it
                        StaticClasses.MarketplaceBans.TryRemove(playerId, out _);
                    }
                }

                // SECURITY: Rate limiting - max 3 requests per second
                DateTime now = DateTime.UtcNow;
                if (StaticClasses.MarketplaceRateLimits.TryGetValue(playerId, out var rateLimit))
                {
                    // Check if within 1 second window
                    if ((now - rateLimit.timestamp).TotalSeconds < 1)
                    {
                        int newCount = rateLimit.count + 1;
                        
                        // If 3+ requests in 1 second, REJECT but DON'T BAN
                        if (newCount >= 3)
                        {
                            // Временная блокировка маркетплейса (не бан аккаунта)
                            DateTime blockUntil = DateTime.UtcNow.AddMinutes(5);
                            StaticClasses.MarketplaceBans.TryAdd(playerId, blockUntil);
                            
                            Console.WriteLine($"[MarketplaceRemoteService] ⚠️ Rate limit exceeded for player {playerId}: {newCount} requests in 1 second. Marketplace blocked for 5 minutes.");
                            
                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                                    { 
                                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                        Code = 429 // Too Many Requests
                                    }
                                }
                            });
                            return;
                        }
                        
                        // Update count
                        StaticClasses.MarketplaceRateLimits[playerId] = (rateLimit.timestamp, newCount);
                    }
                    else
                    {
                        // Reset window
                        StaticClasses.MarketplaceRateLimits[playerId] = (now, 1);
                    }
                }
                else
                {
                    // First request
                    StaticClasses.MarketplaceRateLimits.TryAdd(playerId, (now, 1));
                }

                CreateSaleRequestArgs args = (CreateSaleRequestArgs)new FromByteMethod(typeof(CreateSaleRequestArgs)).FromBytes(values[0]);

                var BoltGame = BoltGameDatabaseProvider.Instance;
                PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
                Axlebolt.Bolt.Protobuf.Player myPlayer = FriendHelper.GetPlayer(playerId);

                BsonDocument fullItemData = BoltGame.GetFullItemFromPlayerInventory(ObjectId.Parse(playerId), args.ItemId);
                if (fullItemData == null)
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                            { 
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                Code = 404
                            }
                        }
                    });
                    return;
                }

                int itemDefinitionId = fullItemData.GetValue("itemDefinitionId").AsInt32;

                // SECURITY: Validate price range (0.01 - 1,000,000)
                if (float.IsNaN(args.Price) || float.IsInfinity(args.Price) || args.Price < 0.01f || args.Price > 1000000.0f)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] REJECTED Sale Request from {playerId}: Invalid price {args.Price}");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                            { 
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                Code = 400
                            }
                        }
                    });
                    return;
                }

                // SECURITY: ATOMIC OPERATION - Take the item from inventory first.
                // If multiple requests come in for the same item ID, only one will succeed.
                if (!BoltGame.RemoveItemIfOwned(ObjectId.Parse(playerId), args.ItemId, itemDefinitionId))
                {
                    Console.WriteLine($"[MarketplaceRemoteService] REJECTED Sale Request from {playerId}: Item {args.ItemId} not owned or already listed.");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                            { 
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                                Code = 404
                            }
                        }
                    });
                    return;
                }

                ObjectId requestId = BoltGame.CreateMarketplaceRequest(playerId, args.ItemId, itemDefinitionId, args.Price, fullItemData);

                OnTradeRequestOpenedEvent evn = new OnTradeRequestOpenedEvent();
                OnPlayerRequestOpenedEvent evp = new OnPlayerRequestOpenedEvent();
                OnTradeUpdatedEvent onTradeUpdatedEvent = new OnTradeUpdatedEvent();

                var activeRequests = BoltGame.GetActiveMarketplaceRequestsByItem(itemDefinitionId, 0, 100);
                var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = itemDefinitionId });
                
                Trade trade = new Trade();
                trade.Id = itemDefinitionId;
                trade.SalesCount = activeRequests.Count;
                trade.SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : args.Price;
                trade.PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0;
                trade.PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity);

                onTradeUpdatedEvent.Trade = trade;

                Axlebolt.Bolt.Protobuf.Player player = new Axlebolt.Bolt.Protobuf.Player();
                player.Id = myPlayer.Id;
                player.Uid = myPlayer.Uid;
                player.Name = myPlayer.Name;
                player.AvatarId = myPlayer.AvatarId;
                player.TimeInGame = playerDocument.timeInGame;
                player.RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch;
                Axlebolt.Bolt.Protobuf.PlayerStatus playerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus();
                playerStatus.PlayerId = myPlayer.Id;
                player.PlayerStatus = playerStatus;

                OpenRequest openRequest = new OpenRequest();
                openRequest.Id = requestId.ToString();
                openRequest.Creator = player;
                openRequest.ItemDefinitionId = itemDefinitionId;
                openRequest.Price = args.Price;
                openRequest.CreateDate = DateTime.Now.Ticks;
                openRequest.Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest;
                openRequest.Quantity = 1;
                
                // STICKER FIX: Add item properties (stickers, stattrack, etc.) to OpenRequest
                if (fullItemData != null && (fullItemData.Contains("properties") || fullItemData.Contains("Properties")))
                {
                    BsonDocument propertiesDoc = null;
                    if (fullItemData.Contains("properties"))
                    {
                        propertiesDoc = fullItemData["properties"].AsBsonDocument;
                    }
                    else if (fullItemData.Contains("Properties"))
                    {
                        propertiesDoc = fullItemData["Properties"].AsBsonDocument;
                    }

                    if (propertiesDoc != null)
                    {
                        // Copy stickers
                        for (int j = 0; j < 5; j++)
                        {
                            if (propertiesDoc.TryGetValue($"sticker_{j}", out var stickerValue))
                            {
                                openRequest.Properties.Add($"sticker_{j}", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                                {
                                    Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                    IntValue = stickerValue.AsInt32
                                });
                            }
                        }
                        // Copy stattrack
                        if (propertiesDoc.TryGetValue("stattrack_value", out var stattrackValue))
                        {
                            openRequest.Properties.Add("stattrack_value", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                            {
                                Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                IntValue = stattrackValue.AsInt32
                            });
                        }
                    }
                }

                evn.Request = openRequest;
                evp.Request = openRequest.Clone();

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(string)).ToBytes(requestId.ToString())
                    }
                });

                BinaryValue val = new ToByteMethod(typeof(OnTradeRequestOpenedEvent)).ToBytes(evn);
                BinaryValue val2 = new ToByteMethod(typeof(OnPlayerRequestOpenedEvent)).ToBytes(evp);
                BinaryValue val3 = new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(onTradeUpdatedEvent);

                EventResponse resp = new EventResponse()
                {
                    ListenerName = "MarketplaceRemoteEventListener",
                    EventName = "onTradeRequestOpened"
                };
                EventResponse resp2 = new EventResponse()
                {
                    ListenerName = "MarketplaceRemoteEventListener",
                    EventName = "onPlayerRequestOpened"
                };
                EventResponse resp3 = new EventResponse()
                {
                    ListenerName = "MarketplaceRemoteEventListener",
                    EventName = "onTradeUpdated"
                };
                
                resp.Params.Add(val);
                resp2.Params.Add(val2);
                resp3.Params.Add(val3);

                _user.SendResponce(new ResponseMessage { EventResponse = resp });
                _user.SendResponce(new ResponseMessage { EventResponse = resp2 });
                _user.SendResponce(new ResponseMessage { EventResponse = resp3 });

                // REAL-TIME UPDATE: Broadcast to all connected users
                Console.WriteLine($"[MarketplaceRemoteService] About to broadcast sale request for item {itemDefinitionId} by player {playerId}");
                BroadcastMarketplaceEvent(resp, playerId);
                BroadcastMarketplaceEvent(resp3, playerId);
                
                Console.WriteLine($"[MarketplaceRemoteService] Completed broadcasting sale request for item {itemDefinitionId} to all users");

                // AUTO-MATCHING: Try to match with existing purchase requests
                await TryMatchSaleWithPurchaseRequestsAndNotify(itemDefinitionId, args.Price, requestId.ToString(), playerId);
            }
            catch (System.Exception ex)
            {
                 Console.WriteLine($"[MarketplaceRemoteService] Error in createSaleRequest: {ex}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500
                        }
                    }
                });
            }
        }

        protected async void createPurchaseRequestBySale(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string buyerId))
                {
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
                    return;
                }

                CreatePurchaseBySaleArgs args = (CreatePurchaseBySaleArgs)new FromByteMethod(typeof(CreatePurchaseBySaleArgs)).FromBytes(values[0]);
                var BoltGame = BoltGameDatabaseProvider.Instance;
                var player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(buyerId));

                // SECURITY: ATOMIC OPERATION - Consolidated logic in DB provider.
                var result = await BoltGame.CreatePurchaseRequestBySale(args, player);

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(string)).ToBytes(args.SaleId)
                    }
                });

                // Try to get seller info for Partner and buyer info for Creator
                string sellerId = result.SellerId;
                
                PlayerDocument sellerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(sellerId));
                Axlebolt.Bolt.Protobuf.Player sellerPlayer = FriendHelper.GetPlayer(sellerId);
                Axlebolt.Bolt.Protobuf.Player sellerpb = new Axlebolt.Bolt.Protobuf.Player
                {
                    Id = sellerPlayer.Id,
                    Uid = sellerPlayer.Uid,
                    Name = sellerPlayer.Name,
                    AvatarId = sellerPlayer.AvatarId,
                    TimeInGame = sellerDocument.timeInGame,
                    RegistrationDate = sellerDocument.createDate.MillisecondsSinceEpoch,
                    PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = sellerPlayer.Id }
                };

                PlayerDocument buyerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(buyerId));
                Axlebolt.Bolt.Protobuf.Player buyerPlayer = FriendHelper.GetPlayer(buyerId);
                Axlebolt.Bolt.Protobuf.Player buyerpb = new Axlebolt.Bolt.Protobuf.Player
                {
                    Id = buyerPlayer.Id,
                    Uid = buyerPlayer.Uid,
                    Name = buyerPlayer.Name,
                    AvatarId = buyerPlayer.AvatarId,
                    TimeInGame = buyerDocument.timeInGame,
                    RegistrationDate = buyerDocument.createDate.MillisecondsSinceEpoch,
                    PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = buyerPlayer.Id }
                };

                // Prepare and send events
                // CommissionPercent уже в процентах (0.17 = 17%), не нужно делить на 100
                float sellerAmount = result.Price * (1f - BoltGame.GetMarketplaceSettingsAsync().Result.CommissionPercent);

                ClosedRequest sellerClosedRequest = new ClosedRequest
                {
                    Id = args.SaleId,
                    OriginId = args.SaleId,
                    Creator = sellerpb,
                    ItemDefinitionId = result.ItemDefinitionId,
                    Price = sellerAmount,
                    CreateDate = DateTime.UtcNow.Ticks,
                    CloseDate = DateTime.UtcNow.Ticks,
                    Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest,
                    Partner = buyerpb,
                    PartnerRequestId = "",
                    Reason = ClosingReason.SuccessTransaction,
                    Quantity = 1
                };

                ClosedRequest buyerClosedRequest = new ClosedRequest
                {
                    Id = args.SaleId,
                    OriginId = args.SaleId,
                    Creator = buyerpb,
                    ItemDefinitionId = result.ItemDefinitionId,
                    Price = result.Price,
                    CreateDate = DateTime.UtcNow.Ticks,
                    CloseDate = DateTime.UtcNow.Ticks,
                    Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                    Partner = sellerpb,
                    PartnerRequestId = args.SaleId,
                    Reason = ClosingReason.SuccessTransaction,
                    Quantity = 1
                };

                Axlebolt.Bolt.Protobuf.InventoryItem purchasedItem = new Axlebolt.Bolt.Protobuf.InventoryItem();
                purchasedItem.Date = DateTime.UtcNow.Ticks;
                purchasedItem.ItemDefinitionId = result.ItemDefinitionId;
                purchasedItem.Quantity = 1;
                purchasedItem.Id = result.AssignedItemId; // The actual ID that was assigned to the item
                purchasedItem.Flags = 0;

                if (result.Properties != null && result.Properties.ElementCount > 0)
                {
                    foreach (var prop in result.Properties)
                    {
                        var itemProp = new Axlebolt.Bolt.Protobuf.InventoryItemProperty();
                        
                        if (prop.Value.IsInt32)
                        {
                            itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Int;
                            itemProp.IntValue = prop.Value.AsInt32;
                        }
                        else if (prop.Value.IsString)
                        {
                            itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.String;
                            itemProp.StringValue = prop.Value.AsString;
                        }
                        else if (prop.Value.IsDouble)
                        {
                            itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Float;
                            itemProp.FloatValue = (float)prop.Value.AsDouble;
                        }
                        
                        purchasedItem.Properties.Add(prop.Name, itemProp);
                    }
                }

                OnTradeRequestClosedEvent tradeClosedEvent = new OnTradeRequestClosedEvent { Request = sellerClosedRequest };
                OnPlayerRequestClosedEvent buyerEvent = new OnPlayerRequestClosedEvent { Request = buyerClosedRequest, Item = purchasedItem };
                OnTradeUpdatedEvent tradeUpdatedEvent = new OnTradeUpdatedEvent();

                var activeSaleRequests = await BoltGame.GetTradeOpenSaleRequests(new GetTradeOpenSaleRequestsArgs { Id = result.ItemDefinitionId });
                var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = result.ItemDefinitionId });
                
                tradeUpdatedEvent.Trade = new Trade
                {
                    Id = result.ItemDefinitionId,
                    SalesCount = activeSaleRequests.Length,
                    SalesPrice = activeSaleRequests.Length > 0 ? activeSaleRequests.Min(r => r.Price) : 0,
                    PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0,
                    PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity)
                };

                // Отправляем только onPlayerRequestClosed покупателю (текущему пользователю)
                _user.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onPlayerRequestClosed", Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(buyerEvent) } } });
                _user.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeUpdated", Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } } });

                // REAL-TIME UPDATE: Broadcast trade closed and updated events to all users (включая покупателя)
                EventResponse tradeClosedResp = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeRequestClosed", Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(tradeClosedEvent) } };
                EventResponse tradeUpdatedResp = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeUpdated", Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } };
                BroadcastMarketplaceEvent(tradeClosedResp, null); // Отправляем всем, включая покупателя
                BroadcastMarketplaceEvent(tradeUpdatedResp, null); // Отправляем всем, включая покупателя

                // Try to send notification to seller
                Console.WriteLine($"[MarketplaceRemoteService] Attempting to notify seller {sellerId}");
                
                if (StaticClasses.UserServices.TryGetValue(sellerId, out UserService sellerUserService))
                {
                    Console.WriteLine($"[MarketplaceRemoteService] Seller {sellerId} is online, sending notification");
                    
                    // Отправляем только onPlayerRequestClosed продавцу с суммой после комиссии
                    OnPlayerRequestClosedEvent sellerEvent = new OnPlayerRequestClosedEvent 
                    { 
                        Request = sellerClosedRequest,
                        Item = purchasedItem
                    };
                    
                    try
                    {
                        sellerUserService.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onPlayerRequestClosed", Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(sellerEvent) } } });
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent onPlayerRequestClosed to seller {sellerId} with amount {sellerAmount}");
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] ❌ Failed to send notification to seller {sellerId}: {ex.Message}");
                    }
                }
                else
                {
                    Console.WriteLine($"[MarketplaceRemoteService] ⚠️ Seller {sellerId} is offline, cannot send real-time notification");
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in createPurchaseRequestBySale: {ex.Message}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = ex.Message.Contains("not found") || ex.Message.Contains("already processed") ? 404 : 500
                        }
                    }
                });
            }
        }

        protected async void cancelRequest(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
                    return;
                }

                CancelRequestArgs args = (CancelRequestArgs)new FromByteMethod(typeof(CancelRequestArgs)).FromBytes(values[0]);
                var BoltGame = BoltGameDatabaseProvider.Instance;
                var player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));

                // SECURITY: ATOMIC OPERATION - Consolidated logic in DB provider.
                var result = await BoltGame.CancelRequest(args, player);
                if (result == null) throw new System.Exception("Request not found or already cancelled");

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(string)).ToBytes(args.Id)
                    }
                });

                // Prepare and send events
                PlayerDocument playerDocument = player;
                Axlebolt.Bolt.Protobuf.Player myPlayer = FriendHelper.GetPlayer(playerId);
                Axlebolt.Bolt.Protobuf.Player pbPlayer = new Axlebolt.Bolt.Protobuf.Player
                {
                    Id = myPlayer.Id,
                    Uid = myPlayer.Uid,
                    Name = myPlayer.Name,
                    AvatarId = myPlayer.AvatarId,
                    TimeInGame = playerDocument.timeInGame,
                    RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch,
                    PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = myPlayer.Id }
                };

                ClosedRequest closedRequest = new ClosedRequest
                {
                    Id = args.Id,
                    OriginId = args.Id,
                    Creator = pbPlayer,
                    ItemDefinitionId = result.ItemDefinitionId,
                    Price = result.Price,
                    CreateDate = DateTime.UtcNow.Ticks, // Simplified
                    CloseDate = DateTime.UtcNow.Ticks,
                    Type = (Axlebolt.Bolt.Protobuf.MarketRequestType)result.RequestType,
                    Partner = pbPlayer.Clone(),
                    PartnerRequestId = playerId,
                    Reason = ClosingReason.Cancelled,
                    Quantity = result.Quantity
                };

                Console.WriteLine($"[MarketplaceRemoteService] ✅ Request cancelled: ID={args.Id}, ItemDefId={result.ItemDefinitionId}, PlayerId={playerId}");

                OnTradeRequestClosedEvent tradeClosedEvent = new OnTradeRequestClosedEvent { Request = closedRequest };
                OnPlayerRequestClosedEvent playerClosedEvent = new OnPlayerRequestClosedEvent { Request = closedRequest.Clone() };
                if (result.ReturnedItem != null)
                {
                    playerClosedEvent.Item = new Axlebolt.Bolt.Protobuf.InventoryItem
                    {
                        Date = result.ReturnedItem.date.ToUniversalTime().Ticks,
                        ItemDefinitionId = result.ReturnedItem.itemDefinitionId,
                        Quantity = result.ReturnedItem.quantity,
                        Id = (int)result.ReturnedItem.id,
                        Flags = 0
                    };
                    
                    // ИСПРАВЛЕНИЕ: Копируем свойства (наклейки, stattrack и т.д.) из возвращенного предмета
                    if (result.ReturnedItem.Properties != null)
                    {
                        foreach (var prop in result.ReturnedItem.Properties)
                        {
                            playerClosedEvent.Item.Properties.Add(prop.Name, new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                            {
                                Type = (Axlebolt.Bolt.Protobuf.PropertyType)prop.Type,
                                IntValue = prop.Type == BoltInventoryItemProperty.PropertyType.Int ? Convert.ToInt32(prop.Value) : 0,
                                FloatValue = prop.Type == BoltInventoryItemProperty.PropertyType.Float ? Convert.ToSingle(prop.Value) : 0,
                                BooleanValue = prop.Type == BoltInventoryItemProperty.PropertyType.Boolean ? Convert.ToBoolean(prop.Value) : false,
                                StringValue = prop.Type == BoltInventoryItemProperty.PropertyType.String ? prop.Value : ""
                            });
                        }
                    }
                }

                var activeRequests = BoltGame.GetActiveMarketplaceRequestsByItem(result.ItemDefinitionId, 0, 100);
                var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = result.ItemDefinitionId });
                
                Trade trade = new Trade
                {
                    Id = result.ItemDefinitionId,
                    SalesCount = activeRequests.Count,
                    SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : 0,
                    PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0,
                    PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity)
                };

                Console.WriteLine($"[MarketplaceRemoteService] Trade updated after cancel: ItemDefId={result.ItemDefinitionId}, SalesCount={trade.SalesCount}, PurchasesCount={trade.PurchasesCount}");

                OnTradeUpdatedEvent tradeUpdatedEvent = new OnTradeUpdatedEvent { Trade = trade };

                _user.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeRequestClosed", Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(tradeClosedEvent) } } });
                _user.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onPlayerRequestClosed", Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(playerClosedEvent) } } });
                _user.SendResponce(new ResponseMessage { EventResponse = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeUpdated", Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } } });

                // REAL-TIME UPDATE: Broadcast cancel events to all users
                Console.WriteLine($"[MarketplaceRemoteService] Broadcasting cancel event for request ID={args.Id} to all users except {playerId}");
                EventResponse tradeClosedResp = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeRequestClosed", Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(tradeClosedEvent) } };
                EventResponse tradeUpdatedResp = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeUpdated", Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } };
                BroadcastMarketplaceEvent(tradeClosedResp, playerId);
                BroadcastMarketplaceEvent(tradeUpdatedResp, playerId);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in cancelRequest: {ex.Message}");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = ex.Message.Contains("not found") ? 404 : 500
                        }
                    }
                });
            }
        }

        protected async void getTradeOpenSaleRequests(BinaryValue[] values, string guid)
        {
            try
            {
                GetTradeOpenSaleRequestsArgs args = (GetTradeOpenSaleRequestsArgs)new FromByteMethod(typeof(GetTradeOpenSaleRequestsArgs)).FromBytes(values[0]);
                var BoltGame = BoltGameDatabaseProvider.Instance;
                
                var activeRequests = BoltGame.GetActiveMarketplaceRequestsByItem(args.Id, args.Page, args.Size);
                
                OpenRequest[] requests = new OpenRequest[activeRequests.Count];
                for (int i = 0; i < activeRequests.Count; i++)
                {
                    try
                    {
                        requests[i] = await activeRequests[i].ToProto();
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] Error converting request {i} to proto: {ex.Message}");
                        // Пропускаем проблемный запрос
                        requests[i] = null;
                    }
                }

                // Фильтруем null значения
                var validRequests = requests.Where(r => r != null).ToArray();

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(OpenRequest[])).ToBytes(validRequests)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getTradeOpenSaleRequests: {ex}");
                _user.SendResponce(new ResponseMessage 
                { 
                    RpcResponse = new RpcResponse 
                    { 
                        Id = guid, 
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                        { 
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                            Code = 500 
                        } 
                    } 
                });
            }
        }

        protected async void getPlayerClosedRequests(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    throw new System.Exception("Player not found");
                }

                GetClosedRequestsArgs args = (GetClosedRequestsArgs)new FromByteMethod(typeof(GetClosedRequestsArgs)).FromBytes(values[0]);
                var playerDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
                
                if (playerDoc == null)
                {
                    throw new System.Exception("Player document not found");
                }
                
                var closedRequests = await BoltGameDatabaseProvider.Instance.GetPlayerClosedRequests(args, playerDoc);
                
                if (closedRequests == null)
                {
                    closedRequests = new ClosedRequest[0];
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(ClosedRequest[])).ToBytes(closedRequests)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getPlayerClosedRequests: {ex}");
                try
                {
                    if (_user != null)
                    {
                        _user.SendResponce(new ResponseMessage { RpcResponse = { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
                    }
                }
                catch (System.Exception sendEx)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] Error sending error response: {sendEx}");
                }
            }
        }

        protected async void getPlayerClosedRequestsCount(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    throw new System.Exception("Player not found");
                }

                GetClosedRequestsCountArgs args = (GetClosedRequestsCountArgs)new FromByteMethod(typeof(GetClosedRequestsCountArgs)).FromBytes(values[0]);
                var playerDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));

                int count = await BoltGameDatabaseProvider.Instance.GetPlayerClosedRequestsCountAsync(args, playerDoc);

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(int)).ToBytes(count)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getPlayerClosedRequestsCount: {ex}");
                try
                {
                    if (_user != null)
                    {
                        _user.SendResponce(new ResponseMessage { RpcResponse = { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
                    }
                }
                catch (System.Exception sendEx)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] Error sending error response: {sendEx}");
                }
            }
        }

        protected async void createSale(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                CreateSaleRequest request = (CreateSaleRequest)new FromByteMethod(typeof(CreateSaleRequest)).FromBytes(values[0]);
                
                var BoltGame = BoltGameDatabaseProvider.Instance;
                BsonDocument fullItemData = BoltGame.GetFullItemFromPlayerInventory(ObjectId.Parse(playerId), request.ItemId);
                if (fullItemData == null)
                {
                    SendError(guid, 404);
                    return;
                }

                int itemDefinitionId = fullItemData.GetValue("itemDefinitionId").AsInt32;

                if (!BoltGame.RemoveItemIfOwned(ObjectId.Parse(playerId), request.ItemId, itemDefinitionId))
                {
                    SendError(guid, 404);
                    return;
                }

                // SECURITY: Validate price range (0.01 - 1,000,000)
                if (float.IsNaN(request.Price) || float.IsInfinity(request.Price) || request.Price < 0.01f || request.Price > 1000000.0f)
                {
                    SendError(guid, 400);
                    return;
                }

                ObjectId id = BoltGame.CreateMarketplaceRequest(playerId, request.ItemId, itemDefinitionId, (long)request.Price, fullItemData);

                CreateSaleResponse response = new CreateSaleResponse { RequestId = id.ToString() };

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(CreateSaleResponse)).ToBytes(response)
                    }
                });

                // Trigger events
                TriggerSaleEvents(playerId, id, itemDefinitionId, request.Price, fullItemData);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in createSale: {ex}");
                SendError(guid, 500);
            }
        }

        private async void TriggerSaleEvents(string playerId, ObjectId requestId, int itemDefinitionId, float price, BsonDocument fullItemData)
        {
            try
            {
                var BoltGame = BoltGameDatabaseProvider.Instance;
                PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
                Axlebolt.Bolt.Protobuf.Player myPlayer = FriendHelper.GetPlayer(playerId);

                OnTradeRequestOpenedEvent evn = new OnTradeRequestOpenedEvent();
                OnPlayerRequestOpenedEvent evp = new OnPlayerRequestOpenedEvent();
                OnTradeUpdatedEvent onTradeUpdatedEvent = new OnTradeUpdatedEvent();

                var activeRequests = BoltGame.GetActiveMarketplaceRequestsByItem(itemDefinitionId, 0, 100);
                var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = itemDefinitionId });
                
                Trade trade = new Trade();
                trade.Id = itemDefinitionId;
                trade.SalesCount = activeRequests.Count;
                trade.SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : price;
                trade.PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0;
                trade.PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity);

                onTradeUpdatedEvent.Trade = trade;

                Axlebolt.Bolt.Protobuf.Player player = new Axlebolt.Bolt.Protobuf.Player();
                player.Id = myPlayer.Id;
                player.Uid = myPlayer.Uid;
                player.Name = myPlayer.Name;
                player.AvatarId = myPlayer.AvatarId;
                player.TimeInGame = playerDocument.timeInGame;
                player.RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch;
                Axlebolt.Bolt.Protobuf.PlayerStatus playerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus();
                playerStatus.PlayerId = myPlayer.Id;
                player.PlayerStatus = playerStatus;

                OpenRequest openRequest = new OpenRequest();
                openRequest.Id = requestId.ToString();
                openRequest.Creator = player;
                openRequest.ItemDefinitionId = itemDefinitionId;
                openRequest.Price = price;
                openRequest.CreateDate = DateTime.Now.Ticks;
                openRequest.Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest;
                openRequest.Quantity = 1;
                
                // STICKER FIX: Add item properties (stickers, stattrack, etc.) to OpenRequest
                if (fullItemData != null && (fullItemData.Contains("properties") || fullItemData.Contains("Properties")))
                {
                    BsonDocument propertiesDoc = null;
                    if (fullItemData.Contains("properties"))
                    {
                        propertiesDoc = fullItemData["properties"].AsBsonDocument;
                    }
                    else if (fullItemData.Contains("Properties"))
                    {
                        propertiesDoc = fullItemData["Properties"].AsBsonDocument;
                    }

                    if (propertiesDoc != null)
                    {
                        // Copy stickers
                        for (int j = 0; j < 5; j++)
                        {
                            if (propertiesDoc.TryGetValue($"sticker_{j}", out var stickerValue))
                            {
                                openRequest.Properties.Add($"sticker_{j}", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                                {
                                    Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                    IntValue = stickerValue.AsInt32
                                });
                            }
                        }
                        // Copy stattrack
                        if (propertiesDoc.TryGetValue("stattrack_value", out var stattrackValue))
                        {
                            openRequest.Properties.Add("stattrack_value", new Axlebolt.Bolt.Protobuf.InventoryItemProperty
                            {
                                Type = Axlebolt.Bolt.Protobuf.PropertyType.Int,
                                IntValue = stattrackValue.AsInt32
                            });
                        }
                    }
                }

                evn.Request = openRequest;
                evp.Request = openRequest.Clone();

                BinaryValue val = new ToByteMethod(typeof(OnTradeRequestOpenedEvent)).ToBytes(evn);
                BinaryValue val2 = new ToByteMethod(typeof(OnPlayerRequestOpenedEvent)).ToBytes(evp);
                BinaryValue val3 = new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(onTradeUpdatedEvent);

                EventResponse resp = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeRequestOpened" };
                EventResponse resp2 = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onPlayerRequestOpened" };
                EventResponse resp3 = new EventResponse { ListenerName = "MarketplaceRemoteEventListener", EventName = "onTradeUpdated" };
                
                resp.Params.Add(val);
                resp2.Params.Add(val2);
                resp3.Params.Add(val3);

                // Send to current user
                _user.SendResponce(new ResponseMessage { EventResponse = resp });
                _user.SendResponce(new ResponseMessage { EventResponse = resp2 });
                _user.SendResponce(new ResponseMessage { EventResponse = resp3 });

                // REAL-TIME UPDATE: Broadcast to all connected users
                BroadcastMarketplaceEvent(resp, playerId);
                BroadcastMarketplaceEvent(resp3, playerId);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in TriggerSaleEvents: {ex}");
            }
        }

        private async Task TryMatchSaleWithPurchaseRequestsAndNotify(int itemDefinitionId, float salePrice, string saleId, string sellerId)
        {
            try
            {
                var BoltGame = BoltGameDatabaseProvider.Instance;
                var database = BoltGame.GetDatabase;
                var collection = database.GetCollection<BsonDocument>("marketplace_request");

                // Find purchase requests that match: same item, maxPrice >= salePrice, active
                var filter = Builders<BsonDocument>.Filter.Eq("itemDefinitionId", itemDefinitionId) &
                             Builders<BsonDocument>.Filter.Gte("price", salePrice) &
                             Builders<BsonDocument>.Filter.Eq("status", (int)MarketplaceRequestStatus.Active) &
                             Builders<BsonDocument>.Filter.Eq("type", (int)Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest);

                var purchaseRequests = await collection.Find(filter)
                    .Sort(Builders<BsonDocument>.Sort.Descending("price")) // Highest price first
                    .Limit(1)
                    .ToListAsync();

                if (purchaseRequests.Count() > 0)
                {
                    var purchaseDoc = purchaseRequests[0];
                    string buyerId = purchaseDoc["playerId"].AsString;

                    Console.WriteLine($"[MarketplaceRemoteService] 🔄 Auto-matching sale {saleId} with purchase request from buyer {buyerId}");

                    try
                    {
                        // Execute the purchase
                        var args = new CreatePurchaseBySaleArgs { SaleId = saleId };
                        var player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(buyerId));

                        // ИСПРАВЛЕНИЕ: Проверяем наличие голды у покупателя ПЕРЕД выполнением покупки
                        var saleDoc = await collection.Find(Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(saleId))).FirstOrDefaultAsync();
                        if (saleDoc != null)
                        {
                            float saleDocPrice = (float)saleDoc["price"].AsDouble;
                            var marketplaceSettings = await BoltGame.GetMarketplaceSettingsAsync();
                            int currencyId = marketplaceSettings.CurrencyId;
                            
                            if (!BoltGame.IsEnoughFunds(buyerId, currencyId.ToString(), saleDocPrice))
                            {
                                Console.WriteLine($"[MarketplaceRemoteService] ⚠️ Buyer {buyerId} has insufficient funds for sale {saleId}. Canceling purchase request.");
                                
                                // Отменяем запрос на покупку
                                ObjectId purchaseReqId = purchaseDoc["_id"].AsObjectId;
                                await BoltGame.CancelPurchaseRequestDueToInsufficientFunds(purchaseReqId);
                                
                                Console.WriteLine($"[MarketplaceRemoteService] ✅ Canceled purchase request {purchaseReqId} due to insufficient funds");
                                return; // Выходим, не выполняя покупку
                            }
                        }

                        var result = await BoltGame.CreatePurchaseRequestBySale(args, player);
                        
                        // КРИТИЧНО: Уменьшаем количество в запросе на покупку после успешной покупки
                        ObjectId purchaseRequestId = purchaseDoc["_id"].AsObjectId;
                        bool decremented = await BoltGame.DecrementPurchaseRequestQuantity(purchaseRequestId);
                        Console.WriteLine($"[MarketplaceRemoteService] 🔽 Decremented purchase request {purchaseRequestId} quantity after auto-match: {decremented}");

                        // Get seller and buyer info
                        PlayerDocument sellerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(sellerId));
                        Axlebolt.Bolt.Protobuf.Player sellerPlayer = FriendHelper.GetPlayer(sellerId);
                        Axlebolt.Bolt.Protobuf.Player sellerpb = new Axlebolt.Bolt.Protobuf.Player
                        {
                            Id = sellerPlayer.Id,
                            Uid = sellerPlayer.Uid,
                            Name = sellerPlayer.Name,
                            AvatarId = sellerPlayer.AvatarId,
                            TimeInGame = sellerDocument.timeInGame,
                            RegistrationDate = sellerDocument.createDate.MillisecondsSinceEpoch,
                            PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = sellerPlayer.Id }
                        };

                        PlayerDocument buyerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(buyerId));
                        Axlebolt.Bolt.Protobuf.Player buyerPlayer = FriendHelper.GetPlayer(buyerId);
                        Axlebolt.Bolt.Protobuf.Player buyerpb = new Axlebolt.Bolt.Protobuf.Player
                        {
                            Id = buyerPlayer.Id,
                            Uid = buyerPlayer.Uid,
                            Name = buyerPlayer.Name,
                            AvatarId = buyerPlayer.AvatarId,
                            TimeInGame = buyerDocument.timeInGame,
                            RegistrationDate = buyerDocument.createDate.MillisecondsSinceEpoch,
                            PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = buyerPlayer.Id }
                        };

                        // Create purchased item
                        var purchasedItem = new Axlebolt.Bolt.Protobuf.InventoryItem
                        {
                            Date = DateTime.UtcNow.Ticks,
                            ItemDefinitionId = result.ItemDefinitionId,
                            Quantity = 1,
                            Id = result.AssignedItemId,
                            Flags = 0
                        };

                        // Copy properties
                        if (result.Properties != null && result.Properties.ElementCount > 0)
                        {
                            foreach (var prop in result.Properties)
                            {
                                var itemProp = new Axlebolt.Bolt.Protobuf.InventoryItemProperty();
                                if (prop.Value.IsInt32)
                                {
                                    itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Int;
                                    itemProp.IntValue = prop.Value.AsInt32;
                                }
                                else if (prop.Value.IsString)
                                {
                                    itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.String;
                                    itemProp.StringValue = prop.Value.AsString;
                                }
                                else if (prop.Value.IsDouble)
                                {
                                    itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Float;
                                    itemProp.FloatValue = (float)prop.Value.AsDouble;
                                }
                                purchasedItem.Properties.Add(prop.Name, itemProp);
                            }
                        }

                        float sellerAmount = result.Price * (1f - BoltGame.GetMarketplaceSettingsAsync().Result.CommissionPercent);

                        // Create closed requests for both parties
                        ClosedRequest sellerClosedRequest = new ClosedRequest
                        {
                            Id = saleId,
                            OriginId = saleId,
                            Creator = sellerpb,
                            ItemDefinitionId = result.ItemDefinitionId,
                            Price = sellerAmount,
                            CreateDate = DateTime.UtcNow.Ticks,
                            CloseDate = DateTime.UtcNow.Ticks,
                            Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest,
                            Partner = buyerpb,
                            PartnerRequestId = purchaseDoc["_id"].ToString(),
                            Reason = ClosingReason.SuccessTransaction,
                            Quantity = 1
                        };

                        ClosedRequest buyerClosedRequest = new ClosedRequest
                        {
                            Id = purchaseDoc["_id"].ToString(),
                            OriginId = purchaseDoc["_id"].ToString(),
                            Creator = buyerpb,
                            ItemDefinitionId = result.ItemDefinitionId,
                            Price = result.Price,
                            CreateDate = DateTime.UtcNow.Ticks,
                            CloseDate = DateTime.UtcNow.Ticks,
                            Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                            Partner = sellerpb,
                            PartnerRequestId = saleId,
                            Reason = ClosingReason.SuccessTransaction,
                            Quantity = 1
                        };

                        // Send notification to SELLER (current user)
                        OnPlayerRequestClosedEvent sellerEvent = new OnPlayerRequestClosedEvent { Request = sellerClosedRequest, Item = purchasedItem };
                        _user.SendResponce(new ResponseMessage 
                        { 
                            EventResponse = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onPlayerRequestClosed", 
                                Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(sellerEvent) } 
                            } 
                        });
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent onPlayerRequestClosed to seller {sellerId}");

                        // Send notification to BUYER
                        if (StaticClasses.UserServices.TryGetValue(buyerId, out UserService buyerUserService))
                        {
                            OnPlayerRequestClosedEvent buyerEvent = new OnPlayerRequestClosedEvent { Request = buyerClosedRequest, Item = purchasedItem };
                            buyerUserService.SendResponce(new ResponseMessage 
                            { 
                                EventResponse = new EventResponse 
                                { 
                                    ListenerName = "MarketplaceRemoteEventListener", 
                                    EventName = "onPlayerRequestClosed", 
                                    Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(buyerEvent) } 
                                } 
                            });
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent onPlayerRequestClosed to buyer {buyerId}");
                        }
                        else
                        {
                            Console.WriteLine($"[MarketplaceRemoteService] ⚠️ Buyer {buyerId} is offline, cannot send real-time notification");
                        }

                        // Broadcast onTradeRequestClosed to all users
                        OnTradeRequestClosedEvent tradeClosedEvent = new OnTradeRequestClosedEvent { Request = sellerClosedRequest };
                        EventResponse tradeClosedResp = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeRequestClosed", 
                            Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(tradeClosedEvent) } 
                        };
                        BroadcastMarketplaceEvent(tradeClosedResp, null);

                        // Broadcast onTradeUpdated
                        var activeRequests = BoltGame.GetActiveMarketplaceRequestsByItem(result.ItemDefinitionId, 0, 100);
                        var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = result.ItemDefinitionId });
                        
                        OnTradeUpdatedEvent tradeUpdatedEvent = new OnTradeUpdatedEvent
                        {
                            Trade = new Trade
                            {
                                Id = result.ItemDefinitionId,
                                SalesCount = activeRequests.Count,
                                SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : 0,
                                PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity),
                                PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0
                            }
                        };

                        EventResponse tradeUpdatedResp = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeUpdated", 
                            Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } 
                        };
                        BroadcastMarketplaceEvent(tradeUpdatedResp, null);

                        // ИСПРАВЛЕНИЕ: Проверяем, был ли запрос на покупку полностью выполнен (удален из БД)
                        var updatedPurchaseRequest = BoltGame.GetMarketplaceRequest(purchaseRequestId);
                        if (updatedPurchaseRequest == null)
                        {
                            // Запрос полностью выполнен - отправляем onTradeRequestClosed
                            var purchaseClosedRequest = new ClosedRequest
                            {
                                Id = purchaseRequestId.ToString(),
                                OriginId = purchaseRequestId.ToString(),
                                Creator = buyerpb,
                                ItemDefinitionId = result.ItemDefinitionId,
                                Price = result.Price,
                                CreateDate = DateTime.UtcNow.Ticks,
                                CloseDate = DateTime.UtcNow.Ticks,
                                Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                                Partner = sellerpb,
                                PartnerRequestId = saleId,
                                Reason = ClosingReason.SuccessTransaction,
                                Quantity = 1
                            };
                            
                            Console.WriteLine($"[MarketplaceRemoteService] 🔔 Closing purchase request: ID={purchaseRequestId}, ItemDefId={result.ItemDefinitionId}, BuyerId={buyerId}, Price={result.Price}");
                            
                            OnTradeRequestClosedEvent purchaseClosedEvent = new OnTradeRequestClosedEvent { Request = purchaseClosedRequest };
                            EventResponse purchaseClosedResp = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeRequestClosed", 
                                Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(purchaseClosedEvent) } 
                            };
                            BroadcastMarketplaceEvent(purchaseClosedResp, null);
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted onTradeRequestClosed for completed purchase request {purchaseRequestId} to ALL users");
                            
                            // Отправляем обновленный onTradeUpdated с новым количеством запросов на покупку
                            var finalActivePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = result.ItemDefinitionId });
                            OnTradeUpdatedEvent finalTradeUpdate = new OnTradeUpdatedEvent
                            {
                                Trade = new Trade
                                {
                                    Id = result.ItemDefinitionId,
                                    SalesCount = activeRequests.Count,
                                    SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : 0,
                                    PurchasesCount = finalActivePurchaseRequests.Sum(r => r.Quantity),
                                    PurchasesPrice = finalActivePurchaseRequests.Length > 0 ? finalActivePurchaseRequests.Max(r => r.Price) : 0
                                }
                            };
                            EventResponse finalTradeUpdateResp = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeUpdated", 
                                Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(finalTradeUpdate) } 
                            };
                            BroadcastMarketplaceEvent(finalTradeUpdateResp, null);
                        }
                        else
                        {
                            // Запрос частично выполнен - отправляем обновленный onTradeUpdated
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Purchase request {purchaseRequestId} partially completed, remaining quantity: {updatedPurchaseRequest.quantity}");
                            
                            var activePurchaseRequestsAfterUpdate = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = result.ItemDefinitionId });
                            
                            OnTradeUpdatedEvent tradeUpdatedEventAfterPartial = new OnTradeUpdatedEvent
                            {
                                Trade = new Trade
                                {
                                    Id = result.ItemDefinitionId,
                                    SalesCount = activeRequests.Count,
                                    SalesPrice = activeRequests.Count > 0 ? activeRequests.Min(r => r.price) : 0,
                                    PurchasesCount = activePurchaseRequestsAfterUpdate.Sum(r => r.Quantity),
                                    PurchasesPrice = activePurchaseRequestsAfterUpdate.Length > 0 ? activePurchaseRequestsAfterUpdate.Max(r => r.Price) : 0
                                }
                            };

                            EventResponse tradeUpdatedRespAfterPartial = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeUpdated", 
                                Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEventAfterPartial) } 
                            };
                            BroadcastMarketplaceEvent(tradeUpdatedRespAfterPartial, null);
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted onTradeUpdated after partial purchase completion: PurchasesCount={activePurchaseRequestsAfterUpdate.Sum(r => r.Quantity)}");
                        }

                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Auto-match completed: sale {saleId} matched with purchase from {buyerId}");
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] ❌ Failed to match sale {saleId} with purchase request: {ex.Message}");
                        
                        // ИСПРАВЛЕНИЕ: Если покупка не удалась из-за недостатка средств, отменяем запрос на покупку
                        if (ex.Message.Contains("Not enough funds") || ex.Message.Contains("insufficient funds"))
                        {
                            try
                            {
                                ObjectId purchaseRequestId = purchaseDoc["_id"].AsObjectId;
                                await BoltGame.CancelPurchaseRequestDueToInsufficientFunds(purchaseRequestId);
                                Console.WriteLine($"[MarketplaceRemoteService] ✅ Canceled purchase request {purchaseRequestId} due to insufficient funds after failed auto-match");
                            }
                            catch (System.Exception cancelEx)
                            {
                                Console.WriteLine($"[MarketplaceRemoteService] ❌ Failed to cancel purchase request after insufficient funds error: {cancelEx.Message}");
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] ❌ Error in TryMatchSaleWithPurchaseRequestsAndNotify: {ex.Message}");
            }
        }

        private void BroadcastMarketplaceEvent(EventResponse eventResponse, string excludePlayerId = null)
        {
            try
            {
                Console.WriteLine($"[MarketplaceRemoteService] BroadcastMarketplaceEvent called. Event: {eventResponse.EventName}, ExcludePlayer: {excludePlayerId}");
                Console.WriteLine($"[MarketplaceRemoteService] Total EventSenders count: {StaticClasses.EventSenders.Count}");
                
                int broadcastCount = 0;
                int skippedCount = 0;
                
                // ИСПРАВЛЕНИЕ: Десериализуем параметры один раз для всех
                object[] deserializedParams = null;
                
                if (eventResponse.Params.Count > 0)
                {
                    try
                    {
                        if (eventResponse.EventName == "onTradeRequestOpened")
                        {
                            var evt = (OnTradeRequestOpenedEvent)new FromByteMethod(typeof(OnTradeRequestOpenedEvent)).FromBytes(eventResponse.Params[0]);
                            Console.WriteLine($"[MarketplaceRemoteService] Broadcasting onTradeRequestOpened: RequestId={evt.Request?.Id}");
                            deserializedParams = new object[] { evt };
                        }
                        else if (eventResponse.EventName == "onTradeUpdated")
                        {
                            var evt = (OnTradeUpdatedEvent)new FromByteMethod(typeof(OnTradeUpdatedEvent)).FromBytes(eventResponse.Params[0]);
                            Console.WriteLine($"[MarketplaceRemoteService] Broadcasting onTradeUpdated: ItemDefId={evt.Trade?.Id}");
                            deserializedParams = new object[] { evt };
                        }
                        else if (eventResponse.EventName == "onTradeRequestClosed")
                        {
                            var evt = (OnTradeRequestClosedEvent)new FromByteMethod(typeof(OnTradeRequestClosedEvent)).FromBytes(eventResponse.Params[0]);
                            Console.WriteLine($"[MarketplaceRemoteService] Broadcasting onTradeRequestClosed: RequestId={evt.Request?.Id}, ItemDefId={evt.Request?.ItemDefinitionId}, Reason={evt.Request?.Reason}");
                            deserializedParams = new object[] { evt };
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] ❌ Error deserializing event params: {ex.Message}");
                        return;
                    }
                }
                
                if (deserializedParams == null)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] ⚠️ No params to broadcast");
                    return;
                }
                
                // ИСПРАВЛЕНИЕ: Используем StaticClasses.EventSenders вместо UserServices
                foreach (var kvp in StaticClasses.EventSenders)
                {
                    string playerId = kvp.Key;
                    
                    try
                    {
                        // Skip the user who triggered the event (already sent)
                        if (excludePlayerId != null && playerId == excludePlayerId)
                        {
                            Console.WriteLine($"[MarketplaceRemoteService] Skipping sender: {playerId}");
                            skippedCount++;
                            continue;
                        }
                        
                        // Находим MarketplaceRemoteEventListener для этого игрока
                        var marketplaceListener = kvp.Value.FirstOrDefault(sender => sender is MarketplaceRemoteEventListener);
                        
                        if (marketplaceListener != null)
                        {
                            // Отправляем событие через listener
                            marketplaceListener.SendEvent(eventResponse.EventName, deserializedParams);
                            
                            broadcastCount++;
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted {eventResponse.EventName} to player {playerId}");
                        }
                        else
                        {
                            Console.WriteLine($"[MarketplaceRemoteService] ⚠️ No MarketplaceRemoteEventListener found for player {playerId}");
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Console.WriteLine($"[MarketplaceRemoteService] ❌ Error broadcasting to player {playerId}: {ex.Message}");
                    }
                }
                
                Console.WriteLine($"[MarketplaceRemoteService] Broadcast complete. Sent to {broadcastCount} users, skipped {skippedCount}");
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in BroadcastMarketplaceEvent: {ex}");
            }
        }

        protected async void createPurchaseRequest(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string buyerId))
                {
                    SendError(guid, 401);
                    return;
                }

                CreatePurchaseRequestArgs args = (CreatePurchaseRequestArgs)new FromByteMethod(typeof(CreatePurchaseRequestArgs)).FromBytes(values[0]);
                var BoltGame = BoltGameDatabaseProvider.Instance;

                // ИСПРАВЛЕНИЕ: Проверяем настройку offrequests
                var marketplaceSettings = await BoltGame.GetMarketplaceSettingsAsync();
                if (marketplaceSettings.Offrequests)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] REJECTED Purchase Request from {buyerId}: Purchase requests are disabled (offrequests=true)");
                    SendError(guid, 403); // Forbidden
                    return;
                }

                // Validate price
                if (float.IsNaN(args.Price) || float.IsInfinity(args.Price) || args.Price < 0.01f || args.Price > 1000000.0f)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] REJECTED Purchase Request from {buyerId}: Invalid price {args.Price}");
                    SendError(guid, 400);
                    return;
                }

                // Validate quantity
                if (args.Quantity < 1 || args.Quantity > 200)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] REJECTED Purchase Request from {buyerId}: Invalid quantity {args.Quantity}");
                    SendError(guid, 400);
                    return;
                }

                // Create purchase request (will auto-match with existing sales)
                var requestId = await BoltGame.CreatePurchaseRequestAsync(buyerId, args.ItemDefinitionId, args.Price, args.Quantity);

                // Get the created request
                var createdRequest = BoltGame.GetMarketplaceRequest(requestId);
                
                if (createdRequest == null)
                {
                    SendError(guid, 500);
                    return;
                }

                // Convert to proto
                var purchaseRequest = await createdRequest.ToProto();

                // Send RPC response
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(string)).ToBytes(requestId.ToString())
                    }
                });

                // Always send "opened" event first (even if it will be immediately closed)
                var onRequestOpenedEvent = new OnPlayerRequestOpenedEvent { Request = purchaseRequest };
                _user.SendResponce(new ResponseMessage 
                { 
                    EventResponse = new EventResponse 
                    { 
                        ListenerName = "MarketplaceRemoteEventListener", 
                        EventName = "onPlayerRequestOpened", 
                        Params = { new ToByteMethod(typeof(OnPlayerRequestOpenedEvent)).ToBytes(onRequestOpenedEvent) } 
                    } 
                });
                Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent onPlayerRequestOpened to buyer {buyerId} for request {requestId}");

                // Try to match with existing sales
                var matchedSaleIds = new List<string>();
                
                // AUTO-MATCHING: Find sales that match the purchase request criteria
                var activeSales = BoltGame.GetActiveMarketplaceRequestsByItem(args.ItemDefinitionId, 0, args.Quantity);
                foreach (var sale in activeSales)
                {
                    // Match if sale price <= purchase price (buyer willing to pay this much)
                    if (sale.price <= args.Price && matchedSaleIds.Count < args.Quantity)
                    {
                        matchedSaleIds.Add(sale._id.ToString());
                        Console.WriteLine($"[MarketplaceRemoteService] 🎯 Matched sale {sale._id} (price: {sale.price}) with purchase request {requestId} (max price: {args.Price})");
                    }
                }
                
                Console.WriteLine($"[MarketplaceRemoteService] Found {matchedSaleIds.Count} matching sales for purchase request {requestId}");
                
                // Process matched sales AFTER sending opened event
                if (matchedSaleIds.Count() > 0)
                {
                    Console.WriteLine($"[MarketplaceRemoteService] Purchase request {requestId} auto-matched with {matchedSaleIds.Count()} sales at creation time");
                    
                    var player = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(buyerId));
                    int purchasedCount = 0;
                    int remainingQuantity = args.Quantity;
                    
                    // Execute purchases for each matched sale WITH 150ms DELAY
                    foreach (var saleId in matchedSaleIds)
                    {
                        try
                        {
                            // 150ms задержка между покупками
                            if (purchasedCount > 0)
                            {
                                await Task.Delay(150);
                            }
                            
                            // Execute the purchase using the database method
                            var saleArgs = new CreatePurchaseBySaleArgs { SaleId = saleId };
                            var purchaseResult = await BoltGame.CreatePurchaseRequestBySale(saleArgs, player);
                            
                            // КРИТИЧНО: Уменьшаем количество в запросе на покупку после успешной покупки
                            bool decremented = await BoltGame.DecrementPurchaseRequestQuantity(requestId);
                            Console.WriteLine($"[MarketplaceRemoteService] 🔽 Decremented purchase request {requestId} quantity: {decremented}");
                            
                            purchasedCount++;
                            remainingQuantity--;
                            
                            Console.WriteLine($"[MarketplaceRemoteService] 🛒 Purchased {purchasedCount}/{matchedSaleIds.Count} - Remaining in request: {remainingQuantity}");
                            
                            // Get seller info
                            string sellerId = purchaseResult.SellerId;
                            PlayerDocument sellerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(sellerId));
                            Axlebolt.Bolt.Protobuf.Player sellerPlayer = FriendHelper.GetPlayer(sellerId);
                            Axlebolt.Bolt.Protobuf.Player sellerpb = new Axlebolt.Bolt.Protobuf.Player
                            {
                                Id = sellerPlayer.Id,
                                Uid = sellerPlayer.Uid,
                                Name = sellerPlayer.Name,
                                AvatarId = sellerPlayer.AvatarId,
                                TimeInGame = sellerDocument.timeInGame,
                                RegistrationDate = sellerDocument.createDate.MillisecondsSinceEpoch,
                                PlayerStatus = new Axlebolt.Bolt.Protobuf.PlayerStatus { PlayerId = sellerPlayer.Id }
                            };
                            
                            // Send notification to buyer for THIS purchase
                            var buyerClosedRequest = new ClosedRequest
                            {
                                Id = requestId.ToString(), // Use the purchase request ID
                                OriginId = requestId.ToString(),
                                Creator = FriendHelper.GetPlayer(buyerId),
                                ItemDefinitionId = purchaseResult.ItemDefinitionId,
                                Price = purchaseResult.Price,
                                CreateDate = DateTime.UtcNow.Ticks,
                                CloseDate = DateTime.UtcNow.Ticks,
                                Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                                Partner = sellerpb,
                                PartnerRequestId = saleId,
                                Reason = ClosingReason.SuccessTransaction,
                                Quantity = 1
                            };
                            
                            var purchasedItem = new Axlebolt.Bolt.Protobuf.InventoryItem
                            {
                                Date = DateTime.UtcNow.Ticks,
                                ItemDefinitionId = purchaseResult.ItemDefinitionId,
                                Quantity = 1,
                                Id = purchaseResult.AssignedItemId,
                                Flags = 0
                            };
                            
                            // Copy properties if available
                            if (purchaseResult.Properties != null && purchaseResult.Properties.ElementCount > 0)
                            {
                                foreach (var prop in purchaseResult.Properties)
                                {
                                    var itemProp = new Axlebolt.Bolt.Protobuf.InventoryItemProperty();
                                    if (prop.Value.IsInt32)
                                    {
                                        itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Int;
                                        itemProp.IntValue = prop.Value.AsInt32;
                                    }
                                    else if (prop.Value.IsString)
                                    {
                                        itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.String;
                                        itemProp.StringValue = prop.Value.AsString;
                                    }
                                    else if (prop.Value.IsDouble)
                                    {
                                        itemProp.Type = Axlebolt.Bolt.Protobuf.PropertyType.Float;
                                        itemProp.FloatValue = (float)prop.Value.AsDouble;
                                    }
                                    purchasedItem.Properties.Add(prop.Name, itemProp);
                                }
                            }
                            
                            var buyerEvent = new OnPlayerRequestClosedEvent { Request = buyerClosedRequest, Item = purchasedItem };
                            _user.SendResponce(new ResponseMessage 
                            { 
                                EventResponse = new EventResponse 
                                { 
                                    ListenerName = "MarketplaceRemoteEventListener", 
                                    EventName = "onPlayerRequestClosed", 
                                    Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(buyerEvent) } 
                                } 
                            });
                            
                            // ИСПРАВЛЕНИЕ: Отправляем уведомление ПРОДАВЦУ
                            if (StaticClasses.UserServices.TryGetValue(sellerId, out UserService sellerUserService))
                            {
                                float sellerAmount = purchaseResult.Price * (1f - BoltGame.GetMarketplaceSettingsAsync().Result.CommissionPercent);
                                
                                var sellerClosedRequest = new ClosedRequest
                                {
                                    Id = saleId,
                                    OriginId = saleId,
                                    Creator = sellerpb,
                                    ItemDefinitionId = purchaseResult.ItemDefinitionId,
                                    Price = sellerAmount,
                                    CreateDate = DateTime.UtcNow.Ticks,
                                    CloseDate = DateTime.UtcNow.Ticks,
                                    Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest,
                                    Partner = FriendHelper.GetPlayer(buyerId),
                                    PartnerRequestId = requestId.ToString(),
                                    Reason = ClosingReason.SuccessTransaction,
                                    Quantity = 1
                                };
                                
                                var sellerEvent = new OnPlayerRequestClosedEvent { Request = sellerClosedRequest, Item = purchasedItem };
                                sellerUserService.SendResponce(new ResponseMessage 
                                { 
                                    EventResponse = new EventResponse 
                                    { 
                                        ListenerName = "MarketplaceRemoteEventListener", 
                                        EventName = "onPlayerRequestClosed", 
                                        Params = { new ToByteMethod(typeof(OnPlayerRequestClosedEvent)).ToBytes(sellerEvent) } 
                                    } 
                                });
                                
                                // КРИТИЧНО: Отправляем продавцу ТАКЖЕ onTradeRequestClosed чтобы убрать из "Только мои запросы"
                                var sellerTradeClosedEvent = new OnTradeRequestClosedEvent { Request = sellerClosedRequest };
                                sellerUserService.SendResponce(new ResponseMessage 
                                { 
                                    EventResponse = new EventResponse 
                                    { 
                                        ListenerName = "MarketplaceRemoteEventListener", 
                                        EventName = "onTradeRequestClosed", 
                                        Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(sellerTradeClosedEvent) } 
                                    } 
                                });
                                
                                Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent onPlayerRequestClosed AND onTradeRequestClosed to seller {sellerId} - запрос должен исчезнуть из списка");
                            }
                            else
                            {
                                Console.WriteLine($"[MarketplaceRemoteService] ⚠️ Seller {sellerId} is offline, cannot send real-time notification");
                            }
                            
                            // ИСПРАВЛЕНИЕ: Отправляем onTradeRequestClosed всем пользователям для ЗАПРОСА НА ПРОДАЖУ
                            var saleClosedRequest = new ClosedRequest
                            {
                                Id = saleId,
                                OriginId = saleId,
                                Creator = sellerpb,
                                ItemDefinitionId = purchaseResult.ItemDefinitionId,
                                Price = purchaseResult.Price,
                                CreateDate = DateTime.UtcNow.Ticks,
                                CloseDate = DateTime.UtcNow.Ticks,
                                Type = Axlebolt.Bolt.Protobuf.MarketRequestType.SaleRequest,
                                Partner = FriendHelper.GetPlayer(buyerId),
                                PartnerRequestId = requestId.ToString(),
                                Reason = ClosingReason.SuccessTransaction,
                                Quantity = 1
                            };
                            
                            OnTradeRequestClosedEvent saleClosedEvent = new OnTradeRequestClosedEvent { Request = saleClosedRequest };
                            EventResponse saleClosedResp = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeRequestClosed", 
                                Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(saleClosedEvent) } 
                            };
                            
                            // Отправляем покупателю напрямую чтобы убрать предложение из списка
                            _user.SendResponce(new ResponseMessage { EventResponse = saleClosedResp });
                            
                            // Отправляем всем остальным пользователям
                            BroadcastMarketplaceEvent(saleClosedResp, buyerId);
                            
                            Console.WriteLine($"[MarketplaceRemoteService] 📢 Broadcasted sale closure for {saleId} to all users - предложение должно исчезнуть");
                            
                            // КРИТИЧНО: ОБНОВЛЕНИЕ СЧЕТЧИКА "X ПРЕДЛОЖЕНИЙ" - отправляем onTradeUpdated после КАЖДОЙ покупки
                            var activeSalesNow = BoltGame.GetActiveMarketplaceRequestsByItem(purchaseResult.ItemDefinitionId, 0, 100);
                            var activePurchasesNow = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = purchaseResult.ItemDefinitionId });
                            
                            var tradeUpdateEvent = new OnTradeUpdatedEvent
                            {
                                Trade = new Trade
                                {
                                    Id = purchaseResult.ItemDefinitionId,
                                    SalesCount = activeSalesNow.Count,
                                    SalesPrice = activeSalesNow.Count > 0 ? activeSalesNow.Min(r => r.price) : 0,
                                    PurchasesCount = activePurchasesNow.Sum(r => r.Quantity),
                                    PurchasesPrice = activePurchasesNow.Length > 0 ? activePurchasesNow.Max(r => r.Price) : 0
                                }
                            };
                            
                            EventResponse tradeUpdateResp = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeUpdated", 
                                Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdateEvent) } 
                            };
                            
                            // Отправляем покупателю
                            _user.SendResponce(new ResponseMessage { EventResponse = tradeUpdateResp });
                            
                            // Отправляем всем остальным
                            BroadcastMarketplaceEvent(tradeUpdateResp, buyerId);
                            
                            Console.WriteLine($"[MarketplaceRemoteService] 🔄 UPDATED TRADE COUNTER: {activeSalesNow.Count} sales remaining (was {activeSalesNow.Count + 1})");
                            
                            // ОБНОВЛЕНИЕ СЧЕТЧИКА: Если еще остались предметы для покупки, отправляем обновленный запрос
                            if (remainingQuantity > 0)
                            {
                                var updatedRequestDoc = BoltGame.GetMarketplaceRequest(requestId);
                                if (updatedRequestDoc != null)
                                {
                                    var updatedPurchaseRequest = await updatedRequestDoc.ToProto();
                                    // Количество берется из базы данных, не нужно переопределять
                                    
                                    var onPlayerRequestOpenedEvent = new OnPlayerRequestOpenedEvent { Request = updatedPurchaseRequest };
                                    _user.SendResponce(new ResponseMessage 
                                    { 
                                        EventResponse = new EventResponse 
                                        { 
                                            ListenerName = "MarketplaceRemoteEventListener", 
                                            EventName = "onPlayerRequestOpened", 
                                            Params = { new ToByteMethod(typeof(OnPlayerRequestOpenedEvent)).ToBytes(onPlayerRequestOpenedEvent) } 
                                        } 
                                    });
                                    Console.WriteLine($"[MarketplaceRemoteService] 📊 Updated purchase request counter: {updatedRequestDoc.quantity} items remaining");
                                }
                            }
                            
                            Console.WriteLine($"[MarketplaceRemoteService] ✅ Auto-matched purchase completed: buyer={buyerId}, seller={purchaseResult.SellerId}, item={purchaseResult.ItemDefinitionId}, price={purchaseResult.Price}");
                        }
                        catch (System.Exception ex)
                        {
                            Console.WriteLine($"[MarketplaceRemoteService] Failed to process auto-matched purchase {saleId}: {ex.Message}");
                            
                            // ИСПРАВЛЕНИЕ: Если покупка не удалась из-за недостатка средств, отменяем запрос на покупку
                            if (ex.Message.Contains("Not enough funds") || ex.Message.Contains("insufficient funds"))
                            {
                                try
                                {
                                    await BoltGame.CancelPurchaseRequestDueToInsufficientFunds(requestId);
                                    Console.WriteLine($"[MarketplaceRemoteService] ✅ Canceled purchase request {requestId} due to insufficient funds during auto-match");
                                    
                                    // Отправляем событие об отмене запроса на покупку
                                    var canceledRequest = new ClosedRequest
                                    {
                                        Id = requestId.ToString(),
                                        OriginId = requestId.ToString(),
                                        Creator = FriendHelper.GetPlayer(buyerId),
                                        ItemDefinitionId = args.ItemDefinitionId,
                                        Price = args.Price,
                                        CreateDate = DateTime.UtcNow.Ticks,
                                        CloseDate = DateTime.UtcNow.Ticks,
                                        Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                                        Partner = null,
                                        PartnerRequestId = "",
                                        Reason = ClosingReason.NotEnoughFunds,
                                        Quantity = args.Quantity
                                    };
                                    
                                    OnTradeRequestClosedEvent canceledEvent = new OnTradeRequestClosedEvent { Request = canceledRequest };
                                    _user.SendResponce(new ResponseMessage 
                                    { 
                                        EventResponse = new EventResponse 
                                        { 
                                            ListenerName = "MarketplaceRemoteEventListener", 
                                            EventName = "onTradeRequestClosed", 
                                            Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(canceledEvent) } 
                                        } 
                                    });
                                    
                                    BroadcastMarketplaceEvent(new EventResponse 
                                    { 
                                        ListenerName = "MarketplaceRemoteEventListener", 
                                        EventName = "onTradeRequestClosed", 
                                        Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(canceledEvent) } 
                                    }, buyerId);
                                    
                                    break; // Прерываем цикл покупок
                                }
                                catch (System.Exception cancelEx)
                                {
                                    Console.WriteLine($"[MarketplaceRemoteService] ❌ Failed to cancel purchase request after insufficient funds error: {cancelEx.Message}");
                                }
                            }
                        }
                    }
                    
                    Console.WriteLine($"[MarketplaceRemoteService] ✅ Purchase request {requestId} processed {purchasedCount}/{matchedSaleIds.Count()} auto-matched sales");
                    
                    // ИСПРАВЛЕНИЕ: Проверяем, был ли запрос на покупку полностью выполнен
                    var updatedRequest = BoltGame.GetMarketplaceRequest(requestId);
                    if (updatedRequest == null || (int)updatedRequest.status == (int)MarketplaceRequestStatus.Sold || remainingQuantity == 0)
                    {
                        // Запрос полностью выполнен - отправляем onTradeRequestClosed чтобы убрать табличку
                        var purchaseClosedRequest = new ClosedRequest
                        {
                            Id = requestId.ToString(),
                            OriginId = requestId.ToString(),
                            Creator = FriendHelper.GetPlayer(buyerId),
                            ItemDefinitionId = args.ItemDefinitionId,
                            Price = args.Price,
                            CreateDate = DateTime.UtcNow.Ticks,
                            CloseDate = DateTime.UtcNow.Ticks,
                            Type = Axlebolt.Bolt.Protobuf.MarketRequestType.PurchaseRequest,
                            Partner = FriendHelper.GetPlayer(buyerId),
                            PartnerRequestId = "",
                            Reason = ClosingReason.SuccessTransaction,
                            Quantity = purchasedCount
                        };
                        
                        OnTradeRequestClosedEvent purchaseClosedEvent = new OnTradeRequestClosedEvent { Request = purchaseClosedRequest };
                        EventResponse purchaseClosedResp = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeRequestClosed", 
                            Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(purchaseClosedEvent) } 
                        };
                        BroadcastMarketplaceEvent(purchaseClosedResp, null);
                        
                        // Отправляем покупателю тоже чтобы убрать табличку "Ваш запрос на покупку"
                        _user.SendResponce(new ResponseMessage 
                        { 
                            EventResponse = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onTradeRequestClosed", 
                                Params = { new ToByteMethod(typeof(OnTradeRequestClosedEvent)).ToBytes(purchaseClosedEvent) } 
                            } 
                        });
                        
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted onTradeRequestClosed for fully completed purchase request {requestId} - табличка должна исчезнуть");
                        
                        // КРИТИЧНО: Отправляем onTradeUpdated чтобы обновить счетчик "Запросов на покупку X шт."
                        var finalActivePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = args.ItemDefinitionId });
                        var finalActiveSaleRequests = BoltGame.GetActiveMarketplaceRequestsByItem(args.ItemDefinitionId, 0, 100);
                        
                        OnTradeUpdatedEvent finalTradeUpdate = new OnTradeUpdatedEvent
                        {
                            Trade = new Trade
                            {
                                Id = args.ItemDefinitionId,
                                SalesCount = finalActiveSaleRequests.Count,
                                SalesPrice = finalActiveSaleRequests.Count > 0 ? finalActiveSaleRequests.Min(r => r.price) : 0,
                                PurchasesCount = finalActivePurchaseRequests.Sum(r => r.Quantity),
                                PurchasesPrice = finalActivePurchaseRequests.Length > 0 ? finalActivePurchaseRequests.Max(r => r.Price) : 0
                            }
                        };
                        
                        EventResponse finalTradeUpdateResp = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeUpdated", 
                            Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(finalTradeUpdate) } 
                        };
                        
                        // Отправляем покупателю
                        _user.SendResponce(new ResponseMessage { EventResponse = finalTradeUpdateResp });
                        
                        // Отправляем всем остальным
                        BroadcastMarketplaceEvent(finalTradeUpdateResp, buyerId);
                        
                        Console.WriteLine($"[MarketplaceRemoteService] 🔄 FINAL UPDATE: Purchases count = {finalActivePurchaseRequests.Sum(r => r.Quantity)} - табличка 'Запросов на покупку' должна обновиться");
                    }
                    else
                    {
                        // Запрос частично выполнен - отправляем onTradeUpdated с обновленным количеством
                        var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = args.ItemDefinitionId });
                        var activeSaleRequests = BoltGame.GetActiveMarketplaceRequestsByItem(args.ItemDefinitionId, 0, 100);
                        
                        // ИСПРАВЛЕНИЕ: Отправляем onTradeRequestOpened для частично выполненного запроса ВСЕМ (включая покупателя)
                        var updatedPurchaseRequest = await updatedRequest.ToProto();
                        
                        // Сначала отправляем покупателю onPlayerRequestOpened с обновленным запросом
                        var onPlayerRequestOpenedEvent = new OnPlayerRequestOpenedEvent { Request = updatedPurchaseRequest };
                        _user.SendResponce(new ResponseMessage 
                        { 
                            EventResponse = new EventResponse 
                            { 
                                ListenerName = "MarketplaceRemoteEventListener", 
                                EventName = "onPlayerRequestOpened", 
                                Params = { new ToByteMethod(typeof(OnPlayerRequestOpenedEvent)).ToBytes(onPlayerRequestOpenedEvent) } 
                            } 
                        });
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Sent updated onPlayerRequestOpened to buyer {buyerId} for partially completed request {requestId}");
                        
                        // Затем отправляем всем (кроме покупателя) onTradeRequestOpened
                        EventResponse broadcastOpenedEvent = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeRequestOpened", 
                            Params = { new ToByteMethod(typeof(OnTradeRequestOpenedEvent)).ToBytes(new OnTradeRequestOpenedEvent { Request = updatedPurchaseRequest }) } 
                        };
                        BroadcastMarketplaceEvent(broadcastOpenedEvent, buyerId);
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted onTradeRequestOpened for partially completed purchase request {requestId}");
                        
                        OnTradeUpdatedEvent tradeUpdatedEvent = new OnTradeUpdatedEvent
                        {
                            Trade = new Trade
                            {
                                Id = args.ItemDefinitionId,
                                SalesCount = activeSaleRequests.Count,
                                SalesPrice = activeSaleRequests.Count > 0 ? activeSaleRequests.Min(r => r.price) : 0,
                                PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity),
                                PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0
                            }
                        };

                        EventResponse tradeUpdatedBroadcast = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeUpdated", 
                            Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } 
                        };
                        BroadcastMarketplaceEvent(tradeUpdatedBroadcast, null);
                        Console.WriteLine($"[MarketplaceRemoteService] ✅ Broadcasted onTradeUpdated for partially completed purchase request {requestId}, remaining quantity: {updatedRequest.quantity}");
                    }
                }
                else
                {
                    // No matches - broadcast to all users
                    EventResponse broadcastEvent = new EventResponse 
                    { 
                        ListenerName = "MarketplaceRemoteEventListener", 
                        EventName = "onTradeRequestOpened", 
                        Params = { new ToByteMethod(typeof(OnTradeRequestOpenedEvent)).ToBytes(new OnTradeRequestOpenedEvent { Request = purchaseRequest }) } 
                    };
                    BroadcastMarketplaceEvent(broadcastEvent, buyerId);

                    // Send onTradeUpdated to update purchase counts
                    var activePurchaseRequests = await BoltGame.GetTradeOpenPurchaseRequests(new GetTradeOpenPurchaseRequestsArgs { Id = args.ItemDefinitionId });
                    var activeSaleRequests = BoltGame.GetActiveMarketplaceRequestsByItem(args.ItemDefinitionId, 0, 100);
                    
                    OnTradeUpdatedEvent tradeUpdatedEvent = new OnTradeUpdatedEvent
                    {
                        Trade = new Trade
                        {
                            Id = args.ItemDefinitionId,
                            SalesCount = activeSaleRequests.Count,
                            SalesPrice = activeSaleRequests.Count > 0 ? activeSaleRequests.Min(r => r.price) : 0,
                            PurchasesCount = activePurchaseRequests.Sum(r => r.Quantity),
                            PurchasesPrice = activePurchaseRequests.Length > 0 ? activePurchaseRequests.Max(r => r.Price) : 0
                        }
                    };

                    _user.SendResponce(new ResponseMessage 
                    { 
                        EventResponse = new EventResponse 
                        { 
                            ListenerName = "MarketplaceRemoteEventListener", 
                            EventName = "onTradeUpdated", 
                            Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } 
                        } 
                    });

                    EventResponse tradeUpdatedBroadcast = new EventResponse 
                    { 
                        ListenerName = "MarketplaceRemoteEventListener", 
                        EventName = "onTradeUpdated", 
                        Params = { new ToByteMethod(typeof(OnTradeUpdatedEvent)).ToBytes(tradeUpdatedEvent) } 
                    };
                    BroadcastMarketplaceEvent(tradeUpdatedBroadcast, buyerId);

                    Console.WriteLine($"[MarketplaceRemoteService] ✅ Purchase request created: {requestId} for item {args.ItemDefinitionId} at max price {args.Price} x{args.Quantity}");
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in createPurchaseRequest: {ex.Message}");
                SendError(guid, ex.Message.Contains("Not enough funds") ? 402 : 500);
            }
        }

        protected async void getTradeOpenPurchaseRequests(BinaryValue[] values, string guid)
        {
            try
            {
                GetTradeOpenPurchaseRequestsArgs args = (GetTradeOpenPurchaseRequestsArgs)new FromByteMethod(typeof(GetTradeOpenPurchaseRequestsArgs)).FromBytes(values[0]);
                var BoltGame = BoltGameDatabaseProvider.Instance;
                
                // Get purchase requests from database
                OpenRequest[] requests = await BoltGame.GetTradeOpenPurchaseRequests(args);
                
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(OpenRequest[])).ToBytes(requests)
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[MarketplaceRemoteService] Error in getTradeOpenPurchaseRequests: {ex}");
                SendError(guid, 500);
            }
        }

        public override void Invoke(RpcRequest request)
        {
            if (string.IsNullOrEmpty(request.MethodName)) return;
            string method = request.MethodName.ToLower();

            if (method == "gettrades") getTrades(request.Params.ToArray(), request.Id);
            else if (method == "gettrade") getTrade(request.Params.ToArray(), request.Id);
            else if (method == "gettradeopensalerequests") getTradeOpenSaleRequests(request.Params.ToArray(), request.Id);
            else if (method == "gettradeopenpurchaserequests") getTradeOpenPurchaseRequests(request.Params.ToArray(), request.Id);
            else if (method == "getplayerclosedrequests") getPlayerClosedRequests(request.Params.ToArray(), request.Id);
            else if (method == "getplayerclosedrequestscount") getPlayerClosedRequestsCount(request.Params.ToArray(), request.Id);
            else if (method == "createsalerequest") createSaleRequest(request.Params.ToArray(), request.Id);
            else if (method == "createsale") createSale(request.Params.ToArray(), request.Id);
            else if (method == "createpurchaserequestbysale") createPurchaseRequestBySale(request.Params.ToArray(), request.Id);
            else if (method == "createpurchaserequest") createPurchaseRequest(request.Params.ToArray(), request.Id);
            else if (method == "cancelrequest") cancelRequest(request.Params.ToArray(), request.Id);
            else if (method == "getmarketplacesettings") getMarketplaceSettings(request.Params.ToArray(), request.Id);
            else if (method == "getplayerprocessingrequest" || method == "getplayerprocessingrequests") getPlayerProcessingRequests(request.Params.ToArray(), request.Id);
            else if (method == "getplayeropenrequests") getPlayerOpenRequests(request.Params.ToArray(), request.Id);
            else _user.SendResponce(new ResponseMessage { RpcResponse = { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
                    { 
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
                        Code = code
                    }
                }
            });
        }
    }
}
