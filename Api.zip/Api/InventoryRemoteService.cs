using Axlebolt.RpcSupport.Protobuf;
using System.Runtime.InteropServices;
using Amazon.Runtime.Internal.Transform;
using System;
using System.Collections.Generic;
using StandRiseServer.MongoDB.Game;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using Axlebolt.Bolt.Protobuf;
using System.Linq;
using MongoDB.Bson;
using static System.Enum;
using StandRiseServer.RpcServer.Helpers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Net;
using System.Threading.Tasks;

namespace StandRiseServer.RpcServer.Api
{



	public class InventoryRemoteService : RpcClass
	{
		public InventoryRemoteService(UserService user) : base(user) { }

		protected void GetInventoryItemDefinitions(BinaryValue[] values, string guid)
		{
			try
			{
				if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
				{
					BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
					if (boltGame == null)
					{
						Console.WriteLine("[Inventory] Error: BoltGameDatabaseProvider.Instance is null");
						SendError(guid, 500);
						return;
					}

					List<BoltInventoryItemDefinitionDocument> definitions = boltGame.GetAllItemDefinitionsByType(0);
					if (definitions == null)
					{
						Console.WriteLine("[Inventory] Error: definitions from database is null");
						SendError(guid, 500);
						return;
					}

					string gameVersion = "";
					if (StaticClasses.PlayersStatus.TryGetValue(Id, out var status))
						gameVersion = status?.playInGame?.gameVersion ?? "";

					var query = definitions.Where(d => d.key > 0).GroupBy(d => d.key).Select(g => g.First());

					// Ограничение на коллекцию Revival удалено

					var uniqueDefinitions = query
						.Select(a => a.GetInventoryItemDefinition())
						.ToArray();

					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(InventoryItemDefinition[])).ToBytes(uniqueDefinitions) } });
					return;
				}
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
			}
			catch (System.Exception ex)
			{
				Console.WriteLine($"[Inventory] Error in GetInventoryItemDefinitions: {ex.Message}\n{ex.StackTrace}");
				SendError(guid, 500);
			}
		}

		protected void GetInventoryItemPropertyDefinitions(BinaryValue[] values, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
				List<BoltInventoryItemPropertyDefinitionsDocument> definitions = boltGame.GetAllItemPropertyDefinitions();
				InventoryItemPropertyDefinitions[] inventoryItemPropertyDefinitions = definitions.Select(a => a.GetInventoryItemPropertyDefinitions()).ToArray();
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(InventoryItemPropertyDefinitions[])).ToBytes(inventoryItemPropertyDefinitions) } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}

		protected void GetPlayerInventory(BinaryValue[] values, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
				PlayerInventoryDocument playerInventoryDocument = null;
				try
				{
					playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(Id));
				}
				catch (System.Exception)
				{
					boltGame.CreatePlayerInventory(ObjectId.Parse(Id));
					playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(Id));
				}
				PlayerInventory playerInventory = playerInventoryDocument.GetPlayerInventoryProto();
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(PlayerInventory)).ToBytes(playerInventory) } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}
		protected void GetPlayerInventory(string playerId, int[] itemDefinitionIds, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
				PlayerInventoryDocument playerInventoryDocument = boltGame.GetPlayerInventoryDocument(ObjectId.Parse(playerId));
				InventoryItem[] items = playerInventoryDocument.GetInventoryItemsProto(itemDefinitionIds);
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(InventoryItem[])).ToBytes(items) } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}
		protected void ExchangeInventoryItems(RpcRequest request)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
				string recipeCode = (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]);
				Console.WriteLine($"[Inventory] executeRecipe: recipeCode='{recipeCode}', paramsCount={request.Params.Count}");
				int[] items = null;
				try
				{
					if (request.Params.Count > 2 && !request.Params[2].IsNull)
						items = (int[])new FromByteMethod(typeof(int[])).FromBytes(request.Params[2]);
				}
				catch (System.Exception ex) { Console.WriteLine($"[Inventory] Failed to parse items param: {ex.Message}"); }
				RandomGenerator randomGenerator = new RandomGenerator();
				try
				{
					switch (recipeCode)
					{

					case "RECIPE_301":

						{
							// SECURITY: ATOMIC OWNERSHIP VALIDATION
							// Recipe 301 (Exchange) must consume an item.
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0]))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}

							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Origin);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_302":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0]))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Furious);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_303":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0]))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Rival);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_304":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0]))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Fable);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_305":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0], (int)InventoryId.ScorpionCase))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Scorpion);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_306":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0], (int)InventoryId.EmpireCase))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							randomGenerator.AddDropChance(SkinValue.Rare, 53);
							randomGenerator.AddDropChance(SkinValue.Epic, 30);
							randomGenerator.AddDropChance(SkinValue.Legendary, 15);
							randomGenerator.AddDropChance(SkinValue.Arcane, 2);
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							ExchangeResult exchangeResult = new ExchangeResult();
							BoltInventoryItem boltInventoryItem = randomGenerator.GetRandomItem(CollectionId.Empire);
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
	
					case "RECIPE_OPEN_GIFT_501":
						{
							if (items == null || items.Length == 0 || !boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0], 501))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}
							var inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							var giftBoxProperties = boltGameDatabaseProvider.GetInventoryItemDefinition(501, 1)?.properties;
							var containsProperty = giftBoxProperties?.FirstOrDefault(p => p.Name == "contains").Value.AsString;
							var valuesProperty = giftBoxProperties?.FirstOrDefault(p => p.Name == "values").Value.AsString;
							if (containsProperty != null && valuesProperty != null)
							{
								var containsArray = containsProperty.Split(',').Select(int.Parse).ToArray();
								var valuesArray = valuesProperty.Split(',').Select(int.Parse).ToArray();
								for (var i = 0; i < Math.Min(containsArray.Length, valuesArray.Length); i++)
								{
									randomGenerator.AddGiftBox2018DropChance((InventoryId)containsArray[i], valuesArray[i]);
								}
							}
							var nextId = (inventoryDocument.InventoryItems.ElementCount > 0) ? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1 : 1;
							var exchangeResult = new ExchangeResult();
							var boltInventoryItem = randomGenerator.GetRandomGiftBoxItem();
							exchangeResult.InventoryItems.Add(boltInventoryItem.ToInventory(nextId));
							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_DROP_IN_GAME":
					case "RECIPE_DROP_IN_GAME_PRO":
					case "RECIPE_DROP_IN_GAME_RANKED":
					case "RECIPE_DROP_ON_LVL":
					case "RECIPE_DROP_ON_BONUS":
						{
							var dropDecision = DropApiClient.RequestDrop(Id, recipeCode);
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0)
								? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1
								: 1;

							BoltInventoryItem rewardItem = CreateInventoryItem(boltGameDatabaseProvider, dropDecision.ItemDefinitionId);
							ExchangeResult exchangeResult = new ExchangeResult();
							exchangeResult.InventoryItems.Add(rewardItem.ToInventory(nextId));

							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), rewardItem, nextId);

							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
					case "RECIPE_GOOD_GAME_1":
					case "RECIPE_GOOD_GAME_2":
					case "RECIPE_GOOD_GAME_3":
						{
							// SECURITY: GOOD_GAME recipes are called by client after match, but validated via DropApiClient
							// DropApiClient.RequestDrop checks player is in "InGame" or "PostMatch" state
							var dropDecision = DropApiClient.RequestDrop(Id, recipeCode);
							PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							int nextId = (inventoryDocument.InventoryItems.ElementCount > 0)
								? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1
								: 1;

							BoltInventoryItem rewardItem = CreateInventoryItem(boltGameDatabaseProvider, dropDecision.ItemDefinitionId);
							ExchangeResult exchangeResult = new ExchangeResult();
							exchangeResult.InventoryItems.Add(rewardItem.ToInventory(nextId));

							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), rewardItem, nextId);

							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}	
					case "NEW_YEAR_2022_SPIN_ROULETTE":
					case "CURSED_SOULS_SPIN_ROULETTE":
					{
					try
					{
						PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));

						int SPIN_TICKET_ID = 201;

						BsonElement spinTicketElement = default;
						bool foundTicket = false;

						foreach (BsonElement elem in inventoryDocument.InventoryItems)
						{
							if (elem.Value.IsBsonDocument)
							{
								var doc = elem.Value.AsBsonDocument;
								if (doc.Contains("itemDefinitionId") && doc["itemDefinitionId"].AsInt32 == SPIN_TICKET_ID)
								{
									spinTicketElement = elem;
									foundTicket = true;
									break;
								}
							}
						}

						if (!foundTicket)
						{
							Logger.Error($"[Spin] Player {Id} has no spin tickets (ID {SPIN_TICKET_ID}) for recipe {recipeCode}");
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 402 } } });
							return;
						}

						int ticketInventoryId = Convert.ToInt32(spinTicketElement.Name);
						var spinPool = new List<(int itemDefinitionId, double chance)>
						{
							(303,    13.25),
							(304,    13.25),
							(305,    13.25),
							(306,    13.25),
							(1296,   15.0),
							(141600, 15.0),
							(1290,   7.5),
							(5090,   7.5),
							(148000, 2.0),
						};

						double totalChance = spinPool.Sum(x => x.chance);
						double roll = new Random().NextDouble() * totalChance;
						double accumulated = 0.0;
						int wonItemDefinitionId = spinPool[^1].itemDefinitionId;

						foreach (var (itemDefinitionId, chance) in spinPool)
						{
							accumulated += chance;
							if (roll < accumulated)
							{
								wonItemDefinitionId = itemDefinitionId;
								break;
							}
						}

						BoltInventoryItem wonItem = new BoltInventoryItem
						{
							itemDefinitionId = wonItemDefinitionId,
							date = DateTime.Now,
							flags = 0,
							quantity = 1
						};

						int nextId = Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1;

						boltGameDatabaseProvider.RemoveItemToPlayerInventoryDocument(ObjectId.Parse(Id), ticketInventoryId);
						boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), wonItem, nextId);

						try { BoltMainDatabaseProvider.Instance.IncrementSpinTimesExecuted(ObjectId.Parse(Id)); }
						catch { }

						ExchangeResult exchangeResult = new ExchangeResult();
						exchangeResult.InventoryItems.Add(wonItem.ToInventory(nextId));

						Logger.Log($"[Spin] Player {Id} spun ({recipeCode}) and won itemDefinitionId={wonItemDefinitionId}");
						_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
					}
					catch (System.Exception ex)
					{
						Logger.Error($"[Spin] Error processing spin for player {Id}: {ex.Message}\n{ex.StackTrace}");
						_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
					}
					return;
				}

						case "CURSED_SOULS_ROULETTE_10":
					case "CURSED_SOULS_ROULETTE_30":
					case "CURSED_SOULS_ROULETTE_50":
						{
							int rewardTicketId = recipeCode switch {
								"CURSED_SOULS_ROULETTE_10" => 202,
								"CURSED_SOULS_ROULETTE_30" => 203,
								"CURSED_SOULS_ROULETTE_50" => 204,
								_ => 0
							};

							try
							{
								PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));

								BsonElement rewardTicketElement = default;
								bool foundRewardTicket = false;
								foreach (BsonElement elem in inventoryDocument.InventoryItems)
								{
									if (elem.Value.IsBsonDocument)
									{
										var doc = elem.Value.AsBsonDocument;
										if (doc.Contains("itemDefinitionId") && doc["itemDefinitionId"].AsInt32 == rewardTicketId)
										{
											rewardTicketElement = elem;
											foundRewardTicket = true;
											break;
										}
									}
								}

								if (!foundRewardTicket)
								{
									Logger.Error($"[Spin] Player {Id} has no guaranteed reward ticket (ID {rewardTicketId}) for {recipeCode}");
									_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 402 } } });
									return;
								}

								int rewardTicketInventoryId = Convert.ToInt32(rewardTicketElement.Name);

								randomGenerator.AddDropChance(SkinValue.Epic, 50.0);
								randomGenerator.AddDropChance(SkinValue.Legendary, 35.0);
								randomGenerator.AddDropChance(SkinValue.Arcane, 15.0);

								BoltInventoryItem wonItem = randomGenerator.GetRandomItem(CollectionId.Cursed_Souls);
								if (wonItem == null)
									wonItem = randomGenerator.GetRandomItem(CollectionId.Halloween_2020);

								if (wonItem == null)
								{
									Logger.Error($"[Spin] Guaranteed reward fallback failed for player {Id}");
									_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
									return;
								}

								int nextId = Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + 1;

								boltGameDatabaseProvider.RemoveItemToPlayerInventoryDocument(ObjectId.Parse(Id), rewardTicketInventoryId);
								boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), wonItem, nextId);

								ExchangeResult exchangeResult = new ExchangeResult();
								exchangeResult.InventoryItems.Add(wonItem.ToInventory(nextId));

								Logger.Log($"[Spin] Player {Id} claimed guaranteed reward ({recipeCode}): itemDefinitionId={wonItem.itemDefinitionId}");
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							}
							catch (System.Exception ex)
							{
								Logger.Error($"[Spin] Error processing guaranteed reward {recipeCode} for player {Id}: {ex.Message}\n{ex.StackTrace}");
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
							}
							return;
						}

					case "306":
					case "406":
					default:
						{
							// Поддержка форматов: "404", "RECIPE_404"
							string recipeCodeRaw = recipeCode.StartsWith("RECIPE_") ? recipeCode.Substring(7) : recipeCode;
							if (!int.TryParse(recipeCodeRaw, out int recipeKey))
							{
								Console.WriteLine($"[Inventory] Unknown recipe: {recipeCode}");
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}

							Console.WriteLine($"[Inventory] Default handler: recipeKey={recipeKey}, items={items?.Length ?? 0}");
							var itemDef = boltGameDatabaseProvider.GetInventoryItemDefinition(recipeKey, 1);
							Console.WriteLine($"[Inventory] itemDef={itemDef?.displayName ?? "null"}, hasProps={itemDef?.properties != null}");
							if (itemDef?.properties == null)
							{
								Console.WriteLine($"[Inventory] No definition found for recipe key {recipeKey}");
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}

							// Пробуем удалить по inventoryItemId, если не получилось — ищем по itemDefinitionId
							bool removed = false;
							if (items != null && items.Length > 0)
							{
								removed = boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), items[0], recipeKey);
							}

							if (!removed)
							{
								// Ищем предмет в инвентаре по itemDefinitionId (fallback для любого случая)
								var invDoc = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
								var foundItem = invDoc.InventoryItems.FirstOrDefault(i => {
									var bi = i.ToBoltInventory();
									return bi != null && bi.itemDefinitionId == recipeKey;
								});
								if (foundItem.Value != null && int.TryParse(foundItem.Name, out int realInvId))
								{
									removed = boltGameDatabaseProvider.RemoveItemIfOwned(ObjectId.Parse(Id), realInvId, recipeKey);
									Console.WriteLine($"[Inventory] Found by defId: inventoryItemId={realInvId}, defId={recipeKey}, removed={removed}");
								}
							}

							if (!removed)
							{
								Console.WriteLine($"[Inventory] RemoveItemIfOwned failed for recipeKey={recipeKey}, items[0]={items?[0]}");
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
								return;
							}

							// Парсим contains
							string containsStr = itemDef.properties.Contains("contains") ? itemDef.properties["contains"].AsString : null;
							if (string.IsNullOrEmpty(containsStr))
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
								return;
							}

							int[] containsIds = containsStr.Split(',').Select(s => s.Trim()).Where(s => int.TryParse(s, out _)).Select(int.Parse).ToArray();
							if (containsIds.Length == 0)
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
								return;
							}

							double GetProp(string key) {
								if (!itemDef.properties.Contains(key)) return 0;
								var v = itemDef.properties[key];
								return v.IsDouble ? v.AsDouble : v.IsString ? double.Parse(v.AsString, System.Globalization.CultureInfo.InvariantCulture) : 0;
							}

							double p1 = GetProp("p1"), p2 = GetProp("p2"), p3 = GetProp("p3"),
								p4 = GetProp("p4"), p5 = GetProp("p5"), p6 = GetProp("p6");
							double p3st = GetProp("p3_st"), p4st = GetProp("p4_st"), p5st = GetProp("p5_st"), p6st = GetProp("p6_st");

							var chances = new Dictionary<SkinValue, double>();
							if (p1 > 0) chances[SkinValue.Common]    = p1 * 100;
							if (p2 > 0) chances[SkinValue.Uncommon]  = p2 * 100;
							if (p3 > 0) chances[SkinValue.Rare]      = p3 > 1 ? p3 : p3 * 100;
							if (p4 > 0) chances[SkinValue.Epic]      = p4 > 1 ? p4 : p4 * 100;
							if (p5 > 0) chances[SkinValue.Legendary] = p5 > 1 ? p5 : p5 * 100;
							if (p6 > 0) chances[SkinValue.Arcane]    = p6 > 1 ? p6 : p6 * 100;
							if (chances.Count == 0) foreach (var id in containsIds) chances[(SkinValue)id] = 1.0;

							var allDefs = RandomGenerator.definitions ?? boltGameDatabaseProvider.GetAllItemDefinitionsByType(0).ToArray();
							var pool = allDefs.Where(d => containsIds.Contains(d.key)).ToList();
							if (pool.Count == 0)
							{
								_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 500 } } });
								return;
							}

							// Бросок редкости
							var rng = new Random();
							double totalChance = chances.Values.Sum();
							double roll = rng.NextDouble() * totalChance;
							double acc = 0;
							SkinValue rolledRarity = chances.Keys.First();
							foreach (var kv in chances) { acc += kv.Value; if (roll < acc) { rolledRarity = kv.Key; break; } }

							var rarityPool = pool.Where(d => d.GetSkinValue() == rolledRarity).ToList();
							if (rarityPool.Count == 0) rarityPool = pool;
							var chosen = rarityPool[rng.Next(rarityPool.Count)];

							// StatTrak
							double stChance = rolledRarity == SkinValue.Rare ? p3st : rolledRarity == SkinValue.Epic ? p4st :
											rolledRarity == SkinValue.Legendary ? p5st : rolledRarity == SkinValue.Arcane ? p6st : 0;
							bool isStatTrak = stChance > 0 && rng.NextDouble() < stChance;

							var inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
							int nextId = inventoryDocument.InventoryItems.ElementCount > 0
								? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int p) ? p : 0).Max() + 1 : 1;

							var droppedItem = new BoltInventoryItem { itemDefinitionId = chosen.key, quantity = 1, flags = 0, date = BsonDateTime.Create(DateTime.UtcNow) };
							if (isStatTrak) droppedItem.Properties.Add(new BoltInventoryItemProperty { Name = "stattrack_value", Type = BoltInventoryItemProperty.PropertyType.Int, Value = "0" });

							Console.WriteLine($"[Inventory] Recipe {recipeKey}: rolled {rolledRarity}, item={chosen.key} ({chosen.displayName}), statTrak={isStatTrak}");

							boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), droppedItem, nextId);
							var exchangeResult = new ExchangeResult();
							exchangeResult.InventoryItems.Add(droppedItem.ToInventory(nextId));
							_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(ExchangeResult)).ToBytes(exchangeResult) } });
							return;
						}
				}
			}
			catch (DropDeniedRpcException ex)
			{
				Logger.LogWarn($"[Inventory] Drop denied for player {Id}, recipe {recipeCode}: {ex.Message}");
				var exception = new Axlebolt.RpcSupport.Protobuf.Exception
				{
					Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
					Code = 403
				};
				if (!string.IsNullOrEmpty(ex.Message))
					exception.Property.Add("reason", ex.Message);
				_user.SendResponce(new ResponseMessage
				{
					RpcResponse = new RpcResponse
					{
						Id = request.Id,
						Exception = exception
					}
				});
				return;
			}
			catch (System.Exception ex)
			{
				Logger.Error($"[Inventory] executeRecipe failed (player={Id}, recipe={recipeCode}): {ex}");
				_user.SendResponce(new ResponseMessage
				{
					RpcResponse = new RpcResponse
					{
						Id = request.Id,
						Exception = new Axlebolt.RpcSupport.Protobuf.Exception
						{
							Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
							Code = 500
						}
					}
				});
				return;
			}
		}
		else
		{
			_user.SendResponce(new ResponseMessage
			{
				RpcResponse = new RpcResponse
				{
					Id = request.Id,
					Exception = new Axlebolt.RpcSupport.Protobuf.Exception
					{
						Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
						Code = 401
					}
				}
			});
		}
		
		}

		protected void BuyInventoryItem(RpcRequest request)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
				int itemId = (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[0]);
				int quanity = (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[1]);
				int currencyId = (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[2]);
				bool toManyItems = (bool)new FromByteMethod(typeof(bool)).FromBytes(request.Params[3]);
				BoltInventoryItemDefinitionDocument boltInventoryItemDefinitionDocument = boltGameDatabaseProvider.GetInventoryItemDefinition(itemId, 1);
				if (boltInventoryItemDefinitionDocument == null)
				{
					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
					return;
				}

				var priceArray = boltInventoryItemDefinitionDocument.buyPrice;
				var priceDoc = priceArray?.FirstOrDefault(p => p.AsBsonDocument.Contains("currencyId") && p.AsBsonDocument["currencyId"].AsInt32 == currencyId);
				
				if (priceDoc == null && (itemId == 305 || itemId == 306 || itemId == 405 || itemId == 406 || itemId == 702))
				{
					int fallbackPrice = (itemId == 305 || itemId == 306 || itemId == 405 || itemId == 406) ? 100 : 60;
					priceDoc = new BsonDocument { { "currencyId", 102 }, { "value", fallbackPrice } }.ToBsonDocument();
				}

				if (priceDoc == null)
				{
					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 403 } } });
					return;
				}

				double itemPrice = priceDoc.AsBsonDocument["value"].ToDouble();
				double totalCost = itemPrice * quanity;

				boltGameDatabaseProvider.CurrencyMinusValue(ObjectId.Parse(Id), currencyId, totalCost);
				PlayerInventoryDocument inventoryDocument = boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id));
				List<InventoryItem> inventoryItems = new List<InventoryItem>();
				for (int x = 0; x < quanity; x++)
				{
					int nextId = (inventoryDocument.InventoryItems.ElementCount > 0) 
						? Convert.ToInt32(inventoryDocument.InventoryItems.GetElement(inventoryDocument.InventoryItems.ElementCount - 1).Name) + (x + 1)
						: x + 1;
					BoltInventoryItem boltInventoryItem = new BoltInventoryItem { itemDefinitionId = itemId, date = (BsonDateTime)DateTime.Now, flags = 0, quantity = 1 };
					boltGameDatabaseProvider.AddItemToPlayerInventoryDocument(ObjectId.Parse(Id), boltInventoryItem, nextId);
					inventoryItems.Add(boltInventoryItem.ToInventory(nextId));
				}
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(InventoryItem[])).ToBytes(inventoryItems.ToArray()) } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}
		protected void SetInventoryItemFlags(RpcRequest request)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
				ItemFlags itemFlags = (ItemFlags)new FromByteMethod(typeof(ItemFlags)).FromBytes(request.Params[0]);
				foreach (KeyValuePair<int, int> keyValuePair in itemFlags.Flags) boltGameDatabaseProvider.SetItemFlag(ObjectId.Parse(Id), keyValuePair.Key, keyValuePair.Value);
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}
		protected void SetInventoryItemsProperties(RpcRequest request)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
				InventoryItemProperties[] inventoryItemProperties = (InventoryItemProperties[])new FromByteMethod(typeof(InventoryItemProperties[])).FromBytes(request.Params[0]);
				foreach (InventoryItemProperties a in inventoryItemProperties) boltGameDatabaseProvider.SetItemProperties(ObjectId.Parse(Id), a.Id, a.Properties.Select(s => new BoltInventoryItemProperty { Name = s.Key, Type = (BoltInventoryItemProperty.PropertyType)s.Value.Type, Value = s.Value.IntValue.ToString() }).ToArray());
				_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new BinaryValue { IsNull = true } } });
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}

		protected async void ApplyInventoryItem(int? consumedItemId, int? appliedItemId, string appliedPropertyName, bool IsRemovable, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				try
				{
					BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
					PlayerInventoryDocument inventoryDocument = await Task.Run(() => boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id)));
					
					var consumedBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == consumedItemId.ToString());
					var appliedBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == appliedItemId.ToString());
					
					if (consumedBson.Value == null || appliedBson.Value == null)
					{
						SendError(guid, 404);
						return;
					}

					BoltInventoryItem consumedItem = consumedBson.ToBoltInventory();
					BoltInventoryItem appliedItem = appliedBson.ToBoltInventory();

					// Проверяем есть ли уже что-то на этом слоте
					var existingProperty = appliedItem.Properties.FirstOrDefault(p => p.Name == appliedPropertyName);
					if (existingProperty != null)
					{
						// Если IsRemovable (шилд) — возвращаем старый в инвентарь
						if (IsRemovable)
						{
							try
							{
								int oldDefId = int.Parse(existingProperty.Value);
								int nextId = inventoryDocument.InventoryItems.ElementCount > 0
									? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1
									: 1;
								BoltInventoryItem returnedItem = new BoltInventoryItem
								{
									itemDefinitionId = oldDefId,
									quantity = 1,
									flags = 0,
									date = BsonDateTime.Create(DateTime.UtcNow)
								};
								await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), returnedItem, nextId);
							}
							catch (System.Exception ex)
							{
								Logger.Error($"[Inventory] Failed to return old removable item: {ex.Message}");
							}
						}
						// Если наклейка — просто удаляем старую (не возвращаем)
						appliedItem.Properties.Remove(existingProperty);
					}

					appliedItem.Properties.Add(new BoltInventoryItemProperty 
					{ 
						Name = appliedPropertyName, 
						Type = BoltInventoryItemProperty.PropertyType.Int, 
						Value = consumedItem.itemDefinitionId.ToString() 
					});

					// Сохраняем флаг removable чтобы при удалении знать возвращать ли предмет
					appliedItem.Properties.RemoveAll(p => p.Name == appliedPropertyName + "_removable");
					if (IsRemovable)
					{
						appliedItem.Properties.Add(new BoltInventoryItemProperty
						{
							Name = appliedPropertyName + "_removable",
							Type = BoltInventoryItemProperty.PropertyType.Boolean,
							Value = "1"
						});
					}

					await boltGameDatabaseProvider.RemoveItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), consumedItemId.Value);
					await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), appliedItem, appliedItemId.Value);
					
					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(PlayerInventoryItem)).ToBytes(appliedItem.ToPlayerInventoryItem(appliedItemId.Value)) } });
				}
				catch (System.Exception ex)
				{
					Logger.Error($"[Inventory] Error applying items: {ex.Message}");
					SendError(guid, 500);
				}
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}

		protected async void RemoveInventoryItemProperty(int? itemId, string propertyName, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				try
				{
					BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
					PlayerInventoryDocument inventoryDocument = await Task.Run(() => boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id)));
					
					var itemBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == itemId.ToString());
					if (itemBson.Value == null)
					{
						SendError(guid, 404);
						return;
					}

					BoltInventoryItem appliedItem = itemBson.ToBoltInventory();
					var property = appliedItem.Properties.FirstOrDefault(a => a.Name == propertyName);
					var removableFlag = appliedItem.Properties.FirstOrDefault(a => a.Name == propertyName + "_removable");
					
					if (property != null)
					{
						bool isShield = false;

						// Проверяем флаг _removable (установленный при applyInventoryItem)
						if (removableFlag != null)
						{
							isShield = true;
							Logger.Error($"[Inventory] RemoveProperty: found _removable flag → isShield=true");
						}
						else if (int.TryParse(property.Value, out int attachedDefId))
						{
							// Проверяем определение предмета — если properties.shield == true, это шилд
							try
							{
								var itemDef = boltGameDatabaseProvider.GetInventoryItemDefinition(attachedDefId, 1);
								Logger.Error($"[Inventory] RemoveProperty: attachedDefId={attachedDefId}, itemDef={itemDef?.displayName ?? "null"}, props={itemDef?.properties?.ToString() ?? "null"}");
								if (itemDef?.properties != null && itemDef.properties.Contains("shield"))
								{
									var shieldVal = itemDef.properties["shield"];
									isShield = shieldVal.IsBoolean ? shieldVal.AsBoolean : shieldVal.ToString() == "true" || shieldVal.ToString() == "1";
									Logger.Error($"[Inventory] RemoveProperty: shield field found, value={shieldVal}, isShield={isShield}");
								}
							}
							catch (System.Exception ex)
							{
								Logger.Error($"[Inventory] Failed to check item definition for shield: {ex.Message}");
							}
						}
						else
						{
							Logger.Error($"[Inventory] RemoveProperty: property.Value='{property.Value}' is not a valid int, skipping shield check");
						}

						Logger.Error($"[Inventory] RemoveProperty: propertyName={propertyName}, isShield={isShield}, willReturn={isShield || propertyName == "charm"}");

						// Шилд или чарм — возвращаем в инвентарь
						if (isShield || propertyName == "charm")
						{
							try
							{
								int returnDefId = int.Parse(property.Value);
								int nextId = inventoryDocument.InventoryItems.ElementCount > 0 
									? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1 
									: 1;

								BoltInventoryItem returnedItem = new BoltInventoryItem
								{
									itemDefinitionId = returnDefId,
									quantity = 1,
									flags = 0,
									date = BsonDateTime.Create(DateTime.UtcNow)
								};

								await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), returnedItem, nextId);
							}
							catch (System.Exception ex)
							{
								Logger.Error($"[Inventory] Failed to return item during removal: {ex.Message}");
							}
						}
						// Обычный стикер — просто удаляем, не возвращаем

						appliedItem.Properties.Remove(property);
						if (removableFlag != null)
							appliedItem.Properties.Remove(removableFlag);
					}

					await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), appliedItem, itemId.Value);
					
					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(PlayerInventoryItem)).ToBytes(appliedItem.ToPlayerInventoryItem(itemId.Value)) } });
				}
				catch (System.Exception ex)
				{
					Logger.Error($"[Inventory] Error removing item property: {ex.Message}");
					SendError(guid, 500);
				}
				return;
			}
			_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
		}

		protected async void activateCoupon(BinaryValue[] value, string guid)
        {
			ActivateCouponRequest request = null;
			try
			{
				request = (ActivateCouponRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension.GetValue<ActivateCouponRequest>(value, 0);
			}
			catch (System.Exception ex)
			{
				Logger.Error($"[Coupon] Failed to parse ActivateCouponRequest: {ex.Message}");
				SendError(guid, 400);
				return;
			}

			Logger.Log($"[Coupon] activateCoupon called: PlayerId={PlayerId}, CouponId='{request?.CouponId}'");

			try
			{
				string couponId = request.CouponId?.ToUpper();
				if (string.IsNullOrEmpty(couponId))
				{
					Logger.LogWarn($"[Coupon] Empty couponId from player {PlayerId}");
					throw new StandRiseServer.RpcServer.Helpers.ActiveCouponNotFoundRpcException();
				}

				Logger.Log($"[Coupon] Calling ActivateCoupon: couponId={couponId}, playerId={PlayerId}");
				var response = await BoltGameDatabaseProvider.Instance.ActivateCoupon(couponId, PlayerId);
				Logger.Log($"[Coupon] ActivateCoupon succeeded: items={response.InventoryItems.Count}, currencies={response.Currencies.Count}");

				await BoltGameDatabaseProvider.Instance.AddPlayerToCoupon(couponId, PlayerId);
				Logger.Log($"[Coupon] AddPlayerToCoupon done, sending response");

				try
				{
					var gameDb = BoltGameDatabaseProvider.Instance;
					var mainDb = BoltMainDatabaseProvider.Instance;

					foreach (var gameEventDoc in gameDb.GetAllActiveGameEvents())
					{
						if (!gameEventDoc.enabled || gameEventDoc.goldPassItem <= 0)
							continue;

						bool receivedGoldPass = response.InventoryItems.Any(i => i.ItemDefinitionId == gameEventDoc.goldPassItem);
						if (!receivedGoldPass)
							continue;

						Logger.Log($"[GoldPass] Player {PlayerId} received goldPassItem={gameEventDoc.goldPassItem} for event={gameEventDoc.code}");

						try { mainDb.GetGameEvent(ObjectId.Parse(PlayerId)); }
						catch { mainDb.CreatePlayerGameEvent(PlayerId); }

						var retroReward = GamePassRewardHelper.GrantRetroactiveGoldPassRewards(PlayerId, gameEventDoc);
						GamePassRewardHelper.AppendRewardToActivateCouponResponse(response, retroReward);
					}
				}
				catch (System.Exception ex) { Logger.Error($"[GoldPass] Retroactive rewards error: {ex.Message}"); }

				SendResponse(guid, response);
			}
			catch (StandRiseServer.RpcServer.Helpers.CouponHasAlreadyActivatedRpcException)
			{
				Logger.LogWarn($"[Coupon] Already activated: couponId={request?.CouponId}, playerId={PlayerId}");
				SendError(guid, 3317);
			}
			catch (StandRiseServer.RpcServer.Helpers.ActiveCouponNotFoundRpcException)
			{
				Logger.LogWarn($"[Coupon] Not found or expired: couponId={request?.CouponId}, playerId={PlayerId}");
				SendError(guid, 3316);
			}
			catch (StandRiseServer.RpcServer.Helpers.CouponPlatformMismatchRpcException)
			{
				Logger.LogWarn($"[Coupon] Platform mismatch: couponId={request?.CouponId}, playerId={PlayerId}");
				SendError(guid, 3318);
			}
			catch (System.Exception ex)
			{
				Logger.Error($"[Coupon] Unhandled error: couponId={request?.CouponId}, playerId={PlayerId}, error={ex.Message}\nStack: {ex.StackTrace}");
				SendError(guid, 500);
			}
        }
		
		protected void GetPlayerCoupons(string guid)
		{
			try
			{
				var response = BoltGameDatabaseProvider.Instance.GetPlayerCoupons(PlayerId).Result;
				SendResponse(guid, response);
			}
			catch (System.Exception ex)
			{
				Logger.Error($"[Coupon] Error getting player coupons: {ex.Message}");
				SendError(guid, 500);
			}
		}

		protected async void MountInventoryItem(BinaryValue[] values, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				try
				{
					var request = (MountInventoryItemRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension.GetValue<MountInventoryItemRequest>(values, 0);
					Console.WriteLine($"[Inventory] MountInventoryItem called: ConsumedItemId={request.ConsumedItemId}, ModifiedItemId={request.ModifiedItemId}, ModificationName='{request.ModificationName}'");
					BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
					PlayerInventoryDocument inventoryDocument = await Task.Run(() => boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id)));

					// Клиент может передавать либо inventoryItemId, либо itemDefinitionId
					// Сначала пробуем найти по inventoryItemId
					var consumedBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == request.ConsumedItemId.ToString());
					var modifiedBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == request.ModifiedItemId.ToString());

					// Если не нашли consumedItem по inventoryItemId, ищем по itemDefinitionId
					if (consumedBson.Value == null)
					{
						consumedBson = inventoryDocument.InventoryItems.FirstOrDefault(i =>
						{
							var item = i.ToBoltInventory();
							return item != null && item.itemDefinitionId == request.ConsumedItemId;
						});
					}

					if (consumedBson.Value == null || modifiedBson.Value == null)
					{
						Console.WriteLine($"[Inventory] MountInventoryItem: Item not found. ConsumedBson={consumedBson.Value != null}, ModifiedBson={modifiedBson.Value != null}");
						SendError(guid, 404);
						return;
					}

					// Получаем реальный inventoryItemId из найденного bson
					int consumedInventoryItemId = int.TryParse(consumedBson.Name, out int parsedConsumedId) ? parsedConsumedId : request.ConsumedItemId;

					BoltInventoryItem consumedItem = consumedBson.ToBoltInventory();
					BoltInventoryItem modifiedItem = modifiedBson.ToBoltInventory();

					// Check if item already has this modification mounted — if so, unmount the old one first
					PlayerInventoryItem unmountedProto = null;
					var existingProp = modifiedItem.Properties.FirstOrDefault(p => p.Name == request.ModificationName);
					var existingRemovableFlag = modifiedItem.Properties.FirstOrDefault(p => p.Name == request.ModificationName + "_removable");
					if (existingProp != null)
					{
						int oldDefId = int.Parse(existingProp.Value);

						// Проверяем — шилд или стикер
						bool oldIsShield = existingRemovableFlag != null;
						if (!oldIsShield)
						{
							try
							{
								var oldItemDef = boltGameDatabaseProvider.GetInventoryItemDefinition(oldDefId, 1);
								if (oldItemDef?.properties != null && oldItemDef.properties.Contains("shield"))
								{
									var sv = oldItemDef.properties["shield"];
									oldIsShield = sv.IsBoolean ? sv.AsBoolean : sv.ToString() == "true" || sv.ToString() == "1";
								}
							}
							catch { }
						}

						if (oldIsShield)
						{
							int unmountNextId = inventoryDocument.InventoryItems.ElementCount > 0
								? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1
								: 1;

							BoltInventoryItem returnedItem = new BoltInventoryItem
							{
								itemDefinitionId = oldDefId,
								quantity = 1,
								flags = 0,
								date = BsonDateTime.Create(DateTime.UtcNow)
							};

							await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), returnedItem, unmountNextId);
							unmountedProto = returnedItem.ToPlayerInventoryItem(unmountNextId);
						}
						// Стикер — просто удаляем

						modifiedItem.Properties.Remove(existingProp);
						if (existingRemovableFlag != null)
							modifiedItem.Properties.Remove(existingRemovableFlag);
					}

					// Mount the consumed item as a property
					modifiedItem.Properties.Add(new BoltInventoryItemProperty
					{
						Name = request.ModificationName,
						Type = BoltInventoryItemProperty.PropertyType.Int,
						Value = consumedItem.itemDefinitionId.ToString()
					});

					// Remove consumed item and update modified item
					await boltGameDatabaseProvider.RemoveItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), consumedInventoryItemId);
					await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), modifiedItem, request.ModifiedItemId);

					var response = new MountInventoryItemResponse
					{
						ModifiedItem = modifiedItem.ToPlayerInventoryItem(request.ModifiedItemId),
						UnmountedItem = unmountedProto
					};
					SendResponse(guid, response);
				}
				catch (System.Exception ex)
				{
					Logger.Error($"[Inventory] Error mounting inventory item: {ex.Message}");
					SendError(guid, 500);
				}
				return;
			}
			SendError(guid, 401);
		}

		protected async void UnmountInventoryItem(BinaryValue[] values, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				try
				{
					var request = (UnmountInventoryItemRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension.GetValue<UnmountInventoryItemRequest>(values, 0);
					BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
					PlayerInventoryDocument inventoryDocument = await Task.Run(() => boltGameDatabaseProvider.GetPlayerInventoryDocument(ObjectId.Parse(Id)));

					var modifiedBson = inventoryDocument.InventoryItems.FirstOrDefault(i => i.Name == request.ModifiedItemId.ToString());
					if (modifiedBson.Value == null)
					{
						SendError(guid, 404);
						return;
					}

					BoltInventoryItem modifiedItem = modifiedBson.ToBoltInventory();
					var property = modifiedItem.Properties.FirstOrDefault(p => p.Name == request.ModificationName);
					var removableFlag = modifiedItem.Properties.FirstOrDefault(p => p.Name == request.ModificationName + "_removable");

					PlayerInventoryItem unmountedProto = null;
					if (property != null)
					{
						int attachedDefId = int.Parse(property.Value);

						// Определяем — шилд или стикер
						bool isShield = removableFlag != null;
						if (!isShield)
						{
							try
							{
								var itemDef = boltGameDatabaseProvider.GetInventoryItemDefinition(attachedDefId, 1);
								if (itemDef?.properties != null && itemDef.properties.Contains("shield"))
								{
									var shieldVal = itemDef.properties["shield"];
									isShield = shieldVal.IsBoolean ? shieldVal.AsBoolean : shieldVal.ToString() == "true" || shieldVal.ToString() == "1";
								}
							}
							catch (System.Exception ex)
							{
								Logger.Error($"[Inventory] UnmountInventoryItem: failed to check shield: {ex.Message}");
							}
						}

						Logger.Error($"[Inventory] UnmountInventoryItem: modName={request.ModificationName}, defId={attachedDefId}, isShield={isShield}");

						if (isShield)
						{
							// Шилд — возвращаем в инвентарь
							int nextId = inventoryDocument.InventoryItems.ElementCount > 0
								? inventoryDocument.InventoryItems.Select(i => int.TryParse(i.Name, out int parsed) ? parsed : 0).Max() + 1
								: 1;

							BoltInventoryItem returnedItem = new BoltInventoryItem
							{
								itemDefinitionId = attachedDefId,
								quantity = 1,
								flags = 0,
								date = BsonDateTime.Create(DateTime.UtcNow)
							};

							await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), returnedItem, nextId);
							unmountedProto = returnedItem.ToPlayerInventoryItem(nextId);
						}
						// Стикер — просто удаляем, не возвращаем

						modifiedItem.Properties.Remove(property);
						if (removableFlag != null)
							modifiedItem.Properties.Remove(removableFlag);
					}

					// Update the modified item without the property
					await boltGameDatabaseProvider.AddItemToPlayerInventoryDocumentAsync(ObjectId.Parse(Id), modifiedItem, request.ModifiedItemId);

					var response = new UnmountInventoryItemResponse
					{
						UnmountedItem = unmountedProto
					};
					SendResponse(guid, response);
				}
				catch (System.Exception ex)
				{
					Logger.Error($"[Inventory] Error unmounting inventory item: {ex.Message}");
					SendError(guid, 500);
				}
				return;
			}
			SendError(guid, 401);
		}

		protected void getRecipeStatus(BinaryValue[] values, string guid)
		{
			if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
			{
				string recipeCode = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
				BoltGameDatabaseProvider boltGameDatabaseProvider = BoltGameDatabaseProvider.Instance;
				
				GetRecipeStatusResponse response = new GetRecipeStatusResponse
				{
					ExecutionIntervalOk = true,
					ExecutionTimingOk = true,
					TimesExecutedTotal = 0
				};

				// For spin roulette, count how many times the player has spun
				if (recipeCode == "CURSED_SOULS_SPIN_ROULETTE")
				{
					// Count spin executions from player's spin history or use a counter
					// For now, we'll return 0 as the client will track spins via inventory items
					response.TimesExecutedTotal = 0;
				}

				_user.SendResponce(new ResponseMessage 
				{ 
					RpcResponse = new RpcResponse 
					{ 
						Id = guid, 
						Return = new ToByteMethod(typeof(GetRecipeStatusResponse)).ToBytes(response)
					} 
				});
			}
			else
			{
				_user.SendResponce(new ResponseMessage 
				{ 
					RpcResponse = new RpcResponse 
					{ 
						Id = guid, 
						Exception = new Axlebolt.RpcSupport.Protobuf.Exception 
						{ 
							Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), 
							Code = 401 
						} 
					} 
				});
			}
		}

		public override void Invoke(RpcRequest request)
		{
			try
			{
				string methodName = request.MethodName;
				Console.WriteLine($"[Inventory] Invoke: {methodName}");

				// Список методов, требующих валидацию токена (критичные операции)
				string[] tokenRequiredMethods = new string[] 
				{
					"exchangeInventoryItems",
					"consumeInventoryItems", 
					"executeRecipe",
					"buyInventoryItem",
					"buyInventoryItems",
					"setInventoryItemFlags",
					"setInventoryItemsProperties",
					"activateCoupon",
					"applyInventoryItem",
					"removeInventoryItemProperty",
					"mountInventoryItem",
					"unmountInventoryItem"
				};

				// Проверяем токен для критичных операций
				if (Array.Exists(tokenRequiredMethods, m => methodName.Equals(m, StringComparison.OrdinalIgnoreCase)))
				{
					if (!ValidateRequestToken(request, out string errorMessage))
					{
						SendTokenValidationError(request.Id, errorMessage);
						return;
					}
				}

				if (methodName.Equals("getPlayerInventory", StringComparison.OrdinalIgnoreCase)) GetPlayerInventory(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("getInventoryItemPropertyDefinitions", StringComparison.OrdinalIgnoreCase)) GetInventoryItemPropertyDefinitions(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("getInventoryItemDefinitions", StringComparison.OrdinalIgnoreCase)) GetInventoryItemDefinitions(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("exchangeInventoryItems", StringComparison.OrdinalIgnoreCase) || methodName.Equals("consumeInventoryItems", StringComparison.OrdinalIgnoreCase) || methodName.Equals("executeRecipe", StringComparison.OrdinalIgnoreCase)) ExchangeInventoryItems(request);
				else if (methodName.Equals("buyInventoryItem", StringComparison.OrdinalIgnoreCase) || methodName.Equals("buyInventoryItems", StringComparison.OrdinalIgnoreCase)) BuyInventoryItem(request);
				else if (methodName.Equals("setInventoryItemFlags", StringComparison.OrdinalIgnoreCase)) SetInventoryItemFlags(request);
				else if (methodName.Equals("setInventoryItemsProperties", StringComparison.OrdinalIgnoreCase)) SetInventoryItemsProperties(request);
				else if (methodName.Equals("activateCoupon", StringComparison.OrdinalIgnoreCase)) activateCoupon(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("getPlayerCoupons", StringComparison.OrdinalIgnoreCase)) GetPlayerCoupons(request.Id);
				else if (methodName.Equals("applyInventoryItem", StringComparison.OrdinalIgnoreCase)) ApplyInventoryItem((int?)new FromByteMethod(typeof(int?)).FromBytes(request.Params[0]), (int?)new FromByteMethod(typeof(int?)).FromBytes(request.Params[1]), (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[2]), (bool)new FromByteMethod(typeof(bool)).FromBytes(request.Params[3]), request.Id);
				else if (methodName.Equals("removeInventoryItemProperty", StringComparison.OrdinalIgnoreCase)) RemoveInventoryItemProperty((int?)new FromByteMethod(typeof(int?)).FromBytes(request.Params[0]), (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[1]), request.Id);
				else if (methodName.Equals("getOtherPlayerItems", StringComparison.OrdinalIgnoreCase)) GetPlayerInventory((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), (int[])new FromByteMethod(typeof(int[])).FromBytes(request.Params[1]), request.Id);
				else if (methodName.Equals("mountInventoryItem", StringComparison.OrdinalIgnoreCase)) MountInventoryItem(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("unmountInventoryItem", StringComparison.OrdinalIgnoreCase)) UnmountInventoryItem(request.Params.ToArray(), request.Id);
				else if (methodName.Equals("getRecipeStatus", StringComparison.OrdinalIgnoreCase)) getRecipeStatus(request.Params.ToArray(), request.Id);

				else 
				{
					Console.WriteLine($"[Inventory] Error: Method not found: {methodName}");
					_user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 404 } } });
				}
			}
			catch (System.Exception ex)
			{
				Console.WriteLine($"[Inventory] Critical error in Invoke ({request.MethodName}): {ex.Message}\n{ex.StackTrace}");
				SendError(request.Id, 500);
			}
		}

		private static BoltInventoryItem CreateInventoryItem(BoltGameDatabaseProvider databaseProvider, int itemDefinitionId)
		{
			if (itemDefinitionId <= 0)
			{
				throw new DropDeniedRpcException($"Invalid item definition id: {itemDefinitionId}");
			}

			var definition = databaseProvider.GetInventoryItemDefinition(itemDefinitionId, 1);
			if (definition == null)
			{
				throw new DropDeniedRpcException($"Item definition not found: {itemDefinitionId}");
			}

			var item = new BoltInventoryItem
			{
				itemDefinitionId = itemDefinitionId,
				quantity = 1,
				flags = 0,
				date = BsonDateTime.Create(DateTime.UtcNow)
			};

			if (definition.IsStattrack())
			{
				item.Properties.Add(new BoltInventoryItemProperty
				{
					Name = "stattrack_value",
					Type = BoltInventoryItemProperty.PropertyType.Int,
					Value = "0"
				});
			}

			return item;
		}
	}

	internal static class DropApiClient
	{
		private const string DefaultBaseUrl = "http://127.0.0.1:2223";
		private static readonly HttpClient HttpClient = new HttpClient
		{
			Timeout = TimeSpan.FromSeconds(5)
		};
		private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true
		};

		internal static DropDecision RequestDrop(string playerId, string recipeCode)
		{
			if (string.IsNullOrEmpty(playerId))
			{
				throw new DropDeniedRpcException("PlayerId is required");
			}

			var requestPayload = new DropApiRequest
			{
				PlayerId = playerId,
				RecipeCode = recipeCode
			};

			string baseUrl = Environment.GetEnvironmentVariable("DROP_API_BASE_URL") ?? DefaultBaseUrl;
			string endpoint = baseUrl.TrimEnd('/') + "/api/drop/evaluate";
			string body = JsonSerializer.Serialize(requestPayload, JsonOptions);
			var content = new StringContent(body, Encoding.UTF8, "application/json");

			HttpResponseMessage response;
			try
			{
				response = HttpClient.PostAsync(endpoint, content).GetAwaiter().GetResult();
			}
			catch (TaskCanceledException ex)
			{
				throw new DropDeniedRpcException($"Drop API timeout: {ex.Message}");
			}
			catch (HttpRequestException ex)
			{
				throw new DropDeniedRpcException($"Drop API unreachable: {ex.Message}");
			}

			string responseText = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
			if (response.StatusCode == HttpStatusCode.OK)
			{
				var apiResponse = JsonSerializer.Deserialize<DropApiResponse>(responseText, JsonOptions);
				if (apiResponse == null || apiResponse.ItemDefinitionId <= 0)
				{
					throw new DropDeniedRpcException("Drop API returned invalid payload");
				}
				return new DropDecision(apiResponse.ItemDefinitionId);
			}

			string reason = ExtractReason(responseText);
			if (response.StatusCode == HttpStatusCode.Forbidden)
			{
				throw new DropDeniedRpcException(reason ?? "Drop denied by API");
			}
			if (response.StatusCode == HttpStatusCode.BadRequest)
			{
				throw new DropDeniedRpcException(reason ?? "Drop request invalid");
			}

			throw new DropDeniedRpcException($"Drop API error {(int)response.StatusCode}: {reason ?? response.StatusCode.ToString()}");
		}

		private static string ExtractReason(string payload)
		{
			if (string.IsNullOrWhiteSpace(payload))
			{
				return null;
			}
			try
			{
				var error = JsonSerializer.Deserialize<DropApiError>(payload, JsonOptions);
				return error?.Reason ?? error?.Message ?? payload;
			}
			catch
			{
				return payload;
			}
		}

		private sealed class DropApiRequest
		{
			public string PlayerId { get; set; }
			public string RecipeCode { get; set; }
		}

		private sealed class DropApiResponse
		{
			public int ItemDefinitionId { get; set; }
			public string Reason { get; set; }
		}

		private sealed class DropApiError
		{
			public string Reason { get; set; }
			public string Message { get; set; }
		}

		internal readonly struct DropDecision
		{
			public DropDecision(int itemDefinitionId)
			{
				ItemDefinitionId = itemDefinitionId;
			}

			public int ItemDefinitionId { get; }
		}
	}
}
