using System;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("ClanStatsRemoteService")]
    public class ClanStatsRemoteService : RpcClass
    {
        public ClanStatsRemoteService(UserService user) : base(user) { }

        public override void Invoke(RpcRequest request)
        {
            try
            {
                switch (request.MethodName)
                {
                    case "getCurrentClanStats":
                        GetCurrentClanStats(request.Params.ToArray(), request.Id);
                        break;
                    case "getClanStats":
                        GetClanStats(request.Params.ToArray(), request.Id);
                        break;
                    default:
                        MethodNotFound(request);
                        break;
                }
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
            }
        }

        public void GetCurrentClanStats(BinaryValue[] value, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider db = BoltMainDatabaseProvider.Instance;
                var player = db.GetPlayerDocument(ObjectId.Parse(Id));
                ClanDocument clanDocument = db.GetPlayerClanDocument(player);

                if (clanDocument == null)
                {
                    SendException(guid, 404, "Player is not in a clan");
                    return;
                }

                string clanId = clanDocument._id.ToString();

                var response = new GetCurrentClanStatsResponse
                {
                    ClanId = clanId,
                    Stats = new ClanStatsMap(),
                    ClanStats = ClanStatsPayloadBuilder.BuildClanStats(clanDocument)
                };
                response.ClanMemberStats.Add(ClanStatsPayloadBuilder.BuildClanMemberStatsForClan(clanDocument));

                SendResponse(guid, response);
            }
        }

        public void GetClanStats(BinaryValue[] value, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var req = GetClanStatsRequest.Parser.ParseFrom(value[0].One.ToByteArray());
                
                var response = new GetClanStatsResponse
                {
                    ClanId = req.ClanId,
                    Stats = new ClanStatsMap(),
                    ClanStats = new Axlebolt.Bolt.Protobuf.ClanStats { ClanId = req.ClanId, SeasonId = "1" }
                };
                
                ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetClanDocument(req.ClanId);
                if (clanDocument != null)
                {
                    response.ClanStats = ClanStatsPayloadBuilder.BuildClanStats(clanDocument);
                    response.ClanMemberStats.Add(ClanStatsPayloadBuilder.BuildClanMemberStatsForClan(clanDocument));
                }
                
                SendResponse(guid, response);
            }
        }

        private void SendException(string guid, int code, string errorInfo)
        {
            SendResponse(guid, new Axlebolt.RpcSupport.Protobuf.Exception
            {
                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                Code = code
            });
        }
    }
}
