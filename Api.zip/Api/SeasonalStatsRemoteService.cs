using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB.Main.PlayerStats;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("SeasonalStatsRemoteService")]
    public class SeasonalStatsRemoteService : RpcClass
    {
        public SeasonalStatsRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "getplayerstatsforseason":
                    await GetPlayerStatsForSeason(request.Params.ToArray(), request.Id);
                    break;
                case "getcurrentclanstatsforseason":
                    await GetCurrentClanStatsForSeason(request.Params.ToArray(), request.Id);
                    break;
                case "getstatsforseason":
                    await GetStatsForSeason(request.Params.ToArray(), request.Id);
                    break;
                case "getclanstatsforseason":
                    await GetClanStatsForSeason(request.Params.ToArray(), request.Id);
                    break;
                case "getcurrentstats":
                    await GetCurrentStats(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task GetPlayerStatsForSeason(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string currentPlayerId))
                {
                    SendError(guid, 401);
                    return;
                }

                var request = ParseRequest(values, GetPlayerStatsForSeasonRequest.Parser);
                var targetPlayerId = string.IsNullOrWhiteSpace(request.PlayerId)
                    ? currentPlayerId
                    : request.PlayerId;

                var response = new GetPlayerStatsForSeasonResponse();
                FillPlayerStats(targetPlayerId, response);
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetCurrentClanStatsForSeason(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                var request = ParseRequest(values, GetCurrentClanStatsForSeasonRequest.Parser);
                var playerDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
                var clanDoc = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDoc);

                var response = new GetCurrentClanStatsForSeasonResponse
                {
                    ClanStats = clanDoc != null
                        ? ClanStatsPayloadBuilder.BuildClanStats(clanDoc, request.SeasonId)
                        : new ClanStats
                        {
                            ClanId = string.Empty,
                            SeasonId = ClanStatsPayloadBuilder.NormalizeSeasonId(request.SeasonId)
                        }
                };

                if (clanDoc != null)
                {
                    response.ClanMemberStats.Add(ClanStatsPayloadBuilder.BuildClanMemberStatsForClan(clanDoc));
                }

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetStatsForSeason(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                // Client expects GetPlayerStatsForSeasonResponse for this RPC call.
                var response = new GetPlayerStatsForSeasonResponse();
                FillPlayerStats(playerId, response);
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetCurrentStats(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                var statsDoc = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
                var tempResponse = new GetPlayerStatsForSeasonResponse();
                
                // Добавляем существующие статистики
                if (statsDoc?.stats != null)
                {
                    foreach (var bsonElement in statsDoc.stats)
                    {
                        if (bsonElement.Value.IsInt32 ||
                            bsonElement.Value.IsInt64 ||
                            bsonElement.Value.IsDouble ||
                            bsonElement.Value.IsString)
                        {
                            tempResponse.Stat.Add(bsonElement.GetPlayerStat());
                        }
                    }
                }
                
                // Добавляем недостающие дефолтные статистики
                EnsureDefaultStats(tempResponse);
                
                // Конвертируем в Stats для ответа
                var stats = new Stats();
                foreach (var stat in tempResponse.Stat)
                {
                    stats.Stat.Add(stat);
                }

                var response = new GetCurrentStatsResponse
                {
                    Stats = stats
                };
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetClanStatsForSeason(BinaryValue[] values, string guid)
        {
            try
            {
                var request = ParseRequest(values, GetClanStatsForSeasonRequest.Parser);
                ClanDocument clanDoc = null;
                string clanId = request.ClanId;

                if (!string.IsNullOrWhiteSpace(clanId))
                {
                    clanDoc = BoltMainDatabaseProvider.Instance.GetClanDocument(clanId);
                }
                else if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    var playerDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
                    clanDoc = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDoc);
                    clanId = clanDoc?._id.ToString() ?? string.Empty;
                }

                var response = new GetClanStatsForSeasonResponse
                {
                    ClanStats = clanDoc != null
                        ? ClanStatsPayloadBuilder.BuildClanStats(clanDoc, request.SeasonId)
                        : new ClanStats
                        {
                            ClanId = clanId ?? string.Empty,
                            SeasonId = ClanStatsPayloadBuilder.NormalizeSeasonId(request.SeasonId)
                        }
                };

                if (clanDoc != null)
                {
                    response.ClanMemberStats.Add(ClanStatsPayloadBuilder.BuildClanMemberStatsForClan(clanDoc));
                }

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private static T ParseRequest<T>(BinaryValue[] values, MessageParser<T> parser)
            where T : IMessage<T>, new()
        {
            if (values == null || values.Length == 0 || values[0]?.One == null || values[0].One.Length == 0)
            {
                return new T();
            }

            return parser.ParseFrom(values[0].One.ToByteArray());
        }

        private static void FillPlayerStats(string playerId, GetPlayerStatsForSeasonResponse response)
        {
            if (string.IsNullOrWhiteSpace(playerId))
            {
                return;
            }

            var statsDoc = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
            
            // Сначала добавляем существующие статистики из базы
            if (statsDoc?.stats != null)
            {
                foreach (var bsonElement in statsDoc.stats)
                {
                    if (bsonElement.Value.IsInt32 ||
                        bsonElement.Value.IsInt64 ||
                        bsonElement.Value.IsDouble ||
                        bsonElement.Value.IsString)
                    {
                        response.Stat.Add(bsonElement.GetPlayerStat());
                    }
                }
            }
            
            // Затем добавляем недостающие дефолтные статистики
            EnsureDefaultStats(response);
        }
        
        private static void EnsureDefaultStats(GetPlayerStatsForSeasonResponse response)
        {
            // Создаем HashSet существующих имен статистик для быстрой проверки
            var existingStats = new System.Collections.Generic.HashSet<string>();
            foreach (var stat in response.Stat)
            {
                existingStats.Add(stat.Name);
            }
            
            // Список всех необходимых статистик
            var requiredStats = new[]
            {
                // Ranked2v2 general stats (используется WrapMode: gameMode.ToLower() + "_" + apiName)
                ("ranked2v2_kills", StatDefType.Int, 0),
                ("ranked2v2_deaths", StatDefType.Int, 0),
                ("ranked2v2_assists", StatDefType.Int, 0),
                ("ranked2v2_headshots", StatDefType.Int, 0),
                ("ranked2v2_shots", StatDefType.Int, 0),
                ("ranked2v2_hits", StatDefType.Int, 0),
                ("ranked2v2_games_played", StatDefType.Int, 0),
                ("ranked2v2_damage", StatDefType.Int, 0),
                ("ranked2v2_wins", StatDefType.Int, 0),
                ("ranked2v2_losses", StatDefType.Int, 0),
                
                // Ranked2v2 specific stats (используется напрямую в PlayerRanked2v2StatsExtension)
                ("ranked_2v2_current_mmr", StatDefType.Int, 1000),
                ("ranked_2v2_rank", StatDefType.Int, 0),
                ("ranked_2v2_best_rank", StatDefType.Int, -1),
                ("ranked_2v2_played_matches", StatDefType.Int, 0),
                ("ranked_2v2_calibration_match_count", StatDefType.Int, 0),
                ("ranked_2v2_won_match_count", StatDefType.Int, 10),
                ("ranked_2v2_best_rank_history1", StatDefType.Int, 0),
                
                // RankedDefuse general stats
                ("rankeddefuse_kills", StatDefType.Int, 0),
                ("rankeddefuse_deaths", StatDefType.Int, 0),
                ("rankeddefuse_assists", StatDefType.Int, 0),
                ("rankeddefuse_headshots", StatDefType.Int, 0),
                ("rankeddefuse_shots", StatDefType.Int, 0),
                ("rankeddefuse_hits", StatDefType.Int, 0),
                ("rankeddefuse_games_played", StatDefType.Int, 0),
                ("rankeddefuse_damage", StatDefType.Int, 0),
                ("rankeddefuse_wins", StatDefType.Int, 0),
                ("rankeddefuse_losses", StatDefType.Int, 0),
                
                // RankedDefuse specific stats
                ("ranked_current_mmr", StatDefType.Int, 1000),
                ("ranked_rank", StatDefType.Int, 0),
                ("ranked_best_rank", StatDefType.Int, -1),
                ("ranked_played_matches", StatDefType.Int, 0),
                ("ranked_calibration_match_count", StatDefType.Int, 0),
                ("ranked_won_match_count", StatDefType.Int, 0),
                ("ranked_best_rank_history1", StatDefType.Int, 0),
                ("ranked_last_match_status", StatDefType.Int, 0),
                ("ranked_last_match_start_time", StatDefType.Int, 0),
                ("ranked_banned_match_no", StatDefType.Int, 0)
            };
            
            // Добавляем только те статистики, которых нет
            foreach (var (statName, type, value) in requiredStats)
            {
                if (!existingStats.Contains(statName))
                {
                    var playerStat = new PlayerStat
                    {
                        Name = statName,
                        Type = type
                    };
                    
                    if (type == StatDefType.Int)
                    {
                        playerStat.IntValue = (int)value;
                    }
                    else if (type == StatDefType.Float)
                    {
                        playerStat.FloatValue = (float)value;
                    }
                    
                    response.Stat.Add(playerStat);
                }
            }
        }

        private void SendResponse(string guid, IMessage response)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { One = response.ToByteString() }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
