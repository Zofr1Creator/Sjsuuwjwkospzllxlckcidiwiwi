using Axlebolt.Bolt.Protobuf;
using StandRiseServer.RpcServer.Api;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using StandRiseServer.MongoDB;
using MongoDB.Bson;
using Axlebolt.Bolt.Matchmaking.Protobuf;
using Player = Axlebolt.Bolt.Matchmaking.Protobuf.Player;
using Group = Axlebolt.Bolt.Matchmaking.Protobuf.Group;
using StandRiseServer.MongoDB.Game;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.RpcServer;
using StandRiseServer.RpcServer.Helpers;

namespace StandRiseServer.RpcServer.Api
{
    public class MatchmakingManager
    {
        private static readonly ConcurrentDictionary<string, QueuedPlayer> _queue = new();
        private static readonly ConcurrentDictionary<string, PendingMatch> _pendingMatches = new();
        private static bool _isMatching = false;

        public class QueuedPlayer
        {
            public string PlayerId { get; set; }
            public int GameMode { get; set; }
            public string Region { get; set; }
            public DateTime QueuedAt { get; set; }
            public int Mmr { get; set; }
            public string MapCondition { get; set; } = "";
            public List<string> PartyMembers { get; set; } = new();
        }

        public class PendingMatch
        {
            public string MatchId { get; set; }
            public int GameMode { get; set; }
            public string Region { get; set; }
            public string RoomId { get; set; }
            public string ChosenMap { get; set; }
            public List<QueuedPlayer> Groups { get; set; }
            public HashSet<string> ConfirmedPlayers { get; set; } = new();
            public CancellationTokenSource TimeoutToken { get; set; }
            public MatchGroup MatchGroup { get; set; }
            public DateTime CreatedAt { get; set; }
        }

        // Unity LevelDefinition resource ids (Levels/Sandstone, etc.)
        private static readonly string[] RankedDefuseMaps = { "Sandstone", "Province", "Rust", "Sakura", "Zone9", "Breeze" };
        private static readonly string[] Ranked2v2Maps = { "Sandstone", "Rust", "Province", "Sakura", "Zone9", "Breeze" };

        private static string NormalizeLevelId(string map)
        {
            if (string.IsNullOrWhiteSpace(map))
            {
                return "Sandstone";
            }

            var trimmed = map.Trim();
            foreach (var id in RankedDefuseMaps.Concat(Ranked2v2Maps).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                if (string.Equals(id, trimmed, StringComparison.OrdinalIgnoreCase))
                {
                    return id;
                }
            }

            if (trimmed.Length == 1)
            {
                return trimmed.ToUpperInvariant();
            }

            return char.ToUpperInvariant(trimmed[0]) + trimmed.Substring(1).ToLowerInvariant();
        }

        private static string ChooseMapForMode(int gameMode, string region, string matchId)
        {
            string[] pool = gameMode switch
            {
                6 => RankedDefuseMaps,
                5 => Ranked2v2Maps,
                8 => Ranked2v2Maps,
                _ => RankedDefuseMaps
            };

            if (pool.Length == 0)
            {
                return "Sandstone";
            }

            // Deterministic selection per match id avoids random skew across clustered workers.
            int seed = (matchId?.GetHashCode() ?? 0) ^ (region?.GetHashCode() ?? 0) ^ gameMode;
            int idx = Math.Abs(seed) % pool.Length;
            return pool[idx];
        }

        public static (bool success, string error) AddToQueue(string playerId, int gameMode, string region, string mapCondition = "", List<string> partyMembers = null)
        {
            if (_queue.ContainsKey(playerId))
            {
                return (false, "Already in queue");
            }

            // Get player MMR for the mode
            int mmr = 1000;
            try
            {
                var statsDoc = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
                if (statsDoc != null && statsDoc.stats != null)
                {
                    string mmrKey = (gameMode == 5 || gameMode == 8) ? "ranked_2v2_current_mmr" : "ranked_current_mmr";
                    mmr = statsDoc.stats.Contains(mmrKey) ? statsDoc.stats[mmrKey].ToInt32() : 1000;
                }
            }
            catch { }

            var queued = new QueuedPlayer
            {
                PlayerId = playerId,
                GameMode = gameMode,
                Region = region,
                QueuedAt = DateTime.UtcNow,
                Mmr = mmr,
                MapCondition = mapCondition,
                PartyMembers = partyMembers ?? new List<string> { playerId }
            };

            _queue[playerId] = queued;

            // Ranked UI: onMatchmakingProgress TaskId 10/20/30 (see MatchmakingRemoteService). Do not spam friend status here.

            Logger.Log($"[Matchmaking] Player {playerId} added to queue for mode {gameMode}, region {region}. MMR: {mmr}, Party size: {queued.PartyMembers.Count}");
            
            if (!_isMatching)
            {
                _ = TryMatchLoop();
            }

            return (true, null);
        }

        public static bool IsSearching(string playerId)
        {
            return _queue.ContainsKey(playerId) || _pendingMatches.Values.Any(m => m.Groups.Any(g => g.PartyMembers.Contains(playerId)));
        }

        public static bool IsInRankedQueue(string playerId)
        {
            return _queue.ContainsKey(playerId);
        }

        public static void RemoveFromQueue(string playerId)
        {
            if (_queue.TryRemove(playerId, out _))
            {
                Logger.Log($"[Matchmaking] Player {playerId} removed from queue");
            }

            // Also check pending matches
            var pending = _pendingMatches.Values.FirstOrDefault(m => m.Groups.Any(g => g.PartyMembers.Contains(playerId)));
            if (pending != null)
            {
                if (_pendingMatches.TryRemove(pending.MatchId, out _))
                {
                    pending.TimeoutToken.Cancel();
                    Logger.Log($"[Matchmaking] Pending match {pending.MatchId} cancelled because player {playerId} disconnected/declined.");

                    var failEvent = new OnMatchmakingFailEvent
                    {
                        Cause = MatchmakingFailCause.GroupMemberDisconnected,
                        Message = "A player left or disconnected during confirmation."
                    };

                    foreach (var group in pending.Groups)
                    {
                    foreach (var pId in group.PartyMembers)
                    {
                        if (pId == playerId) continue;
                        MatchmakingRemoteService.SendMatchmakingEvent(pId, MatchmakingRemoteService.EvMatchmakingFail, failEvent);
                    }

                        // Re-queue players who did not disconnect
                        if (group.PartyMembers.All(p => p != playerId))
                        {
                            AddToQueue(group.PlayerId, pending.GameMode, pending.Region, group.MapCondition, group.PartyMembers);
                        }
                    }
                }
            }
        }

        public static void ConfirmPlayer(string playerId)
        {
            var pending = _pendingMatches.Values.FirstOrDefault(m => m.Groups.Any(g => g.PartyMembers.Contains(playerId)));
            if (pending == null) return;

            lock (pending)
            {
                if (pending.ConfirmedPlayers.Contains(playerId)) return;
                pending.ConfirmedPlayers.Add(playerId);

                // Find the player in MatchGroup and set Confirmed = true
                Player protoPlayer = null;
                foreach (var team in pending.MatchGroup.Teams)
                {
                    foreach (var group in team.Groups)
                    {
                        foreach (var player in group.Players)
                        {
                            if (player.Id == playerId)
                            {
                                player.Confirmed = true;
                                protoPlayer = player;
                                break;
                            }
                        }
                    }
                }

                // Broadcast onPlayersConfirmed event to all players in the pending match
                var confirmEvent = new OnPlayersConfirmedEvent { MatchGroup = pending.MatchGroup };
                if (protoPlayer != null)
                {
                    confirmEvent.NewConfirmedPlayers.Add(protoPlayer);
                }

                foreach (var group in pending.Groups)
                {
                    foreach (var pId in group.PartyMembers)
                    {
                        MatchmakingRemoteService.SendMatchmakingEvent(pId, MatchmakingRemoteService.EvPlayersConfirmed, confirmEvent);
                    }
                }

                // If everyone confirmed, finalize the match!
                int totalPlayers = pending.Groups.Sum(g => g.PartyMembers.Count);
                if (pending.ConfirmedPlayers.Count == totalPlayers)
                {
                    pending.TimeoutToken.Cancel();
                    _pendingMatches.TryRemove(pending.MatchId, out _);
                    _ = FinalizeMatch(pending);
                }
            }
        }

        private static void BroadcastPlayerStatusToFriends(string playerId, PlayerStatus status)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    if (!StaticClasses.MainUserServices.ContainsKey(playerId))
                    {
                        return;
                    }

                    var friends = await BoltGameDatabaseProvider.Instance.GetPlayerFriends(playerId);
                    var protoStatus = status.GetPlayerStatusProto();
                    var friendsSender = StaticClasses.EventSenders.TryGetValue(playerId, out var senders)
                        ? senders.FirstOrDefault(s => s is FriendsRemoteEventSender)
                        : null;

                    if (friendsSender == null)
                    {
                        return;
                    }

                    foreach (var friendDoc in friends)
                    {
                        string friendId = friendDoc.playerInitiatorId == playerId ? friendDoc.playerId : friendDoc.playerInitiatorId;
                        if (StaticClasses.EventSenders.TryGetValue(friendId, out var friendSenders))
                        {
                            friendSenders.FirstOrDefault(s => s is FriendsRemoteEventSender)
                                ?.SendEvent("onPlayerStatusChanged", new object[] { playerId, protoStatus });
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"[Matchmaking] Failed to broadcast status for {playerId}: {ex.Message}");
                }
            });
        }

        private static HashSet<string> GetAllowedMapsForPlayer(QueuedPlayer player)
        {
            string[] pool = player.GameMode switch
            {
                6 => RankedDefuseMaps,
                5 => Ranked2v2Maps,
                8 => Ranked2v2Maps,
                _ => RankedDefuseMaps
            };

            var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(player.MapCondition))
            {
                allowed.UnionWith(pool);
            }
            else
            {
                string[] parts = player.MapCondition.Split(new[] { ',', ';', ' ', '_', '-' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var part in parts)
                {
                    string normalized = NormalizeLevelId(part.Trim());
                    if (pool.Any(m => string.Equals(m, normalized, StringComparison.OrdinalIgnoreCase)))
                    {
                        allowed.Add(normalized);
                    }
                }

                if (allowed.Count == 0)
                {
                    string normalized = NormalizeLevelId(player.MapCondition.Trim());
                    if (pool.Any(m => string.Equals(m, normalized, StringComparison.OrdinalIgnoreCase)))
                    {
                        allowed.Add(normalized);
                    }
                    else
                    {
                        allowed.UnionWith(pool);
                    }
                }
            }

            return allowed;
        }

        private static bool TryMatchPlayersSimple(int mode, string region, List<QueuedPlayer> playersInQueue, int requiredPlayers)
        {
            var selected = new List<QueuedPlayer>();
            int count = 0;
            foreach (var player in playersInQueue.OrderBy(q => q.QueuedAt))
            {
                selected.Add(player);
                count += player.PartyMembers.Count;
                if (count >= requiredPlayers)
                {
                    break;
                }
            }

            if (count < requiredPlayers)
            {
                return false;
            }

            CreateMatch(mode, region, selected);
            return true;
        }

        private static async Task TryMatchLoop()
        {
            if (_isMatching) return;
            _isMatching = true;
            try
            {
                while (_queue.Count > 0)
                {
                    var modes = _queue.Values.Select(q => q.GameMode).Distinct().ToList();
                    foreach (var mode in modes)
                    {
                        var regions = _queue.Values.Where(q => q.GameMode == mode).Select(q => q.Region).Distinct().ToList();
                        foreach (var region in regions)
                        {
                            var playersInQueue = _queue.Values
                                .Where(q => q.GameMode == mode && q.Region == region)
                                .OrderBy(q => q.QueuedAt)
                                .ToList();

                            int requiredPlayers = mode switch
                            {
                                6 => 2, // Ranked Defuse 5v5
                                8 => 2,  // Ranked 2v2
                                5 => 2,  // Allies 2v2
                                _ => 2  // Others (minimum 2 to start)
                            };

                            int totalPlayers = playersInQueue.Sum(p => p.PartyMembers.Count);

                            if (totalPlayers >= requiredPlayers)
                            {
                                if (requiredPlayers <= 4 && TryMatchPlayersSimple(mode, region, playersInQueue, requiredPlayers))
                                {
                                    continue;
                                }

                                // Sort by MMR to match players of similar skill
                                var sortedPlayers = playersInQueue.OrderBy(p => p.Mmr).ToList();
                                
                                // Try to find a group within MMR threshold
                                // Base threshold is 200, increases by 50 every 10 seconds of waiting
                                for (int i = 0; i <= sortedPlayers.Count - 1; i++)
                                {
                                    var matchedGroups = new List<QueuedPlayer>();
                                    matchedGroups.Add(sortedPlayers[i]);
                                    int currentCount = sortedPlayers[i].PartyMembers.Count;
                                    int minMmr = sortedPlayers[i].Mmr;
                                    int maxMmr = sortedPlayers[i].Mmr;

                                    var matchAllowedMaps = new HashSet<string>(GetAllowedMapsForPlayer(sortedPlayers[i]), StringComparer.OrdinalIgnoreCase);

                                    double maxWait = (DateTime.UtcNow - sortedPlayers[i].QueuedAt).TotalSeconds;
                                    int threshold = 200 + (int)(maxWait / 10.0) * 50;

                                    for (int j = 0; j < sortedPlayers.Count; j++)
                                    {
                                        if (i == j) continue;
                                        
                                        var candidate = sortedPlayers[j];
                                        if (Math.Abs(candidate.Mmr - (minMmr + maxMmr) / 2) <= threshold)
                                        {
                                            if (currentCount + candidate.PartyMembers.Count <= requiredPlayers)
                                            {
                                                var candidateAllowed = GetAllowedMapsForPlayer(candidate);
                                                var tempIntersection = new HashSet<string>(matchAllowedMaps, StringComparer.OrdinalIgnoreCase);
                                                tempIntersection.IntersectWith(candidateAllowed);

                                                if (tempIntersection.Count > 0)
                                                {
                                                    matchAllowedMaps = tempIntersection;
                                                    matchedGroups.Add(candidate);
                                                    currentCount += candidate.PartyMembers.Count;
                                                    minMmr = Math.Min(minMmr, candidate.Mmr);
                                                    maxMmr = Math.Max(maxMmr, candidate.Mmr);
                                                }
                                            }
                                        }
                                        if (currentCount == requiredPlayers) break;
                                    }

                                    if (currentCount == requiredPlayers)
                                    {
                                        CreateMatch(mode, region, matchedGroups);
                                        break;
                                    }
                                }
                            }
                            else if (mode != 6 && mode != 8 && mode != 5 && playersInQueue.Count > 0)
                            {
                                // For non-ranked modes, if we can't get exactly requiredPlayers, 
                                // but have some players waiting, we could start with what we have if they've waited long enough
                                var longestWaiting = playersInQueue.First();
                                if ((DateTime.UtcNow - longestWaiting.QueuedAt).TotalSeconds > 30)
                                {
                                    CreateMatch(mode, region, playersInQueue.Take(5).ToList());
                                }
                            }
                        }
                    }

                    foreach (var queued in _queue.Values.ToList())
                    {
                        if (queued.GameMode is 5 or 6 or 8 or 30)
                        {
                            int taskId = MatchmakingRemoteService.ResolveQueuedPlayerTaskId(queued.PartyMembers);
                            MatchmakingRemoteService.SendRankedMatchmakingProgress(queued.PlayerId, taskId);
                        }
                    }

                    await Task.Delay(2500);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[Matchmaking] Error in MatchLoop: {ex.Message}");
            }
            finally
            {
                _isMatching = false;
            }
        }

        private static void CreateMatch(int gameMode, string region, List<QueuedPlayer> groups)
        {
            var matchId = Guid.NewGuid().ToString("N");
            
            string modeName = gameMode switch
            {
                0 => "DeathMatch",
                1 => "Defuse",
                2 => "ArmsRace",
                3 => "Training",
                4 => "SniperDuel",
                5 => "Ranked2v2",
                6 => "RankedDefuse",
                7 => "Escalation",
                8 => "Ranked2v2",
                9 => "SniperDuel",
                30 => "Arcade",
                _ => "DeathMatch"
            };

            string photonMode = gameMode switch
            {
                6 => "RankedDefuse",
                8 => "Ranked2v2",
                5 => "Ranked2v2",
                _ => modeName
            };

            var roomId = $"{photonMode}_{matchId.Substring(0, 12)}";
            
            var pool = gameMode switch
            {
                6 => RankedDefuseMaps,
                5 => Ranked2v2Maps,
                8 => Ranked2v2Maps,
                _ => RankedDefuseMaps
            };

            var matchAllowedMapsForSelection = new HashSet<string>(pool, StringComparer.OrdinalIgnoreCase);
            foreach (var group in groups)
            {
                var groupAllowed = GetAllowedMapsForPlayer(group);
                matchAllowedMapsForSelection.IntersectWith(groupAllowed);
            }

            string chosenMap = "";
            if (matchAllowedMapsForSelection.Count > 0)
            {
                if (matchAllowedMapsForSelection.Count < pool.Length)
                {
                    chosenMap = matchAllowedMapsForSelection.OrderBy(m => m).First();
                }
            }

            if (string.IsNullOrEmpty(chosenMap))
            {
                chosenMap = ChooseMapForMode(gameMode, region, matchId);
            }
            else
            {
                chosenMap = NormalizeLevelId(chosenMap);
            }

            // Construct MatchGroup for Allies or Ranked Defuse
            var matchGroup = new MatchGroup { FilterCondition = chosenMap };
            var team1 = new TeamGroup();
            var team2 = new TeamGroup();

            var allPlayers = groups.SelectMany(g => g.PartyMembers).ToList();
            int currentTeam1Count = 0;
            int totalPlayersToMatch = allPlayers.Count;
            int halfPlayers = totalPlayersToMatch / 2;

            foreach (var group in groups)
            {
                var protoGroup = new Group();
                foreach (var pId in group.PartyMembers)
                {
                    string pName = "Player";
                    string pClan = "";
                    try
                    {
                        var profile = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(pId));
                        if (profile != null)
                        {
                            pName = profile.name;
                        }
                    }
                    catch { }

                    protoGroup.Players.Add(new Player 
                    { 
                        Id = pId, 
                        Name = pName, 
                        Online = true, 
                        Confirmed = false, // Must confirm manually
                        ClanId = pClan
                    });
                }

                if (currentTeam1Count < halfPlayers)
                {
                    team1.Groups.Add(protoGroup);
                    currentTeam1Count += group.PartyMembers.Count;
                }
                else
                {
                    team2.Groups.Add(protoGroup);
                }
            }
            matchGroup.Teams.Add(team1);
            matchGroup.Teams.Add(team2);

            // Clean up players from searching queue
            foreach (var group in groups)
            {
                _queue.TryRemove(group.PlayerId, out _);
            }

            var pending = new PendingMatch
            {
                MatchId = matchId,
                GameMode = gameMode,
                Region = region,
                RoomId = roomId,
                ChosenMap = chosenMap,
                Groups = groups,
                TimeoutToken = new CancellationTokenSource(),
                MatchGroup = matchGroup,
                CreatedAt = DateTime.UtcNow
            };

            _pendingMatches[matchId] = pending;

            // Broadcast onMatchmakingDone to prompt accept/decline screen
            foreach (var group in groups)
            {
                foreach (var playerId in group.PartyMembers)
                {
                    if (gameMode == 5 || gameMode == 6 || gameMode == 8 || gameMode == 30)
                    {
                        string modeNameForLog = gameMode switch
                        {
                            6 => "RankedDefuse",
                            8 => "Ranked2v2",
                            5 => "Ranked2v2",
                            30 => "Arcade",
                            _ => modeName
                        };
                        MatchmakingRemoteService.SendRankedMatchmakingProgress(
                            playerId,
                            MatchmakingRemoteService.TaskIdConfirmation,
                            matchGroup.Clone());
                        Logger.Log($"[Matchmaking] Match found ({modeNameForLog}) for {playerId}. Sent onMatchmakingProgress TaskId={MatchmakingRemoteService.TaskIdConfirmation} (Map: {chosenMap}).");
                    }
                    else
                    {
                        pending.ConfirmedPlayers.Add(playerId);
                    }
                }
            }

            int totalPlayers = groups.Sum(g => g.PartyMembers.Count);
            if (pending.ConfirmedPlayers.Count == totalPlayers)
            {
                // Non-ranked or auto-confirmed match, finalize immediately
                _pendingMatches.TryRemove(matchId, out _);
                _ = FinalizeMatch(pending);
            }
            else
            {
                // Start the 15-second acceptance timer
                StartConfirmationTimeout(pending);
            }
        }

        private static void StartConfirmationTimeout(PendingMatch pending)
        {
            Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(15000, pending.TimeoutToken.Token);
                    if (pending.TimeoutToken.Token.IsCancellationRequested) return;

                    // Timeout expired! Cancel the match
                    if (_pendingMatches.TryRemove(pending.MatchId, out _))
                    {
                        Logger.Log($"[Matchmaking] Match {pending.MatchId} expired: not all players confirmed (Confirmed: {pending.ConfirmedPlayers.Count}/{pending.Groups.Sum(g => g.PartyMembers.Count)}).");

                        var failEvent = new OnMatchmakingFailEvent
                        {
                            Cause = MatchmakingFailCause.GroupMemberNotConfirmed,
                            Message = "A player failed to confirm the match."
                        };

                        foreach (var group in pending.Groups)
                        {
                            bool groupAccepted = group.PartyMembers.All(p => pending.ConfirmedPlayers.Contains(p));
                            
                            foreach (var pId in group.PartyMembers)
                            {
                                MatchmakingRemoteService.SendMatchmakingEvent(pId, MatchmakingRemoteService.EvMatchmakingFail, failEvent);
                            }

                            // Re-queue group if they all accepted
                            if (groupAccepted)
                            {
                                AddToQueue(group.PlayerId, pending.GameMode, pending.Region, group.MapCondition, group.PartyMembers);
                            }
                            else
                            {
                                Logger.Log($"[Matchmaking] Group {group.PlayerId} failed to confirm and is removed from queue.");
                            }

                            foreach (var pId in group.PartyMembers)
                            {
                                MatchmakingRemoteService.UnregisterRankedMatchmakingConnection(pId);
                            }
                        }
                    }
                }
                catch (TaskCanceledException) { }
                catch (Exception ex)
                {
                    Logger.Error($"[Matchmaking] Error in confirmation timeout: {ex.Message}");
                }
            });
        }

        private static async Task FinalizeMatch(PendingMatch pending)
        {
            try
            {
                var matchId = pending.MatchId;
                var gameMode = pending.GameMode;
                var region = pending.Region;
                var roomId = pending.RoomId;
                var groups = pending.Groups;
                var chosenMap = string.IsNullOrWhiteSpace(pending.ChosenMap)
                    ? ChooseMapForMode(gameMode, region, matchId)
                    : pending.ChosenMap;
                
                string modeName = gameMode switch
                {
                    0 => "DeathMatch",
                    1 => "Defuse",
                    2 => "ArmsRace",
                    3 => "Training",
                    4 => "SniperDuel",
                    5 => "Ranked2v2",
                    6 => "RankedDefuse",
                    7 => "Escalation",
                    8 => "Ranked2v2",
                    9 => "SniperDuel",
                    30 => "Arcade",
                    _ => "DeathMatch"
                };

                int maxPlayers = gameMode switch
                {
                    6 => 10,
                    8 => 4,
                    5 => 4,
                    _ => 10
                };

                string photonMode = gameMode switch
                {
                    6 => "RankedDefuse",
                    8 => "Ranked2v2",
                    5 => "Ranked2v2",
                    _ => modeName
                };

                int roundsCount = gameMode switch
                {
                    6 => 15,
                    8 => 9,
                    5 => 9,
                    _ => 0
                };

                const string clientGameVersion = "0.16.0";

                var gameServerData = new GameServer { Ip = "172.211.241.220", Port = 5055 };

                var lobbyMembers = new List<BoltFriend>();
                foreach (var group in groups)
                {
                    foreach (var pId in group.PartyMembers)
                    {
                        try
                        {
                            var profile = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(pId));
                            if (profile != null && lobbyMembers.All(m => m.Id != profile._id.ToString()))
                            {
                                lobbyMembers.Add(profile.GetBoltFriend());
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogWarn($"[Matchmaking] FinalizeMatch: skip player {pId}: {ex.Message}");
                        }
                    }
                }

                if (lobbyMembers.Count == 0)
                {
                    Logger.Error($"[Matchmaking] FinalizeMatch {matchId}: no lobby members resolved");
                    return;
                }

                string ownerId = lobbyMembers.FirstOrDefault(m => m.Id == groups[0].PlayerId)?.Id
                    ?? lobbyMembers[0].Id;

                var matchLobbyData = new ConcurrentDictionary<string, string>();
                matchLobbyData["matchId"] = matchId;
                matchLobbyData["gameMode"] = modeName;
                matchLobbyData["SearchingRegion"] = region.ToLowerInvariant();

                var matchPhotonGame = new PhotonGame
                {
                    region = region.ToLower(),
                    roomId = roomId,
                    appVersion = clientGameVersion,
                    customProperties = new Dictionary<string, string>
                    {
                        { "C0", photonMode },
                        { "C1", chosenMap },
                        { "match_id", matchId },
                        { "game_mode", modeName }
                    }
                };
                if (roundsCount > 0)
                {
                    matchPhotonGame.customProperties["round_count"] = roundsCount.ToString();
                }

                var serverLobby = new BoltLobby(
                    matchId,
                    ownerId,
                    modeName + " Match",
                    BoltLobby.LobbyType.Private,
                    false,
                    maxPlayers,
                    0,
                    matchLobbyData,
                    lobbyMembers,
                    new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    gameServerData,
                    matchPhotonGame);

                StaticClasses.Lobbies[matchId] = serverLobby;

                foreach (var group in groups)
                {
                    foreach (var playerId in group.PartyMembers)
                    {
                        if (StaticClasses.PlayersStatus.TryGetValue(playerId, out var status))
                        {
                            status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
                            var cachedPhoton = new PhotonGame
                            {
                                region = region.ToLower(),
                                roomId = roomId,
                                appVersion = clientGameVersion,
                                customProperties = new Dictionary<string, string>
                                {
                                    { "C0", photonMode },
                                    { "C1", chosenMap },
                                    { "game_mode", modeName },
                                    { "match_id", matchId }
                                }
                            };
                            if (roundsCount > 0)
                            {
                                cachedPhoton.customProperties["round_count"] = roundsCount.ToString();
                            }

                            status.playInGame = new PlayInGame
                            {
                                gameCode = "standoff2",
                                gameVersion = clientGameVersion,
                                lobbyId = matchId,
                                lobbyName = modeName,
                                photonGame = cachedPhoton,
                                gameState = "InGame"
                            };
                            BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(playerId), status);

                            if (gameMode == 5 || gameMode == 6 || gameMode == 8)
                            {
                                PlayerStatsManager.MarkRankedMatchStarted(playerId);
                            }

                            var doneEvent = new OnMatchmakingDoneEvent
                            {
                                Id = matchId,
                                MatchGroup = pending.MatchGroup?.Clone()
                            };
                            MatchmakingRemoteService.SendMatchmakingEvent(playerId, MatchmakingRemoteService.EvMatchmakingDone, doneEvent);
                            Logger.Log($"[Matchmaking] Sent {MatchmakingRemoteService.EvMatchmakingDone} to {playerId} matchId={matchId} room={roomId}");
                            MatchmakingRemoteService.UnregisterRankedMatchmakingConnection(playerId);
                        }
                    }
                }
                
                if (gameMode == 5 || gameMode == 6 || gameMode == 8)
                {
                    var fallbackIds = groups.SelectMany(g => g.PartyMembers).Distinct().ToList();
                    ActiveRankedMatchRegistry.Register(
                        matchId,
                        roomId,
                        modeName,
                        chosenMap,
                        region,
                        pending.MatchGroup,
                        fallbackIds);
                }

                Logger.Log($"[Matchmaking] Match {matchId} finalized successfully! Lobbies populated. Players transitioning to room {roomId}.");
            }
            catch (Exception ex)
            {
                Logger.Error($"[Matchmaking] Error finalizing match: {ex.Message}\n{ex.StackTrace}");
            }
        }
    }
}
