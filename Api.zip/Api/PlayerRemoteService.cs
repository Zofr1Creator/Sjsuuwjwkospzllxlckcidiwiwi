using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Game;
using StandRiseServer.MongoDB.Main;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StandRiseServer.RpcServer.Api
{
    public class PlayerRemoteService : RpcClass
    {
        public PlayerRemoteService(UserService user) : base(user)
        { }
        protected void SetPlayerAvatar(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                FromByteMethod from = new FromByteMethod(typeof(byte[]));
                byte[] Avatarforset = (byte[])from.FromBytes(values[0]);
                int[] rt = new int[Avatarforset.Length];
                rt = Avatarforset.Select(i => (int)i).ToArray();
                string avatarId = boltGame.FindOrCreateAvatar(rt);
                boltMain.SetPlayerAvatar(ObjectId.Parse(Id), avatarId);
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse{ Id = guid, Return = new ToByteMethod(typeof(string)).ToBytes(avatarId) } });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void GetCurrentPlayer(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));

                var protoPlayer = new Axlebolt.Bolt.Protobuf.Player
                {
                    Id = playerDocument._id.ToString(),
                    Uid = playerDocument.uid,
                    Name = playerDocument.name,
                    AvatarId = playerDocument.avatarId,
                    TimeInGame = playerDocument.timeInGame,
                    RegistrationDate = playerDocument.createDate.MillisecondsSinceEpoch,
                    PlayerStatus = StaticClasses.PlayersStatus.ContainsKey(Id) 
                        ? StaticClasses.PlayersStatus[Id].GetPlayerStatusProto() 
                        : new PlayerStatus().GetPlayerStatusProto(),
                    TesterRole = playerDocument.testerRole ?? "",
                };

                var attributes = new Axlebolt.Bolt.Protobuf.Attributes();
                var clanDoc = boltMain.GetPlayerClanDocument(playerDocument);
                if (clanDoc != null)
                {
                    attributes.Map.Add("ClanId", new Axlebolt.Bolt.Protobuf.Attribute { Type = Axlebolt.Bolt.Protobuf.PropertyType.String, String = clanDoc._id.ToString() });
                    attributes.Map.Add("Tag", new Axlebolt.Bolt.Protobuf.Attribute { Type = Axlebolt.Bolt.Protobuf.PropertyType.String, String = clanDoc.tag });
                    
                    // Read role directly from clan members document to avoid ID mismatch
                    int roleId = 1000; // default: Member
                    if (clanDoc.members != null && clanDoc.members.TryGetValue(playerDocument._id.ToString(), out var memberBson) && memberBson.IsBsonDocument)
                    {
                        var memberDoc = memberBson.AsBsonDocument;
                        if (memberDoc.TryGetValue("role", out var roleValue) && roleValue.IsString)
                        {
                            roleId = BoltMainDatabaseProvider.Instance.GetClanMemberRoleByIdString(roleValue.AsString).Id;
                        }
                    }
                    attributes.Map.Add("RoleId", new Axlebolt.Bolt.Protobuf.Attribute { Type = Axlebolt.Bolt.Protobuf.PropertyType.Int, Int = roleId });
                }
                protoPlayer.Attributes = attributes;

                if (playerDocument.isBanned)
                {
                    protoPlayer.Bans.Add(new Axlebolt.Bolt.Protobuf.PlayerBan
                    {
                        BanCode = int.TryParse(playerDocument.banCode, out int code) ? code : 0,
                        Message = playerDocument.banReason ?? "Banned"
                    });
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(Axlebolt.Bolt.Protobuf.Player)).ToBytes(protoPlayer)
                    }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void SetPlayerName(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                FromByteMethod fromByte = new FromByteMethod(typeof(string));
                string name = (string)fromByte.FromBytes(values[0]);
                boltMain.SetPlayerName(ObjectId.Parse(Id), name);
                
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetAwayStatus(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus status = StaticClasses.PlayersStatus.ContainsKey(Id) 
                    ? StaticClasses.PlayersStatus[Id] 
                    : new PlayerStatus();
                status.onlineStatus = PlayerStatus.OnlineStatus.StateAway;
                boltMain.SetPlayerStatus(ObjectId.Parse(Id), status);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetOnlineStatus(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerStatus status = StaticClasses.PlayersStatus.ContainsKey(Id) 
                    ? StaticClasses.PlayersStatus[Id] 
                    : new PlayerStatus();
                status.onlineStatus = PlayerStatus.OnlineStatus.StateOnline;
                boltMain.SetPlayerStatus(ObjectId.Parse(Id), status);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void BanMe(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                FromByteMethod fromByte1 = new FromByteMethod(typeof(string));
                FromByteMethod fromByte2 = new FromByteMethod(typeof(int));
                string banReason = (string)fromByte1.FromBytes(values[0]);
                int banCode = (int)fromByte2.FromBytes(values[1]);
                boltMain.BanPlayer(ObjectId.Parse(Id), banReason, banCode);
                Logger.LogWarn($"[BanMe] Player {Id} banned in-game. Code: {banCode}, Reason: {banReason}");

                var playerDoc = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                StaticClasses.KickWithBan(Id, banReason, banCode, playerDoc?.uid ?? Id);
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetPlayerFirebaseToken(BinaryValue[] values, string guid)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { IsNull = true }
                }
            });
        }
        public override void Invoke(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "setplayeravatar":
                    SetPlayerAvatar(request.Params.ToArray(), request.Id);
                    break;
                case "getplayer":
                case "getcurrentplayer":
                    GetCurrentPlayer(request.Params.ToArray(), request.Id);
                    break;
                case "setplayername":
                    SetPlayerName(request.Params.ToArray(), request.Id);
                    break;
                case "setawaystatus":
                    SetAwayStatus(request.Params.ToArray(), request.Id);
                    break;
                case "setonlinestatus":
                    SetOnlineStatus(request.Params.ToArray(), request.Id);
                    break;
                case "banme":
                    BanMe(request.Params.ToArray(), request.Id);
                    break;
                case "setplayerfirebasetoken":
                    SetPlayerFirebaseToken(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }
    }
    public static class PlayerServiceHelper
    {
        public static Axlebolt.Bolt.Protobuf.PlayerStatus GetPlayerStatusProto(this PlayerStatus bsonElements)
        {
            bsonElements?.EnsurePlayInGame();
            return PlayerStatus.GetByDocument(bsonElements);
        }
    }
}
