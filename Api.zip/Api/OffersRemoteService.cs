using System;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;

namespace StandRiseServer.RpcServer.Api
{
    public class OffersRemoteService : RpcClass
    {
        public OffersRemoteService(UserService user) : base(user)
        {
        }

        protected void GetSpecialOffers(string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string _))
            {
                var response = new GetSpecialOffersResponse();
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(GetSpecialOffersResponse)).ToBytes(response)
                    }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getSpecialOffers")
                GetSpecialOffers(request.Id);
            else
                MethodNotFound(request);
        }
    }
}
