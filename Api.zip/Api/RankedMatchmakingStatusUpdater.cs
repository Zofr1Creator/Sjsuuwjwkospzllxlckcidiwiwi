using System;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;

namespace StandRiseServer.RpcServer.Api
{
    /// <summary>
    /// Периодически отправляет обновления статуса поиска для игроков в очереди ranked matchmaking
    /// Это необходимо чтобы клиент не висел в бесконечном подключении
    /// </summary>
    public static class RankedMatchmakingStatusUpdater
    {
        private static bool _isRunning = false;
        private static readonly object _lock = new object();

        /// <summary>
        /// Запускает цикл обновления статусов (если еще не запущен)
        /// </summary>
        public static void EnsureRunning()
        {
            lock (_lock)
            {
                if (!_isRunning && MatchmakingQueue.RankedQueue.Count > 0)
                {
                    _isRunning = true;
                    Console.WriteLine("[RankedMatchmaking] Starting status update loop");
                    _ = StatusUpdateLoop();
                }
            }
        }

        private static async Task StatusUpdateLoop()
        {
            try
            {
                while (MatchmakingQueue.RankedQueue.Count > 0)
                {
                    // Группируем игроков по регионам
                    var regionGroups = MatchmakingQueue.RankedQueue.Values.GroupBy(x => x.Region).ToList();
                    
                    foreach (var regionGroup in regionGroups)
                    {
                        string region = regionGroup.Key;
                        var playersInRegion = regionGroup.ToList();
                        
                        foreach (var entry in playersInRegion)
                        {
                            try
                            {
                                // Отправляем событие через EventSender
                                if (StaticClasses.EventSenders.TryGetValue(entry.PlayerId, out var senders))
                                {
                                    var matchmakingSender = senders.FirstOrDefault(s => s.eventListenerName == "MatchmakingRemoteEventListener");
                                    if (matchmakingSender != null)
                                    {
                                        // Отправляем простое событие прогресса
                                        // Параметры: state (int), playersCount (int)
                                        // State 1 = MatchmakingState (поиск игроков)
                                        matchmakingSender.SendEvent("onMatchmakingProgress", new object[] { 1, playersInRegion.Count });
                                        Console.WriteLine($"[RankedMatchmaking] Sent progress update to {entry.PlayerId}: state=1, players={playersInRegion.Count}");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"[RankedMatchmaking] Error sending progress update for player {entry.PlayerId}: {ex.Message}");
                            }
                        }
                    }
                    
                    // Ждем 1 секунду перед следующей отправкой
                    await Task.Delay(1000);
                }
                
                Console.WriteLine("[RankedMatchmaking] Status update loop stopped (no players in queue)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[RankedMatchmaking] Error in StatusUpdateLoop: {ex.Message}");
                Console.WriteLine($"[RankedMatchmaking] Stack trace: {ex.StackTrace}");
            }
            finally
            {
                lock (_lock)
                {
                    _isRunning = false;
                }
            }
        }
    }
}
