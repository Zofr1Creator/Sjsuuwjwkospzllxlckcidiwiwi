using System;
using Axlebolt.RpcSupport.Protobuf;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("SeasonRemoteService")]
    public class SeasonRemoteService : RpcClass
    {
        public SeasonRemoteService(UserService user) : base(user)
        {
        }

        protected void GetCurrentSeason(string guid)
        {
            try
            {
                Console.WriteLine($"[Season] GetCurrentSeason called");
                
                // Return empty response for now - Season protobuf type doesn't exist in this version
                // Client will use default season
                Console.WriteLine($"[Season] Returning empty season response");
                
                _user.SendResponce(new ResponseMessage 
                { 
                    RpcResponse = new RpcResponse 
                    { 
                        Id = guid, 
                        Return = new BinaryValue()
                    } 
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Season] GetCurrentSeason ERROR: {ex.Message}");
                _user.SendResponce(new ResponseMessage 
                { 
                    RpcResponse = new RpcResponse 
                    { 
                        Id = guid, 
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 500
                        }
                    } 
                });
            }
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getCurrentSeason") 
                GetCurrentSeason(request.Id);
            else
                MethodNotFound(request);
        }
    }
}
