﻿using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using Newtonsoft.Json;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using StandRiseServer.RpcServer.Helpers;
using MongoDB.Driver;

namespace StandRiseServer.RpcServer.Api
{
    public class GoogleAuthRemoteService : RpcClass
    {
        public GoogleAuthRemoteService(UserService user) : base(user)
        {
        }
        private static string Dec(string str)
        {
            char[] characters = str.ToCharArray();
            string result = "";
            for (int i = 0; i < characters.Length; i++)
            {
                result += Char.ToString((char)(characters[i] ^ 0x023));
            }
            return result;
        }
        public override async Task InvokeAsync(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "encryptedauth":
                    await GoogleEncryptedAuth(request.Params.ToArray(), request.Id);
                    break;
                case "protoauthsecured":
                case "googleprotoauthsecure":
                case "auth":
                case "googleauth":
                    await GoogleProtoAuthSecure(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }
        public async Task GoogleEncryptedAuth(BinaryValue[] value1, string guid)
        {
            try
            {
                BinaryValue[] value2 = new BinaryValue[] { new BinaryValue { IsNull = false } };
                byte[] key = Encoding.ASCII.GetBytes("key_abcdefghijkl");
                byte[] IV = Encoding.ASCII.GetBytes("iv_abcdefghijklm");
                byte[] re = await Utils.DecryptByteAsync(value1[0].One.ToByteArray(), key, IV);
                value2[0].One = ByteString.CopyFrom(re, 0, re.Length);
                FromByteMethod from = new FromByteMethod(typeof(GoogleAuthRequest));
                GoogleAuthRequest Val = (GoogleAuthRequest)from.FromBytes(value2[0]);
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create("https://accounts.google.com/o/oauth2/token");
                webRequest.Method = "POST";
                string Parameters = "huy";
                if (Val.AuthGoogle.Platform == Platform.Android)
                {
                    Parameters = "code=" + Val.AuthGoogle.AuthCode +
                                "&client_id=769476000932-0bs8an7lomlo3pj3od6cvrh5m0tvlfb5.apps.googleusercontent.com" +
                                "&client_secret=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" +
                                "&redirect_uri=urn:ietf:wg:oauth:2.0:oob" +
                                "&grant_type=authorization_code";
                }
                else if (Val.AuthGoogle.Platform == Platform.Ios)
                {
                    Parameters = "code=" + Uri.EscapeDataString(Val.AuthGoogle.AuthCode) +
                            "&client_id=304825330473-hihiktmteeqnerdhp2okctohuco7iblq.apps.googleusercontent.com" +
                            "&client_secret=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" +
                            "&redirect_uri=urn:ietf:wg:oauth:2.0:oob" +
                            "&grant_type=authorization_code";
                }

                else
                {
                    Parameters = "code=" + Val.AuthGoogle.AuthCode +
                                "&client_id=304825330473-hihiktmteeqnerdhp2okctohuco7iblq.apps.googleusercontent.com" +
                                "&client_secret=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" +
                                "&redirect_uri=com.googleusercontent.apps.304825330473-0jubpucn6mddur4ncq4cn2abhhe7okvp:/oauth2redirect" +
                                "&grant_type=authorization_code";
                }

                byte[] byteArray = Encoding.UTF8.GetBytes(Parameters);
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.ContentLength = byteArray.Length;
                Stream postStream = await webRequest.GetRequestStreamAsync();
                await postStream.WriteAsync(byteArray, 0, byteArray.Length);
                postStream.Close();
                WebResponse response = webRequest.GetResponse();
                postStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(postStream);
                string responseFromServer = await reader.ReadToEndAsync();
                GooglePlusAccessToken serStatus = JsonConvert.DeserializeObject<GooglePlusAccessToken>(responseFromServer);
                if (serStatus != null)
                {
                    string accessToken = serStatus.access_token;
                    string id = (await Google2.getgoogleplususerdataSer(accessToken)).id;
                    if (!string.IsNullOrEmpty(id))
                    {//GetLastId
                        BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                        HashDocument asd = null;
                        try
                        {
                            GoogleAccountDocument googleAccountDocument = boltMain.GetGoogleAccount(id);
                            DevicesInfoDocument devicesInfoDocument = null;
                            try
                            {
                                devicesInfoDocument = boltMain.GetDeviceInfoDocument(Val.DeviceInfo.DeviceId);
                            }
                            catch (DeviceInfoNotFoundException)
                            {
                                devicesInfoDocument = boltMain.CreateDeviceInfo(new MongoDB.Main.DeviceInfo { DeviceId = Val.DeviceInfo.DeviceId, DeviceModel = Val.DeviceInfo.DeviceModel });
                            }
                            
                            // SECURITY: Check if device is banned by DeviceId only (model check removed to prevent false positives)
                            if (devicesInfoDocument.isBanned)
                            {
                                Console.WriteLine($"[GoogleEncryptedAuth] BLOCKED: Banned device attempting login - DeviceId={Val.DeviceInfo.DeviceId}");
                                ResponseMessage tests2 = new ResponseMessage
                                {
                                    RpcResponse = new RpcResponse
                                    {
                                        Id = guid,
                                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                        {
                                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                            Code = 9998 // Device banned code
                                        }
                                    }
                                };
                                tests2.RpcResponse.Exception.Property.Add("reason", "Device is banned");
                                _user.SendResponce(tests2);
                                return;
                            }
                            PlayerDocument playerDocument = null;
                            try 
                            { 
                                playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(googleAccountDocument.playerId)); 
                            }
                            catch (InvalidOperationException)
                            {
                                // Player missing, but account exists. Corrupted state.
                                Logger.LogWarn($"[GoogleEncryptedAuth] Account {id} points to missing player {googleAccountDocument.playerId}. Deleting corrupted account.");
                                boltMain.DeleteGoogleAccount(googleAccountDocument._id);
                                throw new AccountNotFoundException(); 
                            }
                            
                            // VERSION CHECK: Skip for whitelisted players
                            if (!playerDocument.bypassVersionCheck)
                            {
                                try
                                {
                                    asd = boltMain.GetHashDocument(Val.AuthGoogle.GameVersion, Val.AuthGoogle.GameId);
                                }
                                catch (HashDocumentNotFoundException)
                                {
                                    Logger.LogWarn($"[GoogleEncryptedAuth] Unknown version {Val.AuthGoogle.GameVersion} for game {Val.AuthGoogle.GameId} from account {id}");
                                    _user.SendResponce(new ResponseMessage
                                    {
                                        RpcResponse = new RpcResponse
                                        {
                                            Id = guid,
                                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                            {
                                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                                Code = 8888
                                            }
                                        }
                                    });
                                    return;
                                }
                            }
                            else
                            {
                                Console.WriteLine($"[GoogleEncryptedAuth] Version check bypassed for whitelisted player: {playerDocument.uid} (Version: {Val.AuthGoogle.GameVersion})");
                            }

                            // PLATFORM FILTER CHECK
                            {
                                var vf = boltMain.GetVersionFilter(Val.AuthGoogle.GameVersion);
                                Logger.Log($"[PlatformFilter] EncryptedAuth player={playerDocument.uid} version={Val.AuthGoogle.GameVersion} platform={Val.AuthGoogle.Platform} ({(int)Val.AuthGoogle.Platform}) filter={vf?.enabled} allowed={string.Join(",", vf?.allowedPlatforms ?? new System.Collections.Generic.List<int>())}");
                                if (vf != null && vf.enabled && !vf.allowedPlatforms.Contains((int)Val.AuthGoogle.Platform))
                                {
                                    Logger.LogWarn($"[GoogleEncryptedAuth] Platform {Val.AuthGoogle.Platform} blocked for version {Val.AuthGoogle.GameVersion} (player {playerDocument.uid})");
                                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 4003 } } });
                                    return;
                                }
                            }

                            if (playerDocument.isBanned)
                            {
                                ResponseMessage tests2 = new ResponseMessage
                                {
                                    RpcResponse = new RpcResponse
                                    {
                                        Id = guid,
                                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                        {
                                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                            Code = 9999
                                        }
                                    }
                                };
                                tests2.RpcResponse.Exception.Property.Add("uid", playerDocument.uid);
                                tests2.RpcResponse.Exception.Property.Add("banCode", playerDocument.banCode);
                                tests2.RpcResponse.Exception.Property.Add("reason", playerDocument.banReason);
                                _user.SendResponce(tests2);
                                return;
                            }



                            DateTime centuryBegin2 = new DateTime(2001, 9, 11);
                            string newtoken2 = Utils.MD5(id + (DateTime.Now.Ticks - centuryBegin2.Ticks));
                            boltMain.UpdateAccountDeviceInfo(id, new MongoDB.Main.DeviceInfo { DeviceId = Val.DeviceInfo.DeviceId, DeviceModel = Val.DeviceInfo.DeviceModel });
                            boltMain.UpdateAccountVerificationInfo(id, new Verification { ApkHash = Val.AppVerification.ApkHash, IsRooted = Val.AppVerification.IsRooted, Signature = Val.AppVerification.Signature });
                            StaticClasses.Tokens.TryAdd(newtoken2, new Token { playerId = playerDocument._id, gameVersion = Val.AuthGoogle.GameVersion, gameCode = Val.AuthGoogle.GameId });
                            BinaryValue responseValue = new ToByteMethod(typeof(GoogleAuthResponse)).ToBytes(new GoogleAuthResponse { Token = newtoken2 });
                            
                            byte[] encrypted = Utils.EncryptByte(responseValue.One.ToByteArray(), key, IV);
                            responseValue.One = ByteString.CopyFrom(encrypted);

                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Return = responseValue
                                }
                            });
                            return;
                        }
                        catch (AccountNotFoundException)
                        {
                            DateTime centuryBegin2 = new DateTime(2001, 9, 11);
                            string newtoken2 = Utils.MD5(id + (DateTime.Now.Ticks - centuryBegin2.Ticks));
                            ObjectId objId = await boltMain.CreateGoogleAccountWithPlayerAsync("GP_" + new Random().Next(1000, 10000).ToString(), (boltMain.GetLastId() + 1).ToString(), id, 1, new Verification { ApkHash = Val.AppVerification.ApkHash, IsRooted = Val.AppVerification.IsRooted, Signature = Val.AppVerification.Signature }, new MongoDB.Main.DeviceInfo { DeviceId = Val.DeviceInfo.DeviceId, DeviceModel = Val.DeviceInfo.DeviceModel }, "Creating player");



                            StaticClasses.Tokens.TryAdd(newtoken2, new Token { playerId = objId, gameVersion = Val.AuthGoogle.GameVersion, gameCode = Val.AuthGoogle.GameId });
                            BinaryValue responseValue = new ToByteMethod(typeof(GoogleAuthResponse)).ToBytes(new GoogleAuthResponse { Token = newtoken2 });
                            
                            byte[] encrypted = Utils.EncryptByte(responseValue.One.ToByteArray(), key, IV);
                            responseValue.One = ByteString.CopyFrom(encrypted);

                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Return = responseValue
                                }
                            });
                            return;
                        }

                    }
                }
            }
            
            catch (System.Exception ex4)
            {
                Logger.Exception(ex4);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 5555
                        }
                    }
                });
                return;
            }
        }
        private class Infos
        {
            public string DeviceModel { get; set; }
            public string DeviceId { get; set; }
            public string Hash { get; set; }
            public bool IsRooted { get; set; }
        }
        public async Task GoogleProtoAuthSecure(BinaryValue[] value, string guid)
        {
            try
            { 
                Console.WriteLine($"GoogleProtoAuthSecure received {value.Length} parameters");
                
                if (value.Length < 2)
                {
                    Console.WriteLine($"ERROR: Expected at least 2 parameters, got {value.Length}");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 400 // Bad request
                            }
                        }
                    });
                    return;
                }
                
                AuthGoogle authGoogle = (AuthGoogle)new FromByteMethod(typeof(AuthGoogle)).FromBytes(value[0]);
                Console.WriteLine("authGoogle " + authGoogle.AuthCode);
                AppVerification verification = (AppVerification)new FromByteMethod(typeof(AppVerification)).FromBytes(value[1]);
                
                // ВЫВОД ДЛЯ ТЕБЯ:
                Console.WriteLine("DEBUG APK HASH: " + verification.ApkHash);
                Console.WriteLine("DEBUG APK SIGNATURE: " + verification.Signature);
                
                // Support both 2-param and 3-param versions
                Infos verificationStr;
                string clientIp = _user.TcpClient.Client.RemoteEndPoint.ToString().Split(':')[0];

                if (value.Length >= 3)
                {
                    // Old format: 3 parameters with separate DeviceInfo
                    string info = Dec((string)new FromByteMethod(typeof(string)).FromBytes(value[2]));
                    verificationStr = JsonConvert.DeserializeObject<Infos>(info);
                }
                else
                {
                    // New format/0.15.0 alignment: use IP if deviceId is missing in verification
                    verificationStr = new Infos
                    {
                        Hash = verification.ApkHash,
                        IsRooted = verification.IsRooted,
                        DeviceId = !string.IsNullOrEmpty(verification.Signature) ? verification.Signature : clientIp, // 0.15.0 sometimes uses signature or IP
                        DeviceModel = "Unknown"
                    };
                    Console.WriteLine($"Using alignment mode with DeviceId: {verificationStr.DeviceId}");
                }
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create("https://accounts.google.com/o/oauth2/token");
                webRequest.Method = "POST";
                string Parameters = "code=" + authGoogle.AuthCode + "&client_id=324527154122-d6i5jb3bv71j1ktidongmancp8a3bdk6.apps.googleusercontent.com&client_secret=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&redirect_uri=urn:ietf:wg:oauth:2.0:oob&grant_type=authorization_code";
                byte[] byteArray = Encoding.UTF8.GetBytes(Parameters);
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.ContentLength = byteArray.Length;
                Stream postStream = await webRequest.GetRequestStreamAsync();
                await postStream.WriteAsync(byteArray, 0, byteArray.Length);
                postStream.Close();
                WebResponse response = webRequest.GetResponse();
                postStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(postStream);
                string responseFromServer = await reader.ReadToEndAsync();
                GooglePlusAccessToken serStatus = JsonConvert.DeserializeObject<GooglePlusAccessToken>(responseFromServer);
                if (serStatus != null)
                {
                    string accessToken = serStatus.access_token;
                    string id = (await Google2.getgoogleplususerdataSer(accessToken)).id;
                    Console.WriteLine("ID: " + id);
                    if (!string.IsNullOrEmpty(id))
                    {//GetLastId
                        BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                        HashDocument asd = null;
                        try
                        {
                            GoogleAccountDocument googleAccountDocument = boltMain.GetGoogleAccount(id);
                            DevicesInfoDocument devicesInfoDocument = null;
                            try
                            {
                                devicesInfoDocument = boltMain.GetDeviceInfoDocument(verificationStr.DeviceId);
                            }
                            catch (DeviceInfoNotFoundException)
                            {
                                devicesInfoDocument = boltMain.CreateDeviceInfo(new MongoDB.Main.DeviceInfo { DeviceId = verificationStr.DeviceId, DeviceModel = verificationStr.DeviceModel });
                            }
                            

                            if (devicesInfoDocument.isBanned)
                            {
                                Console.WriteLine($"[GoogleProtoAuthSecure] BLOCKED: Banned device attempting login - DeviceId={verificationStr.DeviceId}");
                                _user.SendResponce(new ResponseMessage
                                {
                                    RpcResponse = new RpcResponse
                                    {
                                        Id = guid,
                                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                        {
                                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                            Code = 9998 
                                        }
                                    }
                                });
                                return;
                            }
                            PlayerDocument playerDocument = null;
                            try 
                            { 
                                playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(googleAccountDocument.playerId)); 
                            }
                            catch (InvalidOperationException)
                            {

                                Logger.LogWarn($"[GoogleProtoAuthSecure] Account {id} points to missing player {googleAccountDocument.playerId}. Deleting corrupted account.");
                                boltMain.DeleteGoogleAccount(googleAccountDocument._id);
                                throw new AccountNotFoundException(); 
                            }
                            

                            if (!playerDocument.bypassVersionCheck)
                            {
                                try
                                {
                                    asd = boltMain.GetHashDocument(authGoogle.GameVersion, authGoogle.GameId);
                                }
                                catch (HashDocumentNotFoundException)
                                {
                                    Logger.LogWarn($"[GoogleProtoAuthSecure] Unknown version {authGoogle.GameVersion} for game {authGoogle.GameId} from account {id}");
                                    _user.SendResponce(new ResponseMessage
                                    {
                                        RpcResponse = new RpcResponse
                                        {
                                            Id = guid,
                                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                            {
                                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                                Code = 8888
                                            }
                                        }
                                    });
                                    return;
                                }
                            }
                            else
                            {
                                Console.WriteLine($"[GoogleProtoAuthSecure] Version check bypassed for whitelisted player: {playerDocument.uid} (Version: {authGoogle.GameVersion})");
                            }

                            // PLATFORM FILTER CHECK
                            {
                                var vf = boltMain.GetVersionFilter(authGoogle.GameVersion);
                                Logger.Log($"[PlatformFilter] ProtoAuth player={playerDocument.uid} version={authGoogle.GameVersion} platform={authGoogle.Platform} ({(int)authGoogle.Platform}) filter={vf?.enabled} allowed={string.Join(",", vf?.allowedPlatforms ?? new System.Collections.Generic.List<int>())}");
                                if (vf != null && vf.enabled && !vf.allowedPlatforms.Contains((int)authGoogle.Platform))
                                {
                                    Logger.LogWarn($"[GoogleProtoAuthSecure] Platform {authGoogle.Platform} blocked for version {authGoogle.GameVersion} (player {playerDocument.uid})");
                                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 4003 } } });
                                    return;
                                }
                            }

                            if (playerDocument.isBanned)
                            {
                                ResponseMessage tests2 = new ResponseMessage
                                {
                                    RpcResponse = new RpcResponse
                                    {
                                        Id = guid,
                                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                        {
                                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                            Code = 9999
                                        }
                                    }
                                };
                                tests2.RpcResponse.Exception.Property.Add("uid", playerDocument.uid);
                                tests2.RpcResponse.Exception.Property.Add("banCode", playerDocument.banCode.ToString());
                                tests2.RpcResponse.Exception.Property.Add("reason", playerDocument.banReason);
                                _user.SendResponce(tests2);
                                return;
                            }

                            // ANTICHEAT CHECK: Block players without active anticheat
                            if (authGoogle.Platform != Platform.Ios && playerDocument.anticheat != 1)
                            {
                                Logger.LogWarn($"[GoogleProtoAuthSecure] BLOCKED: Player {playerDocument.uid} attempted login without anticheat (status={playerDocument.anticheat})");
                                _user.SendResponce(new ResponseMessage
                                {
                                    RpcResponse = new RpcResponse
                                    {
                                        Id = guid,
                                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                        {
                                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                            Code = 7777 // Anticheat not running
                                        }
                                    }
                                });
                                return;
                            }

                            DateTime centuryBegin2 = new DateTime(2001, 9, 11);
                            string newtoken2 = Utils.MD5(id + (DateTime.Now.Ticks - centuryBegin2.Ticks));
                            boltMain.UpdateAccountDeviceInfo(id, new MongoDB.Main.DeviceInfo { DeviceId = verificationStr.DeviceId, DeviceModel = verificationStr.DeviceModel });
                            boltMain.UpdateAccountVerificationInfo(id, new Verification { ApkHash = verificationStr.Hash, IsRooted = verificationStr.IsRooted, Signature = verification.ApkHash });
                            StaticClasses.Tokens.TryAdd(newtoken2, new Token { playerId = playerDocument._id, gameVersion = authGoogle.GameVersion, gameCode = authGoogle.GameId });
                            
                            BinaryValue valuee = new ToByteMethod(typeof(GoogleAuthResponse)).ToBytes(new GoogleAuthResponse { Token = newtoken2 });
                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Return = valuee
                                }
                            });
                            return;
                        }
                        catch (AccountNotFoundException)
                        {
                            DateTime centuryBegin2 = new DateTime(2001, 9, 11);
                            string newtoken2 = Utils.MD5(id + (DateTime.Now.Ticks - centuryBegin2.Ticks));
                            ObjectId objId = await boltMain.CreateGoogleAccountWithPlayerAsync("GP_" + new Random().Next(1000, 10000).ToString(), (boltMain.GetLastId() + 1).ToString(), id, 1, new Verification { ApkHash = verificationStr.Hash, IsRooted = verificationStr.IsRooted, Signature = verification.ApkHash }, new MongoDB.Main.DeviceInfo { DeviceId = verificationStr.DeviceId, DeviceModel = verificationStr.DeviceModel }, "Creating player");


                            StaticClasses.Tokens.TryAdd(newtoken2, new Token { playerId = objId, gameVersion = authGoogle.GameVersion, gameCode = authGoogle.GameId });
                            BinaryValue valueee = new ToByteMethod(typeof(GoogleAuthResponse)).ToBytes(new GoogleAuthResponse { Token = newtoken2 });
                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Return = valueee
                                }
                            });
                            return;
                        }

                    }
                }
            }

            catch (System.Exception ex4)
            {
                Logger.Exception(ex4);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 5555
                        }
                    }
                });
                return;
            }
        }
        public override void Invoke(RpcRequest request)
        {
            throw new NotImplementedException();
        }

        public class GoogleUserOutputData
        {
            public string id { get; set; }
            public string name { get; set; }
            public string given_name { get; set; }
            public string email { get; set; }
            public string picture { get; set; }
        }
        public class Google2
        {
            public static async Task<GoogleUserOutputData> getgoogleplususerdataSer(string access_token)
            {
                GoogleUserOutputData result = null;
                try
                {
                    HttpClient client = new HttpClient();
                    var urlProfile = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + access_token;

                    client.CancelPendingRequests();
                    HttpResponseMessage output = await client.GetAsync(urlProfile);

                    if (output.IsSuccessStatusCode)
                    {
                        string outputData = await output.Content.ReadAsStringAsync();
                        GoogleUserOutputData serStatus = JsonConvert.DeserializeObject<GoogleUserOutputData>(outputData);

                        if (serStatus != null)
                        {
                            return serStatus;
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    return result;
                }
                return result;
            }
        }
        public class GooglePlusAccessToken
        {
            public string access_token { get; set; }
            public string token_type { get; set; }
            public int expires_in { get; set; }
            public string id_token { get; set; }
            public string refresh_token { get; set; }
        }
    }

}
