using Axlebolt.RpcSupport.Protobuf;
using Axlebolt.Bolt.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using MongoDB.Bson;

namespace StandRiseServer.RpcServer.Api
{
    public class TestAuthRemoteService : RpcClass
    {
        public TestAuthRemoteService (UserService user) : base (user) {}
        protected void Auth(BinaryValue[] values, string guid)
        {
            FromByteMethod fromByteMethod = new FromByteMethod(typeof(AuthToken));
            AuthToken authToken = (AuthToken)fromByteMethod.FromBytes(values[0]);
            BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
            TestAccountDocument testAccountDocument = boltMain.GetTestAccount(authToken.AuthCode);
            DateTime centuryBegin2 = new DateTime(2001, 9, 11);
            string newtoken2 = Utils.MD5(authToken.AuthCode + (DateTime.Now.Ticks - centuryBegin2.Ticks));
            StaticClasses.Tokens.TryAdd(newtoken2, new Token { playerId = ObjectId.Parse(testAccountDocument.playerId), gameCode = authToken.GameId, gameVersion = authToken.GameVersion });
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new ToByteMethod(typeof(string)).ToBytes(newtoken2)
                }
            });
        }
        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "protoAuth") Auth(request.Params.ToArray(), request.Id);
        }
    }
}
