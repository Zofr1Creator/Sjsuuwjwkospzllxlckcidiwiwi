using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Protobuf;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Game;
using MongoDB.Bson;

namespace StandRiseServer.RpcServer.Api
{
    public class FriendsRemoteService : RpcClass
    {
        public FriendsRemoteService(UserService user) : base(user)
        {
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private void SendResponse(string guid, IMessage response)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { One = response.ToByteString() }
                }
            });
        }

        public async Task getAvatars(BinaryValue[] value, string guid)
        {
            FromByteMethod from = new FromByteMethod(typeof(string[]));
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                string[] ids = (string[])from.FromBytes(value[0]);
                var avatars = BoltGameDatabaseProvider.Instance.GetAvatars(ids);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(AvatarBinary[])).ToBytes(avatars)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task GetPlayerFriendsIds(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                EnumFromByteMethod from = new EnumFromByteMethod(typeof(RelationshipStatus[]));
                RelationshipStatus[] statuses = (RelationshipStatus[])from.FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                
                List<string> playerIds = friendDocuments
                    .Where(a => statuses.Contains(a.relationshipStatus.GetRelationshipStatus(a.playerInitiatorId == Id)))
                    .Select(a => a.playerInitiatorId == Id ? a.playerId : a.playerInitiatorId)
                    .ToList();

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(string[])).ToBytes(playerIds.ToArray())
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task GetPlayerFriends(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                try
                {
                    BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                    EnumFromByteMethod from = new EnumFromByteMethod(typeof(RelationshipStatus[]));
                    RelationshipStatus[] statuses = (RelationshipStatus[])from.FromBytes(values[0]);
                    int page = (int)new FromByteMethod(typeof(int)).FromBytes(values[1]);
                    int size = (int)new FromByteMethod(typeof(int)).FromBytes(values[2]);
                
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                var filtered = friendDocuments
                    .Where(a => statuses.Contains(a.relationshipStatus.GetRelationshipStatus(a.playerInitiatorId == Id)))
                    .ToList();

                var paged = filtered.Skip(page * size).Take(size).ToList();
                List<PlayerFriend> playerFriends = new List<PlayerFriend>();
                
                foreach (var doc in paged)
                {
                    playerFriends.Add(doc.GetPlayerFriend(Id));
                }

                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Return = new ToByteMethod(typeof(PlayerFriend[])).ToBytes(playerFriends.ToArray())
                        }
                    });
                    return;
                }
                catch (System.Exception)
                {
                    SendError(guid, 500);
                    return;
                }
            }
            SendError(guid, 401);
        }
        protected async Task GetPlayerFriendById(string playerId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDoc = await boltMain.GetPlayerDocumentAsync(ObjectId.Parse(playerId));
                PlayerFriend friend = playerDoc.GetPlayerFriend(Id);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(PlayerFriend)).ToBytes(friend)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task SendFriendRequest(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                
                if (Id == friendId)
                {
                    SendError(guid, 400);
                    return;
                }

                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                RelationshipStatus resultStatus = RelationshipStatus.RequestInitiator;
                var me = await BoltMainDatabaseProvider.Instance.GetPlayerDocumentAsync(ObjectId.Parse(Id));

                if (friendDocument == null)
                {
                    friendDocument = boltGame.CreatePlayerFriendDocument(new FriendDocument { playerId = friendId, playerInitiatorId = Id, relationshipStatus = RelationshipStatusCustom.Request });
                    if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                    {
                        eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onNewFriendshipRequest", new object[] { me.GetPlayerFriend(friendId) });
                    }
                }
                else 
                {
                    if (friendDocument.relationshipStatus == RelationshipStatusCustom.Friend)
                    {
                        resultStatus = RelationshipStatus.Friend;
                    }
                    else if (friendDocument.relationshipStatus == RelationshipStatusCustom.Blocked)
                    {
                        if (friendDocument.playerInitiatorId != Id)
                        {
                            SendError(guid, 3102); // Blocked by them
                            return;
                        }
                        // If blocked by me, we might want to unblock, but for now just error
                        SendError(guid, 400);
                        return;
                    }
                    else if (friendDocument.relationshipStatus == RelationshipStatusCustom.Request)
                    {
                        if (friendDocument.playerInitiatorId != Id)
                        {
                            // They requested me, I request them -> Friends!
                            friendDocument.relationshipStatus = RelationshipStatusCustom.Friend;
                            boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                            resultStatus = RelationshipStatus.Friend;
                            
                            if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                            {
                                eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onFriendAdded", new object[] { me.GetPlayerFriend(friendId) });
                            }
                        }
                        else 
                        {
                            // Already requested by me
                            resultStatus = RelationshipStatus.RequestInitiator;
                        }
                    }
                    else // None or Ignored
                    {
                        friendDocument.playerInitiatorId = Id;
                        friendDocument.playerId = friendId;
                        friendDocument.relationshipStatus = RelationshipStatusCustom.Request;
                        boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                        
                        if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onNewFriendshipRequest", new object[] { me.GetPlayerFriend(friendId) });
                        }
                    }
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(resultStatus)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task AcceptFriendRequest(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null || friendDocument.relationshipStatus != RelationshipStatusCustom.Request || friendDocument.playerInitiatorId == Id)
                {
                    SendError(guid, 500);
                    return;
                }

                friendDocument.relationshipStatus = RelationshipStatusCustom.Friend;
                boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                
                var me = await BoltMainDatabaseProvider.Instance.GetPlayerDocumentAsync(ObjectId.Parse(Id));
                if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                {
                    eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onFriendAdded", new object[] { me.GetPlayerFriend(friendId) });
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.Friend)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task IgnoreFriendRequest(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null || friendDocument.playerInitiatorId == Id)
                {
                    SendError(guid, 500);
                    return;
                }

                friendDocument.relationshipStatus = RelationshipStatusCustom.Ignored;
                boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.Ignored)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task RevokeFriendRequest(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null || friendDocument.playerId == Id)
                {
                    SendError(guid, 500);
                    return;
                }

                friendDocument.relationshipStatus = RelationshipStatusCustom.None;
                boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                
                if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                {
                    var me = await BoltMainDatabaseProvider.Instance.GetPlayerDocumentAsync(ObjectId.Parse(Id));
                    eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onRevokeFriendshipRequest", new object[] { me.GetPlayerFriend(friendId) });
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.None)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task UnblockFriend(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null || friendDocument.playerId == Id)
                {
                    SendError(guid, 500);
                    return;
                }

                friendDocument.relationshipStatus = RelationshipStatusCustom.None;
                boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.None)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task RemoveFriend(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null)
                {
                    SendError(guid, 404);
                    return;
                }

                friendDocument.relationshipStatus = RelationshipStatusCustom.None;
                boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                
                if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                {
                    eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onFriendRemoved", new object[] { Id });
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.None)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task BlockFriend(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                string friendId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                FriendDocument friendDocument = friendDocuments.FirstOrDefault(a => a.playerId == friendId || a.playerInitiatorId == friendId);
                
                if (friendDocument == null)
                {
                    friendDocument = boltGame.CreatePlayerFriendDocument(new FriendDocument { playerId = friendId, playerInitiatorId = Id, relationshipStatus = RelationshipStatusCustom.Blocked });
                }
                else
                {
                    if (friendDocument.playerInitiatorId == friendId)
                    {
                        string play = friendDocument.playerId;
                        string initiatior = friendDocument.playerInitiatorId;
                        friendDocument.playerId = initiatior;
                        friendDocument.playerInitiatorId = play;
                    }
                    friendDocument.relationshipStatus = RelationshipStatusCustom.Blocked;
                    boltGame.UpdatePlayerFriendDocument(Id, friendId, friendDocument);
                    
                    if (StaticClasses.EventSenders.TryGetValue(friendId, out var eventSenders))
                    {
                        eventSenders.FirstOrDefault(a => a is FriendsRemoteEventSender)?.SendEvent("onFriendRemoved", new object[] { Id });
                    }
                }

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new EnumToByteMethod(typeof(RelationshipStatus)).ToBytes(RelationshipStatus.Blocked)
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task SearchPlayers(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                string value = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                int page = (int)new FromByteMethod(typeof(int)).FromBytes(values[1]);
                int size = (int)new FromByteMethod(typeof(int)).FromBytes(values[2]);
                
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                var players = boltMain.GetPlayersDocumentsByUid(value);
                
                List<PlayerFriend> playerFriends = new List<PlayerFriend>();
                foreach (var a in players)
                {
                    FriendDocument friend = friendDocuments.FirstOrDefault(b => b.playerId == a._id.ToString() || b.playerInitiatorId == a._id.ToString());
                    if (friend != null)
                        playerFriends.Add(friend.GetPlayerFriend(Id));
                    else
                        playerFriends.Add(a.GetPlayerFriend());
                }

                var result = playerFriends.Skip(page * size).Take(size);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new ToByteMethod(typeof(PlayerFriend[])).ToBytes(result.ToArray())
                    }
                });
                return;
            }
            SendError(guid, 401);
        }
        protected async Task GetOnlineStatus(BinaryValue[] values, string guid)
        {
            string playerId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
            Axlebolt.Bolt.Protobuf.OnlineStatus result = Axlebolt.Bolt.Protobuf.OnlineStatus.StateOffline;
            
            if (StaticClasses.PlayersStatus.TryGetValue(playerId, out var status))
            {
                result = (Axlebolt.Bolt.Protobuf.OnlineStatus)status.onlineStatus;
            }
            
            _user.SendResponce(new ResponseMessage 
            { 
                RpcResponse = new RpcResponse 
                { 
                    Id = guid, 
                    Return = new EnumToByteMethod(typeof(Axlebolt.Bolt.Protobuf.OnlineStatus)).ToBytes(result) 
                } 
            });
        }

        protected async Task GetPlayerFriendsCount(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltGame = BoltGameDatabaseProvider.Instance;
                EnumFromByteMethod from = new EnumFromByteMethod(typeof(RelationshipStatus[]));
                RelationshipStatus[] statuses = (RelationshipStatus[])from.FromBytes(values[0]);
                List<FriendDocument> friendDocuments = await boltGame.GetPlayerFriends(Id);
                
                long count = friendDocuments.Count(a => statuses.Contains(a.relationshipStatus.GetRelationshipStatus(a.playerInitiatorId == Id)));
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(long)).ToBytes(count) } });
                return;
            }
            SendError(guid, 401);
        }

        protected async Task GetPlayersCount(BinaryValue[] values, string guid)
        {
            string value = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
            long count = await BoltMainDatabaseProvider.Instance.GetPlayersCountAsync(value);
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(long)).ToBytes(count) } });
        }

        protected async Task GetPlayer(BinaryValue[] values, string guid)
        {
            string playerId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
            PlayerDocument playerDoc = await BoltMainDatabaseProvider.Instance.GetPlayerDocumentAsync(ObjectId.Parse(playerId));
            if (playerDoc != null)
            {
                SendResponse(guid, playerDoc.GetPlayer());
            }
            else
            {
                SendError(guid, 404);
            }
        }

        public override async Task InvokeAsync(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getAvatars":
                    await getAvatars(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerFriendsIds":
                    await GetPlayerFriendsIds(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerFriends":
                    await GetPlayerFriends(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerFriendById":
                case "getPlayerFriend":
                    await GetPlayerFriendById((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), request.Id);
                    break;
                case "searchPlayers":
                    await SearchPlayers(request.Params.ToArray(), request.Id);
                    break;
                case "blockFriend":
                    await BlockFriend(request.Params.ToArray(), request.Id);
                    break;
                case "removeFriend":
                    await RemoveFriend(request.Params.ToArray(), request.Id);
                    break;
                case "unblockFriend":
                    await UnblockFriend(request.Params.ToArray(), request.Id);
                    break;
                case "revokeFriendRequest":
                    await RevokeFriendRequest(request.Params.ToArray(), request.Id);
                    break;
                case "ignoreFriendRequest":
                    await IgnoreFriendRequest(request.Params.ToArray(), request.Id);
                    break;
                case "acceptFriendRequest":
                    await AcceptFriendRequest(request.Params.ToArray(), request.Id);
                    break;
                case "sendFriendRequest":
                    await SendFriendRequest(request.Params.ToArray(), request.Id);
                    break;
                case "getOnlineStatus":
                    await GetOnlineStatus(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerFriendsCount":
                    await GetPlayerFriendsCount(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayersCount":
                    await GetPlayersCount(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayer":
                    await GetPlayer(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }
    }
    public class FriendsRemoteEventSender : IEventSender
    {
        private UserService User { get; set; }
        public string eventListenerName { get; set; } = "FriendsRemoteEventListener";

        public FriendsRemoteEventSender(UserService user) { User = user; }
        protected void OnFriendRemoved(object[] param)
        {
            string playerId = (string)param[0];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onFriendRemoved", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
            User.SendResponce(responseMessage);
        }
        protected void OnFriendAdded(object[] param)
        {
            PlayerFriend player = (PlayerFriend)param[0];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onFriendAdded", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(player));
            User.SendResponce(responseMessage);
        }
        protected void OnFriendAvatarChanged(object[] param)
        {
            string playerId = (string)param[0];
            string avatarId = (string)param[1];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onFriendAvatarChanged", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(avatarId));
            User.SendResponce(responseMessage);
        }

        protected void OnPlayerStatusChanged(object[] param)
        {
            string playerId = (string)param[0];
            Axlebolt.Bolt.Protobuf.PlayerStatus playerStatus = (Axlebolt.Bolt.Protobuf.PlayerStatus)param[1];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onPlayerStatusChanged", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(Axlebolt.Bolt.Protobuf.PlayerStatus)).ToBytes(playerStatus));
            User.SendResponce(responseMessage);
        }
        protected void OnNewFriendshipRequest(object[] param)
        {
            PlayerFriend player = (PlayerFriend)param[0];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onNewFriendshipRequest", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(player));
            User.SendResponce(responseMessage);
        }
        protected void OnRevokeFriendshipRequest(object[] param)
        {
            PlayerFriend player = (PlayerFriend)param[0];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onRevokeFriendshipRequest", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(player));
            User.SendResponce(responseMessage);
        }
        protected void OnFriendNameChanged(object[] param)
        {
            string playerId = (string)param[0];
            string newName = (string)param[1];
            ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onFriendNameChanged", ListenerName = eventListenerName } };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(newName));
            User.SendResponce(responseMessage);
        }
        public void SendEvent(string eventName, object[] param)
        {
            if (eventName == "onFriendNameChanged") OnFriendNameChanged(param);
            else if (eventName == "onRevokeFriendshipRequest") OnRevokeFriendshipRequest(param);
            else if (eventName == "onNewFriendshipRequest") OnNewFriendshipRequest(param);
            else if (eventName == "onPlayerStatusChanged") OnPlayerStatusChanged(param);
            else if (eventName == "onFriendAvatarChanged") OnFriendAvatarChanged(param);
            else if (eventName == "onFriendAdded") OnFriendAdded(param);
            else if (eventName == "onFriendRemoved") OnFriendRemoved(param);
        }
    }
}
