using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.RpcServer;

namespace StandRiseServer.RpcServer.Api
{
    public class MessagesRemoteEventSender : IEventSender
    {
        private UserService User { get; set; }
        public string eventListenerName { get; set; } = "MessagesRemoteEventListener";

        public MessagesRemoteEventSender(UserService user) { User = user; }

        protected void OnMsgFromFriend(object[] param)
        {
            UserMessage userMessage = (UserMessage)param[0];
            ResponseMessage responseMessage = new ResponseMessage
            {
                EventResponse = new EventResponse
                {
                    EventName = "onMsgFromFriend",
                    ListenerName = eventListenerName
                }
            };
            responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(UserMessage)).ToBytes(userMessage));
            User.SendResponce(responseMessage);
        }

        public void SendEvent(string eventName, object[] param)
        {
            if (eventName == "onMsgFromFriend") OnMsgFromFriend(param);
        }
    }
}
