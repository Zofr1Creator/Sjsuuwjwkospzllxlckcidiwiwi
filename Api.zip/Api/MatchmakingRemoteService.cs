using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Matchmaking.Protobuf;
using Dictionary = Axlebolt.Bolt.Protobuf.Dictionary;
using LobbyType = Axlebolt.Bolt.Protobuf.LobbyType;
using StandRiseServer.MongoDB.Game;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB;
using MongoDB.Bson;
using StandRiseServer;

namespace StandRiseServer.RpcServer.Api
{
    public class MatchmakingRemoteService : RpcClass
    {
        // RpcSupport wire names: OnXxx interface methods -> onXxx (same as onFriendAdded / OnFriendAdded).
        internal const string EvMatchmakingProgress = "onMatchmakingProgress";
        internal const string EvMatchmakingDone = "onMatchmakingDone";
        internal const string EvMatchmakingFail = "onMatchmakingFail";
        internal const string EvPlayersConfirmed = "onPlayersConfirmed";

        // Client TaskId -> UI (verified on 0.16): 10 = lobby wait, 20 = search, 30 = match confirmation.
        internal const int TaskIdLobbyWait = 10;
        internal const int TaskIdSearching = 20;
        internal const int TaskIdConfirmation = 30;

        public MatchmakingRemoteService(UserService user) : base(user) { }

        internal static void SendRankedMatchmakingProgress(string playerId, int taskId, MatchGroup matchGroup = null)
        {
            SendMatchmakingProgress(playerId, new OnMatchmakingProgressEvent
            {
                TaskId = taskId,
                MatchGroup = matchGroup
            });
        }

        /// <summary>Lobby wait until full party is in queue; otherwise active search.</summary>
        internal static int ResolveQueuedPlayerTaskId(IReadOnlyList<string> partyMembers)
        {
            if (partyMembers == null || partyMembers.Count <= 1)
            {
                return TaskIdSearching;
            }

            bool allPartyInQueue = partyMembers.All(MatchmakingManager.IsInRankedQueue);
            return allPartyInQueue ? TaskIdSearching : TaskIdLobbyWait;
        }
        protected void SetLobbyMaxMembers(int maxMembers, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                // var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" &&
                    StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    lobby.MaxMembers = maxMembers;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyMaxMembersChanged", new object[] { (byte)maxMembers });
                        }

                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyMaxMembersChanged", new object[] { (byte)maxMembers });
                        }

                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    _user.SendResponce(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetLobbyType(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var from = new EnumFromByteMethod(typeof(Axlebolt.Bolt.Protobuf.LobbyType));
                var type = (Axlebolt.Bolt.Protobuf.LobbyType)from.FromBytes(values[0]);
                Logger.Debug($"SetLobbyType {type}");
                var boltMain = BoltMainDatabaseProvider.Instance;
                // var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    //lobby.Type = (BoltLobby.LobbyType)type;
                    StaticClasses.Lobbies[lobby.Id].Type = (BoltLobby.LobbyType)type;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyTypeChanged", new object[] { type });
                        }
                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyTypeChanged", new object[] { type });
                        }
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void SetLobbyMaxSpectators(int maxMembers, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                //var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" &&
                    StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    lobby.MaxSpectators = maxMembers;
                    foreach (BoltFriend player in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyMaxSpectatorsChanged", new object[] { (byte)maxMembers });
                        }

                    foreach (BoltFriend player in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenderss))
                        {
                            eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyMaxSpectatorsChanged", new object[] { (byte)maxMembers });
                        }

                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    _user.SendResponce(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void CreateLobbyWithSpectators(string name, LobbyType lobbyType, int maxMembers, int maxSpectators, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                var lobby = new BoltLobby(Guid.NewGuid().ToString(),
                    Id,
                    name,
                    EnumMapper<Axlebolt.Bolt.Protobuf.LobbyType, BoltLobby.LobbyType>.ToOriginal(
                        (Axlebolt.Bolt.Protobuf.LobbyType)lobbyType),
                    true, maxMembers,
                    maxSpectators,
                    new System.Collections.Concurrent.ConcurrentDictionary<string, string>(),
                    new List<BoltFriend> { playerDocument.GetBoltFriend() },
                    new List<BoltFriend>(), new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    new GameServer() { Ip = "", Port = 5055 },
                    null)
                {
                    LobbyOwnerId = Id
                };
                var stat = StaticClasses.GetOrCreatePlayerStatus(Id);
                if (!string.IsNullOrEmpty(stat.playInGame?.lobbyId))
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 401
                            }
                        }
                    });
                    return;
                }

                stat.EnsurePlayInGame("InLobby: Custom");
                stat.playInGame.lobbyId = lobby.Id;
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                StaticClasses.Lobbies.TryAdd(lobby.Id, lobby);
                Logger.Log($"[Lobby] Created lobby {lobby.Id} for player {Id}, gameState set to 'InLobby: Custom'");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    { Id = guid, Return = new ToByteMethod(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id)) }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void CreateLobby(string name, int lobbyType, int maxMembers, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                
                // ANTICHEAT CHECK: Block lobby creation without active anticheat
                if (playerDocument.anticheat != 1)
                {
                    Logger.LogWarn($"[Matchmaking] BLOCKED: Player {playerDocument.uid} attempted to create lobby without anticheat (status={playerDocument.anticheat})");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 403 // Forbidden - anticheat required
                            }
                        }
                    });
                    return;
                }
                
                var lobby = new BoltLobby(Guid.NewGuid().ToString(),
                    Id,
                    name,
                    EnumMapper<Axlebolt.Bolt.Protobuf.LobbyType, BoltLobby.LobbyType>.ToOriginal(
                        (Axlebolt.Bolt.Protobuf.LobbyType)lobbyType),
                    lobbyType == (int)LobbyType.Public ? true : false, maxMembers,
                    0,
                    new System.Collections.Concurrent.ConcurrentDictionary<string, string>(),
                    new List<BoltFriend> { playerDocument.GetBoltFriend() },
                    new List<BoltFriend>(), new List<BoltFriend>(),
                    new List<BoltFriend>(),
                    new GameServer() { Ip = "", Port = 5055 },
                    null)
                {
                    LobbyOwnerId = Id
                };
                var stat = StaticClasses.GetOrCreatePlayerStatus(Id);
                if (!string.IsNullOrEmpty(stat.playInGame?.lobbyId))
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 401
                            }
                        }
                    });
                    return;
                }

                stat.EnsurePlayInGame("InLobby: Custom");
                stat.playInGame.lobbyId = lobby.Id;
                BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                StaticClasses.Lobbies.TryAdd(lobby.Id, lobby);
                Console.WriteLine($"[Lobby] Created lobby {lobby.Id} for player {Id}, gameState set to 'InLobby: Custom'");
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    { Id = guid, Return = new ToByteMethod(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id)) }
                });
                return;
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetLobbyData(Dictionary dictionary, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                //PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    Dictionary<string, string> dictionar = new Dictionary<string, string>(lobby.Data);
                    foreach (KeyValuePair<string, string> item in dictionary.Content)
                    {
                        if (string.IsNullOrEmpty(item.Value))
                        {
                            dictionar.Remove(item.Key);
                        }
                        else
                        {
                            dictionar[item.Key] = item.Value;
                        }
                    }
                    lobby.Data = dictionar;
                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyDataChanged", new object[] { dictionary });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyDataChanged", new object[] { dictionary });
                        }
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SetLobbyOwner(string playerId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                var boltMain = BoltMainDatabaseProvider.Instance;
                //var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                var stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" &&
                    StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out var lobby))
                {
                    lobby.AddLobbyMember(lobby.LobbyOwner);
                    lobby.LobbyOwnerId = playerId;
                    lobby.TryRemoveMember(playerId);
                    lobby.TryRemoveSpectator(playerId);
                    foreach (var player in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                        }

                    foreach (var player in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                .SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                        }

                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    _user.SendResponce(new ResponseMessage
                    { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });

        }
        protected void GetLobbyOwner(string lobbyId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                if (StaticClasses.Lobbies.TryGetValue(lobbyId, out var lobby))
                {
                    var owner = lobby.LobbyOwner;
                    var protoOwner = FriendHelper.GetPlayer(owner.GetPlayerDocument());
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        { Id = guid, Return = new ToByteMethod(typeof(Axlebolt.Bolt.Protobuf.Player)).ToBytes(protoOwner) }
                    });
                }
            }
        }
        protected void SetLobbyJoinable(bool joinable, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                //PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    lobby.Joinable = joinable;
                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyJoinableChanged", new object[] { joinable });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyJoinableChanged", new object[] { joinable });
                        }
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        protected void SendLobbyChatMsg(string message, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                //Logger.Debug($"SendLobbyChatMsg {message} by {PlayerId}");
                var boltMain = BoltMainDatabaseProvider.Instance;
                //var playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    Async(() =>
                    {
                        foreach (BoltFriend player in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                            {
                                eventSenders[1].SendEvent("onLobbyChatMessage", new object[] { Id, message });
                            }
                        foreach (BoltFriend player in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(player.Id, out var eventSenders))
                            {
                                eventSenders[1].SendEvent("onLobbyChatMessage", new object[] { Id, message });
                            }
                    });
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
        }
        protected void LeaveLobby(string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                // PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    string lobbyId = stat.playInGame.lobbyId;
                    stat.playInGame.lobbyId = "";
                    stat.playInGame.gameState = "Online";
                    BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                    Logger.Log($"[Lobby] Player {Id} left lobby {lobbyId}, gameState set to 'Online'");
                    lobby.TryRemoveMember(Id);
                    lobby.TryRemoveSpectator(Id);
                    if (lobby.LobbyMembers.Length == 0)
                    {
                        StaticClasses.Lobbies.TryRemove(lobby.Id, out BoltLobby _);
                        _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                        return;
                    }
                    if (lobby.LobbyOwnerId == Id)
                    {
                        lobby.LobbyOwnerId = lobby.LobbyMembers.First().Id;
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                            {
                                eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                            {
                                eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyOwnerChanged", new object[] { lobby.LobbyOwnerId });
                            }
                    }
                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    foreach (BoltFriend playerId in lobby.LobbyMembers)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onPlayerLeftLobby", new object[] { Id });
                        }
                    foreach (BoltFriend playerId in lobby.LobbySpectators)
                        if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenders))
                        {
                            eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onPlayerLeftLobby", new object[] { Id });
                        }
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void InvitePlayerToLobby(string invitedPlayerId, Axlebolt.Bolt.Protobuf.LobbyPlayerType playerType, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerDocument playerInvited = boltMain.GetPlayerDocument(ObjectId.Parse(invitedPlayerId));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];

                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    bool invitedOnline = StaticClasses.EventSenders.TryGetValue(invitedPlayerId, out List<IEventSender> eventSendersCheck);
                    if (invitedOnline)
                    {
                        var mmSender = eventSendersCheck.FirstOrDefault(a => a as MatchmakingEventSender != null);
                    }

                    if (playerType == Axlebolt.Bolt.Protobuf.LobbyPlayerType.Member || playerType == Axlebolt.Bolt.Protobuf.LobbyPlayerType.Any)
                    {
                        lobby.AddLobbyMemberInvite(playerInvited.GetBoltFriend());
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                // Use GetPlayerFriendFast to avoid blocking DB calls
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewPlayerInvitedToLobby", new object[] { Id, playerInvited.GetPlayerFriendFast() });
                            }
                        
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                // Use GetPlayerFriendFast to avoid blocking DB calls
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewPlayerInvitedToLobby", new object[] { Id, playerInvited.GetPlayerFriendFast() });
                            }
                        
                        if (StaticClasses.EventSenders.TryGetValue(invitedPlayerId, out List<IEventSender> eventSenders))
                        {
                            var mmSender = eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null);
                            if (mmSender != null)
                            {
                                // Use GetPlayerFriendFast() which doesn't make DB calls for clan info
                                var senderFriend = playerDocument.GetPlayerFriendFast();
                                mmSender.SendEvent("onReceivedInviteToLobby", new object[] { senderFriend, lobby.Id });
                            }
                            else
                            {
                                Logger.Error($"[Lobby] MatchmakingEventSender not found for player {invitedPlayerId}");
                            }
                        }
                        else
                        {
                            Logger.Error($"[Lobby] Player {invitedPlayerId} not found in EventSenders");
                        }
                    }
                    else if (playerType == Axlebolt.Bolt.Protobuf.LobbyPlayerType.Spectator)
                    {
                        lobby.AddLobbySpectatorInvite(playerInvited.GetBoltFriend());
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderse))
                            {
                                // Use GetPlayerFriendFast to avoid blocking DB calls
                                eventSenderse.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewSpectatorInvitedToLobby", new object[] { Id, playerInvited.GetPlayerFriendFast() });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderse))
                            {
                                // Use GetPlayerFriendFast to avoid blocking DB calls
                                eventSenderse.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewSpectatorInvitedToLobby", new object[] { Id, playerInvited.GetPlayerFriendFast() });
                            }
                        if (StaticClasses.EventSenders.TryGetValue(invitedPlayerId, out List<IEventSender> eventSenders))
                        {
                            var mmSender = eventSenders.FirstOrDefault(a => a as MatchmakingEventSender != null);
                            if (mmSender != null)
                            {
                                // Use GetPlayerFriendFast() which doesn't make DB calls for clan info
                                var senderFriend = playerDocument.GetPlayerFriendFast();
                                mmSender.SendEvent("onReceivedSpectatorInviteToLobby", new object[] { senderFriend, lobby.Id });
                            }
                            else
                            {
                                Logger.Error($"[Lobby] MatchmakingEventSender not found for player {invitedPlayerId}");
                            }
                        }
                        else
                        {
                            Logger.Error($"[Lobby] Player {invitedPlayerId} not found in EventSenders");
                        }
                    }
                    StaticClasses.Lobbies[lobby.Id] = lobby;
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void JoinLobby(string lobbyId, Axlebolt.Bolt.Protobuf.LobbyPlayerType playerType, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (StaticClasses.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
                {
                    if (lobby.Joinable)
                    {
                        if ((lobby.LobbyMembers.Length + 1) == lobby.MaxMembers)
                        {
                            _user.SendResponce(new ResponseMessage
                            {
                                RpcResponse = new RpcResponse
                                {
                                    Id = guid,
                                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                    {
                                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                        Code = 5006
                                    }
                                }
                            });
                            return;
                        }
                        bool canJoin = lobby.Type == BoltLobby.LobbyType.Public
                            || (lobby.Type == BoltLobby.LobbyType.FriendsOnly && playerDocument.IsContainsFriend(lobby.LobbyOwnerId))
                            || (lobby.Type == BoltLobby.LobbyType.Private && (lobby.IsMemberInvited(Id) || lobby.IsSpectatorInvited(Id)));

                        if (canJoin)
                        {
                            lobby.RemoveLobbyAnyInvite(playerDocument.GetBoltFriend());

                            bool joinAsSpectator = playerType == Axlebolt.Bolt.Protobuf.LobbyPlayerType.Spectator
                                && lobby.IsSpectatorInvited(Id);

                            if (joinAsSpectator)
                            {
                                lobby.AddLobbySpectator(playerDocument.GetBoltFriend());
                                foreach (BoltFriend playerId in lobby.LobbyMembers)
                                    if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                    {
                                        eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewSpectatorJoinedLobby", new object[] { playerDocument.GetPlayerFriendFast() });
                                    }
                                foreach (BoltFriend playerId in lobby.LobbySpectators)
                                    if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                    {
                                        eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewSpectatorJoinedLobby", new object[] { playerDocument.GetPlayerFriendFast() });
                                    }
                            }
                            else
                            {
                                lobby.AddLobbyMember(playerDocument.GetBoltFriend());
                                foreach (BoltFriend playerId in lobby.LobbyMembers)
                                    if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                    {
                                        eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewPlayerJoinedLobby", new object[] { playerDocument.GetPlayerFriendFast() });
                                    }
                                foreach (BoltFriend playerId in lobby.LobbySpectators)
                                    if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                                    {
                                        eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onNewPlayerJoinedLobby", new object[] { playerDocument.GetPlayerFriendFast() });
                                    }
                            }

                            StaticClasses.Lobbies[lobby.Id] = lobby;
                            stat.playInGame.lobbyId = lobby.Id;
                            
                            // Определяем режим игры из данных лобби
                            string gameMode = "Custom";
                            if (lobby.Data.TryGetValue("GameMode", out string lobbyGameMode))
                            {
                                gameMode = lobbyGameMode;
                            }
                            stat.playInGame.gameState = $"InLobby: {gameMode}";
                            
                            BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(Id), stat);
                            Console.WriteLine($"[Lobby] Player {Id} joined lobby as {(joinAsSpectator ? "spectator" : "member")}, gameState set to 'InLobby: {gameMode}'");
                            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(Lobby)).ToBytes(lobby.ToOriginal(Id)) } });
                            return;
                        }
                    }
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 5005
                            }
                        }
                    });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 5001
                    }
                }
            });
        }
        protected void RevokePlayerInvitationToLobby(string revokedPlayerId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                //PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerDocument playerInvited = boltMain.GetPlayerDocument(ObjectId.Parse(revokedPlayerId));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    Async(() =>
                    {

                        lobby.RemoveLobbyAnyInvite(playerInvited.GetBoltFriend());
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onRevokeInviteToLobby", new object[] { Id, revokedPlayerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onRevokeInviteToLobby", new object[] { Id, revokedPlayerId });
                            }
                        StaticClasses.Lobbies[lobby.Id] = lobby;
                    });
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void RefuseInvitationToLobby(string lobbyId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));

                Console.WriteLine($"[Lobby] RefuseInvitationToLobby: player={Id}, lobbyId={lobbyId}");

                if (StaticClasses.Lobbies.TryGetValue(lobbyId, out BoltLobby lobby))
                {
                    Async(() =>
                    {
                        // Удаляем приглашение из лобби
                        lobby.RemoveLobbyAnyInvite(playerDocument.GetBoltFriend());
                        StaticClasses.Lobbies[lobby.Id] = lobby;

                        // Уведомляем всех участников лобби об отказе
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                    .SendEvent("onRefuseInviteToLobby", new object[] { Id, Id });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null)
                                    .SendEvent("onRefuseInviteToLobby", new object[] { Id, Id });
                            }

                        Console.WriteLine($"[Lobby] RefuseInvitationToLobby: player {Id} refused invite to lobby {lobbyId}, notified {lobby.LobbyMembers.Length} members");
                    });

                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
                else
                {
                    // Лобби не найдено — просто возвращаем успех (приглашение уже неактуально)
                    Console.WriteLine($"[Lobby] RefuseInvitationToLobby: lobby {lobbyId} not found, returning success");
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void SetLobbyPhotonGame(Axlebolt.Bolt.Protobuf.PhotonGame photonGame, string guid)
                {
                    if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
                    {
                        BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                        PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                        if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                        {
                            // Определяем режим игры из данных лобби
                            string gameMode = "Custom";

                            // Пытаемся извлечь GameMode из LobbyOptions JSON
                            if (lobby.Data.TryGetValue("LobbyOptions", out string lobbyOptionsJson))
                            {
                                try
                                {
                                    var lobbyOptions = System.Text.Json.JsonDocument.Parse(lobbyOptionsJson);
                                    if (lobbyOptions.RootElement.TryGetProperty("GameMode", out var gameModeElement))
                                    {
                                        gameMode = gameModeElement.GetString() ?? "Custom";
                                        Console.WriteLine($"[Lobby] Found GameMode in LobbyOptions: '{gameMode}'");
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine($"[Lobby] Failed to parse LobbyOptions JSON, using default: '{gameMode}'");
                                }
                            }
                            else if (lobby.Data.TryGetValue("GameMode", out string lobbyGameMode))
                            {
                                gameMode = lobbyGameMode;
                                Console.WriteLine($"[Lobby] Found GameMode in lobby.Data: '{gameMode}'");
                            }
                            else
                            {
                                Console.WriteLine($"[Lobby] GameMode not found in lobby.Data, using default: '{gameMode}'");
                            }

                            // Проверяем, начинается игра или заканчивается
                            bool isGameStarting = photonGame != null && !string.IsNullOrEmpty(photonGame.RoomId);
                            string newGameState = isGameStarting ? $"InGame: {gameMode}" : $"InLobby: {gameMode}";

                            Console.WriteLine($"[Lobby] SetLobbyPhotonGame called: isGameStarting={isGameStarting}, newGameState='{newGameState}', RoomId={photonGame?.RoomId ?? "NULL"}");

                            Async(() =>
                            {
                                foreach (BoltFriend member in lobby.LobbyMembers.Concat(lobby.LobbySpectators))
                                {
                                    if (StaticClasses.EventSenders.TryGetValue(member.Id, out List<IEventSender> eventSenderss))
                                    {
                                        eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onLobbyPhotonGameChanged", new object[] { photonGame });
                                    }

                                    // Обновляем статус игрока
                                    if (StaticClasses.PlayersStatus.TryGetValue(member.Id, out PlayerStatus memberStat))
                                    {
                                        // ИСПРАВЛЕНИЕ: Если игра закончилась (photonGame == null или RoomId пустой),
                                        // проверяем, остался ли игрок в лобби
                                        if (!isGameStarting)
                                        {
                                            // Если игрок все еще в лобби - статус "InLobby"
                                            // Если игрок вышел из лобби - статус "Online"
                                            if (!string.IsNullOrEmpty(memberStat.playInGame.lobbyId))
                                            {
                                                memberStat.playInGame.gameState = $"InLobby: {gameMode}";
                                                Console.WriteLine($"[Lobby] Player {member.Id} returned to lobby after game, gameState='{memberStat.playInGame.gameState}'");
                                            }
                                            else
                                            {
                                                memberStat.playInGame.gameState = "Online";
                                                Console.WriteLine($"[Lobby] Player {member.Id} left lobby after game, gameState='Online'");
                                            }
                                            memberStat.playInGame.photonGame = null;
                                        }
                                        else
                                        {
                                            // Игра начинается
                                            memberStat.playInGame.gameState = newGameState;
                                            memberStat.playInGame.photonGame = new PhotonGame
                                            {
                                                region = photonGame.Region,
                                                appVersion = photonGame.AppVersion,
                                                roomId = photonGame.RoomId
                                            };
                                            Console.WriteLine($"[Lobby] Player {member.Id} game started, gameState='{newGameState}'");
                                        }

                                        BoltMainDatabaseProvider.Instance.SetPlayerStatus(ObjectId.Parse(member.Id), memberStat);
                                    }
                                }

                                if (isGameStarting)
                                {
                                    lobby.PhotonGame = new PhotonGame
                                    {
                                        region = photonGame.Region,
                                        appVersion = photonGame.AppVersion,
                                        roomId = photonGame.RoomId
                                    };
                                }
                                else
                                {
                                    lobby.PhotonGame = null;
                                }
                            });
                            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                            return;
                        }
                    }
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 401
                            }
                        }
                    });
                }

        protected void KickPlayerFromLobby(string kickedPlayerId, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                //PlayerDocument playerDocument = boltMain.GetPlayerDocument(ObjectId.Parse(Id));
                PlayerDocument kickedPlayer = boltMain.GetPlayerDocument(ObjectId.Parse(kickedPlayerId));
                PlayerStatus stat = StaticClasses.PlayersStatus[Id];
                if (stat.playInGame.lobbyId != "" && StaticClasses.Lobbies.TryGetValue(stat.playInGame.lobbyId, out BoltLobby lobby))
                {
                    Async(() =>
                    {
                        lobby.RemoveLobbyAny(kickedPlayer.GetBoltFriend());
                        foreach (BoltFriend playerId in lobby.LobbyMembers)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onPlayerKickedFromLobby", new object[] { Id, kickedPlayerId });
                            }
                        foreach (BoltFriend playerId in lobby.LobbySpectators)
                            if (StaticClasses.EventSenders.TryGetValue(playerId.Id, out List<IEventSender> eventSenderss))
                            {
                                eventSenderss.FirstOrDefault(a => a as MatchmakingEventSender != null).SendEvent("onPlayerKickedFromLobby", new object[] { Id, kickedPlayerId });
                            }
                        StaticClasses.Lobbies[lobby.Id] = lobby;
                    });
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                    return;
                }
            }
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        // MATCHMAKING QUEUE METHODS
        
        /// <summary>
        /// Начать поиск соревновательного матча
        /// </summary>
        protected void StartRankedMatchmaking(string region, string gameMode, string[] maps, string guid, MatchmakingRequest request = null)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string? Id) && Id != null)
            {
                var playerDoc = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(Id));

                int gameModeInt;
                string mapCondition;
                List<string> partyMembers;

                if (request != null)
                {
                    (gameModeInt, region, mapCondition, partyMembers) = ResolveFromMatchmakingRequest(request, Id);
                }
                else
                {
                    gameModeInt = MapGameModeToInt(gameMode);
                    mapCondition = maps != null && maps.Length > 0 ? string.Join(",", maps) : "";
                    partyMembers = new List<string> { Id };
                }

                if (!RankedWhitelistService.IsPlayerAllowed(Id))
                {
                    Logger.LogWarn($"[Matchmaking] Ranked search denied for {Id}: not on ranked whitelist");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 403
                            }
                        }
                    });
                    return;
                }

                foreach (var memberId in partyMembers)
                {
                    if (!RankedWhitelistService.IsPlayerAllowed(memberId))
                    {
                        Logger.LogWarn($"[Matchmaking] Ranked search denied for party member {memberId}: not on ranked whitelist");
                        _user.SendResponce(new ResponseMessage
                        {
                            RpcResponse = new RpcResponse
                            {
                                Id = guid,
                                Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                                {
                                    Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                    Code = 403
                                }
                            }
                        });
                        return;
                    }
                }

                MatchmakingQueue.DequeueRanked(Id);
                if (MatchmakingManager.IsSearching(Id))
                {
                    MatchmakingManager.RemoveFromQueue(Id);
                }

                RegisterRankedMatchmakingConnection(Id, _user);
                var (success, error) = MatchmakingManager.AddToQueue(Id, gameModeInt, region, mapCondition, partyMembers);

                if (success)
                {
                    Logger.Log($"[Matchmaking] Player {Id} ({playerDoc.name}) started ranked search: mode={gameModeInt}, region={region}, party={partyMembers.Count}");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Return = new BinaryValue { IsNull = true }
                        }
                    });
                    int initialTaskId = ResolveQueuedPlayerTaskId(partyMembers);
                    SendRankedMatchmakingProgress(Id, initialTaskId);
                    Logger.Log($"[Matchmaking] Ranked UI start player={Id} TaskId={initialTaskId} partySize={partyMembers.Count}");
                }
                else
                {
                    Logger.LogWarn($"[Matchmaking] Failed to enqueue player {Id}: {error}");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 409
                            }
                        }
                    });
                }
                return;
            }
            
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        
        /// <summary>
        /// Остановить поиск соревновательного матча
        /// </summary>
        protected void StopRankedMatchmaking(string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string? Id) && Id != null)
            {
                MatchmakingQueue.DequeueRanked(Id);
                MatchmakingManager.RemoveFromQueue(Id);
                UnregisterRankedMatchmakingConnection(Id);
                Logger.Log($"[Matchmaking] Player {Id} stopped ranked search");

                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue { IsNull = true }
                    }
                });
                return;
            }
            
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        
        /// <summary>
        /// Начать поиск командного матча (Союзники)
        /// </summary>
        protected void StartTeamMatchmaking(string[] playerIds, string region, string gameMode, string[] maps, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string? Id) && Id != null)
            {
                // Проверяем что текущий игрок в списке
                if (!playerIds.Contains(Id))
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 403
                            }
                        }
                    });
                    return;
                }
                
                bool success = MatchmakingQueue.EnqueueTeam(playerIds, region, gameMode, maps);
                
                if (success)
                {
                    Logger.Log($"[Matchmaking] Team started search: {playerIds.Length} players, {gameMode} in {region}");
                    _user.SendResponce(new ResponseMessage 
                    { 
                        RpcResponse = new RpcResponse 
                        { 
                            Id = guid, 
                            Return = new BinaryValue { IsNull = true } 
                        } 
                    });
                }
                else
                {
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = guid,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 409
                            }
                        }
                    });
                }
                return;
            }
            
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }
        
        /// <summary>
        /// Остановить поиск командного матча
        /// </summary>
        protected void ConfirmRankedMatchmaking(string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string? Id) && Id != null)
            {
                MatchmakingManager.ConfirmPlayer(Id);
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue { IsNull = true }
                    }
                });
                return;
            }

            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        protected void StopTeamMatchmaking(string[] playerIds, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                bool success = MatchmakingQueue.DequeueTeam(playerIds);
                
                if (success)
                {
                    Logger.Log($"[Matchmaking] Team stopped search: {playerIds.Length} players");
                }

                _user.SendResponce(new ResponseMessage 
                { 
                    RpcResponse = new RpcResponse 
                    { 
                        Id = guid, 
                        Return = new BinaryValue { IsNull = true } 
                    } 
                });
                return;
            }
            
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = 401
                    }
                }
            });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getInvitesToLobby") _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = request.Id, Return = new ToByteMethod(typeof(LobbyInvite[])).ToBytes(new LobbyInvite[0]) } });
            else if (request.MethodName == "kickPlayerFromLobby") KickPlayerFromLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "setLobbyPhotonGame") SetLobbyPhotonGame((Axlebolt.Bolt.Protobuf.PhotonGame)new FromByteMethod(typeof(Axlebolt.Bolt.Protobuf.PhotonGame)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "revokePlayerInvitationToLobby") RevokePlayerInvitationToLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "refuseInvitationToLobby") RefuseInvitationToLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "joinLobbyAs") JoinLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), (Axlebolt.Bolt.Protobuf.LobbyPlayerType)new EnumFromByteMethod(typeof(Axlebolt.Bolt.Protobuf.LobbyPlayerType)).FromBytes(request.Params[1]), request.Id);
            else if (request.MethodName == "invitePlayerToLobbyAs") InvitePlayerToLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), (Axlebolt.Bolt.Protobuf.LobbyPlayerType)new EnumFromByteMethod(typeof(Axlebolt.Bolt.Protobuf.LobbyPlayerType)).FromBytes(request.Params[1]), request.Id);
            else if (request.MethodName == "invitePlayerToLobby") InvitePlayerToLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), Axlebolt.Bolt.Protobuf.LobbyPlayerType.Member, request.Id);
            else if (request.MethodName == "leaveLobby") LeaveLobby(request.Id);
            else if (request.MethodName == "setLobbyJoinable") SetLobbyJoinable((bool)new FromByteMethod(typeof(bool)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "setLobbyData") SetLobbyData((Dictionary)new FromByteMethod(typeof(Dictionary)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "createLobby") CreateLobby((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[1]), (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[2]), request.Id);
            else if (request.MethodName == "createLobbyWithSpectators") CreateLobbyWithSpectators((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), (LobbyType)new EnumFromByteMethod(typeof(LobbyType)).FromBytes(request.Params[1]), (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[2]), (int)new FromByteMethod(typeof(int)).FromBytes(request.Params[3]), request.Id);
            else if (request.MethodName == "setLobbyMaxMembers") SetLobbyMaxMembers((int)new FromByteMethod(typeof(int)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "setLobbyMaxSpectators") SetLobbyMaxSpectators((int)new FromByteMethod(typeof(int)).FromBytes(request.Params[0]), request.Id);
            else if (request.MethodName == "setLobbyType") SetLobbyType(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "sendLobbyChatMsg") SendLobbyChatMsg((string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]), request.Id);
            // Ranked matchmaking start - main entry point from client
            else if (request.MethodName == "start")
            {
                try
                {
                    var mmRequest = TryParseMatchmakingRequest(request.Params);
                    if (mmRequest != null)
                    {
                        StartRankedMatchmaking(null, null, null, request.Id, mmRequest);
                    }
                    else
                    {
                        var (region, gameMode, maps) = ResolveRankedStartParams(request.Params);
                        StartRankedMatchmaking(region, gameMode, maps, request.Id);
                    }
                }
                catch (System.Exception ex)
                {
                    Logger.Error($"[Matchmaking] Failed to start ranked matchmaking: {ex.Message}");
                    _user.SendResponce(new ResponseMessage
                    {
                        RpcResponse = new RpcResponse
                        {
                            Id = request.Id,
                            Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                            {
                                Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                                Code = 500
                            }
                        }
                    });
                }
            }
            else if (request.MethodName == "cancel" || request.MethodName == "stop")
            {
                StopRankedMatchmaking(request.Id);
            }
            else if (request.MethodName == "confirm")
            {
                ConfirmRankedMatchmaking(request.Id);
            }
            // Ranked matchmaking
            else if (request.MethodName == "startRankedMatchmaking") 
            {
                string region = (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[0]);
                string gameMode = (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[1]);
                string[] maps = (string[])new FromByteMethod(typeof(string[])).FromBytes(request.Params[2]);
                StartRankedMatchmaking(region, gameMode, maps, request.Id);
            }
            else if (request.MethodName == "stopRankedMatchmaking") StopRankedMatchmaking(request.Id);
            // Team matchmaking
            else if (request.MethodName == "startTeamMatchmaking")
            {
                string[] playerIds = (string[])new FromByteMethod(typeof(string[])).FromBytes(request.Params[0]);
                string region = (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[1]);
                string gameMode = (string)new FromByteMethod(typeof(string)).FromBytes(request.Params[2]);
                string[] maps = (string[])new FromByteMethod(typeof(string[])).FromBytes(request.Params[3]);
                StartTeamMatchmaking(playerIds, region, gameMode, maps, request.Id);
            }
            else if (request.MethodName == "stopTeamMatchmaking")
            {
                string[] playerIds = (string[])new FromByteMethod(typeof(string[])).FromBytes(request.Params[0]);
                StopTeamMatchmaking(playerIds, request.Id);
            }
        }

        private (string region, string gameMode, string[] maps) ResolveRankedStartParams(IList<BinaryValue> parameters)
        {
            string region = "eu";
            string gameMode = "RankedDefuse";
            string[] maps = null;

            if (parameters == null || parameters.Count == 0)
            {
                return (region, gameMode, maps);
            }

            if (parameters.Count >= 3)
            {
                try
                {
                    region = NormalizeRegion((string)new FromByteMethod(typeof(string)).FromBytes(parameters[0]));
                    var parsedGameMode = (string)new FromByteMethod(typeof(string)).FromBytes(parameters[1]);
                    if (!string.IsNullOrWhiteSpace(parsedGameMode))
                    {
                        gameMode = parsedGameMode;
                    }

                    maps = (string[])new FromByteMethod(typeof(string[])).FromBytes(parameters[2]);
                    maps = NormalizeMaps(maps);
                }
                catch (System.Exception ex)
                {
                    Logger.LogWarn($"[Matchmaking] Failed to parse ranked matchmaking params: {ex.Message}");
                }

                return (region, gameMode, maps);
            }

            // Single parameter fallback (legacy clients)
            try
            {
                string paramStr = (string)new FromByteMethod(typeof(string)).FromBytes(parameters[0]);
                if (!string.IsNullOrWhiteSpace(paramStr))
                {
                    var lower = paramStr.Trim().ToLowerInvariant();

                    if (lower.Contains("2v2"))
                    {
                        gameMode = lower.Contains("ranked") ? "Ranked2v2Defuse" : "Team2v2Defuse";
                    }
                    else if (lower.Contains("team") || lower.Contains("ally") || lower.Contains("союз"))
                    {
                        gameMode = "TeamDefuse";
                    }

                    region = NormalizeRegion(lower);
                }
            }
            catch
            {
                try
                {
                    int paramInt = (int)new FromByteMethod(typeof(int)).FromBytes(parameters[0]);
                    gameMode = paramInt switch
                    {
                        0 => "RankedDefuse",
                        1 => "TeamDefuse",
                        2 => "Defuse",
                        _ => gameMode
                    };
                }
                catch
                {
                    // Ignore – keep defaults
                }
            }

            return (region, gameMode, maps);
        }

        private static string NormalizeRegion(string candidate)
        {
            if (string.IsNullOrWhiteSpace(candidate))
            {
                return "eu";
            }

            var normalized = candidate.Trim().ToLowerInvariant();
            if (MatchmakingQueue.AvailableRankedRegions.Contains(normalized))
            {
                return normalized;
            }

            return normalized switch
            {
                "europe" => "eu",
                "america" or "us-east" or "us-west" => "us",
                "asia-pacific" or "ap" => "asia",
                _ => "eu"
            };
        }

        private static string[] NormalizeMaps(string[] maps)
        {
            if (maps == null || maps.Length == 0)
            {
                return null;
            }

            var normalized = maps
                .Where(m => !string.IsNullOrWhiteSpace(m))
                .Select(m => m.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            return normalized.Length > 0 ? normalized : null;
        }

        private static MatchmakingRequest TryParseMatchmakingRequest(IList<BinaryValue> parameters)
        {
            if (parameters == null || parameters.Count == 0)
            {
                return null;
            }

            try
            {
                var param = parameters[0];
                if (param == null || param.IsNull)
                {
                    return null;
                }

                return (MatchmakingRequest)new FromByteMethod(typeof(MatchmakingRequest)).FromBytes(param);
            }
            catch (System.Exception ex)
            {
                Logger.LogWarn($"[Matchmaking] Failed to parse MatchmakingRequest protobuf: {ex.Message}");
                return null;
            }
        }

        private static (int gameMode, string region, string mapCondition, List<string> partyMembers) ResolveFromMatchmakingRequest(MatchmakingRequest request, string playerId)
        {
            int gameMode = 6;
            string region = "eu";
            string mapCondition = request.Filter != null && request.Filter.Conditions.Count > 0
                ? string.Join(",", request.Filter.Conditions)
                : "";
            var partyMembers = new List<string> { playerId };

            if (!string.IsNullOrWhiteSpace(request.Profile))
            {
                var profile = request.Profile.Trim();
                int lastUnderscore = profile.LastIndexOf('_');
                if (lastUnderscore > 0 && lastUnderscore < profile.Length - 1)
                {
                    var suffix = profile.Substring(lastUnderscore + 1);
                    var prefix = profile.Substring(0, lastUnderscore);
                    if (IsLikelyRegion(suffix))
                    {
                        region = NormalizeRegion(suffix);
                        profile = prefix;
                    }
                    else if (IsLikelyRegion(prefix))
                    {
                        region = NormalizeRegion(prefix);
                        profile = suffix;
                    }
                }

                gameMode = MapGameModeToInt(profile);
            }

            if (!string.IsNullOrWhiteSpace(request.GroupId) && request.GroupSize > 1 &&
                StaticClasses.Lobbies.TryGetValue(request.GroupId, out BoltLobby lobby))
            {
                partyMembers = lobby.LobbyMembers.Select(m => m.Id).Distinct().ToList();
                if (!partyMembers.Contains(playerId))
                {
                    partyMembers.Add(playerId);
                }
            }

            return (gameMode, region, mapCondition, partyMembers);
        }

        private static bool IsLikelyRegion(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            var normalized = value.Trim().ToLowerInvariant();
            return MatchmakingQueue.AvailableRankedRegions.Contains(normalized)
                || normalized is "europe" or "america" or "us-east" or "us-west" or "asia-pacific" or "ap";
        }

        private static int MapGameModeToInt(string gameMode)
        {
            if (string.IsNullOrWhiteSpace(gameMode))
            {
                return 6;
            }

            var gm = gameMode.Trim();
            if (gm.Contains("Ranked2v2", StringComparison.OrdinalIgnoreCase) ||
                gm.Contains("2v2", StringComparison.OrdinalIgnoreCase))
            {
                return 8;
            }

            if (gm.Contains("Allies", StringComparison.OrdinalIgnoreCase) ||
                gm.Contains("Team", StringComparison.OrdinalIgnoreCase) ||
                gm.Contains("Ally", StringComparison.OrdinalIgnoreCase))
            {
                return 5;
            }

            if (gm.Contains("RankedDefuse", StringComparison.OrdinalIgnoreCase) ||
                gm.Contains("Defuse", StringComparison.OrdinalIgnoreCase))
            {
                return 6;
            }

            return 6;
        }

        /// <summary>
        /// Binds ranked/mm events to the TCP connection that called start/confirm (Bolt matchmaking socket).
        /// </summary>
        internal static void RegisterRankedMatchmakingConnection(string playerId, UserService user)
        {
            EnsureRankedEventSender(playerId, user);
            Logger.Log($"[Matchmaking] Registered ranked connection for {playerId}");
        }

        internal static void UnregisterRankedMatchmakingConnection(string playerId)
        {
            StaticClasses.RankedMatchmakingConnections.TryRemove(playerId, out _);
        }

        private static void EnsureRankedEventSender(string playerId, UserService connection)
        {
            StaticClasses.RankedMatchmakingConnections[playerId] = connection;
            StaticClasses.EventSenders.AddOrUpdate(
                playerId,
                _ => new List<IEventSender> { new RankedMatchmakingEventSender(connection) },
                (_, existing) =>
                {
                    var merged = new List<IEventSender>(existing);
                    merged.RemoveAll(s => s is RankedMatchmakingEventSender);
                    merged.Add(new RankedMatchmakingEventSender(connection));
                    return merged;
                });
        }

        private static bool TrySendRankedListenerEvent(string playerId, string eventName, object evt)
        {
            if (!StaticClasses.EventSenders.TryGetValue(playerId, out var senders))
            {
                return false;
            }

            var rankedSender = senders.FirstOrDefault(s => s is RankedMatchmakingEventSender);
            if (rankedSender == null)
            {
                return false;
            }

            rankedSender.SendEvent(eventName, evt != null ? new object[] { evt } : Array.Empty<object>());
            return true;
        }

        private static void SendRankedEventOnUser(UserService user, string eventName, object evt)
        {
            if (user == null)
            {
                return;
            }

            var responseMessage = new ResponseMessage
            {
                EventResponse = new EventResponse
                {
                    EventName = eventName,
                    ListenerName = "MatchmakingRemoteListener"
                }
            };

            if (evt is Google.Protobuf.IMessage message)
            {
                responseMessage.EventResponse.Params.Add(new BinaryValue
                {
                    IsNull = false,
                    One = message.ToByteString()
                });
            }

            user.SendResponce(responseMessage);
        }

        private static void SendRankedMatchmakingEventDirect(string playerId, string eventName, object evt)
        {
            if (StaticClasses.RankedMatchmakingConnections.TryGetValue(playerId, out var mmUser))
            {
                SendRankedEventOnUser(mmUser, eventName, evt);
                return;
            }

            if (StaticClasses.MainUserServices.TryGetValue(playerId, out var mainUser))
            {
                SendRankedEventOnUser(mainUser, eventName, evt);
            }
        }

        internal static void BroadcastRankedEvent(string playerId, string eventName, object evt)
        {
            if (StaticClasses.RankedMatchmakingConnections.TryGetValue(playerId, out var mmUser))
            {
                SendRankedEventOnUser(mmUser, eventName, evt);
                return;
            }

            if (TrySendRankedListenerEvent(playerId, eventName, evt))
            {
                return;
            }

            SendRankedMatchmakingEventDirect(playerId, eventName, evt);
        }

        internal static void SendRankedMatchmakingEvent(string playerId, string eventName, object evt)
        {
            BroadcastRankedEvent(playerId, eventName, evt);
        }

        internal static void SendMatchmakingProgress(string playerId, OnMatchmakingProgressEvent progressEvent)
        {
            try
            {
                int size = ((Google.Protobuf.IMessage)progressEvent).ToByteArray().Length;
                Logger.Log($"[Matchmaking] SendMatchmakingProgress player={playerId} TaskId={progressEvent.TaskId} protoBytes={size} event={EvMatchmakingProgress}");
            }
            catch (System.Exception ex)
            {
                Logger.LogWarn($"[Matchmaking] SendMatchmakingProgress serialize failed: {ex.Message}");
            }

            BroadcastRankedEvent(playerId, EvMatchmakingProgress, progressEvent);
        }

        internal static void SendMatchmakingEvent(string playerId, string eventName, object evt)
        {
            if (StaticClasses.RankedMatchmakingConnections.ContainsKey(playerId))
            {
                SendRankedMatchmakingEvent(playerId, eventName, evt);
                return;
            }

            if (StaticClasses.EventSenders.TryGetValue(playerId, out var senders))
            {
                var sender = senders.FirstOrDefault(s => s is RankedMatchmakingEventSender);
                sender?.SendEvent(eventName, new object[] { evt });
            }
        }

        public class MatchmakingEventSender : IEventSender
        {
            private UserService User { get; set; }
            public string eventListenerName { get; set; } = "MatchmakingRemoteEventListener";

            public MatchmakingEventSender(UserService user) { User = user; }
            protected void OnLobbyDataChanged(object[] param)
            {
                Dictionary dictionary = (Dictionary)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyDataChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(Dictionary)).ToBytes(dictionary));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyJoinableChanged(object[] param)
            {
                bool dictionary = (bool)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyJoinableChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(bool)).ToBytes(dictionary));
                User.SendResponce(responseMessage);
            }
            protected void OnNewPlayerJoinedLobby(object[] param)
            {
                PlayerFriend friend = (PlayerFriend)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onNewPlayerJoinedLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(friend));
                User.SendResponce(responseMessage);
            }
            protected void OnNewSpectatorJoinedLobby(object[] param)
            {
                PlayerFriend friend = (PlayerFriend)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onNewSpectatorJoinedLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(friend));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyPhotonGameChanged(object[] param)
            {
                Axlebolt.Bolt.Protobuf.PhotonGame photonGame = (Axlebolt.Bolt.Protobuf.PhotonGame)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyPhotonGameChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(Axlebolt.Bolt.Protobuf.PhotonGame)).ToBytes(photonGame));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyChatMessage(object[] param)
            {
                string playerId = (string)param[0];
                string message = (string)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyChatMessage", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(message));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyPlayerTypeChanged(object[] param)
            {
                string playerId = (string)param[0];
                Axlebolt.Bolt.Protobuf.LobbyPlayerType type = (Axlebolt.Bolt.Protobuf.LobbyPlayerType)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyPlayerTypeChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(playerId));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(Axlebolt.Bolt.Protobuf.LobbyPlayerType)).ToBytes(type));
                User.SendResponce(responseMessage);
            }
            protected void OnNewPlayerInvitedToLobby(object[] param)
            {
                string senderId = (string)param[0];
                PlayerFriend friend = (PlayerFriend)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onNewPlayerInvitedToLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(senderId));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(friend));
                User.SendResponce(responseMessage);
            }
            protected void OnReceivedSpectatorInviteToLobby(object[] param)
            {
                PlayerFriend sender = (PlayerFriend)param[0];
                string lobbyId = (string)param[1];
                Console.WriteLine($"[MatchmakingEventSender] OnReceivedSpectatorInviteToLobby called: sender={sender?.Player?.Id}, lobbyId={lobbyId}");
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onReceivedSpectatorInviteToLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(sender));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(lobbyId));
                Console.WriteLine($"[MatchmakingEventSender] Sending onReceivedSpectatorInviteToLobby event with {responseMessage.EventResponse.Params.Count} params");
                User.SendResponce(responseMessage);
                Console.WriteLine($"[MatchmakingEventSender] Event sent successfully");
            }
            protected void OnLobbyMaxSpectatorsChanged(object[] param)
            {
                byte value = (byte)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyMaxSpectatorsChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(byte)).ToBytes(value));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyTypeChanged(object[] param)
            {
                LobbyType type = (LobbyType)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyTypeChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(LobbyType)).ToBytes(type));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyNameChanged(object[] param)
            {
                string name = (string)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyNameChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(name));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyOwnerChanged(object[] param)
            {
                string newOwnerId = (string)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyOwnerChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(newOwnerId));
                User.SendResponce(responseMessage);
            }
            protected void OnPlayerKickedFromLobby(object[] param)
            {
                string kickInitiator = (string)param[0];
                string kickedPlayerId = (string)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onPlayerKickedFromLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickInitiator));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickedPlayerId));
                User.SendResponce(responseMessage);
            }
            protected void OnNewSpectatorInvitedToLobby(object[] param)
            {
                string inviteInitiator = (string)param[0];
                PlayerFriend invitedPlayer = (PlayerFriend)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onNewSpectatorInvitedToLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(inviteInitiator));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(invitedPlayer));
                User.SendResponce(responseMessage);
            }
            protected void OnLobbyMaxMembersChanged(object[] param)
            {
                byte value = (byte)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onLobbyMaxMembersChanged", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(byte)).ToBytes(value));
                User.SendResponce(responseMessage);
            }
            protected void OnReceivedInviteToLobby(object[] param)
            {
                PlayerFriend sender = (PlayerFriend)param[0];
                string lobbyId = (string)param[1];
                Console.WriteLine($"[MatchmakingEventSender] OnReceivedInviteToLobby called");
                Console.WriteLine($"[MatchmakingEventSender] Sender: Id={sender?.Player?.Id}, Name={sender?.Player?.Name}, lobbyId={lobbyId}");
                Console.WriteLine($"[MatchmakingEventSender] Sender details: RelationshipStatus={sender?.RelationshipStatus}, LastUpdate={sender?.LastRelationshipUpdate}");
                
                if (sender == null || sender.Player == null)
                {
                    Console.WriteLine($"[MatchmakingEventSender] ERROR: sender or sender.Player is null!");
                    return;
                }
                
                // Старый формат (2 параметра) — для старых клиентов
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onReceivedInviteToLobby", ListenerName = eventListenerName } };
                var senderBytes = ProtoReflectionUtils.CreateToByteMethod(typeof(PlayerFriend)).ToBytes(sender);
                var lobbyIdBytes = ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(lobbyId);
                Console.WriteLine($"[MatchmakingEventSender] Serialized sender: {senderBytes?.One?.Length ?? 0} bytes, IsNull={senderBytes?.IsNull}");
                Console.WriteLine($"[MatchmakingEventSender] Serialized lobbyId: {lobbyIdBytes?.One?.Length ?? 0} bytes, IsNull={lobbyIdBytes?.IsNull}");
                responseMessage.EventResponse.Params.Add(senderBytes);
                responseMessage.EventResponse.Params.Add(lobbyIdBytes);
                Console.WriteLine($"[MatchmakingEventSender] EventResponse: ListenerName={responseMessage.EventResponse.ListenerName}, EventName={responseMessage.EventResponse.EventName}, ParamsCount={responseMessage.EventResponse.Params.Count}");
                Console.WriteLine($"[MatchmakingEventSender] Sending to User: Connected={User?.TcpClient?.Connected}");
                User.SendResponce(responseMessage);
                Console.WriteLine($"[MatchmakingEventSender] Event queued for sending");

                // Новый формат (1 параметр LobbyInvite) — для новых клиентов
                try
                {
                    long nowMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                    var invite = new LobbyInvite
                    {
                        LobbyId = lobbyId,
                        InviteCreator = sender,
                        Date = nowMs,
                        PlayerType = LobbyPlayerType.Member
                    };
                    var eventMsg = new OnReceivedInviteToLobbyEvent { Invite = invite };
                    var eventResponse = new ResponseMessage { EventResponse = new EventResponse { EventName = "onReceivedInviteToLobbyEvent", ListenerName = eventListenerName } };
                    eventResponse.EventResponse.Params.Add(new ToByteMethod(typeof(OnReceivedInviteToLobbyEvent)).ToBytes(eventMsg));
                    User.SendResponce(eventResponse);
                    Console.WriteLine($"[MatchmakingEventSender] onReceivedInviteToLobbyEvent also sent");
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine($"[MatchmakingEventSender] Failed to send onReceivedInviteToLobbyEvent: {ex.Message}");
                }
            }
            protected void OnPlayerLeftLobby(object[] param)
            {
                string leftPlayer = (string)param[0];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onPlayerLeftLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(leftPlayer));
                User.SendResponce(responseMessage);
            }
            protected void OnRevokeInviteToLobby(object[] param)
            {
                string kickInitiator = (string)param[0];
                string kickedPlayerId = (string)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onRevokeInviteToLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickInitiator));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickedPlayerId));
                User.SendResponce(responseMessage);
            }
            protected void OnRefuseInviteToLobby(object[] param)
            {
                string kickInitiator = (string)param[0];
                string kickedPlayerId = (string)param[1];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onRefuseInviteToLobby", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickInitiator));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(kickedPlayerId));
                User.SendResponce(responseMessage);
            }
            protected void OnMatchFound(object[] param)
            {
                string lobbyId = (string)param[0];
                string map = (string)param[1];
                string region = (string)param[2];
                ResponseMessage responseMessage = new ResponseMessage { EventResponse = new EventResponse { EventName = "onMatchFound", ListenerName = eventListenerName } };
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(lobbyId));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(map));
                responseMessage.EventResponse.Params.Add(ProtoReflectionUtils.CreateToByteMethod(typeof(string)).ToBytes(region));
                User.SendResponce(responseMessage);
            }
            public void SendEvent(string eventName, object[] param)
            {
                if (eventName == "onLobbyDataChanged") OnLobbyDataChanged(param);
                else if (eventName == "onRefuseInviteToLobby") OnRefuseInviteToLobby(param);
                else if (eventName == "onRevokeInviteToLobby") OnRevokeInviteToLobby(param);
                else if (eventName == "onPlayerLeftLobby") OnPlayerLeftLobby(param);
                else if (eventName == "onReceivedInviteToLobby") OnReceivedInviteToLobby(param);
                else if (eventName == "onLobbyMaxMembersChanged") OnLobbyMaxMembersChanged(param);
                else if (eventName == "onNewSpectatorInvitedToLobby") OnNewSpectatorInvitedToLobby(param);
                else if (eventName == "onPlayerKickedFromLobby") OnPlayerKickedFromLobby(param);
                else if (eventName == "onLobbyOwnerChanged") OnLobbyOwnerChanged(param);
                else if (eventName == "onLobbyNameChanged") OnLobbyNameChanged(param);
                else if (eventName == "onLobbyTypeChanged") OnLobbyTypeChanged(param);
                else if (eventName == "onLobbyMaxSpectatorsChanged") OnLobbyMaxSpectatorsChanged(param);
                else if (eventName == "onReceivedSpectatorInviteToLobby") OnReceivedSpectatorInviteToLobby(param);
                else if (eventName == "onNewPlayerInvitedToLobby") OnNewPlayerInvitedToLobby(param);
                else if (eventName == "onLobbyPlayerTypeChanged") OnLobbyPlayerTypeChanged(param);
                else if (eventName == "onLobbyChatMessage") OnLobbyChatMessage(param);
                else if (eventName == "onLobbyPhotonGameChanged") OnLobbyPhotonGameChanged(param);
                else if (eventName == "onNewSpectatorJoinedLobby") OnNewSpectatorJoinedLobby(param);
                else if (eventName == "onNewPlayerJoinedLobby") OnNewPlayerJoinedLobby(param);
                else if (eventName == "onLobbyJoinableChanged") OnLobbyJoinableChanged(param);
                else if (eventName == "onMatchFound") OnMatchFound(param);
            }
        }

        public class RankedMatchmakingEventSender : IEventSender
        {
            private UserService User { get; set; }
            public string eventListenerName { get; set; } = "MatchmakingRemoteListener";

            public RankedMatchmakingEventSender(UserService user) { User = user; }

            public void SendEvent(string eventName, object[] param)
            {
                ResponseMessage responseMessage = new ResponseMessage
                {
                    EventResponse = new EventResponse
                    {
                        EventName = eventName,
                        ListenerName = eventListenerName
                    }
                };

                if (param != null && param.Length > 0 && param[0] != null)
                {
                    if (param[0] is Google.Protobuf.IMessage message)
                    {
                        responseMessage.EventResponse.Params.Add(new BinaryValue
                        {
                            IsNull = false,
                            One = message.ToByteString()
                        });
                    }
                    else
                    {
                        responseMessage.EventResponse.Params.Add(
                            ProtoReflectionUtils.CreateToByteMethod(param[0].GetType()).ToBytes(param[0]));
                    }
                }

                User.SendResponce(responseMessage);
            }
        }
    }
}
