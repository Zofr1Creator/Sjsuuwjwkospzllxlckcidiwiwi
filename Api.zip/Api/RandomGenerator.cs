using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Game;

namespace StandRiseServer.RpcServer.Api;

public class RandomGenerator
{
	private Random random;

	private Dictionary<SkinValue, double> dropChances;

	private readonly Dictionary<CollectionId, double> _collectionChances = new Dictionary<CollectionId, double>();

	private readonly Dictionary<CurrencyAmount, double> _currencyChances = new Dictionary<CurrencyAmount, double>();

	private readonly Dictionary<InventoryId, double> _boxAndCaseChances = new Dictionary<InventoryId, double>();

	private readonly Dictionary<InventoryId, double> _itemsChances = new Dictionary<InventoryId, double>();

	private readonly Dictionary<InventoryId, double> _giftBoxDropChances = new Dictionary<InventoryId, double>();

	private readonly Dictionary<InventoryId, double> _caseProbabilities = new Dictionary<InventoryId, double>();

	private readonly Dictionary<InventoryId, double> _boxProbabilities = new Dictionary<InventoryId, double>();

	private readonly Dictionary<InventoryId, double> _secretProbabilities = new Dictionary<InventoryId, double>();

	public static BoltInventoryItemDefinitionDocument[] definitions;

	public static List<CurrencyAmount> Currencies = new List<CurrencyAmount>();

	public static int statTrakChance;

	public Dictionary<InventoryId, double> GiftBoxDropChances => _giftBoxDropChances;

	public RandomGenerator()
	{
		random = new Random();
		dropChances = new Dictionary<SkinValue, double>();
		if (definitions == null)
		{
			AddDefinitions(BoltGameDatabaseProvider.Instance.GetAllItemDefinitionsByType(0u).ToArray());
		}
		statTrakChance = 20;
	}

	public void AddDropChance(SkinValue itemType, double chance)
	{
		dropChances[itemType] = chance;
	}

	public void SetCollections(params CollectionId[] collections)
	{
		_collectionChances.Clear();
		if (collections == null || collections.Length == 0)
			return;

		var valid = collections.Where(c => c != CollectionId.None).ToArray();
		if (valid.Length == 0)
			return;

		double weight = 1.0 / valid.Length;
		foreach (var collection in valid)
			_collectionChances[collection] = weight;
	}

	public void AddCollectionChance(CollectionId collectionId, double chance)
	{
		if (collectionId == CollectionId.None || chance <= 0)
			return;

		if (_collectionChances.ContainsKey(collectionId))
			_collectionChances[collectionId] += chance;
		else
			_collectionChances[collectionId] = chance;
	}

	private CollectionId PickRandomCollection()
	{
		if (_collectionChances.Count == 0)
			return CollectionId.Origin;

		double total = _collectionChances.Values.Sum();
		if (total <= 0)
			return CollectionId.Origin;

		double roll = random.NextDouble() * total;
		double accumulated = 0.0;
		foreach (var entry in _collectionChances)
		{
			accumulated += entry.Value;
			if (roll < accumulated)
				return entry.Key;
		}

		return _collectionChances.Keys.Last();
	}

	public BoltInventoryItem? GetRandomDropItem()
	{
		return GetRandomItem(PickRandomCollection());
	}

	public void AddCurrencyLuckChance(CurrencyAmount currency, double chance)
	{
		Currencies.Add(currency);
		_currencyChances[currency] = chance;
	}

	public void AddBoxAndChance(InventoryId boxId, double chance)
	{
		_boxProbabilities[boxId] = chance;
	}

	public void AddCaseAndChance(InventoryId caseId, double chance)
	{
		_caseProbabilities[caseId] = 1000.0;
	}

	public void AddSkinsInGameChance(InventoryId inventoryId, double chance)
	{
		_secretProbabilities[inventoryId] = 1000.0;
	}

	public void ClearCurrencyLuckChances()
	{
		Currencies.Clear();
		_currencyChances.Clear();
	}

	public void AddItemsLuckChance(InventoryId currency, double chance)
	{
		_itemsChances[currency] = chance;
	}

	private void ClearItemsLuckChances()
	{
		_itemsChances.Clear();
	}

	public void AddGiftBox2018DropChance(InventoryId itemId, double chance)
	{
		_giftBoxDropChances[itemId] = 1000.0;
	}

	public void AddDefinitions(BoltInventoryItemDefinitionDocument[] Definitions)
	{
		definitions = Definitions;
	}

	public BoltInventoryItem? GetRandomItem(CollectionId collectionId)
	{
		if (definitions == null || definitions.Length == 0)
		{
			Console.WriteLine("[RandomGenerator] ERROR: GetRandomItem - definitions list is null or empty!");
			return null;
		}

		double totalChances = 0.0;
		foreach (double chance in dropChances.Values)
		{
			totalChances += chance;
		}
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<SkinValue, double> item in dropChances)
		{
			accumulatedChances += item.Value;
			if (randomChance < accumulatedChances)
			{
				BoltInventoryItemDefinitionDocument boltInventoryItemDefinition = GetRandomItem(item.Key, collectionId);
				if (boltInventoryItemDefinition == null)
				{
					Console.WriteLine($"[RandomGenerator] ERROR: GetRandomItem returned null for collection {collectionId}, skin {item.Key}");
					return null;
				}

				BoltInventoryItem boltInventoryItem = new BoltInventoryItem
				{
					itemDefinitionId = boltInventoryItemDefinition.key,
					date = DateTime.Now,
					flags = 0,
					quantity = 1
				};
				if (boltInventoryItemDefinition.IsStattrack())
				{
					boltInventoryItem.Properties.Add(new BoltInventoryItemProperty
					{
						Name = "stattrack_value",
						Type = BoltInventoryItemProperty.PropertyType.Int,
						Value = "0"
					});
				}
				return boltInventoryItem;
			}
		}
		return null;
	}

	private BoltInventoryItem? GetRandomSecretItem()
	{
		double totalChances = dropChances.Values.Sum();
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<SkinValue, double> item in dropChances)
		{
			accumulatedChances += item.Value;
			if (randomChance < accumulatedChances)
			{
				BoltInventoryItemDefinitionDocument boltInventoryItemDefinition = GetRandomSecretItem(BoltGameDatabaseProvider.Instance.GetInventoryItemDefinition((int)item.Key, 0));
				BoltInventoryItem boltInventoryItem = new BoltInventoryItem
				{
					itemDefinitionId = boltInventoryItemDefinition.key,
					date = DateTime.UtcNow,
					flags = 0,
					quantity = 1
				};
				if (boltInventoryItemDefinition.IsStattrack())
				{
					boltInventoryItem.Properties.Add(new BoltInventoryItemProperty
					{
						Name = "stattrack_value",
						Type = BoltInventoryItemProperty.PropertyType.Int,
						Value = "25343"
					});
				}
				return boltInventoryItem;
			}
		}
		return null;
	}

	public BoltInventoryItem GetRandomGiftBoxItem()
	{
		double totalChances = _giftBoxDropChances.Values.Sum();
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<InventoryId, double> item in _giftBoxDropChances)
		{
			accumulatedChances += item.Value;
			if (randomChance < accumulatedChances)
			{
				BoltInventoryItemDefinitionDocument boltInventoryItemDefinition = GetRandomGbItem(item.Key);
				return new BoltInventoryItem
				{
					itemDefinitionId = boltInventoryItemDefinition.key,
					date = DateTime.UtcNow,
					flags = 0,
					quantity = 1
				};
			}
		}
		return null;
	}

	public (BoltInventoryItem[], CurrencyAmount[]) GetRandomDropInGame(bool pro)
	{
		(BoltInventoryItem[], CurrencyAmount[]) ret = (Array.Empty<BoltInventoryItem>(), Array.Empty<CurrencyAmount>());
		List<BoltInventoryItem> list = new List<BoltInventoryItem>();
		List<CurrencyAmount> list2 = new List<CurrencyAmount>();
		if (!pro)
		{
			BoltInventoryItem caseDrop = GetRandomCaseDrop();
			BoltInventoryItem boxDrop = GetRandomBoxDrop();
			CurrencyAmount[] currencies = GetRandomCurrenciesDrop();
			if (caseDrop == null && boxDrop == null)
			{
				if (currencies != null)
				{
					CurrencyAmount[] array = currencies;
					foreach (CurrencyAmount currency in array)
					{
						list2.Add(currency);
					}
				}
			}
			else if (caseDrop != null)
			{
				list.Add(caseDrop);
			}
			else if (caseDrop == null && boxDrop != null)
			{
				list.Add(boxDrop);
			}
		}
		else
		{
			BoltInventoryItem caseDrop2 = GetRandomCaseDrop();
			BoltInventoryItem boxDrop2 = GetRandomBoxDrop();
			CurrencyAmount[] currencies2 = GetRandomCurrenciesDrop();
			BoltInventoryItem secret = GetRandomSecretItem();
			if (caseDrop2 == null && boxDrop2 == null)
			{
				if (secret != null)
				{
					list.Add(secret);
				}
				else if (currencies2 != null)
				{
					CurrencyAmount[] array2 = currencies2;
					foreach (CurrencyAmount currency2 in array2)
					{
						list2.Add(currency2);
					}
				}
			}
			else if (caseDrop2 != null)
			{
				list.Add(caseDrop2);
			}
			else if (caseDrop2 == null && boxDrop2 != null)
			{
				list.Add(boxDrop2);
			}
		}
		ret.Item1 = list.ToArray();
		ret.Item2 = list2.ToArray();
		return ret;
	}

	private BoltInventoryItem? GetRandomCaseDrop()
	{
		double totalChances = _caseProbabilities.Values.Sum();
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<InventoryId, double> kvp in _caseProbabilities)
		{
			accumulatedChances += kvp.Value;
			if (randomChance < accumulatedChances)
			{
				return new BoltInventoryItem
				{
					itemDefinitionId = (int)kvp.Key,
					date = DateTime.UtcNow,
					flags = 0,
					quantity = 1
				};
			}
		}
		return null;
	}

	private BoltInventoryItem? GetRandomBoxDrop()
	{
		double totalChances = _caseProbabilities.Values.Sum();
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<InventoryId, double> kvp in _caseProbabilities)
		{
			accumulatedChances += kvp.Value;
			if (randomChance < accumulatedChances)
			{
				return new BoltInventoryItem
				{
					itemDefinitionId = (int)kvp.Key,
					date = DateTime.UtcNow,
					flags = 0,
					quantity = 1
				};
			}
		}
		return null;
	}

	public CurrencyAmount[]? GetRandomCurrenciesDrop()
	{
		List<CurrencyAmount> currencies = new List<CurrencyAmount>();
		double totalChances = _currencyChances.Values.Sum();
		bool hasAdditionalReward = random.NextDouble() < 0.1;
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<CurrencyAmount, double> currencyChance in _currencyChances)
		{
			accumulatedChances += currencyChance.Value;
			if (randomChance < accumulatedChances)
			{
				CurrencyAmount currency = GetRandomCurrencyItem();
				currencies.Add(currency);
				ClearCurrencyLuckChances();
				break;
			}
		}
		if (hasAdditionalReward)
		{
			CurrencyAmount additionalCurrency = GetRandomCurrencyItem();
			currencies.Add(additionalCurrency);
		}
		return (currencies.Count > 0) ? currencies.ToArray() : null;
	}

	public BoltInventoryItem? GetRandomBoxItem(CollectionId collectionId)
	{
		double totalChances = 0.0;
		foreach (double chance in dropChances.Values)
		{
			totalChances += chance;
		}
		double randomChance = random.NextDouble() * totalChances;
		double accumulatedChances = 0.0;
		foreach (KeyValuePair<SkinValue, double> item in dropChances)
		{
			accumulatedChances += item.Value;
			if (randomChance < accumulatedChances)
			{
				BoltInventoryItemDefinitionDocument boltInventoryItemDefinition = GetRandomBoxItem(item.Key, collectionId);
				return new BoltInventoryItem
				{
					itemDefinitionId = boltInventoryItemDefinition.key,
					date = DateTime.Now,
					flags = 0,
					quantity = 1
				};
			}
		}
		return null;
	}

	private BoltInventoryItemDefinitionDocument GetRandomItem(SkinValue skinValue, CollectionId collectionId)
	{
		if (definitions == null || definitions.Length == 0)
		{
			Console.WriteLine("[RandomGenerator] CRITICAL: definitions array is null or empty!");
			return null;
		}

		List<BoltInventoryItemDefinitionDocument> items = GetRandomItems().ToList();
		items.RemoveAll((BoltInventoryItemDefinitionDocument a) => a.properties == null || a.GetSkinValue() != skinValue || a.GetCollectionId() != collectionId);
		if (items.Count == 0)
		{
			// Fallback: try all definitions matching this collection (any value)
			items = definitions.Where(a => a.properties != null && a.GetCollectionId() == collectionId).ToList();
		}
		if (items.Count == 0)
		{
			// Last resort: any skin item
			items = definitions.Where(a => a.properties != null && a.GetSkinValue() != SkinValue.None).ToList();
		}
		if (items.Count == 0)
		{
			Console.WriteLine($"[RandomGenerator] CRITICAL: No items found for collection {collectionId}, value {skinValue}");
			return definitions[0];
		}
		int randomValue = new Random().Next(0, items.Count);
		return items[randomValue];
	}

	private BoltInventoryItemDefinitionDocument GetRandomBoxItem(SkinValue skinValue, CollectionId collectionId)
	{
		List<BoltInventoryItemDefinitionDocument> items = GetRandomItems().ToList();
		items.RemoveAll((BoltInventoryItemDefinitionDocument a) => a.properties == null || a.GetSkinValue() != skinValue || a.GetCollectionId() != collectionId || a.IsStattrack());
		if (items.Count == 0)
		{
			items = definitions.Where(a => a.properties != null && a.GetCollectionId() == collectionId && !a.IsStattrack()).ToList();
		}
		if (items.Count == 0)
		{
			items = definitions.Where(a => a.properties != null && a.GetSkinValue() != SkinValue.None && !a.IsStattrack()).ToList();
		}
		if (items.Count == 0)
		{
			Console.WriteLine($"[RandomGenerator] CRITICAL: No box items found for collection {collectionId}, value {skinValue}");
			return definitions[0];
		}
		int randomValue = new Random().Next(0, items.Count);
		return items[randomValue];
	}

	private CurrencyAmount[] GetRandomCurrencies()
	{
		Random random = new Random();
		return (from _ in Currencies
			select random.Next(Currencies.Count) into randomIndex
			select Currencies[randomIndex]).ToArray();
	}

	private BoltInventoryItemDefinitionDocument GetRandomSecretItem(BoltInventoryItemDefinitionDocument def)
	{
		List<BoltInventoryItemDefinitionDocument> items = GetRandomItems().ToList();
		BsonElement value = def.properties.FirstOrDefault((BsonElement x) => x.Name == "value");
		if (!Enum.TryParse<CollectionId>(def.properties.FirstOrDefault((BsonElement x) => x.Name == "collection").Value.AsString, out var collectionId) || !Enum.TryParse<SkinValue>(value.Value.AsString, out var skinValue))
		{
			return null;
		}
		items.RemoveAll((BoltInventoryItemDefinitionDocument a) => a.GetSkinValue() != skinValue || a.GetCollectionId() != collectionId);
		if (items.Count == 0)
		{
			items = GetRandomItems().ToList();
			items.RemoveAll((BoltInventoryItemDefinitionDocument a) => a.GetSkinValue() != skinValue || a.GetCollectionId() != collectionId);
		}
		int randomValue = new Random().Next(0, items.Count - 1);
		return items[randomValue];
	}

	private CurrencyAmount GetRandomCurrencyItem()
	{
		CurrencyAmount currencyAmount = new CurrencyAmount();
		currencyAmount.Value = 69f;
		currencyAmount.OldValue = 69;
		currencyAmount.CurrencyId = 101;
		return currencyAmount;
	}

	private BoltInventoryItemDefinitionDocument GetRandomGbItem(InventoryId id)
	{
		List<BoltInventoryItemDefinitionDocument> items = GetRandomItems().ToList();
		items.RemoveAll((BoltInventoryItemDefinitionDocument a) => a.key != (int)id);
		if (items.Count == 0)
		{
			items = GetRandomItems().ToList();
		}
		int randomValue = new Random().Next(0, items.Count - 1);
		return items[randomValue];
	}

	private BoltInventoryItemDefinitionDocument[] GetRandomItems()
	{
		Random random = new Random();
		List<BoltInventoryItemDefinitionDocument> randomItems = new List<BoltInventoryItemDefinitionDocument>();
		for (int i = 0; i < definitions.Length; i++)
		{
			int randomIndex = random.Next(definitions.Length);
			BoltInventoryItemDefinitionDocument randomItem = definitions[randomIndex];
			randomItems.Add(randomItem);
		}
		return randomItems.ToArray();
	}

	private static int CalculateWeight(BoltInventoryItemDefinitionDocument definition)
	{
		int num = (int)(7 - definition.GetSkinValue());
		return num * num;
	}
}
