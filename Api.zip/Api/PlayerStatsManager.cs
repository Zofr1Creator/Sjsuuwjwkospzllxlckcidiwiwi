using StandRiseServer.MongoDB;
using StandRiseServer.RpcServer.Helpers;
using System;
using System.Collections.Generic;

namespace StandRiseServer.RpcServer.Api
{
    public static class PlayerStatsManager
    {
        public static void AddKill(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "kills");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_kills");
            }
            Logger.Log($"[PlayerStats] Added kill for player {playerId} in mode {gameMode}");
        }

        public static void AddDeath(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "deaths");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_deaths");
            }
            Logger.Log($"[PlayerStats] Added death for player {playerId} in mode {gameMode}");
        }

        public static void AddAssist(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "assists");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_assists");
            }
            Logger.Log($"[PlayerStats] Added assist for player {playerId} in mode {gameMode}");
        }

        public static void AddShot(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "shots");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_shots");
            }
        }

        public static void AddHit(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "hits");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_hits");
            }
        }

        public static void AddHeadshot(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "headshots");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_headshots");
            }
            Logger.Log($"[PlayerStats] Added headshot for player {playerId} in mode {gameMode}");
        }

        public static void AddDamage(string playerId, float damage, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "damage", damage);
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "damage_dealt", (int)damage);
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_damage", (int)damage);
            }
        }

        public static void AddDamageTaken(string playerId, float damage)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "damage_taken", (int)damage);
        }

        public static void AddGamePlayed(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "games_played");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_games_played");
            }
            Logger.Log($"[PlayerStats] Added game played for player {playerId} in mode {gameMode}");
        }

        public static void AddWin(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "wins");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_wins");
            }
            
            if (gameMode == "ranked")
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_won_match_count");
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_played_matches");
                
                var currentMmr = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "ranked_current_mmr");
                var newMmr = (float)currentMmr + 25f;
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_current_mmr", newMmr);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_target_mmr", newMmr);
            }

            if (gameMode == "allies")
            {
                // NOTE: Client swaps won_match_count and calibration_match_count
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_2v2_calibration_match_count"); // This is actually WON match count for client
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_2v2_played_matches");

                var currentMmr = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "ranked_2v2_current_mmr");
                var newMmr = (float)currentMmr + 25f;
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_2v2_current_mmr", newMmr);
                
                int rank = CalculateRankFromMmr(newMmr);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_2v2_rank", rank);

                // Update best rank if current rank is higher
                var bestRank = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "ranked_2v2_best_rank");
                if (rank > (int)bestRank)
                {
                    BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_2v2_best_rank", rank);
                }
            }
            
            Logger.Log($"[PlayerStats] Added win for player {playerId} in mode {gameMode}");
        }

        public static void AddLoss(string playerId, string gameMode = null)
        {
            BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "losses");
            if (!string.IsNullOrEmpty(gameMode))
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, $"{gameMode}_losses");
            }
            
            if (gameMode == "ranked")
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_played_matches");
                
                var currentMmr = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "ranked_current_mmr");
                var newMmr = Math.Max(0f, (float)currentMmr - 20f);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_current_mmr", newMmr);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_target_mmr", newMmr);
            }

            if (gameMode == "allies")
            {
                BoltGameDatabaseProvider.Instance.IncrementPlayerStat(playerId, "ranked_2v2_played_matches");

                var currentMmr = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "ranked_2v2_current_mmr");
                var newMmr = Math.Max(0f, (float)currentMmr - 20f);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_2v2_current_mmr", newMmr);

                int rank = CalculateRankFromMmr(newMmr);
                BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_2v2_rank", rank);
            }
            
            Logger.Log($"[PlayerStats] Added loss for player {playerId} in mode {gameMode}");
        }

        public static void AddExperience(string playerId, float xp)
        {
            var currentXp = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "level_xp");
            var currentLevel = BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, "level_id");
            
            var newXp = (float)currentXp + xp;
            var newLevel = (int)currentLevel;
            
            while (newXp >= 1000f)
            {
                newXp -= 1000f;
                newLevel++;
            }
            
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "level_xp", newXp);
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "level_id", newLevel);
            
            Logger.Log($"[PlayerStats] Added {xp} XP to player {playerId}. New level: {newLevel}, XP: {newXp}");
        }

        public static void SetRankedMmr(string playerId, float mmr)
        {
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_current_mmr", mmr);
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_target_mmr", mmr);
            
            int rank = CalculateRankFromMmr(mmr);
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, "ranked_rank", rank);
            
            Logger.Log($"[PlayerStats] Set MMR {mmr} (rank {rank}) for player {playerId}");
        }

        private static int CalculateRankFromMmr(float mmr)
        {
            if (mmr < 500) return 1;      
            if (mmr < 750) return 2;      
            if (mmr < 1000) return 3;     
            if (mmr < 1250) return 4;     
            if (mmr < 1500) return 5;     
            if (mmr < 1750) return 6;     
            if (mmr < 2000) return 7;     
            if (mmr < 2500) return 8;     
            return 9;                     
        }

        public static float GetPlayerStat(string playerId, string statName)
        {
            return (float)BoltGameDatabaseProvider.Instance.GetPlayerStat(playerId, statName);
        }

        public static void SetPlayerStat(string playerId, string statName, float value)
        {
            BoltGameDatabaseProvider.Instance.SetPlayerStat(playerId, statName, value);
        }

        public static void MarkRankedMatchStarted(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
            {
                return;
            }

            var db = BoltGameDatabaseProvider.Instance;
            db.GetOrCreatePlayerStatsDocument(playerId);
            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            db.SetPlayerStat(playerId, "ranked_last_match_start_time", now);
            db.SetPlayerStat(playerId, "ranked_last_match_status", 1);
        }

        public static void MarkRankedMatchFinished(string playerId)
        {
            if (string.IsNullOrWhiteSpace(playerId))
            {
                return;
            }

            var db = BoltGameDatabaseProvider.Instance;
            db.GetOrCreatePlayerStatsDocument(playerId);
            db.SetPlayerStat(playerId, "ranked_last_match_status", 0);
        }
    }
}
