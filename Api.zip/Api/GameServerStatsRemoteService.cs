using System;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main.PlayerStats;
using scg = System.Collections.Generic;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("GameServerStatsRemoteService")]
    public class GameServerStatsRemoteService : RpcClass
    {
        public GameServerStatsRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "getstats":
                    await GetStats(request.Params.ToArray(), request.Id);
                    break;
                case "getcurrentstats":
                    await GetCurrentStats(request.Params.ToArray(), request.Id);
                    break;
                case "storeplayersstats":
                    await StorePlayersStats(request.Params.ToArray(), request.Id);
                    break;
                case "getplayersstats":
                    // New clients send one protobuf request; legacy clients send raw params array.
                    if (request.Params.Count == 1 && request.Params[0].One != null)
                        await GetPlayersStatsGeneric(request.Params.ToArray(), request.Id);
                    else
                        await GetPlayersStatsSimple(request.Params.ToArray(), request.Id);
                    break;
                case "getplayerstats":
                    await GetPlayerStats(request.Params.ToArray(), request.Id);
                    break;
                case "storeplayerstats":
                    await StorePlayerStats(request.Params.ToArray(), request.Id);
                    break;
                case "storestats":
                    await StoreStats(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task GetStats(BinaryValue[] values, string guid)
        {
            try
            {
                string playerId = string.Empty;
                string[] apiNames = Array.Empty<string>();

                // Legacy signature: GetStats(string playerId, string[] apiNames)
                if (values != null && values.Length >= 2)
                {
                    try
                    {
                        playerId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                        apiNames = (string[])new FromByteMethod(typeof(string[])).FromBytes(values[1]);
                    }
                    catch
                    {
                        // Fallback to message parsing below.
                    }
                }

                // Some builds can send a single protobuf request payload.
                if (string.IsNullOrWhiteSpace(playerId) && values != null && values.Length >= 1 && values[0]?.One != null)
                {
                    try
                    {
                        var request = GetPlayerStatsRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                        playerId = request.PlayerId;
                        apiNames = request.ApiNames.ToArray();
                    }
                    catch
                    {
                        // Keep defaults; handled below.
                    }
                }

                playerId = ResolvePlayerIdOrCurrent(playerId);
                if (string.IsNullOrWhiteSpace(playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                apiNames = ResolveApiNames(playerId, apiNames);
                Logger.Debug($"[GameServerStats] getStats playerId={playerId}, apiNames={apiNames.Length}");
                var storeStats = BoltGameDatabaseProvider.Instance.GetPlayerStats(playerId, apiNames);
                var stats = ConvertStoreStatsToStats(storeStats);
                SendResponse(guid, stats);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task StorePlayersStats(BinaryValue[] values, string guid)
        {
            try
            {
                // SECURITY: Only game servers can store stats
                if (!StaticClasses.GameServerUsers.Contains(_user.TcpClient))
                {
                    Logger.LogWarn($"[GameServerStats] StorePlayersStats called from non-game-server client - BLOCKED (anti-dupe protection)");
                    SendError(guid, 403); // Forbidden
                    return;
                }

                var request = StorePlayersStatsRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                foreach (var playerStats in request.StorePlayersStats)
                {
                    BoltGameDatabaseProvider.Instance.StorePlayerStats(playerStats.PlayerId, playerStats.Stats);
                }
                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetCurrentStats(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                var statsDoc = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
                var stats = new Stats();
                if (statsDoc?.stats != null)
                {
                    foreach (var bsonElement in statsDoc.stats)
                    {
                        if (bsonElement.Value.IsInt32 || bsonElement.Value.IsInt64 || bsonElement.Value.IsDouble || bsonElement.Value.IsString)
                        {
                            stats.Stat.Add(bsonElement.GetPlayerStat());
                        }
                    }
                }

                var response = new GetCurrentStatsResponse
                {
                    Stats = stats
                };
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetPlayersStatsSimple(BinaryValue[] values, string guid)
        {
            try
            {
                string[] playerIds = (string[])new FromByteMethod(typeof(string[])).FromBytes(values[0]);
                string[] apiNames = (string[])new FromByteMethod(typeof(string[])).FromBytes(values[1]);

                playerIds = NormalizePlayerIds(playerIds);
                if (playerIds.Length == 0 && TryGetCurrentPlayerId(out var currentPlayerId))
                {
                    playerIds = new[] { currentPlayerId };
                }

                var results = playerIds.Select(id =>
                {
                    var resolvedPlayerId = ResolvePlayerIdOrCurrent(id);
                    var resolvedApiNames = ResolveApiNames(resolvedPlayerId, apiNames);
                    var sps = new StorePlayerStats { PlayerId = resolvedPlayerId };
                    sps.Stats.Add(BoltGameDatabaseProvider.Instance.GetPlayerStats(resolvedPlayerId, resolvedApiNames));
                    return sps;
                }).ToArray();
                
                SendResponse(guid, results);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetPlayerStats(BinaryValue[] values, string guid)
        {
            try
            {
                string requestedPlayerId = string.Empty;
                string[] requestedApiNames = Array.Empty<string>();

                if (values != null && values.Length > 0 && values[0]?.One != null)
                {
                    var request = GetPlayerStatsRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                    requestedPlayerId = request.PlayerId;
                    requestedApiNames = request.ApiNames.ToArray();
                }
                else if (values != null && values.Length > 0)
                {
                    // Legacy fallback if payload is sent as separate params.
                    requestedPlayerId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                    if (values.Length > 1)
                    {
                        requestedApiNames = (string[])new FromByteMethod(typeof(string[])).FromBytes(values[1]);
                    }
                }

                var resolvedPlayerId = ResolvePlayerIdOrCurrent(requestedPlayerId);
                if (string.IsNullOrWhiteSpace(resolvedPlayerId))
                {
                    SendError(guid, 401);
                    return;
                }

                var resolvedApiNames = ResolveApiNames(resolvedPlayerId, requestedApiNames);
                Logger.Debug($"[GameServerStats] getPlayerStats playerId={resolvedPlayerId}, apiNames={resolvedApiNames.Length}");
                var stats = BoltGameDatabaseProvider.Instance.GetPlayerStats(resolvedPlayerId, resolvedApiNames);
                var response = new GetPlayerStatsResponse
                {
                    PlayerStats = new Axlebolt.Bolt.Protobuf.PlayerStats
                    {
                        PlayerId = resolvedPlayerId
                    }
                };
                response.PlayerStats.Stats.Add(stats);
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetPlayersStatsGeneric(BinaryValue[] values, string guid)
        {
            try
            {
                var request = GetPlayersStatsRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                var response = new GetPlayersStatsResponse();
                var playerIds = NormalizePlayerIds(request.PlayerIds);
                if (playerIds.Length == 0 && TryGetCurrentPlayerId(out var currentPlayerId))
                {
                    playerIds = new[] { currentPlayerId };
                }

                foreach (var playerId in playerIds)
                {
                    var resolvedPlayerId = ResolvePlayerIdOrCurrent(playerId);
                    var resolvedApiNames = ResolveApiNames(resolvedPlayerId, request.ApiNames);
                    Logger.Debug($"[GameServerStats] getPlayersStats playerId={resolvedPlayerId}, apiNames={resolvedApiNames.Length}");
                    var playerStats = new Axlebolt.Bolt.Protobuf.PlayerStats
                    {
                        PlayerId = resolvedPlayerId,
                    };
                    playerStats.Stats.Add(BoltGameDatabaseProvider.Instance.GetPlayerStats(resolvedPlayerId, resolvedApiNames));
                    response.PlayersStats.Add(playerStats);
                }
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task StorePlayerStats(BinaryValue[] values, string guid)
        {
            try
            {
                // SECURITY: Only game servers can store stats
                if (!StaticClasses.GameServerUsers.Contains(_user.TcpClient))
                {
                    Logger.LogWarn($"[GameServerStats] StorePlayerStats called from non-game-server client - BLOCKED (anti-dupe protection)");
                    SendError(guid, 403); // Forbidden
                    return;
                }

                var request = StorePlayerStatsRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                var payload = request.StorePlayerStats;
                if (payload == null && (!string.IsNullOrWhiteSpace(request.PlayerId) || request.Stats.Count > 0))
                {
                    payload = new Axlebolt.Bolt.Protobuf.StorePlayerStats
                    {
                        PlayerId = request.PlayerId
                    };
                    payload.Stats.Add(request.Stats);
                }

                if (payload != null)
                {
                    payload.PlayerId = ResolvePlayerIdOrCurrent(payload.PlayerId);
                    BoltGameDatabaseProvider.Instance.StorePlayerStats(payload.PlayerId, payload.Stats);
                }
                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task StoreStats(BinaryValue[] values, string guid)
        {
            try
            {
                // SECURITY: Only game servers can store stats
                if (!StaticClasses.GameServerUsers.Contains(_user.TcpClient))
                {
                    Logger.LogWarn($"[GameServerStats] StoreStats called from non-game-server client - BLOCKED (anti-dupe protection)");
                    SendError(guid, 403); // Forbidden
                    return;
                }

                var stats = (StorePlayerStats[])new FromByteMethod(typeof(StorePlayerStats[])).FromBytes(values[0]);
                foreach (var playerStats in stats)
                {
                    BoltGameDatabaseProvider.Instance.StorePlayerStats(playerStats.PlayerId, playerStats.Stats);
                }
                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private void SendResponse(string guid, object response = null)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = response != null ? (response is IMessage message ? new BinaryValue { One = message.ToByteString() } : ProtoReflectionUtils.CreateToByteMethod(response.GetType()).ToBytes(response)) : new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private static Stats ConvertStoreStatsToStats(Google.Protobuf.Collections.RepeatedField<StorePlayerStat> storeStats)
        {
            var stats = new Stats();
            if (storeStats == null)
            {
                return stats;
            }

            foreach (var storeStat in storeStats)
            {
                if (storeStat == null || string.IsNullOrWhiteSpace(storeStat.Name))
                {
                    continue;
                }

                var playerStat = new PlayerStat
                {
                    Name = storeStat.Name
                };

                if (ShouldUseIntegralEncoding(storeStat.Name))
                {
                    long integral = storeStat.StoreLong != 0L ? storeStat.StoreLong : storeStat.StoreInt;
                    playerStat.Type = StatDefType.Int;
                    playerStat.LongValue = integral;
                    playerStat.IntValue = ToInt32Safe(integral);
                }
                else
                {
                    float floatValue = storeStat.StoreFloat;
                    if (floatValue == 0f)
                    {
                        if (storeStat.StoreLong != 0L) floatValue = storeStat.StoreLong;
                        else if (storeStat.StoreInt != 0) floatValue = storeStat.StoreInt;
                    }

                    playerStat.Type = StatDefType.Float;
                    playerStat.FloatValue = floatValue;
                }

                stats.Stat.Add(playerStat);
            }

            return stats;
        }

        private static int ToInt32Safe(long value)
        {
            if (value > int.MaxValue) return int.MaxValue;
            if (value < int.MinValue) return int.MinValue;
            return (int)value;
        }

        private static bool ShouldUseIntegralEncoding(string statName)
        {
            if (string.IsNullOrWhiteSpace(statName))
            {
                return false;
            }

            return statName.EndsWith("_mmr", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_rank", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_matches", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_count", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_xp", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_time", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_id", StringComparison.OrdinalIgnoreCase) ||
                   statName.EndsWith("_until", StringComparison.OrdinalIgnoreCase);
        }

        private bool TryGetCurrentPlayerId(out string playerId)
        {
            playerId = null;
            return StaticClasses.Users.TryGetValue(_user.TcpClient, out playerId) &&
                   !string.IsNullOrWhiteSpace(playerId);
        }

        private string ResolvePlayerIdOrCurrent(string requestedPlayerId)
        {
            if (!string.IsNullOrWhiteSpace(requestedPlayerId))
            {
                return requestedPlayerId.Trim();
            }

            return TryGetCurrentPlayerId(out var currentPlayerId) ? currentPlayerId : string.Empty;
        }

        private string[] ResolveApiNames(string playerId, scg::IEnumerable<string> requestedApiNames)
        {
            var normalized = NormalizeApiNames(requestedApiNames);
            if (normalized.Length > 0)
            {
                return normalized;
            }

            if (string.IsNullOrWhiteSpace(playerId))
            {
                return Array.Empty<string>();
            }

            var statsDocument = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
            if (statsDocument?.stats == null)
            {
                return Array.Empty<string>();
            }

            return NormalizeApiNames(statsDocument.stats.Names);
        }

        private static string[] NormalizePlayerIds(scg::IEnumerable<string> playerIds)
        {
            if (playerIds == null)
            {
                return Array.Empty<string>();
            }

            return playerIds
                .Where(id => !string.IsNullOrWhiteSpace(id))
                .Select(id => id.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private static string[] NormalizeApiNames(scg::IEnumerable<string> apiNames)
        {
            if (apiNames == null)
            {
                return Array.Empty<string>();
            }

            return apiNames
                .Where(name => !string.IsNullOrWhiteSpace(name))
                .Select(name => name.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }
    }
}
