using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.RpcServer;

namespace StandRiseServer.RpcServer.Api
{
    public class GameEventRemoteEventSender : IEventSender
    {
        private UserService User { get; set; }

        public string eventListenerName { get; set; } = "GameEventRemoteEventListener";

        public GameEventRemoteEventSender(UserService user)
        {
            User = user;
        }

        public void SendEvent(string eventName, object[] param)
        {
            if (eventName == "onGamePassChanged")
                OnGamePassChanged(param);
        }

        private void OnGamePassChanged(object[] param)
        {
            var evt = (OnGamePassChangedEvent)param[0];
            var responseMessage = new ResponseMessage
            {
                EventResponse = new EventResponse
                {
                    EventName = "onGamePassChanged",
                    ListenerName = eventListenerName
                }
            };
            responseMessage.EventResponse.Params.Add(
                ProtoReflectionUtils.CreateToByteMethod(typeof(OnGamePassChangedEvent)).ToBytes(evt));
            User.SendResponce(responseMessage);
        }
    }
}
