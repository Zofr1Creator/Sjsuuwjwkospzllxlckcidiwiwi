using System;
using StandRiseServer.RpcServer.Api;
using StandRiseServer.RpcServer;
using Axlebolt.RpcSupport.Protobuf;

namespace StandRiseServer.RpcServer.Api
{
    public class LeaderboardRemoteService : RpcClass
    {
        public LeaderboardRemoteService(UserService user) : base(user)
        {
        }

        protected void GetLeaderboard(string guid)
        {
            _user.SendResponce(new ResponseMessage 
            { 
                RpcResponse = new RpcResponse 
                { 
                    Id = guid, 
                    Return = new BinaryValue() 
                } 
            });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getLeaderboard") 
                GetLeaderboard(request.Id);
            else
                MethodNotFound(request);
        }
    }
}
