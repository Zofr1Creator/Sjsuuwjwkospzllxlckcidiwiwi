using System;
using System.Collections.Generic;
using System.Linq;
using Axlebolt.Bolt.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;

namespace StandRiseServer.RpcServer.Api
{
    internal static class ClanStatsPayloadBuilder
    {
        private static readonly Dictionary<string, int> DefaultClanStats = new Dictionary<string, int>
        {
            { "clan_ranked_current_mmr", 1000 },
            { "clan_ranked_rank", 0 },
            { "clan_ranked_best_rank", -1 },
            { "clan_ranked_played_matches", 0 },
            { "clan_ranked_won_match_count", 0 },
            { "clan_ranked_calibration_match_count", 10 },
            { "clan_ranked_xp", 0 },
            { "clan_ranked_best_rank_history1", 0 },
            { "clan_ranked_season_id", 1 },
            { "clan_ranked_is_banned", 0 }
        };

        private static readonly Dictionary<string, int> DefaultMemberStats = new Dictionary<string, int>
        {
            { "clan_member_ranked_xp", 0 },
            { "clan_member_ranked_played_matches", 0 },
            { "clan_member_ranked_won_match_count", 0 },
            { "clan_member_ranked_last_match_status", 0 },
            { "clan_member_ranked_last_match_start_time", 0 }
        };

        public static string NormalizeSeasonId(string requestedSeasonId, ClanDocument clanDocument = null)
        {
            if (!string.IsNullOrWhiteSpace(requestedSeasonId))
            {
                return requestedSeasonId;
            }

            if (clanDocument?.stats != null &&
                clanDocument.stats.TryGetValue("clan_ranked_season_id", out var seasonValue))
            {
                if (seasonValue.IsInt32)
                {
                    return seasonValue.AsInt32.ToString();
                }

                if (seasonValue.IsInt64)
                {
                    return seasonValue.AsInt64.ToString();
                }

                if (seasonValue.IsString && !string.IsNullOrWhiteSpace(seasonValue.AsString))
                {
                    return seasonValue.AsString;
                }
            }

            return "1";
        }

        public static ClanStats BuildClanStats(ClanDocument clanDocument, string requestedSeasonId = null)
        {
            var clanStats = new ClanStats
            {
                ClanId = clanDocument?._id.ToString() ?? string.Empty,
                SeasonId = NormalizeSeasonId(requestedSeasonId, clanDocument)
            };

            if (clanDocument?.stats != null)
            {
                foreach (var stat in clanDocument.stats)
                {
                    if (TryConvertClanStat(stat.Name, stat.Value, out var clanStat))
                    {
                        clanStats.Stats.Add(clanStat);
                    }
                }
            }

            EnsureRequiredClanStats(clanStats, clanDocument);
            return clanStats;
        }

        public static List<ClanMemberStats> BuildClanMemberStatsForClan(ClanDocument clanDocument)
        {
            var result = new List<ClanMemberStats>();
            if (clanDocument == null)
            {
                return result;
            }

            var playerIds = new HashSet<string>(StringComparer.Ordinal);

            foreach (var member in clanDocument.GetMembers())
            {
                string playerId = member?.PlayerFriend?.Player?.Id;
                if (!string.IsNullOrWhiteSpace(playerId))
                {
                    playerIds.Add(playerId);
                }
            }

            if (clanDocument.members != null)
            {
                foreach (var memberEntry in clanDocument.members)
                {
                    var fallbackId = memberEntry.Name;
                    if (memberEntry.Value.IsBsonDocument)
                    {
                        var memberDoc = memberEntry.Value.AsBsonDocument;
                        if (memberDoc.TryGetValue("playerId", out var playerIdValue) && playerIdValue.IsString)
                        {
                            fallbackId = playerIdValue.AsString;
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(fallbackId))
                    {
                        playerIds.Add(fallbackId);
                    }
                }
            }

            foreach (var playerId in playerIds)
            {
                result.Add(BuildClanMemberStats(playerId));
            }

            return result;
        }

        public static ClanMemberStats BuildClanMemberStats(string playerId)
        {
            var memberStats = new ClanMemberStats
            {
                PlayerId = playerId ?? string.Empty
            };

            if (string.IsNullOrWhiteSpace(playerId))
            {
                EnsureRequiredMemberStats(memberStats);
                return memberStats;
            }

            var statsDocument = BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(playerId);
            if (statsDocument?.stats != null)
            {
                foreach (var stat in statsDocument.stats)
                {
                    if (!stat.Name.StartsWith("clan_member_ranked_", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    if (TryConvertClanMemberStat(stat.Name, stat.Value, out var memberStat))
                    {
                        memberStats.Stats.Add(memberStat);
                    }
                }
            }

            EnsureRequiredMemberStats(memberStats);
            return memberStats;
        }

        private static void EnsureRequiredClanStats(ClanStats clanStats, ClanDocument clanDocument)
        {
            var existing = new HashSet<string>(clanStats.Stats.Select(x => x.StatId), StringComparer.Ordinal);
            foreach (var pair in DefaultClanStats)
            {
                if (existing.Contains(pair.Key))
                {
                    continue;
                }

                clanStats.Stats.Add(new ClanStat
                {
                    StatId = pair.Key,
                    Type = StatDefType.Int,
                    IntValue = pair.Value
                });
            }

            if (!existing.Contains("MEMBERS_COUNT"))
            {
                clanStats.Stats.Add(new ClanStat
                {
                    StatId = "MEMBERS_COUNT",
                    Type = StatDefType.Int,
                    IntValue = Math.Max(clanDocument?.membersCount ?? 0, 0)
                });
            }
        }

        private static void EnsureRequiredMemberStats(ClanMemberStats memberStats)
        {
            var existing = new HashSet<string>(memberStats.Stats.Select(x => x.StatId), StringComparer.Ordinal);
            foreach (var pair in DefaultMemberStats)
            {
                if (existing.Contains(pair.Key))
                {
                    continue;
                }

                memberStats.Stats.Add(new ClanMemberStat
                {
                    StatId = pair.Key,
                    Type = StatDefType.Int,
                    IntValue = pair.Value
                });
            }
        }

        private static bool TryConvertClanStat(string statId, BsonValue value, out ClanStat clanStat)
        {
            clanStat = null;

            if (string.IsNullOrWhiteSpace(statId) || value == null)
            {
                return false;
            }

            if (value.IsDouble)
            {
                clanStat = new ClanStat
                {
                    StatId = statId,
                    Type = StatDefType.Float,
                    FloatValue = (float)value.AsDouble
                };
                return true;
            }

            if (value.IsInt32 || value.IsInt64 || value.IsBoolean || value.IsString)
            {
                clanStat = new ClanStat
                {
                    StatId = statId,
                    Type = StatDefType.Int,
                    IntValue = ToIntValue(value)
                };
                return true;
            }

            return false;
        }

        private static bool TryConvertClanMemberStat(string statId, BsonValue value, out ClanMemberStat memberStat)
        {
            memberStat = null;

            if (string.IsNullOrWhiteSpace(statId) || value == null)
            {
                return false;
            }

            if (value.IsDouble)
            {
                memberStat = new ClanMemberStat
                {
                    StatId = statId,
                    Type = StatDefType.Float,
                    FloatValue = (float)value.AsDouble
                };
                return true;
            }

            if (value.IsInt32 || value.IsInt64 || value.IsBoolean || value.IsString)
            {
                memberStat = new ClanMemberStat
                {
                    StatId = statId,
                    Type = StatDefType.Int,
                    IntValue = ToIntValue(value)
                };
                return true;
            }

            return false;
        }

        private static int ToIntValue(BsonValue value)
        {
            if (value.IsInt32)
            {
                return value.AsInt32;
            }

            if (value.IsInt64)
            {
                long longValue = value.AsInt64;
                if (longValue > int.MaxValue)
                {
                    return int.MaxValue;
                }

                if (longValue < int.MinValue)
                {
                    return int.MinValue;
                }

                return (int)longValue;
            }

            if (value.IsDouble)
            {
                double doubleValue = value.AsDouble;
                if (doubleValue > int.MaxValue)
                {
                    return int.MaxValue;
                }

                if (doubleValue < int.MinValue)
                {
                    return int.MinValue;
                }

                return (int)doubleValue;
            }

            if (value.IsBoolean)
            {
                return value.AsBoolean ? 1 : 0;
            }

            if (value.IsString && int.TryParse(value.AsString, out int parsed))
            {
                return parsed;
            }

            return 0;
        }
    }
}
