using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;

namespace StandRiseServer.RpcServer.Api
{
    public class AnticheatRemoteService : RpcClass
    {
        public AnticheatRemoteService(UserService user) : base(user)
        {
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "reportLoaded")
            {
                if (PlayerId == null)
                {
                    SendError(request.Id, 401);
                    return;
                }

                BoltMainDatabaseProvider.Instance.SetAnticheatStatus(ObjectId.Parse(PlayerId), 1);
                Logger.Log($"[Anticheat] Player {PlayerId} anticheat status set to 1 (running)");
                SendResponse(request.Id);
            }
            else
            {
                MethodNotFound(request);
            }
        }
    }
}
