using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.RpcServer;

namespace StandRiseServer.RpcServer.Api
{
    public class MatchesRemoteEventListener : IEventSender
    {
        private UserService User { get; set; }

        public string eventListenerName { get; set; } = "MatchesRemoteEventListener";

        public MatchesRemoteEventListener(UserService user)
        {
            User = user;
        }

        public void SendEvent(string eventName, object[] param)
        {
            if (eventName == "onMatchFinished")
                OnMatchFinished(param);
        }

        private void OnMatchFinished(object[] param)
        {
            var evt = (OnMatchFinishedEvent)param[0];
            var responseMessage = new ResponseMessage
            {
                EventResponse = new EventResponse
                {
                    EventName = "onMatchFinished",
                    ListenerName = eventListenerName
                }
            };
            responseMessage.EventResponse.Params.Add(
                ProtoReflectionUtils.CreateToByteMethod(typeof(OnMatchFinishedEvent)).ToBytes(evt));
            User.SendResponce(responseMessage);
        }
    }
}
