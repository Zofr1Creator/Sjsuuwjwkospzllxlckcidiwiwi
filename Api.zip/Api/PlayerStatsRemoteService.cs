using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB.Main.PlayerStats;

namespace StandRiseServer.RpcServer.Api
{
    public class PlayerStatsRemoteService : RpcClass
    {
        public PlayerStatsRemoteService(UserService user) : base(user) { }

        private static List<BsonElement> Expect(List<BsonElement> fromt, List<BsonElement> to)
        {
            List<BsonElement> result = new List<BsonElement>();
            HashSet<string> toNames = new HashSet<string>(to.Select(x => x.Name));
            
            foreach (BsonElement bsonElement in fromt)
            {
                if (!toNames.Contains(bsonElement.Name))
                {
                    result.Add(bsonElement);
                }
            }
            return result;
        }

        protected void GetPlayerStats(BinaryValue[] values, string guid)
        {
            try
            {
                FromByteMethod from = new FromByteMethod(typeof(string));
                string playerId = (string)from.FromBytes(values[0]);
                
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                PlayerStatsDocument playerStatsDocument = boltMain.GetOrCreatePlayerStatsDocument(playerId);
                
                Stats stats = new Stats();
                foreach (var bsonElement in playerStatsDocument?.stats ?? new BsonDocument())
                {
                    stats.Stat.Add(bsonElement.GetPlayerStat());
                }
                
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(Stats)).ToBytes(stats) } });
            }
            catch (System.Exception ex)
            {
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Code = 500 } } });
            }
        }

        protected void GetStats(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                PlayerStatsDocument playerStatsDocument = boltMain.GetOrCreatePlayerStatsDocument(Id);
                List<BsonElement> playerStatsOrig = playerStatsDocument?.stats?.ToList() ?? new List<BsonElement>();

                Stats stats = new Stats();
                foreach (var bsonElement in playerStatsOrig)
                {
                    if (bsonElement.Value.IsInt32 || bsonElement.Value.IsInt64 || bsonElement.Value.IsDouble || bsonElement.Value.IsString)
                    {
                        stats.Stat.Add(bsonElement.GetPlayerStat());
                    }
                }
                
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(Stats)).ToBytes(stats) } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Code = 401 } } });
        }

        protected void GetCurrentStats(BinaryValue[] values, string guid)
        {
            if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
            {
                SendError(guid, 401);
                return;
            }

            try
            {
                var boltMain = BoltGameDatabaseProvider.Instance;
                var playerStatsDocument = boltMain.GetOrCreatePlayerStatsDocument(playerId);

                var stats = new Stats();
                foreach (var bsonElement in playerStatsDocument?.stats ?? new BsonDocument())
                {
                    if (bsonElement.Value.IsInt32 || bsonElement.Value.IsInt64 || bsonElement.Value.IsDouble || bsonElement.Value.IsString)
                    {
                        stats.Stat.Add(bsonElement.GetPlayerStat());
                    }
                }

                var response = new GetCurrentStatsResponse
                {
                    Stats = stats
                };

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        // Stats that the client is allowed to save directly.
        // (progression only; kills/deaths/ranked progression are server authoritative)
        private static readonly HashSet<string> _allowedClientStats = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "level_id", "level_xp", "time_played", "total_time",
            "ranked_banned_until", "RANKED_BANNED_UNTIL",
            "ranked_ban_code", "ranked_ban_reason", "ranked_ban_duration",
            "ranked_last_activity_time1", "ranked_last_activity_time2",
            "ranked_last_match_status",
            "clan_member_ranked_last_match_start_time", "clan_member_ranked_last_match_status"
        };

        protected void StoreStats(BinaryValue[] values, string guid)
        {
            if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                SendError(guid, 401);
                return;
            }

            // Allow StoreStats while the player still has an "InGame: ..." status.
            // This service is progression-only (kills/deaths are server authoritative via HTTP/GS match result),
            // so blocking here causes legitimate progression updates to be lost after quick reconnects.

            try
            {
                var allowed = new List<StorePlayerStat>();
                var blocked = new List<string>();

                // Try parsing as StorePlayerStats[] (with PlayerId wrapper)
                StorePlayerStats[] statsArray = null;
                try
                {
                    statsArray = (StorePlayerStats[])new FromByteMethod(typeof(StorePlayerStats[])).FromBytes(values[0]);
                }
                catch { }

                if (statsArray != null && statsArray.Length > 0)
                {
                    foreach (var playerStats in statsArray)
                    {
                        // Only allow saving own stats
                        if (playerStats == null) continue;
                        if (!string.IsNullOrEmpty(playerStats.PlayerId) && playerStats.PlayerId != Id) continue;
                        foreach (var stat in playerStats.Stats)
                        {
                            if (_allowedClientStats.Contains(stat.Name))
                                allowed.Add(stat);
                            else
                                blocked.Add(stat.Name);
                        }
                    }
                }
                else
                {
                    // Fallback: try parsing as plain StorePlayerStat[]
                    try
                    {
                        var plainStats = (StorePlayerStat[])new FromByteMethod(typeof(StorePlayerStat[])).FromBytes(values[0]);
                        foreach (var stat in plainStats)
                        {
                            if (stat == null) continue;
                            if (_allowedClientStats.Contains(stat.Name))
                                allowed.Add(stat);
                            else
                                blocked.Add(stat.Name);
                        }
                    }
                    catch { }
                }

                if (blocked.Count > 0)
                    Logger.LogWarn($"[PlayerStatsRemoteService] Player {Id} tried to set blocked stats: {string.Join(", ", blocked)}");

                if (allowed.Count > 0)
                {
                    BoltGameDatabaseProvider.Instance.GetOrCreatePlayerStatsDocument(Id, ensureDefaultStats: false);
                    var repeatedField = new Google.Protobuf.Collections.RepeatedField<StorePlayerStat>();
                    repeatedField.AddRange(allowed);
                    BoltGameDatabaseProvider.Instance.StorePlayerStats(Id, repeatedField);
                    Logger.Log($"[PlayerStatsRemoteService] Player {Id} saved {allowed.Count} stats: {string.Join(", ", allowed.Select(s => s.Name))}");
                }

                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        protected void ResetStats(string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider.Instance.ResetStats(Id);
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                return;
            }
            SendError(guid, 401);
        }

        protected void GetGlobalStats(BinaryValue[] values, string guid)
        {
            // Placeholder for global stats
            SendResponse(guid, new PlayerStat[0]);
        }

        public override async Task InvokeAsync(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "getplayerstats":
                    GetPlayerStats(request.Params.ToArray(), request.Id);
                    break;
                case "getstats":
                    GetStats(request.Params.ToArray(), request.Id);
                    break;
                case "getcurrentstats":
                    GetCurrentStats(request.Params.ToArray(), request.Id);
                    break;
                case "storestats":
                    StoreStats(request.Params.ToArray(), request.Id);
                    break;
                case "resetstats":
                    ResetStats(request.Id);
                    break;
                case "getglobalstats":
                    GetGlobalStats(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        private void SendResponse(string guid, object response = null)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = response != null
                        ? (response is IMessage message
                            ? new BinaryValue { One = message.ToByteString() }
                            : ProtoReflectionUtils.CreateToByteMethod(response.GetType()).ToBytes(response))
                        : new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }
    }
}
