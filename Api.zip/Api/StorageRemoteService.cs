using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandRiseServer.RpcServer.Api
{
    public class StorageRemoteService : RpcClass
    {
        public StorageRemoteService(UserService user) : base(user) { }

        public void WriteFile(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                FromByteMethod from = new FromByteMethod(typeof(string));
                FromByteMethod from2 = new FromByteMethod(typeof(byte[]));
                string FileName = (string)from.FromBytes(values[0]);
                byte[] File = (byte[])from2.FromBytes(values[1]);
                boltMain.WriteOrCreateFile(ObjectId.Parse(Id), FileName, File);
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        public void ReadFiles(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                FileStoragesDocument fileStorage = boltMain.GetFiles(ObjectId.Parse(Id));
                if (fileStorage == null || fileStorage.files == null)
                {
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(Storage[])).ToBytes(Array.Empty<Storage>()) } });
                    return;
                }
                Storage[] storages = fileStorage.files.Select((a) => { int[] intArray = a.Value.AsBsonArray.Select((aa) => aa.AsInt32).ToArray(); byte[] rt = new byte[intArray.Length]; rt = intArray.Select(i => (byte)i).ToArray(); return new Storage { Filename = a.Name, File = ByteString.CopyFrom(rt, 0, rt.Length) }; }).ToArray();
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(Storage[])).ToBytes(storages) } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        public void ReadFile(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                FromByteMethod from = new FromByteMethod(typeof(string));
                string FileName = (string)from.FromBytes(values[0]);
                FileStoragesDocument fileStorage = boltMain.GetFiles(ObjectId.Parse(Id));
                
                if (fileStorage != null && fileStorage.files != null && fileStorage.files.TryGetValue(FileName, out BsonValue fileBson))
                {
                    int[] intArray = fileBson.AsBsonArray.Select((aa) => aa.AsInt32).ToArray();
                    byte[] rt = new byte[intArray.Length];
                    for (int i = 0; i < intArray.Length; i++) rt[i] = (byte)intArray[i];
                    
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(byte[])).ToBytes(rt) } });
                }
                else
                {
                    _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new ToByteMethod(typeof(byte[])).ToBytes(null) } });
                }
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        public void DeleteFile(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltGameDatabaseProvider boltMain = BoltGameDatabaseProvider.Instance;
                FromByteMethod from = new FromByteMethod(typeof(string));
                string FileName = (string)from.FromBytes(values[0]);
                boltMain.DeleteFile(ObjectId.Parse(Id), FileName);
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = new BinaryValue { IsNull = true } } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }

        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "writeFile") WriteFile(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "readAllFiles") ReadFiles(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "readFile") ReadFile(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "deleteFile") DeleteFile(request.Params.ToArray(), request.Id);
            else MethodNotFound(request);
        }
    }
}
