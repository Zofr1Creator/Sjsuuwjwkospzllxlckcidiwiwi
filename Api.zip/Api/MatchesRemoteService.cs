using System;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using StandRiseServer.RpcServer.Helpers;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("MatchesRemoteService")]
    public class MatchesRemoteService : RpcClass
    {
        public MatchesRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getClanMatches":
                    await GetClanMatches(request.Params.ToArray(), request.Id);
                    break;
                case "getMatch":
                    await GetMatch(request.Params.ToArray(), request.Id);
                    break;
                case "getCurrentPlayerLastMatch":
                    await GetCurrentPlayerLastMatch(request.Params.ToArray(), request.Id);
                    break;
                case "getClanLastMatch":
                    await GetClanLastMatch(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerMatches":
                    await GetPlayerMatches(request.Params.ToArray(), request.Id);
                    break;
                case "getPlayerLastMatch":
                    await GetPlayerLastMatch(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private Task GetClanMatches(BinaryValue[] values, string guid)
        {
            SendResponse(guid, new GetClanMatchesResponse());
            return Task.CompletedTask;
        }

        private Task GetMatch(BinaryValue[] values, string guid)
        {
            try
            {
                string matchId = ParseStringParam(values, 0);
                var response = new GetMatchResponse
                {
                    Match = MatchHistoryHelper.GetMatchById(matchId)
                };
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }

            return Task.CompletedTask;
        }

        private Task GetCurrentPlayerLastMatch(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return Task.CompletedTask;
                }

                var response = new GetCurrentPlayerLastMatchResponse
                {
                    PlayerMatch = MatchHistoryHelper.GetPlayerLastMatch(playerId)
                };
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }

            return Task.CompletedTask;
        }

        private Task GetClanLastMatch(BinaryValue[] values, string guid)
        {
            SendResponse(guid, new GetClanLastMatchResponse());
            return Task.CompletedTask;
        }

        private Task GetPlayerMatches(BinaryValue[] values, string guid)
        {
            try
            {
                var req = ParseGetPlayerMatchesRequest(values);
                string playerId = req?.PlayerId;
                if (string.IsNullOrWhiteSpace(playerId) && StaticClasses.Users.TryGetValue(_user.TcpClient, out string selfId))
                {
                    playerId = selfId;
                }

                int offset = req?.Offset?.Offset_ ?? 0;
                int length = req?.Offset?.Length ?? 20;
                if (length <= 0)
                {
                    length = 20;
                }

                var response = new GetPlayerMatchesResponse();
                foreach (var match in MatchHistoryHelper.GetPlayerMatches(playerId, offset, length))
                {
                    response.Matches.Add(match);
                }

                Logger.Log($"[Matches] getPlayerMatches player={playerId} offset={offset} len={length} returned={response.Matches.Count}");
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }

            return Task.CompletedTask;
        }

        private Task GetPlayerLastMatch(BinaryValue[] values, string guid)
        {
            try
            {
                string playerId = ParseStringParam(values, 0);
                if (string.IsNullOrWhiteSpace(playerId) && StaticClasses.Users.TryGetValue(_user.TcpClient, out string selfId))
                {
                    playerId = selfId;
                }

                var response = new GetPlayerLastMatchResponse
                {
                    PlayerMatch = MatchHistoryHelper.GetPlayerLastMatch(playerId)
                };
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }

            return Task.CompletedTask;
        }

        private static GetPlayerMatchesRequest ParseGetPlayerMatchesRequest(BinaryValue[] values)
        {
            if (values == null || values.Length == 0 || values[0]?.One == null)
            {
                return new GetPlayerMatchesRequest();
            }

            var req = new GetPlayerMatchesRequest();
            req.MergeFrom(new CodedInputStream(values[0].One.ToByteArray()));
            return req;
        }

        private static string ParseStringParam(BinaryValue[] values, int index)
        {
            if (values == null || index >= values.Length || values[index]?.One == null)
            {
                return null;
            }

            try
            {
                // Primary path for this RPC stack: argument encoded via ToByteMethod(typeof(string)).
                return (string)new FromByteMethod(typeof(string)).FromBytes(values[index]);
            }
            catch
            {
                try
                {
                    // Fallback for plain UTF-8 payloads.
                    return values[index].One.ToStringUtf8();
                }
                catch
                {
                    return null;
                }
            }
        }

        private void SendResponse(string guid, IMessage response)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { One = response.ToByteString() }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
