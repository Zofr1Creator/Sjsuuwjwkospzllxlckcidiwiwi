using System;
using System.Threading.Tasks;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;

namespace StandRiseServer.RpcServer.Api
{
    public class BoltRemoteService : RpcClass
    {
        public BoltRemoteService(UserService user) : base(user)
        {
        }

        private string GetPlayerId()
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
            {
                return playerId;
            }
            return null;
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }

        private void SendResponse(string guid, IMessage response)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = response != null ? new BinaryValue { One = response.ToByteString() } : new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendResponseRaw(string guid, BinaryValue data)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = data
                }
            });
        }

        public override async Task InvokeAsync(RpcRequest request)
        {
            string playerId = GetPlayerId();
            Console.WriteLine($"BoltRemoteService.{request.MethodName} called, playerId: {playerId}");

            try
            {
                switch (request.MethodName)
                {
                    case "subscribe":
                        await Subscribe(request.Params.ToArray(), request.Id, playerId);
                        break;
                    case "unsubscribe":
                        await Unsubscribe(request.Params.ToArray(), request.Id, playerId);
                        break;
                    case "systemTime":
                        await SystemTime(request.Id);
                        break;
                    default:
                        Console.WriteLine($"BoltRemoteService: Unknown method {request.MethodName}");
                        MethodNotFound(request);
                        break;
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"BoltRemoteService.{request.MethodName} error: {ex.Message}");
                SendError(request.Id, 500);
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task Subscribe(BinaryValue[] values, string guid, string playerId)
        {
            if (values.Length == 0 || values[0].IsNull)
            {
                SendResponse(guid, null);
                return;
            }

            string topic = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
            Console.WriteLine($"BoltRemoteService.Subscribe: topic={topic}, playerId={playerId}");

            if (string.IsNullOrEmpty(playerId))
            {
                SendResponse(guid, null);
                return;
            }

            // Remove old subscriptions
            if (StaticClasses.Subscribes.ContainsKey(playerId))
            {
                StaticClasses.Subscribes.TryRemove(playerId, out _);
            }
            if (StaticClasses.SubscribesTrades.Contains(playerId))
            {
                StaticClasses.SubscribesTrades.Remove(playerId);
            }

            // Add new subscription based on topic
            if (topic.Contains("marketplace_trade_"))
            {
                string request = topic.Replace("marketplace_trade_", "");
                if (int.TryParse(request, out int tradeId))
                {
                    StaticClasses.Subscribes.TryAdd(playerId, tradeId);
                }
            }
            else if (topic.Contains("marketplace_trades"))
            {
                if (!StaticClasses.SubscribesTrades.Contains(playerId))
                {
                    StaticClasses.SubscribesTrades.Add(playerId);
                }
            }
            else if (topic.StartsWith("global_chat_"))
            {
                string[] parts = topic.Substring("global_chat_".Length).Split('_');
                if (parts.Length >= 1 && int.TryParse(parts[^1], out int room))
                {
                    StaticClasses.SubscribesGlobalChat.TryAdd(playerId, room);
                }
            }

            SendResponse(guid, null);
        }

        private async Task Unsubscribe(BinaryValue[] values, string guid, string playerId)
        {
            if (values.Length == 0 || values[0].IsNull)
            {
                SendResponse(guid, null);
                return;
            }

            string topic = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
            Console.WriteLine($"BoltRemoteService.Unsubscribe: topic={topic}, playerId={playerId}");

            if (string.IsNullOrEmpty(playerId))
            {
                SendResponse(guid, null);
                return;
            }

            if (topic.Contains("marketplace_trade_"))
            {
                if (StaticClasses.Subscribes.ContainsKey(playerId))
                {
                    StaticClasses.Subscribes.TryRemove(playerId, out _);
                }
            }
            else if (topic.Contains("marketplace_trades"))
            {
                if (StaticClasses.SubscribesTrades.Contains(playerId))
                {
                    StaticClasses.SubscribesTrades.Remove(playerId);
                }
            }
            else if (topic.Contains("global_chat_") && StaticClasses.SubscribesGlobalChat.ContainsKey(playerId))
            {
                StaticClasses.SubscribesGlobalChat.TryRemove(playerId, out _);
            }

            SendResponse(guid, null);
        }

        private async Task SystemTime(string guid)
        {
            Console.WriteLine("BoltRemoteService.SystemTime called");
            long time = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            SendResponseRaw(guid, new ToByteMethod(typeof(long)).ToBytes(time));
        }
    }
}
