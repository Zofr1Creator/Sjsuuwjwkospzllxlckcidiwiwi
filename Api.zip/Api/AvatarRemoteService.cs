using System;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Game;
using MongoDB.Bson;

namespace StandRiseServer.RpcServer.Api
{
    public class AvatarRemoteService : RpcClass
    {
        public AvatarRemoteService(UserService user) : base(user)
        {
        }

        private string GetPlayerId()
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
            {
                return playerId;
            }
            return null;
        }

        public override void Invoke(RpcRequest request)
        {
            string playerId = GetPlayerId();
            Console.WriteLine($"AvatarRemoteService.{request.MethodName} called, playerId: {playerId}");

            try
            {
                switch (request.MethodName)
                {
                    case "getAvatars":
                        GetAvatars(request.Params.ToArray(), request.Id);
                        break;
                    default:
                        Console.WriteLine($"AvatarRemoteService: Unknown method {request.MethodName}");
                        ReturnError(request.Id, 404);
                        break;
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"AvatarRemoteService.{request.MethodName} error: {ex.Message}");
                ReturnError(request.Id, 500);
            }
        }

        private void GetAvatars(BinaryValue[] values, string guid)
        {
            Console.WriteLine("AvatarRemoteService.GetAvatars called");
            string[] ids = (string[])new FromByteMethod(typeof(string[])).FromBytes(values[0]);
            var avatars = BoltGameDatabaseProvider.Instance.GetAvatars(ids);
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new ToByteMethod(typeof(AvatarBinary[])).ToBytes(avatars)
                }
            });
        }

        private void ReturnError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
