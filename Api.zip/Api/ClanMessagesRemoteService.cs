using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.RpcServer.Core;
using StandRiseServer.RpcServer.Model;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("ClanMessagesRemoteService")]
    public class ClanMessagesRemoteService : RpcClass
    {
        public ClanMessagesRemoteService(UserService user) : base(user) { }

        protected async void GetUnreadChatMessagesCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan != null)
            {
                var messages = clan.GetMessages2();
                int num = messages.Count(m => !m.playersRead.Contains(playerDocument._id.ToString()));
                SendResponse(guid, num);
                return;
            }
            SendResponse(guid, 0);
        }

        protected void GetUnreadLogMessagesCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan != null)
            {
                var logs = BoltMainDatabaseProvider.Instance.GetClanLogMessages(clan.tag);
                // Since GetClanLogMessages returns ClanUserMessage[], we can't easily check playersRead here.
                // However, ReadLogMessagesClan uses a filter on playersRead in the DB.
                // We'll need a way to count them or assume 0 if not easily accessible without BSON.
                // For now, I'll keep it as 0 or implement a simple check if I can get the BSON.
                SendResponse(guid, 0); 
                return;
            }
            SendResponse(guid, 0);
        }

        private void SendClanChatMessage(BinaryValue[] values, string guid)
        {
            string messages = values.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            BoltMainDatabaseProvider.Instance.SendMessageToClan(messages, playerDocument);
            
            Axlebolt.Bolt.Protobuf.ClanMember[] members = BoltMainDatabaseProvider.Instance.GetAllClanMembers(playerDocument);
            
            ClanUserMessage clanUserMessage = new ClanUserMessage
            {
                Id = "",
                MessageType = MessageType.ChatMessage,
                Timestamp = Utils.ToUnixTime(DateTime.UtcNow),
                ChatMessage = new ClanChatMessage
                {
                    SenderId = playerDocument._id.ToString(),
                    Message = messages
                }
            };
            
            foreach (var member in members)
            {
                SendEventToSession<ClanMessagesRemoteEventListener>(member.PlayerFriend.Player.Id, "onIncomingClanChatMessage", clanUserMessage);
            }
            SendResponse(guid);
        }

        protected void GetClanLogMessages(BinaryValue[] values, string guid)
        {
            int from = values.Length > 0 ? values.GetValue<int>(0) : 0;
            int count = values.Length > 1 ? values.GetValue<int>(1) : 20;
            
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan != null)
            {
                ClanUserMessage[] logs = BoltMainDatabaseProvider.Instance.GetClanLogMessages(clan.tag);
                SendResponse(guid, logs.Skip(from).Take(count).ToArray());
                return;
            }
            SendResponse(guid, new ClanUserMessage[0]);
        }

        private void GetClanMessages(BinaryValue[] values, string guid)
        {
            int from = values.Length > 0 ? values.GetValue<int>(0) : 0;
            int count = values.Length > 1 ? values.GetValue<int>(1) : 20;

            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanUserMessage[] documents = BoltMainDatabaseProvider.Instance.GetClanMsgs(playerDocument);
            List<ClanUserMessage> ponos = documents.ToList();
            ponos.Reverse();
            SendResponse(guid, ponos.Skip(from).Take(count).ToArray());
        }

        protected void GetClanChatMessages(BinaryValue[] values, string guid)
        {
            GetClanMessages(values, guid);
        }

        protected void ReadClanMessages(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            BoltMainDatabaseProvider.Instance.ReadMessagesClan(playerDocument);
            SendResponse(guid);
        }

        protected void ReadClanLogMessages(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            BoltMainDatabaseProvider.Instance.ReadLogMessagesClan(playerDocument);
            SendResponse(guid);
        }

        public override void Invoke(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getClanLogMessages":
                    GetClanLogMessages(request.Params.ToArray(), request.Id);
                    break;
                case "sendClanChatMessage":
                    SendClanChatMessage(request.Params.ToArray(), request.Id);
                    break;
                case "getUnreadChatMessagesCount":
                    GetUnreadChatMessagesCount(request.Id);
                    break;
                case "readClanLogMessages":
                    ReadClanLogMessages(request.Id);
                    break;
                case "getUnreadLogMessagesCount":
                    GetUnreadLogMessagesCount(request.Id);
                    break;
                case "getClanChatMessages":
                    GetClanChatMessages(request.Params.ToArray(), request.Id);
                    break;
                case "getClanMessages":
                    GetClanMessages(request.Params.ToArray(), request.Id);
                    break;
                case "readClanChatMessages":
                    ReadClanMessages(request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }
    }
}
