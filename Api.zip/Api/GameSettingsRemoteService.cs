using Axlebolt.RpcSupport.Protobuf;
using Axlebolt.Bolt.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB.Main.GameSettings;
using Google.Protobuf;

namespace StandRiseServer.RpcServer.Api
{
    public class GameSettingsRemoteService : RpcClass
    {
        public GameSettingsRemoteService(UserService user) : base(user)
        {
        }

        protected void GetGameSettingsEnc(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                GameDocument game = boltMain.GetGameInfo();
                GameSetting[] gameSettings = game.androidSettings.Select((a) => a.GetGameSetting()).ToArray();
                
                var response = new GetGameSettingsResponse();
                foreach (var setting in gameSettings)
                    response.GameSettings.Add(setting);

                byte[] key = Encoding.ASCII.GetBytes("key_abcdefghijkl");
                byte[] IV = Encoding.ASCII.GetBytes("iv_abcdefghijklm");
                byte[] encryptedSettings = Utils.EncryptByte(response.ToByteArray(), key, IV);
                BinaryValue value = new BinaryValue { One = ByteString.CopyFrom(encryptedSettings) };
                
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = value } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        protected void GetGameSettings(BinaryValue[] values, string guid)
        {
            if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string Id) || StaticClasses.GameServerUsers.Contains(_user.TcpClient))
            {
                BoltMainDatabaseProvider boltMain = BoltMainDatabaseProvider.Instance;
                GameDocument game = boltMain.GetGameInfo();
                GameSetting[] gameSettings = game.androidSettings.Select((a) => a.GetGameSetting()).ToArray();
                BinaryValue value = new BinaryValue();
                value = new ToByteMethod(typeof(GameSetting[])).ToBytes(gameSettings);
                _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Return = value } });
                return;
            }
            _user.SendResponce(new ResponseMessage { RpcResponse = new RpcResponse { Id = guid, Exception = new Axlebolt.RpcSupport.Protobuf.Exception { Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8), Code = 401 } } });
        }
        public override void Invoke(RpcRequest request)
        {
            if (request.MethodName == "getGameSettingsEncrypted") GetGameSettingsEnc(request.Params.ToArray(), request.Id);
            else if (request.MethodName == "getGameSettings") GetGameSettings(request.Params.ToArray(), request.Id);
            else MethodNotFound(request);
        }
    }
}
