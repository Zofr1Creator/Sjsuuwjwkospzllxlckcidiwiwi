using System;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using StandRiseServer.MongoDB;
using StandRiseServer.RpcServer;
using StandRiseServer.RpcServer.Helpers;
using System.Linq;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("GSMatchesRemoteService")]
    public class GSMatchesRemoteService : RpcClass
    {
        public GSMatchesRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "finishMatch":
                    await FinishMatch(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task FinishMatch(BinaryValue[] values, string guid)
        {
            try
            {
                var request = FinishMatchRequest.Parser.ParseFrom(values[0].One.ToByteArray());
                var match = request.Match;

                if (match == null)
                {
                    Logger.LogWarn("[FinishMatch] Null match payload");
                    SendResponse(guid, new FinishMatchResponse());
                    return;
                }

                int clanPlayers = match.Clans?.Sum(c => c.Players.Count) ?? 0;
                Logger.Log($"[FinishMatch] Finalizing match {match.MatchId} players={match.Players.Count} clans={match.Clans?.Count ?? 0} clanPlayers={clanPlayers}");

                // Resolve canonical MatchId (same logic as HTTP API) so we can merge HTTP stats
                string roomHint = match.Properties
                    .FirstOrDefault(p => string.Equals(p.Name, "RoomId", StringComparison.OrdinalIgnoreCase))
                    ?.StringValue ?? match.MatchId;
                string incomingId = match.MatchId;
                match.MatchId = MatchHistoryHelper.ResolveCanonicalMatchId(incomingId);
                Logger.Log($"[FinishMatch] Resolved MatchId: incoming={incomingId} canonical={match.MatchId} roomHint={roomHint}");

                if (match.Players.Count == 0 && clanPlayers == 0
                    && ActiveRankedMatchRegistry.TryGet(match.MatchId) == null)
                {
                    Logger.LogWarn("[FinishMatch] Empty match payload — nothing to finalize");
                    SendResponse(guid, new FinishMatchResponse());
                    ActiveRankedMatchRegistry.Remove(match.MatchId);
                    return;
                }

                // Merge HTTP match result (which has correct kills/deaths/stats) BEFORE processing
                // Wait briefly for HTTP result to arrive (Photon plugin may call finishMatch before HTTP /api/match/result)
                var httpResult = TryGetHttpResult(match.MatchId, incomingId, roomHint);
                if (httpResult == null)
                {
                    // Wait up to 2 seconds for HTTP result to arrive
                    for (int i = 0; i < 20 && httpResult == null; i++)
                    {
                        await Task.Delay(100);
                        httpResult = TryGetHttpResult(match.MatchId, incomingId, roomHint);
                    }
                }

                if (httpResult != null)
                {
                    Logger.Log($"[FinishMatch] Merging HTTP result for {match.MatchId} from cache");
                    MatchHistoryHelper.MergeHttpScores(match, httpResult);
                }
                else
                {
                    Logger.LogWarn($"[FinishMatch] No HTTP result available for {match.MatchId}, proceeding with Photon payload only");
                }

                var evt = MatchHistoryHelper.ProcessFinishedMatch(match);
                if (evt?.Match == null)
                {
                    Logger.LogWarn($"[FinishMatch] ProcessFinishedMatch returned null for {match.MatchId}. Attempting hard fallback save...");

                    // Hard fallback: attempt to save the raw match data directly so history is not lost.
                    try
                    {
                        string fallbackMode = MatchHistoryHelper.ExtractGameMode(match);
                        var fallbackIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        foreach (var p in match.Players)
                        {
                            if (!string.IsNullOrWhiteSpace(p.PlayerId))
                            {
                                fallbackIds.Add(p.PlayerId);
                            }
                            else if (!string.IsNullOrWhiteSpace(p.PlayerUid))
                            {
                                fallbackIds.Add(p.PlayerUid);
                            }
                        }
                        if (match.Clans != null)
                        {
                            foreach (var clan in match.Clans)
                            {
                                foreach (var p in clan.Players)
                                {
                                    if (!string.IsNullOrWhiteSpace(p.PlayerId))
                                    {
                                        fallbackIds.Add(p.PlayerId);
                                    }
                                    else if (!string.IsNullOrWhiteSpace(p.PlayerUid))
                                    {
                                        fallbackIds.Add(p.PlayerUid);
                                    }
                                }
                            }
                        }
                        // Also try to get player IDs from active ranked match registry
                        if (fallbackIds.Count == 0)
                        {
                            var active = ActiveRankedMatchRegistry.TryGet(match.MatchId, roomHint);
                            if (active != null)
                            {
                                foreach (var slot in active.Players)
                                {
                                    if (!string.IsNullOrWhiteSpace(slot.PlayerId))
                                    {
                                        fallbackIds.Add(slot.PlayerId);
                                    }
                                    else if (!string.IsNullOrWhiteSpace(slot.Uid))
                                    {
                                        fallbackIds.Add(slot.Uid);
                                    }
                                }
                            }
                        }
                        if (fallbackIds.Count > 0)
                        {
                            MatchHistoryHelper.SaveMatchForPlayers(match, fallbackIds, fallbackMode);
                            Logger.Log($"[FinishMatch] Hard fallback save executed for {match.MatchId} players={fallbackIds.Count}");
                        }
                        else
                        {
                            Logger.LogWarn($"[FinishMatch] Hard fallback aborted: no player ids found for {match.MatchId}");
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Logger.LogWarn($"[FinishMatch] Hard fallback exception: {ex.Message}");
                    }
                    finally
                    {
                        // Always clean up active match registry to prevent reconnection to finished match
                        ActiveRankedMatchRegistry.Remove(match.MatchId);
                        StaticClasses.PendingHttpMatchResults.TryRemove(match.MatchId, out _);
                        StaticClasses.PendingHttpMatchResults.TryRemove(incomingId, out _);
                        StaticClasses.PendingHttpMatchResults.TryRemove(roomHint, out _);
                    }

                    SendResponse(guid, new FinishMatchResponse { MatchId = match.MatchId });
                    return;
                }

                match = evt.Match;

                foreach (var player in match.Players)
                {
                    string playerId = player.PlayerId;
                    if (string.IsNullOrWhiteSpace(playerId))
                    {
                        continue;
                    }

                    try
                    {
                        SendEventToSession<MatchesRemoteEventListener>(
                            playerId, "onMatchFinished", new object[] { evt });
                    }
                    catch (System.Exception broadcastEx)
                    {
                        Logger.LogWarn($"[FinishMatch] onMatchFinished failed for {playerId}: {broadcastEx.Message}");
                        if (evt != null)
                        {
                            StaticClasses.PendingMatchFinishedEvents[playerId] = evt;
                        }
                    }
                }

                SendResponse(guid, new FinishMatchResponse { MatchId = match.MatchId });
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
            finally
            {
                // Ensure cleanup even on exception path
            }

            await Task.CompletedTask;
        }

        private static HttpApiServer.MatchResult TryGetHttpResult(string matchId, string incomingId, string roomHint)
        {
            if (StaticClasses.PendingHttpMatchResults.TryGetValue(matchId, out var result))
                return result;
            if (StaticClasses.PendingHttpMatchResults.TryGetValue(incomingId, out result))
                return result;
            if (StaticClasses.PendingHttpMatchResults.TryGetValue(roomHint, out result))
                return result;
            return null;
        }

        private void SendResponse(string guid, IMessage response)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new BinaryValue { One = response.ToByteString() }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
