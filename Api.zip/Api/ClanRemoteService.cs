using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using MongoDB.Bson;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.RpcServer.Core;
using StandRiseServer.RpcServer.Helpers;
using StandRiseServer.RpcServer.Model;
using StandRiseServer.RpcServer.Clans.Mappers;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("ClanRemoteService")]
    public class ClanRemoteService : RpcClass
    {
        public ClanRemoteService(UserService user) : base(user) { }

        protected async void CreateClan(BinaryValue[] binaryValues, string guid)
        {
            try
            {
                PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
                int priceClan = -4000;
                var existingClan = BoltMainDatabaseProvider.Instance.GetPlayerClan(playerDocument);
                Console.WriteLine($"[Clan] CreateClan: PlayerId={PlayerId}, existingClan={existingClan != null}");
                
                if (BoltGameDatabaseProvider.Instance.IsEnoughFunds(PlayerId, 102.ToString(), priceClan) && existingClan == null)
                {
                    string clanTag = binaryValues.GetValue<string>(0);
                    string clanName = binaryValues.GetValue<string>(1);
                    int clanType = binaryValues.GetValue<int>(2);
                    
                    // Validate clan name and tag
                    if (string.IsNullOrWhiteSpace(clanName) || clanName.Length < 3)
                    {
                        Console.WriteLine($"[Clan] CreateClan: Invalid clan name '{clanName}'");
                        SendError(guid, 2017); // Invalid clan name error
                        return;
                    }
                    
                    if (string.IsNullOrWhiteSpace(clanTag) || clanTag.Length < 2)
                    {
                        Console.WriteLine($"[Clan] CreateClan: Invalid clan tag '{clanTag}'");
                        SendError(guid, 2019); // Invalid clan tag error
                        return;
                    }
                    
                    BsonDateTime clanDate = BsonDateTime.Create(DateTime.Now);
                    
                    Console.WriteLine($"[Clan] CreateClan: Validating name='{clanName}', tag='{clanTag}', type={clanType}");
                    
                    ClanDocument clanDocument = new ClanDocument
                    {
                        _id = ObjectId.GenerateNewId(),
                        name = clanName,
                        tag = clanTag,
                        avatarId = "default_clan_avatar",
                        description = "123",
                        membersCount = 1,
                        maxMembersCount = 10,
                        clanLevel = 1,
                        creationDate = clanDate,
                        type = (ClanType)clanType,
                        isBanned = false,
                        isVerified = false,
                        isOfficial = false,
                        wins = 0,
                        losses = 0,
                        draws = 0,
                        totalMatches = 0,
                        winRate = 0.0,
                        ranking = 0,
                        mmr = 1000,
                        seasonId = 1,
                        region = "EU",
                        language = "ru",
                        stats = new BsonDocument
                        {
                            { "clan_ranked_current_mmr", 1000 },
                            { "clan_ranked_rank", 1 },
                            { "clan_ranked_best_rank", 1 },
                            { "clan_ranked_played_matches", 0 },
                            { "clan_ranked_won_match_count", 0 },
                            { "clan_ranked_calibration_match_count", 0 },
                            { "clan_ranked_xp", 0 },
                            { "clan_ranked_best_rank_history1", 0 },
                            { "clan_ranked_season_id", 1 },
                            { "clan_ranked_is_banned", 0 }
                        },
                        settings = new BsonDocument(),
                        metadata = new BsonDocument(),
                        permissions = new BsonDocument(),
                        seasonStats = new BsonDocument()
                    };

                    Console.WriteLine($"[Clan] Creating clan: _id={clanDocument._id}, tag='{clanTag}', name='{clanName}'");

                    BoltGameDatabaseProvider.Instance.CurrencyMinusValue(PlayerObjectId, 102, priceClan);
                    BoltMainDatabaseProvider.Instance.AddPlayerToClan(playerDocument, clanDocument);
                    BoltMainDatabaseProvider.Instance.CreateClan(clanDocument, playerDocument);
                    
                    Console.WriteLine($"[Clan] Clan created successfully, sending response");
                    
                    var clanProto = ClanMapper.Instance.ToProto(clanDocument);
                    Console.WriteLine($"[Clan] ClanProto: Id={clanProto?.Id}, Name='{clanProto?.Name}', Tag='{clanProto?.Tag}', Type={clanProto?.ClanType}");
                    
                    SendResponse(guid, clanProto);
                }
                else
                {
                    Console.WriteLine($"[Clan] CreateClan denied: funds={BoltGameDatabaseProvider.Instance.IsEnoughFunds(PlayerId, 102.ToString(), priceClan)}, alreadyInClan={existingClan != null}");
                    SendError(guid, 1332);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Clan] CreateClan ERROR: {ex.Message}");
                Console.WriteLine($"[Clan] CreateClan STACK: {ex.StackTrace}");
                SendError(guid, 1332);
            }
        }

        private void GetClan(string guid)
        {
            Console.WriteLine($"[Clan] GetClan called for PlayerId={PlayerId}, PlayerObjectId={PlayerObjectId}");
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            Console.WriteLine($"[Clan] PlayerDocument found: {playerDocument != null}, _id={playerDocument?._id}");
            
            if (playerDocument == null)
            {
                Console.WriteLine($"[Clan] GetClan: PlayerDocument is null");
                SendResponse(guid, (Clan)null);
                return;
            }
            
            ClanDocument clanDoc = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            Console.WriteLine($"[Clan] GetClan: clanDoc={clanDoc != null}, name='{clanDoc?.name}', tag='{clanDoc?.tag}', membersCount={clanDoc?.membersCount}");
            
            if (clanDoc == null)
            {
                Console.WriteLine($"[Clan] GetClan: Player not in clan");
                SendResponse(guid, (Clan)null);
                return;
            }
            
            Clan clanProto = ClanMapper.Instance.ToProto(clanDoc);
            Console.WriteLine($"[Clan] GetClan: Returning clan proto Id={clanProto?.Id}, Name={clanProto?.Name}, Tag={clanProto?.Tag}");
            
            // Send initial clan data event to update UI
            try
            {
                Console.WriteLine($"[Clan] GetClan: Sending OnJoinedToClan event to refresh UI");
                OnJoinedToClanEvent joinedEvent = new OnJoinedToClanEvent
                {
                    Clan = clanProto
                };
                SendEventToSession<ClansRemoteEventListener>(PlayerId, "OnJoinedToClan", joinedEvent);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine($"[Clan] GetClan: Error sending OnJoinedToClan event: {ex.Message}");
            }
            
            SendResponse(guid, clanProto);
        }

        private void ChangeClanName(BinaryValue[] binaryValues, string guid)
        {
            string newName = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            Clan playerClan = BoltMainDatabaseProvider.Instance.GetPlayerClan(playerDocument);
            BoltMainDatabaseProvider.Instance.ChangeClanName(playerClan, newName);
            SendResponse(guid);

            OnClanNameChanged onClanNameChanged = new OnClanNameChanged
            {
                NewName = newName
            };
            SendEventToClanMembers(playerDocument, "OnClanNameChanged", onClanNameChanged);
        }

        private void ChangeClanDescription(BinaryValue[] binaryValues, string guid)
        {
            string description = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            BoltMainDatabaseProvider.Instance.SetClanDescription(clanDocument, description);
            SendResponse(guid);
            SendEventToClanMembers(playerDocument, "OnClanDescriptionChanged", new object[] { description ?? "" });
        }

        private void GetClanById(BinaryValue[] binaryValues, string guid)
        {
            string clanId = binaryValues.GetValue<string>(0);
            ClanDocument clanDoc = BoltMainDatabaseProvider.Instance.GetClanDocument(clanId);
            SendResponse(guid, ClanMapper.Instance.ToProto(clanDoc));
        }

        private void ChangeClanType(BinaryValue[] binaryValues, string guid)
        {
            int newClanType = binaryValues.GetValue<int>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            BoltMainDatabaseProvider.Instance.ChangeClanType(clanDocument, (ClanType)newClanType);
            BoltMainDatabaseProvider.Instance.AddLog(Axlebolt.Bolt.Clans.BoltClanLogType.ClanTypeChanged, playerDocument, changedType: (ClanType)newClanType);
            SendResponse(guid);

            OnClanTypeChanged onClanTypeChanged = new OnClanTypeChanged
            {
                NewClanType = (ClanType)newClanType
            };
            SendEventToSession<ClansRemoteEventListener>(PlayerId, "OnClanTypeChanged", onClanTypeChanged);
        }

        private void GetClanGames(BinaryValue[] binaryValues, string guid)
        {
            // Replicating getClanGames - for now returning empty list or recommended clans as games
            // In a real implementation this might return active clan wars or lobbies.
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = new ToByteMethod(typeof(object[])).ToBytes(Array.Empty<object>())
                }
            });
        }

        private void LeaveClan(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clanDocument == null)
            {
                SendResponse(guid);
                return;
            }

            OnLeftFromClan onLeftFromClan = new OnLeftFromClan
            {
                MemberId = playerDocument._id.ToString()
            };

            foreach (var member in clanDocument.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnLeftFromClan", onLeftFromClan);
            }

            BoltMainDatabaseProvider.Instance.LeaveClan(clanDocument, playerDocument);
            SendResponse(guid);
        }

        private void GetRoles(string guid)
        {
            ClanMemberRole[] clanMemberRoles = BoltMainDatabaseProvider.Instance.GetRoles();
            SendResponse(guid, clanMemberRoles);
        }

        private void SetClanAvatar(BinaryValue[] binaryValues, string guid)
        {
            byte[] newClanAvatar = binaryValues.GetValue<byte[]>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            int[] rt = newClanAvatar.Select(i => (int)i).ToArray();
            string avatarId = BoltGameDatabaseProvider.Instance.FindOrCreateAvatar(rt); // Use common FindOrCreateAvatar
            BoltMainDatabaseProvider.Instance.SetClanAvatar(clanDocument, avatarId);
            SendResponse(guid, avatarId);
        }

        private void GetAvatars(BinaryValue[] binaryValues, string guid)
        {
            string[] avatarIds = binaryValues.GetValue<string[]>(0);
            AvatarBinary[] avatarBinaries = BoltGameDatabaseProvider.Instance.GetAvatars(avatarIds);
            SendResponse(guid, avatarBinaries);
        }

        private void SendMsgToClan(BinaryValue[] binaryValues, string guid)
        {
            string msg = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            BoltMainDatabaseProvider.Instance.SendMessageToClan(msg, playerDocument);
            SendResponse(guid);
        }

        private void FindClan(BinaryValue[] values, string guid)
        {
            string filter = values.GetValue<string>(0);
            int page = values.GetValue<int>(1);
            int size = values.GetValue<int>(2);
            Clan[] clans = BoltMainDatabaseProvider.Instance.FindAllClans(filter, filter);
            IEnumerable<Clan> result = clans.Skip(page * size).Take(size);
            SendResponse(guid, result.ToArray());
        }

        private void GetClanChatMessages(BinaryValue[] binaryValues, string guid)
        {
            GetClanMsgs(binaryValues, guid);
        }

        private void GetClanMsgs(BinaryValue[] binaryValues, string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanUserMessage[] messagesToClan = BoltMainDatabaseProvider.Instance.GetClanMsgs(playerDocument);
            SendResponse(guid, messagesToClan);
        }

        private void GetClanMembers(string guid)
        {
            Console.WriteLine($"[Clan] GetClanMembers: START for PlayerId={PlayerId}");
            
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            if (playerDocument == null)
            {
                Console.WriteLine($"[Clan] GetClanMembers: playerDocument is null");
                SendResponse(guid, new Axlebolt.Bolt.Protobuf.ClanMember[0]);
                return;
            }
            
            Console.WriteLine($"[Clan] GetClanMembers: playerDocument found, _id={playerDocument._id}");
            
            ClanDocument clanDoc = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clanDoc == null)
            {
                Console.WriteLine($"[Clan] GetClanMembers: clanDoc is null for player {playerDocument._id}");
                SendResponse(guid, new Axlebolt.Bolt.Protobuf.ClanMember[0]);
                return;
            }
            
            Console.WriteLine($"[Clan] GetClanMembers: clanDoc found, name='{clanDoc.name}', tag='{clanDoc.tag}'");
            
            var members = clanDoc.GetMembers();
            Console.WriteLine($"[Clan] GetClanMembers: Found {members.Count} members for clan {clanDoc.name} (tag: {clanDoc.tag})");
            
            foreach (var member in members)
            {
                Console.WriteLine($"[Clan] GetClanMembers: Member - Name={member.PlayerFriend?.Player?.Name}, Role={member.RoleId}");
            }
            
            SendResponse(guid, members.ToArray());
            Console.WriteLine($"[Clan] GetClanMembers: Response sent with {members.Count} members");
        }

        private async void AssignRoleToMember(BinaryValue[] binaryValues, string guid)
        {
            string memberId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(memberId));
            PlayerDocument localPlayerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(localPlayerDocument);

            if (clanDocument == null)
            {
                SendError(guid, 2008);
                return;
            }

            // Нельзя назначать роль самому себе
            if (memberId == PlayerId)
            {
                SendError(guid, 2016);
                return;
            }

            // Получаем текущую роль вызывающего напрямую из документа клана
            int callerRoleId = 1000;
            if (clanDocument.members != null && clanDocument.members.TryGetValue(PlayerId, out var callerBson) && callerBson.IsBsonDocument)
            {
                var callerDoc = callerBson.AsBsonDocument;
                if (callerDoc.TryGetValue("role", out var callerRoleVal) && callerRoleVal.IsString)
                    callerRoleId = BoltMainDatabaseProvider.Instance.GetClanMemberRoleByIdString(callerRoleVal.AsString).Id;
            }

            // Только Leader (0), Co-Leader (10) и кастомные лидер-роли могут назначать роли
            if (callerRoleId != 0 && callerRoleId != 10 && callerRoleId != 5)
            {
                SendError(guid, 2016);
                return;
            }

            // Клиент шлёт роль как строку ("Co-Leader", "Elder" и т.д.)
            ClanMemberRole role;
            string roleRaw = binaryValues.GetValue<string>(1);
            if (!string.IsNullOrEmpty(roleRaw) && !int.TryParse(roleRaw, out _))
            {
                role = BoltMainDatabaseProvider.Instance.GetClanMemberRole(roleRaw);
            }
            else
            {
                int newRole = binaryValues.GetValue<int>(1);
                role = BoltMainDatabaseProvider.Instance.GetClanMemberRoleById(newRole);
            }

            // Нельзя назначить роль Leader через этот метод (только через assignLeaderRole)
            if (role.Id == 0)
            {
                SendError(guid, 2016);
                return;
            }

            // Co-Leader не может назначать роль Co-Leader или выше
            if (callerRoleId == 10 && role.Id <= 10)
            {
                SendError(guid, 2016);
                return;
            }

            await BoltMainDatabaseProvider.Instance.AssignRoleToMember(role.Id, playerDocument);
            
            OnAssignedRoleEvent onAssignedRoleEvent = new OnAssignedRoleEvent
            {
                AssignatorMemberId = localPlayerDocument._id.ToString(),
                AssigningMemberId = playerDocument._id.ToString(),
                NewRole = role
            };

            foreach (var member in clanDocument.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnAssignedRoleEvent", onAssignedRoleEvent);
            }
            SendResponse(guid);
        }

        private async void AssignLeaderRole(BinaryValue[] binaryValues, string guid)
        {
            string memberId = binaryValues.GetValue<string>(0);
            string myNewRoleName = binaryValues.GetValue<string>(1); // роль для текущего лидера после передачи
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(memberId));
            PlayerDocument localPlayerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(localPlayerDocument);

            // Определяем роль для старого лидера
            ClanMemberRole oldLeaderNewRole;
            if (!string.IsNullOrEmpty(myNewRoleName) && !int.TryParse(myNewRoleName, out _))
                oldLeaderNewRole = BoltMainDatabaseProvider.Instance.GetClanMemberRole(myNewRoleName);
            else
                oldLeaderNewRole = BoltMainDatabaseProvider.Instance.GetClanMemberRoleById(10); // Co-Leader по умолчанию

            ClanMemberRole leaderRole = BoltMainDatabaseProvider.Instance.GetClanMemberRoleById(0);

            // Старый лидер получает новую роль
            await BoltMainDatabaseProvider.Instance.AssignRoleToMember(oldLeaderNewRole.Id, localPlayerDocument);
            // Новый лидер получает роль Leader
            await BoltMainDatabaseProvider.Instance.AssignRoleToMember(0, playerDocument);
            
            OnAssignedRoleEvent onAssignedRoleEventNewLeader = new OnAssignedRoleEvent
            {
                AssignatorMemberId = localPlayerDocument._id.ToString(),
                AssigningMemberId = playerDocument._id.ToString(),
                NewRole = leaderRole
            };
            OnAssignedRoleEvent onAssignedRoleEventOldLeader = new OnAssignedRoleEvent
            {
                AssignatorMemberId = playerDocument._id.ToString(),
                AssigningMemberId = localPlayerDocument._id.ToString(),
                NewRole = oldLeaderNewRole
            };

            foreach (var member in clanDocument.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnAssignedRoleEvent", onAssignedRoleEventNewLeader);
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnAssignedRoleEvent", onAssignedRoleEventOldLeader);
            }
            SendResponse(guid);
        }

        private void DeleteClanMsgs(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            BoltMainDatabaseProvider.Instance.DeleteClanMsgs(playerDocument);
            SendResponse(guid);
        }

        private void RequestToJoinClan(BinaryValue[] binaryValues, string guid)
        {
            string clanId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetClanDocument(clanId);
            
            if (clanDocument == null)
            {
                SendError(guid, 2008);
                return;
            }

            int effectiveMaxMembers = clanDocument.maxMembersCount > 0 ? clanDocument.maxMembersCount : 10;
            if (clanDocument.membersCount >= effectiveMaxMembers)
            {
                SendError(guid, 2015);
                return;
            }

            // Открытый клан — сразу добавляем без заявки
            if (clanDocument.type == ClanType.Open)
            {
                try
                {
                    BoltMainDatabaseProvider.Instance.JoinClan(clanDocument, playerDocument);
                }
                catch (ClanNotFoundRpcException)
                {
                    SendError(guid, 2008);
                    return;
                }
                catch (PlayerIsAlreadyInClanRpcException)
                {
                    SendError(guid, 2011);
                    return;
                }

                OnJoinedToClanEvent joinedEvent = new OnJoinedToClanEvent
                {
                    Clan = ClanMapper.Instance.ToProto(clanDocument)
                };
                SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnJoinedToClan", joinedEvent);

                foreach (var member in clanDocument.GetMembers())
                {
                    OnMemberJoinedToClanEvent memberJoinedEvent = new OnMemberJoinedToClanEvent
                    {
                        ClanMember = new Axlebolt.Bolt.Protobuf.ClanMember
                        {
                            ClanId = clanDocument._id.ToString(),
                            RoleId = 1000,
                            CreateDate = Utils.ToUnixTime(DateTime.UtcNow)
                        }
                    };
                    memberJoinedEvent.ClanMember.PlayerFriend.Player = FriendHelper.GetPlayer(playerDocument._id.ToString());
                    memberJoinedEvent.ClanMember.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
                    SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnMemberJoinedToClan", memberJoinedEvent);
                }

                SendResponse(guid);
                return;
            }

            // Есть приглашение от клана — принимаем его, сразу добавляем
            ClanInviteDocument existingInviteForPlayer = BoltMainDatabaseProvider.Instance.GetInviteByClanAndPlayer(clanDocument._id.ToString(), playerDocument._id.ToString());
            if (existingInviteForPlayer != null)
            {
                try
                {
                    BoltMainDatabaseProvider.Instance.JoinClan(clanDocument, playerDocument);
                }
                catch (ClanNotFoundRpcException)
                {
                    SendError(guid, 2008);
                    return;
                }
                catch (PlayerIsAlreadyInClanRpcException)
                {
                    SendError(guid, 2011);
                    return;
                }

                BoltMainDatabaseProvider.Instance.DeleteInvite(existingInviteForPlayer._id.ToString());

                OnJoinedToClanEvent joinedEvent = new OnJoinedToClanEvent
                {
                    Clan = ClanMapper.Instance.ToProto(clanDocument)
                };
                SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnJoinedToClan", joinedEvent);

                foreach (var member in clanDocument.GetMembers())
                {
                    OnMemberJoinedToClanEvent memberJoinedEvent = new OnMemberJoinedToClanEvent
                    {
                        ClanMember = new Axlebolt.Bolt.Protobuf.ClanMember
                        {
                            ClanId = clanDocument._id.ToString(),
                            RoleId = 1000,
                            CreateDate = Utils.ToUnixTime(DateTime.UtcNow)
                        }
                    };
                    memberJoinedEvent.ClanMember.PlayerFriend.Player = FriendHelper.GetPlayer(playerDocument._id.ToString());
                    memberJoinedEvent.ClanMember.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
                    SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnMemberJoinedToClan", memberJoinedEvent);
                }

                SendResponse(guid);
                return;
            }

            // Закрытый клан или клан по заявке — создаём заявку
            ClanJoinRequest request = BoltMainDatabaseProvider.Instance.RequestToJoinClan(clanId, playerDocument);
            if (request == null)
            {
                SendResponse(guid);
                return;
            }

            OnJoinRequestTakenEvent onTakenEvent = new OnJoinRequestTakenEvent
            {
                RequestId = request.Id,
                Player = request.RequestSender
            };

            foreach (var member in clanDocument.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnJoinRequestTaken", onTakenEvent);
            }
            SendResponse(guid);
        }

        private void InviteToClan(BinaryValue[] binaryValues, string guid)
        {
            string playerId = binaryValues.GetValue<string>(0);
            PlayerDocument localPlayerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(localPlayerDocument);
            if (clanDocument == null)
            {
                SendError(guid, 2008);
                return;
            }

            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
            if (playerDocument == null)
            {
                SendError(guid, 404);
                return;
            }

            ClanInviteDocument existingInvite = BoltMainDatabaseProvider.Instance.GetInviteByPlayer(clanDocument._id.ToString(), localPlayerDocument._id.ToString(), playerDocument._id.ToString());
            ClanRequestDocument existingRequest = BoltMainDatabaseProvider.Instance.GetJoinRequestByPlayer(clanDocument._id.ToString(), playerId);

            if (existingInvite == null && existingRequest != null)
            {
                if (clanDocument.membersCount >= clanDocument.maxMembersCount)
                {
                    SendError(guid, 2015);
                    return;
                }
                try
                {
                    BoltMainDatabaseProvider.Instance.JoinClan(clanDocument, playerDocument);
                }
                catch (ClanNotFoundRpcException)
                {
                    SendError(guid, 2008);
                    return;
                }
                catch (PlayerIsAlreadyInClanRpcException)
                {
                    SendError(guid, 2011);
                    return;
                }

                BoltMainDatabaseProvider.Instance.DeleteJoinRequest(existingRequest._id.ToString());
                
                OnInviteRequestAcceptedEvent onAcceptedEvent = new OnInviteRequestAcceptedEvent
                {
                    Player = FriendHelper.GetPlayer(playerId)
                };

                foreach (var member in clanDocument.GetMembers())
                {
                    SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnInviteRequestAccepted", onAcceptedEvent);
                }
                SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnInviteRequestAccepted", onAcceptedEvent);
                
                SendResponse(guid);
                return;
            }

            ClanInviteRequest invite = BoltMainDatabaseProvider.Instance.InviteToClan(clanDocument, localPlayerDocument, playerDocument);
            if (invite != null)
            {
                OnInvitedToClanEvent onInvitedEvent = new OnInvitedToClanEvent
                {
                    RequestId = invite.Id,
                    Clan = clanDocument.GetClan(),
                    Player = FriendHelper.GetPlayer(playerDocument._id.ToString())
                };
                SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnInvitedToClanEvent", onInvitedEvent);
                SendResponse(guid);
            }
            else
            {
                SendError(guid, 2008);
            }
        }

        private void KickMember(BinaryValue[] binaryValues, string guid)
        {
            string playerId = binaryValues.GetValue<string>(0);
            string kickingReason = binaryValues.GetValue<string>(1);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(playerId));
            PlayerDocument localPlayerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(localPlayerDocument);
            
            BoltMainDatabaseProvider.Instance.LeaveClan(clanDocument, playerDocument);
            
            OnKickedEvent onKickedEvent = new OnKickedEvent
            {
                KickingReason = kickingReason
            };
            SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnKickedEvent", onKickedEvent);

            OnKickedMemberEvent onKickedMemberEvent = new OnKickedMemberEvent
            {
                KickedMemberId = playerDocument._id.ToString(),
                KickerMemberId = localPlayerDocument._id.ToString()
            };

            foreach (var member in clanDocument.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnKickedMember", onKickedMemberEvent);
            }
            SendResponse(guid);
        }

        private void GetClanSettings(string guid)
        {
            SendResponse(guid, ClanSettingsMapper.Instance.ToProto(null));
        }

        private void GetPlayerInviteRequestsCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            List<ClanInviteDocument> invites = BoltMainDatabaseProvider.Instance.GetPlayerInvites(playerDocument);
            SendResponse(guid, invites.Count);
        }

        private void GetPlayerClosedJoinRequestsCount(string guid)
        {
            // Placeholder: currently no tracking for closed requests in DB
            SendResponse(guid, 0);
        }

        private void GetClanJoinRequestsCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan == null)
            {
                SendResponse(guid, 0);
                return;
            }
            List<ClanRequestDocument> requests = BoltMainDatabaseProvider.Instance.GetClanRequests(clan);
            SendResponse(guid, requests.Count);
        }

        private void GetClanClosedInviteRequestsCount(string guid)
        {
            // Placeholder: currently no tracking for closed requests in DB
            SendResponse(guid, 0);
        }

        private void ValidateClanName(BinaryValue[] binaryValues, string guid)
        {
            string nameClan = binaryValues.GetValue<string>(0);
            try
            {
                BoltMainDatabaseProvider.Instance.ValidateClanName(nameClan);
                SendResponse(guid);
            }
            catch (ClanNameAlreadyExistsRpcException)
            {
                SendError(guid, 2018);
            }
            catch (InvalidClanNameRpcException)
            {
                SendError(guid, 2017);
            }
        }

        private void ValidateClanTag(BinaryValue[] binaryValues, string guid)
        {
            string tagClan = binaryValues.GetValue<string>(0);
            try
            {
                BoltMainDatabaseProvider.Instance.ValidateClanTag(tagClan);
                SendResponse(guid);
            }
            catch (InvalidClanTagRpcException)
            {
                SendError(guid, 2016);
            }
            catch (ClanTagAlreadyExistsRpcException)
            {
                SendError(guid, 2019);
            }
        }

        public void SetClanDescription(BinaryValue[] binaryValues, string guid)
        {
            string description = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            BoltMainDatabaseProvider.Instance.SetClanDescription(clan, description);
            BoltMainDatabaseProvider.Instance.AddLog(Axlebolt.Bolt.Clans.BoltClanLogType.ClanDescriptionChanged, playerDocument);
            SendResponse(guid);
        }

        public void IncreaseMaxMembersCount(BinaryValue[] binaryValues, string guid)
        {
            int newCount = binaryValues.GetValue<int>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            BoltMainDatabaseProvider.Instance.IncreaseMaxMembersCount(clan, newCount);
            BoltMainDatabaseProvider.Instance.AddLog(Axlebolt.Bolt.Clans.BoltClanLogType.ClanMaxMembersCountChanged, playerDocument);
            SendResponse(guid);
        }

        private void GetClanJoinRequests(BinaryValue[] binaryValues, string guid)
        {
            int offset = binaryValues.GetValue<int>(0);
            int length = binaryValues.GetValue<int>(1);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan == null)
            {
                SendResponse(guid, new ClanJoinRequest[0]);
                return;
            }
            List<ClanRequestDocument> requests = BoltMainDatabaseProvider.Instance.GetClanRequests(clan);
            SendResponse(guid, ClanJoinRequestMapper.Instance.ToProtoArray(requests.AsEnumerable().Reverse().Skip(offset).Take(length)));
        }

        private void GetClanInviteRequests(BinaryValue[] binaryValues, string guid)
        {
            int offset = binaryValues.GetValue<int>(0);
            int length = binaryValues.GetValue<int>(1);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan == null)
            {
                SendResponse(guid, new Axlebolt.Bolt.Protobuf.ClanInviteRequest[0]);
                return;
            }
            List<ClanInviteDocument> requests = BoltMainDatabaseProvider.Instance.GetClanInvites(clan);
            SendResponse(guid, ClanInviteRequestMapper.Instance.ToProtoArray(requests.AsEnumerable().Reverse().Skip(offset).Take(length)));
        }

        private void GetPlayerInviteRequests(BinaryValue[] binaryValues, string guid)
        {
            int offset = binaryValues.GetValue<int>(0);
            int length = binaryValues.GetValue<int>(1);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            List<ClanInviteDocument> invites = BoltMainDatabaseProvider.Instance.GetPlayerInvites(playerDocument);
            SendResponse(guid, ClanInviteRequestMapper.Instance.ToProtoArray(invites.Skip(offset).Take(length)));
        }

        private void GetPlayerJoinRequests(BinaryValue[] binaryValues, string guid)
        {
            int offset = binaryValues.GetValue<int>(0);
            int length = binaryValues.GetValue<int>(1);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            List<ClanRequestDocument> requests = BoltMainDatabaseProvider.Instance.GetPlayerRequests(playerDocument);
            SendResponse(guid, ClanJoinRequestMapper.Instance.ToProtoArray(requests.AsEnumerable().Reverse().Skip(offset).Take(length)));
        }

        private void GetClanMembersByClanId(BinaryValue[] binaryValues, string guid)
        {
            string clanId = binaryValues.GetValue<string>(0);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetClanDocument(clanId);
            if (clan == null)
            {
                SendResponse(guid, new Axlebolt.Bolt.Protobuf.ClanMember[0]);
                return;
            }
            SendResponse(guid, clan.GetMembers().ToArray());
        }

        private void DeclineJoinRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var requestDoc = BoltMainDatabaseProvider.Instance.GetJoinRequest(requestId);
            if (requestDoc == null)
            {
                SendResponse(guid);
                return;
            }
            ClanJoinRequest request = requestDoc.GetInviteRequest();
            
            OnRequestDeclined declEvent = new OnRequestDeclined
            {
                RequestId = requestId,
                RequestType = request.RequestType,
                ClanToJoin = request.Clan,
                InvitedPlayer = request.RequestSender
            };
            
            BoltMainDatabaseProvider.Instance.DeleteJoinRequest(requestId);
            SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnRequestDeclined", declEvent);
            SendEventToSession<ClansRemoteEventListener>(request.RequestSender.Id, "OnRequestDeclined", declEvent);
            SendResponse(guid);
        }

        private void CancelJoinRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var requestDoc = BoltMainDatabaseProvider.Instance.GetJoinRequest(requestId);
            if (requestDoc == null)
            {
                SendResponse(guid);
                return;
            }
            ClanJoinRequest request = requestDoc.GetInviteRequest();
            
            OnRequestDeclined declEvent = new OnRequestDeclined
            {
                RequestId = requestId,
                RequestType = request.RequestType,
                ClanToJoin = request.Clan,
                InvitedPlayer = request.RequestSender
            };
            
            BoltMainDatabaseProvider.Instance.DeleteJoinRequest(requestId);
            SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnRequestDeclined", declEvent);
            SendEventToSession<ClansRemoteEventListener>(request.RequestSender.Id, "OnRequestDeclined", declEvent);
            SendResponse(guid);
        }

        private void GetRecommendedClans(BinaryValue[] values, string guid)
        {
            int count = values.GetValue<int>(0);
            List<ClanDocument> clans = BoltMainDatabaseProvider.Instance.GetRandomClanDocuments(count);
            SendResponse(guid, ClanMapper.Instance.ToProtoArray(clans));
        }

        private void RenameClan(BinaryValue[] values, string guid)
        {
            string tag = values.GetValue<string>(0);
            string name = values.GetValue<string>(1);
            if (BoltGameDatabaseProvider.Instance.IsEnoughFunds(PlayerId, 102.ToString(), -4000f))
            {
                PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
                BoltMainDatabaseProvider.Instance.RenameClan(BoltMainDatabaseProvider.Instance.GetPlayerClan(playerDocument), tag, name);
                SendResponse(guid);
            }
            else
            {
                SendError(guid, 401);
            }
        }

        private void DeclineInviteRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var inviteDoc = BoltMainDatabaseProvider.Instance.GetInvite(requestId);
            if (inviteDoc == null)
            {
                SendResponse(guid);
                return;
            }
            ClanInviteRequest request = inviteDoc.GetInviteRequest();

            OnRequestDeclined declEvent = new OnRequestDeclined
            {
                RequestId = requestId,
                RequestType = request.RequestType,
                ClanToJoin = request.Clan,
                InvitedPlayer = request.InvitedPlayer
            };

            BoltMainDatabaseProvider.Instance.DeleteInvite(requestId);
            SendEventToSession<ClansRemoteEventListener>(inviteDoc.senderId, "OnRequestDeclined", declEvent);
            SendEventToSession<ClansRemoteEventListener>(inviteDoc.invitedId, "OnRequestDeclined", declEvent);
            SendResponse(guid);
        }

        private void CancelInviteRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var inviteDoc = BoltMainDatabaseProvider.Instance.GetInvite(requestId);
            if (inviteDoc == null)
            {
                SendResponse(guid);
                return;
            }
            ClanInviteRequest request = inviteDoc.GetInviteRequest();

            OnRequestDeclined declEvent = new OnRequestDeclined
            {
                RequestId = requestId,
                RequestType = request.RequestType,
                ClanToJoin = request.Clan,
                InvitedPlayer = request.InvitedPlayer
            };

            BoltMainDatabaseProvider.Instance.DeleteInvite(requestId);
            SendEventToSession<ClansRemoteEventListener>(inviteDoc.senderId, "OnRequestDeclined", declEvent);
            SendEventToSession<ClansRemoteEventListener>(inviteDoc.invitedId, "OnRequestDeclined", declEvent);
            SendResponse(guid);
        }

        private void AcceptJoinRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument localPlayerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var requestDoc = BoltMainDatabaseProvider.Instance.GetJoinRequest(requestId);
            if (requestDoc == null)
            {
                SendResponse(guid);
                return;
            }

            // Берём клан из заявки, а не из клана принимающего
            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetClanDocument(requestDoc.clanId);
            if (clanDocument == null)
            {
                SendError(guid, 2008);
                return;
            }

            int effectiveMaxMembers = clanDocument.maxMembersCount > 0 ? clanDocument.maxMembersCount : 10;
            if (clanDocument.membersCount >= effectiveMaxMembers)
            {
                SendError(guid, 2015);
                return;
            }

            PlayerDocument joiningPlayer = BoltMainDatabaseProvider.Instance.GetPlayerDocument(ObjectId.Parse(requestDoc.senderId));
            try
            {
                BoltMainDatabaseProvider.Instance.JoinClan(clanDocument, joiningPlayer);
            }
            catch (ClanNotFoundRpcException)
            {
                SendError(guid, 2008);
                return;
            }
            catch (PlayerIsAlreadyInClanRpcException)
            {
                SendError(guid, 2011);
                return;
            }

            BoltMainDatabaseProvider.Instance.DeleteJoinRequest(requestId);

            OnJoinedToClanEvent joinedEvent = new OnJoinedToClanEvent
            {
                Clan = ClanMapper.Instance.ToProto(clanDocument)
            };
            SendEventToSession<ClansRemoteEventListener>(joiningPlayer._id.ToString(), "OnJoinedToClan", joinedEvent);

            foreach (var member in clanDocument.GetMembers())
            {
                OnMemberJoinedToClanEvent memberJoinedEvent = new OnMemberJoinedToClanEvent
                {
                    ClanMember = new Axlebolt.Bolt.Protobuf.ClanMember
                    {
                        ClanId = clanDocument._id.ToString(),
                        RoleId = 1000,
                        CreateDate = Utils.ToUnixTime(DateTime.UtcNow)
                    }
                };
                memberJoinedEvent.ClanMember.PlayerFriend.Player = FriendHelper.GetPlayer(joiningPlayer._id.ToString());
                memberJoinedEvent.ClanMember.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnMemberJoinedToClan", memberJoinedEvent);
            }

            SendResponse(guid);
        }

        private void AcceptInviteRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            var inviteDoc = BoltMainDatabaseProvider.Instance.GetInvite(requestId);
            if (inviteDoc == null)
            {
                SendResponse(guid);
                return;
            }

            ClanDocument clanDocument = BoltMainDatabaseProvider.Instance.GetClanDocument(inviteDoc.clanId);
            if (clanDocument == null)
            {
                SendError(guid, 2008);
                return;
            }

            int effectiveMaxMembers = clanDocument.maxMembersCount > 0 ? clanDocument.maxMembersCount : 10;
            if (clanDocument.membersCount >= effectiveMaxMembers)
            {
                SendError(guid, 2015);
                return;
            }

            try
            {
                BoltMainDatabaseProvider.Instance.JoinClan(clanDocument, playerDocument);
            }
            catch (ClanNotFoundRpcException)
            {
                SendError(guid, 2008);
                return;
            }
            catch (PlayerIsAlreadyInClanRpcException)
            {
                SendError(guid, 2011);
                return;
            }

            BoltMainDatabaseProvider.Instance.DeleteInvite(requestId);

            OnJoinedToClanEvent joinedEvent = new OnJoinedToClanEvent
            {
                Clan = ClanMapper.Instance.ToProto(clanDocument)
            };
            SendEventToSession<ClansRemoteEventListener>(playerDocument._id.ToString(), "OnJoinedToClan", joinedEvent);

            foreach (var member in clanDocument.GetMembers())
            {
                OnMemberJoinedToClanEvent memberJoinedEvent = new OnMemberJoinedToClanEvent
                {
                    ClanMember = new Axlebolt.Bolt.Protobuf.ClanMember
                    {
                        ClanId = clanDocument._id.ToString(),
                        RoleId = 1000,
                        CreateDate = Utils.ToUnixTime(DateTime.UtcNow)
                    }
                };
                memberJoinedEvent.ClanMember.PlayerFriend.Player = FriendHelper.GetPlayer(playerDocument._id.ToString());
                memberJoinedEvent.ClanMember.PlayerFriend.RelationshipStatus = RelationshipStatus.None;
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, "OnMemberJoinedToClan", memberJoinedEvent);
            }

            SendResponse(guid);
        }

        private void DeleteClosedInviteRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            BoltMainDatabaseProvider.Instance.DeleteInvite(requestId);
            SendResponse(guid);
        }

        private void DeleteClosedJoinRequest(BinaryValue[] binaryValues, string guid)
        {
            string requestId = binaryValues.GetValue<string>(0);
            BoltMainDatabaseProvider.Instance.DeleteJoinRequest(requestId);
            SendResponse(guid);
        }

        private void GetClanUnreadInviteRequestsCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan == null)
            {
                SendResponse(guid, 0);
                return;
            }
            List<ClanInviteDocument> invites = BoltMainDatabaseProvider.Instance.GetClanInvites(clan);
            SendResponse(guid, invites.Count);
        }

        private void GetPlayerUnreadJoinRequestsCount(string guid)
        {
            PlayerDocument playerDocument = BoltMainDatabaseProvider.Instance.GetPlayerDocument(PlayerObjectId);
            List<ClanRequestDocument> requests = BoltMainDatabaseProvider.Instance.GetPlayerRequests(playerDocument);
            SendResponse(guid, requests.Count);
        }

        private void SendEventToClanMembers(PlayerDocument playerDocument, string eventName, object eventObj)
        {
            ClanDocument clan = BoltMainDatabaseProvider.Instance.GetPlayerClanDocument(playerDocument);
            if (clan == null) return;
            foreach (var member in clan.GetMembers())
            {
                SendEventToSession<ClansRemoteEventListener>(member.PlayerFriend.Player.Id, eventName, eventObj);
            }
        }


        public override void Invoke(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "createclan":
                    CreateClan(request.Params.ToArray(), request.Id);
                    break;
                case "changeclanname":
                case "renameclan":
                    RenameClan(request.Params.ToArray(), request.Id);
                    break;
                case "getclan":
                    GetClan(request.Id);
                    break;
                case "getclanbyid":
                    GetClanById(request.Params.ToArray(), request.Id);
                    break;
                case "changeclantype":
                    ChangeClanType(request.Params.ToArray(), request.Id);
                    break;
                case "leaveclan":
                    LeaveClan(request.Id);
                    break;
                case "getroles":
                    GetRoles(request.Id);
                    break;
                case "setclanavatar":
                    SetClanAvatar(request.Params.ToArray(), request.Id);
                    break;
                case "getavatars":
                    GetAvatars(request.Params.ToArray(), request.Id);
                    break;
                case "sendmsgtoclan":
                    SendMsgToClan(request.Params.ToArray(), request.Id);
                    break;
                case "findclan":
                    FindClan(request.Params.ToArray(), request.Id);
                    break;
                case "getclanmsgs":
                case "getclanchatmessages":
                    GetClanChatMessages(request.Params.ToArray(), request.Id);
                    break;
                case "getclangames":
                    GetClanGames(request.Params.ToArray(), request.Id);
                    break;
                case "getclanmembers":
                    GetClanMembers(request.Id);
                    break;
                case "assignroletomember":
                    AssignRoleToMember(request.Params.ToArray(), request.Id);
                    break;
                case "assignleaderrole":
                    AssignLeaderRole(request.Params.ToArray(), request.Id);
                    break;
                case "deleteclanmsgs":
                    DeleteClanMsgs(request.Id);
                    break;
                case "requesttojoinclan":
                    RequestToJoinClan(request.Params.ToArray(), request.Id);
                    break;
                case "invitetoclan":
                    InviteToClan(request.Params.ToArray(), request.Id);
                    break;
                case "kickmember":
                    KickMember(request.Params.ToArray(), request.Id);
                    break;
                case "getplayerinviterequests":
                    GetPlayerInviteRequests(request.Params.ToArray(), request.Id);
                    break;
                case "getplayerjoinrequests":
                    GetPlayerJoinRequests(request.Params.ToArray(), request.Id);
                    break;
                case "getclanjoinrequests":
                    GetClanJoinRequests(request.Params.ToArray(), request.Id);
                    break;
                case "getclaninviterequests":
                    GetClanInviteRequests(request.Params.ToArray(), request.Id);
                    break;
                case "getclansettings":
                    GetClanSettings(request.Id);
                    break;
                case "getplayerinviterequestscount":
                    GetPlayerInviteRequestsCount(request.Id);
                    break;
                case "getplayerclosedjoinrequestscount":
                    GetPlayerClosedJoinRequestsCount(request.Id);
                    break;
                case "getclanjoinrequestscount":
                    GetClanJoinRequestsCount(request.Id);
                    break;
                case "getclanclosedinviterequestscount":
                    GetClanClosedInviteRequestsCount(request.Id);
                    break;
                case "validateclanname":
                    ValidateClanName(request.Params.ToArray(), request.Id);
                    break;
                case "validateclantag":
                    ValidateClanTag(request.Params.ToArray(), request.Id);
                    break;
                case "setclandescription":
                    SetClanDescription(request.Params.ToArray(), request.Id);
                    break;
                case "increasemaxmemberscount":
                    IncreaseMaxMembersCount(request.Params.ToArray(), request.Id);
                    break;
                case "getclanmembersbyid":
                case "getclanmembersbyclanid":
                    GetClanMembersByClanId(request.Params.ToArray(), request.Id);
                    break;
                case "declinejoinrequest":
                    DeclineJoinRequest(request.Params.ToArray(), request.Id);
                    break;
                case "canceljoinrequest":
                    CancelJoinRequest(request.Params.ToArray(), request.Id);
                    break;
                case "getrecommendedclans":
                    GetRecommendedClans(request.Params.ToArray(), request.Id);
                    break;
                case "declineinviterequest":
                    DeclineInviteRequest(request.Params.ToArray(), request.Id);
                    break;
                case "cancelinviterequest":
                    CancelInviteRequest(request.Params.ToArray(), request.Id);
                    break;
                case "acceptjoinrequest":
                    AcceptJoinRequest(request.Params.ToArray(), request.Id);
                    break;
                case "acceptinviterequest":
                    AcceptInviteRequest(request.Params.ToArray(), request.Id);
                    break;
                case "deleteclosedinviterequest":
                    DeleteClosedInviteRequest(request.Params.ToArray(), request.Id);
                    break;
                case "deleteclosedjoinrequest":
                    DeleteClosedJoinRequest(request.Params.ToArray(), request.Id);
                    break;
                case "getclanunreadinviterequestscount":
                    GetClanUnreadInviteRequestsCount(request.Id);
                    break;
                case "getplayerunreadjoinrequestscount":
                    GetPlayerUnreadJoinRequestsCount(request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }
    }
}
