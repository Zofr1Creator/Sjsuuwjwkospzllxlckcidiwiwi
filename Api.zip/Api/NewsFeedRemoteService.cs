using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using StandRiseServer.MongoDB;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("NewsFeedRemoteService")]
    public class NewsFeedRemoteService : RpcClass
    {
        public NewsFeedRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "getItems":
                    await GetItems(request.Params.ToArray(), request.Id);
                    break;
                case "sendNews":
                    await SendNews(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task GetItems(BinaryValue[] values, string guid)
        {
            try
            {
                int from = (int)new FromByteMethod(typeof(int)).FromBytes(values[0]);
                int count = (int)new FromByteMethod(typeof(int)).FromBytes(values[1]);
                
                // Typically returns a list of news items
                var response = new List<Axlebolt.Bolt.Protobuf.Item>();
                
                // Placeholder: Return empty array for now
                SendResponse(guid, response.ToArray());
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task SendNews(BinaryValue[] values, string guid)
        {
            try
            {
                string newsFeedItemDefinitionId = (string)new FromByteMethod(typeof(string)).FromBytes(values[0]);
                // Implementation for sending news
                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private void SendResponse(string guid, object response = null)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = response != null ? ProtoReflectionUtils.CreateToByteMethod(response.GetType()).ToBytes(response) : new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
