using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using Google.Protobuf;
using MongoDB.Bson;
using MongoDB.Driver;
using StandRiseServer.MongoDB;
using StandRiseServer.MongoDB.Data;
using StandRiseServer.MongoDB.Game;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.RpcServer.Helpers;

namespace StandRiseServer.RpcServer.Api
{
    [RpcService("GameEventRemoteService")]
    public class GameEventRemoteService : RpcClass
    {
        public GameEventRemoteService(UserService user) : base(user) { }

        public override async Task InvokeAsync(RpcRequest request)
        {
            switch (request.MethodName)
            {
                case "saveChallenge2":
                    await SaveChallenge2(request.Params.ToArray(), request.Id);
                    break;
                case "getAllChallenges":
                    await GetAllChallenges(request.Params.ToArray(), request.Id);
                    break;
                case "getCurrentGameEvents":
                    await GetCurrentGameEvents(request.Id);
                    break;
                case "setChallengeProgress":
                case "processChallenge":
                case "setGameChallengeProgress":
                    await SaveChallengeProgress(request.Params.ToArray(), request.Id, request.MethodName);
                    break;
                case "getPlayerCurrentGameEvents":
                    await GetPlayerCurrentGameEvents(request.Id);
                    break;
                case "progressGameEvent":
                    await ProgressGameEvent(request.Params.ToArray(), request.Id);
                    break;
                case "getCurrentChallenges":
                    await GetCurrentChallenges(request.Params.ToArray(), request.Id);
                    break;
                case "buyEventLevel":
                    await BuyEventLevel(request.Params.ToArray(), request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            _ = InvokeAsync(request);
        }

        private async Task SaveChallenge2(BinaryValue[] values, string guid)
        {
            try
            {
                // Official API: SaveChallenge2(code, action, targetPoints) вЂ” editor mission definition, not player progress.
                SendResponse(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetAllChallenges(BinaryValue[] values, string guid)
        {
            try
            {
                var response = new GetAllChallengesResponse();
                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetCurrentGameEvents(string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                await GetPlayerCurrentGameEvents(guid);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetPlayerCurrentGameEvents(string guid)
{
    try
    {
        if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
        {
            SendError(guid, 401);
            return;
        }

        BoltGameDatabaseProvider gameDb = BoltGameDatabaseProvider.Instance;
        BoltMainDatabaseProvider mainDb = BoltMainDatabaseProvider.Instance;
        GetCurrentGameEventsResponse response = new GetCurrentGameEventsResponse();

        BoltGameEventDocument gameEventDoc = gameDb.GetGameEvent("DRAGON_RISE");

        if (gameEventDoc == null)
        {
            SendResponse(guid, response);
            return;
        }

        var bpProgress = PlayerBattlePassRepository.Instance.LoadProgress(playerId, gameEventDoc);
        if (bpProgress == null)
        {
            SendResponse(guid, response);
            return;
        }

        string eventId = !string.IsNullOrWhiteSpace(gameEventDoc.code)
            ? gameEventDoc.code
            : gameEventDoc._id.ToString();

        int clampedPoints = GamePassRewardHelper.ClampEventPoints(gameEventDoc, bpProgress.points);
        if (clampedPoints != bpProgress.points)
        {
            bpProgress.points = clampedPoints;
            GamePassRewardHelper.SyncLevelsOnDocument(bpProgress, gameEventDoc, playerId);
            PlayerBattlePassRepository.Instance.Save(bpProgress);
        }

        GamePassRewardHelper.EnsureClaimStateInitialized(playerId, gameEventDoc, clampedPoints);
        GamePassRewardHelper.GrantPendingPassRewards(playerId, gameEventDoc);
        bpProgress = PlayerBattlePassRepository.Instance.LoadProgress(playerId, gameEventDoc);
        if (bpProgress == null)
        {
            SendResponse(guid, response);
            return;
        }

        GamePassRewardHelper.SyncLevelsOnDocument(bpProgress, gameEventDoc, playerId);
        PlayerBattlePassRepository.Instance.Save(bpProgress);

        clampedPoints = Math.Max(0, bpProgress.points);
        int freePassLevel = bpProgress.freePassLevel;
        int goldPassLevel = bpProgress.goldPassLevel;

        CurrentGameEvent gameEvent = new CurrentGameEvent
        {
            Id = eventId,
            Code = gameEventDoc.code ?? eventId,
            CurrentDay = Math.Max(1, Math.Min(
                (int)((DateTimeOffset.UtcNow.ToUnixTimeSeconds() - gameEventDoc.dateSince) / 86400) + 1,
                gameEventDoc.durationDays)),
            DateSince = gameEventDoc.dateSince * 1000L,
            DateUntil = gameEventDoc.dateUntil * 1000L,
            DurationDays = gameEventDoc.durationDays,
            Points = clampedPoints
        };

        var gamePassesLevels = BoltGameEventDocument.GetByDocument(gameEventDoc.levels);

        bool hasGoldPass = GamePassRewardHelper.PlayerHasGoldPass(gameDb, playerId, gameEventDoc.goldPassItem);

        if (gamePassesLevels.ContainsKey("freePass"))
        {
            var freePassLevels = gamePassesLevels["freePass"];
            GamePass freePass = new GamePass
            {
                Id = GamePassRewardHelper.FreePassKey,
                Code = GamePassRewardHelper.FreePassKey,
                CurrentLevel = freePassLevel,
                KeyItemDefinitionId = 0
            };
            freePass.Levels.AddRange(freePassLevels.GetGamePassLevelsProto());
            gameEvent.GamePasses.Add(freePass);
        }

        if (gamePassesLevels.ContainsKey("goldPass"))
        {
            var goldPassLevels = gamePassesLevels["goldPass"];
            GamePass goldPass = new GamePass
            {
                Id = GamePassRewardHelper.GoldPassKey,
                Code = GamePassRewardHelper.GoldPassKey,
                CurrentLevel = hasGoldPass ? goldPassLevel : 0,
                KeyItemDefinitionId = gameEventDoc.goldPassItem
            };
            goldPass.Levels.AddRange(goldPassLevels.GetGamePassLevelsProto());
            gameEvent.GamePasses.Add(goldPass);
        }

            response.GameEvents.Add(gameEvent);
            SendResponse(guid, response);
        }
        catch (System.Exception ex)
        {
            Logger.Exception(ex);
            SendError(guid, 500);
        }
        }

        private async Task SaveChallengeProgress(BinaryValue[] values, string guid, string rpcMethod)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                ProgressChallengeRequest request = (ProgressChallengeRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension
                    .GetValue<ProgressChallengeRequest>(values, 0);

                if (request == null || string.IsNullOrWhiteSpace(request.GameEventChallengeId))
                {
                    Logger.Error($"[Challenges] {rpcMethod}: empty GameEventChallengeId");
                    SendError(guid, 400);
                    return;
                }

                string challengeId = request.GameEventChallengeId.Trim();
                ChallengeSaveResult result = ChallengeProgressHelper.SaveProgress(
                    playerId, challengeId, request.Points, pushPassChangesToClient: false);

                Logger.Log($"[Challenges] {rpcMethod} player={playerId} id={challengeId} " +
                    $"incoming={request.Points} stored={result.StoredPoints} " +
                    $"target={result.TargetPoints} completed={result.Completed}");

                var response = new ProgressChallengeResponse
                {
                    ChallengePoints = result.StoredPoints,
                    Completed = result.Completed,
                    EventPoints = result.EventPoints
                };

                if (GamePassRewardHelper.HasPassRewards(result.PassProgress) || result.EventPointsAwarded > 0)
                    GamePassRewardHelper.FillProgressChallengeResponse(response, result.PassProgress);
                else
                {
                    var gameDb = BoltGameDatabaseProvider.Instance;
                    BoltGameEventDocument gameEventDoc = gameDb.GetActiveGameEvent() ?? gameDb.GetGameEvent("DRAGON_RISE");
                    if (gameEventDoc != null)
                    {
                        var bp = PlayerBattlePassRepository.Instance.LoadProgress(playerId, gameEventDoc);
                        if (bp != null)
                        {
                            GamePassRewardHelper.SyncLevelsOnDocument(bp, gameEventDoc, playerId);
                            PlayerBattlePassRepository.Instance.Save(bp);
                            response.EventPoints = bp.points;
                            response.EventGamePassLevels[GamePassRewardHelper.FreePassKey] = bp.freePassLevel;
                            if (bp.goldPassLevel > 0)
                                response.EventGamePassLevels[GamePassRewardHelper.GoldPassKey] = bp.goldPassLevel;
                        }
                    }
                }

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task ProgressGameEvent(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                ProgressGameEventRequest request = (ProgressGameEventRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension
                    .GetValue<ProgressGameEventRequest>(values, 0);

                BoltGameDatabaseProvider gameDb = BoltGameDatabaseProvider.Instance;

                BoltGameEventDocument gameEventDoc = gameDb.GetActiveGameEvent() ?? gameDb.GetGameEvent("DRAGON_RISE");
                if (gameEventDoc == null)
                {
                    SendError(guid, 404);
                    return;
                }

                if (request.Points <= 0)
                {
                    SendError(guid, 400);
                    return;
                }

                var passProgress = GamePassRewardHelper.ApplyEventPoints(playerId, gameEventDoc, request.Points);
                var response = new ProgressGameEventResponse();
                GamePassRewardHelper.FillProgressGameEventResponse(response, passProgress);

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task BuyEventLevel(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                ProgressGameEventRequest request = (ProgressGameEventRequest)StandRiseServer.RpcServer.Core.RpcRequestExtension
                    .GetValue<ProgressGameEventRequest>(values, 0);

                var db = BoltGameDatabaseProvider.Instance;
                var gameEvent = db.GetActiveGameEvent();
                if (gameEvent == null)
                {
                    SendError(guid, 404);
                    return;
                }

                if (!db.IsEnoughFunds(playerId, "102", 100))
                {
                    SendError(guid, 101);
                    return;
                }

                db.CurrencyMinusValue(ObjectId.Parse(playerId), 102, 100);

                var bp = PlayerBattlePassRepository.Instance.LoadProgress(playerId, gameEvent);
                double currentPoints = bp.points;

                if (gameEvent.levels == null || gameEvent.levels.Count == 0)
                {
                    db.CurrencyPlusValue(ObjectId.Parse(playerId), 102, 100);
                    SendError(guid, 404);
                    return;
                }

                var levelsMap = MongoDB.Game.BoltGamePassLevels.GetByDocument(
                    gameEvent.levels.ContainsKey("default")
                        ? gameEvent.levels["default"]
                        : gameEvent.levels.Values.FirstOrDefault());

                var nextLevel = levelsMap.PassLevels.Values
                    .OrderBy(l => l.minPoints)
                    .FirstOrDefault(l => l.minPoints > currentPoints);

                if (nextLevel == null)
                {
                    double maxPoints = levelsMap.PassLevels.Values.Max(l => l.minPoints);
                    if (currentPoints >= maxPoints)
                    {
                        db.CurrencyPlusValue(ObjectId.Parse(playerId), 102, 100);
                        SendError(guid, 400);
                        return;
                    }

                    nextLevel = levelsMap.PassLevels.Values.OrderByDescending(l => l.minPoints).First();
                }

                int pointsDelta = (int)nextLevel.minPoints - (int)currentPoints;
                if (pointsDelta <= 0)
                    pointsDelta = 1;

                var passProgress = GamePassRewardHelper.ApplyEventPoints(playerId, gameEvent, pointsDelta);
                var response = new ProgressGameEventResponse();
                GamePassRewardHelper.FillProgressGameEventResponse(response, passProgress);

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private async Task GetCurrentChallenges(BinaryValue[] values, string guid)
        {
            try
            {
                if (!StaticClasses.Users.TryGetValue(_user.TcpClient, out string playerId))
                {
                    SendError(guid, 401);
                    return;
                }

                GetCurrentChallengesRequest request = (GetCurrentChallengesRequest)
                    StandRiseServer.RpcServer.Core.RpcRequestExtension
                        .GetValue<GetCurrentChallengesRequest>(values, 0);

                var response = new GetCurrentChallengesResponse();

                foreach (var challenge in ChallengeProgressHelper.LoadCurrentChallenges(playerId))
                {
                    response.Challenges.Add(challenge);
                }

                Logger.Log($"[Challenges] requestId={request?.GameEventId ?? "null"} " +
                    $"completedFilter={request?.Completed} sent={response.Challenges.Count} " +
                    $"daily={response.Challenges.Count(c => c.Type == "D")} weekly={response.Challenges.Count(c => c.Type == "W")}");

                SendResponse(guid, response);
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        private void SendResponse(string guid, IMessage response = null)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Return = response != null ? new BinaryValue { One = response.ToByteString() } : new BinaryValue { IsNull = true }
                }
            });
        }

        private void SendError(string guid, int code)
        {
            _user.SendResponce(new ResponseMessage
            {
                RpcResponse = new RpcResponse
                {
                    Id = guid,
                    Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                    {
                        Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                        Code = code
                    }
                }
            });
        }
    }
}
