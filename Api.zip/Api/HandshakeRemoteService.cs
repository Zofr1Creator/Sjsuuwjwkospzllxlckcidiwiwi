using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Protobuf;
using Axlebolt.Bolt.Protobuf;
using Axlebolt.RpcSupport.Protobuf;
using StandRiseServer.MongoDB.Main;
using StandRiseServer.MongoDB;
using MongoDB.Bson;
using StandRiseServer.MongoDB.Game;

namespace StandRiseServer.RpcServer.Api
{
    public class HandshakeRemoteService : RpcClass
    {
        public HandshakeRemoteService(UserService user) : base(user)
        {
        }
        public void ProtoHandshake(BinaryValue[] value, string guid)
        {
            FromByteMethod from = new FromByteMethod(typeof(Handshake));
            ResponseMessage result = null;
            Handshake Val = (Handshake)from.FromBytes(value[0]);
            string ticket = Val.Ticket;
            if (StaticClasses.Tokens.TryGetValue(ticket, out Token val))
            {
                PlayerDocument doc2 = BoltMainDatabaseProvider.Instance.GetPlayerDocument(val.playerId);
                result = new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Return = new BinaryValue
                        {
                            IsNull = true
                        }
                    }
                };
                if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string tt))
                {
                    Logger.LogWarn($"[Handshake] Player {doc2._id} already tracked for this socket. Resetting state anyway.");
                }

                bool rankedOnlyHandshake = StaticClasses.EventSenders.ContainsKey(doc2._id.ToString());
                _user.InitEventSenders(doc2._id.ToString(), rankedConnectionOnly: rankedOnlyHandshake);
                
                // Сбрасываем статус античита при новом подключении
                BoltMainDatabaseProvider.Instance.SetAnticheatStatus(doc2._id, 0);
                
                // Генерируем токен запроса для защиты от дюпов
                string requestToken = RequestTokenValidator.InitializeRequestToken(doc2._id.ToString());
                
                // Check if player has active game session
                RpcServer.PlayerStatus currentStatus = null;
                if (StaticClasses.PlayersStatus.TryGetValue(doc2._id.ToString(), out currentStatus) && 
                    currentStatus?.playInGame != null && 
                    !string.IsNullOrEmpty(currentStatus.playInGame.lobbyId))
                {
                    // Player has active game - restore connection to it
                    Logger.Log($"[Handshake] Player {doc2._id} reconnecting to active game: {currentStatus.playInGame.lobbyId}");
                    currentStatus.onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOnline;
                    BoltMainDatabaseProvider.Instance.SetPlayerStatus(val.playerId, currentStatus);
                }
                else
                {
                    // No active game - set to online
                    BoltMainDatabaseProvider.Instance.SetPlayerStatus(val.playerId, new RpcServer.PlayerStatus { onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOnline, playInGame = new RpcServer.PlayInGame { gameCode = "standoff2", gameVersion = "0.16.0", lobbyId = "", photonGame = null, gameState = "Online" } });
                }
                
                StaticClasses.Users.TryAdd(_user.TcpClient, doc2._id.ToString());
                Logger.Log($"[Handshake] User {doc2._id} handshake successful! Request token: {requestToken.Substring(0, 10)}...");
            }
            else
            {
                _user.SendResponce(new ResponseMessage
                {
                    RpcResponse = new RpcResponse
                    {
                        Id = guid,
                        Exception = new Axlebolt.RpcSupport.Protobuf.Exception
                        {
                            Id = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 8),
                            Code = 2003
                        }
                    }
                });
                return;
            }
            
            // Отправляем ответ (токен клиент получит через отдельный механизм)
            _user.SendResponce(result);
        }
        public async Task EncryptedHandshake(BinaryValue[] value, string guid)
        {
            try
            {
                Handshake Val = null;
                byte[] data = value[0].One.ToByteArray();
                
                try
                {
                    // Use the same keys as GoogleAuthRemoteService
                    byte[] key = Encoding.ASCII.GetBytes("key_abcdefghijkl");
                    byte[] IV = Encoding.ASCII.GetBytes("iv_abcdefghijklm");
                    byte[] handshake = await Utils.DecryptByteAsync(data, key, IV);
                    Val = Handshake.Parser.ParseFrom(handshake);
                    Logger.Log("[Handshake] Decrypted successfully");
                }
                catch (System.Exception ex)
                {
                    Logger.Log($"[Handshake] Decryption failed: {ex.Message}");
                    // Fallback: Try parsing as raw Handshake proto (legacy/alternative pattern)
                    try
                    {
                        Val = Handshake.Parser.ParseFrom(data);
                        Logger.Log("[Handshake] Parsed as raw proto instead");
                    }
                    catch
                    {
                        throw; // Re-throw the original decryption error if both fail
                    }
                }

                if (Val == null || string.IsNullOrEmpty(Val.Ticket))
                {
                    SendError(guid, 2003);
                    return;
                }

                string ticket = Val.Ticket;
                if (StaticClasses.Tokens.TryGetValue(ticket, out Token val))
                {
                    PlayerDocument doc = await BoltMainDatabaseProvider.Instance.GetPlayerDocumentAsync(val.playerId);
                    
                    if (StaticClasses.Users.TryGetValue(_user.TcpClient, out string tt))
                    {
                        Logger.LogWarn($"[Handshake] Player {doc._id} already tracked. Resetting state.");
                    }

                    bool rankedOnlyHandshake = StaticClasses.EventSenders.ContainsKey(doc._id.ToString());
                    _user.InitEventSenders(doc._id.ToString(), rankedConnectionOnly: rankedOnlyHandshake);
                    
                    // Сбрасываем статус античита при новом подключении
                    BoltMainDatabaseProvider.Instance.SetAnticheatStatus(doc._id, 0);
                    
                    // Генерируем токен запроса для защиты от дюпов
                    string requestToken = RequestTokenValidator.InitializeRequestToken(doc._id.ToString());
                    
                    // Check if player has active game session
                    RpcServer.PlayerStatus currentStatus = null;
                    if (StaticClasses.PlayersStatus.TryGetValue(doc._id.ToString(), out currentStatus) && 
                        currentStatus?.playInGame != null && 
                        !string.IsNullOrEmpty(currentStatus.playInGame.lobbyId))
                    {
                        // Player has active game - restore connection to it
                        Logger.Log($"[Handshake] Player {doc._id} reconnecting to active game: {currentStatus.playInGame.lobbyId}");
                        currentStatus.onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOnline;
                        await BoltMainDatabaseProvider.Instance.SetPlayerStatusAsync(val.playerId, currentStatus);
                    }
                    else
                    {
                        // No active game - set to online
                        await BoltMainDatabaseProvider.Instance.SetPlayerStatusAsync(val.playerId, new RpcServer.PlayerStatus 
                        { 
                            onlineStatus = RpcServer.PlayerStatus.OnlineStatus.StateOnline, 
                            playInGame = new RpcServer.PlayInGame { gameCode = "standoff2", gameVersion = "0.16.0", lobbyId = "", photonGame = null, gameState = "Online" } 
                        });
                    }
                    
                    StaticClasses.Users.TryAdd(_user.TcpClient, doc._id.ToString());
                    Logger.Log($"[Handshake] User {doc._id} handshake successful (Encrypted)! Request token: {requestToken.Substring(0, 10)}...");
                    
                    // Отправляем ответ (токен клиент получит через отдельный механизм)
                    SendResponse(guid);
                }
                else
                {
                    SendError(guid, 2003);
                }
            }
            catch (System.Exception ex)
            {
                Logger.Exception(ex);
                SendError(guid, 500);
            }
        }

        public override async Task InvokeAsync(RpcRequest request)
        {
            string methodName = request.MethodName.ToLowerInvariant();
            switch (methodName)
            {
                case "encryptedhandshake":
                case "encryptedhandshake2":
                    await this.EncryptedHandshake(request.Params.ToArray(), request.Id);
                    break;
                case "protohandshake":
                case "handshake":
                case "handshake2":
                case "auth":
                    ProtoHandshake(request.Params.ToArray(), request.Id);
                    break;
                case "logout":
                    SendResponse(request.Id);
                    break;
                default:
                    MethodNotFound(request);
                    break;
            }
        }

        public override void Invoke(RpcRequest request)
        {
            InvokeAsync(request).Wait();
        }
    }
}
